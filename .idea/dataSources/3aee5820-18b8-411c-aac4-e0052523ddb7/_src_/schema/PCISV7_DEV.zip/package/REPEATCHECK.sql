CREATE package repeatcheck is

  PROCEDURE liability_insurance_repeat(CAppType  IN VARCHAR2,
                                       CProdNo   IN VARCHAR2,
                                       CAppNo    IN VARCHAR2,
                                       CPlyNo    IN VARCHAR2,
                                       NEdrPrjNo IN NUMBER,
                                       CResult   OUT VARCHAR2);

end repeatcheck;
/
