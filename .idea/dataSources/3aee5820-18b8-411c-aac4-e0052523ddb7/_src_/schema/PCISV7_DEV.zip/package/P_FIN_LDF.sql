CREATE package P_FIN_LDF is
   --已决季度进展因子
   procedure P_Fin_Amt_Ldf(v_today varchar2, v_cal_type in char, v_return out varchar2);
   --已报季度进展因子
   procedure P_Fin_Report_Ldf(v_today varchar2, v_cal_type in char, v_return out varchar2);
end P_FIN_LDF;
/
