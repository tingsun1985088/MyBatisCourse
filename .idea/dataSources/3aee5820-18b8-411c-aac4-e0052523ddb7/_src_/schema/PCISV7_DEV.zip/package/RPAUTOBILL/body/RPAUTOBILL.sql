CREATE PACKAGE BODY "RPAUTOBILL" is

--自营、共入（除去0332、0330、06和13大类）
PROCEDURE PREMDUE (succflag out varchar2) is
V_RCPT_NO       WEB_FIN_MADCR.C_RCPT_NO%TYPE;
V_FEE_TYP       WEB_FIN_MADCR.C_FEE_TYP%TYPE;
V_END_TM       WEB_FIN_MADCR.T_END_TM%TYPE;
V_CHA_CDE      WEB_FIN_MADCR.C_CHA_CDE%TYPE;
V_EDR_NO     WEB_FIN_MADCR.C_EDR_NO%TYPE;
V_COMPANY_CDE         WEB_FIN_MADCR.C_COMPANY_CDE%TYPE;
V_SALEGRP_CDE            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
V_CURRENT_DPT_CDE  WEB_FIN_MADCR.C_CURRENT_DPT_CDE%TYPE;
V_C_PRE_FLAG    WEB_FIN_MADCR.C_PRE_FLAG%TYPE;
V_SEQ_NO       WEB_FIN_MADCR.C_SEQ_NO%TYPE;
V_CRT_TM       WEB_FIN_MADCR.T_CRT_TM%TYPE;
V_CON_DPT_CDE    WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
V_INSRNC_CDE       WEB_FIN_MADCR.C_INSRNC_CDE%TYPE;
V_ITEM_NO             WEB_FIN_MADCR.C_ITEM_NO%TYPE;
V_PAY_PRSN_NAME    WEB_FIN_MADCR.C_PAY_PRSN_NAME%TYPE;
V_VOU_MEMO        WEB_FIN_MADCR.C_VOU_MEMO%TYPE;
V_SBJT_MEMO        WEB_FIN_MADCR.C_SBJT_MEMO%TYPE;
V_CAV_FLAG           WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
V_FINBANK_CDE     WEB_FIN_MADCR.C_FINBANK_CDE%TYPE;
V_COST_CDE            WEB_FIN_MADCR.C_COST_CDE%TYPE;
V_VOU_NO               WEB_FIN_MADCR.C_VOU_NO%TYPE;
V_CHECK_FLAG      WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
V_USE_ATR              WEB_FIN_MADCR.C_USE_ATR%TYPE;
V_CLM_NO              WEB_FIN_MADCR.C_CLM_NO%TYPE;
V_PLY_NO                WEB_FIN_MADCR.C_PLY_NO%TYPE;
V_CLNT_MRK          WEB_FIN_MADCR.C_CLNT_MRK%TYPE;
V_SBJT_NO              WEB_FIN_MADCR.C_SBJT_NO%TYPE;
V_PROD_NO            WEB_FIN_MADCR.C_PROD_NO%TYPE;
V_DPTACC_NO       WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
V_CUR_NO              WEB_FIN_MADCR.C_CUR_NO%TYPE;
V_CONT_CODE       WEB_FIN_MADCR.C_CONT_CODE%TYPE;
V_SBJT_MRK        WEB_FIN_MADCR.C_SBJT_MRK%TYPE;
V_SEND_FLAG      WEB_FIN_MADCR.C_SEND_FLAG%TYPE;
V_BSNS_TYP         WEB_FIN_MADCR.C_BSNS_TYP%TYPE;
V_RI_COM             WEB_FIN_MADCR.C_RI_COM%TYPE;
V_AMT                  WEB_FIN_MADCR.N_AMT%TYPE;
V_SLS_CDE          WEB_FIN_MADCR.C_SLS_CDE%TYPE;
V_DPT_CDE         WEB_FIN_MADCR.C_DPT_CDE%TYPE;
V_PAY_PRSN_CDE      WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;
V_CHA_CLS        WEB_FIN_MADCR.C_CHA_CLS%TYPE;
V_CHA_MRK       WEB_FIN_MADCR.C_CHA_MRK%TYPE;
V_PERIOD_NAME     WEB_FIN_MADCR.C_PERIOD_NAME%TYPE;
V_VOUCHER_NO     WEB_FIN_MADCR.C_VOUCHER_NO%TYPE;
V_TOTAL_AMT        WEB_FIN_MADCR.N_TOTAL_AMT%TYPE;
V_SERVICETYPE_NO    WEB_FIN_MADCR.C_SERVICETYPE_NO%TYPE;
V_DEPARTMENT_CDE   WEB_FIN_MADCR.C_DEPARTMENT_CDE%TYPE;
V_VERIFYVOU_MEMO   WEB_FIN_MADCR.C_VERIFYVOU_MEMO%TYPE;
V_KIND_NO             WEB_FIN_MADCR.C_KIND_NO%TYPE;
V_EXCH_AMT         WEB_FIN_MADCR.N_EXCH_AMT%TYPE;
V_RATE                   WEB_FIN_MADCR.N_RATE%TYPE;
V_TRANS_MRK     WEB_FIN_MADCR.C_TRANS_MRK%TYPE;
V_TRANS_TM       WEB_FIN_MADCR.T_TRANS_TM%TYPE;
V_PRM_SOU                WEB_FIN_MADCR.C_PRM_SOU%TYPE;
V_DUE_TM                   WEB_FIN_MADCR.T_DUE_TM%TYPE;
V_CHR_CUR_NO        WEB_FIN_MADCR.C_CHR_CUR_NO%TYPE;
V_VEHICLESTYP_NO    WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;
V_AGR_FLAG              WEB_FIN_MADCR.C_AGR_FLAG%TYPE;
V_AGR_KIND               WEB_FIN_MADCR.C_AGR_KIND%TYPE;
V_AGR_TYP                  WEB_FIN_MADCR.C_AGR_TYP%TYPE;
V_SIGN_DATE             WEB_FIN_MADCR.T_SIGN_DATE%TYPE;
V_INSRNC_BGN_TM   WEB_FIN_MADCR.T_INSRNC_BGN_TM%TYPE;
V_INSRNC_END_TM    WEB_FIN_MADCR.T_INSRNC_END_TM%TYPE;
V_INVOICE_NO    WEB_FIN_MADCR.C_INVOICE_NO%TYPE;
V_APP_NME        WEB_FIN_MADCR.C_APP_NME%TYPE;
V_ACCDNT_TM    WEB_FIN_MADCR.T_ACCDNT_TM%TYPE;
V_OVER_DATE      WEB_FIN_MADCR.T_OVER_DATE%TYPE;
V_BILLTYPE          WEB_FIN_MADCR.C_BILLTYPE%TYPE;
V_DATA_SRC        WEB_FIN_MADCR.C_DATA_SRC%TYPE;
V_TRAN_FLAG       WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE;
V_ACCNT_FLAG      WEB_FIN_PRM_DUE.C_ACCNT_FLAG%TYPE;
V_INST_MRK       WEB_FIN_PRM_DUE.C_INST_MRK%TYPE;
V_EDR_TYP       WEB_FIN_PRM_DUE.C_EDR_TYP%TYPE;
V_BALA_MRK      WEB_FIN_PRM_DUE.C_BALA_MRK%TYPE;
V_DUE_AMT        WEB_FIN_PRM_DUE.N_DUE_AMT%TYPE;
V_TMS            WEB_FIN_PRM_DUE.N_TMS%TYPE;
V_POS_FLAG       WEB_FIN_PRM_SUBJECT.C_POS_FLAG%TYPE;
V_PRE_FLAG       WEB_FIN_PRM_SUBJECT.C_PRE_FLAG%TYPE;
V_SBJT_NAME   WEB_FIN_PRM_SUBJECT.C_SBJT_NAME%TYPE;
V_ARP_FLAG      WEB_FIN_PRM_SUBJECT.C_ARP_FLAG%TYPE;
V_ERR_CONTENT              WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
ERRORLINE                  VARCHAR2(400);
V_CNT             INT;

  CURSOR prem_due is
    select C_RCPT_NO,        --单据号
           C_DPT_CDE,        --出单机构
           C_DPTACC_CDE,     --做账机构
           C_PLY_NO,         --保单号
           C_EDR_NO,         -- 批单号
           --C_APP_NO,         --投保单号
           C_BSNS_TYP,       --业务来源
           C_PROD_NO,        --产品代码
           C_TRAN_FLAG,      --业务单据标识(自营标识)
           N_bs_AMT,         --业务金额
           nvl(C_INST_MRK, '0'), --分期标志
           C_PAYER_CDE,          --付款人代码
           C_PAYER_NME,          --付款人名称
           C_SLS_CDE,            --业务员
           C_CHA_MRK,            --渠道标识
           C_CHA_CLS,            --渠道类别
           C_CHA_CDE,            --渠道编码
           C_CON_DPT_CDE,        --共保人
           C_TRANS_MRK,      --迁移标志
           T_TRANS_TM,       --迁移时间
           T_DUE_TM,             --挂账日期
           C_SLSGRP_CDE,         --销售团队
           nvl(c_edr_typ,0),     --批改类型
           C_BALA_MRK,           --冲销标志
           nvl(n_due_amt, 0.00), --挂账金额
           C_ACCNT_FLAG,         --会计状态
           --C_bs_CUR,             --业务币种
           c_due_cur,            --挂账币种
           c_feetyp_cde,         --费用类型代码
          -- C_BANK_CDE,           --银行代码
           C_AGRI_MRK,           --涉农标识
           C_agr_kind,           --涉农性质
           C_agr_typ,            --农险大类
           T_INSRNC_BGN_TM,      --保险起期
       T_INSRNC_END_TM,      --保险止期
           --n_other_amt,          --车船税
       c_circ_vhl_typ,       --车型
         c_app_nme,            --投保人名称
           n_tms,               --期次
       t_issue_tm,           --签单日期
       c_data_src           --数据来源

      from web_fin_prm_due due
     where trunc(t_due_tm) < trunc(sysdate)+1
       and trunc(due.t_insrnc_bgn_tm) < trunc(sysdate)+1
       and c_accnt_flag in('00','10')
       and nvl(N_DUE_AMT, 0) <> 0
       and c_tran_flag in ('1','3')
         and (
           due.c_bala_mrk='0' or (due.c_bala_mrk='1' and nvl(due.c_edr_typ,'0')='2'  and due.c_edr_no is not null
                                                     and exists(
                                                         select 1 from web_fin_prm_due pd where
                                                            pd.c_ply_no=due.c_ply_no
                                                            and pd.n_tms=due.n_tms
                                                            and pd.c_edr_typ is null
                                                            and pd.c_edr_no is null
                                                            and substr(pd.c_accnt_flag,2,1)='1'
                                                            and nvl(pd.c_due_mrk,'0')='1')
                                  )
          )
       and substr(due.c_prod_no,0,2) not in('06','13')
       and due.c_prod_no not in('030001','033001')
      -- and due.dxp_tran_flag in ('A','H')--临时添加
      -- and due.c_rp_flag = '0'
       and nvl(n_other_amt,0) = 0
       and nvl(c_due_mrk, '0') = '0'
       AND c_ply_no IS NOT NULL AND c_ply_no<>CHR(0)
     -- wuqy 06-23 暂时屏蔽   AND nvl(c_slsgrp_cde,'00') <> '00'     --add by wanxc at 20070607  添加销售团队不为空的控制
     --   and substr(due.c_dptacc_cde,0,2)='50'
          and not exists(
           SELECT 1 FROM web_fin_tmp_dcr dcr
           WHERE dcr.c_rcpt_no = due.c_rcpt_no AND c_sbjt_no = '220302'
       );

begin
  succflag := '0';
  open prem_due;
  loop
     begin
    <<GOTO_LAB>>
    FETCH prem_due
      into V_RCPT_NO, V_DPT_CDE, V_DPTACC_NO, V_PLY_NO,V_EDR_NO,V_BSNS_TYP,
    V_PROD_NO,V_TRAN_FLAG,V_AMT,V_INST_MRK,V_PAY_PRSN_CDE,V_PAY_PRSN_NAME,
    V_SLS_CDE, V_CHA_MRK, V_CHA_CLS, V_CHA_CDE, V_CON_DPT_CDE,V_TRANS_MRK,
    V_TRANS_TM, V_DUE_TM, V_SALEGRP_CDE,V_EDR_TYP,V_BALA_MRK,V_DUE_AMT,
    V_ACCNT_FLAG,V_CUR_NO,V_FEE_TYP,V_AGR_FLAG,V_AGR_KIND,V_AGR_TYP,
    V_INSRNC_BGN_TM,V_INSRNC_END_TM,V_VEHICLESTYP_NO,V_APP_NME,V_TMS,V_SIGN_DATE,V_DATA_SRC;
    EXIT WHEN prem_due%NOTFOUND;

        if v_tran_flag = '3' then
            v_tran_flag := '1';
        end if;

      --获取公司段信息

       V_COMPANY_CDE:=rpfunction.getFinCompany(V_DPTACC_NO,V_RCPT_NO);

          --获取科目编号和科目备注，明细段，借贷方向，业务类型,只取第一条数据
          Dz_Proc.get_fin_no(V_SEQ_NO, V_DPT_CDE, '7', dz_proc.g_pttype);
          V_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
          if V_DUE_AMT > 0 then
            V_POS_FLAG := '1';
          else
            V_POS_FLAG := '0';
          end if;

 if substr(V_ACCNT_FLAG, 1, 1) = '0' then --未实收
             V_PRE_FLAG:='1';
               V_VOU_MEMO:='应收保费确认';
          else                           --已实收
             V_PRE_FLAG:='0';
           V_VOU_MEMO:='预收保费结转实收保费';
          end if;

          if V_PRE_FLAG = '0'  then --针对801 预收保费-有单预收
            V_INST_MRK  := '*';   --  V_INST_MRK 预收* 分期为 1 不分期为0  V_PRE_FLAG 未实收 0 已实收 1  V_POS_FLAG 1 正 0 负
          end if;

       select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_pre_flag,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_C_PRE_FLAG,v_prm_sou
              from web_fin_prm_subject
              where c_rp_typ = '701' and rownum=1;

            insert into web_fin_madcr
              (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
               C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
               C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
               c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
               c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
               c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
               c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo, c_Trans_Mrk,t_Trans_Tm,
               c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT
               ,t_insrnc_bgn_tm,t_insrnc_end_tm,t_accdnt_tm,t_over_date,t_sign_date,
               c_vehiclestyp_no,c_agr_flag,c_agr_kind,c_agr_typ,c_edr_no,c_app_nme)
            values
              (V_DUE_TM,V_SEQ_NO,'1',v_CAV_FLAG,v_SBJT_NO,V_DUE_AMT,V_CUR_NO,sysdate,
               v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PROD_NO,v_BSNS_TYP,v_CHA_CLS,
               v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
               '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
               null,V_VOU_MEMO,v_company_cde,null,null,
               v_CON_DPT_CDE,'1',v_PERIOD_NAME,null,null,
               v_SERVICETYPE_NO,null,null,null,null,
               V_FEE_TYP,v_prm_sou,V_DUE_TM,null,null
               ,v_insrnc_bgn_tm,v_insrnc_end_tm,null,null,V_SIGN_DATE,
               V_VEHICLESTYP_NO,v_agr_flag,v_agr_kind,v_agr_typ,V_EDR_NO,v_app_nme);


   if V_EDR_TYP = '2' and V_BALA_MRK = '1' and V_EDR_NO is not  null then
             select C_SBJT_NO,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
                  into v_SBJT_NO,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
                  from  web_fin_madcr m
                  where m.c_sbjt_no<>'6031' and  rownum=1
                 and m.c_rcpt_no=(select c_rcpt_no from Web_Fin_Prm_Due due
                                      where due.c_ply_no=v_PLY_NO and due.n_tms=v_tms and due.c_edr_typ is null and due.c_feetyp_cde='R' and rownum=1);
              if v_SBJT_NO ='224128' then
                  V_DUE_AMT:=-V_DUE_AMT;
              end if;
       else
              select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
              from  web_fin_prm_subject
              where c_inst_mrk = v_inst_mrk       and c_agri_mrk = '*'and c_nat_typ = '*'    and c_ply_typ = '*'and c_fin_typ = '*'
                    and c_rp_typ = '601'   and c_pre_flag = V_PRE_FLAG     and rownum=1;


                   /*退保科目和实收保费挂钩 add by sql*/
                  v_cnt:=0;
                  SELECT COUNT(*) INTO v_cnt
                         FROM web_fin_dcr WHERE c_rcpt_no = trim(v_RCPT_NO) AND c_sbjt_no = '220302';
                  IF v_cnt = 0 THEN
                    select count(1) into v_cnt from (select sum(N_bs_AMT),sum(N_PAID_AMT)  from web_fin_prm_due
                    where c_ply_no =v_PLY_NO and c_edr_typ IS NULL and c_edr_no IS NULL having sum(N_bs_AMT)=sum(N_PAID_AMT));
                      if v_EDR_TYP=3 or (v_AMT <0 AND NVL(LENGTH(v_edr_no),0)>10 AND NVL(LENGTH(v_edr_typ),0)<>2 and v_cnt<>0)  then
                         v_SBJT_NO :='224128';
                         v_CAV_FLAG:='贷';
                         V_DUE_AMT:=-V_DUE_AMT;
                        v_sbjt_memo :='其他应付款-退保费';
                         v_SERVICETYPE_NO:='1000';
                    end if;
               end if;
         end if;
            insert into web_fin_madcr
                  (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
                   C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
                   C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
                   c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
                   c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
                   c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
                   c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo, c_Trans_Mrk,t_Trans_Tm,
                   c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT
                   ,t_insrnc_bgn_tm,t_insrnc_end_tm,t_accdnt_tm,t_over_date,t_sign_date,
                   c_vehiclestyp_no,c_agr_flag,c_agr_kind,c_agr_typ,c_edr_no,c_app_nme)
                values
                  (V_DUE_TM,V_SEQ_NO,'2',v_CAV_FLAG,v_SBJT_NO,V_DUE_AMT,V_CUR_NO,sysdate,
                   v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PROD_NO,v_BSNS_TYP,v_CHA_CLS,
                   v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
                   '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
                   null,V_VOU_MEMO,v_company_cde,null,null,
                   v_CON_DPT_CDE,'1',v_PERIOD_NAME,null,null,
                   v_SERVICETYPE_NO,null,null,null,null,
                   V_FEE_TYP,v_prm_sou,V_DUE_TM,null,null
                   ,v_insrnc_bgn_tm,v_insrnc_end_tm,null,null,V_SIGN_DATE,
                   V_VEHICLESTYP_NO,v_agr_flag,v_agr_kind,v_agr_typ,V_EDR_NO,v_app_nme);


            update web_fin_prm_due set c_due_mrk = '1', t_upd_tm=sysdate, C_ACCNT_FLAG = substr(C_ACCNT_FLAG, 1, 1) || '1'
            where c_rcpt_no = V_RCPT_NO;
   commit;

EXCEPTION
  WHEN OTHERS THEN

      ROLLBACK;
      begin
      errorline :=DBMS_UTILITY.format_error_backtrace;
      v_err_content := 'proc:[premdue],出错流水号:['|| V_RCPT_NO ||'],'||'错误行数:'||errorline||'错误描述:[' || SQLCODE || SQLERRM;
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'), '001', '0000',v_err_content,SYSDATE);
      COMMIT;
      succflag := '-1';
   end;
  end;
  end loop;
  close prem_due;
  commit;
  end;

-- 商车险
PROCEDURE P_PREMDUEACCISC (succflag out varchar2) is
V_RCPT_NO       WEB_FIN_MADCR.C_RCPT_NO%TYPE;
V_FEE_TYP       WEB_FIN_MADCR.C_FEE_TYP%TYPE;
V_END_TM       WEB_FIN_MADCR.T_END_TM%TYPE;
V_CHA_CDE      WEB_FIN_MADCR.C_CHA_CDE%TYPE;
V_EDR_NO     WEB_FIN_MADCR.C_EDR_NO%TYPE;
V_COMPANY_CDE         WEB_FIN_MADCR.C_COMPANY_CDE%TYPE;
V_SALEGRP_CDE            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
V_CURRENT_DPT_CDE  WEB_FIN_MADCR.C_CURRENT_DPT_CDE%TYPE;
V_C_PRE_FLAG    WEB_FIN_MADCR.C_PRE_FLAG%TYPE;
V_SEQ_NO       WEB_FIN_MADCR.C_SEQ_NO%TYPE;
V_CRT_TM       WEB_FIN_MADCR.T_CRT_TM%TYPE;
V_CON_DPT_CDE    WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
V_INSRNC_CDE       WEB_FIN_MADCR.C_INSRNC_CDE%TYPE;
V_ITEM_NO             WEB_FIN_MADCR.C_ITEM_NO%TYPE;
V_PAY_PRSN_NAME    WEB_FIN_MADCR.C_PAY_PRSN_NAME%TYPE;
V_VOU_MEMO        WEB_FIN_MADCR.C_VOU_MEMO%TYPE;
V_SBJT_MEMO        WEB_FIN_MADCR.C_SBJT_MEMO%TYPE;
V_CAV_FLAG           WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
V_FINBANK_CDE     WEB_FIN_MADCR.C_FINBANK_CDE%TYPE;
V_COST_CDE            WEB_FIN_MADCR.C_COST_CDE%TYPE;
V_VOU_NO               WEB_FIN_MADCR.C_VOU_NO%TYPE;
V_CHECK_FLAG      WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
V_USE_ATR              WEB_FIN_MADCR.C_USE_ATR%TYPE;
V_CLM_NO              WEB_FIN_MADCR.C_CLM_NO%TYPE;
V_PLY_NO                WEB_FIN_MADCR.C_PLY_NO%TYPE;
V_CLNT_MRK          WEB_FIN_MADCR.C_CLNT_MRK%TYPE;
V_SBJT_NO              WEB_FIN_MADCR.C_SBJT_NO%TYPE;
V_PROD_NO            WEB_FIN_MADCR.C_PROD_NO%TYPE;
V_DPTACC_NO       WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
V_CUR_NO              WEB_FIN_MADCR.C_CUR_NO%TYPE;
V_CONT_CODE       WEB_FIN_MADCR.C_CONT_CODE%TYPE;
V_SBJT_MRK        WEB_FIN_MADCR.C_SBJT_MRK%TYPE;
V_SEND_FLAG      WEB_FIN_MADCR.C_SEND_FLAG%TYPE;
V_BSNS_TYP         WEB_FIN_MADCR.C_BSNS_TYP%TYPE;
V_RI_COM             WEB_FIN_MADCR.C_RI_COM%TYPE;
V_N_AMT                  WEB_FIN_MADCR.N_AMT%TYPE;
V_SLS_CDE          WEB_FIN_MADCR.C_SLS_CDE%TYPE;
V_DPT_CDE         WEB_FIN_MADCR.C_DPT_CDE%TYPE;
V_PAY_PRSN_CDE      WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;
V_CHA_CLS        WEB_FIN_MADCR.C_CHA_CLS%TYPE;
V_CHA_MRK       WEB_FIN_MADCR.C_CHA_MRK%TYPE;
V_PERIOD_NAME     WEB_FIN_MADCR.C_PERIOD_NAME%TYPE;
V_VOUCHER_NO     WEB_FIN_MADCR.C_VOUCHER_NO%TYPE;
V_TOTAL_AMT        WEB_FIN_MADCR.N_TOTAL_AMT%TYPE;
V_SERVICETYPE_NO    WEB_FIN_MADCR.C_SERVICETYPE_NO%TYPE;
V_DEPARTMENT_CDE   WEB_FIN_MADCR.C_DEPARTMENT_CDE%TYPE;
V_VERIFYVOU_MEMO   WEB_FIN_MADCR.C_VERIFYVOU_MEMO%TYPE;
V_KIND_NO             WEB_FIN_MADCR.C_KIND_NO%TYPE;
V_EXCH_AMT         WEB_FIN_MADCR.N_EXCH_AMT%TYPE;
V_RATE                   WEB_FIN_MADCR.N_RATE%TYPE;
V_TRANS_MRK     WEB_FIN_MADCR.C_TRANS_MRK%TYPE;
V_TRANS_TM       WEB_FIN_MADCR.T_TRANS_TM%TYPE;
V_PRM_SOU                WEB_FIN_MADCR.C_PRM_SOU%TYPE;
V_DUE_TM                   WEB_FIN_MADCR.T_DUE_TM%TYPE;
V_CHR_CUR_NO        WEB_FIN_MADCR.C_CHR_CUR_NO%TYPE;
V_VEHICLESTYP_NO    WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;
V_AGR_FLAG              WEB_FIN_MADCR.C_AGR_FLAG%TYPE;
V_AGR_KIND               WEB_FIN_MADCR.C_AGR_KIND%TYPE;
V_AGR_TYP                  WEB_FIN_MADCR.C_AGR_TYP%TYPE;
V_SIGN_DATE             WEB_FIN_MADCR.T_SIGN_DATE%TYPE;
V_INSRNC_BGN_TM   WEB_FIN_MADCR.T_INSRNC_BGN_TM%TYPE;
V_INSRNC_END_TM    WEB_FIN_MADCR.T_INSRNC_END_TM%TYPE;
V_INVOICE_NO    WEB_FIN_MADCR.C_INVOICE_NO%TYPE;
V_APP_NME        WEB_FIN_MADCR.C_APP_NME%TYPE;
V_ACCDNT_TM    WEB_FIN_MADCR.T_ACCDNT_TM%TYPE;
V_OVER_DATE      WEB_FIN_MADCR.T_OVER_DATE%TYPE;
V_BILLTYPE          WEB_FIN_MADCR.C_BILLTYPE%TYPE;
V_DATA_SRC        WEB_FIN_MADCR.C_DATA_SRC%TYPE;
V_APP_NO           WEB_FIN_PRM_DUE.C_APP_NO%TYPE;
V_INST_MRK       WEB_FIN_PRM_DUE.C_INST_MRK%TYPE;
V_EDR_TYP       WEB_FIN_PRM_DUE.C_EDR_TYP%TYPE;
V_BALA_MRK      WEB_FIN_PRM_DUE.C_BALA_MRK%TYPE;
V_DUE_AMT        WEB_FIN_PRM_DUE.N_DUE_AMT%TYPE;
V_TMS            WEB_FIN_PRM_DUE.N_TMS%TYPE;
V_TRAN_FLAG        WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE;
V_ACCNT_FLAG       WEB_FIN_PRM_DUE.C_ACCNT_FLAG%TYPE;
V_BS_CUR           WEB_FIN_PRM_DUE.C_BS_CUR%TYPE;
V_UDR_TM         WEB_FIN_PRM_DUE.T_UDR_TM%TYPE;
V_ORIG_PRM        WEB_FIN_PRM_DET_DUE.N_ORIG_PRM%TYPE;       --单险种保费
V_CVRG_NO        WEB_FIN_PRM_DET_DUE.C_CVRG_NO%TYPE;
V_POS_FLAG       WEB_FIN_PRM_SUBJECT.C_POS_FLAG%TYPE;
V_PRE_FLAG       WEB_FIN_PRM_SUBJECT.C_PRE_FLAG%TYPE;
V_SBJT_NAME   WEB_FIN_PRM_SUBJECT.C_SBJT_NAME%TYPE;
V_ARP_FLAG      WEB_FIN_PRM_SUBJECT.C_ARP_FLAG%TYPE;
V_ERR_CONTENT              WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
V_CVRG_SUM          NUMBER(20,2);
V_PRD_NO                  VARCHAR2(10);
V_AMT                      NUMBER;
V_ITEM                     NUMBER(5);
V_COUNT                    NUMBER;


  ---------------add by wkf 2013-6-13
    type num_arry is array(10) of number;
    type char_arry is array(10) of varchar2(10);
    amt_ary num_arry := num_arry();
    prodno_ary char_arry:=char_arry();
    i number;
---------------add by wkf 2013-6-13  end

  CURSOR prem_due is
    select due.C_RCPT_NO,        --单据号
           due.C_DPT_CDE,        --出单机构
           due.C_DPTACC_CDE,     --做账机构
           due.C_PLY_NO,     --保单号
           due.C_APP_NO,     --投保单号
           due.C_BSNS_TYP,       --业务来源
           due.C_PROD_NO,        --产品代码
           due.C_TRAN_FLAG,      --业务单据标识(自营标识)
           due.N_bs_AMT,         --业务金额
           nvl(due.C_INST_MRK, '0'), --分期标志
           due.C_PAYER_CDE,          --付款人代码
           due.C_PAYER_NME,          --付款人名称
           due.C_SLS_CDE,            --业务员
           due.C_CHA_MRK,            --渠道标识
           due.C_CHA_CLS,            --渠道类别
           due.C_CHA_CDE,            --渠道编码
           due.C_CON_DPT_CDE,        --共保人
           due.T_DUE_TM,             --挂账日期
           due.C_SLSGRP_CDE,         --销售团队
           nvl(due.c_edr_typ,0),     --批改类型
           due.C_BALA_MRK,           --冲销标志
           nvl(due.n_due_amt, 0.00), --挂账金额
           due.C_ACCNT_FLAG,         --会计状态
           due.C_bs_CUR,             --业务币种
           due.c_due_cur,            --挂账币种
           due.c_feetyp_cde,      --费用类型代码
           due.n_tms,                       --期次
          --base.n_orig_prm       --单险种保费
           due.C_AGRI_MRK,      --涉农性质
           due.c_agr_kind,       --涉农性质
           due.c_agr_typ,         --农险大类
           due.c_edr_no,          --批单号
           due.c_app_nme,      --投保人名称
           due.t_issue_tm,      --签单日期
           due.c_data_src,       --数据来源
       due.t_udr_tm         --核保时间

      from web_fin_prm_due due,web_bas_fin_prod prd
     where
         trunc(t_due_tm) < trunc(sysdate)+1
       and trunc(due.t_insrnc_bgn_tm) < trunc(sysdate)+1
       and c_accnt_flag in('00','10')
       and c_tran_flag='1'
       and c_rcpt_no = 'R00261010013010201403300100000015'
       and prd.c_prod_no = due.c_prod_no
       and prd.c_prod_no = '033001'
      -- and due.dxp_tran_flag in ('A','H')
       and due.c_rp_flag = '1'
      -- and due.c_app_no = base.c_app_no
     --and due.n_tms = base.n_tms
        and (
           due.c_bala_mrk='0' or (due.c_bala_mrk='1' and nvl(due.c_edr_typ,'0')='2'  and due.c_edr_no is not null
                                                     and exists(
                                                         select 1 from web_fin_prm_due pd where
                                                            pd.c_ply_no=due.c_ply_no
                                                            and pd.n_tms=due.n_tms
                                                            and pd.c_edr_typ is null
                                                            and pd.c_edr_no is null
                                                            and substr(pd.c_accnt_flag,2,1)='1'
                                                            and nvl(pd.c_due_mrk,'0')='1')
                                  )
          )
       and nvl(c_due_mrk, '0') = '0'
      and nvl(N_DUE_AMT, 0) <> 0
   --    and substr(due.c_dptacc_cde,0,2)='50'
         and not exists(
           SELECT 1 FROM web_fin_tmp_dcr dcr
    WHERE dcr.c_rcpt_no = due.c_rcpt_no
        AND c_sbjt_no = '220302'
       );




    cursor prem_cvrg(appno varchar2,nTms number) is
     select cvrg.n_orig_prm as prm,
            map.c_cvrg_no as cvrgno
      from  web_fin_prm_det_due cvrg,web_bas_fin_cvrg_map map
      where cvrg.c_app_no = appno
       -- wuqy add 2014-06-25
        and cvrg.c_cvrg_no = map.c_ocvrg_no
        and cvrg.n_orig_prm <> 0
        and cvrg.n_tms = nTms;
        --and cvrg.c_cvrg_no = prd.c_cvrg_no
      --  and cvrg.c_cvrg_no not in ('030009') wuqy 注释 2014-06-25
      --  and cvrg.dxp_tran_flag in ('A','H')



begin
   succflag := '0';
   amt_ary.extend(4);-- wkf  add by wkf 2013-6-13 -- 数组扩展到4个元素
   prodno_ary.extend(4);-- wkf  add by wkf 2013-6-13-- 数组扩展到4个元素

  open prem_due;
  loop
    begin
    <<GOTO_LAB>>
    FETCH prem_due
      into V_RCPT_NO, V_DPT_CDE, V_DPTACC_NO, V_PLY_NO,V_APP_NO,V_BSNS_TYP,
    V_PROD_NO,V_TRAN_FLAG,V_N_AMT,V_INST_MRK,V_PAY_PRSN_CDE,V_PAY_PRSN_NAME,
    V_SLS_CDE,V_CHA_MRK, V_CHA_CLS, V_CHA_CDE, V_CON_DPT_CDE,V_DUE_TM,
    V_SALEGRP_CDE,V_EDR_TYP,V_BALA_MRK,V_DUE_AMT,V_ACCNT_FLAG,V_BS_CUR,V_CUR_NO,
    V_FEE_TYP,V_TMS,V_AGR_FLAG,V_AGR_KIND,V_AGR_TYP,
    V_EDR_NO,V_APP_NME,V_SIGN_DATE,V_DATA_SRC,V_UDR_TM;
    EXIT WHEN prem_due%NOTFOUND;

    --险别总保费
    select sum(cvrg.n_orig_prm)into V_CVRG_SUM
      from  web_fin_prm_det_due cvrg
      where cvrg.c_app_no = v_app_no
      and cvrg.n_tms= V_TMS;
    --  and cvrg.c_cvrg_no not in ('030009')
    --  and cvrg.dxp_tran_flag in ('A','H')



 if  V_CVRG_SUM = V_N_AMT then

    v_item:=0;
    V_PRD_NO:=v_PROD_NO;
    if V_BS_CUR is null or V_BS_CUR = '' then
       V_BS_CUR:= V_CUR_NO;
    end if;
    if V_BS_CUR <> '01' or V_CUR_NO <> V_BS_CUR then


       if V_BS_CUR = '01' and V_CUR_NO <> '01' then
          v_due_amt := v_due_amt*rpfunction.getRate(V_CUR_NO,'01',V_UDR_TM);
          v_rate:='1';

       elsif V_BS_CUR<>'01' and V_CUR_NO='01' then
          v_rate := rpfunction.getRate(V_BS_CUR,'01',V_UDR_TM);
          v_due_amt:=round(v_due_amt/v_rate,2);
       else
          v_rate := rpfunction.getRate(V_BS_CUR,'01',V_UDR_TM);
       end if;
    else
       v_rate:=1;
    end if;

    if v_edr_typ = '2' and v_BALA_MRK <> '1' then
       INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
       VALUES
          (F_Fin_Getcode('e'),'001','0000',
          'proc:[P_premdueaccisc],出错流水号:['|| v_rcpt_no||']注销冲正',
           SYSDATE);
    else

      --获取公司段信息

       v_COMPANY_CDE:=rpfunction.getFinCompany(v_DPTACC_NO,v_rcpt_no);

       Dz_Proc.get_fin_no(V_SEQ_NO, v_dpt_cde, '7', dz_proc.g_pttype);
       v_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
          --给web_fin_prm_subject.c_pos_flag 赋值
          if v_due_amt > 0 then
            v_pos_flag := '1';
          else
            v_pos_flag := '0';
          end if;

        if substr(v_ACCNT_FLAG, 1, 1) = '0' then --未实收
             v_pre_flag:='1';
               v_vou_memo:='应收保费确认';
          else                           --已实收
             v_pre_flag:='0';
           v_vou_memo:='预收保费结转实收保费';
          end if;


          V_AMT :=0.0;
      ------------------add by wkf 2013-6-13

             amt_ary(1) := null;--033210 --该保单车损险保费
             amt_ary(2) := null;--033211 --该保单车损附加险保费
             amt_ary(3) := null;--033220  --该保单商业三者险保费
             amt_ary(4) := null;--033221   --该保单商业三者险附加险保费

             prodno_ary(1):='033210';
             prodno_ary(2):='033211';
             prodno_ary(3):='033220';
             prodno_ary(4):='033221';

  --------------add by wkf 2013-6-13  end

          for v_prmcvrg in prem_cvrg(v_app_no,v_tms) loop
              V_ORIG_PRM:= v_prmcvrg.prm;     --险别保费
              V_CVRG_NO:= v_prmcvrg.cvrgno;   --险别代码


 ------------------------------------根据商车险情况 进行拆分
              if V_CVRG_NO = '030018'
              then
                 V_CVRG_NO :='033220';  --获取该保单中商业第三者责任险的保费
               V_AMT := V_ORIG_PRM;
               amt_ary(3) :=  V_AMT;
              end if;


              if V_CVRG_NO = '030006'
              then
                 V_CVRG_NO  := '033210';  -- 获取该保单中车损险的保费
               V_AMT := V_ORIG_PRM;
               amt_ary(1) :=  V_AMT;
              end if;


              if V_CVRG_NO in ('030210','030212','030032','030030','030015','030205','030209')
              then
                 V_CVRG_NO := '033221'; -- 获取该保单中商业三者险附加险的保费
               V_AMT := V_ORIG_PRM;
               if amt_ary(4) is null then
                 amt_ary(4):=0;
                 end if;
               amt_ary(4) := amt_ary(4) + V_AMT;
              end if;

              if V_CVRG_NO in ('030105','030057','030110','030042','030058','030021',
              '030106','030025','030109','030201','030202','030203','030204','030206','030207',
              '030208','030095','030102','030213','030214','030062','030063')
              then
                V_CVRG_NO := '033211'; -- --获取该保单中车损险附加险
               V_AMT := V_ORIG_PRM;
                if amt_ary(2) is null then
                 amt_ary(2):=0;
                 end if;
               amt_ary(2) := amt_ary(2) + V_AMT;
              end if;

 end loop; --prem_cvrg 循环结束  --- mofify by wkf 2013-6-13
  ---------------------------------------------------------------------

       for i in 1..amt_ary.count loop
             if amt_ary(i) is not null and amt_ary(i)<>0 then
               V_PRD_NO:=prodno_ary(i);
               v_due_amt:=amt_ary(i);



             if v_pre_flag = '0' then --针对801 预收保费-有单预收
                 v_inst_mrk  := '*';   --  v_inst_mrk 预收* 分期为 1 不分期为0  v_pre_flag 未实收 0 已实收 1  v_pos_flag 1 正 0 负
              end if;

            select C_SBJT_NO,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_pre_flag,c_prm_sou
              into v_SBJT_NO,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_C_PRE_FLAG,v_prm_sou
              from  web_fin_prm_subject
              where c_rp_typ = '701'  and rownum=1;


            v_item:=v_item+1;
            insert into web_fin_madcr
              (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
               C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
               C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
               c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
               c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
               c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
               c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo, c_Trans_Mrk,t_Trans_Tm,
               c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (V_DUE_TM,V_SEQ_NO,v_item,v_CAV_FLAG,v_SBJT_NO,v_due_amt,V_BS_CUR,sysdate,
               v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,
               V_PRD_NO,
               v_BSNS_TYP,v_CHA_CLS,
               v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
               '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
               null,v_vou_memo,v_company_cde,null,null,
               v_CON_DPT_CDE,'1',v_PERIOD_NAME,null,null,
               v_SERVICETYPE_NO,null,null,null,null,
               V_FEE_TYP,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);

   if v_edr_typ = '2' and v_BALA_MRK = '1' and v_edr_no is not  null then
             select C_SBJT_NO,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
                  into v_SBJT_NO,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
                  from  web_fin_madcr m
                  where m.c_sbjt_no<>'6031' and  rownum=1
                 and m.c_rcpt_no=(select c_rcpt_no from Web_Fin_Prm_Due due
                                      where due.c_ply_no=v_PLY_NO and due.n_tms=v_tms and due.c_edr_typ is null and due.c_feetyp_cde='R' and rownum=1);
              if v_SBJT_NO ='224128' then
                  v_due_amt:=-v_due_amt;
              end if;
       else
         select C_SBJT_NO,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_pre_flag,c_prm_sou
              into v_SBJT_NO,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_PRE_FLAG,v_prm_sou
              from web_fin_prm_subject
              where c_inst_mrk = v_inst_mrk       and c_agri_mrk = '*'and c_nat_typ = '*'    and c_ply_typ = '*'and c_fin_typ = '*'
                    and c_rp_typ = '601'  and c_pre_flag = v_pre_flag     and rownum=1;

                /*退保科目和实收保费挂钩 add by sql*/
                  v_count:=0;
                  SELECT COUNT(*) INTO v_count
                         FROM web_fin_dcr WHERE c_rcpt_no = trim(v_RCPT_NO) AND c_sbjt_no = '220302';
                  IF v_count = 0 THEN
                    select count(1) into v_count from (select sum(N_bs_AMT),sum(N_PAID_AMT)  from web_fin_prm_due
                    where c_ply_no =v_PLY_NO and c_edr_typ IS NULL and c_edr_no IS NULL having sum(N_bs_AMT)=sum(N_PAID_AMT));
                  if v_EDR_TYP=3 or (V_N_AMT <0 AND NVL(LENGTH(v_edr_no),0)>10 AND NVL(LENGTH(v_edr_typ),0)<>2 and v_count<>0)  then

                     v_SBJT_NO :='224128';
                         v_CAV_FLAG:='贷';
                         v_due_amt:=-v_due_amt;
                        v_sbjt_memo :='其他应付款-退保费';
                         v_SERVICETYPE_NO:='1000';
                    end if;
                   end if;
        end if;
            v_item:=v_item+1;
            insert into web_fin_madcr
              (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
               C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
               C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
               c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
               c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
               c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
               c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo,c_Trans_Mrk,t_Trans_Tm,
               c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT, c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (V_DUE_TM,V_SEQ_NO,v_item,v_CAV_FLAG,v_SBJT_NO,v_due_amt,V_BS_CUR,sysdate,
               v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,
               V_PRD_NO,
               v_BSNS_TYP,v_CHA_CLS,
               v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
               '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
               null,v_vou_memo,v_company_cde,null,null,v_CON_DPT_CDE,
               '1',v_PERIOD_NAME,null,null,
               v_SERVICETYPE_NO,null,null,null,null,
               V_FEE_TYP,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);
  end if;
 end loop;
 --------modify by wkf 2013-6-13 end


          update web_fin_prm_due
             set c_due_mrk = '1',t_upd_tm=sysdate,C_ACCNT_FLAG = substr(C_ACCNT_FLAG, 1, 1) || '1'
           where c_rcpt_no = v_RCPT_NO;
        end if;
    --end if;
    else
      v_err_content := 'proc:[P_premdueaccisc],出错流水号:['|| v_rcpt_no ||'],错误描述:保费金额与承保模块的险别金额之和不等';
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'), '001', '0000',v_err_content,SYSDATE);
    end if;---金额校验结束
     COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    begin
    v_err_content :=DBMS_UTILITY.format_error_backtrace;
      v_err_content := 'proc:[P_premdueaccisc],出错流水号:['|| v_rcpt_no ||'],错误描述:[' || SQLCODE || SQLERRM||v_err_content;
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'), '001', '0000',v_err_content,SYSDATE);
      COMMIT;
      succflag := '-1';
      if prem_cvrg%isopen then
        close prem_cvrg;
        end if;

    end;
end;
  end loop;
  close prem_due;
  commit;
  end;


-- 意健险  --自营、共入（06、13大类）
PROCEDURE P_PREMDUEACCINS (succflag out varchar2) is
V_RCPT_NO       WEB_FIN_MADCR.C_RCPT_NO%TYPE;
V_FEE_TYP       WEB_FIN_MADCR.C_FEE_TYP%TYPE;
V_END_TM       WEB_FIN_MADCR.T_END_TM%TYPE;
V_CHA_CDE      WEB_FIN_MADCR.C_CHA_CDE%TYPE;
V_EDR_NO     WEB_FIN_MADCR.C_EDR_NO%TYPE;
V_COMPANY_CDE         WEB_FIN_MADCR.C_COMPANY_CDE%TYPE;
V_SALEGRP_CDE            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
V_CURRENT_DPT_CDE  WEB_FIN_MADCR.C_CURRENT_DPT_CDE%TYPE;
V_C_PRE_FLAG    WEB_FIN_MADCR.C_PRE_FLAG%TYPE;
V_SEQ_NO       WEB_FIN_MADCR.C_SEQ_NO%TYPE;
V_CRT_TM       WEB_FIN_MADCR.T_CRT_TM%TYPE;
V_CON_DPT_CDE    WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
V_INSRNC_CDE       WEB_FIN_MADCR.C_INSRNC_CDE%TYPE;
V_ITEM_NO             WEB_FIN_MADCR.C_ITEM_NO%TYPE;
V_PAY_PRSN_NAME    WEB_FIN_MADCR.C_PAY_PRSN_NAME%TYPE;
V_VOU_MEMO        WEB_FIN_MADCR.C_VOU_MEMO%TYPE;
V_SBJT_MEMO        WEB_FIN_MADCR.C_SBJT_MEMO%TYPE;
V_CAV_FLAG           WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
V_FINBANK_CDE     WEB_FIN_MADCR.C_FINBANK_CDE%TYPE;
V_COST_CDE            WEB_FIN_MADCR.C_COST_CDE%TYPE;
V_VOU_NO               WEB_FIN_MADCR.C_VOU_NO%TYPE;
V_CHECK_FLAG      WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
V_USE_ATR              WEB_FIN_MADCR.C_USE_ATR%TYPE;
V_CLM_NO              WEB_FIN_MADCR.C_CLM_NO%TYPE;
V_PLY_NO                WEB_FIN_MADCR.C_PLY_NO%TYPE;
V_CLNT_MRK          WEB_FIN_MADCR.C_CLNT_MRK%TYPE;
V_SBJT_NO              WEB_FIN_MADCR.C_SBJT_NO%TYPE;
V_PROD_NO            WEB_FIN_MADCR.C_PROD_NO%TYPE;
V_DPTACC_NO       WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
V_CUR_NO              WEB_FIN_MADCR.C_CUR_NO%TYPE;
V_CONT_CODE       WEB_FIN_MADCR.C_CONT_CODE%TYPE;
V_SBJT_MRK        WEB_FIN_MADCR.C_SBJT_MRK%TYPE;
V_SEND_FLAG      WEB_FIN_MADCR.C_SEND_FLAG%TYPE;
V_BSNS_TYP         WEB_FIN_MADCR.C_BSNS_TYP%TYPE;
V_RI_COM             WEB_FIN_MADCR.C_RI_COM%TYPE;
V_N_AMT                  WEB_FIN_MADCR.N_AMT%TYPE;
V_SLS_CDE          WEB_FIN_MADCR.C_SLS_CDE%TYPE;
V_DPT_CDE         WEB_FIN_MADCR.C_DPT_CDE%TYPE;
V_PAY_PRSN_CDE      WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;
V_CHA_CLS        WEB_FIN_MADCR.C_CHA_CLS%TYPE;
V_CHA_MRK       WEB_FIN_MADCR.C_CHA_MRK%TYPE;
V_PERIOD_NAME     WEB_FIN_MADCR.C_PERIOD_NAME%TYPE;
V_VOUCHER_NO     WEB_FIN_MADCR.C_VOUCHER_NO%TYPE;
V_TOTAL_AMT        WEB_FIN_MADCR.N_TOTAL_AMT%TYPE;
V_SERVICETYPE_NO    WEB_FIN_MADCR.C_SERVICETYPE_NO%TYPE;
V_DEPARTMENT_CDE   WEB_FIN_MADCR.C_DEPARTMENT_CDE%TYPE;
V_VERIFYVOU_MEMO   WEB_FIN_MADCR.C_VERIFYVOU_MEMO%TYPE;
V_KIND_NO             WEB_FIN_MADCR.C_KIND_NO%TYPE;
V_EXCH_AMT         WEB_FIN_MADCR.N_EXCH_AMT%TYPE;
V_RATE                   WEB_FIN_MADCR.N_RATE%TYPE;
V_TRANS_MRK     WEB_FIN_MADCR.C_TRANS_MRK%TYPE;
V_TRANS_TM       WEB_FIN_MADCR.T_TRANS_TM%TYPE;
V_PRM_SOU                WEB_FIN_MADCR.C_PRM_SOU%TYPE;
V_DUE_TM                   WEB_FIN_MADCR.T_DUE_TM%TYPE;
V_CHR_CUR_NO        WEB_FIN_MADCR.C_CHR_CUR_NO%TYPE;
V_VEHICLESTYP_NO    WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;
V_AGR_FLAG              WEB_FIN_MADCR.C_AGR_FLAG%TYPE;
V_AGR_KIND               WEB_FIN_MADCR.C_AGR_KIND%TYPE;
V_AGR_TYP                  WEB_FIN_MADCR.C_AGR_TYP%TYPE;
V_SIGN_DATE             WEB_FIN_MADCR.T_SIGN_DATE%TYPE;
V_INSRNC_BGN_TM   WEB_FIN_MADCR.T_INSRNC_BGN_TM%TYPE;
V_INSRNC_END_TM    WEB_FIN_MADCR.T_INSRNC_END_TM%TYPE;
V_INVOICE_NO    WEB_FIN_MADCR.C_INVOICE_NO%TYPE;
V_APP_NME        WEB_FIN_MADCR.C_APP_NME%TYPE;
V_ACCDNT_TM    WEB_FIN_MADCR.T_ACCDNT_TM%TYPE;
V_OVER_DATE      WEB_FIN_MADCR.T_OVER_DATE%TYPE;
V_BILLTYPE          WEB_FIN_MADCR.C_BILLTYPE%TYPE;
V_DATA_SRC        WEB_FIN_MADCR.C_DATA_SRC%TYPE;
V_APP_NO           WEB_FIN_PRM_DUE.C_APP_NO%TYPE;
V_INST_MRK       WEB_FIN_PRM_DUE.C_INST_MRK%TYPE;
V_EDR_TYP       WEB_FIN_PRM_DUE.C_EDR_TYP%TYPE;
V_BALA_MRK      WEB_FIN_PRM_DUE.C_BALA_MRK%TYPE;
V_DUE_AMT        WEB_FIN_PRM_DUE.N_DUE_AMT%TYPE;
V_TMS            WEB_FIN_PRM_DUE.N_TMS%TYPE;
V_TRAN_FLAG        WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE;
V_ACCNT_FLAG       WEB_FIN_PRM_DUE.C_ACCNT_FLAG%TYPE;
V_BS_CUR           WEB_FIN_PRM_DUE.C_BS_CUR%TYPE;
V_UDR_TM         WEB_FIN_PRM_DUE.T_UDR_TM%TYPE;
V_CI_SHARE        WEB_FIN_PRM_DUE.N_CI_SHARE%TYPE;
V_ORIG_PRM        WEB_FIN_PRM_DET_DUE.N_ORIG_PRM%TYPE;       --单险种保费
V_CVRG_NO        WEB_FIN_PRM_DET_DUE.C_CVRG_NO%TYPE;
V_POS_FLAG       WEB_FIN_PRM_SUBJECT.C_POS_FLAG%TYPE;
V_PRE_FLAG       WEB_FIN_PRM_SUBJECT.C_PRE_FLAG%TYPE;
V_SBJT_NAME   WEB_FIN_PRM_SUBJECT.C_SBJT_NAME%TYPE;
V_ARP_FLAG      WEB_FIN_PRM_SUBJECT.C_ARP_FLAG%TYPE;
V_ERR_CONTENT              WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
V_CVRG_SUM          NUMBER(20,2);
V_PRD_NO                  VARCHAR2(10);
V_AMT                      NUMBER;
V_ITEM                     NUMBER(5);
V_COUNT                    NUMBER;



  CURSOR prem_due is
    select due.C_RCPT_NO,        --单据号
           due.C_DPT_CDE,        --出单机构
           due.C_DPTACC_CDE,     --做账机构
           due.C_PLY_NO,     --保单号
           due.C_APP_NO,     --投保单号
           due.C_BSNS_TYP,       --业务来源
           due.C_PROD_NO,        --产品代码
           due.C_TRAN_FLAG,      --业务单据标识(自营标识)
           due.N_bs_AMT,         --业务金额
           nvl(due.C_INST_MRK, '0'), --分期标志
           due.C_PAYER_CDE,          --付款人代码
           due.C_PAYER_NME,          --付款人名称
           due.C_SLS_CDE,            --业务员
           due.C_CHA_MRK,            --渠道标识
           due.C_CHA_CLS,            --渠道类别
           due.C_CHA_CDE,            --渠道编码
           due.C_CON_DPT_CDE,        --共保人
           due.T_DUE_TM,             --挂账日期
           due.C_SLSGRP_CDE,         --销售团队
           nvl(due.c_edr_typ,0),     --批改类型
           due.C_BALA_MRK,           --冲销标志
           nvl(n_due_amt, 0.00), --挂账金额
           due.C_ACCNT_FLAG,         --会计状态
           due.C_bs_CUR,             --业务币种
           due.c_due_cur,            --挂账币种
           due.c_feetyp_cde,
           due.n_tms,
          -- decode(nvl(base.n_edr_prj_no,0),0,base.n_prm,base.n_prm_var),
       --base.n_orig_prm       --单险种保费
           due.C_AGRI_MRK,
           due.c_agr_kind,
           due.c_agr_typ,
           due.c_edr_no,
           due.c_app_nme,
       due.t_issue_tm,      --签单日期
           due.c_data_src,       --数据来源
       due.t_udr_tm,         --核保时间
       due.n_ci_share         --共保比例
      from web_fin_prm_due due,web_bas_fin_prod prd
     where
     trunc(t_due_tm) < trunc(sysdate)+1
     and trunc(due.t_insrnc_bgn_tm) < trunc(sysdate)+1  and
     c_accnt_flag in('00','10')
     and c_tran_flag in ('1','3')
     --  and due.dxp_tran_flag in ('H')
     and due.c_rp_flag = '1'
     and prd.c_prod_no = due.c_prod_no
     and substr(due.c_prod_no,0,2) in('06','13')
     -- and due.c_app_no = base.c_app_no
     --and due.n_tms = base.n_tms
     and (due.c_bala_mrk='0' or (due.c_bala_mrk='1' and nvl(due.c_edr_typ,'0')='2'  and due.c_edr_no is not null
                                                     and exists(
                                                         select 1 from web_fin_prm_due pd where
                                                            pd.c_ply_no=due.c_ply_no
                                                            and pd.n_tms=due.n_tms
                                                            and pd.c_edr_typ is null
                                                            and pd.c_edr_no is null
                                                            and substr(pd.c_accnt_flag,2,1)='1'
                                                            and nvl(pd.c_due_mrk,'0')='1')
                                  )
          )
       and nvl(c_due_mrk, '0') = '0'
       and nvl(N_DUE_AMT, 0) <> 0
      -- and substr(due.c_dptacc_cde,0,2)='50'
        and not exists(
           SELECT 1 FROM web_fin_tmp_dcr dcr
           WHERE dcr.c_rcpt_no = due.c_rcpt_no AND c_sbjt_no = '220302'
       );


    cursor prem_cvrg(appno varchar2,nTms number) is
     select sum(cvrg.n_orig_prm) as prm,
            cvrg.c_cvrg_no as cvrgno
      from  web_fin_prm_det_due cvrg
      where cvrg.c_app_no = appno
        and  cvrg.n_orig_prm<> 0
    and cvrg.n_tms = nTms
  --  and cvrg.dxp_tran_flag in('H')
        group by cvrg.c_cvrg_no;

begin
  succflag := '0';
  open prem_due;
  loop
    begin
    <<GOTO_LAB>>
    FETCH prem_due
      into V_RCPT_NO, V_DPT_CDE, V_DPTACC_NO, V_PLY_NO,V_APP_NO,V_BSNS_TYP,
    V_PROD_NO,V_TRAN_FLAG,V_N_AMT,V_INST_MRK,V_PAY_PRSN_CDE,V_PAY_PRSN_NAME,
    V_SLS_CDE,V_CHA_MRK, V_CHA_CLS, V_CHA_CDE, V_CON_DPT_CDE,V_DUE_TM,
    V_SALEGRP_CDE,V_EDR_TYP,V_BALA_MRK,V_DUE_AMT,V_ACCNT_FLAG,V_BS_CUR,V_CUR_NO,
    V_FEE_TYP,V_TMS,V_AGR_FLAG,V_AGR_KIND,V_AGR_TYP,
    V_EDR_NO,V_APP_NME,V_SIGN_DATE,V_DATA_SRC,V_UDR_TM,V_CI_SHARE;
    EXIT WHEN prem_due%NOTFOUND;

    --险别总保费
    select sum(cvrg.n_orig_prm)into v_cvrg_sum
      from  web_fin_prm_det_due cvrg
      where cvrg.c_app_no = v_app_no
        and cvrg.n_tms = V_TMS;
      --  and cvrg.dxp_tran_flag in ('H')

   ------校验金额------

  if  v_cvrg_sum = V_N_AMT then
    if v_tran_flag = '3' then v_tran_flag := '1'; end if; -- add by sunchangjie for update 我方从共凭证与自营一致

    v_item:=0;
    v_prd_no:=v_PROD_NO;

    if v_CUR_NO is null or v_CUR_NO = '' then
       v_CUR_NO:= V_BS_CUR;
    end if;
    if v_CUR_NO <> '01' or V_BS_CUR <> v_CUR_NO then
       --核保日期

       if v_CUR_NO = '01' and V_BS_CUR <> '01' then
          v_due_amt := v_due_amt*rpfunction.getRate(V_BS_CUR,'01',V_UDR_TM);
          v_rate:='1';

       elsif v_CUR_NO<>'01' and V_BS_CUR='01' then
          v_rate := rpfunction.getRate(v_CUR_NO,'01',V_UDR_TM);
          v_due_amt:=round(v_due_amt/v_rate,2);
       else
          v_rate := rpfunction.getRate(v_CUR_NO,'01',V_UDR_TM);
       end if;
    else
       v_rate:=1;
    end if;


    if v_edr_typ = '2' and v_BALA_MRK <> '1' then

       INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
       VALUES
          (F_Fin_Getcode('e'),'001','0000',
          '意健险proc:[premdueaccins],出错流水号:['|| v_rcpt_no||']注销冲正',
           SYSDATE);
    else

      --获取公司段信息

       v_COMPANY_CDE:=rpfunction.getFinCompany(v_DPTACC_NO,v_rcpt_no);

       Dz_Proc.get_fin_no(V_SEQ_NO, v_dpt_cde, '7', dz_proc.g_pttype);
       v_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
          --给web_fin_prm_subject.c_pos_flag 赋值
          if v_due_amt > 0 then
            v_pos_flag := '1';
          else
            v_pos_flag := '0';
          end if;


      if substr(v_ACCNT_FLAG, 1, 1) = '0' then --未实收
             v_pre_flag:='1';
               v_vou_memo:='应收保费确认';
          else                           --已实收
             v_pre_flag:='0';
           v_vou_memo:='预收保费结转实收保费';
          end if;



          for v_prmcvrg in prem_cvrg(v_app_no,v_tms) loop
              V_ORIG_PRM:= v_prmcvrg.prm;     --险别保费
              v_cvrg_no:= v_prmcvrg.cvrgno;   --险别代码

              if V_ORIG_PRM=0 then
                 goto GOTO_LAB;
                end if;
                 v_insrnc_cde := v_cvrg_no;

             v_due_amt:=round(V_N_AMT*V_ORIG_PRM/v_cvrg_sum,2);

            --获取科目编号和科目备注，明细段，借贷方向，业务类型,只取第一条数据

            if v_pre_flag = '0' then --针对801 预收保费-有单预收
            v_inst_mrk  := '*';   --  v_inst_mrk 预收* 分期为 1 不分期为0  v_pre_flag 未实收 0 已实收 1  v_pos_flag 1 正 0 负
          end if;

       select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_pre_flag,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_C_PRE_FLAG,v_prm_sou
              from web_fin_prm_subject
              where c_rp_typ = '701'  and rownum=1;


            v_item:=v_item+1;
            insert into web_fin_madcr
              (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
               C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
               C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
               c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
               c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
               c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
               c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo, c_Trans_Mrk,t_Trans_Tm,
               c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,c_insrnc_cde,c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (V_DUE_TM,V_SEQ_NO,v_item,v_CAV_FLAG,v_SBJT_NO,v_due_amt,v_CUR_NO,sysdate,
               v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PROD_NO,v_BSNS_TYP,v_CHA_CLS,
               v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
               '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
               null,v_vou_memo,v_company_cde,null,null,
               v_CON_DPT_CDE,'1',v_PERIOD_NAME,null,null,
               v_SERVICETYPE_NO,null,null,null,null,
               V_FEE_TYP,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_insrnc_cde,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);

       if v_edr_typ = '2' and v_BALA_MRK = '1' and v_edr_no is not  null then
             select C_SBJT_NO,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
                  into v_SBJT_NO,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
                  from  web_fin_madcr m
                  where m.c_sbjt_no<>'6031' and  rownum=1
                 and m.c_rcpt_no=(select c_rcpt_no from Web_Fin_Prm_Due
                                      where c_ply_no=v_PLY_NO and n_tms=v_tms and c_edr_typ is null);
              if v_SBJT_NO ='224128' then
                  v_due_amt:=-v_due_amt;
              end if;
       else
         select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
              from  web_fin_prm_subject
              where c_inst_mrk = v_inst_mrk       and c_agri_mrk = '*'and c_nat_typ = '*'    and c_ply_typ = '*'and c_fin_typ = '*'
               and c_rp_typ = '601'  and c_pre_flag = v_pre_flag     and rownum=1;


                   /*退保科目和实收保费挂钩 add by sql*/
                  v_count:=0;
                  SELECT COUNT(*) INTO v_count
                         FROM web_fin_dcr WHERE c_rcpt_no = trim(v_RCPT_NO) AND c_sbjt_no = '220302';
                  IF v_count = 0 THEN
                    select count(1) into v_count from (select sum(N_bs_AMT),sum(N_PAID_AMT)  from web_fin_prm_due
                    where c_ply_no =v_PLY_NO and c_edr_typ IS NULL and c_edr_no IS NULL having sum(N_bs_AMT)=sum(N_PAID_AMT));
                  if v_EDR_TYP=3 or (v_N_AMT <0 AND NVL(LENGTH(v_edr_no),0)>10 AND NVL(LENGTH(v_edr_typ),0)<>2 and v_count<>0)  then
                         v_SBJT_NO :='224128';
                         v_CAV_FLAG:='贷';
                         v_due_amt:=-v_due_amt;
                        v_sbjt_memo :='其他应付款-退保费';
                         v_SERVICETYPE_NO:='1000';
                    end if;
                   end if;
            end if;
            v_item:=v_item+1;
            insert into web_fin_madcr
              (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
               C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
               C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
               c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
               c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
               c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
               c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo,c_Trans_Mrk,t_Trans_Tm,
               c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,c_insrnc_cde,c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (V_DUE_TM,V_SEQ_NO,v_item,v_CAV_FLAG,v_SBJT_NO,v_due_amt,v_CUR_NO,sysdate,
               v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PROD_NO,v_BSNS_TYP,v_CHA_CLS,
               v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
               '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
               null,v_vou_memo,v_company_cde,null,null,v_CON_DPT_CDE,
               '1',v_PERIOD_NAME,null,null,
               v_SERVICETYPE_NO,null,null,null,null,
               V_FEE_TYP,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_insrnc_cde,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);

               <<GOTO_LAB>>
               NULL;
          end loop; --prem_cvrg 循环结束
          update web_fin_prm_due
             set c_due_mrk = '1',t_upd_tm=sysdate,C_ACCNT_FLAG = substr(C_ACCNT_FLAG, 1, 1) || '1'
           where c_rcpt_no = v_RCPT_NO;
        end if;
    --end if;
    else
      v_err_content := '意健险proc:[P_premdueaccins],出错流水号:['|| v_rcpt_no ||'],错误描述:保费金额与承保模块的险别金额之和不等';
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'), '001', '0000',v_err_content,SYSDATE);
    end if;---金额校验结束
 COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    rollback;
       begin
       v_err_content :=DBMS_UTILITY.format_error_backtrace;
      v_err_content := '意健险proc:[P_premdueaccins],出错流水号:['|| v_rcpt_no ||'],错误描述:[' || SQLCODE || SQLERRM||v_err_content;
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'), '001', '0000',v_err_content,SYSDATE);
      COMMIT;
      succflag := '-1';
      if prem_cvrg%isopen then
        close prem_cvrg;
        end if;
   end;
end;
 end loop;
  close prem_due;
  commit;
  end;

-- 共保
PROCEDURE PREMCONTDUE ( succflag out varchar2) is  --共保共出（除去06、13大类）
 V_RCPT_NO       WEB_FIN_MADCR.C_RCPT_NO%TYPE;
V_FEETYP_CDE       WEB_FIN_MADCR.C_FEE_TYP%TYPE;
V_END_TM       WEB_FIN_MADCR.T_END_TM%TYPE;
V_CHA_CDE      WEB_FIN_MADCR.C_CHA_CDE%TYPE;
V_EDR_NO     WEB_FIN_MADCR.C_EDR_NO%TYPE;
V_COMPANY_CDE         WEB_FIN_MADCR.C_COMPANY_CDE%TYPE;
V_SALEGRP_CDE            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
V_CURRENT_DPT_CDE  WEB_FIN_MADCR.C_CURRENT_DPT_CDE%TYPE;
V_C_PRE_FLAG    WEB_FIN_MADCR.C_PRE_FLAG%TYPE;
V_SEQ_NO       WEB_FIN_MADCR.C_SEQ_NO%TYPE;
V_CRT_TM       WEB_FIN_MADCR.T_CRT_TM%TYPE;
V_CON_DPT_CDE    WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
V_INSRNC_CDE       WEB_FIN_MADCR.C_INSRNC_CDE%TYPE;
V_ITEM_NO             WEB_FIN_MADCR.C_ITEM_NO%TYPE;
V_PAY_PRSN_NAME    WEB_FIN_MADCR.C_PAY_PRSN_NAME%TYPE;
V_VOU_MEMO        WEB_FIN_MADCR.C_VOU_MEMO%TYPE;
V_SBJT_MEMO        WEB_FIN_MADCR.C_SBJT_MEMO%TYPE;
V_CAV_FLAG           WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
V_FINBANK_CDE     WEB_FIN_MADCR.C_FINBANK_CDE%TYPE;
V_COST_CDE            WEB_FIN_MADCR.C_COST_CDE%TYPE;
V_VOU_NO               WEB_FIN_MADCR.C_VOU_NO%TYPE;
V_CHECK_FLAG      WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
V_USE_ATR              WEB_FIN_MADCR.C_USE_ATR%TYPE;
V_CLM_NO              WEB_FIN_MADCR.C_CLM_NO%TYPE;
V_PLY_NO                WEB_FIN_MADCR.C_PLY_NO%TYPE;
V_CLNT_MRK          WEB_FIN_MADCR.C_CLNT_MRK%TYPE;
V_SBJT_NO              WEB_FIN_MADCR.C_SBJT_NO%TYPE;
V_PROD_NO            WEB_FIN_MADCR.C_PROD_NO%TYPE;
V_DPTACC_NO       WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
V_CUR_NO              WEB_FIN_MADCR.C_CUR_NO%TYPE;
V_CONT_CODE       WEB_FIN_MADCR.C_CONT_CODE%TYPE;
V_SBJT_MRK        WEB_FIN_MADCR.C_SBJT_MRK%TYPE;
V_SEND_FLAG      WEB_FIN_MADCR.C_SEND_FLAG%TYPE;
V_BSNS_TYP         WEB_FIN_MADCR.C_BSNS_TYP%TYPE;
V_RI_COM             WEB_FIN_MADCR.C_RI_COM%TYPE;
V_N_AMT                  WEB_FIN_MADCR.N_AMT%TYPE;
V_SLS_CDE          WEB_FIN_MADCR.C_SLS_CDE%TYPE;
V_DPT_CDE         WEB_FIN_MADCR.C_DPT_CDE%TYPE;
V_PAY_PRSN_CDE      WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;
V_CHA_CLS        WEB_FIN_MADCR.C_CHA_CLS%TYPE;
V_CHA_MRK       WEB_FIN_MADCR.C_CHA_MRK%TYPE;
V_PERIOD_NAME     WEB_FIN_MADCR.C_PERIOD_NAME%TYPE;
V_VOUCHER_NO     WEB_FIN_MADCR.C_VOUCHER_NO%TYPE;
V_TOTAL_AMT        WEB_FIN_MADCR.N_TOTAL_AMT%TYPE;
V_SERVICETYPE_NO    WEB_FIN_MADCR.C_SERVICETYPE_NO%TYPE;
V_DEPARTMENT_CDE   WEB_FIN_MADCR.C_DEPARTMENT_CDE%TYPE;
V_VERIFYVOU_MEMO   WEB_FIN_MADCR.C_VERIFYVOU_MEMO%TYPE;
V_KIND_NO             WEB_FIN_MADCR.C_KIND_NO%TYPE;
V_EXCH_AMT         WEB_FIN_MADCR.N_EXCH_AMT%TYPE;
V_RATE                   WEB_FIN_MADCR.N_RATE%TYPE;
V_TRANS_MRK     WEB_FIN_MADCR.C_TRANS_MRK%TYPE;
V_TRANS_TM       WEB_FIN_MADCR.T_TRANS_TM%TYPE;
V_PRM_SOU                WEB_FIN_MADCR.C_PRM_SOU%TYPE;
V_DUE_TM                   WEB_FIN_MADCR.T_DUE_TM%TYPE;
V_CHR_CUR_NO        WEB_FIN_MADCR.C_CHR_CUR_NO%TYPE;
V_VEHICLESTYP_NO    WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;
V_AGR_FLAG              WEB_FIN_MADCR.C_AGR_FLAG%TYPE;
V_AGR_KIND               WEB_FIN_MADCR.C_AGR_KIND%TYPE;
V_AGR_TYP                  WEB_FIN_MADCR.C_AGR_TYP%TYPE;
V_SIGN_DATE             WEB_FIN_MADCR.T_SIGN_DATE%TYPE;
V_INSRNC_BGN_TM   WEB_FIN_MADCR.T_INSRNC_BGN_TM%TYPE;
V_INSRNC_END_TM    WEB_FIN_MADCR.T_INSRNC_END_TM%TYPE;
V_INVOICE_NO    WEB_FIN_MADCR.C_INVOICE_NO%TYPE;
V_APP_NME        WEB_FIN_MADCR.C_APP_NME%TYPE;
V_ACCDNT_TM    WEB_FIN_MADCR.T_ACCDNT_TM%TYPE;
V_OVER_DATE      WEB_FIN_MADCR.T_OVER_DATE%TYPE;
V_BILLTYPE          WEB_FIN_MADCR.C_BILLTYPE%TYPE;
V_DATA_SRC        WEB_FIN_MADCR.C_DATA_SRC%TYPE;
V_APP_NO           WEB_FIN_PRM_DUE.C_APP_NO%TYPE;
V_INST_MRK       WEB_FIN_PRM_DUE.C_INST_MRK%TYPE;
V_BANK_CDE     WEB_FIN_PRM_DUE.C_BANK_CDE%TYPE;
V_EDR_TYP       WEB_FIN_PRM_DUE.C_EDR_TYP%TYPE;
V_BALA_MRK      WEB_FIN_PRM_DUE.C_BALA_MRK%TYPE;
V_DUE_AMT        WEB_FIN_PRM_DUE.N_DUE_AMT%TYPE;
V_TMS            WEB_FIN_PRM_DUE.N_TMS%TYPE;
V_TRAN_FLAG        WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE;
V_ACCNT_FLAG       WEB_FIN_PRM_DUE.C_ACCNT_FLAG%TYPE;
V_BS_CUR           WEB_FIN_PRM_DUE.C_BS_CUR%TYPE;
V_UDR_TM         WEB_FIN_PRM_DUE.T_UDR_TM%TYPE;
V_MAIN_CON_CDE   WEB_FIN_PRM_DUE.C_MAIN_CON_CDE%TYPE;
V_CI_SHAR        WEB_FIN_PRM_DUE.N_CI_SHARE%TYPE;
V_POS_FLAG       WEB_FIN_PRM_SUBJECT.C_POS_FLAG%TYPE;
V_PRE_FLAG       WEB_FIN_PRM_SUBJECT.C_PRE_FLAG%TYPE;
V_SBJT_NAME   WEB_FIN_PRM_SUBJECT.C_SBJT_NAME%TYPE;
V_ARP_FLAG      WEB_FIN_PRM_SUBJECT.C_ARP_FLAG%TYPE;
V_CONT_MRK      WEB_FIN_PRM_SUBJECT.C_CONT_MRK%TYPE;
ERRORLINE                  VARCHAR2(400);
V_ERR_CONTENT              WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
V_CVRG_SUM          NUMBER(20,2);
V_PRD_NO                  VARCHAR2(10);
V_AMT                      NUMBER;
V_ITEM                     NUMBER(5);
V_COUNT                    NUMBER;
V_CON                      NUMBER;
V_I                        NUMBER;
V_CON_DPT                 VARCHAR2(10);
V_MAIN_CON                 VARCHAR2(10);

  cursor premcon_due is
       select distinct c_app_no from web_fin_prm_due due,web_bas_fin_prod prod
       where trunc(t_due_tm) < trunc(sysdate)+1
      and trunc(due.t_insrnc_bgn_tm) < trunc(sysdate)+1
       and  c_accnt_flag IN('00','10')
       and nvl(N_DUE_AMT, 0) <> 0
       and c_tran_flag in ('2')
    -- and due.dxp_tran_flag in ('6')
       and due.c_prod_no = prod.c_prod_no
     /*  and due.c_rcpt_no in
       ('R00261010133010201401000100000024',
       'R00261010133010201401000100000023',
       'R00261010133010201401000100000022')*/
     and substr(due.c_prod_no,0,2) not in('06','13')
      and (
           due.c_bala_mrk='0' or (due.c_bala_mrk='1' and nvl(due.c_edr_typ,'0')='2'  and due.c_edr_no is not null
                                                     and exists(
                                                         select 1 from web_fin_prm_due pd where
                                                            pd.c_ply_no=due.c_ply_no
                                                            and pd.n_tms=due.n_tms
                                                            and pd.c_edr_typ is null
                                                            and pd.c_edr_no is null
                                                            and substr(pd.c_accnt_flag,2,1)='1'
                                                            and nvl(pd.c_due_mrk,'0')='1')
                                  )
          )
       and nvl(c_due_mrk, 0) = '0';

  cursor premcon_due_conman(V_APP_NO varchar2) is
       select distinct a.c_main_con_cde,a.c_con_dpt_cde,a.c_tran_flag
       from web_fin_prm_due a
        where a.c_app_no=V_APP_NO
          /*and a.dxp_tran_flag in ('6')*/;

  CURSOR prem_con_due(V_APP_NO varchar2) is
    select C_RCPT_NO,            --单据号
           C_DPT_CDE,            --出单机构
           C_DPTACC_CDE,         --做账机构
           C_PLY_NO,             --保单号
           C_APP_NO,             --投保单号
           C_BSNS_TYP,           --业务来源
           C_PROD_NO,            --产品代码
           C_TRAN_FLAG,          --业务单据标识(自营标识)
           N_bs_AMT,             --业务金额
           nvl(C_INST_MRK, '0'), --分期标志
           C_PAYER_CDE,          --付款人代码
           C_PAYER_NME,          --付款人名称
           C_SLS_CDE,            --业务员
           C_CHA_MRK,            --渠道标识
           C_CHA_CLS,            --渠道类别
           C_CHA_CDE,            --渠道编码
           C_TRANS_MRK,          --迁移标志
           T_TRANS_TM,           --迁移时间
           T_DUE_TM,             --挂账日期
           C_SLSGRP_CDE,         --销售团队
           nvl(c_edr_typ,0),     --批改类型
           C_BALA_MRK,           --冲销标志
           nvl(n_due_amt, 0.00), --挂账金额
           C_ACCNT_FLAG,         --会计状态
           C_bs_CUR,             --业务币种
           nvl(C_DUE_CUR,'01'),  --挂账币种
           c_feetyp_cde,          --费用类型代码
           C_BANK_CDE,
           c_main_con_cde,           --主共
           c_con_dpt_cde,            --从共
           t_insrnc_bgn_tm,      --保险起期
           C_AGRI_MRK,          --涉农标识
           c_agr_kind,          --涉农性质
           c_agr_typ,           --农险大类
           C_EDR_NO,            --批单号
           c_app_nme,           --投保人名称
           n_tms,           --期次
       t_issue_tm,      --签单日期
           c_data_src,       --数据来源
       t_udr_tm,         --核保时间
       n_ci_share         --共保比例
      from web_fin_prm_due due
     where c_app_no=V_APP_NO
       and nvl(c_due_mrk, 0) = '0'
       and c_accnt_flag IN('00','10')
       and nvl(N_DUE_AMT, 0) <> 0
       and c_tran_flag = '2'
    --   and due.dxp_tran_flag in ('6')
    --   and substr(c_dptacc_cde,0,2)='50'
       and not exists(
           SELECT 1 FROM web_fin_tmp_dcr dcr
           WHERE dcr.c_rcpt_no = due.c_rcpt_no
        AND c_sbjt_no = '220302'
       );
begin
  succflag := '0';
  v_con:=0;
  open premcon_due;
  loop
    begin
    FETCH premcon_due
      into  V_APP_NO ;
    EXIT WHEN premcon_due%NOTFOUND;
    --判断共保人是否配置 begin
    open premcon_due_conman(V_APP_NO);
    v_con:=0;
    loop
      fetch premcon_due_conman into v_main_con_cde,v_con_dpt_cde,v_tran_flag;
      exit when premcon_due_conman%notfound;
      begin
      if v_tran_flag='2' then
           if v_con_dpt_cde<>'327001' then
              select c_fingb_cde into v_con_dpt from web_fin_gb where c_gb_cde = v_con_dpt_cde;
           end if;
      else
           select c_fingb_cde into v_main_con from web_fin_gb where c_gb_cde = v_main_con_cde;
      end if;
      exception WHEN NO_DATA_FOUND THEN

          succflag := '-1';
          v_con:=v_con+1;
          INSERT INTO WEB_BAS_FIN_ERRORLOG
            (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
          VALUES
            (F_Fin_Getcode('e'),'001','0000',V_APP_NO||'(投保单号)共保人查询失败',SYSDATE);
      end;
    end loop;
    close premcon_due_conman;
    ----判断共保人是否配置 end
    v_i:=0;
    if v_con = 0 then
    open prem_con_due(V_APP_NO);

    Dz_Proc.get_fin_no(V_SEQ_NO, '00001', '7', dz_proc.g_pttype);
    loop
      <<GOTO_LAB>>
      FETCH prem_con_due
      into V_RCPT_NO, V_DPT_CDE, V_DPTACC_NO, V_PLY_NO, V_APP_NO, V_BSNS_TYP,
       V_PROD_NO, V_TRAN_FLAG, V_N_AMT, V_INST_MRK, V_PAY_PRSN_CDE, V_PAY_PRSN_NAME,
        V_SLS_CDE, V_CHA_MRK, V_CHA_CLS, V_CHA_CDE, V_TRANS_MRK,
        V_TRANS_TM, V_CRT_TM, V_SALEGRP_CDE, V_EDR_TYP, V_BALA_MRK, V_DUE_AMT,
        V_ACCNT_FLAG, V_BS_CUR,V_CUR_NO, V_FEETYP_CDE, V_BANK_CDE,V_MAIN_CON_CDE,
        V_CON_DPT_CDE,V_INSRNC_BGN_TM,V_AGR_FLAG,V_AGR_KIND,V_AGR_TYP,V_EDR_NO,V_APP_NME,V_TMS,
    V_SIGN_DATE,V_DATA_SRC,V_UDR_TM,V_CI_SHAR ;
    EXIT WHEN prem_con_due%NOTFOUND;
     ---- --add by wkf 2013-8-12 start
    SELECT COUNT(*) INTO v_count
    FROM web_fin_tmp_dcr
    WHERE c_rcpt_no = trim(V_RCPT_NO)
        AND c_sbjt_no = '220302';
    IF v_count > 0 THEN
           GOTO GOTO_LAB ;
    END IF ;
 --add by wkf 2013-8-12 end

    --汇率 begin
    if V_CUR_NO is null or V_CUR_NO = '' then
       V_CUR_NO:= V_BS_CUR;
    end if;

    if V_CUR_NO <> '01' or V_BS_CUR <> V_CUR_NO then

       if V_CUR_NO = '01' and V_BS_CUR <> '01' then
          v_due_amt := v_due_amt*rpfunction.getRate(V_BS_CUR,'01',V_UDR_TM);
          v_rate:='1';

       elsif V_CUR_NO<>'01' and V_BS_CUR='01' then
          v_rate := rpfunction.getRate(V_CUR_NO,'01',V_UDR_TM);
          v_due_amt:=round(v_due_amt/v_rate,2);
       else
          v_rate := rpfunction.getRate(V_CUR_NO,'01',V_UDR_TM);
       end if;
    else
       v_rate:=1;
    end if;

    if v_edr_typ = '2' and v_BALA_MRK <> '1' then
       insert into WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        values
          (F_Fin_Getcode('e'),'001','0000',
           'proc:[premdue],出错流水号:[' || v_rcpt_no ||'] 注销冲正',
           SYSDATE);
    else


       v_COMPANY_CDE:=rpfunction.getFinCompany(v_DPTACC_NO,v_rcpt_no);


        begin

          v_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
          if v_due_amt > 0 then
            v_pos_flag := '1';
          else
            v_pos_flag := '0';
          end if;


              if substr(v_ACCNT_FLAG, 1, 1) = '0' then --未实收
             v_pre_flag:='1';
               v_vou_memo:='应收保费确认';
          else                           --已实收
             v_pre_flag:='0';
           v_vou_memo:='预收保费结转实收保费';
          end if;

          if v_tran_flag='2' then
             V_CONT_MRK:='1';
          else V_CONT_MRK:='2';
          end if;

       if v_main_con_cde = v_con_dpt_cde  then  -- 只有我方主共 才进行挂账





          if v_pre_flag = '0' then --针对801 预收保费-有单预收
            v_inst_mrk  := '*';   --  v_inst_mrk 预收* 分期为 1 不分期为0  v_pre_flag 未实收 0 已实收 1  v_pos_flag 1 正 0 负
          end if;

       select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_pre_flag,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_C_PRE_FLAG,v_prm_sou
              from web_fin_prm_subject
              where c_rp_typ = '701'  and rownum=1;


          v_i := v_i+1;
          insert into web_fin_madcr
              (T_END_TM, C_SEQ_NO, C_ITEM_NO, C_CAV_FLAG, C_SBJT_NO, N_AMT, C_CUR_NO, T_CRT_TM, C_DPTACC_NO,
               C_DPT_CDE, C_RCPT_NO, C_SLS_CDE, C_PROD_NO, C_BSNS_TYP, C_CHA_CLS, C_CHA_CDE, C_SALEGRP_CDE,
               C_PAY_PRSN_CDE, C_PAY_PRSN_NAME, c_Ri_Com, c_Cont_Code, c_Send_Flag, c_Vou_No, c_Sbjt_Memo,
               c_Ply_No, c_Pre_Flag, c_Cha_Mrk, c_Finbank_Cde, c_Vou_Memo, c_Company_Cde, c_Cost_Cde,
               c_Current_Dpt_Cde, c_Con_Dpt_Cde, c_Check_Flag, c_Period_Name, c_Voucher_No, n_Total_Amt,
               c_Servicetype_No, c_Department_Cde, c_Verifyvou_Memo, c_Trans_Mrk, t_Trans_Tm, c_fee_typ,
               c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT, c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (V_DUE_TM, V_SEQ_NO, v_i, v_CAV_FLAG, v_SBJT_NO, v_due_amt, v_CUR_NO, sysdate, v_DPTACC_NO,
               v_DPT_CDE, v_RCPT_NO, v_SLS_CDE, v_PROD_NO, v_BSNS_TYP, v_CHA_CLS, v_CHA_CDE, v_SALEGRP_CDE,
               v_PAY_PRSN_CDE, v_PAY_PRSN_NAME, null, null, '0', '-1', v_sbjt_memo,
               v_PLY_NO, null, v_CHA_MRK, v_BANK_CDE, v_vou_memo, v_company_cde, null,
               null, v_CON_DPT_CDE, '1', v_PERIOD_NAME, null, null,
               v_SERVICETYPE_NO, null, null, null, null, v_feetyp_cde,
               v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);

  if v_edr_typ = '2' and v_BALA_MRK = '1' and v_edr_no is not  null then
             select C_SBJT_NO,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
                  into v_SBJT_NO,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
                  from  web_fin_madcr m
                  where m.c_sbjt_no<>'6031' and  rownum=1
                 and m.c_rcpt_no=(select c_rcpt_no from Web_Fin_Prm_Due due
                                      where due.c_ply_no=v_PLY_NO and due.n_tms=v_tms and due.c_edr_typ is null and due.c_feetyp_cde='R' and rownum=1);
              if v_SBJT_NO ='224128' then
                  v_due_amt:=-v_due_amt;
              end if;
       else
              select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
              from  web_fin_prm_subject
              where c_inst_mrk = v_inst_mrk       and c_agri_mrk = '*'and c_nat_typ = '*'    and c_ply_typ = '*'and c_fin_typ = '*'
                   and c_rp_typ = '601'  and c_pre_flag = v_pre_flag     and rownum=1;


                   /*退保科目和实收保费挂钩 add by sql*/
                  v_count:=0;
                  SELECT COUNT(*) INTO v_count
                         FROM web_fin_dcr WHERE c_rcpt_no = trim(v_RCPT_NO) AND c_sbjt_no = '220302';
                  IF v_count = 0 THEN
                    select count(1) into v_count from (select sum(N_bs_AMT),sum(N_PAID_AMT)  from web_fin_prm_due
                    where c_ply_no =v_PLY_NO and c_edr_typ IS NULL and c_edr_no IS NULL having sum(N_bs_AMT)=sum(N_PAID_AMT));
                      if v_EDR_TYP=3 or (v_N_AMT <0 AND NVL(LENGTH(v_edr_no),0)>10 AND NVL(LENGTH(v_edr_typ),0)<>2 and v_count<>0)  then

                        v_SBJT_NO :='224128';
                         v_CAV_FLAG:='贷';
                         v_due_amt:=-v_due_amt;
                        v_sbjt_memo :='其他应付款-退保费';
                         v_SERVICETYPE_NO:='1000';
                    end if;
                   end if;
               end if;
                v_i := v_i+1;
     insert into web_fin_madcr
              (T_END_TM, C_SEQ_NO, C_ITEM_NO, C_CAV_FLAG, C_SBJT_NO, N_AMT, C_CUR_NO, T_CRT_TM, C_DPTACC_NO,
               C_DPT_CDE, C_RCPT_NO, C_SLS_CDE, C_PROD_NO, C_BSNS_TYP, C_CHA_CLS, C_CHA_CDE, C_SALEGRP_CDE,
               C_PAY_PRSN_CDE, C_PAY_PRSN_NAME, c_Ri_Com, c_Cont_Code, c_Send_Flag, c_Vou_No, c_Sbjt_Memo,
               c_Ply_No, c_Pre_Flag, c_Cha_Mrk, c_Finbank_Cde, c_Vou_Memo, c_Company_Cde, c_Cost_Cde,
               c_Current_Dpt_Cde, c_Con_Dpt_Cde, c_Check_Flag, c_Period_Name, c_Voucher_No, n_Total_Amt,
               c_Servicetype_No, c_Department_Cde, c_Verifyvou_Memo, c_Trans_Mrk, t_Trans_Tm, c_fee_typ,
               c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT, c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (V_DUE_TM, V_SEQ_NO, v_i, v_CAV_FLAG, v_SBJT_NO, v_due_amt, v_CUR_NO, sysdate, v_DPTACC_NO,
               v_DPT_CDE, v_RCPT_NO, v_SLS_CDE, v_PROD_NO, v_BSNS_TYP, v_CHA_CLS, v_CHA_CDE, v_SALEGRP_CDE,
               v_PAY_PRSN_CDE, v_PAY_PRSN_NAME, null, null, '0', '-1', v_sbjt_memo,
               v_PLY_NO, null, v_CHA_MRK, v_BANK_CDE, v_vou_memo, v_company_cde, null,
               null, v_CON_DPT_CDE, '1', v_PERIOD_NAME, null, null,
               v_SERVICETYPE_NO, null, null, null, null, v_feetyp_cde,
               v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);

               update web_fin_prm_due set c_accnt_flag=substr(c_accnt_flag,1,1)||'1',c_due_mrk='1',t_upd_tm=sysdate where c_rcpt_no=v_rcpt_no;
            end if;
            end;
        end if;
    end loop;
    close prem_con_due;
    end if;
commit;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    BEGIN
      errorline :=DBMS_UTILITY.format_error_backtrace;
      v_err_content := 'proc:[premcontdue],出错流水号:['|| v_rcpt_no ||'],'||'错误行数:'||errorline||'错误描述:[' || SQLCODE || SQLERRM;
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'),'001','0000', v_err_content, SYSDATE);
      COMMIT;
      succflag := '-1';
      if prem_con_due%isopen then
         close prem_con_due;
        end if;
    END;
end;
  end loop;
  close premcon_due;
  commit;
 end;


-- 06 共保
PROCEDURE P_PRMCONTDUE_ACCINS ( succflag out varchar2) is--共保共出  （06,13大类）
  V_RCPT_NO       WEB_FIN_MADCR.C_RCPT_NO%TYPE;
V_FEE_TYP       WEB_FIN_MADCR.C_FEE_TYP%TYPE;
V_END_TM       WEB_FIN_MADCR.T_END_TM%TYPE;
V_CHA_CDE      WEB_FIN_MADCR.C_CHA_CDE%TYPE;
V_EDR_NO     WEB_FIN_MADCR.C_EDR_NO%TYPE;
V_COMPANY_CDE         WEB_FIN_MADCR.C_COMPANY_CDE%TYPE;
V_SALEGRP_CDE            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
V_CURRENT_DPT_CDE  WEB_FIN_MADCR.C_CURRENT_DPT_CDE%TYPE;
V_C_PRE_FLAG    WEB_FIN_MADCR.C_PRE_FLAG%TYPE;
V_SEQ_NO       WEB_FIN_MADCR.C_SEQ_NO%TYPE;
V_CRT_TM       WEB_FIN_MADCR.T_CRT_TM%TYPE;
V_CON_DPT_CDE    WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
V_INSRNC_CDE       WEB_FIN_MADCR.C_INSRNC_CDE%TYPE;
V_ITEM_NO             WEB_FIN_MADCR.C_ITEM_NO%TYPE;
V_PAY_PRSN_NAME    WEB_FIN_MADCR.C_PAY_PRSN_NAME%TYPE;
V_VOU_MEMO        WEB_FIN_MADCR.C_VOU_MEMO%TYPE;
V_SBJT_MEMO        WEB_FIN_MADCR.C_SBJT_MEMO%TYPE;
V_CAV_FLAG           WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
V_FINBANK_CDE     WEB_FIN_MADCR.C_FINBANK_CDE%TYPE;
V_COST_CDE            WEB_FIN_MADCR.C_COST_CDE%TYPE;
V_VOU_NO               WEB_FIN_MADCR.C_VOU_NO%TYPE;
V_CHECK_FLAG      WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
V_USE_ATR              WEB_FIN_MADCR.C_USE_ATR%TYPE;
V_CLM_NO              WEB_FIN_MADCR.C_CLM_NO%TYPE;
V_PLY_NO                WEB_FIN_MADCR.C_PLY_NO%TYPE;
V_CLNT_MRK          WEB_FIN_MADCR.C_CLNT_MRK%TYPE;
V_SBJT_NO              WEB_FIN_MADCR.C_SBJT_NO%TYPE;
V_PROD_NO            WEB_FIN_MADCR.C_PROD_NO%TYPE;
V_DPTACC_NO       WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
V_CUR_NO              WEB_FIN_MADCR.C_CUR_NO%TYPE;
V_CONT_CODE       WEB_FIN_MADCR.C_CONT_CODE%TYPE;
V_SBJT_MRK        WEB_FIN_MADCR.C_SBJT_MRK%TYPE;
V_SEND_FLAG      WEB_FIN_MADCR.C_SEND_FLAG%TYPE;
V_BSNS_TYP         WEB_FIN_MADCR.C_BSNS_TYP%TYPE;
V_RI_COM             WEB_FIN_MADCR.C_RI_COM%TYPE;
V_N_AMT                  WEB_FIN_MADCR.N_AMT%TYPE;
V_SLS_CDE          WEB_FIN_MADCR.C_SLS_CDE%TYPE;
V_DPT_CDE         WEB_FIN_MADCR.C_DPT_CDE%TYPE;
V_PAY_PRSN_CDE      WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;
V_CHA_CLS        WEB_FIN_MADCR.C_CHA_CLS%TYPE;
V_CHA_MRK       WEB_FIN_MADCR.C_CHA_MRK%TYPE;
V_PERIOD_NAME     WEB_FIN_MADCR.C_PERIOD_NAME%TYPE;
V_VOUCHER_NO     WEB_FIN_MADCR.C_VOUCHER_NO%TYPE;
V_TOTAL_AMT        WEB_FIN_MADCR.N_TOTAL_AMT%TYPE;
V_SERVICETYPE_NO    WEB_FIN_MADCR.C_SERVICETYPE_NO%TYPE;
V_DEPARTMENT_CDE   WEB_FIN_MADCR.C_DEPARTMENT_CDE%TYPE;
V_VERIFYVOU_MEMO   WEB_FIN_MADCR.C_VERIFYVOU_MEMO%TYPE;
V_KIND_NO             WEB_FIN_MADCR.C_KIND_NO%TYPE;
V_EXCH_AMT         WEB_FIN_MADCR.N_EXCH_AMT%TYPE;
V_RATE                   WEB_FIN_MADCR.N_RATE%TYPE;
V_TRANS_MRK     WEB_FIN_MADCR.C_TRANS_MRK%TYPE;
V_TRANS_TM       WEB_FIN_MADCR.T_TRANS_TM%TYPE;
V_PRM_SOU                WEB_FIN_MADCR.C_PRM_SOU%TYPE;
V_DUE_TM                   WEB_FIN_MADCR.T_DUE_TM%TYPE;
V_CHR_CUR_NO        WEB_FIN_MADCR.C_CHR_CUR_NO%TYPE;
V_VEHICLESTYP_NO    WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;
V_AGR_FLAG              WEB_FIN_MADCR.C_AGR_FLAG%TYPE;
V_AGR_KIND               WEB_FIN_MADCR.C_AGR_KIND%TYPE;
V_AGR_TYP                  WEB_FIN_MADCR.C_AGR_TYP%TYPE;
V_SIGN_DATE             WEB_FIN_MADCR.T_SIGN_DATE%TYPE;
V_INSRNC_BGN_TM   WEB_FIN_MADCR.T_INSRNC_BGN_TM%TYPE;
V_INSRNC_END_TM    WEB_FIN_MADCR.T_INSRNC_END_TM%TYPE;
V_INVOICE_NO    WEB_FIN_MADCR.C_INVOICE_NO%TYPE;
V_APP_NME        WEB_FIN_MADCR.C_APP_NME%TYPE;
V_ACCDNT_TM    WEB_FIN_MADCR.T_ACCDNT_TM%TYPE;
V_OVER_DATE      WEB_FIN_MADCR.T_OVER_DATE%TYPE;
V_BILLTYPE          WEB_FIN_MADCR.C_BILLTYPE%TYPE;
V_DATA_SRC        WEB_FIN_MADCR.C_DATA_SRC%TYPE;
V_APP_NO           WEB_FIN_PRM_DUE.C_APP_NO%TYPE;
V_TRAN_FLAG        WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE;
V_ACCNT_FLAG       WEB_FIN_PRM_DUE.C_ACCNT_FLAG%TYPE;
V_BS_CUR           WEB_FIN_PRM_DUE.C_BS_CUR%TYPE;
V_UDR_TM         WEB_FIN_PRM_DUE.T_UDR_TM%TYPE;
V_MAIN_CON_CDE   WEB_FIN_PRM_DUE.C_MAIN_CON_CDE%TYPE;
V_CI_SHARE        WEB_FIN_PRM_DUE.N_CI_SHARE%TYPE;
v_due_amt           WEB_FIN_PRM_DUE.N_DUE_AMT%TYPE;
v_tms                  WEB_FIN_PRM_DUE.N_TMS%TYPE;
V_INST_MRK       WEB_FIN_PRM_DUE.C_INST_MRK%TYPE;
v_edr_typ           WEB_FIN_PRM_DUE.C_EDR_TYP%TYPE;
v_BALA_MRK    WEB_FIN_PRM_DUE.C_BALA_MRK%TYPE;
v_due_cur           WEB_FIN_PRM_DUE.C_DUE_CUR%TYPE;
v_feetyp_cde    WEB_FIN_PRM_DUE.C_FEETYP_CDE%TYPE;
v_BANK_CDE     WEB_FIN_PRM_DUE.C_BANK_CDE%TYPE;
V_ORIG_PRM        WEB_FIN_PRM_DET_DUE.N_ORIG_PRM%TYPE;       --单险种保费
V_CVRG_NO        WEB_FIN_PRM_DET_DUE.C_CVRG_NO%TYPE;
V_POS_FLAG       WEB_FIN_PRM_SUBJECT.C_POS_FLAG%TYPE;
V_PRE_FLAG       WEB_FIN_PRM_SUBJECT.C_PRE_FLAG%TYPE;
V_SBJT_NAME   WEB_FIN_PRM_SUBJECT.C_SBJT_NAME%TYPE;
V_ARP_FLAG      WEB_FIN_PRM_SUBJECT.C_ARP_FLAG%TYPE;
V_CONT_MRK      WEB_FIN_PRM_SUBJECT.C_CONT_MRK%TYPE;
V_ERR_CONTENT              WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
V_CVRG_SUM          NUMBER(20,2);
V_PRD_NO                  VARCHAR2(10);
V_AMT                      NUMBER;
V_ITEM                     NUMBER(5);
V_COUNT                    NUMBER;
V_CON                      NUMBER;
V_I                        NUMBER;
V_CON_DPT                 VARCHAR2(10);
V_MAIN_CON                 VARCHAR2(10);

  cursor premcon_due is
       select distinct c_app_no
       from web_fin_prm_due due,web_bas_fin_prod prd
      where trunc(t_due_tm) < trunc(sysdate)+1
      and trunc(due.t_insrnc_bgn_tm) < trunc(sysdate)+1
       and c_accnt_flag IN('00','10')
       and nvl(N_DUE_AMT, 0) <> 0
       and c_tran_flag = '2'
     --  and due.dxp_tran_flag in ('A','H')
       and substr(due.c_prod_no,0,2) in('06','13')
       and due.c_prod_no = prd.c_prod_no
     and due.c_con_dpt_cde = due.c_main_con_cde
        and (
           due.c_bala_mrk='0' or (due.c_bala_mrk='1' and nvl(due.c_edr_typ,'0')='2'  and due.c_edr_no is not null
                                                     and exists(
                                                         select 1 from web_fin_prm_due pd where
                                                            pd.c_ply_no=due.c_ply_no
                                                            and pd.n_tms=due.n_tms
                                                            and pd.c_edr_typ is null
                                                            and pd.c_edr_no is null
                                                            and substr(pd.c_accnt_flag,2,1)='1'
                                                            and nvl(pd.c_due_mrk,'0')='1')
                                  )
          )
       and nvl(c_due_mrk, 0) = '0'
     /*  and substr(due.c_dptacc_cde,0,2)='50'*/;


  cursor premcon_due_conman(v_app_no varchar2) is
       select distinct a.c_main_con_cde,a.c_con_dpt_cde,a.c_tran_flag,a.n_due_amt,a.n_ci_share,a.n_tms
       from web_fin_prm_due a
        where c_app_no=v_app_no
                 /*  and a.dxp_tran_flag in ('A','H')*/;

  CURSOR prem_con_due(v_app_no varchar2) is
    select due.C_RCPT_NO,            --单据号
           due.C_DPT_CDE,            --出单机构
           due.C_DPTACC_CDE,         --做账机构
           due.C_PLY_NO,             --保单号
           due.C_APP_NO,             --投保单号
           due.C_BSNS_TYP,           --业务来源
           due.C_PROD_NO,            --产品代码
           due.C_TRAN_FLAG,          --业务单据标识(自营标识)
           due.N_bs_AMT,             --业务金额
           nvl(due.C_INST_MRK, '0'), --分期标志
           due.C_PAYER_CDE,          --付款人代码
           due.C_PAYER_NME,          --付款人名称
           due.C_SLS_CDE,            --业务员
           due.C_CHA_MRK,            --渠道标识
           due.C_CHA_CLS,            --渠道类别
           due.C_CHA_CDE,            --渠道编码
           due.C_TRANS_MRK,          --迁移标志
           due.T_TRANS_TM,           --迁移时间
           due.T_DUE_TM,             --挂账日期
           due.C_SLSGRP_CDE,         --销售团队
           nvl(due.c_edr_typ,0),     --批改类型
           due.C_BALA_MRK,           --冲销标志
           nvl(due.n_due_amt, 0.00), --挂账金额
           due.C_ACCNT_FLAG,         --会计状态
           due.C_bs_CUR,             --业务币种
           nvl(due.C_DUE_CUR,'01'),  --挂账币种
           due.c_feetyp_cde,         --费用类型代码
           due.C_BANK_CDE,
           due.c_main_con_cde,           --主共
           due.c_con_dpt_cde,            --从共
           due.t_insrnc_bgn_tm,         --保险起期
           --decode(nvl(base.n_edr_prj_no,0),0,base.n_prm,base.n_prm_var),
           due.C_AGRI_MRK,      --涉农标识
           due.c_agr_kind,      --涉农性质
           due.c_agr_typ,       --农险大类
           due.c_edr_no,        --批单号
           due.c_app_nme,        --投保人名称
           due.n_tms,           --期次
       due.t_issue_tm,      --签单日期
           due.c_data_src,       --数据来源
       due.t_udr_tm,         --核保时间
       due.n_ci_share         --共保比例
      from web_fin_prm_due due
     where trunc(t_due_tm) < trunc(sysdate)+1
           and trunc(due.t_insrnc_bgn_tm)< trunc(sysdate)+1
       and nvl(c_due_mrk, '0') = '0'
       and c_accnt_flag in('00','10')
       and nvl(N_DUE_AMT, 0) <> 0
       and c_tran_flag = '2'
     /*  and due.dxp_tran_flag in ('A','H')*/
       and due.c_app_no=v_app_no
    /*   and substr(due.c_dptacc_cde,0,2)='50'*/
       and not exists(
           SELECT 1 FROM web_fin_tmp_dcr dcr
    WHERE dcr.c_rcpt_no = due.c_rcpt_no
        AND c_sbjt_no = '220302'
       );

    cursor prmcon_cvrg(appno varchar2,nTms number) is
     select sum(cvrg.n_orig_prm) as prm,
            cvrg.c_cvrg_no as cvrgno
      from  web_fin_prm_det_due cvrg
      where cvrg.c_app_no = appno
        and cvrg.n_orig_prm <> 0
    and cvrg.n_tms= nTms
   /* and cvrg.dxp_tran_flag in ('A','H')*/
        group by cvrg.c_cvrg_no;
begin
  succflag := '0';
  v_con:=0;
  open premcon_due;
  loop
    begin
    FETCH premcon_due
      into  v_app_no ;
    EXIT WHEN premcon_due%NOTFOUND;
    --判断共保人是否配置 begin
    open premcon_due_conman(v_app_no);
    v_con:=0;
    v_ci_share:=1.000000;
    loop
      fetch premcon_due_conman into v_main_con_cde,v_con_dpt_cde,v_tran_flag,v_due_amt,v_ci_share,v_tms;
      exit when premcon_due_conman%notfound;
      begin
      select sum(cvrg.n_orig_prm) into V_CVRG_SUM
        from web_fin_prm_det_due cvrg
        where cvrg.c_app_no = v_app_no
    and cvrg.n_tms = v_tms;

    if v_con_dpt_cde<>'327001' then
              select c_fingb_cde into v_con_dpt from web_fin_gb where c_gb_cde = v_con_dpt_cde;
           end if;

           select c_fingb_cde into v_main_con from web_fin_gb where c_gb_cde = v_main_con_cde;


      ---- 金额校验 -------------
     if abs(round(V_CVRG_SUM*v_ci_share,2)) <> abs(round(v_due_amt,2)) then
          succflag := '-1';
          v_con:=v_con+1;
          INSERT INTO WEB_BAS_FIN_ERRORLOG
            (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
          VALUES
            (F_Fin_Getcode('e'),'001','0000','proc[p_premcontdue_accins]:'||v_app_no||'(投保单号)金额校验失败',SYSDATE);
      end if;
      exception WHEN NO_DATA_FOUND THEN
        v_err_content :=DBMS_UTILITY.format_error_backtrace;
          succflag := '-1';
          v_con:=v_con+1;
          INSERT INTO WEB_BAS_FIN_ERRORLOG
            (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
          VALUES
            (F_Fin_Getcode('e'),'001','0000',v_err_content||'proc[p_premcontdue_accins]:'||v_app_no||'(投保单号)共保人查询失败',SYSDATE);
      end;
    end loop;
    close premcon_due_conman;
    ----判断共保人是否配置 end

    v_i:=0;
    if v_con = 0 then
    open prem_con_due(v_app_no);

    Dz_Proc.get_fin_no(V_SEQ_NO, '00001', '7', dz_proc.g_pttype);
    loop
      <<GOTO_LAB>>
      FETCH prem_con_due
      into v_RCPT_NO, v_DPT_CDE, v_DPTACC_NO, v_PLY_NO, v_app_no, v_BSNS_TYP, v_PROD_NO, v_tran_flag, v_N_AMT, v_inst_mrk, v_PAY_PRSN_CDE,
       v_PAY_PRSN_NAME, v_SLS_CDE, v_CHA_MRK, v_CHA_CLS, v_CHA_CDE,v_TRANS_MRK, v_TRANS_TM, v_CRT_TM, v_SALEGRP_CDE,
        v_edr_typ, v_BALA_MRK, v_due_amt, v_ACCNT_FLAG, v_CUR_NO,v_due_cur, v_feetyp_cde, v_BANK_CDE,v_main_con_cde,v_con_dpt_cde,v_insrnc_bgn_tm,
        v_agr_flag,v_agr_kind,v_agr_typ,v_edr_no,v_app_nme,v_tms,V_SIGN_DATE,V_DATA_SRC,V_UDR_TM,V_CI_SHARE;
    EXIT WHEN prem_con_due%NOTFOUND;



    v_prd_no:=v_PROD_NO;


    select sum(cvrg.n_orig_prm) into V_CVRG_SUM
        from web_fin_prm_det_due cvrg
        where cvrg.c_app_no = v_app_no
    and cvrg.n_tms = v_tms;

    --汇率 begin
    if v_due_cur is null or v_due_cur = '' then
       v_due_cur:= v_CUR_NO;
    end if;
    if v_due_cur <> '01' or v_CUR_NO <> v_due_cur then
       --核保日期

       if v_due_cur = '01' and v_CUR_NO <> '01' then
          v_due_amt := v_due_amt*rpfunction.getRate(v_CUR_NO,'01',V_UDR_TM);
          v_rate:='1';
       elsif v_due_cur<>'01' and v_CUR_NO='01' then
          v_rate := rpfunction.getRate(v_due_cur,'01',V_UDR_TM);
          v_due_amt:=round(v_due_amt/v_rate,2);
       else
          v_rate := rpfunction.getRate(v_due_cur,'01',V_UDR_TM);
       end if;
    else
       v_rate:=1;
    end if;
    --汇率 end

    if v_edr_typ = '2' and v_BALA_MRK <> '1' then
       insert into WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        values
          (F_Fin_Getcode('e'),'001','0000',
           'proc:[P_premdue_accins],出错流水号:[' || v_rcpt_no ||'] 注销冲正',
           SYSDATE);
    else

      --获公司段信息

       v_COMPANY_CDE:=rpfunction.getFinCompany(v_DPTACC_NO,v_rcpt_no);

        begin

          if  v_due_amt > 0 then
            v_pos_flag := '1';
          else
            v_pos_flag := '0';
          end if;

          if substr(v_ACCNT_FLAG, 1, 1) = '0' then --未实收

             v_pre_flag:='1';
          elsif substr(v_ACCNT_FLAG, 1, 1) = '1' then --已实收

             v_pre_flag:='0';
          else  v_pre_flag:='0';
          end if;
          v_cont_mrk:='1';


   v_i:=0;

          -----险别循环 begin
           for v_prmcvrg in prmcon_cvrg(v_app_no,v_tms)
             loop
              V_ORIG_PRM:= v_prmcvrg.prm;
              v_cvrg_no:= v_prmcvrg.cvrgno;
              v_due_amt := V_ORIG_PRM*v_ci_share;
              if v_due_amt=0 then
                 goto GOTO_LAB;
               end if;



       if v_COMPANY_CDE <>'-1' and v_PROD_NO <> '-1' and v_bsns_typ <> '-1' then


        begin


          v_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
          if v_due_amt > 0 then
            v_pos_flag := '1';
          else
            v_pos_flag := '0';
          end if;
      if substr(v_ACCNT_FLAG, 1, 1) = '0' then --未实收
             v_pre_flag:='1';
               v_vou_memo:='应收保费确认';
          else                           --已实收
             v_pre_flag:='0';
           v_vou_memo:='预收保费结转实收保费';
          end if;

          if v_tran_flag='2' then
             v_cont_mrk:='1';
          else v_cont_mrk:='2';
          end if;

       if v_main_con_cde = v_con_dpt_cde  then  -- 只有我方主共 才进行挂账

           if v_pre_flag = '0'  then --针对801 预收保费-有单预收
            v_inst_mrk  := '*';   --  v_inst_mrk 预收* 分期为 1 不分期为0  v_pre_flag 未实收 0 已实收 1  v_pos_flag 1 正 0 负
          end if;

       select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_pre_flag,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_C_PRE_FLAG,v_prm_sou
              from web_fin_prm_subject
              where c_rp_typ = '701' and rownum=1;

             v_i:= v_i+1;
          insert into web_fin_madcr
              (T_END_TM, C_SEQ_NO, C_ITEM_NO, C_CAV_FLAG, C_SBJT_NO, N_AMT, C_CUR_NO, T_CRT_TM, C_DPTACC_NO,
               C_DPT_CDE, C_RCPT_NO, C_SLS_CDE, C_PROD_NO, C_BSNS_TYP, C_CHA_CLS, C_CHA_CDE, C_SALEGRP_CDE,
               C_PAY_PRSN_CDE, C_PAY_PRSN_NAME, c_Ri_Com, c_Cont_Code, c_Send_Flag, c_Vou_No, c_Sbjt_Memo,
               c_Ply_No, c_Pre_Flag, c_Cha_Mrk, c_Finbank_Cde, c_Vou_Memo, c_Company_Cde, c_Cost_Cde,
               c_Current_Dpt_Cde, c_Con_Dpt_Cde, c_Check_Flag, c_Period_Name, c_Voucher_No, n_Total_Amt,
               c_Servicetype_No, c_Department_Cde, c_Verifyvou_Memo, c_Trans_Mrk, t_Trans_Tm, c_fee_typ,
               c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,c_insrnc_cde,c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (v_due_tm, V_SEQ_NO, v_i, v_CAV_FLAG, v_SBJT_NO, v_due_amt, v_due_cur, sysdate, v_DPTACC_NO,
               v_DPT_CDE, v_RCPT_NO, v_SLS_CDE,
               v_prod_no,
               v_BSNS_TYP, v_CHA_CLS, v_CHA_CDE, v_SALEGRP_CDE,
               v_PAY_PRSN_CDE, v_PAY_PRSN_NAME, null, null, '0', '-1', v_sbjt_memo,
               v_PLY_NO, null, v_CHA_MRK, v_BANK_CDE, v_vou_memo, v_company_cde, null,
               null, v_CON_DPT_CDE, '1', v_PERIOD_NAME, null, null,
               v_SERVICETYPE_NO, null, null, null, null, v_feetyp_cde,

               v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_cvrg_no, v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);
  if v_edr_typ = '2' and v_BALA_MRK = '1' and v_edr_no is not  null then
             select C_SBJT_NO,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
                  into v_SBJT_NO,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
                  from  web_fin_madcr m
                  where m.c_sbjt_no<>'6031' and  rownum=1
                 and m.c_rcpt_no=(select c_rcpt_no from Web_Fin_Prm_Due due
                                      where due.c_ply_no=v_PLY_NO and due.n_tms=v_tms and due.c_edr_typ is null and due.c_feetyp_cde='R' and rownum=1);
              if v_SBJT_NO ='224128' then
                  v_due_amt:=-v_due_amt;
              end if;
       else

                select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
              from  web_fin_prm_subject
              where c_inst_mrk = v_inst_mrk       and c_agri_mrk = '*'and c_nat_typ = '*'    and c_ply_typ = '*'and c_fin_typ = '*'
                   and c_rp_typ = '601'  and c_pre_flag = v_pre_flag     and rownum=1;

             /*退保科目和实收保费挂钩 add by sql*/
                  v_count:=0;
                  SELECT COUNT(*) INTO v_count
                         FROM web_fin_dcr WHERE c_rcpt_no = trim(v_RCPT_NO) AND c_sbjt_no = '220302';
                  IF v_count = 0 THEN
                    select count(1) into v_count from (select sum(N_bs_AMT),sum(N_PAID_AMT)  from web_fin_prm_due
                    where c_ply_no =v_PLY_NO and c_edr_typ IS NULL and c_edr_no IS NULL having sum(N_bs_AMT)=sum(N_PAID_AMT));
                     if v_EDR_TYP=3 or (v_N_AMT <0 AND NVL(LENGTH(v_edr_no),0)>10 AND NVL(LENGTH(v_edr_typ),0)<>2 and v_count<>0)  then

                        v_SBJT_NO :='224128';
                         v_CAV_FLAG:='贷';
                         v_due_amt:=-v_due_amt;
                        v_sbjt_memo :='其他应付款-退保费';
                         v_SERVICETYPE_NO:='1000';
                    end if;
               end if;
     end if;
               v_i:= v_i+1;
     insert into web_fin_madcr
              (T_END_TM, C_SEQ_NO, C_ITEM_NO, C_CAV_FLAG, C_SBJT_NO, N_AMT, C_CUR_NO, T_CRT_TM, C_DPTACC_NO,
               C_DPT_CDE, C_RCPT_NO, C_SLS_CDE, C_PROD_NO, C_BSNS_TYP, C_CHA_CLS, C_CHA_CDE, C_SALEGRP_CDE,
               C_PAY_PRSN_CDE, C_PAY_PRSN_NAME, c_Ri_Com, c_Cont_Code, c_Send_Flag, c_Vou_No, c_Sbjt_Memo,
               c_Ply_No, c_Pre_Flag, c_Cha_Mrk, c_Finbank_Cde, c_Vou_Memo, c_Company_Cde, c_Cost_Cde,
               c_Current_Dpt_Cde, c_Con_Dpt_Cde, c_Check_Flag, c_Period_Name, c_Voucher_No, n_Total_Amt,
               c_Servicetype_No, c_Department_Cde, c_Verifyvou_Memo, c_Trans_Mrk, t_Trans_Tm, c_fee_typ,
               c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,c_insrnc_cde, c_agr_flag,c_agr_kind,c_agr_typ,c_app_nme)
            values
              (v_due_tm, V_SEQ_NO, v_i, v_CAV_FLAG, v_SBJT_NO, v_due_amt, v_due_cur, sysdate, v_DPTACC_NO,
               v_DPT_CDE, v_RCPT_NO, v_SLS_CDE,
              v_PROD_NO,
               v_BSNS_TYP, v_CHA_CLS, v_CHA_CDE, v_SALEGRP_CDE,
               v_PAY_PRSN_CDE, v_PAY_PRSN_NAME, null, null, '0', '-1', v_sbjt_memo,
               v_PLY_NO, null, v_CHA_MRK, v_BANK_CDE, v_vou_memo, v_company_cde, null,
               null, v_CON_DPT_CDE, '1', v_PERIOD_NAME, null, null,
               v_SERVICETYPE_NO, null, null, null, null, v_feetyp_cde,
               v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,v_cvrg_no,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme);

           update web_fin_prm_due set c_accnt_flag=substr(c_accnt_flag,1,1)||'1',c_due_mrk='1',t_upd_tm=sysdate where c_rcpt_no=v_rcpt_no;

 -----------------------------------------------------------------------------------------------------
      elsif v_cont_mrk='2' or v_main_con_cde = v_con_dpt_cde then--我方从共
            v_con := '0';
          end if;
        end;
     end if;
        <<GOTO_LAB>>
        NULL;
 end loop; -----险别循环 end
            -----------------------------------------------------------------------------------------------------
        end;
        end if;

    end loop;
    close prem_con_due;
    if succflag<>'-1' and v_con = 0 then
       update web_fin_prm_due set c_accnt_flag=substr(c_accnt_flag,1,1)||'1',c_due_mrk='1',t_upd_tm=sysdate where c_app_no=v_app_no;
    end if;
    end if;--共保判断
commit;

EXCEPTION
  WHEN OTHERS THEN
    rollback;
    BEGIN
      v_err_content :=DBMS_UTILITY.format_error_backtrace;
      v_err_content := v_err_content||'[06共保proc:[p_prmcontdue_accins],出错流水号:v_app_no=[' || v_app_no ||'],错误描述：[' || SQLCODE || SQLERRM;
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'),'001','0000', v_err_content, SYSDATE);
      COMMIT;
      succflag := '-1';
      if prem_con_due%isopen then
         close prem_con_due;
        end if;
    END;
end ;
  end loop;
  close premcon_due;
  commit;
  end;


-- 手续费
PROCEDURE P_PAYDUE (succflag out varchar2) is--手续费
 V_RCPT_NO       WEB_FIN_MADCR.C_RCPT_NO%TYPE;
 V_FEE_TYP       WEB_FIN_MADCR.C_FEE_TYP%TYPE;
 V_END_TM       WEB_FIN_MADCR.T_END_TM%TYPE;
 V_CHA_CDE      WEB_FIN_MADCR.C_CHA_CDE%TYPE;
 V_EDR_NO     WEB_FIN_MADCR.C_EDR_NO%TYPE;
 v_N_AMT       WEB_FIN_MADCR.N_AMT%TYPE;
V_COMPANY_CDE         WEB_FIN_MADCR.C_COMPANY_CDE%TYPE;
V_SALEGRP_CDE            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
V_CURRENT_DPT_CDE  WEB_FIN_MADCR.C_CURRENT_DPT_CDE%TYPE;
V_PRE_FLAG    WEB_FIN_MADCR.C_PRE_FLAG%TYPE;
V_SEQ_NO       WEB_FIN_MADCR.C_SEQ_NO%TYPE;
V_CRT_TM       WEB_FIN_MADCR.T_CRT_TM%TYPE;
V_CON_DPT_CDE    WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
V_INSRNC_CDE       WEB_FIN_MADCR.C_INSRNC_CDE%TYPE;
V_ITEM_NO             WEB_FIN_MADCR.C_ITEM_NO%TYPE;
V_PAY_PRSN_NAME    WEB_FIN_MADCR.C_PAY_PRSN_NAME%TYPE;
V_VOU_MEMO        WEB_FIN_MADCR.C_VOU_MEMO%TYPE;
V_SBJT_MEMO        WEB_FIN_MADCR.C_SBJT_MEMO%TYPE;
V_CAV_FLAG           WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
V_FINBANK_CDE     WEB_FIN_MADCR.C_FINBANK_CDE%TYPE;
V_COST_CDE            WEB_FIN_MADCR.C_COST_CDE%TYPE;
V_VOU_NO               WEB_FIN_MADCR.C_VOU_NO%TYPE;
V_CHECK_FLAG      WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
V_USE_ATR              WEB_FIN_MADCR.C_USE_ATR%TYPE;
V_CLM_NO              WEB_FIN_MADCR.C_CLM_NO%TYPE;
V_PLY_NO                WEB_FIN_MADCR.C_PLY_NO%TYPE;
V_CLNT_MRK          WEB_FIN_MADCR.C_CLNT_MRK%TYPE;
V_SBJT_NO              WEB_FIN_MADCR.C_SBJT_NO%TYPE;
V_PROD_NO            WEB_FIN_MADCR.C_PROD_NO%TYPE;
V_DPTACC_NO       WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
V_CUR_NO              WEB_FIN_MADCR.C_CUR_NO%TYPE;
V_CONT_CODE       WEB_FIN_MADCR.C_CONT_CODE%TYPE;
V_SBJT_MRK        WEB_FIN_MADCR.C_SBJT_MRK%TYPE;
V_SEND_FLAG      WEB_FIN_MADCR.C_SEND_FLAG%TYPE;
V_BSNS_TYP         WEB_FIN_MADCR.C_BSNS_TYP%TYPE;
V_RI_COM             WEB_FIN_MADCR.C_RI_COM%TYPE;
V_AMT                  WEB_FIN_MADCR.N_AMT%TYPE;
V_SLS_CDE          WEB_FIN_MADCR.C_SLS_CDE%TYPE;
V_DPT_CDE         WEB_FIN_MADCR.C_DPT_CDE%TYPE;
V_PAY_PRSN_CDE      WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;
V_CHA_CLS        WEB_FIN_MADCR.C_CHA_CLS%TYPE;
V_CHA_MRK       WEB_FIN_MADCR.C_CHA_MRK%TYPE;
V_PERIOD_NAME     WEB_FIN_MADCR.C_PERIOD_NAME%TYPE;
V_VOUCHER_NO     WEB_FIN_MADCR.C_VOUCHER_NO%TYPE;
V_TOTAL_AMT        WEB_FIN_MADCR.N_TOTAL_AMT%TYPE;
V_SERVICETYPE_NO    WEB_FIN_MADCR.C_SERVICETYPE_NO%TYPE;
V_DEPARTMENT_CDE   WEB_FIN_MADCR.C_DEPARTMENT_CDE%TYPE;
V_VERIFYVOU_MEMO   WEB_FIN_MADCR.C_VERIFYVOU_MEMO%TYPE;
V_KIND_NO             WEB_FIN_MADCR.C_KIND_NO%TYPE;
V_EXCH_AMT         WEB_FIN_MADCR.N_EXCH_AMT%TYPE;
V_RATE                   WEB_FIN_MADCR.N_RATE%TYPE;
V_TRANS_MRK     WEB_FIN_MADCR.C_TRANS_MRK%TYPE;
V_TRANS_TM       WEB_FIN_MADCR.T_TRANS_TM%TYPE;
V_PRM_SOU                WEB_FIN_MADCR.C_PRM_SOU%TYPE;
V_DUE_TM                   WEB_FIN_MADCR.T_DUE_TM%TYPE;
V_CHR_CUR_NO        WEB_FIN_MADCR.C_CHR_CUR_NO%TYPE;
V_VEHICLESTYP_NO    WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;
V_AGR_FLAG              WEB_FIN_MADCR.C_AGR_FLAG%TYPE;
V_AGR_KIND               WEB_FIN_MADCR.C_AGR_KIND%TYPE;
V_AGR_TYP                  WEB_FIN_MADCR.C_AGR_TYP%TYPE;
V_SIGN_DATE             WEB_FIN_MADCR.T_SIGN_DATE%TYPE;
V_INSRNC_BGN_TM   WEB_FIN_MADCR.T_INSRNC_BGN_TM%TYPE;
V_INSRNC_END_TM    WEB_FIN_MADCR.T_INSRNC_END_TM%TYPE;
V_INVOICE_NO    WEB_FIN_MADCR.C_INVOICE_NO%TYPE;
V_APP_NME        WEB_FIN_MADCR.C_APP_NME%TYPE;
V_ACCDNT_TM    WEB_FIN_MADCR.T_ACCDNT_TM%TYPE;
V_OVER_DATE      WEB_FIN_MADCR.T_OVER_DATE%TYPE;
V_BILLTYPE          WEB_FIN_MADCR.C_BILLTYPE%TYPE;
V_DATA_SRC        WEB_FIN_MADCR.C_DATA_SRC%TYPE;
V_APP_NO          WEB_FIN_PAY_DUE.C_APP_NO%TYPE;
V_TRAN_FLAG       WEB_FIN_PAY_DUE.C_TRAN_FLAG%TYPE;
V_BS_CUR          WEB_FIN_PAY_DUE.C_BS_CUR%TYPE;
V_ISSUE_TM        WEB_FIN_PAY_DUE.T_ISSUE_TM%TYPE;
V_POS_FLAG       WEB_FIN_PRM_SUBJECT.C_POS_FLAG%TYPE;
V_ACCNT_FLAG      WEB_FIN_PAY_DUE.C_ACCNT_FLAG%TYPE;
V_EDR_TYP          WEB_FIN_PAY_DUE.C_EDR_TYP%TYPE;
v_BALA_MRK      WEB_FIN_PAY_DUE.c_Bala_Mrk%TYPE;
v_due_amt           WEB_FIN_PAY_DUE.N_DUE_AMT%TYPE;
v_FEETYP_CDE       WEB_FIN_PAY_DUE.C_FEETYP_CDE%TYPE;
V_udr_tm           WEB_FIN_PAY_DUE.T_UDR_TM%TYPE;
v_sbjt_name   web_fin_pay_subject.c_sbjt_name%type; --科目备注
 v_err_content       WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
V_INST_MRK      VARCHAR2(1);
V_COUNT      NUMBER;
  CURSOR pay_due is
    select pay.C_RCPT_NO, --单据号
           pay.C_DPT_CDE, --出单机构
           pay.C_DPTACC_CDE, --做账机构
           pay.C_PLY_NO, --保单号
           pay.C_APP_NO, --投保单号
           pay.C_BSNS_TYP, --业务来源
           pay.C_PROD_NO, --产品代码
           pay.C_TRAN_FLAG, --业务单据标识(自营标识)
           pay.N_bs_AMT, --业务金额
           pay.C_PAYER_CDE, --付款人代码
           pay.C_PAYER_NME, --付款人名称
           pay.C_SLS_CDE, --业务员
           pay.C_CHA_MRK, --渠道标识
           pay.C_CHA_CLS, --渠道类别
           pay.C_CHA_CDE, --渠道编码
           pay.C_CON_DPT_CDE, --共保人
           pay.C_TRANS_MRK, --迁移标志
           pay.T_TRANS_TM, --迁移时间
           pay.T_DUE_TM, --挂账日期
           pay.C_SLSGRP_CDE, --销售团队
           pay.c_edr_typ, --批改类型
           pay.C_BALA_MRK, --冲销标志
           pay.n_due_amt, --挂账金额
           --pay.C_ACCNT_FLAG, --会计状态
           pay.C_bs_CUR, --业务币种
       pay.c_due_cur,--挂账币种
           pay.c_FEETYP_CDE,--费用类型代码
           pay.C_BANK_CDE, --银行代码
           pay.T_INSRNC_BGN_TM,--保险起期
       pay.T_INSRNC_END_TM,--保险止期
           pay.c_circ_vhl_typ,--车型
           pay.c_agri_mrk,--涉农标识
           pay.c_agr_kind,--涉农性质
           pay.c_agr_typ,--农险大类
           pay.c_app_nme,--投保人名称
       pay.t_udr_tm, --核保日期
       pay.c_data_src,--数据来源
       pay.t_issue_tm --签单日期
      from web_fin_pay_due pay,web_bas_fin_prod prd
     where trunc(pay.t_due_tm) < trunc(sysdate)+1
      and trunc(pay.t_insrnc_bgn_tm) < trunc(sysdate)+1 and
     --   pay.c_rcpt_no = 'S0261010013010201403000100000010'
     --   pay.c_rcpt_no = 'S0261010013010201403000100000014'
        nvl(pay.c_due_mrk, 0) = '0'
       and pay.c_prod_no = prd.c_prod_no
       and c_accnt_flag in('00','10')
       and c_feetyp_cde='S'
    --   and pay.dxp_tran_flag in ('S')
       and pay.c_bala_mrk<>'1'
       and nvl(n_due_amt,0) <> 0;
      -- and substr(pay.c_dptacc_cde,0,2)='50'
begin
  succflag := '0';
  open pay_due;
  loop
    begin
     <<GOTO_LAB>>
    fetch pay_due
      into v_RCPT_NO, v_DPT_CDE, v_DPTACC_NO, v_PLY_NO, v_app_no, v_BSNS_TYP,v_PROD_NO, v_tran_flag, v_N_AMT, v_PAY_PRSN_CDE,
       v_PAY_PRSN_NAME, v_SLS_CDE, v_CHA_MRK, v_CHA_CLS, v_CHA_CDE, v_CON_DPT_CDE, v_TRANS_MRK, v_TRANS_TM, V_DUE_TM,
       v_SALEGRP_CDE, v_edr_typ, v_BALA_MRK, v_due_amt,V_BS_CUR,v_CUR_NO, v_FEETYP_CDE, v_FINBANK_CDE,
       V_INSRNC_BGN_TM, V_INSRNC_END_TM,v_VEHICLESTYP_NO,v_agr_flag,v_agr_kind,v_agr_typ,v_app_nme,V_udr_tm,V_DATA_SRC,V_SIGN_DATE;
    exit when pay_due%notfound;

    SELECT COUNT(*) INTO v_count FROM web_fin_tmp_dcr WHERE c_rcpt_no=trim(v_RCPT_NO)  AND c_sbjt_no = '1124';  --手续费预收 收付的中间状态不挂帐
   IF v_count>0 THEN
         GOTO GOTO_LAB ;
    end if;

      v_tran_flag := '1';  -- 自营标识
      if v_CUR_NO is null or v_CUR_NO = '' or lower(v_CUR_NO) = 'null' then
       v_CUR_NO:= V_BS_CUR;
    end if;
    if v_CUR_NO <> '01' or V_BS_CUR <> v_CUR_NO then
       --核保日期

       if v_CUR_NO = '01' and V_BS_CUR <> '01' then
          v_due_amt := v_due_amt*rpfunction.getRate(V_BS_CUR,'01',V_udr_tm);
          v_rate:='1';
       elsif v_CUR_NO<>'01' and V_BS_CUR='01' then
          v_rate := rpfunction.getRate(v_CUR_NO,'01',V_udr_tm);
          v_due_amt:=round(v_due_amt/v_rate,2);
       else
          v_rate := rpfunction.getRate(v_CUR_NO,'01',V_udr_tm);
       end if;
    else
       v_rate:=1;
    end if;

    v_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
 ----------------------------------------------------------

     --添加分期标识
      if v_app_no is not null then
      select count(c_inst_mrk) into v_count from web_fin_prm_due where c_ply_no = v_PLY_NO AND c_inst_mrk='1' and rownum=1;
       if v_count>0 then
          select c_inst_mrk into v_inst_mrk from web_fin_prm_due where c_ply_no = v_PLY_NO and  c_inst_mrk='1' and rownum=1;
       else
          v_inst_mrk:='0';
       end if;
      end if;

-----------------------------------------
        --获取公司段信息

     v_COMPANY_CDE:=rpfunction.getFinCompany(v_DPTACC_NO,v_rcpt_no);

      Dz_Proc.get_fin_no(V_SEQ_NO, v_dpt_cde, '7', dz_proc.g_pttype);



      --给web_fin_prm_subject.c_pos_flag 赋值
      if v_due_amt > 0 then
        v_pos_flag := '1';
      else
        v_pos_flag := '0';
      end if;


        SELECT COUNT(c_rcpt_no) INTO v_count FROM web_FIN_DCR WHERE c_sbjt_no LIKE '1124%'
                                 AND c_rcpt_no=v_rcpt_no ;
        if v_count>0 then
            v_ACCNT_FLAG :='1';
        else
             v_ACCNT_FLAG :='0';
        end if;
    if  v_ACCNT_FLAG ='1' then
       v_vou_memo:='预付手续费确认';
       else
       v_vou_memo:='手续费确认';
      end if;
      --获取科目编号和科目备注,借贷方向，业务类型 只取第一条数据
      select pay.C_SBJT_NO,
             pay.c_sbjt_name,
             pay.C_CAV_FLAG,
             pay.C_SERVICETYPE_NO,
             pay.c_sbjt_memo
        into v_SBJT_NO, v_sbjt_name, v_CAV_FLAG, v_SERVICETYPE_NO,v_sbjt_memo
        from (select rownum num,
                      C_SBJT_NO,
                      C_SBJT_name,
                      C_CAV_FLAG,
                      C_SERVICETYPE_No,
                      c_sbjt_memo
                 from web_fin_pay_subject
                where c_agri_mrk = v_agr_flag
             and c_nat_typ = '*'
             and c_ply_typ = '*'
             and c_tran_flag = v_tran_flag
             and c_rp_typ = '802'
             and c_pos_flag = v_pos_flag
             and c_fee_typ = 'S'
               ) pay
       where pay.num = 1;

    if v_PROD_NO like '0332%' then
        v_PROD_NO:='033210';
   end if;

      insert into web_fin_madcr
        (T_END_TM, C_SEQ_NO, C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,
         C_SLS_CDE, C_PROD_NO, C_BSNS_TYP,C_CHA_CLS,C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,
         c_Cont_Code,c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,
         c_Cost_Cde,c_Current_Dpt_Cde,c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,c_Servicetype_No,
         c_Department_Cde,c_Verifyvou_Memo,c_Trans_Mrk,t_Trans_Tm,c_fee_typ,t_insrnc_bgn_tm,t_insrnc_end_tm,t_accdnt_tm,
     t_over_date,t_sign_date,c_vehiclestyp_no,c_agr_flag,c_agr_typ,c_edr_no,c_app_nme,c_agr_kind,t_due_tm)
      values
        (V_DUE_TM,V_SEQ_NO,'1',v_CAV_FLAG,v_SBJT_NO,v_due_amt,v_CUR_NO,sysdate,v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,
         v_SLS_CDE,v_PROD_NO,v_BSNS_TYP,v_CHA_CLS,v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,
         null,'0','-1', v_SBJT_memo,v_PLY_NO,null,v_CHA_MRK,v_FINBANK_CDE,v_vou_memo,v_company_cde,null,null,v_CON_DPT_CDE,
         '1',v_PERIOD_NAME,null,null,v_SERVICETYPE_NO,null,null,null,null,v_FEETYP_CDE,v_insrnc_bgn_tm,V_INSRNC_END_TM,
     null,null,V_SIGN_DATE,v_VEHICLESTYP_NO,v_agr_flag,v_agr_typ,null,v_app_nme,v_agr_kind,v_due_tm);

if  v_ACCNT_FLAG ='1'  then
     v_SBJT_NO:='1124';
     v_sbjt_name:='预付手续费';
     v_sbjt_memo:='预付手续费';
     v_CAV_FLAG:='贷';
  else
        select pay.C_SBJT_NO,
               pay.c_sbjt_name,
               pay.C_CAV_FLAG,
               pay.C_SERVICETYPE_NO,
               pay.c_sbjt_memo
          into v_SBJT_NO, v_sbjt_name, v_CAV_FLAG, v_SERVICETYPE_NO,v_sbjt_memo
          from (select rownum num,
                        C_SBJT_NO,
                        C_SBJT_name,
                        C_CAV_FLAG,
                        C_SERVICETYPE_No,
                        c_sbjt_memo
                   from web_fin_pay_subject
                  where c_agri_mrk = v_agr_flag
               and c_nat_typ = '*'
               and c_ply_typ = '*'
               and c_tran_flag = v_tran_flag
               and c_rp_typ = '902'
               and c_pos_flag = v_pos_flag
               and c_inst_mrk =v_inst_mrk
               and c_fee_typ = 'S'
                 ) pay where pay.num = 1;


    end if;
      insert into web_fin_madcr
        (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,
         C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,
         c_Cont_Code,c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,
     c_Cost_Cde,c_Current_Dpt_Cde, c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,c_Servicetype_No,
     c_Department_Cde,c_Verifyvou_Memo,c_Trans_Mrk,t_Trans_Tm,c_fee_typ,t_insrnc_bgn_tm,t_insrnc_end_tm,t_accdnt_tm,t_over_date,
     t_sign_date,c_vehiclestyp_no,c_agr_flag,c_agr_typ,c_edr_no,c_app_nme,c_agr_kind,t_due_tm)
      values
        (V_DUE_TM,V_SEQ_NO,'2', v_CAV_FLAG,v_SBJT_NO,v_due_amt,v_CUR_NO,sysdate,v_DPTACC_NO,v_DPT_CDE,
    v_RCPT_NO,v_SLS_CDE,v_PROD_NO,v_BSNS_TYP,v_CHA_CLS,v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,
         v_PAY_PRSN_NAME, null,null,'0','-1',v_SBJT_memo,v_PLY_NO,null,v_CHA_MRK,v_FINBANK_CDE,v_vou_memo,
         v_company_cde,null,null,v_CON_DPT_CDE,'1',v_PERIOD_NAME,null,null,v_SERVICETYPE_NO,null,
         null,null,null,v_FEETYP_CDE,v_insrnc_bgn_tm,V_INSRNC_END_TM,null,null,V_SIGN_DATE,v_VEHICLESTYP_NO,v_agr_flag,
     v_agr_typ,null,v_app_nme,v_agr_kind,v_due_tm);
      -- 更新接口表信息
        update web_fin_pay_due
         set c_due_mrk = '1',C_ACCNT_FLAG = substr(C_ACCNT_FLAG,1,1)||'1',T_UPD_TM=sysdate
       where c_rcpt_no = v_RCPT_NO;
   --end if;
   commit;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    BEGIN
       v_err_content :=DBMS_UTILITY.format_error_backtrace;
      v_err_content := '手续费proc:[p_paydue],出错流水号：[ ' || v_rcpt_no ||
                       ' ],错误描述：[' || SQLCODE || SQLERRM||v_err_content;

      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'),
         '001', --自动挂账失败
         '0000', --暂无业务类型
         v_err_content,
         SYSDATE);
      COMMIT;
      succflag := '-1';
    END;
end;
  end loop;
  close pay_due;
  commit;
  end;


PROCEDURE P_PREMDUE_CCS (succflag out varchar2) is   --0330车险
 V_RCPT_NO       WEB_FIN_MADCR.C_RCPT_NO%TYPE;
 V_FEE_TYP       WEB_FIN_MADCR.C_FEE_TYP%TYPE;
 V_END_TM       WEB_FIN_MADCR.T_END_TM%TYPE;
 V_CHA_CDE      WEB_FIN_MADCR.C_CHA_CDE%TYPE;
 V_EDR_NO     WEB_FIN_MADCR.C_EDR_NO%TYPE;
V_COMPANY_CDE         WEB_FIN_MADCR.C_COMPANY_CDE%TYPE;
V_SALEGRP_CDE            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
V_CURRENT_DPT_CDE  WEB_FIN_MADCR.C_CURRENT_DPT_CDE%TYPE;
V_C_PRE_FLAG    WEB_FIN_MADCR.C_PRE_FLAG%TYPE;
V_SEQ_NO       WEB_FIN_MADCR.C_SEQ_NO%TYPE;
V_CRT_TM       WEB_FIN_MADCR.T_CRT_TM%TYPE;
V_CON_DPT_CDE    WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
V_INSRNC_CDE       WEB_FIN_MADCR.C_INSRNC_CDE%TYPE;
V_ITEM_NO             WEB_FIN_MADCR.C_ITEM_NO%TYPE;
V_PAY_PRSN_NAME    WEB_FIN_MADCR.C_PAY_PRSN_NAME%TYPE;
V_VOU_MEMO        WEB_FIN_MADCR.C_VOU_MEMO%TYPE;
V_SBJT_MEMO        WEB_FIN_MADCR.C_SBJT_MEMO%TYPE;
V_CAV_FLAG           WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
V_FINBANK_CDE     WEB_FIN_MADCR.C_FINBANK_CDE%TYPE;
V_COST_CDE            WEB_FIN_MADCR.C_COST_CDE%TYPE;
V_VOU_NO               WEB_FIN_MADCR.C_VOU_NO%TYPE;
V_CHECK_FLAG      WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
V_USE_ATR              WEB_FIN_MADCR.C_USE_ATR%TYPE;
V_CLM_NO              WEB_FIN_MADCR.C_CLM_NO%TYPE;
V_PLY_NO                WEB_FIN_MADCR.C_PLY_NO%TYPE;
V_CLNT_MRK          WEB_FIN_MADCR.C_CLNT_MRK%TYPE;
V_SBJT_NO              WEB_FIN_MADCR.C_SBJT_NO%TYPE;
V_PROD_NO            WEB_FIN_MADCR.C_PROD_NO%TYPE;
V_DPTACC_NO       WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
V_CUR_NO              WEB_FIN_MADCR.C_CUR_NO%TYPE;
V_CONT_CODE       WEB_FIN_MADCR.C_CONT_CODE%TYPE;
V_SBJT_MRK        WEB_FIN_MADCR.C_SBJT_MRK%TYPE;
V_SEND_FLAG      WEB_FIN_MADCR.C_SEND_FLAG%TYPE;
V_BSNS_TYP         WEB_FIN_MADCR.C_BSNS_TYP%TYPE;
V_RI_COM             WEB_FIN_MADCR.C_RI_COM%TYPE;
V_AMT                  WEB_FIN_MADCR.N_AMT%TYPE;
V_SLS_CDE          WEB_FIN_MADCR.C_SLS_CDE%TYPE;
V_DPT_CDE         WEB_FIN_MADCR.C_DPT_CDE%TYPE;
V_PAY_PRSN_CDE      WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;
V_CHA_CLS        WEB_FIN_MADCR.C_CHA_CLS%TYPE;
V_CHA_MRK       WEB_FIN_MADCR.C_CHA_MRK%TYPE;
V_PERIOD_NAME     WEB_FIN_MADCR.C_PERIOD_NAME%TYPE;
V_VOUCHER_NO     WEB_FIN_MADCR.C_VOUCHER_NO%TYPE;
V_TOTAL_AMT        WEB_FIN_MADCR.N_TOTAL_AMT%TYPE;
V_SERVICETYPE_NO    WEB_FIN_MADCR.C_SERVICETYPE_NO%TYPE;
V_DEPARTMENT_CDE   WEB_FIN_MADCR.C_DEPARTMENT_CDE%TYPE;
V_VERIFYVOU_MEMO   WEB_FIN_MADCR.C_VERIFYVOU_MEMO%TYPE;
V_KIND_NO             WEB_FIN_MADCR.C_KIND_NO%TYPE;
V_EXCH_AMT         WEB_FIN_MADCR.N_EXCH_AMT%TYPE;
V_RATE                   WEB_FIN_MADCR.N_RATE%TYPE;
V_TRANS_MRK     WEB_FIN_MADCR.C_TRANS_MRK%TYPE;
V_TRANS_TM       WEB_FIN_MADCR.T_TRANS_TM%TYPE;
V_PRM_SOU                WEB_FIN_MADCR.C_PRM_SOU%TYPE;
V_DUE_TM                   WEB_FIN_MADCR.T_DUE_TM%TYPE;
V_CHR_CUR_NO        WEB_FIN_MADCR.C_CHR_CUR_NO%TYPE;
V_VEHICLESTYP_NO    WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;
V_AGR_FLAG              WEB_FIN_MADCR.C_AGR_FLAG%TYPE;
V_AGR_KIND               WEB_FIN_MADCR.C_AGR_KIND%TYPE;
V_AGR_TYP                  WEB_FIN_MADCR.C_AGR_TYP%TYPE;
V_SIGN_DATE             WEB_FIN_MADCR.T_SIGN_DATE%TYPE;
V_INSRNC_BGN_TM   WEB_FIN_MADCR.T_INSRNC_BGN_TM%TYPE;
V_INSRNC_END_TM    WEB_FIN_MADCR.T_INSRNC_END_TM%TYPE;
V_INVOICE_NO    WEB_FIN_MADCR.C_INVOICE_NO%TYPE;
V_APP_NME        WEB_FIN_MADCR.C_APP_NME%TYPE;
V_ACCDNT_TM    WEB_FIN_MADCR.T_ACCDNT_TM%TYPE;
V_OVER_DATE      WEB_FIN_MADCR.T_OVER_DATE%TYPE;
V_BILLTYPE          WEB_FIN_MADCR.C_BILLTYPE%TYPE;
V_DATA_SRC        WEB_FIN_MADCR.C_DATA_SRC%TYPE;
V_BS_cur         WEB_FIN_PRM_DUE.c_Bs_Cur%TYPE;
V_TMS            WEB_FIN_PRM_DUE.N_TMS%TYPE;
V_ACCNT_FLAG      WEB_FIN_PRM_DUE.C_ACCNT_FLAG%TYPE;
V_INST_MRK       WEB_FIN_PRM_DUE.C_INST_MRK%TYPE;
V_UDR_TM        WEB_FIN_PRM_DUE.T_UDR_TM%TYPE;
V_OTHER_AMT      WEB_FIN_PRM_DUE.N_OTHER_AMT%TYPE;
V_APP_NO           WEB_FIN_PRM_DUE.C_APP_NO%TYPE;
V_TRAN_FLAG        WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE;
v_N_AMT            WEB_FIN_PRM_DUE.N_BS_AMT%type;
v_edr_typ           WEB_FIN_PRM_DUE.C_EDR_TYP%TYPE;
v_BALA_MRK    WEB_FIN_PRM_DUE.C_BALA_MRK%TYPE;
v_due_amt        WEB_FIN_PRM_DUE.N_DUE_AMT%TYPE;
v_feetyp_cde    WEB_FIN_PRM_DUE.C_FEETYP_CDE%TYPE;
v_BANK_CDE    WEB_FIN_PRM_DUE.c_Bank_Cde%TYPE;
V_POS_FLAG       WEB_FIN_PRM_SUBJECT.C_POS_FLAG%TYPE;
V_PRE_FLAG       WEB_FIN_PRM_SUBJECT.C_PRE_FLAG%TYPE;
V_SBJT_NAME   WEB_FIN_PRM_SUBJECT.C_SBJT_NAME%TYPE;
V_ARP_FLAG      WEB_FIN_PRM_SUBJECT.C_ARP_FLAG%TYPE;
V_ERR_CONTENT              WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
ERRORLINE                  VARCHAR2(400);
V_COUNT                    NUMBER;
V_PRD_NO                  VARCHAR2(10);
  CURSOR prem_due is
    select C_RCPT_NO,        --单据号
           C_DPT_CDE,        --出单机构
           C_DPTACC_CDE,     --做账机构
           C_PLY_NO,         --保单号
           C_EDR_NO,         -- 批单号
           C_APP_NO,         --投保单号
           C_BSNS_TYP,       --业务来源
           due.C_PROD_NO,        --产品代码
           C_TRAN_FLAG,      --业务单据标识(自营标识)
           N_bs_AMT,         --业务金额
           nvl(C_INST_MRK, '0'), --分期标志
           C_PAYER_CDE,          --付款人代码
           C_PAYER_NME,          --付款人名称
           C_SLS_CDE,            --业务员
           C_CHA_MRK,            --渠道标识
           C_CHA_CLS,            --渠道类别
           C_CHA_CDE,            --渠道编码
           C_CON_DPT_CDE,        --共保人
           due.C_TRANS_MRK,          --迁移标志
           due.T_TRANS_TM,           --迁移时间
           T_DUE_TM,             --挂账日期
           C_SLSGRP_CDE,         --销售团队
           nvl(c_edr_typ,0),     --批改类型
           C_BALA_MRK,           --冲销标志
           nvl(n_due_amt, 0.00), --挂账金额
           C_ACCNT_FLAG,         --会计状态
           C_bs_CUR,             --业务币种
           c_due_cur,            --挂账币种
           c_feetyp_cde,        --费用类型代码
           C_BANK_CDE,          --银行代码
           C_AGRI_MRK,          --涉农标识
           due.c_agr_kind,      --涉农性质
           due.c_agr_typ,       --弄险大类
           T_INSRNC_BGN_TM,   --保险起期
       T_INSRNC_END_TM,   --保险止期
           n_other_amt,      --车船税
           C_CIRC_VHL_TYP,     --车型
           due.c_app_nme,      --投保人名称
           due.n_tms,          --期次
       due.t_udr_tm,      --核保日期
       due.t_issue_tm,    --签单日期
       due.c_data_src      --数据来源

      from web_fin_prm_due due,web_bas_fin_prod a
     where
       trunc(t_due_tm) < trunc(sysdate)+1
      and trunc(due.t_insrnc_bgn_tm) < trunc(sysdate)+1
    --  and c_rcpt_no = '73eb6aa0acdf4c438c46961bf8d8a682'

     -- and c_rcpt_no = 'R00261010013010201403000100000032'

    /*  and due.c_rcpt_no in
     ('R00261010013000201403000100000021','R00261010013000201403000100000022')
      and due.c_rcpt_no in ('R00261010013010201403000100000038') */
       and c_accnt_flag in('00','10')
       and c_tran_flag ='1'
       and a.c_prod_no = due.c_prod_no
       and nvl(c_due_mrk, '0') = '0'
      -- and due.dxp_tran_flag in ('A','H')
       and due.c_rp_flag = '1'
       and due.c_prod_no = '030001'
       and (
           due.c_bala_mrk='0' or (due.c_bala_mrk='1' and nvl(due.c_edr_typ,'0')='2'  and due.c_edr_no is not null
                                                     and exists(
                                                         select 1 from web_fin_prm_due pd where
                                                            pd.c_ply_no=due.c_ply_no
                                                            and pd.n_tms=due.n_tms
                                                            and pd.c_edr_typ is null
                                                            and pd.c_edr_no is null
                                                            and substr(pd.c_accnt_flag,2,1)='1'
                                                            and nvl(pd.c_due_mrk,'0')='1')
                                  )
          )
      -- and substr(due.c_dptacc_cde,0,2)='50'
       and not exists(
       select 1  FROM web_fin_tmp_dcr d WHERE d.c_rcpt_no = due.c_rcpt_no
        AND c_sbjt_no = '220302');

begin
  succflag := '0';
  open prem_due;
  loop
    begin
    <<GOTO_LAB>>
    FETCH prem_due
      into v_RCPT_NO, v_DPT_CDE, v_DPTACC_NO, v_PLY_NO,v_edr_no,v_app_no,
      v_BSNS_TYP, v_PROD_NO, v_tran_flag, v_N_AMT, v_inst_mrk, v_PAY_PRSN_CDE,
      v_PAY_PRSN_NAME, v_SLS_CDE, v_CHA_MRK, v_CHA_CLS, v_CHA_CDE, v_CON_DPT_CDE,
      v_TRANS_MRK, v_TRANS_TM, v_due_TM, v_SALEGRP_CDE, v_edr_typ, v_BALA_MRK,
      v_due_amt, v_ACCNT_FLAG, V_BS_cur,v_cur_NO,v_feetyp_cde, v_BANK_CDE,
      v_agr_flag,v_agr_kind,v_agr_typ,V_INSRNC_BGN_TM,V_INSRNC_END_TM,v_other_amt,
      v_vehiclestyp_no,v_app_nme,v_tms,V_UDR_TM,V_SIGN_DATE,V_DATA_SRC;
    EXIT WHEN prem_due%NOTFOUND;



    v_prd_no:=v_PROD_NO;
    v_prod_no := substr(v_prod_no,1,2);
    if v_cur_NO is null or v_cur_NO = '' then
       v_cur_NO:= V_BS_cur;
    end if;
    if v_cur_NO <> '01' or V_BS_cur <> v_cur_NO then
       --核保日期

       if v_cur_NO = '01' and V_BS_cur <> '01' then
          v_due_amt := v_due_amt*rpfunction.getRate(V_BS_cur,'01',V_UDR_TM);
          v_rate:='1';
          --v_exch_amt:= v_due_amt;
       elsif v_cur_NO<>'01' and V_BS_cur='01' then
          v_rate := rpfunction.getRate(v_cur_NO,'01',V_UDR_TM);
          v_due_amt:=round(v_due_amt/v_rate,2);
       else
          v_rate := rpfunction.getRate(v_cur_NO,'01',V_UDR_TM);
       end if;
    else
       v_rate:=1;
    end if;



    if v_edr_typ = '2' and v_BALA_MRK <> '1' then
       INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
       VALUES
          (F_Fin_Getcode('e'),'001','0000','proc:[p_prmdue_css],出错流水号:['|| v_rcpt_no||']注销冲正',SYSDATE);
    else

      --获取成本中心,公司段信息

       v_COMPANY_CDE:=rpfunction.getFinCompany(v_DPTACC_NO,v_rcpt_no);

           Dz_Proc.get_fin_no(V_SEQ_NO, v_dpt_cde, '7', dz_proc.g_pttype);
           v_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
              --给web_fin_prm_subject.c_pos_flag 赋值
              if v_due_amt > 0 then
                v_pos_flag := '1';
              else
                v_pos_flag := '0';
              end if;

      if substr(v_ACCNT_FLAG, 1, 1) = '0' then --未实收
             v_pre_flag:='1';
               v_vou_memo:='应收保费确认';
          else                           --已实收
             v_pre_flag:='0';
           v_vou_memo:='预收保费结转实收保费';
          end if;



                --获取科目编号和科目备注，明细段，借贷方向，业务类型,只取第一条数据
            if    v_N_AMT<>0 then

              if v_pre_flag = '0'  then --针对801 预收保费-有单预收
                  v_inst_mrk  := '*';   --  v_inst_mrk 预收* 分期为 1 不分期为0  v_pre_flag 未实收 0 已实收 1  v_pos_flag 1 正 0 负
                end if;

             select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_pre_flag,c_prm_sou
                    into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_C_PRE_FLAG,v_prm_sou
                    from web_fin_prm_subject
                    where c_rp_typ = '701'  and rownum=1;

                insert into web_fin_madcr
                  (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
                   C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
                   C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
                   c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
                   c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
                   c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
                   c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo, c_Trans_Mrk,t_Trans_Tm,
                   c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT
                   ----根据v5需求添加
                   ,t_insrnc_bgn_tm,t_insrnc_end_tm,t_accdnt_tm,t_over_date,t_sign_date,
                   c_vehiclestyp_no,c_agr_flag,c_agr_typ,c_edr_no,c_app_nme,c_agr_kind )
                values
                  (v_due_tm,V_SEQ_NO,'1',v_CAV_FLAG,v_SBJT_NO,v_due_amt,v_cur_NO,sysdate,
                   v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PRD_NO,v_BSNS_TYP,v_CHA_CLS,
                   v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
                   '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
                   v_BANK_CDE,v_vou_memo,v_company_cde,null,null,
                   v_CON_DPT_CDE,'1',v_PERIOD_NAME,null,null,
                   v_SERVICETYPE_NO,null,null,null,null,
                   v_feetyp_cde,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate
                   ,v_insrnc_bgn_tm,v_insrnc_end_tm,null,null,V_SIGN_DATE,
                   v_vehiclestyp_no,v_agr_flag,v_agr_typ,v_edr_no,v_app_nme,v_agr_kind
                   );

   if v_edr_typ = '2' and v_BALA_MRK = '1' and v_edr_no is not  null then
             select C_SBJT_NO,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
                  into v_SBJT_NO,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
                  from  web_fin_madcr m
                  where m.c_sbjt_no<>'6031' and  rownum=1
                 and m.c_rcpt_no=(select c_rcpt_no from Web_Fin_Prm_Due due
                                      where due.c_ply_no=v_PLY_NO and due.n_tms=v_tms and due.c_edr_typ is null and due.c_feetyp_cde='R' and rownum=1);
              if v_SBJT_NO ='224128' then
                  v_due_amt:=-v_due_amt;
              end if;
       else
           select C_SBJT_NO,C_ARP_FLAG,C_SBJT_name,c_sbjt_memo,C_CAV_FLAG,C_SERVICETYPE_NO,c_prm_sou
              into v_SBJT_NO,v_arp_flag,v_sbjt_name,v_sbjt_memo,v_CAV_FLAG,v_SERVICETYPE_NO,v_prm_sou
              from  web_fin_prm_subject
              where c_inst_mrk = v_inst_mrk       and c_agri_mrk = '*'and c_nat_typ = '*'    and c_ply_typ = '*'and c_fin_typ = '*'
                   and c_rp_typ = '601'  and c_pre_flag = v_pre_flag     and rownum=1;
                     /*退保科目和实收保费挂钩 add by sql*/
                  v_count:=0;
                  SELECT COUNT(*) INTO v_count
                         FROM web_fin_dcr WHERE c_rcpt_no = trim(v_RCPT_NO) AND c_sbjt_no = '220302';
                  IF v_count = 0 THEN
                    select count(1) into v_count from (select sum(N_bs_AMT),sum(N_PAID_AMT)  from web_fin_prm_due
                    where c_ply_no =v_PLY_NO and c_edr_typ IS NULL and c_edr_no IS NULL having sum(N_bs_AMT)=sum(N_PAID_AMT));
                   if v_EDR_TYP=3 or (v_N_AMT <0 AND NVL(LENGTH(v_edr_no),0)>10 AND NVL(LENGTH(v_edr_typ),0)<>2 and v_count<>0)  then

                       v_SBJT_NO :='224128';
                         v_CAV_FLAG:='贷';
                         v_due_amt:=-v_due_amt;
                        v_sbjt_memo :='其他应付款-退保费';
                         v_SERVICETYPE_NO:='1000';
                    end if;
               end if;
   end if;
                insert into web_fin_madcr
                  (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
                   C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
                   C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
                   c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
                   c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
                   c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
                   c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo,c_Trans_Mrk,t_Trans_Tm,
                   c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,
                   c_agr_flag,c_agr_kind,T_INSRNC_BGN_TM,T_INSRNC_END_TM
                   ,T_SIGN_DATE,c_app_nme,c_agr_typ,c_vehiclestyp_no
                   )
                values
                  (v_due_tm,V_SEQ_NO,'2',v_CAV_FLAG,v_SBJT_NO,v_due_amt,v_cur_NO,sysdate,
                   v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PRD_NO,v_BSNS_TYP,v_CHA_CLS,
                   v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
                   '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
                   v_BANK_CDE,v_vou_memo,v_company_cde,null,null,v_CON_DPT_CDE,
                   '1',v_PERIOD_NAME,null,null,
                   v_SERVICETYPE_NO,null,null,null,null,
                   v_feetyp_cde,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,
                   v_agr_flag,v_agr_kind,v_insrnc_bgn_tm,v_insrnc_end_tm
                   ,V_SIGN_DATE,v_app_nme,v_agr_typ,v_vehiclestyp_no
                   );
              end if;


--  wuqy 添加对车船税
       if v_pre_flag = 1 then
         if RTRIM(LTRIM(v_prd_no)) = '0330' and v_EDR_TYP <> '3' and v_edr_typ <> '2'  THEN
            if v_other_amt <> 0 then
               v_sbjt_no := '122113';
               v_cav_flag := '借';

                insert into web_fin_madcr
                  (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
                   C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
                   C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
                   c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
                   c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
                   c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
                   c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo,c_Trans_Mrk,t_Trans_Tm,
                   c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,
                   c_agr_flag,c_agr_kind,T_INSRNC_BGN_TM,T_INSRNC_END_TM
                   ,T_SIGN_DATE,c_app_nme,c_agr_typ,c_vehiclestyp_no
                   )
                values
                  (v_due_tm,V_SEQ_NO,'3',v_CAV_FLAG,v_SBJT_NO,v_other_amt,v_cur_NO,sysdate,
                   v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PRD_NO,v_BSNS_TYP,v_CHA_CLS,
                   v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
                   '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
                   v_BANK_CDE,v_vou_memo,v_company_cde,null,null,v_CON_DPT_CDE,
                   '1',v_PERIOD_NAME,null,null,
                   v_SERVICETYPE_NO,null,null,null,null,
                   v_feetyp_cde,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,
                   v_agr_flag,v_agr_kind,v_insrnc_bgn_tm,v_insrnc_end_tm
                   ,V_SIGN_DATE,v_app_nme,v_agr_typ,v_vehiclestyp_no
                   );
               v_cav_flag := '贷';
               v_sbjt_no := '224120';
               insert into web_fin_madcr
                  (T_END_TM,C_SEQ_NO,C_ITEM_NO,C_CAV_FLAG,C_SBJT_NO,N_AMT,C_CUR_NO,T_CRT_TM,
                   C_DPTACC_NO,C_DPT_CDE,C_RCPT_NO,C_SLS_CDE,C_PROD_NO,C_BSNS_TYP,C_CHA_CLS,
                   C_CHA_CDE,C_SALEGRP_CDE,C_PAY_PRSN_CDE,C_PAY_PRSN_NAME,c_Ri_Com,c_Cont_Code,
                   c_Send_Flag,c_Vou_No,c_Sbjt_Memo,c_Ply_No,c_Pre_Flag,c_Cha_Mrk,
                   c_Finbank_Cde,c_Vou_Memo,c_Company_Cde,c_Cost_Cde,c_Current_Dpt_Cde,
                   c_Con_Dpt_Cde,c_Check_Flag,c_Period_Name,c_Voucher_No,n_Total_Amt,
                   c_Servicetype_No,c_Department_Cde,c_Verifyvou_Memo,c_Trans_Mrk,t_Trans_Tm,
                   c_fee_typ,c_prm_sou,t_due_tm,n_rate,N_EXCH_AMT,
                   c_agr_flag,c_agr_kind,T_INSRNC_BGN_TM,T_INSRNC_END_TM
                   ,T_SIGN_DATE,c_app_nme,c_agr_typ,c_vehiclestyp_no
                   )
                values
                  (v_due_tm,V_SEQ_NO,'4',v_CAV_FLAG,v_SBJT_NO,v_other_amt,v_cur_NO,sysdate,
                   v_DPTACC_NO,v_DPT_CDE,v_RCPT_NO,v_SLS_CDE,v_PRD_NO,v_BSNS_TYP,v_CHA_CLS,
                   v_CHA_CDE,v_SALEGRP_CDE,v_PAY_PRSN_CDE,v_PAY_PRSN_NAME,null,null,
                   '0','-1',v_sbjt_memo,v_PLY_NO,null,v_CHA_MRK,
                   v_BANK_CDE,v_vou_memo,v_company_cde,null,null,v_CON_DPT_CDE,
                   '1',v_PERIOD_NAME,null,null,
                   v_SERVICETYPE_NO,null,null,null,null,
                   v_feetyp_cde,v_prm_sou,v_due_tm,v_rate,v_due_amt*v_rate,
                   v_agr_flag,v_agr_kind,v_insrnc_bgn_tm,v_insrnc_end_tm
                   ,V_SIGN_DATE,v_app_nme,v_agr_typ,v_vehiclestyp_no
                   );

       end if;
       end if;
       end if;
              update web_fin_prm_due
                 set c_due_mrk = '1', t_upd_tm=sysdate, C_ACCNT_FLAG = substr(C_ACCNT_FLAG, 1, 1) || '1'
               where c_rcpt_no = v_RCPT_NO;
          end if;----产品,公司,部门,渠道 end

    --end if;
commit;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    BEGIN
      errorline :=DBMS_UTILITY.format_error_backtrace;
      v_err_content := 'proc:[p_premdue_ccs],出错流水号:c_rcpt_no['|| v_rcpt_no ||'],'||'错误行数:'||errorline||'错误描述:[' || SQLCODE || SQLERRM;
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'), '001', '0000',v_err_content,SYSDATE);
      COMMIT;
      succflag := '-1';
    END;
end;
  end loop;
  close prem_due;
  commit;
  end;

PROCEDURE P_FIN_GATHERMADCR(succflag out varchar2)
IS
   v_seq_no                 WEB_FIN_MADCR.C_SEQ_NO%TYPE;
   v_seq_no_tmp           WEB_FIN_MADCR.C_SEQ_NO%TYPE;
  v_item_no                WEB_FIN_MADCR.C_ITEM_NO%TYPE;
  v_cav_flag               WEB_FIN_MADCR.C_CAV_FLAG%TYPE;
  V_VEHICLESTYP_NO         WEB_FIN_MADCR.C_VEHICLESTYP_NO%TYPE;  -- 暂时没有车型
  v_ply_no                 WEB_FIN_MADCR.C_PLY_NO%TYPE;
  v_sls_cde                WEB_FIN_MADCR.C_SLS_CDE%TYPE;   -- 业务员
  v_pay_prsn_cde           WEB_FIN_MADCR.C_PAY_PRSN_CDE%TYPE;  -- 被保险人编码
  v_dpt_cde                WEB_FIN_MADCR.C_DPT_CDE%TYPE;
  v_prod_no                WEB_FIN_MADCR.C_PROD_NO%TYPE;
  v_cur_no                 WEB_FIN_MADCR.C_CUR_NO%TYPE;
  v_amt                    WEB_FIN_MADCR.N_AMT%TYPE;
  v_crt_tm                 WEB_FIN_MADCR.T_CRT_TM%TYPE;
  v_dptacc_cde             WEB_FIN_MADCR.C_DPTACC_NO%TYPE;
  v_salegrp_cde            WEB_FIN_MADCR.C_SALEGRP_CDE%TYPE;
  v_bsns_typ               WEB_FIN_MADCR.C_BSNS_TYP%TYPE;   -- 业务来源
  v_cha_mrk                WEB_FIN_MADCR.C_CHA_MRK%TYPE;   -- 渠道标识
  v_vou_memo               WEB_FIN_MADCR.C_VOU_MEMO%TYPE;  -- 凭证摘要
  v_con_dpt_cde            WEB_FIN_MADCR.C_CON_DPT_CDE%TYPE;
  v_check_flag             WEB_FIN_MADCR.C_CHECK_FLAG%TYPE;
  v_sbjt_no                WEB_FIN_MADCR.C_SBJT_NO%TYPE;
  v_ri_com                 WEB_FIN_MADCR.C_RI_COM%TYPE;
  v_err_content            WEB_BAS_FIN_ERRORLOG.C_Err_CONTENT%TYPE;
  v_agr_flag               CHAR;         --涉农标志    1涉农险 2非涉农 3农险
  v_agr_kind               VARCHAR2(4);  --涉农性质    01政策性  02商业性
  v_agr_typ                VARCHAR2(4);  --农险标的物 类似于交强险车型代码
  v_insrnc_cde             VARCHAR2(8);     --安诚财务接口升级
  v_edr_no                 VARCHAR2(30);
  v_clm_no                 VARCHAR2(30);
  v_SIGN_DATE              DATE;
  v_INSRNC_BGN_TM          DATE;
  v_INSRNC_END_TM          DATE;
  v_APP_NME                WEB_FIN_PRM_DUE.C_APP_NME%TYPE;  --投保人
  v_ACCDNT_TM              DATE;             --出险日期
  v_OVER_DATE              DATE;             --结案时间
  v_BILLTYPE               VARCHAR2(30);
  v_cha_cde                WEB_FIN_PRM_DUE.C_CHA_CDE%TYPE;    -- 代理
  v_rcpt_no                web_fin_pay_due.c_rcpt_no%type;
  V_DPT_NAME               v_fin_madcr.C_DPT_NAME%TYPE; --  机构名称
  V_DPTACC_NAME            v_fin_madcr.C_DPTACC_NAME%TYPE; -- 做帐机构名称
  V_PROD_NAME              web_prd_prod.c_nme_cn%type;  --产品名称
  V_SBJT_NAME              v_fin_madcr.c_sbjt_name%TYPE; -- 科目名称
  v_CURRENT_DPT_CDE        v_fin_madcr.c_current_dpt_cde%type; -- 内部往来
  v_count                  integer;
  v_fee_typ                web_fin_madcr.c_fee_typ%type;
  v_index                  integer;
  CURSOR cur_ifgDetailma IS
  SELECT c_seq_no,c_item_no,c_cav_flag,C_VEHICLESTYP_NO,  -- 车型
       c_ply_no,C_SLS_CDE,C_PAY_PRSN_CDE,c_dpt_cde,c_prod_no,
       c_cur_no,n_amt,t_crt_tm,c_dptacc_no,c_salegrp_cde,
       c_bsns_typ,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_check_flag,
       c_sbjt_no,c_ri_com,c_agr_flag,c_agr_kind,c_agr_typ,
       t_sign_date,t_INSRNC_BGN_TM,t_INSRNC_END_TM,c_APP_NME,c_edr_no,
       c_clm_no,t_ACCDNT_TM,t_over_date,c_insrnc_cde,C_CURRENT_DPT_CDE,
       c_fee_typ,c_rcpt_no
    FROM WEB_FIN_MADCR
    WHERE nvl(c_vou_no,'-1')='-1' and nvl(c_send_flag,'0')='0'
      AND  TRUNC(t_crt_tm) < TRUNC(SYSDATE)+1
           order by c_seq_no desc;
      --AND c_vou_memo<>'应收其他共保人赔款'
      --AND c_vou_memo<>'应收其他共保人手续费';
     --获取所有没有传财务的类凭证（进行借贷平衡校验）add by wanxc at 20080326

  BEGIN
    v_sbjt_no := '0000';
    v_index:=0;
    --v_seq_no_tmp:='0000';

    OPEN cur_ifgDetailma;
    succflag := '0';
    LOOP

    <<GOTO_LAB>>
    FETCH cur_ifgDetailma
    INTO
    v_seq_no,v_item_no,v_cav_flag,V_VEHICLESTYP_NO,
    v_ply_no,v_sls_cde,v_pay_prsn_cde,v_dpt_cde,v_prod_no,
    v_cur_no,v_amt,v_crt_tm,v_dptacc_cde,v_salegrp_cde,
    v_bsns_typ,v_cha_mrk,v_vou_memo,v_con_dpt_cde,v_check_flag,
    v_sbjt_no,v_ri_com,v_agr_flag,v_agr_kind,v_agr_typ,
    v_sign_date,v_INSRNC_BGN_TM,v_INSRNC_END_TM,v_APP_NME,v_edr_no,
    v_clm_no,v_ACCDNT_TM,v_over_date,v_insrnc_cde,v_CURRENT_DPT_CDE,
    v_fee_typ,V_RCPT_NO;
    EXIT WHEN cur_ifgDetailma%NOTFOUND;
        IF v_amt = 0 THEN
          UPDATE WEB_FIN_MADCR
          SET c_vou_no='金额为0，不传财务'
          WHERE 1=1
            AND c_item_no = v_item_no
            AND c_seq_no=v_seq_no;
            GOTO GOTO_LAB ;
        END IF;
       /* if v_seq_no_tmp<>'0000' and v_seq_no<>v_seq_no_tmp then
          commit;
         end if;*/
        IF v_VEHICLESTYP_NO = '00' or  v_VEHICLESTYP_NO is null THEN
            v_VEHICLESTYP_NO := '';
        END IF ;
        -- 出现非交强险附带车型问题
        IF SUBSTR(v_prod_no,1,4) <> '030001' THEN
            v_VEHICLESTYP_NO := '';
/*        elsif   SUBSTR(v_prod_no,1,4) = '0330' and v_fee_typ='S'
            THEN
             SELECT c_circ_vhl_typ INTO v_VEHICLESTYP_NO FROM web_fin_pay_due WHERE C_RCPT_NO=V_RCPT_NO;*/
        END IF;

        IF SUBSTR(v_prod_no,1,2) <> '14' THEN
            v_agr_typ := '';
        END IF;

        -- 加入 c_dpt_name
        if v_dpt_cde is not null then
        SELECT count(C_DPT_CNM) into v_count FROM WEB_ORG_DPT WHERE WEB_ORG_DPT.C_DPT_CDE = v_dpt_cde;
        if v_count = 1 then
         select c_dpt_cnm into V_DPT_NAME FROM WEB_ORG_DPT WHERE WEB_ORG_DPT.C_DPT_CDE = v_dpt_cde;
        else
         V_DPT_NAME := '';
        end if;
        end if;

        -- 加入 c_dptacc_name
        if v_dptacc_cde is not null then
        SELECT count(C_DPT_CNM) INTO v_count FROM WEB_ORG_DPT WHERE WEB_ORG_DPT.C_DPT_CDE = v_dptacc_cde;
        if v_count = 1 then
          SELECT C_DPT_CNM INTO V_DPTACC_NAME FROM WEB_ORG_DPT WHERE WEB_ORG_DPT.C_DPT_CDE = v_dptacc_cde;
        else
          v_dptacc_name := '';
          end if;
        end if;

        -- 加入 c_prod_name
        if v_prod_no is not null then
        SELECT count(C_NME_CN) INTO v_count FROM WEB_PRD_PROD WHERE WEB_PRD_PROD.C_PROD_NO = substr(v_prod_no,1,4);
        if v_count = 1 then
        SELECT C_NME_CN INTO V_PROD_NAME FROM WEB_PRD_PROD WHERE WEB_PRD_PROD.C_PROD_NO = substr(v_prod_no,1,4);
        else
         V_PROD_NAME := '';
        end if;
        end if;

       -- 加入 科目名称
       if  v_sbjt_no is not null then
       SELECT count(C_SBJT_NAME) INTO v_count FROM WEB_BAS_FIN_SUBJECT WHERE WEB_BAS_FIN_SUBJECT.C_SBJT_NO = v_sbjt_no;
       if v_count = 1 then
       SELECT C_SBJT_NAME INTO V_SBJT_NAME FROM WEB_BAS_FIN_SUBJECT WHERE WEB_BAS_FIN_SUBJECT.C_SBJT_NO = v_sbjt_no;
       else
        v_sbjt_name := '';
       end if;
       end if;
--客商信息
   if v_con_dpt_cde is not null or v_con_dpt_cde<>'' then
    begin
    SELECT c_ri_com into v_CURRENT_DPT_CDE
                      FROM T_FIN_CONDPT_TO_RI
                   WHERE c_con_dpt_cde = v_con_dpt_cde
                        AND t_effect_tm <= SYSDATE
                       AND (t_adb_tm IS NULL OR t_adb_tm > SYSDATE)
                       and v_con_dpt_cde like '327%';
          exception when no_data_found then
            v_CURRENT_DPT_CDE:=v_CURRENT_DPT_CDE;
    end;
    end if;
  ----给赔款挂账加上保险起止期
  if  v_clm_no is not null or v_clm_no<>'' then
      begin
      SELECT t_INSRNC_BGN_TM ,t_INSRNC_END_TM into v_INSRNC_BGN_TM,v_INSRNC_END_TM
             FROM WEB_FIN_PRM_DUE WHERE C_ply_NO =v_ply_no
             AND ROWNUM = 1;
   exception when no_data_found then
     v_INSRNC_BGN_TM:=v_INSRNC_BGN_TM;
    end;
    end if;
        --add by wkf 2013-8-14 险别代码除06意外险和13健康险外 其余为空
        IF trim(v_insrnc_cde) like '06%' or trim(v_insrnc_cde) like '13%' THEN
        v_insrnc_cde:=v_insrnc_cde;
        else v_insrnc_cde:=null;
        end if;

         --add by wkf 2013-8-14
      /*  v_dpt_cde:=rpfunction.getDptCde('to_old',v_dpt_cde);--add by wkf 2013-5-27
        v_dptacc_cde:=rpfunction.getDptCde('to_old',v_dptacc_cde);--add by wanghui 2013-5-27
        v_sls_cde:=rpfunction.getEmpCde('to_old',v_sls_cde);--add by wkf 2013-5-30
        v_ri_com:=rpfunction.getEmpCde('to_old',v_ri_com);--add by wkf 2013-5-30*/

        INSERT INTO v_fin_madcr(c_ply_no,C_SLS_CDE,C_PAY_PRSN_CDE,c_seq_no,c_item_no,
        c_cav_flag,c_sbjt_no,n_amt,c_cur_no,t_crt_tm,
        c_dptacc_no,c_dpt_cde,c_prod_no,c_vou_memo,c_send_flag,
        c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
        c_ri_com,c_agr_flag,c_agr_kind,t_sign_date,t_INSRNC_BGN_TM,
        t_INSRNC_END_TM,c_APP_NME,c_edr_no,c_clm_no,t_ACCDNT_TM,
        t_over_date,c_insrnc_cde,c_dpt_name,c_dptacc_name,c_prod_name,
        c_sbjt_name,C_pay_prsn_NAME)
        VALUES(v_ply_no,v_sls_cde,v_pay_prsn_cde,v_seq_no,v_item_no,
        v_cav_flag,v_sbjt_no,v_amt,v_cur_no,v_crt_tm,
        DECODE(SUBSTR(v_dptacc_cde,1,6),'330607','330607',SUBSTR(v_dptacc_cde,1,4)),
        v_dpt_cde,trim(v_prod_no || SUBSTR(v_VEHICLESTYP_NO,1,2)),v_vou_memo,'0',
        v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,
        v_sls_cde,v_agr_flag,v_agr_kind,v_sign_date,v_INSRNC_BGN_TM,
        v_INSRNC_END_TM,v_APP_NME,v_edr_no,v_clm_no,v_ACCDNT_TM,
        v_over_date,v_insrnc_cde,V_DPT_NAME,v_dptacc_name,v_prod_name,
        v_sbjt_name,v_APP_NME);
 --         commit;

        /*刷新汇总信息*/
        UPDATE WEB_FIN_MADCR
          SET c_vou_no=v_seq_no
          WHERE 1=1
            AND c_item_no = v_item_no
            AND c_seq_no=v_seq_no;
          COMMIT;


         END LOOP;
          CLOSE cur_ifgDetailma;




    EXCEPTION
      WHEN OTHERS THEN
        --RAISE;
        rollback;
        begin
        v_err_content:=DBMS_UTILITY.format_error_backtrace;
        v_err_content:='proc:[P_Fin_Gathermadcr],出错流水号：['||'c_clm_no='||v_clm_no||',C_ply_NO='||v_ply_NO||',v_rcpt_no='||v_rcpt_no||',v_amt='||v_amt||',v_seq_no='||v_seq_no||',v_item_no='||v_item_no||','||v_err_content||'],错误描述：['||SQLCODE||SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG( c_err_no,c_errtype_no,c_tran_type,c_err_content,t_crt_tm )
        VALUES(F_Fin_Getcode('e'),'001',  '0000',  v_err_content,SYSDATE);
        COMMIT;
        succflag := '-1';
        end;
  END;

    --用友要求用C_CURRENT_DPT_CDE字段来存放C_RI_COM字段的值，
    --用C_RI_COM字段来存放C_SLS_CDE字段的值
/*
    --add by wanxc at 20071114添加共保公司到再保公司的映射(与上一个update语句顺序不可以互换)
 begin
    UPDATE V_FIN_maDCR a
      SET C_CURRENT_DPT_CDE = (SELECT c_ri_com
                      FROM T_FIN_CONDPT_TO_RI
                   WHERE c_con_dpt_cde = a.c_con_dpt_cde
                        AND t_effect_tm <= SYSDATE
                       AND (t_adb_tm IS NULL OR t_adb_tm > SYSDATE))
      WHERE (C_CURRENT_DPT_CDE IS NULL OR C_CURRENT_DPT_CDE = CHR(0))
        AND c_seq_no = v_seq_no
        AND c_item_no = v_item_no
        AND c_con_dpt_cde IS NOT NULL
        AND c_con_dpt_cde LIKE '327%';
     end;

        ---内部往来机构--

    --end--
        -------------添加被保险人-------
        UPDATE V_FIN_MADCR
        SET C_pay_prsn_NAME=c_app_nme
        WHERE 1=1 AND c_seq_no = v_seq_no AND c_item_no = v_item_no;

        ----给赔款挂账加上保险起止期
        UPDATE v_fin_madcr
        SET t_INSRNC_BGN_TM =(SELECT t_INSRNC_BGN_TM FROM WEB_FIN_PRM_DUE WHERE v_fin_madcr.C_ply_NO = WEB_FIN_PRM_DUE.C_ply_NO AND ROWNUM = 1),
         t_INSRNC_END_TM =(SELECT t_INSRNC_END_TM FROM WEB_FIN_PRM_DUE WHERE v_fin_madcr.C_ply_NO = WEB_FIN_PRM_DUE.C_ply_NO AND ROWNUM = 1)
        WHERE 1=1 AND c_seq_no = v_seq_no AND c_item_no = v_item_no
        AND c_clm_no=v_clm_no;
    -------------------end-----------------------*/


    --v_seq_no_tmp:=v_seq_no;

end RPAUTOBILL;

/
