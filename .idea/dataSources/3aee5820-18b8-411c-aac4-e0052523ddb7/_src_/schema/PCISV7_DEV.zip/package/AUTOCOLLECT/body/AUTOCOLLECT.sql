CREATE PACKAGE BODY "AUTOCOLLECT" IS
  --??
  PROCEDURE DividendGather IS
    --??????  ?????????????????? ?
    --????
    v_dpt_cde         WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_expiration_type WEB_FIN_SAVEAMT_DUE.c_expiration_type%TYPE;
    v_cur_cde         WEB_FIN_SAVEAMT_DUE.C_BS_CUR%TYPE;
    v_batch_no        WEB_FIN_SAVEAMT_DUE.c_batch_no%TYPE;
    v_bala_mrk        WEB_FIN_SAVEAMT_DUE.c_bala_mrk%TYPE;
    v_err_content     WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;

    --??(?????????????) ???????????????????????
    CURSOR cur_ifclmInfo IS
      SELECT a.c_dpt_cde, a.C_BS_CUR
        FROM WEB_FIN_SAVEAMT_DUE a, WEB_ORG_DPT b
       WHERE a.c_dpt_cde = b.c_dpt_cde
         AND a.N_BS_AMT > 0
         AND a.N_OTHER_AMT > 0
         AND a.c_batch_no IS NULL
         AND a.n_paid_amt = 0
         AND LENGTH(b.c_dpt_cde) = 8
         AND b.c_company_cde <> '?'
         AND b.c_department_cde <> '?'
         AND a.N_BS_AMT <> 0
         AND a.c_bala_mrk = '1'
         AND b.c_company_cde IS NOT NULL
         AND b.c_department_cde IS NOT NULL
         AND not exists
       (SELECT 1
                FROM web_fin_tmpbigsave_due
               where c_ply_no = a.c_ply_no)
         AND a.t_crt_tm >=
             TO_DATE('2008-10-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
      --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS')
       GROUP BY a.c_dpt_cde, a.C_BS_CUR;

  BEGIN

    OPEN cur_ifclmInfo;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifclmInfo
        INTO v_dpt_cde, v_cur_cde;
      EXIT WHEN cur_ifclmInfo%NOTFOUND;

      --?????
      Dz_Proc.get_fin_no(v_batch_no, v_dpt_cde, '7', dz_proc.g_pttype);

      UPDATE WEB_FIN_SAVEAMT_DUE a
         SET c_batch_no = v_batch_no
       WHERE a.N_BS_AMT > 0
         AND a.N_OTHER_AMT > 0
         AND a.c_batch_no IS NULL
         AND a.n_paid_amt = 0
         AND a.N_BS_AMT <> 0
         AND a.c_bala_mrk = '1'
         AND a.c_dpt_cde = v_dpt_cde
         and a.C_BS_CUR = v_cur_cde
         AND not exists
       (SELECT 1
                FROM web_fin_tmpbigsave_due
               where c_ply_no = a.c_ply_no)
         AND t_crt_tm >=
             TO_DATE('2008-10-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
      --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS');
      commit;
    END LOOP;
    CLOSE cur_ifclmInfo;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_dpt_cde ||
                             v_expiration_type || v_cur_cde || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[DividendGather],??????[' || v_dpt_cde ||
                         v_expiration_type || v_cur_cde || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  Procedure DividendCavSave IS
    -- ?????????
    /*
        1.??????????
        2.??????

        ?????

    */
    v_dptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_dpt_cde    WEB_ORG_DPT.c_dpt_cde%TYPE;

    v_prod_no   WEB_FIN_PRM_DUE.c_prod_no%TYPE;
    v_pre_sum   WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_edr_type  WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
    v_edr_no    WEB_FIN_PRM_DUE.c_edr_no%TYPE;
    v_ply_no    WEB_FIN_PRM_DUE.c_ply_no%TYPE;
    v_DUE_TM    WEB_FIN_PRM_DUE.T_DUE_TM%TYPE;
    v_today_tm  WEB_FIN_DCR.t_crt_tm%TYPE;
    v_cav_flag  WEB_FIN_DCR.c_cav_flag%TYPE;
    v_cnt       INT;
    v_tmpcnt    INT;
    v_sbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_memo WEB_FIN_MADCR.c_sbjt_memo%TYPE;
    v_vou_memo  WEB_FIN_MADCR.c_vou_memo%TYPE;
    vTmpVouNo   WEB_FIN_MADCR.c_seq_no%TYPE;
    vTmpVouNo1  WEB_FIN_MADCR.c_seq_no%TYPE;

    vSbjtNo       WEB_FIN_DCR.c_sbjt_no%TYPE;
    vCavFlag      WEB_FIN_DCR.C_CAV_FLAG%TYPE;
    v_feetyp_cde  WEB_FIN_SAVEAMT_DUE.c_feetyp_cde%TYPE;
    v_tran_flag   WEB_FIN_PAY_DUE.c_tran_flag%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_seq_no      WEB_FIN_DCR.c_seq_no%TYPE;
    v_item_no     WEB_FIN_DCR.C_ITEM_NO%TYPE;
    vToday        VARCHAR(10);
    vBillToday    VARCHAR(10);

    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;

    v_drcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_drsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_crsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_voucher_no  WEB_FIN_DCR.c_voucher_no%TYPE;
    v_period_name WEB_FIN_DCR.c_period_name%TYPE;
    v_rcpt_no     WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;

    v_cur_no          WEB_FIN_CAV_BILL.C_CUR_CDE%TYPE;
    v_sum_amt         WEB_FIN_CAV_BILL.n_sum_amt%TYPE;
    v_total_amt       WEB_FIN_DCR.n_total_amt%TYPE;
    v_expiration_type WEB_FIN_SAVEAMT_DUE.c_expiration_type%TYPE;
    v_nitem_no        INT;
    v_fack_pk         INT;
    v_bala_mrk        WEB_FIN_SAVEAMT_DUE.c_bala_mrk%TYPE;
    v_batch_no        WEB_FIN_SAVEAMT_DUE.c_batch_no%TYPE;
    v_rp_type         web_fin_dcr_intf.c_rp_type%TYPE;
    v_amt             web_fin_dcr_intf.n_amt%TYPE;
    v_succsflag       INT;
    V_OTHER_AMT       WEB_FIN_SAVEAMT_DUE.N_OTHER_AMT%TYPE;
    v_singleother_amt WEB_FIN_SAVEAMT_DUE.N_OTHER_AMT%TYPE;

    v_returnflag INT;
    /*???????*/
    CURSOR cur_gather IS
      SELECT DISTINCT c_batch_no, c_dpt_cde
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_batch_no IS NOT NULL
         and c_bala_mrk = '1'
         AND N_BS_AMT > 0
         AND N_OTHER_AMT > 0
         AND t_crt_tm >=
             TO_DATE('2008-10-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         AND n_paid_amt = 0;

    CURSOR cur_ifclmInfo IS
      SELECT c_dpt_cde,
             c_prod_no,
             c_ply_no,
             N_BS_AMT,
             T_DUE_TM,
             c_rcpt_no,
             C_BS_CUR,
             c_expiration_type,
             c_bala_mrk,
             n_other_amt
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_batch_no = v_batch_no
         and c_bala_mrk = '1'
         AND c_batch_no IS NOT NULL
         AND N_BS_AMT > 0
         AND N_OTHER_AMT > 0;

    --??
    CURSOR cur_gatherrcpt IS
      SELECT c_cav_flag,
             c_sbjt_no,
             c_cur_no,
             c_dpt_cde,
             c_kind_no,
             SUM(n_amt),
             C_DPTACC_NO,
             c_vou_memo,
             c_company_cde,
             c_servicetype_no,
             c_rp_type,
             C_ITEM_NO
        FROM WEB_FIN_DCR
       WHERE c_seq_no = vTmpVouNo
         AND c_rcpt_no IS NOT NULL
       GROUP BY c_cav_flag,
                c_sbjt_no,
                c_cur_no,
                c_dpt_cde,
                c_kind_no,
                C_DPTACC_NO,
                c_vou_memo,
                c_company_cde,
                c_servicetype_no,
                c_rp_type,
                C_ITEM_NO;

    CURSOR cur_gatherpay IS
      SELECT SUM(N_sum_AMT), c_feetyp_cde
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_batch_no = v_batch_no
         and c_bala_mrk = '1'
         AND c_batch_no IS NOT NULL
         AND N_BS_AMT > 0
         AND N_OTHER_AMT > 0
       Group by c_feetyp_cde;

    CURSOR cur_calfee IS
      SELECT c_rcpt_no FROM WEB_FIN_CAV_DOC WHERE C_CAV_PK_ID = vTmpVouNo;

    v_tmp_cnt  INT;
    v_end_time WEB_FIN_SAVEAMT_DUE.t_crt_tm%TYPE;

  BEGIN
    v_fack_pk := 10000; --wpc
    OPEN cur_gather;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_gather
        INTO v_batch_no, v_dpt_cde;
      EXIT WHEN cur_gather%NOTFOUND;

      SELECT c_dptacc_cde
        INTO v_dptacc_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = v_dpt_cde;

      SELECT SUM(N_SUM_AMT), SUM(N_OTHER_AMT)
        INTO v_total_amt, v_other_amt
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_batch_no = v_batch_no
         and c_bala_mrk = '1'
         AND c_batch_no IS NOT NULL
         AND N_BS_AMT > 0
         AND N_OTHER_AMT > 0;

      SELECT C_PERIOD_NAME
        INTO v_period_name
        FROM WEB_FIN_MONTHLYCLOSING --??
       WHERE c_dptacc_cde = v_dptacc_cde
         AND c_closing_flag = '1'; --??

      SELECT TRUNC(T_END_TM)
        INTO v_end_time
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = v_period_name;

      --???????????
      IF TO_CHAR(SYSDATE, 'YYYY-MM') <> v_period_name THEN
        v_today_tm := v_end_time;
      ELSE
        v_today_tm := SYSDATE;
      END IF;

      v_nitem_no := 1;

      --??
      OPEN cur_ifclmInfo;
      LOOP
        FETCH cur_ifclmInfo
          INTO v_dpt_cde, v_prod_no, v_ply_no, v_pre_sum, v_DUE_TM, v_rcpt_no, v_cur_no, v_expiration_type, v_bala_mrk, v_singleother_amt;
        EXIT WHEN cur_ifclmInfo%NOTFOUND;

        SELECT c_department_cde, c_company_cde, c_dptacc_cde
          INTO v_department_cde, v_company_cde, v_dptacc_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = v_dpt_cde;
        /*
        1????
          DR????????????/??????(217101)
              ??????(214401)
          CR?????/??????(119302)
        2?????
          DR????????????/??????(217101)
             ??????(214401)
          CR?????/??????(119303)

        */
        v_drsbjt_no      := '217101';
        v_vou_memo       := '???????';
        v_servicetype_no := '1112';
        v_rp_type        := '202';

        --?????
        --Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7');
        vTmpVouNo := v_batch_no;
        SELECT c_kind_no
          INTO v_kind_no
          FROM WEB_BAS_FIN_PROD
         WHERE c_prod_no = v_prod_no;

        v_drcav_flag := '?';
        v_crcav_flag := '?';

        IF v_nitem_no = '1' THEN
          v_period_name := TO_CHAR(v_today_tm, 'yyyy-mm');
          Dz_Proc.get_fin_voucode(v_voucher_no,
                                  v_period_name,
                                  v_company_cde,
                                  dz_proc.g_pttype);
          --?????
          INSERT INTO WEB_FIN_CAV_BILL
            (c_dpt_cde,
             c_crt_cde,
             c_upd_cde,
             c_rp_type,
             C_CUR_CDE,
             n_sum_amt,
             c_oper_cde,
             T_CAV_TM,
             T_CRT_TM,
             t_upd_tm,
             C_CAV_PK_ID,
             c_check_cde,
             T_CHECK_TM,
             c_check_memo,
             c_check_flag,
             C_MULTICAV_FLAG)
          VALUES
            (v_dptacc_cde,
             'admin',
             'admin',
             v_rp_type,
             v_cur_no,
             v_total_amt,
             'admin',
             v_today_tm,
             v_today_tm,
             v_today_tm,
             v_batch_no,
             'admin',
             v_today_tm,
             '??',
             '2',
             '1');
          /*??????*/
          /*wpc begin  WEB_FIN_CAV_BILL ?WEB_FIN_RPTYP???*/
          INSERT INTO WEB_FIN_CAV_RPTYP
            (C_CAVRPTYP_PK_ID,
             C_CAV_PK_ID,
             N_ITEM_NO,
             C_RP_TYPE,
             C_CUR_CDE,
             N_SUM_AMT,
             C_REPLACE_FLAG,
             C_CRT_CDE,
             T_CRT_TM,
             C_UPD_CDE,
             T_UPD_TM)
          VALUES
            (v_batch_no,
             v_batch_no,
             '1', --v_nitem_no,
             v_rp_type,
             v_cur_no,
             v_total_amt,
             '0',
             'admin',
             v_today_tm,
             'admin',
             v_today_tm);
          /* wpc end*/
          OPEN cur_gatherpay;
          LOOP
            FETCH cur_gatherpay
              INTO v_sum_amt, v_feetyp_cde;
            EXIT WHEN cur_gatherpay%NOTFOUND;

            if v_feetyp_cde = 'P' then
              v_crsbjt_no := '119303'; --????
            else
              v_crsbjt_no := '119302'; --????
            end if;
            --???????(??????)
            --IF v_bala_mrk='0' THEN
            v_fack_pk := v_fack_pk + 1;
            INSERT INTO WEB_FIN_CAV_OBJ
              (n_item_no,
               c_dpt_cde,
               c_sbjt_no,
               n_amt,
               c_crt_cde, --wpc
               T_CRT_TM, --wpc
               C_UPD_CDE, --wpc
               T_UPD_TM, --wpc
               c_prod_no,
               C_CAV_PK_ID,
               C_CUR_CDE,
               c_cav_dir,
               c_sls_cde,
               c_cha_cls,
               c_cha_cde,
               C_PAYER_NME,
               n_pre_amt,
               c_ocav_no,
               -- c_oitem_no,
               c_pre_flag,
               c_bsns_typ,
               C_CURT_DPT_CDE)
              SELECT v_nitem_no,
                     c_dpt_cde,
                     v_crsbjt_no,
                     v_sum_amt,
                     'admin', --wpc
                     v_today_tm, --wpc
                     'admin', --wpc
                     SYSDATE, --wpc
                     c_prod_no,
                     v_batch_no,
                     C_BS_CUR,
                     '2', --'??'
                     c_sls_cde,

                     c_cha_cls,
                     c_cha_cde,
                     'admin',
                     v_sum_amt,
                     v_batch_no,
                     -- '1',
                     '1',
                     c_bsns_typ,
                     NULL
                FROM WEB_FIN_SAVEAMT_DUE
               WHERE c_rcpt_no = v_rcpt_no
                 and c_bala_mrk = '1';

            INSERT INTO WEB_FIN_DCR
              (C_SEQ_NO,
               C_ITEM_NO,
               C_CAV_FLAG,
               c_sbjt_no,
               N_AMT,
               C_CUR_NO,
               T_CRT_TM,
               C_DPTACC_NO,
               C_SEND_FLAG,
               c_sbjt_memo,
               c_kind_no,
               c_department_cde,
               c_company_cde,
               c_period_name,
               c_vou_memo,
               c_voucher_no,
               c_vou_no,
               n_total_amt,
               C_CAV_NO,
               c_servicetype_no,
               c_rp_type)
              SELECT vTmpVouNo,
                     TO_CHAR(v_nitem_no),
                     v_crcav_flag,
                     v_crsbjt_no,
                     v_sum_amt,
                     c_bs_cur,
                     v_today_tm,
                     v_dptacc_cde,

                     '0',
                     v_sbjt_memo,
                     '0',
                     '0',
                     v_company_cde,
                     TO_CHAR(v_today_tm, 'YYYY-MM'),
                     v_vou_memo,
                     v_voucher_no,
                     v_voucher_no,
                     v_total_amt,
                     vTmpVouNo,
                     v_servicetype_no,
                     v_rp_type
                FROM WEB_FIN_SAVEAMT_DUE
               WHERE c_rcpt_no = v_rcpt_no
                 and c_bala_mrk = '1';

            v_nitem_no := v_nitem_no + 1;
          END LOOP;
          CLOSE cur_gatherpay;
          --ELSE -- ??
          /*
              INSERT INTO WEB_FIN_CAV_MNY--?????
              (
                C_CAV_PK_ID         ,
                n_item_no        ,
                C_BAL_TYP       ,
                n_amt            ,
                n_use_amt        ,
                c_cur_no         ,
                C_PAYER_NME       ,
                c_bank_cde       ,
                c_check_no       ,
                t_rp_tm          ,
                c_flow_cde        ,
                C_BANK_NME      ,
                c_bank_accnt     ,
                c_rp_name        ,
                c_feetyp_cde     ,
                c_sbjt_no        ,
                c_savecash_bank  ,
                t_savecash_tm    ,
                c_savecash_no    ,
                c_savecash_opt   ,
                c_formafee_no    ,
                c_check_flag
              )
              SELECT
                v_batch_no         ,
                '1'        ,
                '00200'          ,
                v_sum_amt            ,
                v_sum_amt        ,
                c_cur_cde         ,
                'admin',
                null       ,
                null       ,
                v_today_tm          ,
                null        ,
                null      ,
                null     ,
                SUBSTR(C_PAYER_NME,1,20)        ,
                null     ,
                '100102'        ,
                null  ,
                null    ,
                null    ,
                null   ,
                null    ,
                '0'
              FROM WEB_FIN_SAVEAMT_DUE
              WHERE c_rcpt_no=v_rcpt_no;
          */
          --END IF;

          v_crsbjt_no := '214401';
          v_fack_pk   := v_fack_pk + 1;
          INSERT INTO WEB_FIN_CAV_OBJ

            (C_CRT_CDE, --wpc
             c_upd_cde, --wpc
             t_crt_tm, --wpc
             t_upd_tm, --wpc
             C_CAV_PK_ID,
             n_item_no,
             c_sbjt_no,
             n_amt,
             C_CUR_CDE,
             c_cav_dir,
             c_dpt_cde,
             c_sls_cde,
             c_prod_no,
             c_cha_cls,
             c_cha_cde,
             C_PAYER_NME,
             n_pre_amt,

             --c_oitem_no,
             c_pre_flag,
             c_bsns_typ,
             C_CURT_DPT_CDE)
            SELECT 'admin', --wpc
                   'admin', --wpc
                   sysdate, --wpc
                   sysdate, --wpc
                   v_batch_no,
                   v_nitem_no,
                   '214401',
                   v_other_amt,
                   c_bs_cur,
                   '1', --'??',wpc
                   c_dpt_cde,
                   c_sls_cde,
                   c_prod_no,
                   c_cha_cls,
                   c_cha_cde,
                   'admin',
                   v_sum_amt,

                   -- '1',
                   '1',
                   c_bsns_typ,
                   NULL
              FROM WEB_FIN_SAVEAMT_DUE
             WHERE c_rcpt_no = v_rcpt_no
               and c_bala_mrk = '1';

          INSERT INTO WEB_FIN_DCR
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             c_sbjt_no,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_SEND_FLAG,
             c_sbjt_memo,
             c_kind_no,
             c_department_cde,
             c_company_cde,
             c_period_name,
             c_vou_memo,
             c_voucher_no,
             c_vou_no,
             n_total_amt,
             C_CAV_NO,
             c_servicetype_no,
             c_rp_type)
            SELECT vTmpVouNo,
                   TO_CHAR(v_nitem_no),
                   v_drcav_flag,
                   '214401',
                   v_other_amt,
                   c_bs_cur,
                   v_today_tm,
                   v_dptacc_cde,

                   '0',
                   v_sbjt_memo,
                   '0',
                   '0',
                   v_company_cde,
                   TO_CHAR(v_today_tm, 'YYYY-MM'),
                   v_vou_memo,
                   v_voucher_no,
                   v_voucher_no,
                   v_total_amt,
                   vTmpVouNo,
                   v_servicetype_no,
                   v_rp_type
              FROM WEB_FIN_SAVEAMT_DUE
             WHERE c_rcpt_no = v_rcpt_no
               and c_bala_mrk = '1';
        END IF;

        v_nitem_no := v_nitem_no + 1;

        --??????
        INSERT INTO WEB_FIN_CAV_DOC
          (c_bill_flag, --wpc
           N_RP_PRM, --wpc
           t_crt_tm, --wpc
           t_upd_tm, --wpc
           N_ORIG_CUR_AMT, --wpc
           N_ORIG_PRM, --WPC
           C_CRT_CDE, --wpc
           C_UPD_CDE, --wpc
           n_item_no,
           C_CAV_PK_ID,
           c_rcpt_no,
           c_ply_no,
           c_edr_no,
           --C_BS_CUR,
           --N_DUE_AMT,
           n_exch_rate,
           N_SUM_AMT,
           --  n_exchgot_prm,
           t_insrnc_bgn_tm,
           t_insrnc_end_tm,
           c_prod_no,
           c_sls_cde,
           c_cha_cls,
           c_cha_cde,
           C_PAYER_CDE,
           c_dpt_cde,
           c_feetyp_cde,
           C_SLSGRP_CDE,
           c_bsns_typ,
           C_PAYER_NME,
           C_BS_CUR,
           N_BS_AMT,
           c_rp_cur,
           n_rp_amt)
          SELECT '4', --wpc
                 n_rp_amt, --wpc
                 sysdate, --wpc
                 sysdate, --wpc
                 (N_BS_AMT), --wpc
                 (N_BS_AMT), --wpc
                 'admin', --wpc
                 'admin', --wpc
                 v_nitem_no,
                 v_batch_no,
                 c_rcpt_no,
                 c_ply_no,
                 c_clm_no,
                 --  c_bs_cur,
                 --   - (N_BS_AMT - n_other_amt),
                 1,
                 - (N_BS_AMT),
                 --     - (N_BS_AMT),
                 t_insrnc_bgn_tm,
                 t_insrnc_end_tm,
                 c_prod_no,
                 NULL,
                 NULL,
                 NULL,
                 NULL,
                 c_dpt_cde,
                 NULL,
                 NULL,
                 c_bsns_typ,
                 ' ',
                 c_bs_cur,
                 - (N_BS_AMT),
                 c_bs_cur,
                 - (N_BS_AMT)
            FROM WEB_FIN_SAVEAMT_DUE
           WHERE c_rcpt_no = v_rcpt_no
             and c_bala_mrk = '1';

        INSERT INTO WEB_FIN_DCR
          (C_SEQ_NO,
           C_ITEM_NO,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           C_DPTACC_NO,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_ply_no,
           c_cha_mrk,
           c_vou_memo,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde,
           c_sbjt_memo,
           c_period_name,
           c_voucher_no,
           n_total_amt,
           C_CAV_NO,
           c_rp_type)
          SELECT vTmpVouNo,
                 TO_CHAR(v_nitem_no),
                 v_drcav_flag,
                 v_drsbjt_no,
                 v_pre_sum,
                 c_bs_cur,
                 v_today_tm,
                 v_dptacc_cde,
                 c_dpt_cde,
                 c_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 NULL,
                 NULL,
                 NULL,
                 v_voucher_no,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 c_ply_no,
                 c_cha_mrk,
                 v_vou_memo,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde,
                 '0',
                 TO_CHAR(v_today_tm, 'YYYY-MM'),
                 v_voucher_no,
                 v_total_amt,
                 vTmpVouNo,
                 v_rp_type
            FROM WEB_FIN_SAVEAMT_DUE
           WHERE c_rcpt_no = v_rcpt_no
             and c_bala_mrk = '1';

      END LOOP;
      CLOSE cur_ifclmInfo;

      IF v_nitem_no <> 1 THEN
        v_nitem_no := 1;
        --?????
        --????????
        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           C_BAL_TYPE,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           C_SALEGRP_CDE,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_department_cde,
           c_rcpt_no,
           C_CAV_NO)
          SELECT c_seq_no,
                 '1',
                 c_cav_flag,
                 '100101', --wpc
                 --(SELECT c_finsbjt_no
                 -- FROM WEB_BAS_FIN_SUBJECT
                 --WHERE c_sbjt_no = WEB_FIN_DCR.c_sbjt_no),
                 '0',
                 n_amt,
                 n_exch_amt,
                 DECODE(c_cur_no,
                        '01',
                        'CNY',
                        '02',
                        'HKD',
                        '03',
                        'USD',
                        '12',
                        'EUR',
                        '13',
                        'EUR',
                        '05',
                        'JPY',
                        c_cur_no),
                 n_rate,
                 c_chr_cur_no,
                 t_crt_tm,
                 C_DPTACC_NO,
                 C_FLOW_NO,
                 v_rp_type,
                 c_ri_com,
                 C_BAL_TYPE,
                 NULL,
                 c_check_no,
                 t_rp_tm,
                 c_kind_no,
                 '0',
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 C_SALEGRP_CDE, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 c_voucher_no,
                 c_period_name,
                 v_total_amt,
                 v_servicetype_no,
                 c_department_cde,
                 c_rcpt_no,
                 vTmpVouNo
            FROM WEB_FIN_DCR
           WHERE c_seq_no = vTmpVouNo
             AND C_ITEM_NO = '1';

        v_nitem_no := v_nitem_no + 1;

        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           C_BAL_TYPE,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           C_SALEGRP_CDE,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_department_cde,
           c_rcpt_no,
           C_CAV_NO)
          SELECT c_seq_no,
                 '2',
                 c_cav_flag,
                 (SELECT c_finsbjt_no
                    FROM WEB_BAS_FIN_SUBJECT
                   WHERE c_sbjt_no = WEB_FIN_DCR.c_sbjt_no),
                 '0',
                 n_amt,
                 n_exch_amt,
                 DECODE(c_cur_no,
                        '01',
                        'CNY',
                        '02',
                        'HKD',
                        '03',
                        'USD',
                        '12',
                        'EUR',
                        '13',
                        'EUR',
                        '05',
                        'JPY',
                        c_cur_no),
                 n_rate,
                 c_chr_cur_no,
                 t_crt_tm,
                 c_dptacc_no,
                 c_flow_no,
                 v_rp_type,
                 c_ri_com,
                 C_BAL_TYPE,
                 NULL,
                 c_check_no,
                 t_rp_tm,
                 c_kind_no,
                 '0',
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 C_SALEGRP_CDE, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 c_voucher_no,
                 c_period_name,
                 v_total_amt,
                 v_servicetype_no,
                 c_department_cde,
                 c_rcpt_no,
                 vTmpVouNo
            FROM WEB_FIN_DCR
           WHERE c_seq_no = vTmpVouNo
             AND c_item_no = '2';

        UPDATE WEB_FIN_DCR --???????
           SET c_voucher_no = v_voucher_no, c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        UPDATE web_fin_dcr_intf --?????
           SET c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        --????
        v_nitem_no := v_nitem_no + 1;
        -- v_nitem_no := 2;
        OPEN cur_gatherrcpt;
        LOOP
          <<GOTO_LAB>>
          FETCH cur_gatherrcpt
            INTO v_cav_flag, v_sbjt_no, v_cur_no, v_dpt_cde, v_kind_no, v_amt, v_dptacc_cde, v_vou_memo, v_company_cde, v_servicetype_no, v_rp_type, v_item_no;
          EXIT WHEN cur_gatherrcpt%NOTFOUND;

          IF to_number(v_item_no, 0) <> v_nitem_no THEN

            INSERT INTO web_fin_dcr_intf
              (c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               c_sbjt_memo,
               n_amt,
               n_exch_amt,
               c_cur_no,
               n_rate,
               c_chr_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_flow_no,
               c_rp_type,
               c_ri_com,
               C_BAL_TYPE,
               c_bank_cde,
               c_check_no,
               t_rp_tm,
               c_prod_no,
               c_send_flag,
               c_cont_code,
               c_dpt_cde,
               c_vou_memo,
               c_con_dpt_cde,
               c_cost_cde,
               c_company_cde,
               C_SALEGRP_CDE,
               c_bsns_typ,
               c_cha_mrk,
               c_vou_no,
               c_period_name,
               n_total_amt,
               c_servicetype_no,
               c_department_cde,
               c_rcpt_no,
               C_CAV_NO)
              SELECT c_seq_no,
                     '3',
                     c_cav_flag,
                     (SELECT c_finsbjt_no
                        FROM WEB_BAS_FIN_SUBJECT
                       WHERE c_sbjt_no = WEB_FIN_DCR.c_sbjt_no),
                     '0',
                     n_amt,
                     n_exch_amt,
                     DECODE(c_cur_no,
                            '01',
                            'CNY',
                            '02',
                            'HKD',
                            '03',
                            'USD',
                            '12',
                            'EUR',
                            '13',
                            'EUR',
                            '05',
                            'JPY',
                            c_cur_no),
                     n_rate,
                     c_chr_cur_no,
                     t_crt_tm,
                     c_dptacc_no,
                     c_flow_no,
                     v_rp_type,
                     c_ri_com,
                     C_BAL_TYPE,
                     NULL,
                     c_check_no,
                     t_rp_tm,
                     c_kind_no,
                     '0',
                     c_cont_code,
                     c_dpt_cde,
                     c_vou_memo,
                     c_con_dpt_cde,
                     c_cost_cde,
                     c_company_cde,
                     C_SALEGRP_CDE, /*c_bsns_typ*/
                     '0',
                     c_cha_mrk,
                     c_voucher_no,
                     c_period_name,
                     v_total_amt,
                     v_servicetype_no,
                     c_department_cde,
                     c_rcpt_no,
                     vTmpVouNo
                FROM WEB_FIN_DCR
               WHERE c_seq_no = vTmpVouNo
                 AND c_item_no = '3';
            v_nitem_no := v_nitem_no + 1;
          END IF;

          SELECT c_department_cde
            INTO v_department_cde
            FROM WEB_ORG_DPT
           WHERE c_dpt_cde = v_dpt_cde;

          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_flow_no,
             c_rp_type,
             c_ri_com,
             C_BAL_TYPE,
             c_bank_cde,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             C_SALEGRP_CDE,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_department_cde,
             c_rcpt_no,
             C_CAV_NO)
          VALUES
            (vTmpVouNo,
             TO_CHAR(v_nitem_no),
             v_cav_flag,
             v_sbjt_no,
             '0',
             v_amt,
             v_amt,
             DECODE(v_cur_no,
                    '01',
                    'CNY',
                    '02',
                    'HKD',
                    '03',
                    'USD',
                    '12',
                    'EUR',
                    '13',
                    'EUR',
                    '05',
                    'JPY',
                    v_cur_no),
             1,
             NULL,
             v_today_tm,
             v_dptacc_cde,
             NULL,
             v_rp_type,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             v_kind_no,
             '0',
             NULL,
             v_dpt_cde,
             v_vou_memo,
             NULL,
             NULL,
             v_company_cde,
             NULL, /*c_bsns_typ*/
             '0',
             NULL,
             v_voucher_no,
             TO_CHAR(v_today_tm, 'YYYY-MM'),
             v_total_amt,
             v_servicetype_no,
             v_department_cde,
             NULL,
             vTmpVouNo);
          v_nitem_no := v_nitem_no + 1;
        END LOOP;
        CLOSE cur_gatherrcpt;

      END IF;

      UPDATE WEB_FIN_SAVEAMT_DUE --??????
         SET N_RP_AMT     = N_BS_AMT,
             n_paid_amt   = N_BS_AMT,
             T_PAID_TM    = v_today_tm,
             T_RP_TM      = v_today_tm,
             c_accnt_flag = DECODE(c_accnt_flag,
                                   '01',
                                   '11',
                                   '00',
                                   '10',
                                   '10')
       WHERE c_batch_no = v_batch_no
         and c_bala_mrk = '1'
         AND N_BS_AMT > 0
         AND N_OTHER_AMT > 0
         AND n_paid_amt = 0;

      OPEN cur_calfee;
      LOOP
        FETCH cur_calfee
          INTO v_rcpt_no;
        EXIT WHEN cur_calfee%NOTFOUND;

        -- Collectfu.Producecost(v_rcpt_no,'0',v_returnflag);
        v_returnflag := 1;
        IF v_returnflag < 0 THEN
          v_succsflag := -4;
          rollback;
          RETURN;
        END IF;

      END LOOP;
      CLOSE cur_calfee;

      UPDATE web_fin_dcr_intf
         SET c_department_cde = v_department_cde, c_prod_no = '014'
       WHERE c_seq_no = vTmpVouNo
         and c_sbjt_no = '214401';

      UPDATE web_fin_dcr_intf --?????
         SET c_servicetype_no = '1112'
       WHERE c_seq_no = vTmpVouNo;

      CollectFu.ValidityCheckCavVou(v_voucher_no, v_succsflag); --??????????0?????????
      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[DividendCavSave ValidityCheckCavVou],??????[' ||
                         TO_CHAR(v_succsflag) || v_batch_no || v_dpt_cde ||
                         v_prod_no || v_cur_no ||
                         TO_CHAR(v_today_tm, 'YYYY-MM-DD') || v_dptacc_cde ||
                         v_vou_memo || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_gather;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        ROLLBACK;
        dbms_output.put_line('exception' || '*' || v_batch_no || SQLERRM);
        v_err_content := 'proc:[DividendCavSave],??????[' ||
                         v_batch_no || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  PROCEDURE OtherIncomeGather IS
    --??????????  ?????????????????? ?
    --????
    v_dpt_cde         WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_expiration_type WEB_FIN_SAVEAMT_DUE.c_expiration_type%TYPE;
    v_cur_cde         WEB_FIN_SAVEAMT_DUE.C_BS_CUR%TYPE;
    v_batch_no        WEB_FIN_SAVEAMT_DUE.c_batch_no%TYPE;
    v_bala_mrk        WEB_FIN_SAVEAMT_DUE.c_bala_mrk%TYPE;
    v_err_content     WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;

    --??(?????????????) ???????????????????????
    CURSOR cur_ifclmInfo IS
      SELECT a.c_dpt_cde, a.C_BS_CUR
        FROM WEB_FIN_SAVEAMT_DUE a, WEB_ORG_DPT b
       WHERE a.c_dpt_cde = b.c_dpt_cde
         AND a.N_BS_AMT > 0
         AND a.N_OTHER_AMT <= 0
         AND a.c_batch_no IS NULL
         AND a.n_paid_amt = 0
         AND LENGTH(b.c_dpt_cde) = 8
         AND b.c_company_cde <> '?'
         AND b.c_department_cde <> '?'
         AND a.N_BS_AMT <> 0
         and a.c_bala_mrk = '1'
         AND b.c_company_cde IS NOT NULL
         AND b.c_department_cde IS NOT NULL
         AND not exists
       (SELECT 1
                FROM web_fin_tmpbigsave_due
               where c_ply_no = a.c_ply_no)
         AND a.t_crt_tm >=
             TO_DATE('2008-10-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
      --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS')
       GROUP BY a.c_dpt_cde, a.C_BS_CUR;

  BEGIN

    OPEN cur_ifclmInfo;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifclmInfo
        INTO v_dpt_cde, v_cur_cde;
      EXIT WHEN cur_ifclmInfo%NOTFOUND;

      --?????
      Dz_Proc.get_fin_no(v_batch_no, v_dpt_cde, '7', dz_proc.g_pttype);

      UPDATE WEB_FIN_SAVEAMT_DUE a
         SET c_batch_no = v_batch_no
       WHERE a.N_BS_AMT > 0
         AND a.N_OTHER_AMT <= 0
         AND a.c_batch_no IS NULL
         AND a.n_paid_amt = 0
         AND a.N_BS_AMT <> 0
         and a.c_bala_mrk = '1'
         AND a.c_dpt_cde = v_dpt_cde
         and a.C_BS_CUR = v_cur_cde
         AND not exists
       (SELECT 1
                FROM web_fin_tmpbigsave_due
               where c_ply_no = a.c_ply_no)
         AND a.t_crt_tm >=
             TO_DATE('2008-10-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
      --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS');
      commit;
    END LOOP;
    CLOSE cur_ifclmInfo;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_dpt_cde ||
                             v_expiration_type || v_cur_cde || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[OtherIncomeGather],??????[' ||
                         v_dpt_cde || v_expiration_type || v_cur_cde ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;
  Procedure OtherIncomeCavSave IS
    -- ???????????
    /*
        1.??????????
        2.??????
        ?????

    */
    v_dptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_dpt_cde    WEB_ORG_DPT.c_dpt_cde%TYPE;

    v_prod_no   WEB_FIN_PRM_DUE.c_prod_no%TYPE;
    v_pre_sum   WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_edr_type  WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
    v_edr_no    WEB_FIN_PRM_DUE.c_edr_no%TYPE;
    v_ply_no    WEB_FIN_PRM_DUE.c_ply_no%TYPE;
    v_DUE_TM    WEB_FIN_PRM_DUE.T_DUE_TM%TYPE;
    v_today_tm  WEB_FIN_DCR.t_crt_tm%TYPE;
    v_cav_flag  WEB_FIN_DCR.c_cav_flag%TYPE;
    v_cnt       INT;
    v_tmpcnt    INT;
    v_sbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_memo WEB_FIN_MADCR.c_sbjt_memo%TYPE;
    v_vou_memo  WEB_FIN_MADCR.c_vou_memo%TYPE;
    vTmpVouNo   WEB_FIN_MADCR.c_seq_no%TYPE;
    vTmpVouNo1  WEB_FIN_MADCR.c_seq_no%TYPE;

    vSbjtNo       WEB_FIN_DCR.c_sbjt_no%TYPE;
    vCavFlag      WEB_FIN_DCR.C_CAV_FLAG%TYPE;
    v_feetyp_cde  WEB_FIN_PAY_DUE.c_feetyp_cde%TYPE;
    v_tran_flag   WEB_FIN_PAY_DUE.c_tran_flag%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_seq_no      WEB_FIN_DCR.c_seq_no%TYPE;
    v_item_no     WEB_FIN_DCR.c_item_no%TYPE;

    vToday     VARCHAR(10);
    vBillToday VARCHAR(10);

    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;

    v_drcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_drsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_crsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_voucher_no  WEB_FIN_DCR.c_voucher_no%TYPE;
    v_period_name WEB_FIN_DCR.c_period_name%TYPE;
    v_rcpt_no     WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;

    v_cur_no          WEB_FIN_CAV_BILL.C_CUR_CDE%TYPE;
    v_sum_amt         WEB_FIN_CAV_BILL.n_sum_amt%TYPE;
    v_expiration_type WEB_FIN_SAVEAMT_DUE.c_expiration_type%TYPE;
    v_nitem_no        INT;

    v_bala_mrk        WEB_FIN_SAVEAMT_DUE.c_bala_mrk%TYPE;
    v_batch_no        WEB_FIN_SAVEAMT_DUE.c_batch_no%TYPE;
    v_rp_type         web_fin_dcr_intf.c_rp_type%TYPE;
    v_amt             web_fin_dcr_intf.n_amt%TYPE;
    v_succsflag       INT;
    V_OTHER_AMT       WEB_FIN_SAVEAMT_DUE.N_OTHER_AMT%TYPE;
    v_singleother_amt WEB_FIN_SAVEAMT_DUE.N_OTHER_AMT%TYPE;

    v_returnflag INT;

    CURSOR cur_gather IS
      SELECT DISTINCT c_batch_no, c_dpt_cde
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_batch_no IS NOT NULL
         and c_bala_mrk = '1'
         AND N_BS_AMT > 0
         AND N_OTHER_AMT <= 0
            --     and c_batch_no='200906150200014017000002'
         AND n_paid_amt = 0;

    CURSOR cur_ifclmInfo IS
      SELECT c_dpt_cde,
             c_prod_no,
             c_ply_no,
             N_BS_AMT,
             T_DUE_TM,
             c_rcpt_no,
             c_bs_cur,
             c_expiration_type,
             c_bala_mrk,
             n_other_amt
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_batch_no = v_batch_no
         and c_bala_mrk = '1'
         AND c_batch_no IS NOT NULL
         AND N_BS_AMT > 0
         AND N_OTHER_AMT <= 0;

    --??
    CURSOR cur_gatherrcpt IS
      SELECT c_cav_flag,
             c_sbjt_no,
             c_cur_no,
             c_dpt_cde,
             c_kind_no,
             SUM(n_amt),
             c_dptacc_no,
             c_vou_memo,
             c_company_cde,
             c_servicetype_no,
             c_rp_type
        FROM WEB_FIN_DCR
       WHERE c_seq_no = vTmpVouNo
         AND c_rcpt_no IS NOT NULL
       GROUP BY c_cav_flag,
                c_sbjt_no,
                c_cur_no,
                c_dpt_cde,
                c_kind_no,
                c_dptacc_no,
                c_vou_memo,
                c_company_cde,
                c_servicetype_no,
                c_rp_type;

    CURSOR cur_calfee IS
      SELECT c_rcpt_no FROM WEB_FIN_CAV_DOC WHERE C_CAV_PK_ID = vTmpVouNo;

    v_tmp_cnt  INT;
    v_end_time WEB_FIN_SAVEAMT_DUE.t_crt_tm%TYPE;

  BEGIN

    OPEN cur_gather;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_gather
        INTO v_batch_no, v_dpt_cde;
      EXIT WHEN cur_gather%NOTFOUND;

      SELECT SUM(N_sum_AMT), SUM(N_OTHER_AMT)
        INTO v_sum_amt, v_other_amt
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_batch_no = v_batch_no
         and c_bala_mrk = '1'
         AND c_batch_no IS NOT NULL
         AND N_BS_AMT > 0
         AND N_OTHER_AMT <= 0;

      SELECT c_dptacc_cde
        INTO v_dptacc_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = v_dpt_cde;

      SELECT C_PERIOD_NAME
        INTO v_period_name
        FROM WEB_FIN_MONTHLYCLOSING
       WHERE c_dptacc_cde = v_dptacc_cde
         AND c_closing_flag = '1'; --??

      SELECT TRUNC(t_end_tm)
        INTO v_end_time
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = v_period_name;

      --???????????
      IF TO_CHAR(SYSDATE, 'YYYY-MM') <> v_period_name THEN
        v_today_tm := v_end_time;
      ELSE
        v_today_tm := SYSDATE;
      END IF;

      IF v_other_amt = 0 THEN
        v_nitem_no := 2;
      ELSE
        v_nitem_no := 3;
      END IF;

      --??
      OPEN cur_ifclmInfo;
      LOOP
        FETCH cur_ifclmInfo
          INTO v_dpt_cde, v_prod_no, v_ply_no, v_pre_sum, v_DUE_TM, v_rcpt_no, v_cur_no, v_expiration_type, v_bala_mrk, v_singleother_amt;
        EXIT WHEN cur_ifclmInfo%NOTFOUND;

        SELECT c_department_cde, c_company_cde, c_dptacc_cde
          INTO v_department_cde, v_company_cde, v_dptacc_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = v_dpt_cde;

        --??????
        --??????
        INSERT INTO WEB_FIN_CAV_DOC
          (c_bill_flag, --wpc
           N_RP_PRM, --wpc
           t_crt_tm, --wpc
           t_upd_tm, --wpc
           N_ORIG_CUR_AMT, --wpc
           N_ORIG_PRM, --WPC
           C_CRT_CDE, --wpc
           C_UPD_CDE, --wpc
           n_item_no,
           C_CAV_PK_ID,
           c_rcpt_no,
           c_ply_no,
           c_edr_no,
           --C_BS_CUR,
           --N_DUE_AMT,
           n_exch_rate,
           N_SUM_AMT,
           --  n_exchgot_prm,
           t_insrnc_bgn_tm,
           t_insrnc_end_tm,
           c_prod_no,
           c_sls_cde,
           c_cha_cls,
           c_cha_cde,
           C_PAYER_CDE,
           c_dpt_cde,
           c_feetyp_cde,
           C_SLSGRP_CDE,
           c_bsns_typ,
           C_PAYER_NME,
           C_BS_CUR,
           N_BS_AMT,
           c_rp_cur,
           n_rp_amt)
          SELECT '4', --wpc
                 n_rp_amt, --wpc
                 sysdate, --wpc
                 sysdate, --wpc
                 (N_BS_AMT), --wpc
                 (N_BS_AMT), --wpc
                 'admin', --wpc
                 'admin', --wpc
                 v_nitem_no,
                 v_batch_no,
                 c_rcpt_no,
                 c_ply_no,
                 c_clm_no,
                 --  c_bs_cur,
                 --   - (N_BS_AMT - n_other_amt),
                 1,
                 - (N_BS_AMT),
                 --     - (N_BS_AMT),
                 t_insrnc_bgn_tm,
                 t_insrnc_end_tm,
                 c_prod_no,
                 NULL,
                 NULL,
                 NULL,
                 NULL,
                 c_dpt_cde,
                 NULL,
                 NULL,
                 c_bsns_typ,
                 ' ',
                 c_bs_cur,
                 - (N_BS_AMT),
                 c_bs_cur,
                 - (N_BS_AMT)
            FROM WEB_FIN_SAVEAMT_DUE
           WHERE c_rcpt_no = v_rcpt_no
             and c_bala_mrk = '1';

        --?????
        --Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7');
        vTmpVouNo := v_batch_no;
        SELECT c_kind_no
          INTO v_kind_no
          FROM WEB_BAS_FIN_PROD
         WHERE c_prod_no = v_prod_no;

        v_drcav_flag := '?';
        v_crcav_flag := '?';

        /*
         1????????
            DR????????????/??????(217101)
            CR?????/??????(119302)

         2??????????????
            DR????????????/??????(217101)
            CR?????/??????(119302)
                ????/??????(410905)
        */
        v_drsbjt_no      := '217101';
        v_vou_memo       := '???????';
        v_servicetype_no := '1112';
        v_rp_type        := '202';

        v_crsbjt_no := '119302'; --??
        INSERT INTO WEB_FIN_DCR
          (C_SEQ_NO,
           c_item_no,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           c_dptacc_no,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_ply_no,
           c_cha_mrk,
           c_vou_memo,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde,
           c_sbjt_memo,
           c_period_name,
           c_voucher_no,
           n_total_amt,
           C_CAV_NO,
           c_rp_type)
          SELECT vTmpVouNo,
                 TO_CHAR(v_nitem_no),
                 v_drcav_flag,
                 v_drsbjt_no,
                 v_pre_sum,
                 c_bs_cur,
                 v_today_tm,
                 v_dptacc_cde,
                 c_dpt_cde,
                 c_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 NULL,
                 NULL,
                 NULL,
                 v_voucher_no,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 c_ply_no,
                 c_cha_mrk,
                 v_vou_memo,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde,
                 '0',
                 TO_CHAR(v_today_tm, 'YYYY-MM'),
                 v_voucher_no,
                 v_sum_amt,
                 vTmpVouNo,
                 v_rp_type
            FROM WEB_FIN_SAVEAMT_DUE
           WHERE c_rcpt_no = v_rcpt_no
             and c_bala_mrk = '1';

        IF (v_other_amt = 0 and v_nitem_no = '2') or
           (v_other_amt <> 0 and v_nitem_no = '3') THEN
          v_period_name := TO_CHAR(v_today_tm, 'yyyy-mm');
          Dz_Proc.get_fin_voucode(v_voucher_no,
                                  v_period_name,
                                  v_company_cde,
                                  dz_proc.g_pttype);

          --?????
          INSERT INTO WEB_FIN_CAV_BILL
            (c_dpt_cde,
             c_crt_cde,
             c_upd_cde,
             c_rp_type,
             C_CUR_CDE,
             n_sum_amt,
             c_oper_cde,
             T_CAV_TM,
             T_CRT_TM,
             t_upd_tm,
             C_CAV_PK_ID,
             c_check_cde,
             T_CHECK_TM,
             c_check_memo,
             c_check_flag)
          VALUES
            (v_dptacc_cde,
             'admin',
             'admin',
             v_rp_type,
             v_cur_no,
             v_sum_amt,
             'admin',
             v_today_tm,
             v_today_tm,
             v_today_tm,
             v_batch_no,
             'admin',
             v_today_tm,
             '??',
             '2');
          /*??????*/
          /*wpc begin  WEB_FIN_CAV_BILL ?WEB_FIN_RPTYP???*/
          INSERT INTO WEB_FIN_CAV_RPTYP
            (C_CAVRPTYP_PK_ID,
             C_CAV_PK_ID,
             N_ITEM_NO,
             C_RP_TYPE,
             C_CUR_CDE,
             N_SUM_AMT,
             C_REPLACE_FLAG,
             C_CRT_CDE,
             T_CRT_TM,
             C_UPD_CDE,
             T_UPD_TM)
          VALUES
            (v_batch_no,
             v_batch_no,
             '1', --v_nitem_no,
             v_rp_type,
             v_cur_no,
             v_sum_amt,
             '0',
             'admin',
             v_today_tm,
             'admin',
             v_today_tm);
          /* wpc end*/
          --???????(??????)
          --IF v_bala_mrk='0' THEN
          INSERT INTO WEB_FIN_CAV_OBJ

            (c_crt_cde, --wpc
             T_CRT_TM, --wpc
             C_UPD_CDE, --wpc
             T_UPD_TM, --wpc
             C_CAV_PK_ID,
             n_item_no,
             c_sbjt_no,
             n_amt,
             C_CUR_CDE,
             c_cav_dir,
             c_dpt_cde,
             c_sls_cde,
             c_prod_no,
             c_cha_cls,
             c_cha_cde,
             C_PAYER_NME,
             n_pre_amt,

             -- c_oitem_no,
             c_pre_flag,
             c_bsns_typ,
             C_CURT_DPT_CDE)
            SELECT 'admin', --wpc
                   v_today_tm, --wpc
                   'admin', --wpc
                   v_today_tm, --wpc
                   v_batch_no,
                   1,
                   v_crsbjt_no,
                   v_sum_amt,
                   C_BS_CUR,
                   '2', --'??'
                   c_dpt_cde,
                   c_sls_cde,
                   c_prod_no,
                   c_cha_cls,
                   c_cha_cde,
                   'admin',
                   v_sum_amt,

                   -- '1',
                   '1',
                   c_bsns_typ,
                   NULL
              FROM WEB_FIN_SAVEAMT_DUE
             WHERE c_rcpt_no = v_rcpt_no
               and c_bala_mrk = '1';

          IF v_other_amt <> 0 THEN
            v_nitem_no  := v_nitem_no + 1;
            v_crsbjt_no := '410905';
            INSERT INTO WEB_FIN_CAV_OBJ

              (c_crt_cde, --wpc
               T_CRT_TM, --wpc
               C_UPD_CDE, --wpc
               T_UPD_TM, --wpc
               C_CAV_PK_ID,
               n_item_no,
               c_sbjt_no,
               n_amt,
               c_cur_cde,
               c_cav_dir,
               c_dpt_cde,
               c_sls_cde,
               c_prod_no,
               c_cha_cls,
               c_cha_cde,
               C_PAYER_NME,
               n_pre_amt,

               --c_oitem_no,
               c_pre_flag,
               c_bsns_typ,
               C_CURT_DPT_CDE)
              SELECT 'admin', --wpc
                     v_today_tm, --wpc
                     'admin', --wpc
                     v_today_tm, --wpc
                     v_batch_no,
                     2,
                     '410905',
                     abs(v_other_amt),
                     c_bs_cur,
                     '2', --'??',--wpc
                     c_dpt_cde,
                     c_sls_cde,
                     c_prod_no,
                     c_cha_cls,
                     c_cha_cde,
                     'admin',
                     0,

                     -- '1',
                     '1',
                     c_bsns_typ,
                     NULL
                FROM WEB_FIN_SAVEAMT_DUE
               WHERE c_rcpt_no = v_rcpt_no
                 and c_bala_mrk = '1';

          END IF;

          INSERT INTO WEB_FIN_DCR
            (C_SEQ_NO,
             c_item_no,
             C_CAV_FLAG,
             c_sbjt_no,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             c_dptacc_NO,
             C_SEND_FLAG,
             c_sbjt_memo,
             c_kind_no,
             c_department_cde,
             c_company_cde,
             c_period_name,
             c_vou_memo,
             c_voucher_no,
             c_vou_no,
             n_total_amt,
             C_CAV_NO,
             c_servicetype_no,
             c_rp_type)
            SELECT vTmpVouNo,
                   '1', --wpc to_char(v_nitem_no),--'1',--wpc
                   v_crcav_flag,
                   '119302',
                   v_sum_amt,
                   c_bs_cur,
                   v_today_tm,
                   v_dptacc_cde,

                   '0',
                   '0',
                   '0',
                   '0',
                   v_company_cde,
                   TO_CHAR(v_today_tm, 'YYYY-MM'),
                   v_vou_memo,
                   v_voucher_no,
                   v_voucher_no,
                   v_sum_amt,
                   vTmpVouNo,
                   v_servicetype_no,
                   v_rp_type
              FROM WEB_FIN_SAVEAMT_DUE
             WHERE c_rcpt_no = v_rcpt_no
               and c_bala_mrk = '1';

          IF v_other_amt <> 0 THEN
            INSERT INTO WEB_FIN_DCR
              (C_SEQ_NO,
               c_item_no,
               C_CAV_FLAG,
               c_sbjt_no,
               N_AMT,
               C_CUR_NO,
               T_CRT_TM,
               c_dptacc_no,
               C_SEND_FLAG,
               c_sbjt_memo,
               c_kind_no,
               c_department_cde,
               c_company_cde,
               c_period_name,
               c_vou_memo,
               c_voucher_no,
               c_vou_no,
               n_total_amt,
               C_CAV_NO,
               c_servicetype_no,
               c_rp_type,
               c_prod_no)
              SELECT vTmpVouNo,
                     '2',
                     '?',
                     '410905',
                     abs(v_other_amt),
                     c_bs_cur,
                     v_today_tm,
                     v_dptacc_cde,

                     '0',
                     v_sbjt_memo,
                     '014',
                     v_department_cde,
                     v_company_cde,
                     TO_CHAR(v_today_tm, 'YYYY-MM'),
                     v_vou_memo,
                     v_voucher_no,
                     v_voucher_no,
                     v_sum_amt,
                     vTmpVouNo,
                     v_servicetype_no,
                     v_rp_type,
                     c_prod_no
                FROM WEB_FIN_SAVEAMT_DUE
               WHERE c_rcpt_no = v_rcpt_no
                 and c_bala_mrk = '1';
          END IF;
        END IF;

        v_nitem_no := v_nitem_no + 1;

      END LOOP;
      CLOSE cur_ifclmInfo;

      IF v_nitem_no <> 1 THEN
        --?????
        --????????
        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           C_BAL_TYPE,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           C_SALEGRP_CDE,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_department_cde,
           c_rcpt_no,
           C_CAV_NO)
          SELECT c_seq_no,
                 '1',
                 c_cav_flag,
                 c_sbjt_no,
                 '0',
                 n_amt,
                 n_exch_amt,
                 DECODE(c_cur_no,
                        '01',
                        'CNY',
                        '02',
                        'HKD',
                        '03',
                        'USD',
                        '12',
                        'EUR',
                        '13',
                        'EUR',
                        '05',
                        'JPY',
                        c_cur_no),
                 n_rate,
                 c_chr_cur_no,
                 t_crt_tm,
                 c_dptacc_no,
                 c_flow_no,
                 v_rp_type,
                 c_ri_com,
                 C_BAL_TYPE,
                 NULL,
                 c_check_no,
                 t_rp_tm,
                 c_kind_no,
                 '0',
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 C_SALEGRP_CDE, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 c_voucher_no,
                 c_period_name,
                 v_sum_amt,
                 v_servicetype_no,
                 c_department_cde,
                 c_rcpt_no,
                 vTmpVouNo
            FROM WEB_FIN_DCR
           WHERE c_seq_no = vTmpVouNo
             AND c_item_no = '1';

        IF v_other_amt <> 0 THEN
          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_flow_no,
             c_rp_type,
             c_ri_com,
             C_BAL_TYPE,
             c_bank_cde,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             C_SALEGRP_CDE,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_department_cde,
             c_rcpt_no,
             C_CAV_NO)
            SELECT c_seq_no,
                   '2',
                   c_cav_flag,
                   c_sbjt_no,
                   '0',
                   n_amt,
                   n_exch_amt,
                   DECODE(c_cur_no,
                          '01',
                          'CNY',
                          '02',
                          'HKD',
                          '03',
                          'USD',
                          '12',
                          'EUR',
                          '13',
                          'EUR',
                          '05',
                          'JPY',
                          c_cur_no),
                   n_rate,
                   c_chr_cur_no,
                   t_crt_tm,
                   c_dptacc_no,
                   c_flow_no,
                   v_rp_type,
                   c_ri_com,
                   C_BAL_TYPE,
                   NULL,
                   c_check_no,
                   t_rp_tm,
                   c_kind_no,
                   '0',
                   c_cont_code,
                   c_dpt_cde,
                   c_vou_memo,
                   c_con_dpt_cde,
                   c_cost_cde,
                   c_company_cde,
                   C_SALEGRP_CDE, /*c_bsns_typ*/
                   '0',
                   c_cha_mrk,
                   c_voucher_no,
                   c_period_name,
                   v_sum_amt,
                   v_servicetype_no,
                   c_department_cde,
                   c_rcpt_no,
                   vTmpVouNo
              FROM WEB_FIN_DCR
             WHERE c_seq_no = vTmpVouNo
               AND c_item_no = '2';
        END IF;

        UPDATE WEB_FIN_DCR
           SET c_voucher_no = v_voucher_no, c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        UPDATE web_fin_dcr_intf
           SET c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        --????

        IF v_other_amt = 0 THEN
          v_nitem_no := 1;
        ELSE
          v_nitem_no := 2;
        END IF;

        OPEN cur_gatherrcpt;
        LOOP
          <<GOTO_LAB>>
          FETCH cur_gatherrcpt
            INTO v_cav_flag, v_sbjt_no, v_cur_no, v_dpt_cde, v_kind_no, v_amt, v_dptacc_cde, v_vou_memo, v_company_cde, v_servicetype_no, v_rp_type;
          EXIT WHEN cur_gatherrcpt%NOTFOUND;

          v_nitem_no := v_nitem_no + 1;

          SELECT c_department_cde
            INTO v_department_cde
            FROM WEB_ORG_DPT
           WHERE c_dpt_cde = v_dpt_cde;

          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_flow_no,
             c_rp_type,
             c_ri_com,
             C_BAL_TYPE,
             c_bank_cde,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             C_SALEGRP_CDE,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_department_cde,
             c_rcpt_no,
             C_CAV_NO)
          VALUES
            (vTmpVouNo,
             TO_CHAR(v_nitem_no),
             v_cav_flag,
             v_sbjt_no,
             '0',
             v_amt,
             v_amt,
             DECODE(v_cur_no,
                    '01',
                    'CNY',
                    '02',
                    'HKD',
                    '03',
                    'USD',
                    '12',
                    'EUR',
                    '13',
                    'EUR',
                    '05',
                    'JPY',
                    v_cur_no),
             1,
             NULL,
             v_today_tm,
             v_dptacc_cde,
             NULL,
             v_rp_type,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             v_kind_no,
             '0',
             NULL,
             v_dpt_cde,
             v_vou_memo,
             NULL,
             NULL,
             v_company_cde,
             NULL, /*c_bsns_typ*/
             '0',
             NULL,
             v_voucher_no,
             TO_CHAR(v_today_tm, 'YYYY-MM'),
             v_sum_amt,
             v_servicetype_no,
             v_department_cde,
             NULL,
             vTmpVouNo);

        END LOOP;
        CLOSE cur_gatherrcpt;

      END IF;

      UPDATE WEB_FIN_SAVEAMT_DUE
         SET N_RP_AMT     = N_BS_AMT,
             n_paid_amt   = N_BS_AMT,
             T_PAID_TM    = v_today_tm,
             T_RP_TM      = v_today_tm,
             c_accnt_flag = DECODE(c_accnt_flag,
                                   '01',
                                   '11',
                                   '00',
                                   '10',
                                   '10')
       WHERE c_batch_no = v_batch_no
         and c_bala_mrk = '1'
         AND N_BS_AMT > 0
         AND N_OTHER_AMT <= 0
         AND n_paid_amt = 0;

      OPEN cur_calfee;
      LOOP
        FETCH cur_calfee
          INTO v_rcpt_no;
        EXIT WHEN cur_calfee%NOTFOUND;

        --Collectfu.Producecost(v_rcpt_no,'0',v_returnflag);
        IF v_returnflag < 0 THEN
          v_succsflag := -4;
          rollback;
          RETURN;
        END IF;

      END LOOP;
      CLOSE cur_calfee;

      UPDATE web_fin_dcr_intf
         SET c_department_cde = v_department_cde, c_prod_no = '014'
       WHERE c_seq_no = vTmpVouNo
         and c_sbjt_no = '410905';

      UPDATE web_fin_dcr_intf
         SET c_servicetype_no = '1112'
       WHERE c_seq_no = vTmpVouNo;

      Collectfu.ValidityCheckCavVou(v_voucher_no, v_succsflag); --??????????0?????????

      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[OtherIncomeCavSave ValidityCheckCavVou],??????[' ||
                         TO_CHAR(v_succsflag) || v_batch_no || v_dpt_cde ||
                         v_prod_no || v_cur_no ||
                         TO_CHAR(v_today_tm, 'YYYY-MM-DD') || v_dptacc_cde ||
                         v_vou_memo || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_gather;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        ROLLBACK;
        dbms_output.put_line('exception' || '*' || v_batch_no || SQLERRM);
        v_err_content := 'proc:[OtherIncomeCavSave],??????[' ||
                         v_batch_no || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;
  --20. ????  ??????????????????  1??????????????? 2??? 5 ??? ?
  /*
    113101????/????
    113102????/????
    113103????/????
    113104????/????
  */
  PROCEDURE ClmCategories IS
    --????
    v_dpt_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_eac_dcm_mrk WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
    v_cur_typ     WEB_FIN_CLM_DUE.c_bs_cur%TYPE;
    v_batch_no    WEB_FIN_CLM_DUE.c_batch_no%TYPE;
    v_bala_mrk    WEB_FIN_CLM_DUE.c_bala_mrk%TYPE;
    v_err_content WEB_BAS_fin_errorlog.c_err_content%TYPE;

    --??(?????????????) ???????????????????????
    CURSOR cur_ifclmInfo IS
      SELECT a.c_dpt_cde, a.c_eac_dcm_mrk, a.c_bs_cur, a.c_bala_mrk
        FROM WEB_FIN_CLM_DUE a, WEB_ORG_DPT b
       WHERE a.c_dpt_cde = b.c_dpt_cde
         AND a.c_batch_no IS NULL
         AND a.c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
         AND a.c_bala_mrk IN ('0', '2', '3') -- ?????????
         AND a.n_paid_amt = 0
         AND LENGTH(b.c_dpt_cde) = 8
         AND b.c_company_cde <> '?'
         AND b.c_department_cde <> '?'
         AND a.n_bs_amt <> 0
         AND b.c_company_cde IS NOT NULL
         AND b.c_department_cde IS NOT NULL
         AND a.c_eac_dcm_mrk IN ('1', '2', '5', '6')
         AND a.n_bs_amt > 0
         AND a.t_crt_tm >=
             TO_DATE('2007-05-08 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         AND a.t_crt_tm <=
             TO_DATE('2008-06-05 23:59:50', 'YYYY-MM-DD HH24:MI:SS')
       GROUP BY a.c_dpt_cde, a.c_eac_dcm_mrk, a.c_bs_cur, a.c_bala_mrk;

  BEGIN

    update WEB_FIN_CLM_DUE a
       set c_batch_no = null
     WHERE a.c_batch_no IS NOT NULL
       AND a.c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
       AND a.c_bala_mrk IN ('0', '2', '3') -- ?????????
       AND a.n_paid_amt = 0
       AND a.n_bs_amt <> 0
       AND a.c_eac_dcm_mrk IN ('1', '2', '5', '6')
       AND a.n_bs_amt > 0
       AND a.t_crt_tm >=
           TO_DATE('2007-05-08 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
       AND a.t_crt_tm <=
           TO_DATE('2008-06-05 23:59:50', 'YYYY-MM-DD HH24:MI:SS');

    --???????
    AutoCollect.newClmCategories;

    OPEN cur_ifclmInfo;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifclmInfo
        INTO v_dpt_cde, v_eac_dcm_mrk, v_cur_typ, v_bala_mrk;
      EXIT WHEN cur_ifclmInfo%NOTFOUND;

      --?????
      Dz_Proc.get_fin_no(v_batch_no, v_dpt_cde, '7', dz_proc.g_pttype);

      UPDATE WEB_FIN_CLM_DUE a
         SET c_batch_no = v_batch_no
       WHERE c_dpt_cde = v_dpt_cde
         AND c_eac_dcm_mrk = v_eac_dcm_mrk
         AND c_bs_cur = v_cur_typ
         AND c_bala_mrk = v_bala_mrk
         AND c_batch_no IS NULL
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
         AND c_bala_mrk IN ('0', '2', '3') -- ?????????
         AND n_paid_amt = 0
         AND n_bs_amt <> 0
         AND c_eac_dcm_mrk IN ('1', '2', '5', '6')
         AND a.n_bs_amt > 0
         AND t_crt_tm >=
             TO_DATE('2007-05-08 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         AND t_crt_tm <=
             TO_DATE('2008-06-05 23:59:50', 'YYYY-MM-DD HH24:MI:SS');
      commit;
    END LOOP;
    CLOSE cur_ifclmInfo;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_dpt_cde ||
                             v_eac_dcm_mrk || v_cur_typ || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[ClmCategories],??????[' || v_dpt_cde ||
                         v_eac_dcm_mrk || v_cur_typ || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  PROCEDURE newClmCategories IS
    --????
    v_dpt_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_eac_dcm_mrk WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
    v_cur_typ     WEB_FIN_CLM_DUE.c_bs_cur%TYPE;
    v_batch_no    WEB_FIN_CLM_DUE.c_batch_no%TYPE;
    v_bala_mrk    WEB_FIN_CLM_DUE.c_bala_mrk%TYPE;
    v_err_content WEB_BAS_fin_errorlog.c_err_content%TYPE;

    --??(?????????????) ???????????????????????
    CURSOR cur_ifclmInfo IS
      SELECT a.c_dpt_cde, a.c_eac_dcm_mrk, a.c_bs_cur, a.c_bala_mrk
        FROM WEB_FIN_CLM_DUE a, WEB_ORG_DPT b
       WHERE a.c_dpt_cde = b.c_dpt_cde
         AND a.c_batch_no IS NULL
         AND a.c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
         AND a.c_bala_mrk IN ('0', '2', '3') -- ?????????
         AND a.n_paid_amt = 0
         AND LENGTH(b.c_dpt_cde) = 8
         AND b.c_company_cde <> '?'
         AND b.c_department_cde <> '?'
         AND a.n_bs_amt <> 0
         AND b.c_company_cde IS NOT NULL
         AND b.c_department_cde IS NOT NULL
         AND a.c_eac_dcm_mrk IN ('1', '2', '5', '6')
         AND a.n_bs_amt > 0
         AND a.t_crt_tm >=
             TO_DATE('2008-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
            --       AND not exists (SELECT 1 FROM t_fin_tmpbigsavedue where c_ply_no=a.c_ply_no)
            --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:59','YYYY-MM-DD HH24:MI:SS')
         and exists (select 1
                from web_fin_rpclmcustomer
               where c_bala_mrk = '6'
                 and c_capital_flows not in ('6', '7')
                 and c_rcpt_no = a.c_rcpt_no)
       GROUP BY a.c_dpt_cde, a.c_eac_dcm_mrk, a.c_bs_cur, a.c_bala_mrk;

  BEGIN

    update WEB_FIN_CLM_DUE a
       set c_batch_no = null
     WHERE a.c_batch_no IS NOT NULL
       AND a.c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
       AND a.c_bala_mrk IN ('0', '2', '3') -- ?????????
       AND a.n_paid_amt = 0
       AND a.n_bs_amt <> 0
       AND a.c_eac_dcm_mrk IN ('1', '2', '5', '6')
       AND a.n_bs_amt > 0
       AND a.t_crt_tm >=
           TO_DATE('2008-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
          --       AND not exists (SELECT 1 FROM t_fin_tmpbigsavedue where c_ply_no=a.c_ply_no)
          --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:59','YYYY-MM-DD HH24:MI:SS')
       and exists (select 1
              from web_fin_rpclmcustomer
             where c_bala_mrk = '6'
               and c_capital_flows not in ('6', '7')
               and c_rcpt_no = a.c_rcpt_no);

    --???????
    --  Auto_confirmed.newnewClmCategories;

    OPEN cur_ifclmInfo;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifclmInfo
        INTO v_dpt_cde, v_eac_dcm_mrk, v_cur_typ, v_bala_mrk;
      EXIT WHEN cur_ifclmInfo%NOTFOUND;

      --?????
      Dz_Proc.get_fin_no(v_batch_no, v_dpt_cde, '7', dz_proc.g_pttype);

      UPDATE WEB_FIN_CLM_DUE a
         SET c_batch_no = v_batch_no
       WHERE c_dpt_cde = v_dpt_cde
         AND c_eac_dcm_mrk = v_eac_dcm_mrk
         AND c_bs_cur = v_cur_typ
         AND c_bala_mrk = v_bala_mrk
         AND c_batch_no IS NULL
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
         AND c_bala_mrk IN ('0', '2', '3') -- ?????????
         AND n_paid_amt = 0
         AND n_bs_amt <> 0
         AND c_eac_dcm_mrk IN ('1', '2', '5', '6')
         AND a.n_bs_amt > 0
         AND a.t_crt_tm >=
             TO_DATE('2008-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
            --       AND not exists (SELECT 1 FROM t_fin_tmpbigsavedue where c_ply_no=a.c_ply_no)
            --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:59','YYYY-MM-DD HH24:MI:SS')
         and exists (select 1
                from web_fin_rpclmcustomer
               where c_bala_mrk = '6'
                 and c_capital_flows not in ('6', '7')
                 and c_rcpt_no = a.c_rcpt_no);
      commit;
    END LOOP;
    CLOSE cur_ifclmInfo;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_dpt_cde ||
                             v_eac_dcm_mrk || v_cur_typ || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[newClmCategories],??????[' ||
                         v_dpt_cde || v_eac_dcm_mrk || v_cur_typ ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  Procedure Passescompensates IS
    v_dptacc_cde web_org_dpt.c_dptacc_cde%TYPE;
    v_dpt_cde    web_org_dpt.c_dpt_cde%TYPE;
    v_prod_no    WEB_FIN_PRM_DUE.c_prod_no%TYPE;
    v_pre_sum    WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
    v_edr_type   WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
    v_edr_no     WEB_FIN_PRM_DUE.c_edr_no%TYPE;
    v_ply_no     WEB_FIN_PRM_DUE.c_ply_no%TYPE;
    v_bal_tm     WEB_FIN_PRM_DUE.t_due_tm%TYPE;
    v_today_tm   web_FIN_DCR.t_crt_tm%TYPE;
    v_cav_flag   web_FIN_DCR.c_cav_flag%TYPE;
    v_cnt        INT;
    v_tmpcnt     INT;
    v_sbjt_no    WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_memo  WEB_FIN_MADCR.c_sbjt_memo%TYPE;
    v_vou_memo   WEB_FIN_MADCR.c_vou_memo%TYPE;
    vTmpVouNo    WEB_FIN_MADCR.c_seq_no%TYPE;
    vTmpVouNo1   WEB_FIN_MADCR.c_seq_no%TYPE;

    vSbjtNo       web_FIN_DCR.c_sbjt_no%TYPE;
    vCavFlag      web_FIN_DCR.C_CAV_FLAG%TYPE;
    v_feetyp_cde  WEB_FIN_PAY_DUE.c_feetyp_cde%TYPE;
    v_tran_flag   WEB_FIN_PAY_DUE.c_tran_flag%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
    v_seq_no      WEB_FIN_DCR.c_seq_no%TYPE;
    v_item_no     WEB_FIN_DCR.c_item_no%TYPE;

    vToday     VARCHAR(10);
    vBillToday VARCHAR(10);

    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;

    v_drcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_drsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_crsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_voucher_no  WEB_FIN_DCR.c_voucher_no%TYPE;
    v_period_name WEB_FIN_DCR.c_period_name%TYPE;
    v_rcpt_no     WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;

    v_cur_no      WEB_FIN_CAV_BILL.C_CUR_CDE%TYPE;
    v_sum_amt     WEB_FIN_CAV_BILL.n_sum_amt%TYPE;
    v_eac_dcm_mrk WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
    v_nitem_no    INT;
    v_pretyp_cde  WEB_FIN_CLM_DUE.c_pretyp_cde%TYPE;
    v_bala_mrk    WEB_FIN_CLM_DUE.c_bala_mrk%TYPE;
    v_batch_no    WEB_FIN_CLM_DUE.c_batch_no%TYPE;
    v_rp_type     web_fin_dcr_intf.c_rp_type%TYPE;
    v_amt         web_fin_dcr_intf.n_amt%TYPE;
    v_succsflag   INT;

    CURSOR cur_gather IS
      SELECT /*+ index (WEB_FIN_CLM_DUE IDX_FIN_CLMDUE_CRTTM)*/
      DISTINCT c_batch_no, c_dpt_cde
        FROM WEB_FIN_CLM_DUE
       WHERE c_batch_no IS NOT NULL
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
         AND c_bala_mrk IN ('0', '2', '3')
         AND n_rp_amt = 0
         and t_crt_tm >=
             TO_DATE('2007-05-08 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and t_crt_tm <=
             TO_DATE('2008-06-05 23:59:59', 'YYYY-MM-DD HH24:MI:SS')
         AND n_paid_amt = 0;

    CURSOR cur_ifclmInfo IS
      SELECT c_dpt_cde,
             c_prod_no,
             c_ply_no,
             n_bs_amt,
             t_DUE_tm,
             c_rcpt_no,
             c_bs_cur,
             c_eac_dcm_mrk,
             c_bala_mrk,
             c_pretyp_cde
        FROM WEB_FIN_CLM_DUE
       WHERE c_bala_mrk IN ('0', '2', '3')
         AND c_batch_no = v_batch_no
         AND c_batch_no IS NOT NULL
         AND n_rp_amt = 0
         and t_crt_tm >=
             TO_DATE('2007-05-08 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and t_crt_tm <=
             TO_DATE('2008-06-05 23:59:59', 'YYYY-MM-DD HH24:MI:SS')
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF');

    --??
    CURSOR cur_gatherrcpt IS
      SELECT c_cav_flag,
             c_sbjt_no,
             c_cur_no,
             c_dpt_cde,
             c_kind_no,
             SUM(n_amt),
             c_dptacc_no,
             c_vou_memo,
             c_company_cde,
             c_servicetype_no,
             c_rp_type
        FROM WEB_FIN_DCR
       WHERE c_seq_no = vTmpVouNo
         AND c_rcpt_no IS NOT NULL
       GROUP BY c_cav_flag,
                c_sbjt_no,
                c_cur_no,
                c_dpt_cde,
                c_kind_no,
                c_dptacc_no,
                c_vou_memo,
                c_company_cde,
                c_servicetype_no,
                c_rp_type;

    v_tmp_cnt  INT;
    v_end_time WEB_FIN_CLM_DUE.t_crt_tm%TYPE;

  BEGIN

    --??2008.11.1????????
    AutoCollect.NewPassesCompen;

    OPEN cur_gather;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_gather
        INTO v_batch_no, v_dpt_cde;
      EXIT WHEN cur_gather%NOTFOUND;

      SELECT SUM(n_bs_amt)
        INTO v_sum_amt
        FROM WEB_FIN_CLM_DUE
       WHERE c_bala_mrk IN ('0', '2', '3')
         AND c_batch_no = v_batch_no
         AND c_batch_no IS NOT NULL
         and t_crt_tm >=
             TO_DATE('2007-05-08 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and t_crt_tm <=
             TO_DATE('2008-06-05 23:59:59', 'YYYY-MM-DD HH24:MI:SS')
         AND n_rp_amt = 0
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF');

      SELECT c_dptacc_cde
        INTO v_dptacc_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = v_dpt_cde;

      SELECT C_PERIOD_NAME
        INTO v_period_name
        FROM WEB_FIN_MONTHLYCLOSING
       WHERE c_dptacc_cde = v_dptacc_cde
         AND c_closing_flag = '1'; --??

      SELECT TRUNC(t_end_tm)
        INTO v_end_time
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = v_period_name;

      --???????????
      IF TO_CHAR(SYSDATE, 'YYYY-MM') <> v_period_name THEN
        v_today_tm := v_end_time;
      ELSE
        v_today_tm := SYSDATE;
      END IF;

      v_nitem_no := 2;

      --??
      OPEN cur_ifclmInfo;
      LOOP
        FETCH cur_ifclmInfo
          INTO v_dpt_cde, v_prod_no, v_ply_no, v_pre_sum, v_bal_tm, v_rcpt_no, v_cur_no, v_eac_dcm_mrk, v_bala_mrk, v_pretyp_cde;
        EXIT WHEN cur_ifclmInfo%NOTFOUND;

        SELECT c_department_cde, c_company_cde, c_dptacc_cde
          INTO v_department_cde, v_company_cde, v_dptacc_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = v_dpt_cde;

        --??????
        INSERT INTO WEB_FIN_CAV_DOC
          (N_ITEM_NO,
           C_CAV_PK_ID,
           c_rcpt_no,
           c_ply_no,
           c_edr_no,
           --c_rp_cur,
           -- n_get_prm,
           n_exch_rate,
           --n_paid_amt,
           -- n_exchgot_prm,
           t_insrnc_bgn_tm,
           t_insrnc_end_tm,
           c_prod_no,
           c_sls_cde,
           c_cha_cls,
           c_cha_cde,
           C_PAYER_CDE,
           c_dpt_cde,
           c_feetyp_cde,
           C_SLSGRP_CDE,
           c_bsns_typ,
           C_PAYER_NME,
           c_bs_cur,
           n_bs_amt,
           c_rp_cur,
           n_rp_amt)
          SELECT TO_CHAR(v_nitem_no),
                 v_batch_no,
                 c_rcpt_no,
                 c_ply_no,
                 c_clm_no,
                 --c_bs_cur,
                 --n_bs_amt,
                 1,
                 -- n_bs_amt,
                 -- n_bs_amt,
                 t_insrnc_bgn_tm,
                 t_insrnc_end_tm,
                 c_prod_no,
                 NULL,
                 NULL,
                 NULL,
                 NULL,
                 c_dpt_cde,
                 NULL,
                 NULL,
                 c_bsns_typ,
                 ' ',
                 c_bs_cur,
                 n_bs_amt,
                 c_bs_cur,
                 n_bs_amt
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

        --?????
        --Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7');
        vTmpVouNo := v_batch_no;
        SELECT c_kind_no
          INTO v_kind_no
          FROM WEB_BAS_FIN_PROD
         WHERE c_prod_no = v_prod_no;

        v_drcav_flag := '?';
        v_crcav_flag := '?';

        /*
        113101????/????
        113102????/????
        113103????/????
        113104????/????
        */

        IF v_eac_dcm_mrk = '1' THEN

          IF v_pretyp_cde IS NULL THEN
            v_drsbjt_no := '113101'; --??????????  ?????????
          ELSIF v_pretyp_cde = '0' THEN
            v_drsbjt_no := '113101';
          ELSIF v_pretyp_cde = '1' THEN
            v_drsbjt_no := '113101';
          ELSIF v_pretyp_cde = '2' THEN
            v_drsbjt_no := '113102'; --1?????
          ELSIF v_pretyp_cde = '3' THEN
            v_drsbjt_no := '113103';
          ELSIF v_pretyp_cde = '4' THEN
            v_drsbjt_no := '113104';
          END IF;

          v_vou_memo       := '??????';
          v_servicetype_no := '1107';
          v_rp_type        := '204';
        ELSIF v_eac_dcm_mrk = '2' THEN
          v_drsbjt_no      := '215001'; --????
          v_vou_memo       := '????';
          v_servicetype_no := '1108';
          v_rp_type        := '205';
        ELSIF v_eac_dcm_mrk = '5' THEN
          --5 ???
          v_drsbjt_no      := '440104';
          v_vou_memo       := '????';
          v_servicetype_no := '1108';
          v_rp_type        := '204';
        ELSIF v_eac_dcm_mrk = '6' THEN
          --5 ???
          v_drsbjt_no      := '440104';
          v_vou_memo       := '????';
          v_servicetype_no := '1108';
          v_rp_type        := '204';
        END IF;

        --0 ???? 1 ??/??/?? 2 ????
        /*
        IF v_bala_mrk='0' THEN
            v_crsbjt_no:='119301';
        ELSE
            v_crsbjt_no:='100102';
        END IF;
        */
        v_crsbjt_no := '119301';

        INSERT INTO WEB_FIN_DCR
          (C_SEQ_NO,
           C_ITEM_NO,
           C_CAV_FLAG,
           C_SBJT_NO,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           C_DPTACC_NO,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_ply_no,
           c_cha_mrk,
           c_vou_memo,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde,
           c_sbjt_memo,
           c_period_name,
           c_voucher_no,
           n_total_amt,
           c_cav_no,
           c_rp_type)
          SELECT vTmpVouNo,
                 TO_CHAR(v_nitem_no),
                 v_drcav_flag,
                 v_drsbjt_no,
                 v_pre_sum,
                 c_bs_cur,
                 v_today_tm,
                 v_dptacc_cde,
                 c_dpt_cde,
                 c_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 c_insrnt_cde,
                 NULL,
                 NULL,
                 v_voucher_no,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 c_ply_no,
                 c_cha_mrk,
                 v_vou_memo,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde,
                 '0',
                 TO_CHAR(v_today_tm, 'YYYY-MM'),
                 v_voucher_no,
                 v_sum_amt,
                 vTmpVouNo,
                 v_rp_type
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

        IF v_nitem_no = '2' THEN
          v_period_name := TO_CHAR(v_today_tm, 'yyyy-mm');
          Dz_Proc.get_fin_voucode(v_voucher_no,
                                  v_period_name,
                                  v_company_cde,
                                  dz_proc.g_pttype);

          --?????
          INSERT INTO WEB_FIN_CAV_BILL
            (c_dpt_cde,
             c_rp_type,
             C_CUR_CDE,
             n_sum_amt,
             c_oper_cde,
             t_cav_tm,
             t_upd_tm,
             C_CAV_PK_ID,
             c_check_cde,
             t_check_tm,
             c_check_memo,
             c_check_flag)
          VALUES
            (v_dptacc_cde,
             v_rp_type,
             v_cur_no,
             v_sum_amt,
             'admin',
             v_today_tm,
             v_today_tm,
             v_batch_no,
             'admin',
             v_today_tm,
             '??',
             '2');
          /*??????*/
          /*wpc begin  WEB_FIN_CAV_BILL ?WEB_FIN_RPTYP???*/
          INSERT INTO WEB_FIN_CAV_RPTYP
            (C_CAVRPTYP_PK_ID,
             C_CAV_PK_ID,
             N_ITEM_NO,
             C_RP_TYPE,
             C_CUR_CDE,
             N_SUM_AMT,
             C_REPLACE_FLAG,
             C_CRT_CDE,
             T_CRT_TM,
             C_UPD_CDE,
             T_UPD_TM)
          VALUES
            (v_batch_no,
             v_batch_no,
             v_nitem_no,
             v_rp_type,
             v_cur_no,
             v_sum_amt,
             '0',
             'admin',
             v_today_tm,
             'admin',
             v_today_tm);
          /* wpc end*/
          --???????(??????)
          --IF v_bala_mrk='0' THEN
          INSERT INTO WEB_FIN_CAV_OBJ

            (C_CAV_PK_ID,
             n_item_no,
             c_sbjt_no,
             n_amt,
             C_CUR_CDE,
             C_CAV_DIR,
             c_dpt_cde,
             c_sls_cde,
             c_prod_no,
             c_cha_cls,
             c_cha_cde,
             C_PAYER_NME,
             n_pre_amt,

             -- N_ITEM_NO,
             c_pre_flag,
             c_bsns_typ,
             C_CURT_DPT_CDE)
            SELECT v_batch_no,
                   '1',
                   '119301',
                   v_sum_amt,
                   c_bs_cur,
                   '??',
                   c_dpt_cde,
                   c_sls_cde,
                   c_prod_no,
                   c_cha_cls,
                   c_cha_cde,
                   'admin',
                   v_sum_amt,

                   --'1',
                   '1',
                   c_bsns_typ,
                   NULL
              FROM WEB_FIN_CLM_DUE
             WHERE c_rcpt_no = v_rcpt_no;
          --ELSE -- ??
          /*
              INSERT INTO WEB_FIN_CAV_MNY
              (
                c_cav_no         ,
                c_item_no        ,
                c_bal_type       ,
                n_amt            ,
                n_use_amt        ,
                c_cur_no         ,
                c_pay_name       ,
                c_bank_cde       ,
                c_check_no       ,
                t_rp_tm          ,
                c_flow_no        ,
                c_bank_name      ,
                c_bank_accnt     ,
                c_rp_name        ,
                c_feetyp_cde     ,
                c_sbjt_no        ,
                c_savecash_bank  ,
                t_savecash_tm    ,
                c_savecash_no    ,
                c_savecash_opt   ,
                c_formafee_no    ,
                c_check_flag
              )
              SELECT
                v_batch_no         ,
                '1'        ,
                '00200'          ,
                v_sum_amt            ,
                v_sum_amt        ,
                c_cur_typ         ,
                'admin',
                null       ,
                null       ,
                v_today_tm          ,
                null        ,
                null      ,
                null     ,
                SUBSTR(c_pay_name,1,20)        ,
                null     ,
                '100102'        ,
                null  ,
                null    ,
                null    ,
                null   ,
                null    ,
                '0'
              FROM WEB_FIN_CLM_DUE
              WHERE c_rcpt_no=v_rcpt_no;
          */
          --END IF;

          INSERT INTO WEB_FIN_DCR
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_SEND_FLAG,
             c_sbjt_memo,
             c_kind_no,
             c_department_cde,
             c_company_cde,
             c_period_name,
             c_vou_memo,
             c_voucher_no,
             c_vou_no,
             n_total_amt,
             c_cav_no,
             c_rp_type)
            SELECT vTmpVouNo,
                   '1',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_sum_amt,
                   c_bs_cur,
                   v_today_tm,
                   v_dptacc_cde,

                   '0',
                   v_sbjt_memo,
                   '0',
                   '0',
                   v_company_cde,
                   TO_CHAR(v_today_tm, 'YYYY-MM'),
                   v_vou_memo,
                   v_voucher_no,
                   v_voucher_no,
                   v_sum_amt,
                   vTmpVouNo,
                   v_rp_type
              FROM WEB_FIN_CLM_DUE
             WHERE c_rcpt_no = v_rcpt_no;

        END IF;

        v_nitem_no := v_nitem_no + 1;

      END LOOP;
      CLOSE cur_ifclmInfo;

      IF v_nitem_no <> 1 THEN
        --?????
        --????????
        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_department_cde,
           c_rcpt_no,
           c_cav_no)
          SELECT c_seq_no,
                 '1',
                 c_cav_flag,
                 c_sbjt_no,
                 '0',
                 n_amt,
                 n_exch_amt,
                 DECODE(c_cur_no,
                        '01',
                        'CNY',
                        '02',
                        'HKD',
                        '03',
                        'USD',
                        '12',
                        'EUR',
                        '13',
                        'EUR',
                        '05',
                        'JPY',
                        c_cur_no),
                 n_rate,
                 c_chr_cur_no,
                 t_crt_tm,
                 c_dptacc_no,
                 c_flow_no,
                 v_rp_type,
                 c_ri_com,
                 c_bal_type,
                 NULL,
                 c_check_no,
                 t_rp_tm,
                 c_kind_no,
                 '0',
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 c_salegrp_cde, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 c_voucher_no,
                 c_period_name,
                 v_sum_amt,
                 v_servicetype_no,
                 c_department_cde,
                 c_rcpt_no,
                 vTmpVouNo
            FROM WEB_FIN_DCR
           WHERE c_seq_no = vTmpVouNo
             AND c_item_no = '1';

        UPDATE WEB_FIN_DCR
           SET c_voucher_no = v_voucher_no, c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        UPDATE web_fin_dcr_intf
           SET c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        --????

        v_nitem_no := 1;
        OPEN cur_gatherrcpt;
        LOOP
          <<GOTO_LAB>>
          FETCH cur_gatherrcpt
            INTO v_cav_flag, v_sbjt_no, v_cur_no, v_dpt_cde, v_kind_no, v_amt, v_dptacc_cde, v_vou_memo, v_company_cde, v_servicetype_no, v_rp_type;
          EXIT WHEN cur_gatherrcpt%NOTFOUND;

          v_nitem_no := v_nitem_no + 1;

          SELECT c_department_cde
            INTO v_department_cde
            FROM WEB_ORG_DPT
           WHERE c_dpt_cde = v_dpt_cde;

          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_flow_no,
             c_rp_type,
             c_ri_com,
             c_bal_type,
             c_bank_cde,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_department_cde,
             c_rcpt_no,
             c_cav_no)
          VALUES
            (vTmpVouNo,
             TO_CHAR(v_nitem_no),
             v_cav_flag,
             v_sbjt_no,
             '0',
             v_amt,
             v_amt,
             DECODE(v_cur_no,
                    '01',
                    'CNY',
                    '02',
                    'HKD',
                    '03',
                    'USD',
                    '12',
                    'EUR',
                    '13',
                    'EUR',
                    '05',
                    'JPY',
                    v_cur_no),
             1,
             NULL,
             v_today_tm,
             v_dptacc_cde,
             NULL,
             v_rp_type,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             v_kind_no,
             '0',
             NULL,
             v_dpt_cde,
             v_vou_memo,
             NULL,
             NULL,
             v_company_cde,
             NULL, /*c_bsns_typ*/
             '0',
             NULL,
             v_voucher_no,
             TO_CHAR(v_today_tm, 'YYYY-MM'),
             v_sum_amt,
             v_servicetype_no,
             v_department_cde,
             NULL,
             vTmpVouNo);

        END LOOP;
        CLOSE cur_gatherrcpt;

      END IF;

      UPDATE WEB_FIN_CLM_DUE
         SET n_rp_amt     = n_bs_amt,
             n_paid_amt   = n_bs_amt,
             t_paid_tm    = v_today_tm,
             t_rp_tm      = v_today_tm,
             c_accnt_flag = DECODE(c_accnt_flag,
                                   '01',
                                   '11',
                                   '00',
                                   '10',
                                   '10')
       WHERE c_batch_no = v_batch_no
         and t_crt_tm >=
             TO_DATE('2007-05-08 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and t_crt_tm <=
             TO_DATE('2008-06-05 23:59:59', 'YYYY-MM-DD HH24:MI:SS')
         AND n_rp_amt = 0
         AND n_paid_amt = 0;

      --Auto_Confirmed.ValidityCheckCavVou(vTmpVouNo,v_succsflag);--??????????0?????????

      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[Passescompensates ValidityCheckCavVou],??????[' ||
                         TO_CHAR(v_succsflag) || v_batch_no || v_dpt_cde ||
                         v_prod_no || v_cur_no ||
                         TO_CHAR(v_today_tm, 'YYYY-MM-DD') || v_dptacc_cde ||
                         v_vou_memo || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_gather;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        ROLLBACK;
        dbms_output.put_line('exception' || '*' || v_batch_no || SQLERRM);
        v_err_content := 'proc:[Passescompensates],??????[' ||
                         v_batch_no || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  Procedure NewPassesCompen IS
    v_dptacc_cde web_org_dpt.c_dptacc_cde%TYPE;
    v_dpt_cde    web_org_dpt.c_dpt_cde%TYPE;
    v_prod_no    WEB_FIN_PRM_DUE.c_prod_no%TYPE;
    v_pre_sum    WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
    v_edr_type   WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
    v_edr_no     WEB_FIN_PRM_DUE.c_edr_no%TYPE;
    v_ply_no     WEB_FIN_PRM_DUE.c_ply_no%TYPE;
    v_bal_tm     WEB_FIN_PRM_DUE.t_due_tm%TYPE;
    v_today_tm   web_FIN_DCR.t_crt_tm%TYPE;
    v_cav_flag   web_FIN_DCR.c_cav_flag%TYPE;
    v_cnt        INT;
    v_tmpcnt     INT;
    v_sbjt_no    WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_memo  WEB_FIN_MADCR.c_sbjt_memo%TYPE;
    v_vou_memo   WEB_FIN_MADCR.c_vou_memo%TYPE;
    vTmpVouNo    WEB_FIN_MADCR.c_seq_no%TYPE;
    vTmpVouNo1   WEB_FIN_MADCR.c_seq_no%TYPE;

    vSbjtNo       web_FIN_DCR.c_sbjt_no%TYPE;
    vCavFlag      web_FIN_DCR.C_CAV_FLAG%TYPE;
    v_feetyp_cde  WEB_FIN_PAY_DUE.c_feetyp_cde%TYPE;
    v_tran_flag   WEB_FIN_PAY_DUE.c_tran_flag%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.C_ERR_CONTENT%TYPE;
    v_seq_no      WEB_FIN_DCR.c_seq_no%TYPE;
    v_item_no     WEB_FIN_DCR.c_item_no%TYPE;

    vToday     VARCHAR(10);
    vBillToday VARCHAR(10);

    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;

    v_drcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_drsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_crsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_voucher_no  WEB_FIN_DCR.c_voucher_no%TYPE;
    v_period_name WEB_FIN_DCR.c_period_name%TYPE;
    v_rcpt_no     WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;

    v_cur_no      WEB_FIN_CAV_BILL.C_CUR_CDE%TYPE;
    v_sum_amt     WEB_FIN_CAV_BILL.n_sum_amt%TYPE;
    v_eac_dcm_mrk WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
    v_nitem_no    INT;
    v_pretyp_cde  WEB_FIN_CLM_DUE.c_pretyp_cde%TYPE;
    v_bala_mrk    WEB_FIN_CLM_DUE.c_bala_mrk%TYPE;
    v_batch_no    WEB_FIN_CLM_DUE.c_batch_no%TYPE;
    v_rp_type     web_fin_dcr_intf.c_rp_type%TYPE;
    v_amt         web_fin_dcr_intf.n_amt%TYPE;
    v_succsflag   INT;

    CURSOR cur_gather IS
      SELECT /*+ index (WEB_FIN_CLM_DUE IDX_FIN_CLMDUE_CRTTM)*/
      DISTINCT c_batch_no, c_dpt_cde
        FROM WEB_FIN_CLM_DUE a
       WHERE c_batch_no IS NOT NULL
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF')
         AND c_bala_mrk IN ('0', '2', '3')
         AND n_rp_amt = 0
         and t_crt_tm >=
             TO_DATE('2008-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and exists (select 1
                from web_fin_rpclmcustomer
               where c_bala_mrk = '6'
                 and c_capital_flows not in ('6', '7')
                 and c_rcpt_no = a.c_rcpt_no)
         AND n_paid_amt = 0;

    CURSOR cur_ifclmInfo IS
      SELECT c_dpt_cde,
             c_prod_no,
             c_ply_no,
             n_bs_amt,
             t_DUE_tm,
             c_rcpt_no,
             c_bs_cur,
             c_eac_dcm_mrk,
             c_bala_mrk,
             c_pretyp_cde
        FROM WEB_FIN_CLM_DUE a
       WHERE c_bala_mrk IN ('0', '2', '3')
         AND c_batch_no = v_batch_no
         AND c_batch_no IS NOT NULL
         AND n_rp_amt = 0
         and t_crt_tm >=
             TO_DATE('2008-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and exists (select 1
                from web_fin_rpclmcustomer
               where c_bala_mrk = '6'
                 and c_capital_flows not in ('6', '7')
                 and c_rcpt_no = a.c_rcpt_no)
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF');

    --??
    CURSOR cur_gatherrcpt IS
      SELECT c_cav_flag,
             c_sbjt_no,
             c_cur_no,
             c_dpt_cde,
             c_kind_no,
             SUM(n_amt),
             c_dptacc_no,
             c_vou_memo,
             c_company_cde,
             c_servicetype_no,
             c_rp_type
        FROM WEB_FIN_DCR
       WHERE c_seq_no = vTmpVouNo
         AND c_rcpt_no IS NOT NULL
       GROUP BY c_cav_flag,
                c_sbjt_no,
                c_cur_no,
                c_dpt_cde,
                c_kind_no,
                c_dptacc_no,
                c_vou_memo,
                c_company_cde,
                c_servicetype_no,
                c_rp_type;

    v_tmp_cnt  INT;
    v_end_time WEB_FIN_CLM_DUE.t_crt_tm%TYPE;

  BEGIN

    OPEN cur_gather;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_gather
        INTO v_batch_no, v_dpt_cde;
      EXIT WHEN cur_gather%NOTFOUND;

      SELECT SUM(n_bs_amt)
        INTO v_sum_amt
        FROM WEB_FIN_CLM_DUE a
       WHERE c_bala_mrk IN ('0', '2', '3')
         AND c_batch_no = v_batch_no
         AND c_batch_no IS NOT NULL
         and t_crt_tm >=
             TO_DATE('2008-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and exists (select 1
                from web_fin_rpclmcustomer
               where c_bala_mrk = '6'
                 and c_capital_flows not in ('6', '7')
                 and c_rcpt_no = a.c_rcpt_no)
         AND n_rp_amt = 0
         AND c_feetyp_cde IN ('CPDF', 'CPPK', 'CPYF');

      SELECT c_dptacc_cde
        INTO v_dptacc_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = v_dpt_cde;

      SELECT C_PERIOD_NAME
        INTO v_period_name
        FROM WEB_FIN_MONTHLYCLOSING
       WHERE c_dptacc_cde = v_dptacc_cde
         AND c_closing_flag = '1'; --??

      SELECT TRUNC(t_end_tm)
        INTO v_end_time
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = v_period_name;

      --???????????
      IF TO_CHAR(SYSDATE, 'YYYY-MM') <> v_period_name THEN
        v_today_tm := v_end_time;
      ELSE
        v_today_tm := SYSDATE;
      END IF;

      v_nitem_no := 2;

      --??
      OPEN cur_ifclmInfo;
      LOOP
        FETCH cur_ifclmInfo
          INTO v_dpt_cde, v_prod_no, v_ply_no, v_pre_sum, v_bal_tm, v_rcpt_no, v_cur_no, v_eac_dcm_mrk, v_bala_mrk, v_pretyp_cde;
        EXIT WHEN cur_ifclmInfo%NOTFOUND;

        SELECT c_department_cde, c_company_cde, c_dptacc_cde
          INTO v_department_cde, v_company_cde, v_dptacc_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = v_dpt_cde;

        --??????
        INSERT INTO WEB_FIN_CAV_DOC
          (N_ITEM_NO,
           C_CAV_PK_ID,
           c_rcpt_no,
           c_ply_no,
           c_edr_no,
           --c_rp_cur,
           -- n_get_prm,
           n_exch_rate,
           --n_paid_amt,
           -- n_exchgot_prm,
           t_insrnc_bgn_tm,
           t_insrnc_end_tm,
           c_prod_no,
           c_sls_cde,
           c_cha_cls,
           c_cha_cde,
           C_PAYER_CDE,
           c_dpt_cde,
           c_feetyp_cde,
           C_SLSGRP_CDE,
           c_bsns_typ,
           C_PAYER_NME,
           c_bs_cur,
           n_bs_amt,
           c_rp_cur,
           n_rp_amt)
          SELECT TO_CHAR(v_nitem_no),
                 v_batch_no,
                 c_rcpt_no,
                 c_ply_no,
                 c_clm_no,
                 --c_bs_cur,
                 --n_bs_amt,
                 1,
                 -- n_bs_amt,
                 -- n_bs_amt,
                 t_insrnc_bgn_tm,
                 t_insrnc_end_tm,
                 c_prod_no,
                 NULL,
                 NULL,
                 NULL,
                 NULL,
                 c_dpt_cde,
                 NULL,
                 NULL,
                 c_bsns_typ,
                 ' ',
                 c_bs_cur,
                 n_bs_amt,
                 c_bs_cur,
                 n_bs_amt
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

        --?????
        --Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7');
        vTmpVouNo := v_batch_no;
        SELECT c_kind_no
          INTO v_kind_no
          FROM WEB_BAS_FIN_PROD
         WHERE c_prod_no = v_prod_no;

        v_drcav_flag := '?';
        v_crcav_flag := '?';

        /*
        113101????/????
        113102????/????
        113103????/????
        113104????/????
        */

        IF v_eac_dcm_mrk = '1' THEN

          IF v_pretyp_cde IS NULL THEN
            v_drsbjt_no := '113101'; --??????????  ?????????
          ELSIF v_pretyp_cde = '0' THEN
            v_drsbjt_no := '113101';
          ELSIF v_pretyp_cde = '1' THEN
            v_drsbjt_no := '113101';
          ELSIF v_pretyp_cde = '2' THEN
            v_drsbjt_no := '113102'; --1?????
          ELSIF v_pretyp_cde = '3' THEN
            v_drsbjt_no := '113103';
          ELSIF v_pretyp_cde = '4' THEN
            v_drsbjt_no := '113104';
          END IF;

          v_vou_memo       := '??????';
          v_servicetype_no := '1107';
          v_rp_type        := '204';
        ELSIF v_eac_dcm_mrk = '2' THEN
          v_drsbjt_no      := '215001'; --????
          v_vou_memo       := '????';
          v_servicetype_no := '1108';
          v_rp_type        := '205';
        ELSIF v_eac_dcm_mrk = '5' THEN
          --5 ???
          v_drsbjt_no      := '440104';
          v_vou_memo       := '????';
          v_servicetype_no := '1108';
          v_rp_type        := '204';
        ELSIF v_eac_dcm_mrk = '6' THEN
          --5 ???
          v_drsbjt_no      := '440104';
          v_vou_memo       := '????';
          v_servicetype_no := '1108';
          v_rp_type        := '204';
        END IF;

        --0 ???? 1 ??/??/?? 2 ????
        /*
        IF v_bala_mrk='0' THEN
            v_crsbjt_no:='119301';
        ELSE
            v_crsbjt_no:='100102';
        END IF;
        */
        v_crsbjt_no := '119301';

        INSERT INTO WEB_FIN_DCR
          (C_SEQ_NO,
           C_ITEM_NO,
           C_CAV_FLAG,
           C_SBJT_NO,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           C_DPTACC_NO,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_ply_no,
           c_cha_mrk,
           c_vou_memo,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde,
           c_sbjt_memo,
           c_period_name,
           c_voucher_no,
           n_total_amt,
           c_cav_no,
           c_rp_type)
          SELECT vTmpVouNo,
                 TO_CHAR(v_nitem_no),
                 v_drcav_flag,
                 v_drsbjt_no,
                 v_pre_sum,
                 c_bs_cur,
                 v_today_tm,
                 v_dptacc_cde,
                 c_dpt_cde,
                 c_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 c_insrnt_cde,
                 NULL,
                 NULL,
                 v_voucher_no,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 c_ply_no,
                 c_cha_mrk,
                 v_vou_memo,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde,
                 '0',
                 TO_CHAR(v_today_tm, 'YYYY-MM'),
                 v_voucher_no,
                 v_sum_amt,
                 vTmpVouNo,
                 v_rp_type
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

        IF v_nitem_no = '2' THEN
          v_period_name := TO_CHAR(v_today_tm, 'yyyy-mm');
          Dz_Proc.get_fin_voucode(v_voucher_no,
                                  v_period_name,
                                  v_company_cde,
                                  dz_proc.g_pttype);

          --?????
          INSERT INTO WEB_FIN_CAV_BILL
            (c_dpt_cde,
             c_rp_type,
             C_CUR_CDE,
             n_sum_amt,
             c_oper_cde,
             t_cav_tm,
             t_upd_tm,
             C_CAV_PK_ID,
             c_check_cde,
             t_check_tm,
             c_check_memo,
             c_check_flag)
          VALUES
            (v_dptacc_cde,
             v_rp_type,
             v_cur_no,
             v_sum_amt,
             'admin',
             v_today_tm,
             v_today_tm,
             v_batch_no,
             'admin',
             v_today_tm,
             '??',
             '2');
          /*??????*/
          /*wpc begin  WEB_FIN_CAV_BILL ?WEB_FIN_RPTYP???*/
          INSERT INTO WEB_FIN_CAV_RPTYP
            (C_CAVRPTYP_PK_ID,
             C_CAV_PK_ID,
             N_ITEM_NO,
             C_RP_TYPE,
             C_CUR_CDE,
             N_SUM_AMT,
             C_REPLACE_FLAG,
             C_CRT_CDE,
             T_CRT_TM,
             C_UPD_CDE,
             T_UPD_TM)
          VALUES
            (v_batch_no,
             v_batch_no,
             v_nitem_no,
             v_rp_type,
             v_cur_no,
             v_sum_amt,
             '0',
             'admin',
             v_today_tm,
             'admin',
             v_today_tm);
          /* wpc end*/
          --???????(??????)
          --IF v_bala_mrk='0' THEN
          INSERT INTO WEB_FIN_CAV_OBJ

            (C_CAV_PK_ID,
             n_item_no,
             c_sbjt_no,
             n_amt,
             C_CUR_CDE,
             C_CAV_DIR,
             c_dpt_cde,
             c_sls_cde,
             c_prod_no,
             c_cha_cls,
             c_cha_cde,
             C_PAYER_NME,
             n_pre_amt,

             -- N_ITEM_NO,
             c_pre_flag,
             c_bsns_typ,
             C_CURT_DPT_CDE)
            SELECT v_batch_no,
                   '1',
                   '119301',
                   v_sum_amt,
                   c_bs_cur,
                   '??',
                   c_dpt_cde,
                   c_sls_cde,
                   c_prod_no,
                   c_cha_cls,
                   c_cha_cde,
                   'admin',
                   v_sum_amt,

                   --'1',
                   '1',
                   c_bsns_typ,
                   NULL
              FROM WEB_FIN_CLM_DUE
             WHERE c_rcpt_no = v_rcpt_no;
          --ELSE -- ??
          /*
              INSERT INTO WEB_FIN_CAV_MNY
              (
                c_cav_no         ,
                c_item_no        ,
                c_bal_type       ,
                n_amt            ,
                n_use_amt        ,
                c_cur_no         ,
                c_pay_name       ,
                c_bank_cde       ,
                c_check_no       ,
                t_rp_tm          ,
                c_flow_no        ,
                c_bank_name      ,
                c_bank_accnt     ,
                c_rp_name        ,
                c_feetyp_cde     ,
                c_sbjt_no        ,
                c_savecash_bank  ,
                t_savecash_tm    ,
                c_savecash_no    ,
                c_savecash_opt   ,
                c_formafee_no    ,
                c_check_flag
              )
              SELECT
                v_batch_no         ,
                '1'        ,
                '00200'          ,
                v_sum_amt            ,
                v_sum_amt        ,
                c_cur_typ         ,
                'admin',
                null       ,
                null       ,
                v_today_tm          ,
                null        ,
                null      ,
                null     ,
                SUBSTR(c_pay_name,1,20)        ,
                null     ,
                '100102'        ,
                null  ,
                null    ,
                null    ,
                null   ,
                null    ,
                '0'
              FROM WEB_FIN_CLM_DUE
              WHERE c_rcpt_no=v_rcpt_no;
          */
          --END IF;

          INSERT INTO WEB_FIN_DCR
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_SEND_FLAG,
             c_sbjt_memo,
             c_kind_no,
             c_department_cde,
             c_company_cde,
             c_period_name,
             c_vou_memo,
             c_voucher_no,
             c_vou_no,
             n_total_amt,
             c_cav_no,
             c_rp_type)
            SELECT vTmpVouNo,
                   '1',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_sum_amt,
                   c_bs_cur,
                   v_today_tm,
                   v_dptacc_cde,

                   '0',
                   v_sbjt_memo,
                   '0',
                   '0',
                   v_company_cde,
                   TO_CHAR(v_today_tm, 'YYYY-MM'),
                   v_vou_memo,
                   v_voucher_no,
                   v_voucher_no,
                   v_sum_amt,
                   vTmpVouNo,
                   v_rp_type
              FROM WEB_FIN_CLM_DUE
             WHERE c_rcpt_no = v_rcpt_no;

        END IF;

        v_nitem_no := v_nitem_no + 1;

      END LOOP;
      CLOSE cur_ifclmInfo;

      IF v_nitem_no <> 1 THEN
        --?????
        --????????
        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_department_cde,
           c_rcpt_no,
           c_cav_no)
          SELECT c_seq_no,
                 '1',
                 c_cav_flag,
                 c_sbjt_no,
                 '0',
                 n_amt,
                 n_exch_amt,
                 DECODE(c_cur_no,
                        '01',
                        'CNY',
                        '02',
                        'HKD',
                        '03',
                        'USD',
                        '12',
                        'EUR',
                        '13',
                        'EUR',
                        '05',
                        'JPY',
                        c_cur_no),
                 n_rate,
                 c_chr_cur_no,
                 t_crt_tm,
                 c_dptacc_no,
                 c_flow_no,
                 v_rp_type,
                 c_ri_com,
                 c_bal_type,
                 NULL,
                 c_check_no,
                 t_rp_tm,
                 c_kind_no,
                 '0',
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 c_salegrp_cde, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 c_voucher_no,
                 c_period_name,
                 v_sum_amt,
                 v_servicetype_no,
                 c_department_cde,
                 c_rcpt_no,
                 vTmpVouNo
            FROM WEB_FIN_DCR
           WHERE c_seq_no = vTmpVouNo
             AND c_item_no = '1';

        UPDATE WEB_FIN_DCR
           SET c_voucher_no = v_voucher_no, c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        UPDATE web_fin_dcr_intf
           SET c_vou_no = v_voucher_no
         WHERE c_seq_no = vTmpVouNo;

        --????

        v_nitem_no := 1;
        OPEN cur_gatherrcpt;
        LOOP
          <<GOTO_LAB>>
          FETCH cur_gatherrcpt
            INTO v_cav_flag, v_sbjt_no, v_cur_no, v_dpt_cde, v_kind_no, v_amt, v_dptacc_cde, v_vou_memo, v_company_cde, v_servicetype_no, v_rp_type;
          EXIT WHEN cur_gatherrcpt%NOTFOUND;

          v_nitem_no := v_nitem_no + 1;

          SELECT c_department_cde
            INTO v_department_cde
            FROM WEB_ORG_DPT
           WHERE c_dpt_cde = v_dpt_cde;

          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_flow_no,
             c_rp_type,
             c_ri_com,
             c_bal_type,
             c_bank_cde,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_department_cde,
             c_rcpt_no,
             c_cav_no)
          VALUES
            (vTmpVouNo,
             TO_CHAR(v_nitem_no),
             v_cav_flag,
             v_sbjt_no,
             '0',
             v_amt,
             v_amt,
             DECODE(v_cur_no,
                    '01',
                    'CNY',
                    '02',
                    'HKD',
                    '03',
                    'USD',
                    '12',
                    'EUR',
                    '13',
                    'EUR',
                    '05',
                    'JPY',
                    v_cur_no),
             1,
             NULL,
             v_today_tm,
             v_dptacc_cde,
             NULL,
             v_rp_type,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             v_kind_no,
             '0',
             NULL,
             v_dpt_cde,
             v_vou_memo,
             NULL,
             NULL,
             v_company_cde,
             NULL, /*c_bsns_typ*/
             '0',
             NULL,
             v_voucher_no,
             TO_CHAR(v_today_tm, 'YYYY-MM'),
             v_sum_amt,
             v_servicetype_no,
             v_department_cde,
             NULL,
             vTmpVouNo);

        END LOOP;
        CLOSE cur_gatherrcpt;

      END IF;

      UPDATE WEB_FIN_CLM_DUE a
         SET n_rp_amt     = n_bs_amt,
             n_paid_amt   = n_bs_amt,
             t_paid_tm    = v_today_tm,
             t_rp_tm      = v_today_tm,
             c_accnt_flag = DECODE(c_accnt_flag,
                                   '01',
                                   '11',
                                   '00',
                                   '10',
                                   '10')
       WHERE c_batch_no = v_batch_no
         and t_crt_tm >=
             TO_DATE('2008-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
         and exists (select 1
                from web_fin_rpclmcustomer
               where c_bala_mrk = '6'
                 and c_capital_flows not in ('6', '7')
                 and c_rcpt_no = a.c_rcpt_no)
         AND n_rp_amt = 0
         AND n_paid_amt = 0;

      --Auto_Confirmed.ValidityCheckCavVou(vTmpVouNo,v_succsflag);--??????????0?????????

      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[NewPassesCompen ValidityCheckCavVou],??????[' ||
                         TO_CHAR(v_succsflag) || v_batch_no || v_dpt_cde ||
                         v_prod_no || v_cur_no ||
                         TO_CHAR(v_today_tm, 'YYYY-MM-DD') || v_dptacc_cde ||
                         v_vou_memo || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_gather;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        ROLLBACK;
        dbms_output.put_line('exception' || '*' || v_batch_no || SQLERRM);
        v_err_content := 'proc:[NewPassesCompen],??????[' ||
                         v_batch_no || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  --?????? (????handlingcharge????)
  PROCEDURE ClearPrize IS
    --????
    v_dpt_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%type;

  BEGIN
    --return; --????20090216
    /*
        ????????????????
         A.????:
          1.?????,??????.
         B.????:
        1.?????:
        (1)?2008?10?9??(?10?9?)?????????????=???????+??????
        (2)?2008?10?9???????????????=???????
        --?2009?6?9?????????0?????????

        2.??????????
        (1)?2008?10?1??(?10?1?)?????????????=???????+??????
        (2)?2008?10?1???????????????=???????

      ??:
    and  exists (select 1 from t_department where b.c_dpt_cde=t_department.c_dpt_cde
    and c_ctct_Cde not in ('014002','014003','014005','014006','014007','014012','014013','014015')
    and (c_grant_dpt_cde like 'S%' or c_grant_dpt_cde like 'X%' )
    )

      and b.c_ctct_Cde not in ('014002','014003','014005','014006','014007','014012','014013','014015')
      and (b.c_grant_dpt_cde like 'S%' or b.c_grant_dpt_cde like 'X%' )
      */

    --?????????????????????????

    INSERT INTO web_FIN_PAY_DUE
      (C_DPT_CDE,
       C_DPTACC_CDE,
       C_PLY_NO,
       C_APP_NO,
       C_EDR_NO,
       T_INSRNC_BGN_TM,
       T_INSRNC_END_TM,
       N_TMS,
       C_TRAN_FLAG,
       C_FEETYP_CDE,
       C_LONGSHORT_FLAG,
       C_PROD_NO,
       C_CLNT_MRK,
       C_BSNS_TYP,
       C_BS_CUR,
       N_BS_AMT,
       C_DUE_CUR,
       N_DUE_AMT,
       T_DUE_TM,
       C_PAYER_CDE,
       C_PAYER_NME,
       C_BALA_MRK,
       C_BANK_ACCOUNT,
       C_SLSGRP_CDE,
       C_SLS_CDE,
       C_CHA_MRK,
       C_CHA_CLS,
       C_CHA_CDE,
       C_APP_NME,
       C_CRT_CDE,
       T_CRT_TM,
       C_ACCNT_FLAG,
       C_RCPT_NO)
      select

       a.C_DPT_CDE,
       (select C_DPTACC_CDE from WEB_ORG_DPT WHERE C_DPT_CDE = A.C_DPT_CDE),
       A.C_PLY_NO,
       null,
       A.C_EDR_NO,
       a.T_INSRNC_BGN_TM,
       a.T_INSRNC_END_TM,
       a.N_TMS,
       '1', --,a.C_TRAN_FLAG       ,
       'S',
       '1',
       a.C_PROD_NO,
       null,
       a.C_BSNS_TYP,
       '01',
       a.n_slsfee,
       '01',
       a.n_slsfee,
       trunc(a.d_change_dte),
       (SELECT c_app_cde
          FROM WEB_PLY_APPLICANT
         WHERE C_PLY_NO = a.c_ply_no
           and rownum = 1),
       (SELECT c_app_nme
          FROM WEB_PLY_APPLICANT
         WHERE C_PLY_NO = a.c_ply_no
           and rownum = 1),
       '0',
       null,
       null,
       a.C_SLS_CDE,
       null,
       null,
       null,
       (SELECT c_app_nme
          FROM WEB_PLY_APPLICANT
         WHERE C_PLY_NO = a.c_ply_no
           and rownum = 1),
       'admin',
       trunc(a.d_change_dte),
       '00',
       a.c_seq_no || a.c_item_no
        from rpt_fin_gotfee a, web_ply_base b
       WHERE a.c_ply_no = b.c_ply_no
         and a.n_slsfee <> 0
         AND a.d_change_dte >= TO_DATE('2008-10-01', 'YYYY-MM-DD')
         AND a.t_udr_date >= TO_DATE('2008-10-09', 'YYYY-MM-DD')
         AND a.d_change_dte >= SYSDATE - 19
         and not exists
       (select 1
                from rpt_fin_gotfee
               where n_fees = 0
                 and n_slsfee <> 0
                 and c_prod_no in ('0316', '0320')
                 and t_udr_date >= TO_DATE('2009-06-09', 'YYYY-MM-DD')
                 and c_ply_no = a.c_ply_no)
         and not exists (select 1
                from web_fin_pay_due
               where c_rcpt_no = a.c_seq_no || a.c_item_no)
         and exists
       (select 1
                from web_org_dpt
               where b.c_dpt_cde = web_org_dpt.c_dpt_cde
                 and c_dpt_attr not in
                     ('014002', '014003', '014005', '014006', '014007',
                      '014012', '014013', '014015')
                 and (c_grant_dpt_cde like 'S%' or c_grant_dpt_cde like 'X%'));
    --wpc ?rpt_fin_gotfee??

    --?????????????????????????

    INSERT INTO web_FIN_PAY_DUE
      (

       C_DPT_CDE,
       C_DPTACC_CDE,
       C_PLY_NO,
       C_APP_NO,
       C_EDR_NO,
       T_INSRNC_BGN_TM,
       T_INSRNC_END_TM,
       N_TMS,
       C_TRAN_FLAG,
       C_FEETYP_CDE,
       C_LONGSHORT_FLAG,
       C_PROD_NO,
       C_CLNT_MRK,
       C_BSNS_TYP,
       C_BS_CUR,
       N_BS_AMT,
       C_DUE_CUR,
       N_DUE_AMT,
       T_DUE_TM,
       C_PAYER_CDE,
       C_PAYER_NME,
       C_BALA_MRK,
       C_BANK_ACCOUNT,
       C_SLSGRP_CDE,
       C_SLS_CDE,
       C_CHA_MRK,
       C_CHA_CLS,
       C_CHA_CDE,
       C_APP_NME,
       C_CRT_CDE,
       T_CRT_TM,
       C_ACCNT_FLAG,
       C_RCPT_NO)
      select

       a.C_DPT_CDE,
       (select C_DPTACC_CDE from WEB_ORG_DPT WHERE C_DPT_CDE = A.C_DPT_CDE),
       A.C_PLY_NO,
       null,
       A.C_EDR_NO,
       a.T_INSRNC_BGN_TM,
       a.T_INSRNC_END_TM,
       a.N_TMS,
       '1', --,a.C_TRAN_FLAG       ,
       'S',
       '1',
       a.C_PROD_NO,
       null,
       a.C_BSNS_TYP,
       '01',
       a.n_slsfee,
       '01',
       a.n_slsfee,
       trunc(a.d_change_dte),
       (SELECT c_app_cde
          FROM WEB_PLY_APPLICANT
         WHERE C_PLY_NO = a.c_ply_no
           and rownum = 1),
       (SELECT c_app_nme
          FROM WEB_PLY_APPLICANT
         WHERE C_PLY_NO = a.c_ply_no
           and rownum = 1),
       '0',
       null,
       null,
       a.C_SLS_CDE,
       null,
       null,
       null,
       (SELECT c_app_nme
          FROM WEB_PLY_APPLICANT
         WHERE C_PLY_NO = a.c_ply_no
           and rownum = 1),
       'admin',
       trunc(a.d_change_dte),
       '00',
       a.c_seq_no || a.c_item_no
        from rpt_fin_gotfee a, web_ply_base b
       WHERE a.c_ply_no = b.c_ply_no
         and a.n_slsfee <> 0
         AND a.d_change_dte >= TO_DATE('2008-10-01', 'YYYY-MM-DD')
         AND a.d_change_dte >= SYSDATE - 19
         AND a.t_udr_date >= TO_DATE('2008-10-01', 'YYYY-MM-DD')
         AND a.t_udr_date <= TO_DATE('2008-10-09', 'YYYY-MM-DD')
            --AND b.c_prod_no NOT in ('0316','0325')
         AND b.c_prod_no NOT in ('0316', '0320')
         and not exists (select 1
                from web_fin_pay_due
               where c_rcpt_no = a.c_seq_no || a.c_item_no)
         and exists
       (select 1
                from web_org_dpt
               where b.c_dpt_cde = web_org_dpt.c_dpt_cde
                 and c_dpt_attr not in
                     ('014002', '014003', '014005', '014006', '014007',
                      '014012', '014013', '014015')
                 and (c_grant_dpt_cde like 'S%' or c_grant_dpt_cde like 'X%'));

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[ClearPrize],??????[' || v_dpt_cde ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;
  --????????
  PROCEDURE Autorpprm

   IS
    --v_PRMDUE_PK_ID  WEB_FIN_PRM_DUE.C_PRMDUE_PK_ID%TYPE;

    v_dptacc_cde   WEB_FIN_PRM_DUE.c_dptacc_cde%TYPE;
    v_crt_tm       WEB_FIN_PRM_DUE.t_crt_tm%TYPE;
    v_bs_amt       WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
    v_bs_cur       WEB_FIN_PRM_DUE.c_bs_cur%TYPE;
    v_bank_account WEB_FIN_PRM_DUE.c_bank_account%TYPE; --????
    v_bfn_no       WEB_FIN_PRM_DUE.c_bfn_no%TYPE;
    v_print_no     web_pay_confirm_info.c_print_no%TYPE; --?????

    v_rcpt_no     WEB_FIN_PRM_DUE.C_RCPT_NO%TYPE;
    v_rp_type     WEB_FIN_CAV_BILL.C_RP_TYPE%TYPE;
    v_batch_no    WEB_FIN_SAVEAMT_DUE.c_batch_no%TYPE;
    v_bs_amt1     WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
    v_dpt_cde     WEB_FIN_PRM_DUE.c_dpt_cde%TYPE;
    v_prod_no     WEB_FIN_PRM_DUE.c_prod_no%TYPE;
    v_other_amt   WEB_FIN_PRM_DUE.N_OTHER_AMT%TYPE;
    v_vou_no      WEB_FIN_DCR.C_VOU_NO%TYPE; --???
    v_period_name WEB_FIN_MONTHLYCLOSING.C_PERIOD_NAME%TYPE; --????
    V_CHA_CLS     WEB_FIN_PRM_DUE.C_CHA_CLS%TYPE;
    V_CHA_CDE     WEB_FIN_PRM_DUE.C_CHA_CDE%TYPE;
    v_sls_cde     WEB_FIN_PRM_DUE.C_SLS_CDE%TYPE;

    v_company_cde WEB_ORG_DPT.c_Company_Cde%TYPE;

    v_accnt_flag web_fin_prm_due.c_accnt_flag%TYPE; --????

    v_mny_sbjt_no    web_fin_cav_mny.c_sbjt_no%TYPE;
    v_bank_cde       web_fin_cav_mny.c_bank_cde%TYPE;
    v_bank_nme       WEB_BAS_FIN_BANK.c_Bank_Nme%TYPE;
    v_flow_cde       web_bas_fin_cash_flow.c_flow_cde%TYPE;
    v_total_amt      web_fin_dcr.n_total_amt%TYPE;
    V_CAVRPTYP_PK_ID web_fin_cav_rptyp.c_cavrptyp_pk_id%TYPE;
    v_department_cde web_fin_dcr.c_department_cde%TYPE;

    CURSOR cur_bill IS --WEB_FIN_CAV_BILL?WEB_FIN_CAV_RPTYP
    --??????????????????
      select a.c_dptacc_cde,
             to_date(to_char(a.t_crt_tm, 'YYYY-MM-DD'), 'YYYY-MM-DD'),
             a.c_bs_cur,
             a.c_bank_account,
             sum(n_bs_amt),
             sum(NVL(a.n_other_amt, 0))
        from WEB_FIN_PRM_DUE a, web_pay_confirm_info b
       WHERE a.C_RCPT_NO = b.C_UNIQUE_NO
         and a.T_CRT_TM >= to_date('2009-06-01', 'YYYY-MM-DD')
         and a.T_CRT_TM <= to_date('2009-06-15', 'YYYY-MM-DD')
         and a.c_bala_mrk = '0'
         and a.c_bank_account is not null
         AND a.c_accnt_flag IN ('00', '01')
         and c_accnt_flag in ('01', '00') --??????
       GROUP BY a.c_dptacc_cde,
                to_char(a.t_crt_tm, 'YYYY-MM-DD'),
                a.c_bs_cur,
                a.c_bank_account
       order BY a.c_dptacc_cde,
                to_char(a.t_crt_tm, 'YYYY-MM-DD'),
                a.c_bs_cur;

    CURSOR cur_doc is --WEB_FIN_CAV_DOC?MNY?OBJ?DCR
      select a.c_rcpt_no,
             a.c_cha_cls,
             a.c_cha_cde,
             a.c_sls_cde,
             a.c_dpt_cde,
             a.c_prod_no,
             to_date(to_char(a.t_crt_tm, 'YYYY-MM-DD'), 'YYYY-MM-DD'),
             a.n_bs_amt,
             a.n_other_amt,
             a.c_bs_cur,
             a.c_bank_account,
             NVL(a.n_other_amt, 0)
        from WEB_FIN_PRM_DUE a, web_pay_confirm_info b
       WHERE a.c_rcpt_no = b.C_UNIQUE_NO
            --and a.T_CRT_TM >=to_date('2009-06-05','YYYY-MM-DD')
            --and a.T_CRT_TM <=to_date('2009-06-05','YYYY-MM-DD')
         and a.c_dptacc_cde = b.C_REG_DPT_CDE
         AND a.t_crt_tm >=
             to_date(to_char(v_crt_tm, 'YYYY-MM-DD') || ' 00:00:00',
                     'yyyy-mm-dd hh24:mi:ss')
         AND a.t_crt_tm <=
             to_date(to_char(v_crt_tm, 'YYYY-MM-DD') || ' 23:59:59',
                     'yyyy-mm-dd hh24:mi:ss')
         and a.c_bs_cur = b.C_CUR_NO
         and a.c_bala_mrk = '0'
         and a.c_bank_account is not null
         AND a.c_accnt_flag IN ('00', '01')
         and c_accnt_flag in ('01', '00') --??????
         and c_accnt_flag in ('01', '00') --??????
         AND a.c_bank_account = v_bank_account --????
            --AND a.C_bfn_no=v_bfn_no
            --AND b.c_print_no=v_print_no
         and a.c_bala_mrk = '0';
    v_err_content web_bas_fin_errorlog.c_err_content%TYPE;
    v_nitem_no    int;
    v_temp_cnt    int;
  BEGIN

    OPEN cur_bill;
    LOOP
      FETCH cur_bill
        INTO v_dptacc_cde, v_crt_tm, v_bs_cur, v_bank_account, v_bs_amt, v_other_amt;
      EXIT WHEN cur_bill%NOTFOUND;
      --???????
      v_total_amt := v_bs_amt + v_other_amt;

      UPDATE WEB_FIN_PRM_DUE a
         SET N_RP_AMT     = N_BS_AMT,
             n_paid_amt   = N_BS_AMT,
             T_PAID_TM    = v_crt_tm,
             T_RP_TM      = v_crt_tm,
             c_accnt_flag = DECODE(c_accnt_flag,
                                   '01',
                                   '11',
                                   '00',
                                   '10',
                                   '10')
       WHERE t_crt_tm >=
             to_date(to_char(v_crt_tm, 'YYYY-MM-DD') || ' 00:00:00',
                     'yyyy-mm-dd hh24:mi:ss')
         AND t_crt_tm <=
             to_date(to_char(v_crt_tm, 'YYYY-MM-DD') || ' 23:59:59',
                     'yyyy-mm-dd hh24:mi:ss')
         and c_dptacc_cde = v_dptacc_cde
         AND c_bank_account = v_bank_account
         and c_bs_cur = v_bs_cur
         and a.c_bala_mrk = '0'
         and a.c_bank_account is not null
         AND A.c_accnt_flag IN ('00', '01')
         and c_accnt_flag in ('01', '00');

      select c_dpt_cde
        into v_dpt_cde
        from web_fin_prm_due
       where c_dptacc_cde = v_dptacc_cde
         AND t_crt_tm >=
             to_date(to_char(v_crt_tm, 'YYYY-MM-DD') || ' 00:00:00',
                     'yyyy-mm-dd hh24:mi:ss')
         AND t_crt_tm <=
             to_date(to_char(v_crt_tm, 'YYYY-MM-DD') || ' 23:59:59',
                     'yyyy-mm-dd hh24:mi:ss')
         and c_bs_cur = v_bs_cur
         and rownum = 1
         and c_bank_account = v_bank_account;

      --???????
      dz_proc.get_fin_cav_no(v_batch_no, v_dpt_cde, '5', dz_proc.g_pttype);

      v_nitem_no := 1;
      IF v_bank_account = '1' THEN
        v_rp_type := '111';
      ELSE
        IF v_bank_account = '2' THEN
          v_rp_type := '112';
        ELSE
          v_rp_type := '101';
        END IF;
      END IF;

      INSERT INTO WEB_FIN_CAV_BILL
        (C_CAV_PK_ID,
         c_dpt_cde,
         c_crt_cde,
         c_upd_cde,
         c_rp_type,
         C_CUR_CDE,
         n_sum_amt,
         c_oper_cde,
         T_CAV_TM,
         T_CRT_TM,
         t_upd_tm,
         c_check_cde,
         T_CHECK_TM,
         c_check_flag,
         C_CHECK_MEMO)
      values
        (v_batch_no,
         v_dptacc_cde,
         'admin',
         'admin',
         v_rp_type,
         v_bs_cur,
         v_total_amt,
         'admin',
         sysdate,
         v_crt_tm,
         sysdate,
         'admin',
         v_crt_tm,
         '2',
         '??');

      V_CAVRPTYP_PK_ID := v_batch_no || '_' || TO_CHAR(v_nitem_no);

      INSERT INTO WEB_FIN_CAV_RPTYP
        (C_CAVRPTYP_PK_ID,
         C_CAV_PK_ID,
         N_ITEM_NO,
         C_RP_TYPE,
         C_CUR_CDE,
         N_SUM_AMT,
         C_REPLACE_FLAG,
         C_CRT_CDE,
         T_CRT_TM,
         C_UPD_CDE,
         T_UPD_TM)
      VALUES
        (V_CAVRPTYP_PK_ID,
         v_batch_no,
         v_nitem_no,
         v_rp_type,
         v_bs_cur,
         v_total_amt,
         '0',
         'admin',
         v_crt_tm,
         'admin',
         sysdate);

      OPEN cur_doc;
      LOOP
        FETCH CUR_DOC
          INTO v_rcpt_no, V_CHA_CLS, V_CHA_CDE, v_sls_cde, v_dpt_cde, v_prod_no, v_crt_tm, v_bs_amt, v_other_amt, v_bs_cur, v_bank_account, v_other_amt;
        EXIT WHEN CUR_DOC%NOTFOUND;

        --?????
        v_total_amt := v_bs_amt + v_other_amt;

        -- ??????????
        SELECT count(1)
          INTO v_temp_cnt
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = v_Dpt_Cde;
        IF v_temp_cnt = 0 THEN

          RETURN;
        END IF;
        --?????
        select NVL(c_accnt_flag, 00)
          into v_accnt_flag
          from web_fin_prm_due
         where c_rcpt_no = v_rcpt_no;

        IF v_accnt_flag <> '10' and v_accnt_flag <> '11' THEN

          --???????
          update web_fin_prm_due
             set c_accnt_flag = c_accnt_flag + 10, --????
                 t_rp_tm      = sysdate,
                 t_paid_tm    = sysdate,
                 n_rp_amt     = v_bs_amt,
                 n_paid_amt   = v_bs_amt
           WHERE c_rcpt_no = v_rcpt_no;

          --??????
          INSERT INTO WEB_FIN_CAV_DOC
            (

             N_ITEM_NO,
             C_CAV_PK_ID,
             c_rcpt_no,
             c_ply_no,
             c_edr_no,
             n_exch_rate,
             t_insrnc_bgn_tm,
             t_insrnc_end_tm,
             c_prod_no,
             c_sls_cde,
             c_cha_cls,
             c_cha_cde,
             C_PAYER_CDE,
             c_dpt_cde,
             c_feetyp_cde,
             C_SLSGRP_CDE,
             c_bsns_typ,
             C_PAYER_NME,
             c_bs_cur,
             n_bs_amt,
             n_rp_prm, --?????
             N_ORIG_CUR_AMT,
             N_ORIG_PRM,
             C_CRT_CDE,
             C_UPD_CDE,
             c_rp_cur,
             n_rp_amt,
             t_crt_tm,
             t_upd_tm,
             c_bill_flag,
             C_CLNT_MRK)
            select

             v_nitem_no,
             v_batch_no,
             c_rcpt_no,
             c_ply_no,
             c_edr_no,
             1,
             t_insrnc_bgn_tm,
             t_insrnc_end_tm,
             c_prod_no,
             v_sls_cde,
             V_CHA_CLS,
             V_CHA_CDE,
             C_PAYER_CDE,
             c_dpt_cde,
             c_feetyp_cde,
             C_SLSGRP_CDE,
             c_bsns_typ,
             C_PAYER_NME,
             c_bs_cur,
             n_bs_amt,
             n_bs_amt,
             n_bs_amt,
             n_bs_amt,
             'admin',
             'admin',
             v_bs_cur,
             n_bs_amt,
             sysdate,
             sysdate,
             c_tran_flag,
             '1'
              from web_fin_prm_due
             where c_rcpt_no = v_rcpt_no;

          IF v_other_amt <> 0 THEN

            INSERT INTO WEB_FIN_CAV_OBJ --????
              (n_item_no,
               c_dpt_cde,
               c_sbjt_no,
               n_amt,
               c_crt_cde,
               T_CRT_TM,
               C_UPD_CDE,
               T_UPD_TM,
               c_prod_no,
               C_CAV_PK_ID,
               C_CUR_CDE,
               c_cav_dir,
               c_sls_cde,
               c_cha_cls,
               c_cha_cde,
               C_PAYER_NME,
               n_pre_amt,

               c_pre_flag,
               c_bsns_typ,
               C_CURT_DPT_CDE)
              SELECT v_nitem_no,
                     c_dpt_cde,
                     '119113', --???
                     v_other_amt,
                     'admin',
                     sysdate,
                     'admin',
                     SYSDATE,
                     '0320',
                     v_batch_no,
                     C_BS_CUR,
                     '1', --'??'
                     v_sls_cde,
                     v_cha_cls,
                     v_cha_cde,
                     C_PAYER_NME,
                     v_other_amt,

                     '1',
                     c_bsns_typ,
                     NULL
                from web_fin_prm_due
               where c_rcpt_no = v_rcpt_no;
          END IF;

          --?????????
          SELECT C_BANK_CDE, c_sbjt_no, c_bank_nme
            INTO v_bank_cde, v_mny_sbjt_no, v_bank_nme
            FROM WEB_BAS_FIN_BANK
           WHERE c_dpt_cde = v_dptacc_cde
             and enabled_flag = 'Y'
             and c_rp_flag = '05'
             AND ROWNUM = 1;

          --????
          select c_finflow_cde
            into v_flow_cde
            from web_bas_fin_cash_flow
           where c_rp_typ = v_rp_type;

          INSERT INTO WEB_FIN_CAV_MNY --?????
            (C_CAV_PK_ID,
             n_item_no,
             C_BAL_TYP,
             n_amt,
             n_use_amt,
             c_cur_cde,
             C_PAYER_NME,
             c_bank_cde,
             t_rp_tm,
             c_flow_cde,
             C_BANK_NME,
             c_bank_accnt,
             --c_feetyp_cde     ,
             c_sbjt_no,
             c_savecash_bank,
             t_savecash_tm,
             c_savecash_no,
             c_savecash_opt,
             c_formafee_no,
             c_check_flag,
             C_CRT_CDE,
             C_UPD_CDE,
             T_CRT_TM,
             T_UPD_TM,
             c_check_no --  ,
             -- c_rp_name
             )
            SELECT v_batch_no,
                   v_nitem_no,
                   '001002', --????
                   v_total_amt,
                   v_total_amt,
                   v_bs_cur,
                   C_PAYER_NME,
                   v_bank_cde,
                   sysdate,
                   v_flow_cde, --????
                   v_bank_nme,
                   null,
                   --C_FEETYP_CDE     ,
                   v_mny_sbjt_no,
                   null,
                   null,
                   null,
                   null,
                   null,
                   '0',
                   'admin',
                   'admin',
                   SYSDATE,
                   SYSDATE,
                   (select C_CHEQUE_NO
                      from web_pay_confirm_info
                     where C_UNIQUE_NO = v_rcpt_no) --,--???
            --c_app_nme
              from web_fin_prm_due
             where c_rcpt_no = v_rcpt_no;

          --COMMIT;

          --????
          select c_period_name
            into v_period_name
            from WEB_FIN_MONTHLYCLOSING
           where c_dptacc_cde = v_dptacc_cde;

          --????????????
          SELECT C_company_cde
            INTO v_company_cde
            FROM WEB_ORG_DPT
           WHERE c_dptacc_cde = v_dptacc_cde
             and rownum = 1;

          IF v_company_cde = '?' OR v_company_cde IS NULL THEN
            --??????????ORACLE??,????????????!
            RETURN;
          END IF;

          --?????
          dz_proc.get_fin_voucode(v_vou_no,
                                  v_period_name,
                                  v_dptacc_cde,
                                  dz_proc.g_pttype);

          --??????
          select c_department_cde
            into v_department_cde
            from web_org_dpt
           where c_dpt_cde = v_dpt_cde;

          INSERT INTO WEB_FIN_DCR --???
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             c_sbjt_no,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             t_rp_tm,
             C_DPTACC_NO,
             C_SEND_FLAG,
             c_sbjt_memo,
             c_kind_no,
             --c_department_cde,
             c_company_cde,
             c_period_name,
             c_voucher_no,
             c_vou_no,
             n_total_amt,
             C_CAV_NO,
             c_vou_memo,
             c_rp_type,
             C_CHA_CLS,
             C_CHA_CDE,
             --c_sls_cde,
             c_bank_cde,
             c_flow_no,
             C_SERVICETYPE_NO,
             c_check_no,
             c_bal_type,
             C_PAY_NAME,
             --C_PAY_PRSN_NAME,
             c_check_cde)
            SELECT v_batch_no,
                   '1',
                   '?', --v_drcav_flag,
                   c_sbjt_no, --?????
                   v_total_amt,
                   c_cur_cde,
                   v_crt_tm,
                   sysdate,
                   v_dptacc_cde,
                   '0',
                   c_bank_cde, --????v_sbjt_memo,
                   '0',
                   --v_dpt_cde,
                   v_company_cde, --v_company_cde,
                   v_period_name, --????
                   v_vou_no, --???
                   v_vou_no, --???
                   v_total_amt, --?????
                   v_batch_no,
                   '????', --????
                   v_rp_type,
                   V_CHA_CLS,
                   V_CHA_CDE,
                   --v_sls_cde,
                   c_bank_cde,
                   v_flow_cde,
                   '1102', --????
                   c_check_no,
                   c_bal_typ, --????
                   C_PAYER_NME,
                   --c_rp_name,
                   'admin'
              from web_fin_cav_MNY
             where c_cav_pk_id = v_batch_no;

          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_flow_no,
             c_rp_type,
             c_ri_com,
             c_bal_type,
             c_bank_cde,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_cav_no,
             c_check_cde,
             c_department_cde)
            SELECT c_seq_no,
                   c_item_no,
                   c_cav_flag,
                   (SELECT c_finsbjt_no
                      FROM web_bas_fin_subject
                     WHERE c_sbjt_no = web_fin_dcr.c_sbjt_no),
                   c_sbjt_memo,
                   v_total_amt,
                   n_exch_amt,
                   DECODE(c_cur_no,
                          '01',
                          'CNY',
                          '02',
                          'HKD',
                          '03',
                          'USD',
                          '12',
                          'EUR',
                          '13',
                          'EUR',
                          '05',
                          'JPY',
                          c_cur_no),
                   n_rate,
                   c_chr_cur_no,
                   v_crt_tm,
                   c_dptacc_no,
                   c_flow_no,
                   c_rp_type,
                   c_ri_com,
                   c_bal_type,
                   c_bank_cde,
                   c_check_no,
                   t_rp_tm,
                   c_prod_no,
                   c_send_flag,
                   c_cont_code,
                   c_dpt_cde,
                   c_vou_memo,
                   c_con_dpt_cde,
                   c_cost_cde,
                   c_company_cde,
                   c_salegrp_cde, /*c_bsns_typ*/
                   C_BSNS_TYP, --????
                   c_cha_mrk,
                   c_voucher_no,
                   c_period_name,
                   v_total_amt,
                   c_servicetype_no,
                   v_batch_no,
                   'admin',
                   c_department_cde
              FROM web_fin_dcr
             WHERE c_seq_no = trim(v_batch_no)
               AND c_cav_flag = '?'
               AND ROWNUM = 1;

          INSERT INTO WEB_FIN_DCR --???
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             c_sbjt_no,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             t_rp_tm,
             C_DPTACC_NO,
             C_SEND_FLAG,
             c_sbjt_memo,
             c_kind_no,
             c_department_cde,
             c_company_cde,
             c_period_name,
             c_voucher_no,
             c_vou_no,
             n_total_amt,
             C_CAV_NO,
             c_vou_memo,
             c_rp_type,
             C_CHA_CLS,
             C_CHA_CDE,
             c_sls_cde,
             --c_flow_no,
             c_prod_no,
             c_dpt_cde,
             C_SERVICETYPE_NO,
             c_check_cde,
             c_rcpt_no,
             C_PAY_PRSN_NAME,
             --C_pay_name,
             c_ply_no,
             N_RATE,
             C_CHR_CUR_NO,
             C_SALEGRP_CDE,
             c_cha_mrk)
            SELECT v_batch_no,
                   '2',
                   '?', --v_drcav_flag,
                   '112201', --?????
                   v_bs_amt,
                   c_bs_cur,
                   v_crt_tm,
                   sysdate,
                   v_dptacc_cde,
                   '0',
                   '0', --????v_sbjt_memo,
                   '0320',
                   v_department_cde,
                   v_company_cde, --????,
                   v_period_name, --????
                   v_vou_no, --???
                   v_vou_no, --???
                   v_total_amt, --?????
                   v_batch_no,
                   '????', --????
                   v_rp_type,
                   V_CHA_CLS,
                   V_CHA_CDE,
                   v_sls_cde,
                   --v_flow_cde,
                   c_prod_no, --????
                   c_dpt_cde, --????
                   '1102', --????
                   'admin', --???
                   c_rcpt_no,
                   c_payer_nme, --????
                   --c_payer_nme,
                   c_ply_no,
                   1,
                   '01',
                   C_SLSGRP_CDE,
                   '0'
              from web_fin_cav_doc
             where c_cav_pk_id = v_batch_no;

          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             --c_flow_no,
             c_rp_type,
             c_ri_com,
             c_bal_type,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_cav_no,
             c_check_cde,
             c_rcpt_no,
             c_department_cde)
            SELECT c_seq_no,
                   c_item_no,
                   c_cav_flag,
                   (SELECT c_finsbjt_no
                      FROM web_bas_fin_subject
                     WHERE c_sbjt_no = web_fin_dcr.c_sbjt_no),
                   c_sbjt_memo,
                   v_bs_amt,
                   v_bs_amt,
                   DECODE(c_cur_no,
                          '01',
                          'CNY',
                          '02',
                          'HKD',
                          '03',
                          'USD',
                          '12',
                          'EUR',
                          '13',
                          'EUR',
                          '05',
                          'JPY',
                          c_cur_no),
                   n_rate,
                   c_chr_cur_no,
                   v_crt_tm,
                   c_dptacc_no,
                   --c_flow_no,
                   c_rp_type,
                   c_ri_com,
                   c_bal_type,
                   c_check_no,
                   t_rp_tm,
                   c_prod_no,
                   c_send_flag,
                   c_cont_code,
                   c_dpt_cde,
                   c_vou_memo,
                   c_con_dpt_cde,
                   c_cost_cde,
                   c_company_cde,
                   c_salegrp_cde, /*c_bsns_typ*/
                   '0',
                   c_cha_mrk,
                   c_voucher_no,
                   c_period_name,
                   v_total_amt,
                   c_servicetype_no,
                   v_batch_no,
                   'admin',
                   c_rcpt_no,
                   c_department_cde

              FROM web_fin_dcr
             WHERE c_seq_no = trim(v_batch_no)
               AND c_cav_flag = '?'
               AND ROWNUM = 1
               AND c_sbjt_no = '112201';

          INSERT INTO WEB_FIN_DCR --???
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             c_sbjt_no,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_SEND_FLAG,
             c_sbjt_memo,
             c_kind_no,
             c_department_cde,
             c_company_cde,
             c_period_name,
             c_voucher_no,
             c_vou_no,
             n_total_amt,
             C_CAV_NO,
             c_vou_memo,
             c_rp_type,
             C_CHA_CLS,
             C_CHA_CDE,
             c_sls_cde,
             --c_flow_no,
             --C_PAY_PRSN_NAME,
             c_prod_no,
             c_dpt_cde,
             c_pay_name,
             t_rp_tm,
             c_check_cde,
             c_servicetype_no)
            SELECT v_batch_no,
                   '3',
                   '?', --v_drcav_flag,
                   '119113', --?????
                   v_other_amt,
                   c_cur_cde,
                   v_crt_tm,
                   v_dptacc_cde,
                   '0',
                   '0', --????v_sbjt_memo,
                   '0',
                   v_department_cde,
                   v_company_cde, --v_company_cde,
                   v_period_name, --????
                   v_vou_no, --???
                   v_vou_no, --???
                   v_total_amt, --?????
                   v_batch_no,
                   '????', --????
                   v_rp_type,
                   V_CHA_CLS,
                   V_CHA_CDE,
                   v_sls_cde,
                   --v_flow_cde,
                   --c_payer_nme,
                   c_prod_no,
                   c_dpt_cde,
                   C_PAYER_NME,
                   sysdate,
                   'admin',
                   '1102'
              from web_fin_cav_obj
             where c_cav_pk_id = v_batch_no;

          INSERT INTO web_fin_dcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             c_cur_no,
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             c_dptacc_no,
             --c_flow_no,
             c_rp_type,
             c_ri_com,
             c_bal_type,
             c_check_no,
             t_rp_tm,
             c_prod_no,
             c_send_flag,
             c_cont_code,
             c_dpt_cde,
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             c_company_cde,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_vou_no,
             c_period_name,
             n_total_amt,
             c_servicetype_no,
             c_cav_no,
             c_check_cde,
             c_department_cde)
            SELECT c_seq_no,
                   c_item_no,
                   c_cav_flag,
                   (SELECT c_finsbjt_no
                      FROM web_bas_fin_subject
                     WHERE c_sbjt_no = web_fin_dcr.c_sbjt_no),
                   c_sbjt_memo,
                   v_other_amt,
                   n_exch_amt,
                   DECODE(c_cur_no,
                          '01',
                          'CNY',
                          '02',
                          'HKD',
                          '03',
                          'USD',
                          '12',
                          'EUR',
                          '13',
                          'EUR',
                          '05',
                          'JPY',
                          c_cur_no),
                   n_rate,
                   c_chr_cur_no,
                   v_crt_tm,
                   c_dptacc_no,
                   --c_flow_no,
                   c_rp_type,
                   c_ri_com,
                   c_bal_type,
                   c_check_no,
                   t_rp_tm,
                   c_prod_no,
                   c_send_flag,
                   c_cont_code,
                   c_dpt_cde,
                   c_vou_memo,
                   c_con_dpt_cde,
                   c_cost_cde,
                   c_company_cde,
                   c_salegrp_cde, /*c_bsns_typ*/
                   C_BSNS_TYP,
                   c_cha_mrk,
                   c_voucher_no,
                   c_period_name,
                   v_total_amt,
                   '1102',
                   v_batch_no,
                   'admin',
                   c_department_cde
              FROM web_fin_dcr
             WHERE c_seq_no = trim(v_batch_no)
               AND c_cav_flag = '?'
               AND ROWNUM = 1
               AND c_sbjt_no = '119113';

          --v_nitem_no:=v_nitem_no+1;

          --???????
          dz_proc.get_fin_cav_no(v_batch_no,
                                 v_dpt_cde,
                                 '5',
                                 dz_proc.g_pttype);

        END IF;
      END LOOP;
      CLOSE cur_doc;

    END LOOP;
    CLOSE cur_bill;
    COMMIT;
    --2.1 v_other_amt<>0
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        dbms_output.put_line('exception' || '*' || v_dptacc_cde ||
                             v_batch_no || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[Autorpprm],??????[' || v_dptacc_cde ||
                         v_batch_no || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  --??

  --????????(???????????)
  Procedure CalSaveThreeTax IS
    v_insrnc_bgn_tm DATE; --????
    v_insrnc_end_tm DATE; --????
    v_prod_no       WEB_FIN_SAVEAMT_DUE.c_prod_no%TYPE; --????

    v_dpt_cde  WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;
    plytime    NUMBER(16, 2);
    edrtime    NUMBER(16, 2);
    newedrtime NUMBER(16, 2);
    ngetamt    NUMBER(16, 2);
    npayamt    NUMBER(16, 2);
    npaidamt   NUMBER(16, 2);
    --v_edr_rsn     WEB_EDR_BASE.c_edr_rsn%TYPE;
    v_edr_rsn     VARCHAR2(2);
    v_cur_cde     WEB_FIN_SAVEAMT_DUE.C_DUE_CUR%TYPE;
    v_rcpt_no     WEB_FIN_SAVEAMT_DUE.c_rcpt_no%TYPE;
    v_salegrp_cde WEB_FIN_SAVEAMT_DUE.C_SLSGRP_CDE%TYPE;
    chacls        WEB_FIN_SAVEAMT_DUE.c_cha_cls%TYPE;
    chacde        WEB_FIN_SAVEAMT_DUE.c_cha_cde%TYPE;
    v_sls_cde     WEB_FIN_SAVEAMT_DUE.c_sls_cde%TYPE;
    --payprsncde    WEB_FIN_SAVEAMT_DUE.c_pay_prsn_cde%TYPE;
    payprsncde VARCHAR2(14);
    --v_dpt_cde          T_FIN_SAVEAMTDUE.c_dpt_cde%TYPE;
    --v_monseqno   T_FIN_MONTHACCRUAL.c_mon_ret_no%TYPE;
    v_monseqno VARCHAR2(21);
    --v_seq_no     T_FIN_VOUCHER.c_seq_no%TYPE;
    v_seq_no VARCHAR2(21);
    --v_monseqno1  T_FIN_MONTHACCRUAL.c_mon_ret_no%TYPE;
    v_monseqno1 VARCHAR2(21);
    --v_seq_no1    T_FIN_VOUCHER.c_seq_no%TYPE;
    v_seq_no1        VARCHAR2(21);
    v_feetyp_cde     WEB_FIN_SAVEAMT_DUE.c_feetyp_cde%TYPE;
    v_newedrno       WEB_EDR_BASE.c_edr_no%TYPE;
    n_realflag       NUMBER(1);
    a                NUMBER(1);
    v_Interest_reate web_fin_presave.n_Interest_reate%type;
    v_other_amttax   WEB_FIN_SAVEAMT_DUE.N_BS_AMT%TYPE;
    v_cal_tm         DATE;
    v_ply_no         WEB_FIN_SAVEAMT_DUE.c_ply_no%type;

    v_other_amt WEB_FIN_SAVEAMT_DUE.N_BS_AMT%TYPE;
    v_pay_amt   WEB_FIN_SAVEAMT_DUE.N_BS_AMT%TYPE;
    v_succsflag int;

    dznoflag        INT;
    v_interest_flag VARCHAR2(2);

    v_vou_memo       WEB_FIN_MADCR.c_vou_memo%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_MADCR.c_company_cde%TYPE;
    v_period_name    WEB_FIN_MADCR.c_period_name%TYPE;
    v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;
    v_end_time       WEB_BAS_FIN_ACCT_PERIOD.T_END_TM%TYPE;
    v_dptacc_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_maseq_no       WEB_FIN_MADCR.c_seq_no%TYPE;

    v_kind_no      WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_tmp_cnt      INT;
    v_tracktmp_cnt INT;
    v_add_type     web_prd_prod.c_add_type%TYPE;

    v_bonds_rate web_fin_presave.N_Bonds_rate%TYPE;
    v_crt_cde    WEB_FIN_SAVEAMT_DUE.c_crt_cde%TYPE;
    v_year       number(20, 4);
    v_data       web_fin_presave.N_Bonds_rate%TYPE; --number(16,8);--t_fin_tmpsave.n_data%TYPE;
    v_fm         number(16, 6); --t_fin_tmpsave.n_fm%TYPE;
    v_fz         number(16, 6); --t_fin_tmpsave.n_fz%TYPE;
    v_jg         number(16, 6); --t_fin_presave.N_Bonds_rate%TYPE;--t_fin_tmpsave.n_jg%TYPE;                          --???????

    --v_max             WEB_FIN_SAVEAMT_DUE.n_pay_amt%TYPE;             --???
    --v_Surrender_amt  WEB_FIN_SAVEAMT_DUE.n_pay_amt%TYPE;             --????
    --N_cal_amt       WEB_FIN_SAVEAMT_DUE.n_pay_amt%TYPE;              --?????

    v_max           NUMBER(22, 6); --???
    v_Surrender_amt NUMBER(22, 6); --????
    N_cal_amt       NUMBER(22, 6); --?????

    v_ical_tm  WEB_FIN_SAVEAMT_DUE.t_crt_tm%type;
    v_sub_rate NUMBER(16, 6);
    k_count    number;

    v_crt_cde     WEB_FIN_SAVEAMT_DUE.c_crt_cde%type;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%type;
    CURSOR cur_calint IS
      SELECT c_prod_no,
             NVL(n_paid_amt, 0),
             TRUNC(t_insrnc_bgn_tm),
             TRUNC(t_insrnc_end_tm),
             NVL(C_DUE_CUR, CHR(0)),
             NVL(c_rcpt_no, CHR(0)),
             NVL(C_SLSGRP_CDE, CHR(0)),
             NVL(c_cha_cls, CHR(0)),
             NVL(c_cha_cde, CHR(0)),
             NVL(c_sls_cde, CHR(0)),
             NVL(C_PAYER_CDE, CHR(0)),
             NVL(c_dpt_cde, CHR(0)),
             C_DPTACC_CDE,
             c_ply_no
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_feetyp_cde = 'G'
         AND n_paid_amt < 0
            --and t_check_tm <= to_date('2009-05-31 23:59:59','yyyy-mm-dd hh24:mi:ss')
         and t_crt_tm <=
             to_date('2009-05-31 23:59:59', 'yyyy-mm-dd hh24:mi:ss')
         AND not exists
       (SELECT 1
                FROM web_fin_tmpbigsave_due
               where c_ply_no = WEB_FIN_SAVEAMT_DUE.c_ply_no)
         AND NOT EXISTS
       (SELECT c_ply_no
                FROM web_edr_base
               WHERE c_ply_no = WEB_FIN_SAVEAMT_DUE.c_ply_no
                 AND c_edr_rsn IN ('A1', 'A3', '77'))
         AND WEB_FIN_SAVEAMT_DUE.c_Ply_No = '10200008600012009000098';

    --????G?????0???????? ?????????????????????????????

  BEGIN

    -- return;

    --?????
    --IF TRUNC(SYSDATE - 1, 'MM') <> TRUNC(ADD_MONTHS(SYSDATE, -1)) THEN
    --  RETURN;
    --ELSE
    /*
    UPDATE WEB_FIN_SAVEAMT_DUE
      SET c_lx_flag='0'
      WHERE c_feetyp_cde = 'G' AND n_paid_amt < 0
    and not exists
         (SELECT c_ply_no from t_edr_base
             WHERE c_ply_no =WEB_FIN_SAVEAMT_DUE.c_ply_no
               and c_edr_rsn in ('A1','A3','77')
         );
    */

    --   commit;
    --   END IF;

    --????????
    v_ical_tm     := TRUNC(SYSDATE) - 1;
    v_period_name := TO_CHAR(v_cal_tm, 'yyyy-mm');

    OPEN cur_calint;
    LOOP
      FETCH cur_calint
        INTO v_prod_no, npaidamt, v_insrnc_bgn_tm, v_insrnc_end_tm, v_cur_cde, v_rcpt_no, v_salegrp_cde, chacls, chacde, v_sls_cde, payprsncde, v_dpt_cde, v_dptacc_cde, v_ply_no;

      EXIT WHEN cur_calint%NOTFOUND;

      Service_Interface.CalPlyTax(v_ply_no,
                                  v_insrnc_bgn_tm,
                                  v_insrnc_end_tm,
                                  0,
                                  plytime,
                                  v_Bonds_rate,
                                  v_other_amttax,
                                  v_succsflag);

      IF TRUNC(v_cal_tm) <= TRUNC(v_insrnc_end_tm) THEN
        --???????
        select nvl(N_Bonds_rate, 0)
          into v_Bonds_rate
          from WEB_BAS_FIN_PROD
         where c_prod_no = c_prod_no;

        --?????????

        v_year := (TRUNC(v_insrnc_end_tm) - TRUNC(v_cal_tm)) / 365;
        v_data := (100 + v_Bonds_rate) / 100;
        v_fm   := POWER(v_data, v_year);

        select nvl(N_PROFIT_AMT, 0)
          INTO v_other_amttax
          FROM WEB_FIN_SAVEAMT_DUE
         WHERE c_rcpt_no = v_rcpt_no;

        --????????????????N_PROFIT_AMT?
        --IF v_other_amttax=0 THEN
        --maintenance.CalPlyTax(v_ply_no,v_other_amttax,v_succsflag);
        --END IF;

        v_fz            := v_other_amttax;
        v_jg            := (newedrtime * 10000 + v_fz) / v_fm;
        v_Surrender_amt := Invst_Finc.get_dischg_sum(v_add_type,
                                                     v_insrnc_bgn_tm,
                                                     v_insrnc_end_tm,
                                                     v_cal_tm,
                                                     newedrtime);
      ELSE
        v_year          := 0;
        v_jg            := newedrtime * 10000 + v_other_amt;
        v_Surrender_amt := newedrtime * 10000 + v_other_amt;
        V_BONDS_RATE    := 0;
      END IF;
      -- v_Bonds_rate = v_data;

      /*??????*/

      /*?????*/
      v_max       := v_other_amt + newedrtime * 10000;
      v_other_amt := v_other_amt + newedrtime * 10000;
      IF v_other_amt < v_Surrender_amt THEN
        v_max := v_Surrender_amt;
      END IF;

      IF v_max < v_jg THEN
        v_max := v_jg;
      END IF;

      N_cal_amt := v_max - v_other_amt;
      --???????

      /*??????????????????*/
      DELETE FROM WEB_FIN_PRESAVE
       WHERE C_RCPT_NO = v_rcpt_no
         AND T_CAL_TM = v_CAL_TM;

      INSERT INTO WEB_FIN_PRESAVE
        (c_rcpt_no,
         T_CAL_TM,
         C_ply_no,
         n_shares_no,
         N_bs_amt,
         N_TAX_amt,
         N_discount_amt,
         N_Surrender_amt,
         N_Bonds_rate,
         N_interest_reate,
         N_max_amt,
         N_cal_amt,
         C_memo,
         c_flag,
         c_prod_no,
         n_year)
      VALUES
        (v_rcpt_no,
         v_cal_tm,
         v_ply_no,
         nvl(newedrtime, 0),
         nvl(newedrtime, 0) * 10000,
         ngetamt,
         v_jg,
         v_Surrender_amt,
         v_Bonds_rate,
         v_Interest_reate,
         v_max,
         n_cal_amt, --?????
         '', --??
         0,
         v_prod_no,
         v_year);
      v_succsflag := 1;
      COMMIT;

    END LOOP;

    CLOSE cur_calint;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_rcpt_no || v_ply_no ||
                             v_cur_cde || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[CalSaveThreeTax],??????[' ||
                         v_rcpt_no || v_ply_no || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;
  END;

  --???????(???????????)
  PROCEDURE CalThreeTaxMa IS
    v_insrnc_bgn_tm DATE; --????
    v_insrnc_end_tm DATE; --????
    v_prod_no       WEB_FIN_SAVEAMT_DUE.c_prod_no%TYPE; --????
    --v_ply_no        WEB_FIN_SAVEAMT_DUE.c_ply_no%TYPE;
    v_dpt_cde     WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;
    npaidamt      NUMBER(16, 2);
    v_cur_cde     WEB_FIN_SAVEAMT_DUE.C_DUE_CUR%TYPE;
    v_rcpt_no     WEB_FIN_SAVEAMT_DUE.c_rcpt_no%TYPE;
    v_salegrp_cde WEB_FIN_SAVEAMT_DUE.C_SLSGRP_CDE%TYPE;
    chacls        WEB_FIN_SAVEAMT_DUE.c_cha_cls%TYPE;
    chacde        WEB_FIN_SAVEAMT_DUE.c_cha_cde%TYPE;
    v_sls_cde     WEB_FIN_SAVEAMT_DUE.c_sls_cde%TYPE;

    --payprsncde      WEB_FIN_SAVEAMT_DUE.c_pay_prsn_cde%TYPE;VARCHAR2 14
    payprsncde VARCHAR2(14);

    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_crt_cde     WEB_FIN_SAVEAMT_DUE.c_crt_cde%TYPE;

    --v_cal_tm WEB_FIN_PAY_DUE.t_bal_tm%TYPE;
    v_cal_tm DATE;

    v_dptacc_no      WEB_FIN_SAVEAMT_DUE.C_DPTACC_CDE%TYPE;
    v_RP_CUR         WEB_FIN_SAVEAMT_DUE.C_RP_CUR%TYPE;
    v_bsns_typ       WEB_FIN_SAVEAMT_DUE.c_bsns_typ%TYPE;
    v_CHA_MRK        WEB_FIN_SAVEAMT_DUE.C_CHA_MRK%TYPE;
    v_flag           WEB_FIN_PRESAVE.C_FLAG%TYPE;
    v_vou_memo       WEB_FIN_MADCR.c_vou_memo%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%type;
    v_company_cde    WEB_FIN_MADCR.c_company_cde%TYPE;
    v_period_name    WEB_FIN_MADCR.c_period_name%TYPE;
    v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;
    v_end_time       WEB_BAS_FIN_ACCT_PERIOD.t_end_tm%TYPE;
    v_dptacc_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_maseq_no       WEB_FIN_MADCR.c_seq_no%TYPE;
    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_ply_no         WEB_FIN_SAVEAMT_DUE.c_ply_no%TYPE;

    CURSOR cur_calint IS

      SELECT a.c_prod_no,
             NVL(b.N_cal_amt, 0),
             TRUNC(a.t_insrnc_bgn_tm),
             TRUNC(a.t_insrnc_end_tm),
             NVL(a.C_DUE_CUR, CHR(0)),
             NVL(a.c_rcpt_no, CHR(0)),
             NVL(a.C_SLSGRP_CDE, CHR(0)),
             NVL(a.c_cha_cls, CHR(0)),
             NVL(a.c_cha_cde, CHR(0)),
             NVL(a.c_sls_cde, CHR(0)),
             NVL(a.C_PAYER_CDE, CHR(0)),
             NVL(a.c_dpt_cde, CHR(0)),
             a.c_crt_cde,
             a.C_DPTACC_CDE,
             a.C_RP_CUR,
             a.c_crt_cde,
             a.C_DPTACC_CDE,
             a.c_dpt_cde,
             a.c_bsns_typ,
             a.C_CHA_MRK,
             a.c_ply_no
        FROM WEB_FIN_SAVEAMT_DUE a, WEB_FIN_PRESAVE b
       where a.C_PLY_NO = v_ply_no
         and a.c_rcpt_no = b.c_rcpt_no; --and b.c_flag='0';

  BEGIN

    --????????
    --v_cal_tm:=TRUNC(SYSDATE)-1;
    v_cal_tm      := to_date('2008-08-01', 'YYYY-MM-DD');
    v_period_name := to_char(v_cal_tm, 'yyyy-mm');

    OPEN cur_calint;
    LOOP
      FETCH cur_calint
        INTO v_prod_no, npaidamt, v_insrnc_bgn_tm, v_insrnc_end_tm, v_cur_cde, v_rcpt_no, v_salegrp_cde, chacls, chacde, v_sls_cde, payprsncde, v_dpt_cde, v_crt_cde, v_dptacc_cde, V_RP_CUR, v_crt_cde, v_dptacc_no, v_dpt_cde, v_bsns_typ, v_CHA_MRK, v_ply_no;

      EXIT WHEN cur_calint%NOTFOUND;
      --v_period_name:=TO_CHAR(SYSDATE,'YYYY-MM');
      SELECT TRUNC(t_end_tm)
        INTO v_end_time
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = v_period_name;

      v_cal_tm      := trunc(v_end_time);
      v_period_name := TO_CHAR(v_cal_tm, 'YYYY-MM');

      --????
      /*
           5001(2960)
           Dr???????????/??????????  450203
         Cr:????????/????????   216203
      */
      v_vou_memo       := '??????????';
      v_servicetype_no := '5001';
      SELECT c_company_cde, c_department_cde
        INTO v_company_cde, v_department_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      --?????
      Dz_Proc.get_fin_no(v_maseq_no, v_dpt_cde, '7', '0');

      SELECT c_kind_no
        INTO v_kind_no
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = v_prod_no;

      INSERT INTO WEB_FIN_MADCR
        (c_seq_no,
         c_item_no,
         t_end_tm,
         c_cav_flag,
         c_sbjt_no,

         n_amt,
         c_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_dpt_cde,

         c_rcpt_no,
         c_sls_cde,
         c_prod_no,
         c_bsns_typ,
         c_cha_cls,

         c_cha_cde,
         c_salegrp_cde,
         c_pay_prsn_cde,
         c_pay_prsn_name,
         c_ri_com,
         c_cont_code,
         c_ply_no,
         c_cha_mrk,

         c_vou_memo,
         c_company_cde,
         c_check_flag,
         n_total_amt,
         c_servicetype_no,
         c_kind_no,
         c_department_cde)
      VALUES
        (v_maseq_no,
         '1' /*c_item_no*/,
         SYSDATE /*t_end_tm*/,
         '?' /*c_cav_flag*/,
         '450203',

         npaidamt /*n_amt*/,
         v_cur_cde /*c_cur_no*/,
         v_cal_tm /*t_crt_tm*/,
         v_dptacc_no,
         v_dpt_cde,

         v_rcpt_no,
         v_sls_cde,
         v_prod_no,
         v_bsns_typ,
         chacls,
         chacde,
         v_salegrp_cde,
         null, --v_pay_prsn_cde     ,
         null, --v_pay_prsn_name    ,
         null, --v_ri_com           ,
         null, --v_ri_com        ,
         v_ply_no,
         v_cha_mrk,

         v_vou_memo /*c_vou_memo*/,
         v_company_cde,
         '0' /*c_check_flag*/,
         npaidamt /*n_total_amt*/,
         v_servicetype_no,
         v_kind_no,
         v_department_cde);

      INSERT INTO WEB_FIN_MADCR
        (c_seq_no,
         c_item_no,
         t_end_tm,
         c_cav_flag,
         c_sbjt_no,

         n_amt,
         c_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_dpt_cde,

         c_rcpt_no,
         c_sls_cde,
         c_prod_no,
         c_bsns_typ,
         c_cha_cls,

         c_cha_cde,
         c_salegrp_cde,
         c_pay_prsn_cde,
         c_pay_prsn_name,
         c_ri_com,
         c_cont_code,
         c_ply_no,
         c_cha_mrk,

         c_vou_memo,
         c_company_cde,
         c_check_flag,
         n_total_amt,
         c_servicetype_no,
         c_kind_no,
         c_department_cde)
      VALUES
        (v_maseq_no,
         '2' /*c_item_no*/,
         SYSDATE /*t_end_tm*/,
         '?' /*c_cav_flag*/,
         '216203',

         npaidamt /*n_amt*/,
         v_cur_cde /*c_cur_no*/,
         v_cal_tm /*t_crt_tm*/,
         v_dptacc_no,
         v_dpt_cde,

         v_rcpt_no,
         v_sls_cde,
         v_prod_no,
         v_bsns_typ,
         chacls,
         chacde,
         v_salegrp_cde,
         null, --v_pay_prsn_cde     ,
         null, --v_pay_prsn_name    ,
         null, --v_ri_com           ,
         null, --v_ri_com        ,
         v_ply_no,
         v_cha_mrk,

         v_vou_memo /*c_vou_memo*/,
         v_company_cde,
         '0' /*c_check_flag*/,
         npaidamt /*n_total_amt*/,
         v_servicetype_no,
         v_kind_no,
         v_department_cde);

      UPDATE web_fin_presave SET c_flag = '1' where c_rcpt_no = v_rcpt_no;
      commit;
    END LOOP;

    CLOSE cur_calint;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_rcpt_no || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[CalThreeTaxMa],??????[' || v_rcpt_no ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;

  END;

  procedure AutoAccounts(v_batch_no     in varchar2,
                         v_rp_type      in varchar2,
                         v_bal_flag     in char,
                         v_bank_cde     in varchar2,
                         v_sucsess_flag out number) is
    /**
    ????
    1????????
    2????????
    */
    v_cav_pk_id web_fin_cav_bill.c_cav_pk_id%type; --????
    v_total_amt web_fin_cav_bill.n_sum_amt%type; --????

    --??????
    v_due_type           char(1); --???? 1??2??3??4??5???
    v_dptacc_cde         v_fin_due.c_dptacc_cde%type; --????
    v_bs_amt             v_fin_due.n_bs_amt%type; --????
    v_total_bs_amt       v_fin_due.n_bs_amt%type; --?????
    v_total_other_amt    v_fin_due.n_other_amt%type; --?????
    v_total_other_posamt v_fin_due.n_other_amt%type; --???????
    v_total_other_negamt v_fin_due.n_other_amt%type; --???????
    v_ply_no             v_fin_due.c_ply_no%type; --???
    v_edr_no             v_fin_due.c_edr_no%type; --???
    v_clm_no             v_fin_due.c_clm_no%type; --???
    v_rcpt_no            v_fin_due.c_rcpt_no%type; --???
    v_prod_no            v_fin_due.c_prod_no%type; --??
    v_dpt_cde            v_fin_due.c_dpt_cde%type; --????
    v_bs_cur             v_fin_due.c_bs_cur%type; --????
    v_other_amt          v_fin_due.n_other_amt%type; --????
    v_crt_tm             v_fin_due.t_crt_tm%type; --????
    v_sls_cde            v_fin_due.c_sls_cde%type; --???
    v_cha_cls            v_fin_due.c_cha_cls%type; --????
    v_cha_cde            v_fin_due.c_cha_cde%type; --??
    v_PAYER_NME          v_fin_due.c_PAYER_NME%type; --???
    v_bsns_typ           v_fin_due.c_bsns_typ%type; --????
    v_feetyp_cde         v_fin_due.c_feetyp_cde%type; --????
    v_tran_flag          v_fin_due.c_tran_flag%type; --????
    --??????
    v_cavobj_itemno web_fin_cav_obj.n_item_no%type; --???????
    v_objsbjt_no    web_fin_cav_obj.c_sbjt_no%type; --??????
    v_objamt        web_fin_cav_obj.n_amt%type; --??????
    v_cur_cde       web_fin_cav_obj.c_cur_cde%type; --??????
    v_cav_dir       web_fin_cav_obj.c_cav_dir%type; --??????
    v_pre_amt       web_fin_cav_obj.n_pre_amt%type; --????????
    v_pre_flag      web_fin_cav_obj.c_pre_flag%type; --????????
    --??????
    v_cavdoc_itemno web_fin_cav_doc.n_item_no%type; --??????
    v_EXCH_RATE     web_fin_cav_doc.N_EXCH_RATE%type; --??
    --?????
    v_dcritem_no     number;
    v_sbjt_no        web_fin_dcr.c_sbjt_no%type; --???
    v_sbjt_memo      web_fin_dcr.c_sbjt_memo%type; --????
    v_seq_no         web_fin_dcr.c_seq_no%type; --??????
    v_cav_flag       web_fin_dcr.c_cav_flag%type; --????
    v_vou_memo       web_fin_dcr.c_vou_memo%type; --????
    v_servicetype_no web_fin_dcr.c_servicetype_no%type; --????
    v_vou_no         web_fin_dcr.c_vou_no%type; --???
    v_gcvou_no       web_fin_dcr.c_vou_no%type; --?????

    v_intfitem_no web_fin_dcr_intf.c_item_no%type; --??
    --????
    v_department_cde WEB_ORG_DPT.c_department_cde%type; --??
    v_company_cde    WEB_ORG_DPT.c_company_cde%type; --??
    --????
    v_PERIOD_NAME WEB_BAS_FIN_ACCT_PERIOD.C_PERIOD_NAME%type; --??????
    --????
    v_kind_no web_bas_fin_prod.c_kind_no%type; --????
    --????
    v_sum_amt web_fin_cav_bill.n_sum_amt%type; --???
    --?????
    v_eac_dcm_mrk web_fin_clm_due.c_eac_dcm_mrk%type;
    v_err_content web_bas_fin_errorlog.c_err_content%type;
    v_counter     number; --???
    v_return      number;

    CURSOR cur_busBill is --?????????????
      select a.c_ply_no,
             a.c_edr_no,
             a.c_clm_no,
             a.c_rcpt_no,
             a.c_prod_no,
             a.c_dpt_cde,
             a.c_dptacc_cde,
             a.n_bs_amt,
             to_date(to_char(a.t_crt_tm, 'YYYY-MM-DD'), 'YYYY-MM-DD'),
             a.c_bs_cur,
             NVL(a.n_other_amt, 0)
        from V_FIN_DUE a
       where a.c_accnt_flag IN ('00', '01') --????
         and a.c_bala_mrk = '0' --???
         and a.c_batch_no = v_batch_no
         and a.c_due_type = v_due_type;

    --??????
    /*
    CURSOR cur_cavMny IS
      SELECT C_BAL_TYP,
             N_AMT,
             C_CUR_cde,
             C_PAYER_NME,
             C_BANK_CDE,
             C_CHECK_NO,
             T_RP_TM,
             c_sbjt_no,
             c_flow_cde,
             n_item_no,
             C_BANK_NME
        FROM WEB_FIN_CAV_MNY
       WHERE C_CAV_PK_ID = v_cav_pk_id;
       */
    --??????
    CURSOR cur_cavObj IS
      SELECT c_sbjt_no, n_amt, c_cur_cde, c_cav_dir, n_pre_amt, c_pre_flag
        FROM WEB_FIN_CAV_OBJ
       WHERE C_CAV_PK_ID = v_cav_pk_id;
    --??????
    CURSOR cur_cavDoc IS
      SELECT c_rcpt_no,
             N_EXCH_RATE,
             C_BS_CUR,
             N_BS_AMT,
             c_prod_no,
             c_sls_cde,
             c_bsns_typ,
             c_cha_cls,
             c_cha_cde,
             c_dpt_cde,
             c_edr_no,
             c_feetyp_cde,
             C_PAYER_NME,
             c_edr_no,
             c_ply_no
        FROM WEB_FIN_CAV_DOC
       WHERE C_CAV_PK_ID = v_cav_pk_id;
    --??????
    CURSOR cur_dcr IS
      SELECT SUM(n_amt),
             c_dpt_cde,
             c_kind_no,
             c_cav_flag,
             c_sbjt_no,
             c_cur_no
        FROM WEB_FIN_DCR
       WHERE c_seq_no = v_seq_no
       GROUP BY c_dpt_cde, c_kind_no, c_cav_flag, c_sbjt_no, c_cur_no;

  begin
    --??????????????
    if v_rp_type = '101' or v_rp_type = '111' or v_rp_type = '112' or
       v_rp_type = '201' or v_rp_type = '210' or v_rp_type = '211' then
      v_due_type := '1';
    elsif v_rp_type = '103' or v_rp_type = '106' or v_rp_type = '207' or
          v_rp_type = '109' or v_rp_type = '204' or v_rp_type = '205' or
          v_rp_type = '113' then
      v_due_type := '2';
    elsif v_rp_type = '105' or v_rp_type = '206' or v_rp_type = '209' or
          v_rp_type = '212' then
      v_due_type := '3';
    elsif v_rp_type = '102' or v_rp_type = '202' or v_rp_type = '212' then
      v_due_type := '4';
    elsif v_rp_type = '132' or v_rp_type = '232' then
      v_due_type := '5';
    else
      v_sucsess_flag := 1;
      return;
    end if;
    v_counter     := 0; --???
    v_intfitem_no := 0; --????-??

    select count(1)
      into v_counter
      from v_fin_due
     where c_batch_no = v_batch_no
       and rownum = 1;
    if v_counter = 1 then
      select c_dptacc_cde, --??????????
             c_dpt_cde,
             c_prod_no,
             c_bs_cur,
             c_sls_cde,
             c_cha_cls,
             c_cha_cde,
             C_PAYER_NME,
             c_bsns_typ
        into v_dptacc_cde,
             v_dpt_cde,
             v_prod_no,
             v_bs_cur,
             v_sls_cde,
             v_cha_cls,
             v_cha_cde,
             v_PAYER_NME,
             v_bsns_typ
        from v_fin_due
       where c_batch_no = v_batch_no
         and rownum = 1;
      v_counter := 0;
    else
      return;
    end if;

    v_total_bs_amt       := 0; --?????
    v_total_other_amt    := 0; --?????
    v_total_other_posamt := 0; --???????
    v_total_other_negamt := 0; --???????
    v_cavobj_itemno      := 1; --???????
    v_cavdoc_itemno      := 1; --??????
    v_dcritem_no         := 1; --?????
    v_sum_amt            := 0; --?????

    dz_proc.get_fin_cav_no(v_cav_pk_id,
                           v_dptacc_cde,
                           '5',
                           dz_proc.g_pttype); --??????
    insert into web_fin_cav_bill --????????????????
      (C_CAV_PK_ID,
       c_dpt_cde,
       C_CUR_CDE,
       c_crt_cde,
       c_upd_cde,
       c_rp_type,
       n_sum_amt,
       c_oper_cde,
       T_CAV_TM,
       T_CRT_TM,
       t_upd_tm,
       c_check_cde,
       T_CHECK_TM,
       c_check_flag)
    values
      (v_cav_pk_id,
       v_dptacc_cde,
       v_bs_cur,
       'admin',
       'admin',
       v_rp_type,
       0,
       'admin',
       sysdate,
       sysdate,
       sysdate,
       'admin',
       sysdate,
       '2');

    --????????????????
    open cur_busBill;
    loop
      FETCH cur_busBill
        INTO v_ply_no, v_edr_no, v_clm_no, v_rcpt_no, v_prod_no, v_dpt_cde, v_dptacc_cde, v_bs_amt, v_crt_tm, v_bs_cur, v_other_amt;
      EXIT WHEN cur_busBill%NOTFOUND;

      v_total_bs_amt := v_total_bs_amt + v_bs_amt; --?????
      if v_other_amt > 0 then
        v_total_other_posamt := v_total_other_posamt + v_other_amt; --???????
      elsif v_other_amt < 0 then
        v_total_other_negamt := v_total_other_negamt + v_other_amt; --???????
      end if;

      if v_due_type = '1' then
        v_sum_amt := v_total_bs_amt + v_total_other_posamt +
                     v_total_other_negamt;
      elsif v_due_type = '4' or v_due_type = '5' then
        v_sum_amt := v_total_bs_amt - v_total_other_posamt -
                     v_total_other_negamt;
      end if;

      --???
      IF v_dptacc_cde = '11' or v_dptacc_cde = '1164' then    --???
           v_sum_amt := v_sum_amt + v_total_bs_amt * 0.001;
        end if;

      --??????  WEB_FIN_CAV_DOC
      INSERT INTO WEB_FIN_CAV_DOC
        (C_CAV_PK_ID,
         N_ITEM_NO,
         c_rcpt_no,
         c_ply_no,
         c_edr_no,
         n_exch_rate,
         t_insrnc_bgn_tm,
         t_insrnc_end_tm,
         c_prod_no,
         c_sls_cde,
         c_cha_cls,
         c_cha_cde,
         C_PAYER_CDE,
         c_dpt_cde,
         c_feetyp_cde,
         C_SLSGRP_CDE,
         c_bsns_typ,
         C_PAYER_NME,
         c_bs_cur,
         n_bs_amt,
         n_rp_prm, --?????
         N_ORIG_CUR_AMT,
         N_ORIG_PRM,
         C_CRT_CDE,
         C_UPD_CDE,
         c_rp_cur,
         n_rp_amt,
         t_crt_tm,
         t_upd_tm,
         c_bill_flag,
         C_CLNT_MRK)
        select v_CAV_PK_ID,
               v_cavdoc_itemno,
               c_rcpt_no,
               c_ply_no,
               c_edr_no,
               1,
               t_insrnc_bgn_tm,
               t_insrnc_end_tm,
               c_prod_no,
               c_sls_cde,
               c_CHA_CLS,
               c_CHA_CDE,
               C_PAYER_CDE,
               c_dpt_cde,
               c_feetyp_cde,
               C_SLSGRP_CDE,
               c_bsns_typ,
               C_PAYER_NME,
               c_bs_cur,
               DECODE(v_due_type, '1', n_bs_amt, -n_bs_amt),
               DECODE(v_due_type, '1', n_bs_amt, -n_bs_amt),
               DECODE(v_due_type, '1', n_bs_amt, -n_bs_amt),
               DECODE(v_due_type, '1', n_bs_amt, -n_bs_amt),
               'admin',
               'admin',
               v_bs_cur,
               DECODE(v_due_type, '1', n_bs_amt, -n_bs_amt),
               sysdate,
               sysdate,
               v_due_type,
               C_CLNT_MRK
          from v_fin_due
         where c_rcpt_no = v_rcpt_no;
      v_cavdoc_itemno := v_cavdoc_itemno + 1;

      --???????
      if v_due_type = '1' then
        update web_fin_prm_due
           set N_RP_AMT     = N_BS_AMT,
               n_paid_amt   = N_BS_AMT,
               T_PAID_TM    = v_crt_tm,
               T_RP_TM      = v_crt_tm,
               c_accnt_flag = DECODE(c_accnt_flag,
                                     '01',
                                     '11',
                                     '00',
                                     '10',
                                     '10')
           where c_rcpt_no = v_rcpt_no;
      elsif v_due_type = '2' then
        update web_fin_clm_due
           set N_RP_AMT     = N_BS_AMT,
               n_paid_amt   = N_BS_AMT,
               T_PAID_TM    = v_crt_tm,
               T_RP_TM      = v_crt_tm,
               c_accnt_flag = DECODE(c_accnt_flag,
                                     '01',
                                     '11',
                                     '00',
                                     '10',
                                     '10')
           where c_rcpt_no = v_rcpt_no;
      elsif v_due_type = '3' then
        update web_fin_pay_due
           set N_RP_AMT     = N_BS_AMT,
               n_paid_amt   = N_BS_AMT,
               T_PAID_TM    = v_crt_tm,
               T_RP_TM      = v_crt_tm,
               c_accnt_flag = DECODE(c_accnt_flag,
                                     '01',
                                     '11',
                                     '00',
                                     '10',
                                     '10')
           where c_rcpt_no = v_rcpt_no;
      elsif v_due_type = '4' then
        update web_fin_saveamt_due
           set N_RP_AMT     = N_BS_AMT,
               n_paid_amt   = N_BS_AMT,
               T_PAID_TM    = v_crt_tm,
               T_RP_TM      = v_crt_tm,
               c_accnt_flag = DECODE(c_accnt_flag,
                                     '01',
                                     '11',
                                     '00',
                                     '10',
                                     '10')
           where c_rcpt_no = v_rcpt_no;
      elsif v_due_type = '5' then
        update web_fin_credit_due
           set N_RP_AMT     = N_BS_AMT,
               n_paid_amt   = N_BS_AMT,
               T_PAID_TM    = v_crt_tm,
               T_RP_TM      = v_crt_tm,
               c_accnt_flag = DECODE(c_accnt_flag,
                                     '01',
                                     '11',
                                     '00',
                                     '10',
                                     '10')
           where c_rcpt_no = v_rcpt_no;
      end if;
    end loop;
    close cur_busBill;

    --?????????
    update web_fin_cav_bill
       set n_sum_amt = v_sum_amt
     where c_cav_pk_id = v_cav_pk_id;

    --????????
    INSERT INTO WEB_FIN_CAV_OBJ --????
      (C_CAV_PK_ID,
       n_item_no,
       C_dpt_cde,
       c_sbjt_no,
       n_amt,
       c_crt_cde,
       T_CRT_TM,
       C_UPD_CDE,
       T_UPD_TM,
       c_prod_no,
       C_CUR_CDE,
       c_cav_dir,
       c_sls_cde,
       c_cha_cls,
       c_cha_cde,
       C_PAYER_NME,
       c_bsns_typ)
    values
      (v_CAV_PK_ID,
       v_cavobj_itemno,
       v_dpt_cde,
       '119707', --???? ??
       abs(v_sum_amt), --?????
       'admin',
       sysdate,
       'admin',
       SYSDATE,
       v_prod_no,
       v_bs_cur,
       '2', --'??'
       v_sls_cde,
       v_cha_cls,
       v_cha_cde,
       v_bsns_typ,
       v_payer_nme);
    v_cavobj_itemno := v_cavobj_itemno + 1;

    if v_due_type = '1' and (v_total_other_posamt > 0) then
      INSERT INTO WEB_FIN_CAV_OBJ --????
        (C_CAV_PK_ID,
         n_item_no,
         C_dpt_cde,
         c_sbjt_no,
         n_amt,
         c_crt_cde,
         T_CRT_TM,
         C_UPD_CDE,
         T_UPD_TM,
         c_prod_no,
         C_CUR_CDE,
         c_cav_dir,
         c_sls_cde,
         c_cha_cls,
         c_cha_cde,
         C_PAYER_NME,
         c_bsns_typ)
      values
        (v_CAV_PK_ID,
         v_cavobj_itemno,
         v_dpt_cde,
         '119113', --???????????
         abs(v_total_other_posamt), --?????
         'admin',
         sysdate,
         'admin',
         SYSDATE,
         v_prod_no,
         v_bs_cur,
         '1', --'??'
         v_sls_cde,
         v_cha_cls,
         v_cha_cde,
         v_bsns_typ,
         v_payer_nme);
      v_cavobj_itemno := v_cavobj_itemno + 1;
    end if;

    if v_due_type = '4' or v_due_type = '5' then
      if v_total_other_posamt > 0 then
        INSERT INTO WEB_FIN_CAV_OBJ --????
          (C_CAV_PK_ID,
           n_item_no,
           C_dpt_cde,
           c_sbjt_no,
           n_amt,
           c_crt_cde,
           T_CRT_TM,
           C_UPD_CDE,
           T_UPD_TM,
           c_prod_no,
           C_CUR_CDE,
           c_cav_dir,
           c_sls_cde,
           c_cha_cls,
           c_cha_cde,
           C_PAYER_NME,
           c_bsns_typ)
        values
          (v_CAV_PK_ID,
           v_cavobj_itemno,
           v_dpt_cde,
           '214401', --??????(??????)
           abs(v_total_other_posamt), --?????
           'admin',
           sysdate,
           'admin',
           SYSDATE,
           v_prod_no,
           v_bs_cur,
           '1', --'??'
           v_sls_cde,
           v_cha_cls,
           v_cha_cde,
           v_bsns_typ,
           v_payer_nme);
        v_cavobj_itemno := v_cavobj_itemno + 1;
      end if;
      if v_total_other_negamt < 0 then
        INSERT INTO WEB_FIN_CAV_OBJ --????
          (C_CAV_PK_ID,
           n_item_no,
           C_dpt_cde,
           c_sbjt_no,
           n_amt,
           c_crt_cde,
           T_CRT_TM,
           C_UPD_CDE,
           T_UPD_TM,
           c_prod_no,
           C_CUR_CDE,
           c_cav_dir,
           c_sls_cde,
           c_cha_cls,
           c_cha_cde,
           C_PAYER_NME,
           c_bsns_typ)
        values
          (v_CAV_PK_ID,
           v_cavobj_itemno,
           v_dpt_cde,
           '410905', --????/??????
           abs(v_total_other_negamt), --?????
           'admin',
           sysdate,
           'admin',
           SYSDATE,
           v_prod_no,
           v_bs_cur,
           '2', --'??'
           v_sls_cde,
           v_cha_cls,
           v_cha_cde,
           v_bsns_typ,
           v_payer_nme);
        v_cavobj_itemno := v_cavobj_itemno + 1;
      end if;
    end if;

    if  v_due_type = '1' and  (v_dptacc_cde = '11' or v_dptacc_cde = '1164') then    --???
        INSERT INTO web_fin_cav_obj --????
        (C_CAV_pk_id,
         n_item_no,
         C_dpt_cde,
         c_sbjt_no,
         n_amt,
         c_prod_no,
         C_CUR_CDE,
         c_cav_dir,
         c_sls_cde,
         c_cha_cls,
         c_cha_cde,
         c_payer_nme,
         c_bsns_typ)
      values
        (v_cav_pk_id,
         v_cavobj_itemno,
         v_dpt_cde,
         '214609',                 --????/???
         abs(v_total_bs_amt*0.001), --?????
         v_prod_no,
         v_bs_cur,
         '1', --'??'
         v_sls_cde,
         v_cha_cls,
         v_cha_cde,
         v_bsns_typ,
         v_payer_nme);
      v_cavobj_itemno := v_cavobj_itemno + 1;
    end if;
    --?????
    Dz_Proc.get_FIN_cav_no(v_seq_no, v_dpt_cde, '4', dz_proc.g_pttype);

    --???????
    select count(1)
      into v_counter
      from web_org_dpt
     WHERE c_dpt_cde = v_Dpt_Cde
       and rownum = 1;
    if v_counter = 1 then
      SELECT c_department_cde, c_company_cde
        INTO v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = v_Dpt_Cde
         and rownum = 1;
      v_counter := 0;
    else
      v_department_cde := 'unkown';
      v_company_cde    := 'unkown';
    end if;
    --??????
    select count(1)
      into v_counter
      from web_bas_fin_prod
     where c_prod_no = v_prod_no
       and rownum = 1;

    if v_counter = 1 then
      select c_kind_no
        into v_kind_no
        from web_bas_fin_prod
       where c_prod_no = v_prod_no
         and rownum = 1;
      v_counter := 0;
    else
      v_kind_no := 'unkown';
    end if;
    --????????
    select count(1)
      into v_counter
      from WEB_BAS_FIN_ACCT_PERIOD
     where T_BGN_TM < sysdate
       and T_END_TM > sysdate
       and rownum = 1;

    if v_counter = 1 then
      select C_PERIOD_NAME
        into v_PERIOD_NAME
        from WEB_BAS_FIN_ACCT_PERIOD
       where T_BGN_TM < sysdate
         and T_END_TM > sysdate
         and rownum = 1;
      v_counter := 0;
    else
      v_sucsess_flag := 2;
      return;
    end if;

    --?????
    Dz_Proc.get_fin_voucode(v_vou_no,
                            v_period_name,
                            v_company_cde,
                            dz_proc.g_pttype);

    --?????????
    IF v_Rp_type = '101' OR v_Rp_type = '111' OR v_Rp_type = '112' THEN
      --???
      v_vou_memo       := '????';
      v_servicetype_no := '1102';
    ELSIF v_Rp_type = '103' THEN
      /*103 ???*/
      v_vou_memo       := '?????';
      v_servicetype_no := '1109';
    ELSIF v_Rp_type = '104' THEN
      /*104 ????*/
      v_vou_memo       := '??????';
      v_servicetype_no := '1103';
    ELSIF v_Rp_type = '105' THEN
      /*105 ?????*/
      v_vou_memo       := '?????';
      v_servicetype_no := '1105';
    ELSIF v_Rp_type = '106' THEN
      /*106 ??????*/
      v_vou_memo       := '??????';
      v_servicetype_no := '1110';
    ELSIF v_Rp_type = '107' OR v_Rp_type = '209' THEN
      /*107  ????? 209 */
      v_vou_memo       := '?????????';
      v_servicetype_no := '1114';
    ELSIF v_Rp_type = '201' THEN
      /*201 ??/??-?????/?? 202 ??/??????*/
      v_vou_memo       := '????';
      v_servicetype_no := '1102';
    ELSIF v_Rp_type = '203' THEN
      /*203 ????? */
      v_vou_memo       := '?????';
      v_servicetype_no := '1104';
    ELSIF v_Rp_type = '204' THEN
      /*204 ???? */
      v_vou_memo       := '??????';
      v_servicetype_no := '1107';
    ELSIF v_Rp_type = '205' THEN
      /*205 ??*/
      v_vou_memo       := '????';
      v_servicetype_no := '1108';
    ELSIF v_Rp_type = '102' THEN
      v_vou_memo       := '???????';
      v_servicetype_no := '1111';
    ELSIF v_Rp_type = '132' THEN
      v_vou_memo       := '????';
      v_servicetype_no := '1111';
    ELSIF v_Rp_type = '202' THEN
      v_vou_memo       := '???????';
      v_servicetype_no := '1112';
    ELSIF v_Rp_type = '232' THEN
      v_vou_memo       := '????';
      v_servicetype_no := '9001';
    ELSIF v_Rp_type = '212' THEN
      v_vou_memo       := '???????';
      v_servicetype_no := '1112';
    ELSIF v_Rp_type = '206' THEN
      /*206 ?????*/
      v_vou_memo       := '?????';
      v_servicetype_no := '1106';
    ELSIF v_Rp_type = '207' THEN
      /*207*/
      v_vou_memo       := '??????';
      v_servicetype_no := '1110';
    ELSIF v_Rp_type = '208' THEN
      --???????????
      v_vou_memo := '??????????';
    END IF;
    open cur_cavObj;
    loop
      FETCH cur_cavObj
        INTO v_objsbjt_no, v_objamt, v_cur_cde, v_cav_dir, v_pre_amt, v_pre_flag;
      EXIT WHEN cur_cavObj%NOTFOUND;

      --????
      IF v_rp_type > '200' AND v_cav_dir = '2' THEN
        --?
        v_cav_flag := '?';
      ELSIF v_rp_type > '200' AND v_cav_dir = '1' THEN
        --?
        v_cav_flag := '?';
      ELSIF v_rp_type < '200' AND v_cav_dir = '2' THEN
        --?
        v_cav_flag := '?';
      ELSIF v_rp_type < '200' AND v_cav_dir = '1' THEN
        --?
        v_cav_flag := '?';
      END IF;
      --??????
      select count(1)
        into v_counter
        from web_bas_fin_subject
       where c_sbjt_no = v_objsbjt_no
         and rownum = 1;

      if v_counter = 1 then
        select C_SBJT_NAME
          into v_sbjt_memo
          from web_bas_fin_subject
         where c_sbjt_no = v_objsbjt_no
           and rownum = 1;
        v_counter := 0;
      else
        v_sbjt_memo := '0';
      end if;

      insert into web_fin_dcr
        (C_SEQ_NO,
         C_ITEM_NO,
         C_CAV_FLAG,
         c_sbjt_no,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         t_rp_tm,
         C_DPTACC_NO,
         C_SEND_FLAG,
         c_sbjt_memo,
         c_kind_no,
         c_department_cde,
         c_company_cde,
         c_period_name,
         c_voucher_no,
         c_vou_no,
         n_total_amt,
         C_CAV_NO,
         c_vou_memo,
         c_rp_type,
         C_CHA_CLS,
         C_CHA_CDE,
         c_sls_cde,
         c_bank_cde,
         c_flow_no,
         C_SERVICETYPE_NO,
         c_check_no,
         c_bal_type,
         C_PAY_NAME,
         c_check_cde)
      values
        (v_seq_no,
         to_char(v_dcritem_no),
         v_cav_flag,
         v_objsbjt_no,
         v_objamt,
         v_cur_cde,
         sysdate,
         sysdate,
         v_DPTACC_cde,
         '0',
         '0',
         v_kind_no,
         v_department_cde,
         v_company_cde,
         v_PERIOD_NAME,
         null,
         v_vou_no,
         v_sum_amt,
         v_cav_pk_id,
         v_vou_memo,
         v_rp_type,
         v_CHA_CLS,
         v_CHA_CDE,
         v_sls_cde,
         null,
         null,
         v_SERVICETYPE_NO,
         null,
         null,
         v_PAYER_NME,
         'admin');
      v_dcritem_no := v_dcritem_no + 1; --??????
    end loop;
    close cur_cavObj;
    --?????????
    open cur_cavDoc;
    loop
      FETCH cur_cavDoc
        INTO v_rcpt_no, v_EXCH_RATE, v_BS_CUR, v_BS_AMT, v_prod_no, v_sls_cde, v_bsns_typ, v_cha_cls, v_cha_cde, v_dpt_cde, v_edr_no, v_feetyp_cde, v_PAYER_NME, v_edr_no, v_ply_no;
      EXIT WHEN cur_cavDoc%NOTFOUND;

      --??????
      select count(1)
        into v_counter
        from v_fin_due
       where c_rcpt_no = v_rcpt_no
         and rownum = 1;

      if v_counter = 1 then
        select c_DPTACC_cde
          into v_DPTACC_cde
          from v_fin_due
         where c_rcpt_no = v_rcpt_no
           and rownum = 1;
        v_counter := 0;
      else
        v_DPTACC_cde := 'unkown';
      end if;

      --??????
      select count(1)
        into v_counter
        from web_bas_fin_prod
       where c_prod_no = v_prod_no
         and rownum = 1;

      if v_counter = 1 then
        select c_kind_no
          into v_kind_no
          from web_bas_fin_prod
         where c_prod_no = v_prod_no
           and rownum = 1;
        v_counter := 0;
      else
        v_kind_no := 'unkown';
      end if;

      --???????
      SELECT count(1)
        INTO v_counter
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = v_Dpt_Cde;

      if v_counter = 1 then
        SELECT c_department_cde, c_company_cde
          INTO v_department_cde, v_company_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = v_Dpt_Cde;
        v_counter := 0;
      else
        v_department_cde := 'unkown';
        v_company_cde    := 'unkown';
      end if;

      IF v_Rp_Type > '200' THEN
        --??
        v_Cav_Flag := '?';
      ELSE
        v_Cav_Flag := '?';
      END IF;

      IF v_Rp_Type = '201' AND v_bs_Amt < 0 THEN
        --201 ??/??-?????/?? ??????????    ????/????
        v_Cav_Flag := '?';
      END IF;

      IF v_Rp_Type = '201' AND v_bs_Amt > 0 THEN
        --201 ??/??-?????/?? ??????????
        v_Cav_Flag := '?';
      END IF;

      IF v_Rp_Type = '101' OR v_Rp_Type = '111' OR v_Rp_Type = '112' THEN
        /*101 ?????????/?? */
        select count(1)
          into v_counter
          from web_fin_prm_due
         where c_rcpt_no = v_rcpt_no
           and rownum = 1;

        if v_counter = 1 then
          select c_tran_flag
            into v_tran_flag
            from web_fin_prm_due
           where c_rcpt_no = v_rcpt_no
             and rownum = 1;
          v_counter := 0;
        else
          v_tran_flag := '1';
        end if;

        IF v_tran_flag = '2' THEN
          v_Sbjt_No  := '122204';
          v_bs_Amt   := v_bs_Amt;
          v_Cav_Flag := '?';
        ELSE
          IF v_bs_Amt > 0 AND v_bal_flag = '2' THEN
            --??????,??????????
            v_Sbjt_No := '212101'; --????
          ELSIF v_bs_Amt > 0 AND v_bal_flag = '1' THEN
            --??????,??????????
            v_Sbjt_No := '112201'; --????
          ELSE
            v_Sbjt_No := '112201'; --????
          END IF;

          IF v_bs_Amt < 0 THEN
            IF v_bal_flag = '2' THEN
              --??
              v_Sbjt_No := '212101';
              v_bs_Amt  := -ABS(v_bs_Amt);
            ELSE
              --??
              v_Sbjt_No := '112201';
              v_bs_Amt  := -ABS(v_bs_Amt);
            END IF;
          END IF;
          v_Cav_Flag := '?';
        END IF;
      ELSIF v_Rp_Type = '103' THEN
        /*103 ??? */
        v_Sbjt_No  := '440106'; --????/????? ?????? ???? 440106
        v_Cav_Flag := '?';
        v_bs_Amt   := v_bs_Amt;
        SELECT count(1)
          INTO v_counter
          FROM WEB_FIN_CLM_DUE
         WHERE c_rcpt_no = v_Rcpt_No
           and rownum = 1;

        if v_counter = 1 then
          SELECT c_eac_dcm_mrk
            INTO v_eac_dcm_mrk
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_Rcpt_No
             and rownum = 1;
          v_counter := 0;
        else
          v_eac_dcm_mrk := '1';
        end if;

        --????????????
        IF v_eac_dcm_mrk = '1' THEN
          BEGIN
            v_Sbjt_No := '212201';
          END;
        ELSIF v_eac_dcm_mrk = '5' THEN
          --???
          /*
              ??????
              ??????????
          */
          v_Sbjt_No := '440104';
        ELSIF v_eac_dcm_mrk = '2' THEN
          /*
              ??????
              ??????
          */
          v_Sbjt_No := '215001';
        ELSIF v_eac_dcm_mrk = '6' THEN
          --??????
          v_Sbjt_No := '440104';
        END IF;
      ELSIF v_Rp_Type = '201' THEN
        /*201 ??/??-?????/?? ????????????????????   ?????????????????????????? ??????*/
        select count(1)
          into v_counter
          from web_fin_prm_due
         where c_rcpt_no = v_rcpt_no
           and rownum = 1;

        if v_counter = 1 then
          select c_tran_flag
            into v_tran_flag
            from web_fin_prm_due
           where c_rcpt_no = v_rcpt_no
             and rownum = 1;
          v_counter := 0;
        else
          v_tran_flag := '1';
        end if;

        IF v_tran_flag = '2' THEN
          v_Sbjt_No  := '122204';
          v_bs_Amt   := v_bs_Amt;
          v_Cav_Flag := '?';
        ELSE
          IF v_bs_Amt > 0 THEN
            /*?????????????????????????? ???????????????????????????????*/
            IF v_bal_flag = '2' THEN
              --??
              v_Sbjt_No  := '212101';
              v_Cav_Flag := '?';
            ELSE
              --??
              v_Sbjt_No  := '112201';
              v_Cav_Flag := '?';
            END IF;
            v_bs_Amt := -ABS(v_bs_Amt);
          ELSE
            IF v_bal_flag = '2' THEN
              v_Sbjt_No  := '212101'; --????
              v_Cav_Flag := '?';
              v_bs_Amt   := ABS(v_bs_Amt);
            ELSE
              v_Sbjt_No  := '112201'; --????
              v_Cav_Flag := '?';
              v_bs_Amt   := ABS(v_bs_Amt);
            END IF;
          END IF;
        END IF;
      ELSIF v_Rp_Type = '202' THEN
        /*202 ??/??????*/
        v_Sbjt_No  := '217101'; --????
        v_Cav_Flag := '?';
        v_bs_Amt   := -v_bs_Amt;
      ELSIF v_Rp_Type = '232' THEN
        v_Sbjt_No  := 'X17101';
        v_Cav_Flag := '?';
        v_bs_Amt   := -v_bs_Amt;
      ELSIF v_Rp_Type = '212' THEN
        /*212 ??/??????*/
        v_Sbjt_No  := '217101'; --????
        v_Cav_Flag := '?';
        IF v_edr_no = '' or v_edr_no is null THEN
          v_Sbjt_No  := '217101'; --????
          v_bs_Amt   := v_bs_Amt;
          v_Cav_Flag := '?';
        ELSE
          v_bs_Amt := -v_bs_Amt;
        END IF;
      ELSIF v_Rp_Type = '102' THEN
        /*102 ???*/
        v_Sbjt_No  := '217101'; --????
        v_Cav_Flag := '?';
        IF v_edr_no <> ' ' and v_edr_no is not null THEN
          v_Sbjt_No  := '217101'; --????
          v_bs_Amt   := -v_bs_Amt;
          v_Cav_Flag := '?';
        ELSE
          v_bs_Amt := v_bs_Amt;
        END IF;
      ELSIF v_Rp_Type = '132' THEN
        v_Sbjt_No  := 'X17101';
        v_Cav_Flag := '?';

        IF v_edr_no <> ' ' and v_edr_no is not null THEN
          v_Sbjt_No  := 'X17101';
          v_bs_Amt   := -v_bs_Amt;
          v_Cav_Flag := '?';
        ELSE
          v_bs_Amt := v_bs_Amt;
        END IF;
      ELSIF v_Rp_Type = '204' THEN
        /*204 ????*/
        SELECT count(1)
          INTO v_counter
          FROM WEB_FIN_CLM_DUE
         WHERE c_rcpt_no = v_Rcpt_No
           and rownum = 1;
        if v_counter = 1 then
          SELECT c_eac_dcm_mrk
            INTO v_eac_dcm_mrk
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_Rcpt_No
             and rownum = 1;
          v_counter := 0;
        else
          v_eac_dcm_mrk := '1';
        end if;

        v_bs_Amt := -v_bs_Amt;
        IF v_eac_dcm_mrk = '1' THEN
          v_Sbjt_No := '113101'; --??????????  ?????????
        ELSIF v_eac_dcm_mrk = '5' THEN
          --5 ???
          v_Sbjt_No := '440104';
        ELSIF v_eac_dcm_mrk = '6' THEN
          --6??????
          v_Sbjt_No := '440104';
        END IF;
      ELSIF v_Rp_Type = '205' THEN
        /*205 ??*/
        v_bs_Amt := -v_bs_Amt;
        IF v_eac_dcm_mrk = '2' THEN
          v_Cav_Flag := '?';
          v_Sbjt_No  := '215001'; --????
        ELSIF v_eac_dcm_mrk = '1' THEN
          v_Cav_Flag := '?';
          v_Sbjt_No  := '113101'; --??????????  ?????????
        ELSIF v_eac_dcm_mrk = '5' THEN
          --5 ???
          v_Cav_Flag := '?';
          v_Sbjt_No  := '440104';
        ELSE
          -- ?:  ????  ?: ?????????
          v_Cav_Flag := '?';
          v_Sbjt_No  := '410301';
        END IF;
      ELSIF v_Rp_Type = '105' THEN
        /*105 ????? ????????? ???????*/
        v_Sbjt_No  := '211101';
        v_Cav_Flag := '?';
        v_bs_Amt   := v_bs_Amt;
      ELSIF v_Rp_Type = '206' THEN
        /*206 ?????*/
        v_Sbjt_No  := '211101'; --?????
        v_Cav_Flag := '?';
        v_bs_Amt   := -v_bs_Amt;
      ELSIF v_Rp_Type = '106' THEN
        v_bs_Amt   := ABS(v_bs_Amt);
        v_Cav_Flag := '?';
        v_Sbjt_No  := '215001'; /*?????-??????*/
      ELSIF v_Rp_Type = '207' THEN
        select count(1)
          into v_counter
          from web_fin_clm_due
         where c_rcpt_no = v_rcpt_no
           and rownum = 1;

        if v_counter = 1 then
          select c_tran_flag
            into v_tran_flag
            from web_fin_clm_due
           where c_rcpt_no = v_rcpt_no
             and rownum = 1;
          v_counter := 0;
        else
          v_tran_flag := '1';
        end if;

        v_bs_Amt   := -v_bs_Amt;
        v_Cav_Flag := '?';
        IF v_tran_flag = '2' THEN
          v_Sbjt_No := '122204';
        ELSE
          v_Sbjt_No := '215001'; /*?????????*/
        END IF;
      END IF;

      insert into web_fin_dcr
        (C_SEQ_NO,
         C_ITEM_NO,
         C_CAV_FLAG,
         c_sbjt_no,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         t_rp_tm,
         c_dpt_cde,
         C_DPTACC_NO,
         C_SEND_FLAG,
         c_sbjt_memo,
         c_kind_no,
         c_department_cde,
         c_company_cde,
         c_period_name,
         c_voucher_no,
         c_vou_no,
         n_total_amt,
         C_CAV_NO,
         c_rcpt_no,
         c_ply_no,
         c_vou_memo,
         c_rp_type,
         C_CHA_CLS,
         C_CHA_CDE,
         c_sls_cde,
         c_bank_cde,
         c_flow_no,
         C_SERVICETYPE_NO,
         c_check_no,
         c_bal_type,
         C_PAY_NAME,
         c_check_cde)
      values
        (v_seq_no,
         to_char(v_dcritem_no),
         v_cav_flag,
         v_Sbjt_No,
         v_bs_Amt,
         v_BS_CUR,
         sysdate,
         sysdate,
         v_dpt_cde,
         v_DPTACC_cde,
         '0',
         '0',
         v_kind_no,
         v_department_cde,
         v_company_cde,
         v_PERIOD_NAME,
         null,
         v_vou_no,
         v_sum_Amt,
         v_cav_pk_id,
         v_rcpt_no,
         v_ply_no,
         v_vou_memo,
         v_rp_type,
         v_CHA_CLS,
         v_CHA_CDE,
         v_sls_cde,
         null,
         null,
         v_SERVICETYPE_NO,
         null,
         null,
         v_PAYER_NME,
         'admin');
      v_dcritem_no := v_dcritem_no + 1; --??????
    end loop;
    close cur_cavDoc;

    v_intfitem_no := 1;
    open cur_dcr;
    loop
      fetch cur_dcr
        into v_sum_amt, v_dpt_cde, v_prod_no, v_cav_flag, v_sbjt_no, v_bs_cur;
      EXIT WHEN cur_dcr%NOTFOUND;

      select count(1)
        into v_counter
        from WEB_FIN_DCR
       WHERE c_seq_no = v_seq_no
         and c_dpt_cde = v_dpt_cde
         and c_kind_no = v_prod_no
         and c_cav_flag = v_cav_flag
         and c_sbjt_no = v_sbjt_no
         and c_cur_no = v_bs_cur
         and rownum = 1;

      INSERT INTO web_fin_dcr_intf
        ( --C_DCRINTF_PK_ID,  --LZC ADD 20090425
         c_seq_no,
         c_item_no,
         c_cav_flag,
         c_sbjt_no,
         c_sbjt_memo,
         n_amt,
         n_exch_amt,
         n_rate,
         c_chr_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_flow_no,
         c_rp_type,
         c_ri_com,
         C_BAL_TYPe,
         c_bank_cde,
         c_check_no,
         t_rp_tm,
         c_prod_no,
         c_send_flag,
         c_cont_code,
         c_dpt_cde,
         c_vou_memo,
         c_con_dpt_cde,
         c_cost_cde,
         c_salegrp_cde,
         c_bsns_typ,
         c_cha_mrk,
         c_check_flag,
         n_total_amt,
         c_company_cde,
         c_period_name,
         C_CAV_no,
         c_vou_no,
         c_cur_no,
         c_servicetype_no,
         c_finbank_cde,
         c_department_cde)
        SELECT --vVouNo||'-'||c_item_no,     --LZC ADD 20090425
         v_seq_no,
         v_intfitem_no,
         v_cav_flag,
         (SELECT c_finsbjt_no
            FROM WEB_BAS_FIN_SUBJECT
           WHERE c_sbjt_no = v_sbjt_no),
         '0', --c_sbjt_memo
         v_sum_amt,
         v_sum_amt,
         n_rate,
         c_chr_cur_no,
         sysdate,
         c_dptacc_no,
         c_flow_no,
         c_rp_type,
         c_ri_com,
         C_BAL_TYPe,
         c_bank_cde,
         c_check_no,
         t_rp_tm,
         nvl(v_prod_no, '0'),
         c_send_flag,
         c_cont_code,
         c_dpt_cde,
         c_vou_memo,
         c_con_dpt_cde,
         c_cost_cde,
         c_salegrp_cde, --c_bsns_typ
         '0',
         c_cha_mrk,
         c_check_flag,
         n_total_amt,
         c_company_cde,
         c_period_name,
         C_CAV_NO,
         c_vou_no,
         DECODE(v_bs_cur,
                '01',
                'CNY',
                '02',
                'HKD',
                '03',
                'USD',
                '12',
                'EUR',
                '13',
                'EUR',
                '05',
                'JPY',
                v_bs_cur),
         c_servicetype_no,
         c_finbank_cde,
         c_department_cde
          FROM WEB_FIN_DCR
         WHERE c_seq_no = v_seq_no
           and c_dpt_cde = v_dpt_cde
           and c_kind_no = v_prod_no
           and c_cav_flag = v_cav_flag
           and c_sbjt_no = v_sbjt_no
           and c_cur_no = v_bs_cur
           and rownum = 1;
      v_intfitem_no := v_intfitem_no + 1;
      update web_fin_dcr
         set c_voucher_no = v_vou_no
       where c_seq_no = v_seq_no
         and c_dpt_cde = v_dpt_cde
         and c_kind_no = v_prod_no
         and c_cav_flag = v_cav_flag
         and c_sbjt_no = v_sbjt_no
         and c_cur_no = v_bs_cur;
    end loop;
    close cur_dcr;

    /*
    ???? 119303       ????? 02||company_id
    ??????  10020101
    */
    select n_total_amt, c_company_cde,c_servicetype_no
      into v_sum_amt,  v_company_cde,v_servicetype_no
      from web_fin_dcr
     where c_seq_no = v_seq_no
       and c_rcpt_no is not null
       and rownum = 1;
   --???????????
    dz_proc.get_fin_voucode(v_gcvou_no, v_period_name, '1000100',dz_proc.g_pttype);
    dz_proc.get_fin_no(v_seq_no, '00000019', '7',dz_proc.g_pttype);
    --????????
    select c_sbjt_no into v_sbjt_no from web_bas_fin_bank where c_bank_cde=v_bank_cde;

     INSERT INTO web_fin_dcr --??????
      (c_seq_no,
       c_item_no,
       c_cav_flag,
       c_sbjt_no,
       n_amt,
       c_cur_no,
       t_crt_tm,
       c_dptacc_no,
       c_send_flag,
       c_sbjt_memo,
       c_kind_no,
       c_department_cde,
       c_company_cde,
       c_period_name,
       c_vou_memo,
       c_voucher_no,
       c_vou_no,
       n_total_amt,
       c_cav_no,
       c_rp_type,
       t_rp_tm,
       c_servicetype_no)
    values
      (v_seq_no,
       TO_CHAR(1),
       '?',
       v_sbjt_no,--'10020101',
       v_sum_amt,
       '01',
       sysdate,
       '00000019',
       '0', --c_send_flag
       '0', --c_sbjt_memo
       '0', --c_kind_no
       '0', --c_department_cde
       '1000100',
       v_period_name,
       v_vou_memo,
       v_gcvou_no,
       v_gcvou_no,
       v_sum_amt,
       v_cav_pk_id,
       v_rp_type,
       sysdate,
       v_servicetype_no);

    INSERT INTO web_fin_dcr --????
      (c_seq_no,
       c_item_no,
       c_cav_flag,
       c_sbjt_no,
       n_amt,
       c_cur_no,
       t_crt_tm,
       c_dptacc_no,
       c_send_flag,
       c_sbjt_memo,
       c_kind_no,
       c_department_cde,
       c_company_cde,
       c_period_name,
       c_vou_memo,
       c_voucher_no,
       c_vou_no,
       n_total_amt,
       c_cav_no,
       c_rp_type,
       t_rp_tm,
       c_servicetype_no)
    values
      (v_seq_no,
       TO_CHAR(2),
       '?',
       '119607',
       v_sum_amt,
       '01',
       sysdate,
       '00000019',
       '0',
       '02' || v_company_cde,
       '0',
       '0',
       '1000100',
       v_period_name,
       v_vou_memo,
       v_gcvou_no,
       v_gcvou_no,
       v_sum_amt,
       v_cav_pk_id,
       v_rp_type,
       sysdate,
       v_servicetype_no);

    --?????
    INSERT INTO web_fin_dcr_intf
      (c_seq_no,
       c_item_no,
       c_cav_flag,
       c_sbjt_no,
       c_sbjt_memo,
       n_amt,
       n_exch_amt,
       c_cur_no,
       n_rate,
       c_chr_cur_no,
       t_crt_tm,
       c_dptacc_no,
       c_flow_no,
       c_rp_type,
       c_ri_com,
       c_bal_type,
       c_bank_cde,
       c_check_no,
       t_rp_tm,
       c_prod_no,
       c_send_flag,
       c_cont_code,
       c_dpt_cde,
       c_vou_memo,
       c_con_dpt_cde,
       c_cost_cde,
       c_company_cde,
       c_salegrp_cde,
       c_bsns_typ,
       c_cha_mrk,
       c_vou_no,
       c_period_name,
       n_total_amt,
       c_servicetype_no,
       c_department_cde,
       c_rcpt_no,
       c_cav_no)
      SELECT v_seq_no,
             TO_CHAR(1),
             '?',
             (SELECT c_finsbjt_no
                FROM web_bas_fin_subject
               WHERE c_sbjt_no = web_fin_dcr.c_sbjt_no),
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             DECODE(c_cur_no,
                    '01',
                    'CNY',
                    '02',
                    'HKD',
                    '03',
                    'USD',
                    '12',
                    'EUR',
                    '13',
                    'EUR',
                    '05',
                    'JPY',
                    c_cur_no),
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             '00000019',
             c_flow_no,
             v_rp_type,
             c_ri_com,
             c_bal_type,
             NULL,
             c_check_no,
             t_rp_tm,
             c_kind_no,
             '0',
             c_cont_code,
             '0',
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             '1000100',
             c_salegrp_cde,
             '0',
             c_cha_mrk,
             c_voucher_no,
             c_period_name,
             v_sum_amt,
             v_servicetype_no,
             '0',
             c_rcpt_no,
             v_cav_pk_id
        FROM web_fin_dcr
       WHERE c_seq_no = v_seq_no
         AND c_item_no = '1';

    INSERT INTO web_fin_dcr_intf
      (c_seq_no,
       c_item_no,
       c_cav_flag,
       c_sbjt_no,
       c_sbjt_memo,
       n_amt,
       n_exch_amt,
       c_cur_no,
       n_rate,
       c_chr_cur_no,
       t_crt_tm,
       c_dptacc_no,
       c_flow_no,
       c_rp_type,
       c_ri_com,
       c_bal_type,
       c_bank_cde,
       c_check_no,
       t_rp_tm,
       c_prod_no,
       c_send_flag,
       c_cont_code,
       c_dpt_cde,
       c_vou_memo,
       c_con_dpt_cde,
       c_cost_cde,
       c_company_cde,
       c_salegrp_cde,
       c_bsns_typ,
       c_cha_mrk,
       c_vou_no,
       c_period_name,
       n_total_amt,
       c_servicetype_no,
       c_department_cde,
       c_rcpt_no,
       c_cav_no)
      SELECT v_seq_no,
             TO_CHAR(2),
             '?',
             '119607',
             c_sbjt_memo,
             n_amt,
             n_exch_amt,
             DECODE(c_cur_no,
                    '01',
                    'CNY',
                    '02',
                    'HKD',
                    '03',
                    'USD',
                    '12',
                    'EUR',
                    '13',
                    'EUR',
                    '05',
                    'JPY',
                    c_cur_no),
             n_rate,
             c_chr_cur_no,
             t_crt_tm,
             '00000019',
             c_flow_no,
             v_rp_type,
             c_ri_com,
             c_bal_type,
             NULL,
             c_check_no,
             t_rp_tm,
             c_kind_no,
             '0',
             c_cont_code,
             '0',
             c_vou_memo,
             c_con_dpt_cde,
             c_cost_cde,
             '1000100',
             c_salegrp_cde,
             '0',
             c_cha_mrk,
             c_voucher_no,
             c_period_name,
             v_sum_amt,
             v_servicetype_no,
             '0',
             c_rcpt_no,
             v_cav_pk_id
        FROM web_fin_dcr
       WHERE c_seq_no = v_seq_no
         AND c_item_no = '2';

        --???
    update web_fin_dcr_intf   --????
       set c_prod_no = '0', c_department_cde = '0'
     where c_vou_no in (v_vou_no, v_gcvou_no)
       and c_sbjt_no = '119607'
       or  c_sbjt_no = '214609';

    update web_fin_dcr_intf   --???
       set c_prod_no = '0'
     where c_vou_no in (v_vou_no, v_gcvou_no)
       and c_sbjt_no = '119113';
    Collectfu.ValidityCheckCavVou(v_Vou_no, v_return);
    if v_return = 0 then
      Collectfu.ValidityCheckCavVou(v_gcvou_no, v_return);
    end if;
    if v_return <> 0 then
      dbms_output.put_line('exception' || '*' || v_dpt_cde || v_bs_cur ||
                           SQLERRM);
      ROLLBACK;

      v_err_content := 'proc:[AutoAccounts.ValidityCheckCavVou],??????[' ||
                       v_seq_no || '-' || v_return || '],?????[' ||
                       SQLCODE || SQLERRM;

      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'),
         '001', --??????
         '0000', --??????
         v_err_content,
         SYSDATE);
      COMMIT;
    end if;


    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_dpt_cde || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[AutoAccounts],??????[' || v_seq_no || '-' ||
                         v_dpt_cde || '-' || v_prod_no || '-' || v_cav_flag || '-' ||
                         v_sbjt_no || '-' || v_bs_cur || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;

  end;

  procedure AutoAccountsGather IS
     v_dptacc_cde  web_org_dpt.c_dptacc_cde%type;
     v_cur_cde     web_fin_prm_due.c_bs_cur%type;
     v_prod_no     web_fin_prm_due.c_prod_no%type;
     v_crt_tm      web_fin_prm_due.t_crt_tm%type;

     v_batch_no    web_fin_prm_due.c_batch_no%type;
     v_err_content web_bas_fin_errorlog.c_err_content%type;

     CURSOR cur_due is --?????????????
      select trunc(a.t_crt_tm),b.c_dptacc_cde,a.c_bs_cur,a.c_prod_no
        from web_fin_prm_due a,web_org_dpt b
       where  a.c_dpt_cde = b.c_dpt_cde
         and b.c_dptacc_cde not like '03%'
         and b.c_dptacc_cde not like '27%'
         and a.c_accnt_flag in ('00','01')
         and exists (select 1 from web_fin_rpe_doc where c_rcpt_no = a.c_rcpt_no)
        group by trunc(a.t_crt_tm),b.c_dptacc_cde,a.c_prod_no,a.c_bs_cur;
  BEGIN

    OPEN cur_due;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_due
        INTO v_crt_tm,v_dptacc_cde, v_cur_cde,v_prod_no;
      EXIT WHEN cur_due%NOTFOUND;

      --?????
      Dz_Proc.get_fin_no(v_batch_no, v_dptacc_cde, '7',dz_proc.g_pttype);

      UPDATE web_fin_prm_due a
         SET c_batch_no = v_batch_no
       WHERE 1=1
        AND a.c_batch_no IS NULL
        and a.c_accnt_flag in ('00','01')
        and a.t_crt_tm >= v_crt_tm
        and a.t_crt_tm < v_crt_tm+1
        and a.c_bs_cur = v_cur_cde
        and a.c_prod_no = v_prod_no
        and exists (select 1 from web_org_dpt b
               where a.c_dpt_cde  = b.c_dpt_cde
                 and b.c_dptacc_cde= v_dptacc_cde
                 and b.c_dptacc_cde not like '03%'
                 and b.c_dptacc_cde not like '27%')
        and exists (select 1 from web_fin_rpe_doc
               where c_rcpt_no  = a.c_rcpt_no);
      commit;
    END LOOP;
    CLOSE cur_due;
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_crt_tm ||'|'||v_dptacc_cde ||'|'||
                              v_cur_cde ||'|'|| v_prod_no || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[AutoAccountsGather],??????[' || v_crt_tm ||'|'||v_dptacc_cde ||'|'||
                         v_cur_cde ||'|'|| v_prod_no || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO web_bas_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

END Autocollect;
/
