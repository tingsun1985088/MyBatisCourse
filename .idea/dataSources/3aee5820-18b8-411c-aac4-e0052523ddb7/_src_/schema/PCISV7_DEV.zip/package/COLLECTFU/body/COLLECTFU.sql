CREATE PACKAGE BODY "COLLECTFU" 
IS
-- 处理会计员冲正时处理单据
PROCEDURE chargeagainst (vcavno IN VARCHAR2, v_succsflag IN OUT NUMBER)
   IS
      --预收处理变量
      vitemno         web_fin_cav_obj.n_item_no%TYPE;
      vamt            web_fin_cav_obj.n_amt%TYPE;
      v_cur_cde       web_fin_cav_obj.c_cur_cde%TYPE;
      vdptcde         web_fin_cav_obj.c_dpt_cde%TYPE;
      vslscde         web_fin_cav_obj.c_sls_cde%TYPE;
      vprodno         web_fin_cav_obj.c_prod_no%TYPE;
      vocavno         web_fin_cav_obj.c_ocav_no%TYPE;
      voitemno        web_fin_cav_obj.c_oitem_no%TYPE;
      vchacls         web_fin_cav_obj.c_cha_cls%TYPE;
      vchacde         web_fin_cav_obj.c_cha_cde%TYPE;
      vpayname        web_fin_cav_obj.c_payer_nme%TYPE;
      vpreamt         web_fin_pre_mny.n_pre_amt%TYPE;
      vpreflag        web_fin_cav_obj.c_pre_flag%TYPE;
      v_nbal_tm       INT;
      v_rp_cur        web_fin_cav_doc.c_rp_cur%TYPE;
      v_rp_amt        web_fin_cav_doc.n_rp_amt%TYPE;

      CURSOR cur_ifcavobject
      IS
         SELECT n_item_no, n_amt,
                                 --c_cur_CDE,
                                 c_dpt_cde, c_sls_cde, c_prod_no, c_cha_cls,
                c_cha_cde, c_payer_nme, n_pre_amt, c_pre_flag, c_ocav_no,
                c_oitem_no
           FROM web_fin_cav_obj
          WHERE c_cav_pk_id = vcavno
                and c_sbjt_no='220303';

      --业务单据处理变量
      vrptype         web_fin_cav_bill.c_rp_type%TYPE;
      vrcptno         web_fin_cav_doc.c_rcpt_no%TYPE;
      vgotprm         web_fin_cav_doc.n_bs_amt%TYPE;
      v_bill_flag     web_fin_cav_doc.c_bill_flag%TYPE;
      v_err_content   web_bas_fin_errorlog.c_err_content%TYPE;

      CURSOR cur_ifcavdoc
      IS
         SELECT c_rcpt_no, n_bs_amt, c_bill_flag
           FROM web_fin_cav_doc
          WHERE c_cav_pk_id = vcavno;
   /*
     CURSOR cur_ifCavRi IS
       SELECT c_rcpt_no, n_paid_amt
         FROM WEB_FIN_CAV_RIDOC
        WHERE C_CAV_PK_ID = vCavNo;
   */
   BEGIN
      --冲正收付单处理
      v_succsflag := 0;

      SELECT c_cur_cde
        INTO v_cur_cde
        FROM web_fin_cav_bill
       WHERE c_cav_pk_id = vcavno;

      /*
          1.回写对应的预收表
          2.回写对应的接口表
          3.回写标识冲正标识
      */

      --1.回写对应的预收表
      OPEN cur_ifcavobject;

      LOOP
         FETCH cur_ifcavobject
          INTO vitemno, vamt, vdptcde, vslscde, vprodno, vchacls, vchacde,
               vpayname, vpreamt, vpreflag, vocavno, voitemno;

         EXIT WHEN cur_ifcavobject%NOTFOUND;

        /* IF vpreflag = '1' THEN
            --预收 注意预收需增加一个复核标识，只有复核通过的才能够供收付用
           UPDATE web_fin_rppre_money
               SET n_usepre_amt = n_usepre_amt - vamt
             WHERE c_cav_no = vocavno
               AND c_item_no = voitemno
               AND c_pre_flag = '1';
         ELSE
            --处理轨迹
            UPDATE web_fin_rppre_money
               SET n_usepre_amt = n_usepre_amt - vamt
             WHERE c_ocav_no = vocavno
               AND c_oitem_no = voitemno
               AND c_pre_flag = '1';
         END IF;*/
         --更新原预收单的已使用金额
          UPDATE web_fin_rppre_money SET n_usepre_amt = n_usepre_amt - vamt
             WHERE c_cav_no = vocavno
               AND c_item_no = voitemno
               AND c_pre_flag = '1';
          --冲销新单据（匹配的）产生的预收
         UPDATE web_fin_rppre_money SET c_check_flag = '3' WHERE c_cav_no = vcavno AND c_item_no = vitemno;
      END LOOP;
      CLOSE cur_ifcavobject;
      commit;
   --2.回写对应的接口表
   --业务单据处理
   /*
   SELECT c_rp_type
     INTO vRpType
     FROM WEB_FIN_CAV_BILL
    WHERE C_CAV_PK_ID = vCavNo;

   vRpType := TRIM(vRpType);

   OPEN cur_ifCavDoc;
   LOOP
     FETCH cur_ifCavDoc
       INTO vRcptNo, vGotPrm, v_bill_flag;
     EXIT WHEN cur_ifCavDoc%NOTFOUND;

     IF vRpType = '101' OR vRpType = '111' OR vRpType = '112' THEN
       --101 收回应收保费、加保/加费 102 收储金
       UPDATE WEB_FIN_PRM_DUE
          SET N_RP_AMT = N_RP_AMT - vGotPrm,
              n_paid_amt      = n_paid_amt - vGotPrm,
              c_rp_cur       = NULL,
              T_RP_TM       = NULL,
              T_PAID_TM     = NULL,
              t_upd_tm       = SYSDATE,
              c_accnt_flag   = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;
        update FinPrmDueVO a SET

a.CRpCur='',a.NRpAmt='',a.TRpTm='',a.CRpFlag='',a.TPaidTm='',a.NPaidAmt='',a.TUpdTm=:TUpdTm,a.CUpdCde=:CUpdCde,"
         + "a.CAccntFlag=:CAccntFlag where a.CRcptNo=:CRcptNo

     ELSIF vRpType = '103' OR vRpType = '106' THEN
       --103 追偿款
       UPDATE WEB_FIN_CLM_DUE
          SET N_RP_AMT = N_RP_AMT - (-vGotPrm),
              n_paid_amt      = n_paid_amt - (-vGotPrm),
              c_rp_cur        = NULL,
              T_RP_TM        = NULL,
              T_PAID_TM      = NULL,
              t_upd_tm        = SYSDATE,
              c_accnt_flag    = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;
       --ELSIF vRpType='104' THEN 104 预收保费
     ELSIF vRpType = '105' THEN
       --105 收回手续费
       UPDATE WEB_FIN_PAY_DUE
          SET N_RP_AMT = N_RP_AMT - (-vGotPrm),
              n_paid_amt      = n_paid_amt - (-vGotPrm),
              c_rp_cur        = NULL,
              T_RP_TM        = NULL,
              T_PAID_TM      = NULL,
              t_upd_tm        = SYSDATE,
              c_accnt_flag    = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;
     ELSIF vRpType = '102' THEN
       UPDATE WEB_FIN_SAVEAMT_DUE
          SET N_RP_AMT = 0,
              n_paid_amt      = 0,
              c_rp_cur        = NULL,
              T_RP_TM        = NULL,
              T_PAID_TM      = NULL,
              t_upd_tm        = SYSDATE,
              c_accnt_flag    = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;
     ELSIF vRpType = '201' THEN
       --201 减保/退费-保费，退保/退费 202 返还/退还保户储金
       UPDATE WEB_FIN_PRM_DUE
          SET N_RP_AMT = N_RP_AMT - vGotPrm,
              n_paid_amt      = n_paid_amt - vGotPrm,
              c_rp_cur       = NULL,
              T_RP_TM       = NULL,
              T_PAID_TM     = NULL,
              t_upd_tm       = SYSDATE,
              c_accnt_flag   = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;
     ELSIF vRpType = '204' OR vRpType = '205' OR vRpType = '207' THEN
       --204 预付赔款 205 赔款
       UPDATE WEB_FIN_CLM_DUE
          SET N_RP_AMT = N_RP_AMT - (-vGotPrm),
              n_paid_amt      = n_paid_amt - (-vGotPrm),
              c_rp_cur        = NULL,
              T_RP_TM        = NULL,
              T_PAID_TM      = NULL,
              t_upd_tm        = SYSDATE,
              c_accnt_flag    = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;
     ELSIF vRpType = '206' THEN
      --206 支出手续费
       UPDATE WEB_FIN_PAY_DUE
          SET N_RP_AMT = N_RP_AMT - (-vGotPrm),
              n_paid_amt      = n_paid_amt - (-vGotPrm),
              c_rp_cur        = NULL,
              T_RP_TM        = NULL,
              T_PAID_TM      = NULL,
              t_upd_tm        = SYSDATE,
              c_accnt_flag    = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;
     ELSIF vRpType = '202' THEN
       /*
          UPDATE WEB_FIN_SAVEAMT_DUE
              SET N_RP_AMT=N_RP_AMT-(-vGotPrm),
              n_paid_amt=n_paid_amt-(-vGotPrm),
              c_rp_cur=NULL,n_rp_amt= NVL(n_rp_amt,0) - (-v_rp_amt),
              T_RP_TM=NULL,T_PAID_TM=NULL,
              t_upd_tm=SYSDATE,c_accnt_flag='0'||(c_accnt_flag-10)
              WHERE c_rcpt_no=vRcptNo;
       */
   /*  UPDATE WEB_FIN_SAVEAMT_DUE
              SET N_RP_AMT = 0,
                  n_paid_amt      = 0,
                  c_rp_cur        = NULL,
                  T_RP_TM        = NULL,
                  T_PAID_TM      = NULL,
                  t_upd_tm        = SYSDATE,
                  c_accnt_flag    = '0' || (c_accnt_flag - 10)
            WHERE c_rcpt_no = vRcptNo;

         END IF;

       END LOOP;
       CLOSE cur_ifCavDoc;
   */
   /*
     OPEN cur_ifCavRi;
     LOOP
       FETCH cur_ifCavRi
         INTO vRcptNo, vGotPrm;
       EXIT WHEN cur_ifCavRi%NOTFOUND;

       UPDATE WEB_FIN_RICED_DUE
          SET n_real_got_fee = n_real_got_fee - vGotPrm,
              n_got_fee      = n_got_fee - vGotPrm,
              T_RP_TM       = NULL,
              T_PAID_TM     = NULL,
              t_upd_tm       = SYSDATE,
              c_accnt_flag   = '0' || (c_accnt_flag - 10)
        WHERE c_rcpt_no = vRcptNo;

       UPDATE WEB_FIN_RIBILL_DUE
          SET T_RP_TM     = NULL,
              T_PAID_TM   = NULL,
              t_upd_tm     = SYSDATE,
              c_accnt_flag = '0' || (c_accnt_flag - 10)
        WHERE c_vou_no = vRcptNo;

     END LOOP;
     CLOSE cur_ifCavRi;
   */
   --3。回写标识冲正标识
   /*
       UPDATE WEB_FIN_CAV_BILL
           SET c_check_flag='3'
           WHERE C_CAV_PK_ID=vCavNo;
   */
   --4.处理类凭证信息
   EXCEPTION
      WHEN OTHERS
      THEN
         BEGIN
            --RAISE;
            v_succsflag := -9;
            DBMS_OUTPUT.put_line ('exception' || '*' || vcavno || SQLERRM);
         END;
   END;
END collectfu;
/
