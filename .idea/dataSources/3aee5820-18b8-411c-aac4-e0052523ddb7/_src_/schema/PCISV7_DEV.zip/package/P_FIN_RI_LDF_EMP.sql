CREATE package P_FIN_RI_LDF_EMP is
  --Original Weightings 基于已决原始加权平均法
  procedure P_Fin_RI_Amt_Ldf_OWS(today1 varchar2, v_cal_type in char, v_return out varchar2);
  --Original Weightings 基于已报原始加权平均法
  procedure P_Fin_RI_Report_Ldf_OWS(today1 varchar2, v_cal_type in char, v_return out varchar2);

  -- 基于已决简单算术平均法
  procedure P_Fin_RI_Amt_Ldf_SA(today1 varchar2, v_cal_type in char, v_return out varchar2);
  -- 基于已报简单算术平均法
  procedure P_Fin_RI_Report_Ldf_SA(today1 varchar2, v_cal_type in char, v_return out varchar2);

  -- 基于已决最近两个事故年的原始加权平均法
  procedure P_Fin_RI_Amt_Ldf_TOWYEAR(today1 varchar2, v_cal_type in char, v_return out varchar2);
  -- 基于已报最近两个事故年的原始加权平均法
  procedure P_Fin_RI_Report_Ldf_TOWYEAR(today1 varchar2, v_cal_type in char, v_return out varchar2);

  --基于已决累计进展因子
  procedure P_Fin_RI_Amt_Ldf_EMP(v_today varchar2, v_cal_type in char, v_return out varchar2);
  --基于已报累计进展因子
  procedure P_Fin_RI_Report_Ldf_EMP(v_today varchar2, v_cal_type in char, v_return out varchar2);

end P_FIN_RI_LDF_EMP;
/
