CREATE PACKAGE BODY "repeatcheck" is




 procedure liability_insurance_repeat(
                                                       CAppType IN VARCHAR2,
                                                       CProdNo IN VARCHAR2,
                                                       CAppNo  IN VARCHAR2,
                                                       CPlyNo IN VARCHAR2,
                                                       NEdrPrjNo IN NUMBER,
                                                       CResult OUT VARCHAR2) is
  vCertNoOld    VARCHAR2(30);
  vCertNoNew    VARCHAR2(30);
  vCPlyNo       VARCHAR2(30);
  vNSeqNo       number;
  vPlyTgtObject web_ply_tgt_obj%rowtype;
  vAppTgtObject web_App_tgt_obj%rowtype;
  vEdrPlyNo     VARCHAR2(30);
  vNEdrPrjNo    number;
  --新增投保清单
  Cursor liability_insurance_new is
    select n_seq_no,decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2) as CCertNo from web_app_tgt_obj a where c_app_no = CAppNo;
  --批改的清单
  Cursor liability_insurance_update is
    select newApp.n_seq_no,decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2) as CCertNo
      from web_app_tgt_obj newApp
     where newApp.c_app_no = CAppNo
       and newApp.c_cancel_mark = '0'
    minus
    select n_seq_no, decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2) as CCertNo
      from web_ply_tgt_obj
     where c_ply_no = vEdrPlyNo
       and n_edr_prj_no = vNEdrPrjNo
       and c_cancel_mark = '0';
    --重复记录
     cursor repeatList is
          
            select c_ply_no as CPlyNo,
                   decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2) as CCertNo
              from web_ply_tgt_obj
             where c_app_no in (select c_app_no
                                  from web_ply_base
                                 where c_prod_no = CProdNo
                                   and t_insrnc_end_tm < sysdate
                                   and c_latest_mrk = '1'
                                   and C_PLY_STS = 'I')
               and c_Tgt_Obj_Txt_Fld_2 = vCertNoNew;

begin
  if CAppType='A' then 
  --循环获取新增清单证件号码
      open liability_insurance_new;
      loop
        fetch liability_insurance_new
          into vNSeqNo,vCertNoNew;
        exit when liability_insurance_new%notfound;
        open repeatList;
        loop
          fetch repeatList
            into vCPlyNo, vCertNoOld;
          exit when repeatList%notfound;
          CResult := CResult || '重复投保,序号 ' || vAppTgtObject.n_Seq_No ||
                     ',证件号码 ' || vCertNoNew || ',保单号' || vCPlyNo;
          dbms_output.put_line(CResult);
        
        end loop;
        close repeatList;
      end loop;
      close liability_insurance_new;
  else 
      vNEdrPrjNo:=NEdrPrjNo-1;
      vEdrPlyNo :=CPlyNo;
      open liability_insurance_update;
      loop
        fetch liability_insurance_update
          into vNSeqNo,vCertNoNew;
        exit when liability_insurance_update%notfound;
        open repeatList;
        loop
          fetch repeatList
            into vCPlyNo, vCertNoOld;
          exit when repeatList%notfound;
          CResult := CResult || '重复投保,序号 ' || vAppTgtObject.n_Seq_No ||
                     ',证件号码 ' || vCertNoNew || ',保单号' || vCPlyNo;
          dbms_output.put_line(CResult);
        
        end loop;
        close repeatList;
      end loop;
      close liability_insurance_update;
  end if;
  
end liability_insurance_repeat;
end repeatcheck;
/
