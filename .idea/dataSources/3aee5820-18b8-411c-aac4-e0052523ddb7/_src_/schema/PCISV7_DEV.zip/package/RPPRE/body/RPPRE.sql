CREATE package body rpPre is

--冲上期数据
procedure finMadcrBackPre(v_date in date,succflag out varchar2) is
  v_err_content    web_bas_fin_errorlog.c_err_content%type;
  begin
     succflag:='0';
     insert into web_fin_madcr_pre
          (c_company_cde,t_crt_tm,c_insrnc_cde,c_vou_memo,c_sbjt_memo,c_cav_flag,
           c_sbjt_no,c_prod_no,c_dptacc_no,c_cur_no,c_bsns_typ,n_amt,c_dpt_cde,
           c_servicetype_no,c_department_cde,n_exch_amt,n_rate,c_prm_sou,t_end_tm,
           c_pre_flag,c_is_back)
    select c_company_cde,v_date,c_insrnc_cde,'冲回-'||c_vou_memo,c_sbjt_memo,c_cav_flag,
           c_sbjt_no,c_prod_no,c_dptacc_no,c_cur_no,c_bsns_typ,-n_amt,c_dpt_cde,
           c_servicetype_no,c_department_cde,-n_exch_amt,n_rate,c_prm_sou,sysdate,
           '0','1'
     from web_fin_madcr_pre a
     where /*c_servicetype_no in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154','1155')*/
           c_servicetype_no in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154',DECODE(TO_CHAR(v_date,'MM'),'01','1154','1155')) --20140213 巨灾风险不冲回上年的数据即提取1月的准备金时，不冲回巨灾
           and t_crt_tm=add_months(trunc(v_date),-1)--trunc((ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and a.c_is_back = '0';
     commit;
  exception
  when others then
    begin
      rollback;
      v_err_content := 'proc:[finMadcrBackPre],出错流水号:'||'],错误描述:['|| SQLCODE ||SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      values
        (F_Fin_Getcode('e'),'001','0000',v_err_content,SYSDATE);
      commit;
      succflag := '-1';
    end;
  end finMadcrBackPre;

--对本期数据汇总,写到 web_fin_madcr_pre表
procedure finmidPre(v_date in date,succflag out varchar2) is
  v_err_content    web_bas_fin_errorlog.c_err_content%type;
begin
    succflag:='0';
    insert into web_fin_madcr_pre
          (c_company_cde,t_crt_tm,c_insrnc_cde,c_vou_memo,c_sbjt_memo,c_cav_flag,
           c_sbjt_no,c_prod_no,c_dptacc_no,c_cur_no,c_bsns_typ,n_amt,c_dpt_cde,
           c_servicetype_no,c_department_cde,n_exch_amt,n_rate,c_prm_sou,t_end_tm,
           c_pre_flag,c_is_back)
    select c_company_cde,t_crt_tm,c_insrnc_cde,c_vou_memo,c_sbjt_memo,c_cav_flag,
           c_sbjt_no,c_prod_no,c_dptacc_no,c_cur_no,c_bsns_typ,sum(n_amt),c_dpt_cde,
           c_servicetype_no,c_department_cde,sum(n_exch_amt),n_rate,c_prm_sou,sysdate,
           '0','0'
     from web_fin_madcr_mid_pre a
     where c_servicetype_no in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154','1155')
           and t_crt_tm = v_date
           and a.c_is_back = '0'
           and nvl(c_is_gather,'0') = '0'
     group by
          c_company_cde,t_crt_tm,c_insrnc_cde,c_vou_memo,c_sbjt_memo,c_cav_flag,
          c_sbjt_no,c_prod_no,c_dptacc_no,c_cur_no,c_bsns_typ,c_dpt_cde,
          c_servicetype_no,c_department_cde,n_rate,c_prm_sou;
     update web_fin_madcr_mid_pre a
     set c_is_gather = '1'
     where c_servicetype_no in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154','1155')
           and t_crt_tm = v_date
           and a.c_is_back = '0'
           and nvl(c_is_gather,'0') = '0';
     commit;
  exception
  when others then
    begin
      rollback;
      v_err_content := 'proc:[finmidPre],出错流水号:'||'],错误描述:['|| SQLCODE ||SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      values
        (F_Fin_Getcode('e'),'001','0000',v_err_content,SYSDATE);
      commit;
      succflag := '-1';
    end;
end finmidPre;
--准备金汇总
procedure finintfpre(v_date in date,succflag out varchar2) is
  v_ITEM_NO        web_fin_madcr.c_item_no%type; --序号
  v_CAV_FLAG       web_fin_madcr.c_cav_flag%type; --借贷方向()
  v_SBJT_NO        web_fin_madcr.c_sbjt_no%type; --科目编码
  v_N_AMT          web_fin_madcr.n_amt%type; --金额
  v_DPTACC_NO      web_fin_madcr.c_dptacc_no%type; --做账机构
  v_DPT_CDE        web_fin_madcr.c_dpt_cde%type; --出单机构
  v_PROD_NO        web_fin_madcr.c_prod_no%type; --产品代码
  v_RI_COM         web_fin_madcr.c_ri_com%type; --再保人
  v_VOU_MEMO       web_fin_madcr.c_vou_memo%type; --凭证摘要
  v_CONT_CODE      web_fin_madcr.c_cont_code%type; --合约代码
  v_BSNS_TYP       web_fin_madcr.c_bsns_typ%type; --业务来源
  v_SALEGRP_CDE    web_fin_madcr.c_salegrp_cde%type; --销售团队
  v_COMPANY_CDE    web_fin_madcr.c_company_cde%type; --财务公司
  v_CON_DPT_CDE    web_fin_madcr.c_con_dpt_cde%type; --共保人
  v_RCPT_NO        web_fin_madcr.c_rcpt_no%type; --收据号
  v_CHECK_FLAG     web_fin_madcr.c_check_flag%type; --复核标识
  v_PERIOD_NAME    web_fin_madcr.c_period_name%type; --会计期间
  v_SERVICETYPE_NO web_fin_madcr.c_servicetype_no%type; --业务类型
  v_DEPARTMENT_CDE web_fin_madcr.c_department_cde%type; --部门
  v_VERIFYVOU_MEMO web_fin_madcr.c_verifyvou_memo%type; --校验编码
  v_SBJT_MEMO      web_fin_madcr.c_sbjt_memo%type; --科目备注
  vTmpVouNo        web_fin_madcr.c_seq_no%type;
  v_pre_flag       web_fin_madcr.c_pre_flag%type;--准备金标识
  v_err_content    WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
  v_COMPANYCDE     web_org_dpt.c_company_cde%type;
  v_SERVICETYPE    web_fin_madcr.c_servicetype_no%type;
  v_vou_date       web_fin_madcr_intf.t_vou_date%type;
  v_cur_no         web_fin_madcr_intf.c_cur_no%type;
  v_rate           web_fin_madcr_intf.n_rate%type;
  v_exch_amt       web_fin_madcr.n_amt%type; --金额
cursor cur is
  select a.c_dptacc_no,c_company_cde,a.c_dpt_cde,a.c_department_cde,a.c_sbjt_no,
         a.c_bsns_typ,a.c_sbjt_memo,a.c_prod_no,a.n_amt,a.c_cur_no,a.n_exch_amt,
         a.n_rate,a.c_servicetype_no,a.c_cav_flag,a.c_pre_flag,trunc(a.t_crt_tm) as t_crt_tm,
         a.c_seq_no,a.c_item_no
 from  web_fin_madcr_pre a
 where a.c_voucher_no is null and a.c_cur_no <> '01'
       and c_servicetype_no in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154','1155')
       and t_crt_tm = v_date;

cursor company is
  select distinct c_company_cde,c_cur_no
    from web_fin_madcr_pre a
    where a.c_voucher_no is null
       and t_crt_tm = v_date;

cursor servicetype is
    select distinct c_no as c_Servicetype_No from web_bas_fin_servicetype a
    where a.c_no  in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154','1155');
cursor gather_pre is
    select c_dptacc_no, c_dpt_cde, c_sbjt_no, c_bsns_typ, c_sbjt_memo, c_prod_no, sum(n_amt), c_servicetype_no,
           c_cav_flag, c_pre_flag, trunc(t_crt_tm), c_company_cde, c_department_cde, n_rate, sum(A.N_EXCH_AMT)
      from web_fin_madcr_pre a
     where t_crt_tm = v_date
       and c_company_cde = v_COMPANYCDE
       and c_servicetype_no = v_SERVICETYPE
       and c_voucher_no is null
       and c_cur_no = v_cur_no
  group by c_dptacc_no, c_dpt_cde, c_sbjt_no, c_bsns_typ, c_sbjt_memo, c_prod_no, c_servicetype_no,
           c_cav_flag, c_pre_flag, trunc(t_crt_tm), c_company_cde, c_department_cde, n_rate;
begin
  succflag := '0';

  for v_company in company loop
    begin
      v_COMPANYCDE:=v_company.c_company_cde;
      v_cur_no:=v_company.c_cur_no;
    for v_SERVICETYPENO in  servicetype loop
      begin
         v_SERVICETYPE:= v_SERVICETYPENO.c_Servicetype_No;
         Dz_Proc.get_fin_no(vTmpVouNo, '0099', '7', dz_proc.g_pttype);
  open gather_pre;
  v_item_no := 1;
  --Dz_Proc.get_fin_no(vTmpVouNo, '0101000', '7', dz_proc.g_pttype);
  v_PERIOD_NAME := to_char(trunc(sysdate), 'yyyy-mm');
  loop
    fetch gather_pre
      into  v_DPTACC_NO ,v_DPT_CDE ,v_SBJT_NO,v_BSNS_TYP,v_SBJT_MEMO,v_PROD_NO,v_n_amt,
            v_SERVICETYPE_NO,v_CAV_FLAG,v_pre_flag,v_vou_date,v_COMPANY_CDE,v_department_cde,v_rate,v_exch_amt;
    exit when gather_pre%notfound;

    select c_name into v_vou_memo from web_bas_fin_servicetype where c_no = v_SERVICETYPE_NO;

    v_vou_memo := to_char(trunc(v_vou_date), 'yyyy-mm-dd') || ' ' ||v_vou_memo;

    insert into web_fin_madcr_intf_pre
      (C_SEQ_NO,C_ITEM_NO, C_CAV_FLAG, C_SBJT_NO, N_AMT,C_CUR_NO,  T_CRT_TM, C_DPTACC_NO,
       C_DPT_CDE, C_PROD_NO,C_RI_COM,  C_VOU_NO,C_VOU_MEMO, C_SEND_FLAG,   C_CONT_CODE,
       C_BSNS_TYP, C_SALEGRP_CDE, C_COMPANY_CDE, T_VOU_DATE, C_CON_DPT_CDE, C_RCPT_NO,
       C_CHECK_FLAG, C_SEND_MEMO, C_PERIOD_NAME, C_SERVICETYPE_NO,    REQUEST_ID,
       C_DEPARTMENT_CDE,C_VERIFYVOU_MEMO,C_SBJT_MEMO,n_rate,n_exch_amt)
    values
      (vTmpVouNo, v_ITEM_NO,v_CAV_FLAG,v_SBJT_NO,v_N_AMT, decode(v_cur_no,'01','CNY',rpfunction.getFinCur(v_cur_no)),   sysdate, v_DPTACC_NO,
       v_DPT_CDE, v_PROD_NO,  v_RI_COM,  null,  v_VOU_MEMO,   '0',    v_CONT_CODE,
       v_BSNS_TYP, v_SALEGRP_CDE,  v_COMPANY_CDE, v_vou_date /*sysdate*/,  v_CON_DPT_CDE,  v_RCPT_NO,
       v_CHECK_FLAG,  null,  to_char(v_vou_date,'yyyy-mm'),  /*v_PERIOD_NAME,*/   v_SERVICETYPE_NO,    null,
       v_DEPARTMENT_CDE,v_VERIFYVOU_MEMO,v_SBJT_MEMO,v_rate,v_exch_amt);
     --由于数据量过大,效率过低,不使用此种方式回写
     /*update web_fin_madcr_pre a
       set a.c_voucher_no = vTmpVouNo||'_'||v_item_no
     where --c_servicetype_no in ('1011', '1012', '1013', '1014')
           \*trunc(t_crt_tm) < trunc(sysdate)
       and trunc(t_crt_tm) > trunc(sysdate)-31*\
       trunc(t_crt_tm)>=trunc((ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
       and trunc(t_crt_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
       and c_dptacc_no = v_DPTACC_NO
       and c_dpt_cde = v_DPT_CDE
       and c_sbjt_no = v_SBJT_NO
       and c_bsns_typ = v_BSNS_TYP
       and c_sbjt_memo = v_SBJT_MEMO
       and c_prod_no = v_PROD_NO
       and c_servicetype_no = v_SERVICETYPE_NO
       and c_cav_flag = v_CAV_FLAG
       and c_pre_flag = v_pre_flag
       and c_department_cde = v_department_cde
       and trunc(t_crt_tm) = trunc(v_vou_date)
       --and t_end_tm >= to_date('2012-01-04 11:17','yyyy-mm-dd hh24:mi')
       and c_cur_no = v_cur_no
       and n_rate = v_rate
       and c_company_cde = v_COMPANY_CDE
       and c_voucher_no is null;*/
       --and c_vou_memo like '%冲回%';
       v_ITEM_NO := v_item_no + 1;
      end loop;
      close gather_pre;
      update web_fin_madcr_pre a
       set a.c_voucher_no = vTmpVouNo
     where t_crt_tm = v_date
       and c_servicetype_no = v_SERVICETYPE
       and c_cur_no = v_cur_no
       and c_company_cde = v_COMPANYCDE
       and c_voucher_no is null;
       commit;
    end;
    end loop;
     commit;
  end;
  end loop;

  --外币 begin
  /*for v_cur in cur loop
      begin
      v_vou_memo := to_char(v_cur.t_crt_tm, 'yyyy-mm-dd') || ' ' ||
                   rpfunction.getServicetype(v_cur.c_servicetype_no);
       insert into web_fin_madcr_intf_pre
      (C_SEQ_NO,C_ITEM_NO, C_CAV_FLAG, C_SBJT_NO, N_AMT,
       C_CUR_NO,  T_CRT_TM, C_DPTACC_NO,
       C_DPT_CDE, C_PROD_NO,C_VOU_MEMO, C_SEND_FLAG,
       C_BSNS_TYP, C_COMPANY_CDE, T_VOU_DATE,
       C_PERIOD_NAME, C_SERVICETYPE_NO,
       C_DEPARTMENT_CDE, C_SBJT_MEMO,n_rate,n_exch_amt)
    values
      (v_cur.c_seq_no||'1', v_cur.c_item_no,v_cur.c_cav_flag,v_cur.c_sbjt_no,v_cur.n_amt,
       rpfunction.getFinCur(v_cur.c_cur_no),   sysdate,v_cur.c_dptacc_no,
       v_cur.c_dpt_cde,v_cur.c_prod_no, v_vou_memo ,'0',
       v_cur.c_bsns_typ,v_cur.c_company_cde,v_cur.t_crt_tm,
       to_char(v_cur.t_crt_tm,'yyyy-mm'), v_cur.c_servicetype_no,
       v_cur.c_department_cde,v_cur.c_sbjt_memo,v_cur.n_rate,v_cur.n_exch_amt);
      end;
    update web_fin_madcr_pre a set a.c_voucher_no = v_cur.c_seq_no||'1'||'_'||v_cur.c_item_no
    where a.c_seq_no = v_cur.c_seq_no and a.c_item_no = v_cur.c_item_no;
  end loop;
  --外币 end
  commit;*/

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      dbms_output.put_line('exception' || ' * ' || v_rcpt_no || ' ' ||SQLERRM);
      ROLLBACK;
      v_err_content := 'proc:[finintfpre],出错流水号:'||'],错误描述:['|| SQLCODE ||
                       SQLERRM;
      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'),'001','0000',v_err_content,SYSDATE);
      COMMIT;
      succflag := '-1';
    END;
end finintfpre;

--传财务接口表
procedure finPreToFin(v_date in date,succflag out varchar2) is
  v_err_content    web_bas_fin_errorlog.c_err_content%type;
  begin
     succflag:='0';
     insert into web_fin_madcr_intf
     select *
      from web_fin_madcr_intf_pre a
     where c_servicetype_no in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154','1155')
       and a.t_vou_date = v_date
       and c_send_flag = '0'
       ;
     commit;
     --更新数据
     update web_fin_madcr_intf_pre a
        set a.c_send_flag = '1'
      where c_servicetype_no in('1133','1127','1131','1129','1431','1135','1148','1152','1429','1154','1155')
       and t_vou_date = v_date
       and c_send_flag = '0'
       ;
     commit;
  exception
  when others then
    begin
      rollback;
      v_err_content := 'proc:[finPreToFin],出错流水号:'||'],错误描述:['|| SQLCODE ||SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      values
        (F_Fin_Getcode('e'),'001','0000',v_err_content,SYSDATE);
      commit;
      succflag := '-1';
    end;
  end finPreToFin;

end rpPre;
/
