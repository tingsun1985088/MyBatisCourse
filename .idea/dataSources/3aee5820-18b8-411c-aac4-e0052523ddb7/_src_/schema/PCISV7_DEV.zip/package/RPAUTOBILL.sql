CREATE PACKAGE "RPAUTOBILL" is

       procedure premdue(succflag out varchar2);     --保费
       procedure p_premdueaccisc(succflag out varchar2); --商车保费
       procedure p_premdueaccins(succflag out varchar2); -- 保费(意健拆分)
       procedure premcontdue(succflag out varchar2);  -- 共保保费
       procedure p_prmcontdue_accins(succflag out varchar2);--共保保费(意外险)
       procedure P_paydue(succflag out varchar2); -- 手续费
       procedure p_premdue_ccs(succflag out varchar2);--车船税
       PROCEDURE P_FIN_GATHERMADCR(succflag out varchar2); -- 汇总
   -- procedure P_CLMDUE_INPUT(succflag out varchar2); --处理当天赔款未挂账数据
end rpAutoBill;



/
