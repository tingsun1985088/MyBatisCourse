CREATE PACKAGE BODY "QUEST_PPCM_DATA_INSERTER" AS

	TYPE typ_sql_snap IS TABLE OF quest_ppcm_sql_snapshot%ROWTYPE INDEX BY BINARY_INTEGER;

	arr_sql_snap 		typ_sql_snap;
	lv_idx 				PLS_INTEGER := 1;
	lc_batch_count 		PLS_INTEGER := 500;

	PROCEDURE add_sql_snap(p_instance_id 					NUMBER,
						   p_snapshot_id 					NUMBER,
						   p_sql_id 						VARCHAR2,
						   p_executions 					FLOAT,
						   p_buffer_gets 					FLOAT,
						   p_elapsed_time 					FLOAT,
						   p_disk_reads 					FLOAT,
						   p_cpu_time 						FLOAT,
						   p_user_io_wait_time 				FLOAT,
						   p_concurrency_wait_time 			FLOAT,
						   p_cluster_wait_time 				FLOAT,
						   p_application_wait_time 			FLOAT,
						   p_executions_rate 				FLOAT,
						   p_buffer_gets_rate 				FLOAT,
						   p_elapsed_time_rate 				FLOAT,
						   p_disk_reads_rate 				FLOAT,
						   p_cpu_time_rate 					FLOAT,
						   p_user_io_wait_time_rate 		FLOAT,
						   p_concurrency_wait_time_rate 	FLOAT,
						   p_cluster_wait_time_rate 		FLOAT,
						   p_application_wait_time_rate 	FLOAT,
						   p_avg_plan_hash_value 			NUMBER)
	IS
	BEGIN

		arr_sql_snap(lv_idx).instance_id 				:= 	p_instance_id 					;
		arr_sql_snap(lv_idx).snapshot_id 				:=	p_snapshot_id 				;
		arr_sql_snap(lv_idx).sql_id 					:=	p_sql_id 					;
		arr_sql_snap(lv_idx).executions 				:=	p_executions 				;
		arr_sql_snap(lv_idx).buffer_gets 				:=	p_buffer_gets 				;
		arr_sql_snap(lv_idx).elapsed_time 				:=	p_elapsed_time 				;
		arr_sql_snap(lv_idx).disk_reads 				:=	p_disk_reads 				;
		arr_sql_snap(lv_idx).cpu_time 					:=	p_cpu_time 					;
		arr_sql_snap(lv_idx).user_io_wait_time 			:=	p_user_io_wait_time 		;
		arr_sql_snap(lv_idx).concurrency_wait_time 		:=	p_concurrency_wait_time 	;
		arr_sql_snap(lv_idx).cluster_wait_time 			:=	p_cluster_wait_time 		;
		arr_sql_snap(lv_idx).application_wait_time 		:=	p_application_wait_time 	;
		arr_sql_snap(lv_idx).executions_rate 			:=	p_executions_rate 			;
		arr_sql_snap(lv_idx).buffer_gets_rate 			:=	p_buffer_gets_rate 			;
		arr_sql_snap(lv_idx).elapsed_time_rate 			:=	p_elapsed_time_rate 		;
		arr_sql_snap(lv_idx).disk_reads_rate 			:=	p_disk_reads_rate 			;
		arr_sql_snap(lv_idx).cpu_time_rate 				:=	p_cpu_time_rate 			;
		arr_sql_snap(lv_idx).user_io_wait_time_rate 	:=	p_user_io_wait_time_rate 	;
		arr_sql_snap(lv_idx).concurrency_wait_time_rate :=	p_concurrency_wait_time_rate;
		arr_sql_snap(lv_idx).cluster_wait_time_rate 	:=	p_cluster_wait_time_rate 	;
		arr_sql_snap(lv_idx).application_wait_time_rate :=	p_application_wait_time_rate;
		arr_sql_snap(lv_idx).avg_plan_hash_value 		:=	p_avg_plan_hash_value 		;

		lv_idx := lv_idx + 1;

		IF lv_idx > lc_batch_count THEN
			save_snap;
		END IF;

	END add_sql_snap;

	PROCEDURE save_snap IS
	BEGIN

		FORALL idx IN 1..arr_sql_snap.COUNT
			INSERT INTO quest_ppcm_sql_snapshot
			VALUES arr_sql_snap(idx);

		arr_sql_snap.DELETE;

		lv_idx := 1;

		COMMIT;
	END save_snap;

END quest_ppcm_data_inserter;
/
