CREATE PACKAGE BODY EL_LOSSINFO_INTO IS

  /*读取超赔合约中险位合约的有效起止期、适用机构、产品信息，
  用于检索符号条件的险位损失*/
  CURSOR ELCONTDPTPROD IS
    SELECT M.C_CONT_ID,
           MIN(M.T_CONT_BGN_TM) T_CONT_BGN_TM,
           MAX(M.T_CONT_END_TM) + 1 T_CONT_END_TM,
           D.C_DPT_CDE,
           C.C_PROD_NO
      FROM WEB_RI_CONT_EL_MECHANISMDPT D,
           WEB_RI_CONT_EL_MAIN         M,
           WEB_RI_CONT_EL_CLASS        C,
           WEB_RI_CONT_EL_LAYER        L
     WHERE M.C_CONT_ID = D.C_CONT_ID
       AND M.C_CONT_ID = C.C_CONT_ID
       AND M.C_CONT_ID = L.C_CONT_ID
       AND L.N_LAYER = C.N_LAYER
       AND M.C_CONT_STATUS = 'E' --有效合约状态
       AND L.C_LAYER_TYP IN ('0', '2') --险位损失
       AND M.C_EL_TYPE IN ('R', 'H')
       AND C.C_STATUS = '2' --险种有效状态
     GROUP BY M.C_CONT_ID, D.C_DPT_CDE, C.C_PROD_NO;

  /*二级巨灾代码游标*/
  CURSOR CATAINFO IS
    SELECT T.C_CATA_CDE, T.C_CATA_CNM
      FROM WEB_RI_EL_CATA T
     WHERE T.C_STATUS IN ('1', '2')
       AND T.N_LEVEL = '2'
       AND (CASE
             WHEN (T.T_EL_ACCOUNT_END_TM IS NULL) THEN
              SYSDATE
             ELSE
              T.T_EL_ACCOUNT_END_TM
           END) >= SYSDATE;
  /
