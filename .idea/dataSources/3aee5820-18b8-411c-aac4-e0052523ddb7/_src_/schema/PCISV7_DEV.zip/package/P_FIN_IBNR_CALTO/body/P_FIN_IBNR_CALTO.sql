CREATE package body P_FIN_IBNR_CALTO is

  v_Sqlcode               Number;
  v_Sqlerrm               Varchar2(600);
  v_dpt_cde               VARCHAR2(20);
  v_max_tm                VARCHAR2(20);
  V_PROD_NO               VARCHAR2(20);
  v_ply_no                VARCHAR2(30);
  I                       INT;
  num                     int;
  v_kind_no               varchar2(10);
  v_clm_rate              Number(20,6);
  v_lase_tm               date;
  V_IBNR_BFFD             Number(20,2);--BF法-法定
  V_IBNR_PAYFD            Number(20,2);--赔付率法-法定
  V_IBNR_AMTFD            Number(20,2); -- IBNR 法定值
  v_fee_rate_dir          Number(20,6);  --ibnr直接理赔费用比例
  v_fee_rate_indir        Number(20,6);  --间接理赔费用与已决赔款的经验比率
  V_IBNR_FEE_DIRFD        Number(20,2);
  V_IBNR_FEE_INDIRFD      Number(20,2);
  V_IBNR_BFKJ             Number(20,2);--BF法-会计
  V_IBNR_PAYKJ            Number(20,2);--赔付率法-会计
  V_IBNR_AMTKJ            Number(20,2); -- IBNR 会计值
  V_IBNR_FEE_DIRKJ        Number(20,2); --ibnr直接理赔费用准备金 -会计
  V_IBNR_BAC_FEE_DIRKJ    Number(20,2); --ibnr直接理赔费用准备金 -会计
  V_IBNR_FEE_INDIRKJ      Number(20,2); --IBNR间接理赔费用准备金-会计
  V_IBNR_BAC_FEE_INDIRKJ  Number(20,2);
  v_pend_SUM              Number(20,2);--已报告未决赔款+理赔费用
  V_PEND_FEE              Number(20,2); --理赔费用
  v_ibnr_risk             Number(20,6);--风险边际 014005
  v_ibnr_discount         Number(20,6);--贴现率 014004
  v_ibnr_Duration         Number(20,6);--久期  014003
  V_IBNR_SUMKJ            Number(20,2); --IBNR会计值+ 已报告未决赔款+理赔费用
  V_IBNR_SUM_AMT          Number(20,2); --会计IBNR:(含有直接理赔费用)
  V_IBNR_BAC_SUM_AMT      Number(20,2);
  V_IBNR_ACT_AMT          Number(20,2); --会计IBNR:(传财务值)
  V_IBNR_BAC_ACT_AMT      Number(20,2);
  V_PEND_FEE_INDIRKJ      Number(20,2); --会计已报告间接理赔费用
  V_PEND_BAC_FEE_INDIRKJ  Number(20,2); --会计已报告间接理赔费用
  v_err_content           varchar2(400);--日志错误信息
  t_today_tm              date;
  v_year                  varchar2(4);
  v_quart                 varchar2(5);
  v_pay_Weight            number(16,6);                    --赔付率法权重
  v_bf_clm_Weight         number(16,6);                    --bf法已决权重
  v_bf_report_Weight      number(16,6);                  --bf法已报权重
  v_lt_clm_Weight         number(16,6);                  --链锑法已决权重
  v_lt_report_Weight      number(16,6);                  --链锑法已报权重
  v_bf_weight             number(16,6);                  --BF权重
  v_lt_weight             number(16,6);                  --链锑法权重
  v_lt_clm_ibnr           Number(20,2);
  v_lt_report_ibnr        Number(20,2);
  v_bf_clm_ibnr           Number(20,2);
  v_bf_report_ibnr        Number(20,2);
  v_pay_ibnr              Number(20,2);
  v_pay_dirfee                 Number(20,2);
  v_pay_indirfee               Number(20,2);
  v_lt_clm_dirfee              Number(20,2);
  v_lt_clm_indirfee            Number(20,2);
  v_lt_clm_pend_indirfee       Number(20,2);
  v_lt_report_dirfee           Number(20,2);
  v_lt_report_indirfee         Number(20,2);
  v_lt_report_pend_indirfee    Number(20,2);
  v_bf_clm_dirfee              Number(20,2);
  v_bf_clm_indirfee            Number(20,2);
  v_bf_report_pend_indirfee    Number(20,2);
  v_bf_report_dirfee           Number(20,2);
  v_bf_report_indirfee         Number(20,2);
  v_bf_clm_pend_indirfee       Number(20,2);
  v_pay_pend_indirfee          Number(20,2);

 Procedure P_FIN_IBNR_CALTO(v_today in  varchar2,v_return  OUT NUMBER)
 Is
  cursor cur_base_10 is
    SELECT DISTINCT C_KIND_NO,C_PROD_NO,c_year,c_quart
    FROM (
      select C_KIND_NO, C_PROD_NO,c_year,c_quart
      from WEB_FIN_MID_IBNR_BF a
      WHERE A.T_CAL_TM = trunc(t_today_tm)
      UNION ALL
      select C_KIND_NO, C_PROD_NO,c_year,c_quart
      from web_fin_mid_ibnr_pay a
      WHERE trunc(A.t_cal_tm) =trunc(t_today_tm)
      UNION ALL
      select C_KIND_NO, C_PROD_NO,c_year,c_quart
      from web_fin_mid_ibnr_lt a
      WHERE trunc(A.t_cal_tm) =trunc(t_today_tm)
    );

 begin

   --将p_fin_ibnr_calnew 中相关计算各个险类ibnr程序单独出来,去掉所有相关法定ibnr计算,只计算会计IBNR shexiwan 2012-10-31
   v_max_tm :=to_char(to_date(v_today,'yyyy-mm_dd'),'yyyy-mm');
   t_today_tm:= TO_DATE(v_today,'YYYY-MM-DD');
   v_lase_tm:=add_months(t_today_tm,-1);
   v_return := 0;
   num := 0;

   v_pay_Weight:=0;                       --赔付率法权重
   v_bf_clm_Weight:=0;                    --bf法已决权重
   v_bf_report_Weight:=0;                 --bf法已报权重
   v_lt_clm_Weight:=0;                    --链锑法已决权重
   v_lt_report_Weight:=0;                 --链锑法已报权重
   v_lt_clm_ibnr:=0;
   v_lt_report_ibnr:=0;
   v_bf_clm_ibnr:=0;
   v_bf_report_ibnr:=0;
   v_pay_ibnr:=0;

   /*計算ibnr*/
     num := 10; I:=1;
       delete from WEB_FIN_MID_IBNR where T_CRT_TM=trunc(t_today_tm);   commit;
       open cur_base_10;    --行循环
        loop
          fetch cur_base_10 into
               v_kind_no,V_PROD_NO,v_year,v_quart;
          EXIT WHEN cur_base_10%NOTFOUND;
     num:=11;

   /************************會計bgn**************************************/

     -- add by sehxwian 2012-09-13 begin ----------------------------------
     --再保前基于已决算法选取 1:原始加权平均法,2:简单算术平均法,3:最近两个事故原始加权平均法,4:手动录入进展因子
     /*select C_FLG into v_flg_lt_clm from web_fin_ibnr_pbl a
     where c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no) and c_prod_no = v_prod_no
      and C_RI_FLAG = '0' and C_TYPE = '1' and a.c_lt_bf = '1';*/
      --基于已报算法选取
      /*select C_FLG into v_flg_lt_report from web_fin_ibnr_pbl a
     where c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no) and c_prod_no = v_prod_no
      and C_RI_FLAG = '0' and C_TYPE = '2' and a.c_lt_bf = '1';*/

      /*select C_FLG into v_flg_bf_clm from web_fin_ibnr_pbl a
     where c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no) and c_prod_no = v_prod_no
      and C_RI_FLAG = '0' and C_TYPE = '1' and a.c_lt_bf = '2';*/
      --基于已报算法选取
      /*select C_FLG into v_flg_bf_report from web_fin_ibnr_pbl a
     where c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no) and c_prod_no = v_prod_no
      and C_RI_FLAG = '0' and C_TYPE = '2' and a.c_lt_bf = '2';*/

       --赔付法IBNR(IBNR含费用,IBNR直接理赔费用,ibnr间接理赔费用,已报间接理赔费用)
       begin
         select N_CAL_CLM_AMT,a.n_ibnr_dirfee,a.n_ibnr_indirfee,N_PEND_INDIRFEE
           into v_pay_ibnr,v_pay_dirfee,v_pay_indirfee,v_pay_pend_indirfee
           from web_fin_mid_ibnr_pay a
          where a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
           and  a.c_prod_no = v_prod_no   and a.c_year = v_year
           and  a.c_quart = v_quart;
       exception when no_data_found then
          v_pay_ibnr:=0;
          v_pay_dirfee:=0;
          v_pay_indirfee:=0;
          v_pay_pend_indirfee:=0;
       end;

       --已决链锑法IBNR
       begin
         SELECT a.n_ibnr,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
           into v_lt_clm_ibnr,v_lt_clm_dirfee,v_lt_clm_indirfee,v_lt_clm_pend_indirfee
           FROM WEB_FIN_MID_IBNR_LT A
          WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
            and a.c_prod_no = v_prod_no   and a.c_year = v_year
            and a.c_quart = v_quart       --and C_FLG = v_flg_lt_clm
            and C_TYPE = '1';
        exception when no_data_found then
           v_lt_clm_ibnr:=0;
           v_lt_clm_dirfee:=0;
           v_lt_clm_indirfee:=0;
           v_lt_clm_pend_indirfee:=0;
        end;
       --已决BF法IBNR
       begin
           SELECT a.n_ibnr_bf,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
             into v_bf_clm_ibnr,v_bf_clm_dirfee,v_bf_clm_indirfee,v_bf_clm_pend_indirfee
             FROM WEB_FIN_MID_IBNR_BF A
            WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
              and a.c_prod_no = v_prod_no   and a.c_year = v_year
              and a.c_quart = v_quart       --and C_FLG = v_flg_bf_clm
              and C_TYPE = '1';
       exception when no_data_found then
           v_bf_clm_ibnr:=0;
           v_bf_clm_dirfee:=0;
           v_bf_clm_indirfee:=0;
           v_bf_clm_pend_indirfee:=0;
       end;

       --已报链锑法IBNR
       begin
           SELECT a.n_ibnr,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
             into v_lt_report_ibnr,v_lt_report_dirfee,v_lt_report_indirfee,v_lt_report_pend_indirfee
             FROM WEB_FIN_MID_IBNR_LT A
            WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
              and a.c_prod_no = v_prod_no   and a.c_year = v_year
              and a.c_quart = v_quart       --and C_FLG = v_flg_lt_report
              and C_TYPE = '2';
       exception when no_data_found then
           v_lt_report_ibnr:=0;
           v_lt_report_dirfee:=0;
           v_lt_report_indirfee:=0;
           v_lt_report_pend_indirfee:=0;
       end;
       --已报BF法IBNR
       begin
           SELECT a.n_ibnr_bf,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
             into v_bf_report_ibnr,v_bf_report_dirfee,v_bf_report_indirfee,v_bf_report_pend_indirfee
             FROM WEB_FIN_MID_IBNR_BF A
            WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
              and a.c_prod_no = v_prod_no   and a.c_year = v_year
              and a.c_quart = v_quart       --and C_FLG = v_flg_bf_report
              and C_TYPE = '2';
       exception when no_data_found then
           v_bf_report_ibnr:=0;
           v_bf_report_dirfee:=0;
           v_bf_report_indirfee:=0;
           v_bf_report_pend_indirfee:=0;
       end;
     begin
       --赔付率法ibnr权重(不区分已决,已报)
       select a.n_rate into v_pay_Weight from web_fin_ibnr_rate a
        where a.c_kind_no = v_kind_no  and a.c_prod_no = v_prod_no
          and a.c_cde = '017001';
     exception when no_data_found then
           v_pay_Weight:=0;
     end;
     --链锑法总的权重
     begin
       select a.n_rate into v_lt_Weight from web_fin_ibnr_rate a
        where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
          and a.c_cde = '017002';
     exception when no_data_found then
           v_lt_Weight:=0;
     end;
     --链锑法法ibnr权重(已决)
     begin
       select a.n_rate into v_lt_clm_Weight from web_fin_ibnr_rate a
        where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
          and a.c_cde = '017003';
     exception when no_data_found then
           v_lt_clm_Weight:=0;
     end;
     --链锑法法ibnr权重(已报)
     begin
       select a.n_rate into v_lt_report_Weight from web_fin_ibnr_rate a
        where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
          and a.c_cde = '017004';
     exception when no_data_found then
           v_lt_report_Weight:=0;
     end;
     --BF法总的权重
     begin
       select a.n_rate into v_bf_Weight from web_fin_ibnr_rate a
        where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
          and a.c_cde = '017005';
     exception when no_data_found then
           v_bf_Weight:=0;
     end;
     --BF法ibnr权重(已决)
     begin
     select a.n_rate into v_bf_clm_Weight from web_fin_ibnr_rate a
      where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
        and a.c_cde = '017006';
     exception when no_data_found then
           v_bf_clm_Weight:=0;
     end;
     --BF法ibnr权重(已报)
     begin
       select a.n_rate into v_bf_report_Weight from web_fin_ibnr_rate a
        where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
          and a.c_cde = '017007';
     exception when no_data_found then
           v_bf_report_Weight:=0;
     end;

   -- add by sehxwian 2012-09-13 end  -----------------------------------

/*--会计IBNR值分别赋予不同的权重确定初始未决赔款准备金*/

    --会计未决赔款准备进=初始未决赔款准备进*（1+风险边际）/（1+贴现率）^久期   POWER(（1+贴现率）,久期)  POWER(2,3) =8
    --V_IBNR_SUMKJ := (V_IBNR_AMTKJ+v_pend_SUM)*(1+v_ibnr_risk)/POWER((1+v_ibnr_discount),v_ibnr_Duration);

    --V_IBNR_SUM_AMT会计IBNR:(含有直接理赔费用)=会计未决赔款准备进-已报告未决赔款+理赔费用
    --V_IBNR_SUM_AMT:=V_IBNR_SUMKJ-v_pend_SUM;
    --modify by shenxiwan 2012-09-14 各个不同ibnr*权重
    v_pay_Weight:=0;
    v_lt_clm_Weight:=0;
    v_lt_weight:=1;
    v_lt_report_Weight:=1;
    v_bf_clm_Weight:=0;
    v_bf_weight:=0;
    v_bf_report_Weight:=0;
    V_IBNR_SUM_AMT:=v_pay_ibnr*v_pay_Weight +
                   v_lt_clm_ibnr*v_lt_clm_Weight*v_lt_weight + v_lt_report_ibnr*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_ibnr*v_bf_clm_Weight*v_bf_weight + v_bf_report_ibnr*v_bf_report_Weight*v_bf_weight;

 /************************會計end**************************************/
   /************************理赔费用bgn**************************************/

  --法定IBNR间接理赔费用准备金= IBNR准备金(比例值) * 间接理赔费用与已决赔款的经验比率  014008
      /**新算法 2012-07-30 shexiwan
      ALAE准备金＝未决赔款准备金×ALAE比例
      已报未决ALAE＝已报未决赔款×ALAE比例/(1－ALAE比例)
      IBNR的ALAE＝ALAE准备金－已报未决ALAE
      **/
     --ALAR(未决理赔费用)

   --会计ibnr直接理赔费用=会计未决赔款准备金*ibnr直接理赔费用比例-已发生已报告直接理赔费用；
     --V_IBNR_FEE_DIRKJ:= V_IBNR_SUMKJ*v_fee_rate_dir-V_PEND_FEE;
     --V_IBNR_FEE_DIRKJ:=V_IBNR_SUM_AMT*v_fee_rate_dir;/*新算法:(J3-E3-F3)*未决评估参数!G2 修改于20110620*/
     V_IBNR_FEE_DIRKJ:=v_pay_dirfee*v_pay_Weight +
                   v_lt_clm_dirfee*v_lt_clm_Weight*v_lt_weight + v_lt_report_dirfee*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_dirfee*v_bf_clm_Weight*v_bf_weight + v_bf_report_dirfee*v_bf_report_Weight*v_bf_weight;
   --会计ibnr间接理赔费用=会计IBNR准备金*间接理赔费用与已决赔款的经验比率；
     --V_IBNR_FEE_INDIRKJ:= V_IBNR_SUM_AMT*v_fee_rate_indir;
     V_IBNR_FEE_INDIRKJ:=v_pay_indirfee*v_pay_Weight +
                   v_lt_clm_indirfee*v_lt_clm_Weight*v_lt_weight + v_lt_report_indirfee*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_indirfee*v_bf_clm_Weight*v_bf_weight + v_bf_report_indirfee*v_bf_report_Weight*v_bf_weight;
    --会计已报告间接理赔费用:=(已报告未决赔款+理赔费用)*间接理赔费用与已决赔款的经验比率*0.5
     --V_PEND_FEE_INDIRKJ:= v_pend_SUM*v_fee_rate_indir*0.5;
     V_PEND_FEE_INDIRKJ:=v_pay_pend_indirfee*v_pay_Weight +
                   v_lt_clm_pend_indirfee*v_lt_clm_Weight*v_lt_weight + v_lt_report_pend_indirfee*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_pend_indirfee*v_bf_clm_Weight*v_bf_weight + v_bf_report_pend_indirfee*v_bf_report_Weight*v_bf_weight;

   /************************理赔费用end**************************************/

      --V_IBNR_ACT_AMT会计IBNR:(传财务值)=会计IBNR:(含有直接理赔费用)-会计ibnr直接理赔费用
    V_IBNR_ACT_AMT:=V_IBNR_SUM_AMT-V_IBNR_FEE_DIRKJ;

   -- 法定及会计 ibnr值 ibnr理赔费用 汇总的数据
          insert into WEB_FIN_MID_IBNR(T_Crt_TM ,T_UPD_TM ,t_cal_tm ,N_SEQ_NO ,C_DPT_CDE ,
                    C_INTER_CDE  ,C_PROD_NO ,c_kind_no ,C_INSRNC_CDE ,C_CLS_TM ,
                    N_IBNR_PAYFD ,N_IBNR_BFFD  ,N_IBNR_CAL_AMTFD ,
                    N_DIR_RATE ,N_IBNR_FEE_DIRFD ,N_INDIR_RATE ,N_IBNR_FEE_INDIRFD  ,
                    N_IBNR_RATEKJ ,N_IBNR_BFKJ  ,N_IBNR_PAYKJ ,N_IBNR_ACT_AMTKJ ,
                    N_IBNR_RISK,N_IBNR_DISCOUNT,N_IBNR_DURATION,
                    N_PEND_AMT,N_IBNR_SUMKJ,N_IBNR_FEE_DIRKJ ,N_IBNR_FEE_INDIRKJ,N_CLM_PEND_DIRFEE,
                    N_IBNR_SUM_AMT, N_IBNR_ACT_AMT ,N_PEND_FEE_INDIRKJ,c_Year,c_Quart)
           values(t_today_tm,sysdate,t_today_tm,I,v_dpt_cde
                 ,'9',V_PROD_NO,v_kind_no,''/*v_insrnc_cde*/,'',
                 nvl(V_IBNR_PAYFD,0),nvl(V_IBNR_BFFD,0),nvl(V_IBNR_AMTFD,0),
                 v_fee_rate_dir,nvl(V_IBNR_FEE_DIRFD,0)/*nvl(v_ibnr_fee_dir,0),*/,v_fee_rate_indir,NVL(V_IBNR_FEE_INDIRFD,0)/*NVL(v_ibnr_fee_indir,0)*/,
                 v_clm_rate,NVL(V_IBNR_BFKJ,0),NVL(V_IBNR_PAYKJ,0),NVL(V_IBNR_AMTKJ,0),
                 v_ibnr_risk,v_ibnr_discount,v_ibnr_Duration,
                 NVL(v_pend_SUM,0),NVL(V_IBNR_SUMKJ,0),NVL(V_IBNR_FEE_DIRKJ,0),NVL(V_IBNR_FEE_INDIRKJ,0),nvl(V_PEND_FEE,0),
                 nvl(V_IBNR_SUM_AMT,0),nvl(V_IBNR_ACT_AMT,0),NVL(V_PEND_FEE_INDIRKJ,0),v_year,v_quart);

         end loop;
       close cur_base_10;
    commit;
       --20140504执行成功向日志表中添加记录
      INSERT INTO WEB_BAS_FIN_ERRORLOG
       (C_ERR_NO, C_ERRTYPE_NO, C_TRAN_TYPE, C_ERR_CONTENT, T_CRT_TM)
      VALUES
       ('000', '001', '0000', '[P_FIN_IBNR_CALTO]--再保前IBNR汇总存过执行成功！', SYSDATE);
      COMMIT;

 Exception
  When Others Then
    Rollback;
    v_Sqlcode := Sqlcode;
    v_Sqlerrm := Substr(Sqlerrm, 1, 600);
  ROLLBACK;
      v_err_content:='proc:[P_FIN_IBNR_CALTO],出错流水号：['||v_today||V_Prod_NO||v_ply_no||'],错误描述：['||num||SQLCODE||SQLERRM;

      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
     v_return := -1;
 END;

 ---再保(采用再保前-再保分出计算)
 Procedure P_FIN_RI_IBNR_CALTO(v_today in  varchar2,v_return  OUT NUMBER)
 Is
  cursor cur_base_10 is /*根據權重因子得到ibnr值*/
    SELECT DISTINCT C_KIND_NO,C_PROD_NO,c_year,c_quart
    FROM (
      select C_KIND_NO, C_PROD_NO,c_year,c_quart
      from WEB_FIN_RI_MID_IBNR a
      WHERE A.T_CAL_TM = trunc(t_today_tm)
      UNION ALL
      select C_KIND_NO, C_PROD_NO,c_year,c_quart
      from WEB_FIN_MID_BAC_IBNR a
      WHERE trunc(A.t_cal_tm) =trunc(t_today_tm)
    );

 begin

   --将p_fin_ibnr_calnew 中相关计算各个险类ibnr程序单独出来,去掉所有相关法定ibnr计算,只计算会计IBNR shexiwan 2012-10-31
   v_max_tm :=to_char(to_date(v_today,'yyyy-mm_dd'),'yyyy-mm');
   t_today_tm:= TO_DATE(v_today,'YYYY-MM-DD');
   v_lase_tm:=add_months(t_today_tm,-1);
   v_return := 0;
   num := 0;

   v_pay_Weight:=0;                       --赔付率法权重
   v_bf_clm_Weight:=0;                    --bf法已决权重
   v_bf_report_Weight:=0;                 --bf法已报权重
   v_lt_clm_Weight:=0;                    --链锑法已决权重
   v_lt_report_Weight:=0;                 --链锑法已报权重
   v_lt_clm_ibnr:=0;
   v_lt_report_ibnr:=0;
   v_bf_clm_ibnr:=0;
   v_bf_report_ibnr:=0;
   v_pay_ibnr:=0;

   /*計算ibnr*/
     num := 10; I:=1;
       delete from WEB_FIN_RI_MID_IBNR where TRUNC(T_CAL_TM)=trunc(t_today_tm);   commit;
       open cur_base_10;    --行循环
        loop
          fetch cur_base_10 into
               v_kind_no,V_PROD_NO,v_year,v_quart;
          EXIT WHEN cur_base_10%NOTFOUND;
     num:=11;
    --ibnr含费用,ibnr,会计ibnr直接理赔费用,会计ibnr间接理赔费用,会计已报告间接理赔费用
    BEGIN
      SELECT A.N_IBNR_SUM_AMT,A.N_IBNR_ACT_AMT,A.N_IBNR_FEE_DIRKJ,N_IBNR_FEE_INDIRKJ,N_PEND_FEE_INDIRKJ
        INTO V_IBNR_SUM_AMT,V_IBNR_ACT_AMT,V_IBNR_FEE_DIRKJ,V_IBNR_FEE_INDIRKJ,V_PEND_FEE_INDIRKJ
        FROM WEB_FIN_MID_IBNR A
       WHERE TRUNC(A.T_CAL_TM) = trunc(t_today_tm)
         AND A.C_YEAR = V_YEAR AND A.C_QUART = V_QUART
         AND A.C_PROD_NO = V_PROD_NO AND A.C_KIND_NO = V_KIND_NO;
    exception when no_data_found then
         V_IBNR_SUM_AMT:=0;
         V_IBNR_ACT_AMT:=0;
         V_IBNR_FEE_DIRKJ:=0;
         V_IBNR_FEE_INDIRKJ:=0;
         V_PEND_FEE_INDIRKJ:=0;
    end ;

    BEGIN
      SELECT A.N_IBNR_SUM_AMT,A.N_IBNR_ACT_AMT,A.N_IBNR_FEE_DIRKJ,N_IBNR_FEE_INDIRKJ,A.N_PEND_FEE_INDIRKJ
        INTO V_IBNR_BAC_SUM_AMT,V_IBNR_BAC_ACT_AMT,V_IBNR_BAC_FEE_DIRKJ,V_IBNR_BAC_FEE_INDIRKJ,V_PEND_BAC_FEE_INDIRKJ
        FROM WEB_FIN_MID_BAC_IBNR A
       WHERE TRUNC(A.T_CAL_TM) = trunc(t_today_tm)
         AND A.C_YEAR = V_YEAR AND A.C_QUART = V_QUART
         AND A.C_PROD_NO = V_PROD_NO AND A.C_KIND_NO = V_KIND_NO;
    exception when no_data_found then
         V_IBNR_BAC_SUM_AMT:=0;
         V_IBNR_BAC_ACT_AMT:=0;
         V_IBNR_BAC_FEE_DIRKJ:=0;
         V_IBNR_BAC_FEE_INDIRKJ:=0;
         V_PEND_BAC_FEE_INDIRKJ:=0;
    end ;

    V_IBNR_SUM_AMT:=V_IBNR_SUM_AMT - V_IBNR_BAC_SUM_AMT;
    V_IBNR_FEE_DIRKJ:=V_IBNR_FEE_DIRKJ - V_IBNR_BAC_FEE_DIRKJ;
    V_IBNR_FEE_INDIRKJ:=V_IBNR_FEE_INDIRKJ - V_IBNR_BAC_FEE_INDIRKJ;
    V_IBNR_ACT_AMT:=V_IBNR_ACT_AMT - V_IBNR_BAC_ACT_AMT;
    V_PEND_FEE_INDIRKJ:=V_PEND_FEE_INDIRKJ - V_PEND_BAC_FEE_INDIRKJ;

   -- 法定及会计 ibnr值 ibnr理赔费用 汇总的数据
          insert into WEB_FIN_RI_MID_IBNR(T_Crt_TM ,T_UPD_TM ,t_cal_tm ,N_SEQ_NO ,C_DPT_CDE ,
                    C_INTER_CDE  ,C_PROD_NO ,c_kind_no ,C_INSRNC_CDE ,C_CLS_TM ,
                    N_IBNR_PAYFD ,N_IBNR_BFFD  ,N_IBNR_CAL_AMTFD ,
                    N_DIR_RATE ,N_IBNR_FEE_DIRFD ,N_INDIR_RATE ,N_IBNR_FEE_INDIRFD  ,
                    N_IBNR_RATEKJ ,N_IBNR_BFKJ  ,N_IBNR_PAYKJ ,N_IBNR_ACT_AMTKJ ,
                    N_IBNR_RISK,N_IBNR_DISCOUNT,N_IBNR_DURATION,
                    N_PEND_AMT,N_IBNR_SUMKJ,N_IBNR_FEE_DIRKJ ,N_IBNR_FEE_INDIRKJ,N_CLM_PEND_DIRFEE,
                    N_IBNR_SUM_AMT, N_IBNR_ACT_AMT ,N_PEND_FEE_INDIRKJ,c_Year,c_Quart)
           values(t_today_tm,sysdate,t_today_tm,I,v_dpt_cde,
                 '9',V_PROD_NO,v_kind_no,''/*v_insrnc_cde*/,'',
                 nvl(V_IBNR_PAYFD,0),nvl(V_IBNR_BFFD,0),nvl(V_IBNR_AMTFD,0),
                 v_fee_rate_dir,nvl(V_IBNR_FEE_DIRFD,0)/*nvl(v_ibnr_fee_dir,0),*/,v_fee_rate_indir,NVL(V_IBNR_FEE_INDIRFD,0)/*NVL(v_ibnr_fee_indir,0)*/,
                 v_clm_rate,NVL(V_IBNR_BFKJ,0),NVL(V_IBNR_PAYKJ,0),NVL(V_IBNR_AMTKJ,0),
                 v_ibnr_risk,v_ibnr_discount,v_ibnr_Duration,
                 NVL(v_pend_SUM,0),NVL(V_IBNR_SUMKJ,0),NVL(V_IBNR_FEE_DIRKJ,0),NVL(V_IBNR_FEE_INDIRKJ,0),nvl(V_PEND_FEE,0),
                 nvl(V_IBNR_SUM_AMT,0),nvl(V_IBNR_ACT_AMT,0),NVL(V_PEND_FEE_INDIRKJ,0),v_year,v_quart);

         end loop;
       close cur_base_10;
    commit;

 Exception
  When Others Then
    Rollback;
    v_Sqlcode := Sqlcode;
    v_Sqlerrm := Substr(Sqlerrm, 1, 600);
  ROLLBACK;
     v_err_content:='proc:[P_FIN_RI_IBNR_CALTO],出错流水号：['||v_today||V_Prod_NO||v_ply_no||'],错误描述：['||num||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
     v_return := -1;
 END;


 Procedure P_FIN_BAC_IBNR_CALTO(v_today in  varchar2,v_return  OUT NUMBER)
 Is
  cursor cur_base_10 is /*根據權重因子得到ibnr值*/
    SELECT DISTINCT C_KIND_NO,C_PROD_NO,c_year,c_quart
    FROM (
      select C_KIND_NO, C_PROD_NO,c_year,c_quart
      from WEB_FIN_MID_BAC_IBNR_BF a
      WHERE A.T_CAL_TM = trunc(t_today_tm)
      union all
      select C_KIND_NO, C_PROD_NO,c_year,c_quart
      from WEB_FIN_MID_BAC_IBNR_lt a
      WHERE A.T_CAL_TM = trunc(t_today_tm)
      --and a.c_kind_no = '01'
    );

 begin

   --将p_fin_ibnr_calnew 中相关计算各个险类ibnr程序单独出来,去掉所有相关法定ibnr计算,只计算会计IBNR shexiwan 2012-10-31
   v_max_tm :=to_char(to_date(v_today,'yyyy-mm_dd'),'yyyy-mm');
   t_today_tm:= TO_DATE(v_today,'YYYY-MM-DD');
   v_lase_tm:=add_months(t_today_tm,-1);
   v_return := 0;
   num := 0;

   v_pay_Weight:=0;                       --赔付率法权重
   v_bf_clm_Weight:=0;                    --bf法已决权重
   v_bf_report_Weight:=0;                 --bf法已报权重
   v_lt_clm_Weight:=0;                    --链锑法已决权重
   v_lt_report_Weight:=0;                 --链锑法已报权重
   v_lt_clm_ibnr:=0;
   v_lt_report_ibnr:=0;
   v_bf_clm_ibnr:=0;
   v_bf_report_ibnr:=0;
   v_pay_ibnr:=0;

   /*計算ibnr*/
     num := 10; I:=1;
       delete from WEB_FIN_MID_BAC_IBNR where T_CRT_TM=trunc(t_today_tm);   commit;
       open cur_base_10;    --行循环
        loop
          fetch cur_base_10 into
               v_kind_no,V_PROD_NO,v_year,v_quart;
          EXIT WHEN cur_base_10%NOTFOUND;
     num:=11;

   /************************會計bgn**************************************/

     -- add by sehxwian 2012-09-13 begin ----------------------------------

       --赔付法IBNR(IBNR含费用,IBNR直接理赔费用,ibnr间接理赔费用,已报间接理赔费用)
     /* begin
       select N_CAL_CLM_AMT,a.n_ibnr_dirfee,a.n_ibnr_indirfee,N_PEND_INDIRFEE
        into v_pay_ibnr,v_pay_dirfee,v_pay_indirfee,v_pay_pend_indirfee
        from web_fin_mid_bac_ibnr_pay a
       where a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
        and  a.c_prod_no = v_prod_no   and a.c_year = v_year
        and  a.c_quart = v_quart;
       exception when no_data_found then*/
         v_pay_ibnr:=0; v_pay_dirfee:=0;v_pay_indirfee:=0;v_pay_pend_indirfee:=0;
      -- end ;
       --已决链锑法IBNR
       begin
         SELECT a.n_ibnr,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
           into v_lt_clm_ibnr,v_lt_clm_dirfee,v_lt_clm_indirfee,v_lt_clm_pend_indirfee
           FROM WEB_FIN_MID_bac_IBNR_LT A
          WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
            and a.c_prod_no = v_prod_no   and a.c_year = v_year
            and a.c_quart = v_quart       --and C_FLG = '1'
            and C_TYPE = '1';
       exception when no_data_found then
           v_lt_clm_ibnr:=0;
           v_lt_clm_dirfee:=0;
           v_lt_clm_indirfee:=0;
           v_lt_clm_pend_indirfee:=0;
       end;
       --已决BF法IBNR
       begin
           SELECT a.n_ibnr_bf,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
             into v_bf_clm_ibnr,v_bf_clm_dirfee,v_bf_clm_indirfee,v_bf_clm_pend_indirfee
             FROM WEB_FIN_MID_bac_IBNR_BF A
            WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
              and a.c_prod_no = v_prod_no   and a.c_year = v_year
              and a.c_quart = v_quart       --and C_FLG = '1'
              and C_TYPE = '1';
       exception when no_data_found then
            v_bf_clm_ibnr:=0;
            v_bf_clm_dirfee:=0;
            v_bf_clm_indirfee:=0;
            v_bf_clm_pend_indirfee:=0;
       end;
       --已报链锑法IBNR
       begin
           SELECT a.n_ibnr,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
             into v_lt_report_ibnr,v_lt_report_dirfee,v_lt_report_indirfee,v_lt_report_pend_indirfee
             FROM WEB_FIN_MID_bac_IBNR_LT A
            WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
              and a.c_prod_no = v_prod_no   and a.c_year = v_year
              and a.c_quart = v_quart       --and C_FLG = '1'
              and C_TYPE = '2';
       exception when no_data_found then
            v_lt_report_ibnr:=0;
            v_lt_report_dirfee:=0;
            v_lt_report_indirfee:=0;
            v_lt_report_pend_indirfee:=0;
       end;
       --已报BF法IBNR
       begin
           SELECT a.n_ibnr_bf,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_PEND_INDIRFEE
             into v_bf_report_ibnr,v_bf_report_dirfee,v_bf_report_indirfee,v_bf_report_pend_indirfee
             FROM WEB_FIN_MID_bac_IBNR_BF A
            WHERE a.t_cal_tm = t_today_tm   and a.c_kind_no = v_kind_no
              and a.c_prod_no = v_prod_no   and a.c_year = v_year
              and a.c_quart = v_quart       --and C_FLG = '1'
              and C_TYPE = '2';
       exception when no_data_found then
            v_bf_report_ibnr:=0;
            v_bf_report_dirfee:=0;
            v_bf_report_indirfee:=0;
            v_bf_report_pend_indirfee:=0;
       end;

     --赔付率法ibnr权重(不区分已决,已报)
     begin
       select a.n_rate into v_pay_Weight from web_fin_ibnr_rate a
       where a.c_kind_no = v_kind_no  and a.c_prod_no = v_prod_no
         and a.c_cde = '027001';
     exception when no_data_found then
       v_pay_Weight:=0;
     end;

     --链锑法总的权重
     begin
       select a.n_rate into v_lt_Weight from web_fin_ibnr_rate a
       where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
         and a.c_cde = '027002';
     exception when no_data_found then
       v_lt_Weight:=0;
     end;
     --链锑法法ibnr权重(已决)
     begin
       select a.n_rate into v_lt_clm_Weight from web_fin_ibnr_rate a
       where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
         and a.c_cde = '027003';
     exception when no_data_found then
       v_lt_clm_Weight:=0;
     end;
     --链锑法法ibnr权重(已报)
     begin
       select a.n_rate into v_lt_report_Weight from web_fin_ibnr_rate a
       where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
         and a.c_cde = '027004';
     exception when no_data_found then
       v_lt_report_Weight:=0;
     end;
     --BF法总的权重
     begin
       select a.n_rate into v_bf_Weight from web_fin_ibnr_rate a
       where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
         and a.c_cde = '027005';
     exception when no_data_found then
       v_bf_Weight:=0;
     end;
     --BF法ibnr权重(已决)
     begin
       select a.n_rate into v_bf_clm_Weight from web_fin_ibnr_rate a
       where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
         and a.c_cde = '027006';
     exception when no_data_found then
       v_bf_clm_Weight:=0;
     end;
     --BF法ibnr权重(已报)
     begin
       select a.n_rate into v_bf_report_Weight from web_fin_ibnr_rate a
       where a.c_kind_no = v_kind_no   and a.c_prod_no = v_prod_no
         and a.c_cde = '027007';
     exception when no_data_found then
       v_bf_report_Weight:=0;
     end;

   -- add by sehxwian 2012-09-13 end  -----------------------------------

/*--会计IBNR值分别赋予不同的权重确定初始未决赔款准备金*/

    --会计未决赔款准备进=初始未决赔款准备进*（1+风险边际）/（1+贴现率）^久期   POWER(（1+贴现率）,久期)  POWER(2,3) =8
    --V_IBNR_SUMKJ := (V_IBNR_AMTKJ+v_pend_SUM)*(1+v_ibnr_risk)/POWER((1+v_ibnr_discount),v_ibnr_Duration);

    --V_IBNR_SUM_AMT会计IBNR:(含有直接理赔费用)=会计未决赔款准备进-已报告未决赔款+理赔费用
    --V_IBNR_SUM_AMT:=V_IBNR_SUMKJ-v_pend_SUM;
    --modify by shenxiwan 2012-09-14 各个不同ibnr*权重
    v_pay_Weight:=0;
    v_lt_clm_Weight:=0;
    v_lt_weight:=1;
    v_lt_report_Weight:=1;
    v_bf_clm_Weight:=0;
    v_bf_weight:=0;
    v_bf_report_Weight:=0;
    V_IBNR_SUM_AMT:=v_pay_ibnr*v_pay_Weight +
                   v_lt_clm_ibnr*v_lt_clm_Weight*v_lt_weight + v_lt_report_ibnr*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_ibnr*v_bf_clm_Weight*v_bf_weight + v_bf_report_ibnr*v_bf_report_Weight*v_bf_weight;
 /************************會計end**************************************/
   /************************理赔费用bgn**************************************/

  --法定IBNR间接理赔费用准备金= IBNR准备金(比例值) * 间接理赔费用与已决赔款的经验比率  014008
      /**新算法 2012-07-30 shexiwan
      ALAE准备金＝未决赔款准备金×ALAE比例
      已报未决ALAE＝已报未决赔款×ALAE比例/(1－ALAE比例)
      IBNR的ALAE＝ALAE准备金－已报未决ALAE
      **/
     --ALAR(未决理赔费用)

   --会计ibnr直接理赔费用=会计未决赔款准备金*ibnr直接理赔费用比例-已发生已报告直接理赔费用；
     --V_IBNR_FEE_DIRKJ:= V_IBNR_SUMKJ*v_fee_rate_dir-V_PEND_FEE;
     --V_IBNR_FEE_DIRKJ:=V_IBNR_SUM_AMT*v_fee_rate_dir;/*新算法:(J3-E3-F3)*未决评估参数!G2 修改于20110620*/
     V_IBNR_FEE_DIRKJ:=v_pay_dirfee*v_pay_Weight +
                   v_lt_clm_dirfee*v_lt_clm_Weight*v_lt_weight + v_lt_report_dirfee*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_dirfee*v_bf_clm_Weight*v_bf_weight + v_bf_report_dirfee*v_bf_report_Weight*v_bf_weight;

   --会计ibnr间接理赔费用=会计IBNR准备金*间接理赔费用与已决赔款的经验比率；
     --V_IBNR_FEE_INDIRKJ:= V_IBNR_SUM_AMT*v_fee_rate_indir;
     /*V_IBNR_FEE_INDIRKJ:=v_pay_indirfee*v_pay_Weight +
                   v_lt_clm_indirfee*v_lt_clm_Weight*v_lt_weight + v_lt_report_indirfee*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_indirfee*v_bf_clm_Weight*v_bf_weight + v_bf_report_indirfee*v_bf_report_Weight*v_bf_weight;*/

     --会计ibnr间接理赔费用,会计已报告间接理赔费用
    BEGIN
      SELECT N_IBNR_FEE_INDIRKJ,N_PEND_FEE_INDIRKJ
       INTO  V_IBNR_FEE_INDIRKJ,V_PEND_FEE_INDIRKJ
      FROM WEB_FIN_MID_IBNR A
      WHERE TRUNC(A.T_CAL_TM) = trunc(t_today_tm)
      AND A.C_YEAR = V_YEAR AND A.C_QUART = V_QUART
      AND A.C_PROD_NO = V_PROD_NO AND A.C_KIND_NO = V_KIND_NO;
    exception when no_data_found then
         V_IBNR_FEE_INDIRKJ:=0;V_PEND_FEE_INDIRKJ:=0;
    end ;
    --会计已报告间接理赔费用:=(已报告未决赔款+理赔费用)*间接理赔费用与已决赔款的经验比率*0.5
     --V_PEND_FEE_INDIRKJ:= v_pend_SUM*v_fee_rate_indir*0.5;
     /*V_PEND_FEE_INDIRKJ:=v_pay_pend_indirfee*v_pay_Weight +
                   v_lt_clm_pend_indirfee*v_lt_clm_Weight*v_lt_weight + v_lt_report_pend_indirfee*v_lt_report_Weight*v_lt_weight +
                   v_bf_clm_pend_indirfee*v_bf_clm_Weight*v_bf_weight + v_bf_report_pend_indirfee*v_bf_report_Weight*v_bf_weight;*/

   /************************理赔费用end**************************************/

      --V_IBNR_ACT_AMT会计IBNR:(传财务值)=会计IBNR:(含有直接理赔费用)-会计ibnr直接理赔费用
    V_IBNR_ACT_AMT:=V_IBNR_SUM_AMT-V_IBNR_FEE_DIRKJ;
    if V_IBNR_ACT_AMT+V_IBNR_FEE_DIRKJ <> 0 then
   -- 法定及会计 ibnr值 ibnr理赔费用 汇总的数据
          insert into WEB_FIN_MID_BAC_IBNR(T_Crt_TM ,T_UPD_TM ,t_cal_tm ,N_SEQ_NO ,C_DPT_CDE ,
                    C_INTER_CDE  ,C_PROD_NO ,c_kind_no ,C_INSRNC_CDE ,C_CLS_TM ,
                    N_IBNR_PAYFD ,N_IBNR_BFFD  ,N_IBNR_CAL_AMTFD ,
                    N_DIR_RATE ,N_IBNR_FEE_DIRFD ,N_INDIR_RATE ,N_IBNR_FEE_INDIRFD  ,
                    N_IBNR_RATEKJ ,N_IBNR_BFKJ  ,N_IBNR_PAYKJ ,N_IBNR_ACT_AMTKJ ,
                    N_IBNR_RISK,N_IBNR_DISCOUNT,N_IBNR_DURATION,
                    N_PEND_AMT,N_IBNR_SUMKJ,N_IBNR_FEE_DIRKJ ,N_IBNR_FEE_INDIRKJ,N_CLM_PEND_DIRFEE,
                    N_IBNR_SUM_AMT, N_IBNR_ACT_AMT ,N_PEND_FEE_INDIRKJ,c_Year,c_Quart)
           values(t_today_tm,sysdate,t_today_tm,I,v_dpt_cde
                 ,'9',V_PROD_NO,v_kind_no,''/*v_insrnc_cde*/,'',
                 nvl(V_IBNR_PAYFD,0),nvl(V_IBNR_BFFD,0),nvl(V_IBNR_AMTFD,0),
                 v_fee_rate_dir,nvl(V_IBNR_FEE_DIRFD,0)/*nvl(v_ibnr_fee_dir,0),*/,v_fee_rate_indir,NVL(V_IBNR_FEE_INDIRFD,0)/*NVL(v_ibnr_fee_indir,0)*/,
                 v_clm_rate,NVL(V_IBNR_BFKJ,0),NVL(V_IBNR_PAYKJ,0),NVL(V_IBNR_AMTKJ,0),
                 v_ibnr_risk,v_ibnr_discount,v_ibnr_Duration,
                 NVL(v_pend_SUM,0),NVL(V_IBNR_SUMKJ,0),NVL(V_IBNR_FEE_DIRKJ,0),NVL(V_IBNR_FEE_INDIRKJ,0),nvl(V_PEND_FEE,0),
                 nvl(V_IBNR_SUM_AMT,0),nvl(V_IBNR_ACT_AMT,0),NVL(V_PEND_FEE_INDIRKJ,0),v_year,v_quart);
    end if;
         end loop;
       close cur_base_10;
    commit;
       --20140504执行成功向日志表中添加记录
      INSERT INTO WEB_BAS_FIN_ERRORLOG
       (C_ERR_NO, C_ERRTYPE_NO, C_TRAN_TYPE, C_ERR_CONTENT, T_CRT_TM)
      VALUES
       ('000', '001', '0000', '[P_FIN_BAC_IBNR_CALTO]--再保后IBNR汇总存过执行成功！', SYSDATE);
      COMMIT;

 Exception
  When Others Then
    Rollback;
    v_Sqlcode := Sqlcode;
    v_Sqlerrm := Substr(Sqlerrm, 1, 600);
  ROLLBACK;
    v_err_content:='proc:[P_FIN_BAC_IBNR_CALTO],出错流水号：['||v_today||V_Prod_NO||v_ply_no||'],错误描述：['||num||SQLCODE||SQLERRM;
    insert into web_bas_fin_errorlog
    (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
    VALUES('007','001','0000', v_err_content,SYSDATE);
    COMMIT;
     v_return := -1;
 END;

end P_FIN_IBNR_CALTO;
/
