CREATE package EL_LOSSINFO_INTO is

  procedure CLMINFO_EL_INTO;

  procedure PENDINFO_EL_INTO;

  procedure LOSSINFO_EL_INIT;

  procedure LOSSINFO_CATA_INIT;

end EL_LOSSINFO_INTO;
/
