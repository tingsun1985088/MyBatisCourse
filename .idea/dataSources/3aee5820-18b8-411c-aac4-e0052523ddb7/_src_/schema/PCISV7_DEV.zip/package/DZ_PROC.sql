CREATE PACKAGE "DZ_PROC" IS

g_pttype varchar2(2):='01';--编号
/* 补0函数,  */
FUNCTION fill_zero(i_str VARCHAR2, i_length NUMBER, i_direction  NUMBER)
RETURN VARCHAR2;

/*产生财务收、付款流水号 SEQUENCE finseq*/
PROCEDURE get_fin_no(oFinCde OUT WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
                    icDptCde WEB_ORG_DPT.c_dpt_cde%TYPE,
                    icFinTyp VARCHAR2,
          idep_type VARCHAR2);
/*************************产生订单流水号 SEQUENCE finseq******************/
--------订单号：年月日YYYYMMDD（8位）+类型（A1财产、A2寿险、A3健康）+公司码（7）+事业部门类型(2)+流水号（6位）
   PROCEDURE get_order_no (
      ofincde    OUT   WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
      icdptcde            WEB_ORG_DPT.c_dpt_cde%TYPE,
      icfintyp            VARCHAR2,
      idep_type                         VARCHAR2
   );

/*产生财务收付款流水号 SEQUENCE finseq*/
PROCEDURE get_fin_cav_no(oFinCde IN OUT WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
                    icDptCde WEB_ORG_DPT.c_dpt_cde%TYPE,
                                icFinTyp VARCHAR2,
                      idep_type VARCHAR2);
/*获取凭证号*/
--公司编码（7位）+凭证来源（2位）+年/月（4位）+每月顺序号（6位)

-- wuqy 暂时屏蔽 2013-4-16
/* PROCEDURE get_fin_voucode(v_vou_no IN OUT WEB_FIN_DCR.c_vou_no%TYPE,
            v_period_name IN OUT WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE,
                      v_dptacc_cde     WEB_FIN_DCR.c_dptacc_no%TYPE,
            idep_type VARCHAR2);*/
/*再保获取凭证号,流水号表用B标识 */
-- wuqy 暂时屏蔽 2013-4-16
/*
PROCEDURE get_fin_rivoucode(v_vou_no IN OUT WEB_FIN_DCR.c_vou_no%TYPE,
            v_period_name IN OUT WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE,
                      v_dptacc_cde     WEB_FIN_DCR.c_dptacc_no%TYPE,
            idep_type VARCHAR2);
*/

/*准备金获取凭证号,流水号表用Z标识 */
-- wuqy 暂时屏蔽 2013-4-16
/*PROCEDURE get_fin_prevoucode(v_vou_no IN OUT WEB_FIN_DCR.c_vou_no%TYPE,
            v_period_name IN OUT WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE,
                      v_dptacc_cde     WEB_FIN_DCR.c_dptacc_no%TYPE,
            idep_type VARCHAR2);*/

/*************************产生业务接口流水号 SEQUENCE finseq******************/
PROCEDURE get_ifin_no(oFinCde OUT WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
                    icDptCde WEB_ORG_DPT.c_dpt_cde%TYPE,
                    icFinTyp VARCHAR2,
          idep_type VARCHAR2);

END Dz_Proc;

/
