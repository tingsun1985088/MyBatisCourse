CREATE package f_fin_cache is
  --缓存基础数据
  function f_dpt_array return t_dpt_table;               --所有机构
  function f_prod_array return t_prod_table;             --产品
  function f_department_array return t_department_table; --部门
  function f_company_array return t_company_table;       --帐套
  function f_bsns_array return t_bsns_table;             --渠道
  function f_ibnr_array return t_ibnr_table;       
    
end f_fin_cache;
/
