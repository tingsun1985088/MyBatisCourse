CREATE PACKAGE FIN_iface_optimize IS
procedure p_get_report(
      t_bgn_tm  IN  date,
            t_end_tm  IN  date ,
            dptlen   IN  int,
            v_C_TYPE in varchar2,
            v_ret_sta OUT number);
END FIN_iface_optimize;
/
