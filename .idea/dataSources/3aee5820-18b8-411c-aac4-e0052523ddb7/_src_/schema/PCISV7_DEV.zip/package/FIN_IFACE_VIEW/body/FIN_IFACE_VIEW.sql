CREATE package body fin_iface_view is
      --编译视图
      procedure fin_compile_view(succflag out varchar2) is
      begin
        execute immediate 'alter materialized view V_CLM_NOVHL compile';
        execute immediate 'alter materialized view V_CLM_VHL compile';
        execute immediate 'alter materialized view V_FACTORAGE_NOVHL compile';
        execute immediate 'alter materialized view V_FACTORAGE_VHL compile';
        execute immediate 'alter materialized view V_FACTORAGE_VHL2 compile';
        execute immediate 'alter materialized view V_PAYMENTS_ON_ACCOUNT compile';
        execute immediate 'alter materialized view V_PREMIUMS_RECEIVABLE compile';
        execute immediate 'alter materialized view V_PREM_NOVHL compile';
        --execute immediate 'alter materialized view V_PREM_NOVHL2 compile';
        execute immediate 'alter materialized view V_PREM_VHL compile';
        execute immediate 'alter materialized view V_REINSURANCE_COMPANYNOVHL compile';
        execute immediate 'alter materialized view V_REINSURANCE_COMPANYVHL compile';
        execute immediate 'alter materialized view V_REINSURANCE_PREMIUM compile';
        execute immediate 'alter materialized view V_REINSURANCE_PREMIUM_COMPANY compile';
        execute immediate 'alter materialized view V_REINSURANCE_PREMIUM_NOVHL compile';
        --execute immediate 'alter materialized view V_REINSURANCE_PREMIUM_VHL compile';
        execute immediate 'alter materialized view V_RESCLM compile';--未决赔款准备金－机动车辆保险
        execute immediate 'alter materialized view V_RESCLM_NOVHL compile';---未决赔款准备金－非车
        execute immediate 'alter materialized view V_RESCLM_NOVHL2 compile';---未决赔款准备金－非车
        execute immediate 'alter materialized view V_RESPLY_NOVHL compile';--提取未到期责任准备金－非车
        execute immediate 'alter materialized view V_RESPLY_VHL compile';--提取未到期责任准备金－机动车辆保险
        execute immediate 'alter materialized view V_RICED_DUE compile';
        --execute immediate 'alter materialized view V_RICED_DUE_NOVHL compile';
        execute immediate 'alter materialized view V_RICED_DUE_VHL compile';
        execute immediate 'alter materialized view V_RICLM2_NOVHL compile';
        execute immediate 'alter materialized view V_RICLM2_VHL compile';
        execute immediate 'alter materialized view V_RICLM_NOVHL compile';
        execute immediate 'alter materialized view V_RICLM_VHL compile';
        execute immediate 'alter materialized view V_RIPRM_NOVHL compile';
        execute immediate 'alter materialized view V_RIPRM_NOVHL2 compile';
        execute immediate 'alter materialized view V_RIPRM_VHL compile';
        execute immediate 'alter materialized view V_RIRESCLM compile';--摊回未决赔款准备金
        execute immediate 'alter materialized view V_RIRESCLM_NOVHL compile';--摊回未决赔款准备金 --非车
        execute immediate 'alter materialized view V_RIRESCLM_VHL compile';--摊回未决赔款准备金 --车
        execute immediate 'alter materialized view V_RESPLY_NOVHL2 compile';--未到期责任准备金－非车

        execute immediate 'alter materialized view v_factorage_novhl_yj compile';
        execute immediate 'alter materialized view v_premiums_receivable_yj compile';
        execute immediate 'alter materialized view v_prem_novhl_yj compile';
        execute immediate 'alter materialized view v_resclm_novhl2_yj compile';---未决赔款准备金－非车
        execute immediate 'alter materialized view v_resclm_novhl_yj compile';--提取未决赔款准备金－非车
        execute immediate 'alter materialized view v_resply_novhl2_yj compile';--未到期责任准备金－非车
        execute immediate 'alter materialized view v_resply_novhl_yj compile';--提取未到期责任准备金－非车
        execute immediate 'alter materialized view v_riresclm_novhl_yj compile';--摊回未决赔款准备金 --非车
        execute immediate 'alter materialized view v_clm_novhl_yj compile';
        execute immediate 'alter materialized view V_REINSURANCE_companyyj compile';
        execute immediate 'alter materialized view v_reinsurance_premiumyj compile';
       -- execute immediate 'alter materialized view v_resclm_novhl_yj compile';
        --execute immediate 'alter materialized view v_resply_novhl_yj compile';
        execute immediate 'alter materialized view v_riclm_novhl_yj compile';
        --execute immediate 'alter materialized view v_riresclm_novhl_yj compile';
        --农险 add by shexiwan 2012-12-05
        execute immediate 'alter materialized view V_PREMIUMS_RECEIVABLE_NY compile';

      end fin_compile_view;
      --刷新视图(全量刷新)
      procedure fin_refresh_view(succflag out varchar2)is
         v_view_name varchar2(50);
         v_view_sql  varchar2(10000);
         v_memo      varchar2(50);
         cursor cur_view is
         select a.c_view_name,a.c_view_sql,a.c_memo 
           from FIN_IFACE_DYNA_VIEW_CONF a
          where a.c_pk_id = '1';
      begin
          /*open cur_view;
            loop
               fetch cur_view into v_view_name,v_view_sql,v_memo;
               exit when cur_view%notfound;
                    execute immediate v_view_sql;
             end loop;
          close cur_view;*/
       
      
         --赔付支出－赔款支出 非车
        dbms_output.put_line('begin :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        DBMS_SNAPSHOT.REFRESH('V_CLM_NOVHL');
        dbms_output.put_line('V_CLM_NOVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --dbms_mview.refresh
        --赔付支出－赔款支出 车险
        DBMS_SNAPSHOT.REFRESH('V_CLM_VHL');
        dbms_output.put_line('V_CLM_VHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --手续费及佣金支出 非车
        DBMS_SNAPSHOT.REFRESH('V_FACTORAGE_NOVHL');
        dbms_output.put_line('V_FACTORAGE_NOVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --续费及佣金支出——机动车辆保险
        DBMS_SNAPSHOT.REFRESH('V_FACTORAGE_VHL');
        dbms_output.put_line('V_FACTORAGE_VHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --手续费及佣金支出——机动车辆保险 交强险
        DBMS_SNAPSHOT.REFRESH('V_FACTORAGE_VHL2');
        dbms_output.put_line('V_FACTORAGE_VHL2 end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --预付赔付款－机动车辆保险－交强险
        DBMS_SNAPSHOT.REFRESH('V_PAYMENTS_ON_ACCOUNT');
        dbms_output.put_line('V_PAYMENTS_ON_ACCOUNT end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --应收保费
        DBMS_SNAPSHOT.REFRESH('V_PREMIUMS_RECEIVABLE');
        dbms_output.put_line('V_PREMIUMS_RECEIVABLE end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --原保费收入非车(不到险别)
        DBMS_SNAPSHOT.REFRESH('V_PREM_NOVHL');
        dbms_output.put_line('V_PREM_NOVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --DBMS_SNAPSHOT.REFRESH('V_PREM_NOVHL2');
        --原保费收入 车(到险别)
        DBMS_SNAPSHOT.REFRESH('V_PREM_VHL');
        dbms_output.put_line('V_PREM_VHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --分保费收入（损益） 非车(不分境内境外)
        DBMS_SNAPSHOT.REFRESH('V_REINSURANCE_COMPANYNOVHL');
        dbms_output.put_line('V_REINSURANCE_COMPANYNOVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        ----分保费收入－机动车辆保险
        DBMS_SNAPSHOT.REFRESH('V_REINSURANCE_COMPANYVHL');
        dbms_output.put_line('V_REINSURANCE_COMPANYVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        ----分出保费-车险
        DBMS_SNAPSHOT.REFRESH('V_REINSURANCE_PREMIUM');
        dbms_output.put_line('V_REINSURANCE_PREMIUM end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        ---- 分保费收入---境内、境外
        DBMS_SNAPSHOT.REFRESH('V_REINSURANCE_PREMIUM_COMPANY');
        dbms_output.put_line('V_REINSURANCE_PREMIUM_COMPANY end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        ----分出保费非车
        DBMS_SNAPSHOT.REFRESH('V_REINSURANCE_PREMIUM_NOVHL');
        dbms_output.put_line('V_REINSURANCE_PREMIUM_NOVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --DBMS_SNAPSHOT.REFRESH('V_REINSURANCE_PREMIUM_VHL');
        
        ----分保费收入（损益） 非车(不分境内境外)
        DBMS_SNAPSHOT.REFRESH('V_RICED_DUE');
        dbms_output.put_line('V_RICED_DUE end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        
        --DBMS_SNAPSHOT.REFRESH('V_RICED_DUE_NOVHL');
        --分保费用（损益） 车险
        DBMS_SNAPSHOT.REFRESH('V_RICED_DUE_VHL');
        dbms_output.put_line('V_RICED_DUE_VHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --摊回赔付支出（损益）－赔款支出 非车
        DBMS_SNAPSHOT.REFRESH('V_RICLM2_NOVHL');
        dbms_output.put_line('V_RICLM2_NOVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --摊回赔款商车
        DBMS_SNAPSHOT.REFRESH('V_RICLM2_VHL');
        dbms_output.put_line('V_RICLM2_VHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --分保费收入（损益） 非车(不分境内境外)
        DBMS_SNAPSHOT.REFRESH('V_RICLM_NOVHL');
        dbms_output.put_line('V_RICLM_NOVHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --赔付支出－分保赔付支出（损益） (车险)
        DBMS_SNAPSHOT.REFRESH('V_RICLM_VHL');
        dbms_output.put_line('V_RICLM_VHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        
        --DBMS_SNAPSHOT.REFRESH('V_RIPRM_NOVHL');
        --摊回分保费用 非车
        DBMS_SNAPSHOT.REFRESH('V_RIPRM_NOVHL2');
        dbms_output.put_line('V_RIPRM_NOVHL2 end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --摊回分保费用 车
        DBMS_SNAPSHOT.REFRESH('V_RIPRM_VHL');
        dbms_output.put_line('V_RIPRM_VHL end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        
        --手续费及佣金支出 非车
        DBMS_SNAPSHOT.REFRESH('v_factorage_novhl_yj');
        dbms_output.put_line('v_factorage_novhl_yj end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --应收保费
        DBMS_SNAPSHOT.REFRESH('v_premiums_receivable_yj');
        dbms_output.put_line('v_premiums_receivable_yj end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        
         ----原保费收入非车(不到险别)
        DBMS_SNAPSHOT.REFRESH('v_prem_novhl_yj');
        dbms_output.put_line('v_prem_novhl_yj end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --赔付支出－赔款支出 非车
        DBMS_SNAPSHOT.REFRESH('v_clm_novhl_yj');
        dbms_output.put_line('v_clm_novhl_yj end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        --分保费收入（损益） 非车(不分境内境外)
        DBMS_SNAPSHOT.REFRESH('V_REINSURANCE_companyyj');
        dbms_output.put_line('V_REINSURANCE_companyyj end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
         --分出保费非车(不到险别)
        DBMS_SNAPSHOT.REFRESH('v_reinsurance_premiumyj');
        dbms_output.put_line('v_reinsurance_premiumyj end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        
         --赔付支出－分保赔付支出（损益） (非车险)
        DBMS_SNAPSHOT.REFRESH('v_riclm_novhl_yj');
        dbms_output.put_line('v_riclm_novhl_yj end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        
        --农险 add by shexiwan 2012-12-05
        ---应收保费
        DBMS_SNAPSHOT.REFRESH('V_PREMIUMS_RECEIVABLE_NY');
        dbms_output.put_line('V_PREMIUMS_RECEIVABLE_NY end :' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
        
        ------准备金 begin-----------
        ------未决赔款准备金－机动车辆保险
         /*DBMS_SNAPSHOT.REFRESH('V_RESCLM');
         ---提取未决赔款准备金－非车
         DBMS_SNAPSHOT.REFRESH('V_RESCLM_NOVHL');
         ---未决赔款准备金－非车
         DBMS_SNAPSHOT.REFRESH('V_RESCLM_NOVHL2');
         --提取未到期责任准备金－非车
         DBMS_SNAPSHOT.REFRESH('V_RESPLY_NOVHL');
         ----提取未到期责任准备金－机动车辆保险
         DBMS_SNAPSHOT.REFRESH('V_RESPLY_VHL');
         --摊回未决赔款准备金
         DBMS_SNAPSHOT.REFRESH('V_RIRESCLM');
         --摊回未决赔款准备金 --非车
         DBMS_SNAPSHOT.REFRESH('V_RIRESCLM_NOVHL');
         --摊回未决赔款准备金 --车
         DBMS_SNAPSHOT.REFRESH('V_RIRESCLM_VHL');
         --未到期责任准备金－非车
         DBMS_SNAPSHOT.REFRESH('V_RESPLY_NOVHL2');
         --未决赔款准备金－非车
         DBMS_SNAPSHOT.REFRESH('v_resclm_novhl2_yj');
        --提取未决赔款准备金－非车
         DBMS_SNAPSHOT.REFRESH('v_resclm_novhl_yj');
         ----未到期责任准备金－非车
         DBMS_SNAPSHOT.REFRESH('v_resply_novhl2_yj');
         --提取未到期责任准备金－非车
         DBMS_SNAPSHOT.REFRESH('v_resply_novhl_yj');
         --摊回未决赔款准备金 --非车
         DBMS_SNAPSHOT.REFRESH('v_riresclm_novhl_yj');
         --提取未决赔款准备金－非车
         DBMS_SNAPSHOT.REFRESH('v_resclm_novhl_yj');
         DBMS_SNAPSHOT.REFRESH('v_resply_novhl_yj');
         --摊回未决赔款准备金 --非车
         DBMS_SNAPSHOT.REFRESH('v_riresclm_novhl_yj');*/
        ------准备金 end-----------
        
      end fin_refresh_view;

end fin_iface_view;
/
