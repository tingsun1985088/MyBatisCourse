CREATE package P_FIN_RI_LDF is
   --已决季度进展因子
   procedure P_Fin_Ri_Amt_Ldf(today varchar2, v_cal_type in char, v_return out varchar2);
   --已报季度进展因子
   procedure P_Fin_Ri_Report_Ldf(today varchar2, v_cal_type in char, v_return out varchar2);
end P_FIN_RI_LDF;
/
