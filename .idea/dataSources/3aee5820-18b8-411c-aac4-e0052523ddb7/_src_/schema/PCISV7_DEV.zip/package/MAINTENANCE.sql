CREATE PACKAGE "MAINTENANCE" is

  PROCEDURE CUX_SEND_MAIL(x_message   in long,
                          x_Subject   in varchar2,
                          x_mail_to   in varchar2,
                          v_succsflag  OUT int);

end maintenance;










/
