CREATE PACKAGE BODY "CLMUNIFY" is
  --?????????????????????????????????????  ClmUnify

  /*
     -1 ??????????
     -2 ????????
     -9 ??????!
  */
  PROCEDURE checkClmUnify(v_rcpt_no       IN WEB_FIN_RPCLMCUSTOMER.C_Rcpt_No%type,
                          v_emp_cde       IN WEB_FIN_RPCLMCUSTOMER.c_Check_Cde%type,
                          v_dptacc_cde    IN web_pay_seemoney_config.c_dptacc_cde%type,
                          v_type          IN VARCHAR2,
                          v_overrule_mind IN WEB_FIN_RPCLMCUSTOMER.c_recv_bank_reason%TYPE,
                          v_succsflag     IN OUT NUMBER) IS

    v_init_state WEB_FIN_RPCLMCUSTOMER.C_BALA_MRK%TYPE;
    v_vary_state WEB_FIN_RPCLMCUSTOMER.C_BALA_MRK%TYPE;
    v_pay_amt    WEB_FIN_RPCLMCUSTOMER.n_Get_Prm%TYPE;

    v_min_amt       web_pay_seemoney_config.n_min_amt%TYPE;
    v_max_amt       web_pay_seemoney_config.n_max_amt%TYPE;
    v_dpt_level     web_pay_seemoney_config.c_dpt_level%TYPE;
    v_clm_dpt_level web_pay_seemoney_config.c_dpt_level%TYPE;
    v_bala_mrk      web_fin_rpclmcustomer.c_rcpt_no%TYPE;

    v_dpt_cde web_fin_clm_due.c_dpt_cde%TYPE;
    v_count   number;

  BEGIN
    v_succsflag := 0;
    v_count     := 0;

    select count(1)
      into v_count
      from web_fin_rpclmcustomer
     where c_rcpt_no = v_rcpt_no;

   if v_count <> 1 then
      v_succsflag := -1;
      RETURN;
   end if;

    select nvl(C_BALA_MRK,'0'),nvl(n_Get_Prm,0)
      into v_init_state, v_pay_amt
      from web_fin_rpclmcustomer
     where c_rcpt_no = v_rcpt_no;

    select nvl(n_min_amt,0),nvl(n_max_amt,0), nvl(c_dpt_level,'2')
      into v_min_amt, v_max_amt, v_dpt_level
      from web_pay_seemoney_config
     where c_dptacc_cde = v_dptacc_cde;
    /*
    *   1 ??   Check
    *   2 ??   UndoCheck
    *   3 ??   SEND
    *   4 ??   RECV
    */
    if v_type = 'Check' then
      /*??*/
      if v_pay_amt <= v_max_amt then
        UPDATE web_fin_rpclmcustomer
           SET C_BALA_MRK     = '4',
               C_CHECK_CDE    = v_emp_cde,
               T_CHECK_TM     = sysdate,
               T_UPDATE_TM    = sysdate,
               c_previous_mrk = c_bala_mrk
         WHERE C_RCPT_NO = v_rcpt_no
           and C_BALA_MRK <> '5';
      else
        if v_dpt_level = '2' then
          UPDATE web_fin_rpclmcustomer
             SET C_BALA_MRK     = '3',
                 C_CHECK_CDE    = v_emp_cde,
                 T_CHECK_TM     = sysdate,
                 T_UPDATE_TM    = sysdate,
                 c_previous_mrk = c_bala_mrk
           WHERE C_RCPT_NO = v_rcpt_no
             and C_BALA_MRK <> '5';
        else
          UPDATE web_fin_rpclmcustomer
             SET C_BALA_MRK     = '2',
                 C_CHECK_CDE    = v_emp_cde,
                 T_CHECK_TM     = sysdate,
                 T_UPDATE_TM    = sysdate,
                 c_previous_mrk = c_bala_mrk
           WHERE C_RCPT_NO = v_rcpt_no
             and C_BALA_MRK <> '5';
        end if;
      end if;
    elsif v_type = 'UndoCheck' then
      /*??*/
      SELECT c.c_dpt_level
        into v_clm_dpt_level
        FROM web_fin_clm_due a, web_org_dpt b, web_pay_seemoney_config c
       where a.c_dpt_cde = b.c_dpt_cde
         and b.c_dptacc_cde = c.c_dptacc_cde
         and a.c_rcpt_no = v_rcpt_no;

      /*????*/
      if v_clm_dpt_level = v_dpt_level then
        UPDATE web_fin_rpclmcustomer
           SET C_BALA_MRK         = '0',
               C_CHECK_CDE        = v_emp_cde,
               T_CHECK_TM         = sysdate,
               T_UPDATE_TM        = sysdate,
               c_previous_mrk     = c_bala_mrk,
               c_recv_bank_reason = v_overrule_mind
         WHERE C_RCPT_NO = v_rcpt_no
           and C_BALA_MRK <> '5';

        UPDATE web_fin_clm_due
           SET C_BALA_MRK = '0'
         WHERE C_RCPT_NO = v_rcpt_no;
      else
        /*?????*/
        if v_dpt_level = '1' then
          UPDATE web_fin_rpclmcustomer
             SET C_BALA_MRK         = '2',
                 C_CHECK_CDE        = v_emp_cde,
                 T_CHECK_TM         = sysdate,
                 T_UPDATE_TM        = sysdate,
                 c_previous_mrk     = c_bala_mrk,
                 n_UndoCheck_count  = n_UndoCheck_count + 1,
                 c_recv_bank_reason = v_overrule_mind
           WHERE C_RCPT_NO = v_rcpt_no
             and C_BALA_MRK <> '5';
          /*?????*/
        elsif v_dpt_level = '2' then
          UPDATE web_fin_rpclmcustomer
             SET C_BALA_MRK         = '1',
                 C_CHECK_CDE        = v_emp_cde,
                 T_CHECK_TM         = sysdate,
                 T_UPDATE_TM        = sysdate,
                 c_previous_mrk     = c_bala_mrk,
                 c_recv_bank_reason = v_overrule_mind
           WHERE C_RCPT_NO = v_rcpt_no
             and C_BALA_MRK <> '5';
        end if;
      end if;
    elsif v_type = 'SEND' then
      /*??*/
      UPDATE web_fin_rpclmcustomer
         SET C_BALA_MRK      = '5',
             c_send_bank_cde = v_emp_cde,
             t_send_bank_tm  = sysdate,
             T_UPDATE_TM     = sysdate,
             c_previous_mrk  = c_bala_mrk
       WHERE C_RCPT_NO = v_rcpt_no
         and C_BALA_MRK <> '5';
    elsif v_type = 'RECV' then
      /*??*/
      SELECT c_bala_mrk
        into v_bala_mrk
        from web_fin_rpclmcustomer
       where c_rcpt_no = v_rcpt_no;
      /*??*/
      if v_bala_mrk = '6' then
        /*????*/
        SELECT count(1)
          into v_count
          from web_fin_rprollclmcustomer
         where c_rcpt_no = v_rcpt_no;
        if v_count > 0 then
          v_succsflag := -2;
          RETURN;
        else
          insert into web_fin_rprollclmcustomer
            (c_rcpt_no,
             c_item_no,
             c_customer_accounts,
             c_accounts_name,
             c_bank_accounts,
             c_provinces,
             c_city,
             c_mail,
             c_mobile_phone,
             c_cur_cde,
             c_open_city,
             c_bal_type,
             c_company_accounts,
             t_desire_date,
             t_desire_time,
             c_use,
             n_get_prm,
             c_receive_no,
             c_company_openbank,
             c_table_flag,
             c_check_flag,
             c_check_cde,
             t_check_tm,
             c_send_bank_flag,
             c_send_bank_cde,
             t_send_bank_tm,
             c_recv_bank_flag,
             c_recv_bank_cde,
             t_recv_bank_tm,
             c_recv_bank_reason,
             c_check_name,
             c_export_name,
             t_export_tm,
             c_import_name,
             t_import_tm,
             c_import_memo,
             c_bala_mrk,
             c_bank_cde,
             c_capital_flows,
             c_repairplant_no,
             c_pay_type,
             t_roll_tm,
             c_crt_cde,
             C_CHECK_MEMO,
             c_Entry_name,
             t_Entry_tm,
             T_UPDATE_TM,
             C_IDENTITY_NO,
             C_REPORTCASE_TEL,
             C_INSURANT_TEL,
             c_validate_flag,
             C_VALIDATE_MIND)
            SELECT C_RCPT_NO,
                   '1',
                   C_CUSTOMER_ACCOUNTS,
                   C_ACCOUNTS_NAME,
                   C_BANK_ACCOUNTS,
                   C_PROVINCES,
                   C_CITY,
                   C_MAIL,
                   C_MOBILE_PHONE,
                   C_CUR_CDE,
                   C_OPEN_CITY,
                   C_BAL_TYPE,
                   C_COMPANY_ACCOUNTS,
                   T_DESIRE_DATE,
                   T_DESIRE_TIME,
                   C_USE,
                   N_GET_PRM,
                   C_RECEIVE_NO,
                   C_COMPANY_OPENBANK,
                   C_TABLE_FLAG,
                   C_CHECK_FLAG,
                   C_CHECK_CDE,
                   T_CHECK_TM,
                   C_SEND_BANK_FLAG,
                   C_SEND_BANK_CDE,
                   T_SEND_BANK_TM,
                   C_RECV_BANK_FLAG,
                   v_emp_cde,
                   sysdate,
                   v_overrule_mind,
                   C_CHECK_NAME,
                   C_EXPORT_NAME,
                   T_EXPORT_TM,
                   C_IMPORT_NAME,
                   T_IMPORT_TM,
                   C_IMPORT_MEMO,
                   '0',
                   C_BANK_CDE,
                   C_CAPITAL_FLOWS,
                   C_REPAIRPLANT_NO,
                   C_PAY_TYPE,
                   sysdate,
                   v_emp_cde,
                   C_CHECK_MEMO,
                   C_ENTRY_NAME,
                   T_ENTRY_TM,
                   sysdate,
                   C_IDENTITY_NO,
                   C_REPORTCASE_TEL,
                   C_INSURANT_TEL,
                   C_VALIDATE_FLAG,
                   C_VALIDATE_MIND
              from web_fin_rpclmcustomer
             where c_rcpt_no = v_rcpt_no;
        end if;
      else
        if v_overrule_mind = '????' then
          UPDATE web_fin_rpclmcustomer
             SET C_BALA_MRK         = '6',
                 c_recv_bank_cde    = v_emp_cde,
                 t_recv_bank_tm     = sysdate,
                 T_UPDATE_TM        = sysdate,
                 c_previous_mrk     = c_bala_mrk,
                 c_recv_bank_reason = v_overrule_mind
           WHERE C_RCPT_NO = v_rcpt_no;
        else
          UPDATE web_fin_rpclmcustomer
             SET C_BALA_MRK         = '0',
                 c_recv_bank_cde    = v_emp_cde,
                 t_recv_bank_tm     = sysdate,
                 T_UPDATE_TM        = sysdate,
                 c_previous_mrk     = c_bala_mrk,
                 c_recv_bank_reason = v_overrule_mind
           WHERE C_RCPT_NO = v_rcpt_no;

          UPDATE web_fin_clm_due
             SET C_BALA_MRK = '0'
           WHERE C_RCPT_NO = v_rcpt_no;
        end if;
      end if;

    end if;
    v_succsflag := 0;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        v_succsflag := -9;
        RETURN;
      END;
  END;

  PROCEDURE checkRollClmUnify( --starte     IN       WEB_FIN_RPCLMCUSTOMER.C_BALA_MRK%TYPE,
                              v_rcpt_no       IN WEB_FIN_RPROLLCLMCUSTOMER.C_Rcpt_No%type, --???
                              v_emp_cde       IN WEB_FIN_RPROLLCLMCUSTOMER.c_Check_Cde%type, --???
                              v_dptacc_cde    IN web_pay_seemoney_config.c_dptacc_cde%type, --????
                              v_type          IN VARCHAR2, --????
                              v_overrule_mind IN WEB_FIN_RPROLLCLMCUSTOMER.c_recv_bank_reason%TYPE, --??
                              v_succsflag     IN OUT NUMBER) IS

    v_init_state WEB_FIN_RPROLLCLMCUSTOMER.C_BALA_MRK%TYPE;
    v_vary_state WEB_FIN_RPROLLCLMCUSTOMER.C_BALA_MRK%TYPE;
    v_pay_amt    WEB_FIN_RPROLLCLMCUSTOMER.n_Get_Prm%TYPE;

    v_min_amt       web_pay_seemoney_config.n_min_amt%TYPE;
    v_max_amt       web_pay_seemoney_config.n_max_amt%TYPE;
    v_dpt_level     web_pay_seemoney_config.c_dpt_level%TYPE;
    v_clm_dpt_level web_pay_seemoney_config.c_dpt_level%TYPE;

    v_dpt_cde web_fin_clm_due.c_dpt_cde%TYPE;

  BEGIN
    v_succsflag := 0;
    /*
    *   1 ??   Check
    *   2 ??   UndoCheck
    *   3 ??   SEND
    *   4 ??   RECV
    */
    if v_type = 'Check' then
      /*??*/
      UPDATE WEB_FIN_RPROLLCLMCUSTOMER
         SET C_BALA_MRK     = '4',
             C_CHECK_CDE    = v_emp_cde,
             T_CHECK_TM     = sysdate,
             T_UPDATE_TM    = sysdate
       WHERE C_RCPT_NO = v_rcpt_no
         and C_BALA_MRK <> '5';
    elsif v_type = 'UndoCheck' then
      /*??*/
      UPDATE WEB_FIN_RPROLLCLMCUSTOMER
         SET C_BALA_MRK         = '0',
             C_CHECK_CDE        = v_emp_cde,
             T_CHECK_TM         = sysdate,
             T_UPDATE_TM        = sysdate,
             c_recv_bank_reason = v_overrule_mind
       WHERE C_RCPT_NO = v_rcpt_no
         and C_BALA_MRK <> '5';
    elsif v_type = 'SEND' then
      /*??*/
      UPDATE WEB_FIN_RPROLLCLMCUSTOMER
         SET C_BALA_MRK      = '5',
             c_send_bank_cde = v_emp_cde,
             t_send_bank_tm  = sysdate,
             T_UPDATE_TM     = sysdate
       WHERE C_RCPT_NO = v_rcpt_no
         and C_BALA_MRK <> '5';
    elsif v_type = 'RECV' then
      /*??*/
      if v_overrule_mind = '????' then
        UPDATE WEB_FIN_RPROLLCLMCUSTOMER
           SET C_BALA_MRK         = '6',
               c_recv_bank_cde    = v_emp_cde,
               t_recv_bank_tm     = sysdate,
               T_UPDATE_TM        = sysdate,
               c_recv_bank_reason = v_overrule_mind
         WHERE C_RCPT_NO = v_rcpt_no;
      else
        UPDATE WEB_FIN_RPROLLCLMCUSTOMER
           SET C_BALA_MRK         = '0',
               c_recv_bank_cde    = v_emp_cde,
               t_recv_bank_tm     = sysdate,
               T_UPDATE_TM        = sysdate,
               c_recv_bank_reason = v_overrule_mind
         WHERE C_RCPT_NO = v_rcpt_no;
      end if;
    end if;
    v_succsflag := 0;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        v_succsflag := -9;
        RETURN;
      END;
  END;
end ClmUnify;
/
