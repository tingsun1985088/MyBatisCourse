CREATE PACKAGE "PACCFUNC" is


  procedure crtedrpayrcd(edrtyp in varchar,
                         /* d(??) n(??) s(???) y(??) k(???) c(???)g(???) t(????) p(?????)*/
                         v_edr_no      in web_edr_base.c_edr_no%type, /* ????    */
                         v_ply_no      in web_ply_base.c_ply_no%type, /* ???       */
                         v_crt_cde     in web_fin_pay_due.c_crt_cde%type, /* ???   */
                         v_pay_mde_cde in web_fin_pay_due.c_pay_mde_cde%type, /* ???? */
                         --v_paid_amt   in out web_fin_pay_due.n_paid_amt%type, /* ???? */
                         v_rcpt_no in out web_fin_pay_due.c_rcpt_no%type, /* ???   */
                         v_succsflag in out number);
/*
v_succsflag:
	0	??
	-1 	????????????
*/


end paccfunc;










/
