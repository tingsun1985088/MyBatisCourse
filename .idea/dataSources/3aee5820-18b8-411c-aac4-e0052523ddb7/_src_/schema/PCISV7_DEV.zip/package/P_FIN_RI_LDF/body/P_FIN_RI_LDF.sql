CREATE package body P_FIN_RI_LDF is
 v_err_content               web_bas_fin_errorlog.c_err_content%TYPE;--日志错误信息
v_Sqlcode                   Number;
v_Sqlerrm                   Varchar2(600);
v_inwd_mrk                  varchar2(10);
v_srs_case_mrk              varchar2(10);
v_got_prm                   number(20,2);
v_accnt_tm                  date;
v_insrc_cde                 Varchar2(10);
v_dpt_cde                   Varchar2(10);
v_kind_no                   Varchar2(10);
v_prod_no                   Varchar2(10);
v_year                      Varchar2(4);
v_quart                     Varchar2(2);
v_000                       number(20,2);
v_001                       number(20,2);
v_002                       number(20,2);
v_003                       number(20,2);
v_004                       number(20,2);
v_005                       number(20,2);
v_006                       number(20,2);
v_007                       number(20,2);
v_008                       number(20,2);
v_009                       number(20,2);
v_010                       number(20,2);
v_011                       number(20,2);
v_012                       number(20,2);
v_013                       number(20,2);
v_014                       number(20,2);
v_015                       number(20,2);
v_016                       number(20,2);
v_017                       number(20,2);
v_018                       number(20,2);
v_019                       number(20,2);
v_020                       number(20,2);
v_021                       number(20,2);
v_022                       number(20,2);
v_023                       number(20,2);
v_024                        number(20,2);
v_025                        number(20,2);
v_026                        number(20,2);
v_027                        number(20,2);
v_028                        number(20,2);
v_029                        number(20,2);
v_030                        number(20,2);
v_031                        number(20,2);
v_032                        number(20,2);
v_033                        number(20,2);
v_034                        number(20,2);
v_035                        number(20,2);
v_036                        number(20,2);
v_037                        number(20,2);
v_038                        number(20,2);
v_039                        number(20,2);
v_040                        number(20,2);
v_041                        number(20,2);
v_042                        number(20,2);
v_043                        number(20,2);
v_044                        number(20,2);
v_045                        number(20,2);
v_046                        number(20,2);
v_047                        number(20,2);
v_048                        number(20,2);
v_049                        number(20,2);
v_050                        number(20,2);
v_051                        number(20,2);
v_052                        number(20,2);
v_053                        number(20,2);
v_054                        number(20,2);
v_055                        number(20,2);
v_056                        number(20,2);
v_057                        number(20,2);
v_058                        number(20,2);
v_059                        number(20,2);
v_060                        number(20,2);
v_061                        number(20,2);
v_062                        number(20,2);
v_063                        number(20,2);
v_064                        number(20,2);
v_065                        number(20,2);
v_066                        number(20,2);
v_067                         number(20,2);
v_068                         number(20,2);
v_069                         number(20,2);
v_070                         number(20,2);
v_071                         number(20,2);
v_072                         number(20,2);
v_ldf_000                       number(20,6);
v_ldf_001                       number(20,6);
v_ldf_002                       number(20,6);
v_ldf_003                       number(20,6);
v_ldf_004                       number(20,6);
v_ldf_005                       number(20,6);
v_ldf_006                       number(20,6);
v_ldf_007                       number(20,6);
v_ldf_008                       number(20,6);
v_ldf_009                       number(20,6);
v_ldf_010                       number(20,6);
v_ldf_011                       number(20,6);
v_ldf_012                       number(20,6);
v_ldf_013                       number(20,6);
v_ldf_014                       number(20,6);
v_ldf_015                       number(20,6);
v_ldf_016                       number(20,6);
v_ldf_017                       number(20,6);
v_ldf_018                       number(20,6);
v_ldf_019                       number(20,6);
v_ldf_020                       number(20,6);
v_ldf_021                       number(20,6);
v_ldf_022                       number(20,6);
v_ldf_023                       number(20,6);
v_ldf_024                        number(20,6);
v_ldf_025                        number(20,6);
v_ldf_026                        number(20,6);
v_ldf_027                        number(20,6);
v_ldf_028                        number(20,6);
v_ldf_029                        number(20,6);
v_ldf_030                        number(20,6);
v_ldf_031                        number(20,6);
v_ldf_032                        number(20,6);
v_ldf_033                        number(20,6);
v_ldf_034                        number(20,6);
v_ldf_035                        number(20,6);
v_ldf_036                        number(20,6);
v_ldf_037                        number(20,6);
v_ldf_038                        number(20,6);
v_ldf_039                        number(20,6);
v_ldf_040                        number(20,6);
v_ldf_041                        number(20,6);
v_ldf_042                        number(20,6);
v_ldf_043                        number(20,6);
v_ldf_044                        number(20,6);
v_ldf_045                        number(20,6);
v_ldf_046                        number(20,6);
v_ldf_047                        number(20,6);
v_ldf_048                        number(20,6);
v_ldf_049                        number(20,6);
v_ldf_050                        number(20,6);
v_ldf_051                        number(20,6);
v_ldf_052                        number(20,6);
v_ldf_053                        number(20,6);
v_ldf_054                        number(20,6);
v_ldf_055                        number(20,6);
v_ldf_056                        number(20,6);
v_ldf_057                        number(20,6);
v_ldf_058                        number(20,6);
v_ldf_059                        number(20,6);
v_ldf_060                        number(20,6);
v_ldf_061                        number(20,6);
v_ldf_062                        number(20,6);
v_ldf_063                        number(20,6);
v_ldf_064                        number(20,6);
v_ldf_065                        number(20,6);
v_ldf_066                        number(20,6);
v_ldf_067                         number(20,6);
v_ldf_068                         number(20,6);
v_ldf_069                         number(20,6);
v_ldf_070                         number(20,6);
v_ldf_071                         number(20,6);
v_ldf_072                         number(20,6);
v_today                           date;
v_num                             number(5);
V_PK_ID                           VARCHAR2(50);
 procedure P_Fin_Ri_Amt_Ldf(today     varchar2,
                            v_cal_type  in char,
                            v_return    out varchar2)
--已决赔款进展因子(季度)
is
cursor cur_clm is

 select a.c_kind_no,decode(a.c_prod_no,'0320','0320','---'),a.n_got_prm,
        a.n_000, a.n_001, a.n_002, a.n_003, a.n_004, a.n_005, a.n_006, a.n_007,
        a.n_008, a.n_009, a.n_010, a.n_011, a.n_012, a.n_013, a.n_014, a.n_015,
        a.n_016, a.n_017, a.n_018, a.n_019, a.n_020, a.n_021, a.n_022, a.n_023,
        a.n_024, a.n_025, a.n_026, a.n_027, a.n_028, a.n_029, a.n_030, a.n_031,
        a.n_032, a.n_033, a.n_034, a.n_035, a.n_036, a.n_037, a.n_038, a.n_039,
        a.n_040, a.n_041, a.n_042, a.n_043, a.n_044, a.n_045, a.n_046, a.n_047,
        a.n_048, a.n_049, a.n_050, a.n_051, a.n_052, a.n_053, a.n_054, a.n_055,
        a.n_056, a.n_057, a.n_058, a.n_059, a.n_060, a.n_061, a.n_062, a.n_063,
        a.n_064, a.n_065, a.n_066, a.n_067, a.n_068, a.n_069, a.n_070, a.n_071,
        a.n_072, a.c_year, a.c_quart
   from web_fin_ri_amt a where a.t_cal_tm = v_today;

begin
   v_return:='1';
   v_today:=to_date(today,'yyyy-mm-dd');
   --EXECUTE IMMEDIATE 'DELETE FROM WEB_FIN_RI_LDF WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
   delete from WEB_FIN_RI_LDF a where a.t_cal_tm = v_today and a.c_mrk = '2' and a.c_type = '1';
   commit;
   v_num:=9999;
     open cur_clm;
       loop
            fetch cur_clm
              into v_kind_no,v_prod_no,v_got_prm,--v_insrc_cde,v_dpt_cde,v_inwd_mrk,v_srs_case_mrk,
                  v_000 ,v_001 ,v_002 ,v_003 ,v_004 ,v_005 ,v_006 ,v_007 ,v_008 ,v_009 ,
                  v_010 ,v_011 ,v_012 ,v_013 ,v_014 ,v_015 ,v_016 ,v_017 ,v_018 ,v_019 ,
                  v_020 ,v_021 ,v_022 ,v_023 ,v_024 ,v_025 ,v_026 ,v_027 ,v_028 ,v_029 ,
                  v_030 ,v_031 ,v_032 ,v_033 ,v_034 ,v_035 ,v_036 ,v_037 ,v_038 ,v_039 ,
                  v_040 ,v_041 ,v_042 ,v_043 ,v_044 ,v_045 ,v_046 ,v_047 ,v_048 ,v_049 ,
                  v_050 ,v_051 ,v_052 ,v_053 ,v_054 ,v_055 ,v_056 ,v_057 ,v_058 ,v_059 ,
                  v_060 ,v_061 ,v_062 ,v_063 ,v_064 ,v_065 ,v_066 ,v_067 ,v_068 ,v_069 ,
                  v_070 ,v_071 ,v_072,v_year,v_quart;
            exit when cur_clm%notfound;
          V_PK_ID:=sys_guid();
          v_ldf_000:=0;

             v_ldf_001:=case when v_000 = 0 and v_001 <>0 then v_num when v_001 = 0 and v_000 = 0  then 1 else v_001/v_000 end;
             v_ldf_002:=case when v_001 = 0 and v_002 <>0 then v_num when v_002 = 0 and v_001 = 0  then 1 else v_002/v_001 end;
             v_ldf_003:=case when v_002 = 0 and v_003 <>0 then v_num when v_003 = 0 and v_002 = 0  then 1 else v_003/v_002 end;
             v_ldf_004:=case when v_003 = 0 and v_004 <>0 then v_num when v_004 = 0 and v_003 = 0  then 1 else v_004/v_003 end;
             v_ldf_005:=case when v_004 = 0 and v_005 <>0 then v_num when v_005 = 0 and v_004 = 0  then 1 else v_005/v_004 end;
             v_ldf_006:=case when v_005 = 0 and v_006 <>0 then v_num when v_006 = 0 and v_005 = 0  then 1 else v_006/v_005 end;
             v_ldf_007:=case when v_006 = 0 and v_007 <>0 then v_num when v_007 = 0 and v_006 = 0  then 1 else v_007/v_006 end;
             v_ldf_008:=case when v_007 = 0 and v_008 <>0 then v_num when v_008 = 0 and v_007 = 0  then 1 else v_008/v_007 end;
             v_ldf_009:=case when v_008 = 0 and v_009 <>0 then v_num when v_009 = 0 and v_008 = 0  then 1 else v_009/v_008 end;
             v_ldf_010:=case when v_009 = 0 and v_010 <>0 then v_num when v_010 = 0 and v_009 = 0  then 1 else v_010/v_009 end;
             v_ldf_011:=case when v_010 = 0 and v_011 <>0 then v_num when v_011 = 0 and v_010 = 0  then 1 else v_011/v_010 end;
             v_ldf_012:=case when v_011 = 0 and v_012 <>0 then v_num when v_012 = 0 and v_011 = 0  then 1 else v_012/v_011 end;
             v_ldf_013:=case when v_012 = 0 and v_013 <>0 then v_num when v_013 = 0 and v_012 = 0  then 1 else v_013/v_012 end;
             v_ldf_014:=case when v_013 = 0 and v_014 <>0 then v_num when v_014 = 0 and v_013 = 0  then 1 else v_014/v_013 end;
             v_ldf_015:=case when v_014 = 0 and v_015 <>0 then v_num when v_015 = 0 and v_014 = 0  then 1 else v_015/v_014 end;
             v_ldf_016:=case when v_015 = 0 and v_016 <>0 then v_num when v_016 = 0 and v_015 = 0  then 1 else v_016/v_015 end;
             v_ldf_017:=case when v_016 = 0 and v_017 <>0 then v_num when v_017 = 0 and v_016 = 0  then 1 else v_017/v_016 end;
             v_ldf_018:=case when v_017 = 0 and v_018 <>0 then v_num when v_018 = 0 and v_017 = 0  then 1 else v_018/v_017 end;
             v_ldf_019:=case when v_018 = 0 and v_019 <>0 then v_num when v_019 = 0 and v_018 = 0  then 1 else v_019/v_018 end;
             v_ldf_020:=case when v_019 = 0 and v_020 <>0 then v_num when v_020 = 0 and v_019 = 0  then 1 else v_020/v_019 end;
             v_ldf_021:=case when v_020 = 0 and v_021 <>0 then v_num when v_021 = 0 and v_020 = 0  then 1 else v_021/v_020 end;
             v_ldf_022:=case when v_021 = 0 and v_022 <>0 then v_num when v_022 = 0 and v_021 = 0  then 1 else v_022/v_021 end;
             v_ldf_023:=case when v_022 = 0 and v_023 <>0 then v_num when v_023 = 0 and v_022 = 0  then 1 else v_023/v_022 end;
             v_ldf_024:=case when v_023 = 0 and v_024 <>0 then v_num when v_024 = 0 and v_023 = 0  then 1 else v_024/v_023 end;
             v_ldf_025:=case when v_024 = 0 and v_025 <>0 then v_num when v_025 = 0 and v_024 = 0  then 1 else v_025/v_024 end;
             v_ldf_026:=case when v_025 = 0 and v_026 <>0 then v_num when v_026 = 0 and v_025 = 0  then 1 else v_026/v_025 end;
             v_ldf_027:=case when v_026 = 0 and v_027 <>0 then v_num when v_027 = 0 and v_026 = 0  then 1 else v_027/v_026 end;
             v_ldf_028:=case when v_027 = 0 and v_028 <>0 then v_num when v_028 = 0 and v_027 = 0  then 1 else v_028/v_027 end;
             v_ldf_029:=case when v_028 = 0 and v_029 <>0 then v_num when v_029 = 0 and v_028 = 0  then 1 else v_029/v_028 end;
             v_ldf_030:=case when v_029 = 0 and v_030 <>0 then v_num when v_030 = 0 and v_029 = 0  then 1 else v_030/v_029 end;
             v_ldf_031:=case when v_030 = 0 and v_031 <>0 then v_num when v_031 = 0 and v_030 = 0  then 1 else v_031/v_030 end;
             v_ldf_032:=case when v_031 = 0 and v_032 <>0 then v_num when v_032 = 0 and v_031 = 0  then 1 else v_032/v_031 end;
             v_ldf_033:=case when v_032 = 0 and v_033 <>0 then v_num when v_033 = 0 and v_032 = 0  then 1 else v_033/v_032 end;
             v_ldf_034:=case when v_033 = 0 and v_034 <>0 then v_num when v_034 = 0 and v_033 = 0  then 1 else v_034/v_033 end;
             v_ldf_035:=case when v_034 = 0 and v_035 <>0 then v_num when v_035 = 0 and v_034 = 0  then 1 else v_035/v_034 end;
             v_ldf_036:=case when v_035 = 0 and v_036 <>0 then v_num when v_036 = 0 and v_035 = 0  then 1 else v_036/v_035 end;
             v_ldf_037:=case when v_036 = 0 and v_037 <>0 then v_num when v_037 = 0 and v_036 = 0  then 1 else v_037/v_036 end;
             v_ldf_038:=case when v_037 = 0 and v_038 <>0 then v_num when v_038 = 0 and v_037 = 0  then 1 else v_038/v_037 end;
             v_ldf_039:=case when v_038 = 0 and v_039 <>0 then v_num when v_039 = 0 and v_038 = 0  then 1 else v_039/v_038 end;
             v_ldf_040:=case when v_039 = 0 and v_040 <>0 then v_num when v_040 = 0 and v_039 = 0  then 1 else v_040/v_039 end;
             v_ldf_041:=case when v_040 = 0 and v_041 <>0 then v_num when v_041 = 0 and v_040 = 0  then 1 else v_041/v_040 end;
             v_ldf_042:=case when v_041 = 0 and v_042 <>0 then v_num when v_042 = 0 and v_041 = 0  then 1 else v_042/v_041 end;
             v_ldf_043:=case when v_042 = 0 and v_043 <>0 then v_num when v_043 = 0 and v_042 = 0  then 1 else v_043/v_042 end;
             v_ldf_044:=case when v_043 = 0 and v_044 <>0 then v_num when v_044 = 0 and v_043 = 0  then 1 else v_044/v_043 end;
             v_ldf_045:=case when v_044 = 0 and v_045 <>0 then v_num when v_045 = 0 and v_044 = 0  then 1 else v_045/v_044 end;
             v_ldf_046:=case when v_045 = 0 and v_046 <>0 then v_num when v_046 = 0 and v_045 = 0  then 1 else v_046/v_045 end;
             v_ldf_047:=case when v_046 = 0 and v_047 <>0 then v_num when v_047 = 0 and v_046 = 0  then 1 else v_047/v_046 end;
             v_ldf_048:=case when v_047 = 0 and v_048 <>0 then v_num when v_048 = 0 and v_047 = 0  then 1 else v_048/v_047 end;
             v_ldf_049:=case when v_048 = 0 and v_049 <>0 then v_num when v_049 = 0 and v_048 = 0  then 1 else v_049/v_048 end;
             v_ldf_050:=case when v_049 = 0 and v_050 <>0 then v_num when v_050 = 0 and v_049 = 0  then 1 else v_050/v_049 end;
             v_ldf_051:=case when v_050 = 0 and v_051 <>0 then v_num when v_051 = 0 and v_050 = 0  then 1 else v_051/v_050 end;
             v_ldf_052:=case when v_051 = 0 and v_052 <>0 then v_num when v_052 = 0 and v_051 = 0  then 1 else v_052/v_051 end;
             v_ldf_053:=case when v_052 = 0 and v_053 <>0 then v_num when v_053 = 0 and v_052 = 0  then 1 else v_053/v_052 end;
             v_ldf_054:=case when v_053 = 0 and v_054 <>0 then v_num when v_054 = 0 and v_053 = 0  then 1 else v_054/v_053 end;
             v_ldf_055:=case when v_054 = 0 and v_055 <>0 then v_num when v_055 = 0 and v_054 = 0  then 1 else v_055/v_054 end;
             v_ldf_056:=case when v_055 = 0 and v_056 <>0 then v_num when v_056 = 0 and v_055 = 0  then 1 else v_056/v_055 end;
             v_ldf_057:=case when v_056 = 0 and v_057 <>0 then v_num when v_057 = 0 and v_056 = 0  then 1 else v_057/v_056 end;
             v_ldf_058:=case when v_057 = 0 and v_058 <>0 then v_num when v_058 = 0 and v_057 = 0  then 1 else v_058/v_057 end;
             v_ldf_059:=case when v_058 = 0 and v_059 <>0 then v_num when v_059 = 0 and v_058 = 0  then 1 else v_059/v_058 end;
             v_ldf_060:=case when v_059 = 0 and v_060 <>0 then v_num when v_060 = 0 and v_059 = 0  then 1 else v_060/v_059 end;
             v_ldf_061:=case when v_060 = 0 and v_061 <>0 then v_num when v_061 = 0 and v_060 = 0  then 1 else v_061/v_060 end;
             v_ldf_062:=case when v_061 = 0 and v_062 <>0 then v_num when v_062 = 0 and v_061 = 0  then 1 else v_062/v_061 end;
             v_ldf_063:=case when v_062 = 0 and v_063 <>0 then v_num when v_063 = 0 and v_062 = 0  then 1 else v_063/v_062 end;
             v_ldf_064:=case when v_063 = 0 and v_064 <>0 then v_num when v_064 = 0 and v_063 = 0  then 1 else v_064/v_063 end;
             v_ldf_065:=case when v_064 = 0 and v_065 <>0 then v_num when v_065 = 0 and v_064 = 0  then 1 else v_065/v_064 end;
             v_ldf_066:=case when v_065 = 0 and v_066 <>0 then v_num when v_066 = 0 and v_065 = 0  then 1 else v_066/v_065 end;
             v_ldf_067:=case when v_066 = 0 and v_067 <>0 then v_num when v_067 = 0 and v_066 = 0  then 1 else v_067/v_066 end;
             v_ldf_068:=case when v_067 = 0 and v_068 <>0 then v_num when v_068 = 0 and v_067 = 0  then 1 else v_068/v_067 end;
             v_ldf_069:=case when v_068 = 0 and v_069 <>0 then v_num when v_069 = 0 and v_068 = 0  then 1 else v_069/v_068 end;
             v_ldf_070:=case when v_069 = 0 and v_070 <>0 then v_num when v_070 = 0 and v_069 = 0  then 1 else v_070/v_069 end;
             v_ldf_071:=case when v_070 = 0 and v_071 <>0 then v_num when v_071 = 0 and v_070 = 0  then 1 else v_071/v_070 end;
             v_ldf_072:=case when v_071 = 0 and v_072 <>0 then v_num when v_072 = 0 and v_071 = 0  then 1 else v_072/v_071 end;
             
          insert into WEB_FIN_RI_LDF(
            t_crt_tm,t_upd_tm,c_kind_no,c_prod_no,c_insrnc_cde,c_dpt_cde,c_inwd_mrk,c_srs_case_mrk,n_got_prm,
            n_000 ,n_001 ,n_002 ,n_003 ,n_004 ,n_005 ,n_006 ,n_007 ,n_008 ,n_009 ,
            n_010 ,n_011 ,n_012 ,n_013 ,n_014 ,n_015 ,n_016 ,n_017 ,n_018 ,n_019 ,
            n_020 ,n_021 ,n_022 ,n_023 ,n_024 ,n_025 ,n_026 ,n_027 ,n_028 ,n_029 ,
            n_030 ,n_031 ,n_032 ,n_033 ,n_034 ,n_035 ,n_036 ,n_037 ,n_038 ,n_039 ,
            n_040 ,n_041 ,n_042 ,n_043 ,n_044 ,n_045 ,n_046 ,n_047 ,n_048 ,n_049 ,
            n_050 ,n_051 ,n_052 ,n_053 ,n_054 ,n_055 ,n_056 ,n_057 ,n_058 ,n_059 ,
            n_060 ,n_061 ,n_062 ,n_063 ,n_064 ,n_065 ,n_066 ,n_067 ,n_068 ,n_069 ,
            n_070 ,n_071 ,n_072 ,t_cal_tm, c_year, C_QUART,  C_MRK ,C_TYPE,c_pk_id)
          values(
            sysdate,sysdate,v_kind_no,v_prod_no,v_insrc_cde,v_dpt_cde,v_inwd_mrk,v_srs_case_mrk,v_got_prm,
            v_ldf_000 ,v_ldf_001 ,v_ldf_002 ,v_ldf_003 ,v_ldf_004 ,v_ldf_005 ,v_ldf_006 ,v_ldf_007 ,v_ldf_008 ,v_ldf_009 ,
            v_ldf_010 ,v_ldf_011 ,v_ldf_012 ,v_ldf_013 ,v_ldf_014 ,v_ldf_015 ,v_ldf_016 ,v_ldf_017 ,v_ldf_018 ,v_ldf_019 ,
            v_ldf_020 ,v_ldf_021 ,v_ldf_022 ,v_ldf_023 ,v_ldf_024 ,v_ldf_025 ,v_ldf_026 ,v_ldf_027 ,v_ldf_028 ,v_ldf_029 ,
            v_ldf_030 ,v_ldf_031 ,v_ldf_032 ,v_ldf_033 ,v_ldf_034 ,v_ldf_035 ,v_ldf_036 ,v_ldf_037 ,v_ldf_038 ,v_ldf_039 ,
            v_ldf_040 ,v_ldf_041 ,v_ldf_042 ,v_ldf_043 ,v_ldf_044 ,v_ldf_045 ,v_ldf_046 ,v_ldf_047 ,v_ldf_048 ,v_ldf_049 ,
            v_ldf_050 ,v_ldf_051 ,v_ldf_052 ,v_ldf_053 ,v_ldf_054 ,v_ldf_055 ,v_ldf_056 ,v_ldf_057 ,v_ldf_058 ,v_ldf_059 ,
            v_ldf_060 ,v_ldf_061 ,v_ldf_062 ,v_ldf_063 ,v_ldf_064 ,v_ldf_065 ,v_ldf_066 ,v_ldf_067 ,v_ldf_068 ,v_ldf_069 ,
            v_ldf_070 ,v_ldf_071 ,v_ldf_072 ,v_today   ,v_year,   v_quart    ,'2','1',v_pk_id
            );
      end loop;
   close cur_clm;
  commit;

  exception
  When Others Then
    Rollback;
    v_Sqlcode := Sqlcode;
    v_Sqlerrm := Substr(Sqlerrm, 1, 600);
  ROLLBACK;

  v_err_content:='proc:[P_Fin_ri_Amt_Ldf],出错流水号:['||v_today||'],错误描述：['||SQLCODE||SQLERRM;
  insert into web_bas_fin_errorlog
  (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
  VALUES('007','001','0000', v_err_content,SYSDATE);
  COMMIT;
  v_return := -1;
end P_Fin_ri_Amt_Ldf;

procedure P_Fin_ri_Report_Ldf(today     varchar2,
                              v_cal_type  in char,
                              v_return    out varchar2)
--已决赔款进展因子(季度)
is
cursor cur_clm is
 select a.c_kind_no,decode(a.c_prod_no,'0320','0320','---'),a.n_got_prm,
        a.n_000, a.n_001, a.n_002, a.n_003, a.n_004, a.n_005, a.n_006, a.n_007,
        a.n_008, a.n_009, a.n_010, a.n_011, a.n_012, a.n_013, a.n_014, a.n_015,
        a.n_016, a.n_017, a.n_018, a.n_019, a.n_020, a.n_021, a.n_022, a.n_023,
        a.n_024, a.n_025, a.n_026, a.n_027, a.n_028, a.n_029, a.n_030, a.n_031,
        a.n_032, a.n_033, a.n_034, a.n_035, a.n_036, a.n_037, a.n_038, a.n_039,
        a.n_040, a.n_041, a.n_042, a.n_043, a.n_044, a.n_045, a.n_046, a.n_047,
        a.n_048, a.n_049, a.n_050, a.n_051, a.n_052, a.n_053, a.n_054, a.n_055,
        a.n_056, a.n_057, a.n_058, a.n_059, a.n_060, a.n_061, a.n_062, a.n_063,
        a.n_064, a.n_065, a.n_066, a.n_067, a.n_068, a.n_069, a.n_070, a.n_071,
        a.n_072, a.c_year, a.c_quart
   from web_fin_ri_report a where a.t_cal_tm = v_today;

begin
   v_return:='1';
   v_today:=to_date(today,'yyyy-mm-dd');
   delete from WEB_FIN_RI_LDF a where a.t_cal_tm = v_today and a.c_mrk = '2' and a.c_type = '2';
   commit;
   v_num:=9999;
     open cur_clm;
       loop
            fetch cur_clm
              into v_kind_no,v_prod_no,v_got_prm,--v_insrc_cde,v_dpt_cde,v_inwd_mrk,v_srs_case_mrk,
                  v_000 ,v_001 ,v_002 ,v_003 ,v_004 ,v_005 ,v_006 ,v_007 ,v_008 ,v_009 ,
                  v_010 ,v_011 ,v_012 ,v_013 ,v_014 ,v_015 ,v_016 ,v_017 ,v_018 ,v_019 ,
                  v_020 ,v_021 ,v_022 ,v_023 ,v_024 ,v_025 ,v_026 ,v_027 ,v_028 ,v_029 ,
                  v_030 ,v_031 ,v_032 ,v_033 ,v_034 ,v_035 ,v_036 ,v_037 ,v_038 ,v_039 ,
                  v_040 ,v_041 ,v_042 ,v_043 ,v_044 ,v_045 ,v_046 ,v_047 ,v_048 ,v_049 ,
                  v_050 ,v_051 ,v_052 ,v_053 ,v_054 ,v_055 ,v_056 ,v_057 ,v_058 ,v_059 ,
                  v_060 ,v_061 ,v_062 ,v_063 ,v_064 ,v_065 ,v_066 ,v_067 ,v_068 ,v_069 ,
                  v_070 ,v_071 ,v_072,v_year,v_quart;
            exit when cur_clm%notfound;
          V_PK_ID:=sys_guid();
          v_ldf_000:=0;
          
             v_ldf_001:=case when v_000 = 0 and v_001 <>0 then v_num when v_001 = 0 and v_000 = 0  then 1 else v_001/v_000 end;
             v_ldf_002:=case when v_001 = 0 and v_002 <>0 then v_num when v_002 = 0 and v_001 = 0  then 1 else v_002/v_001 end;
             v_ldf_003:=case when v_002 = 0 and v_003 <>0 then v_num when v_003 = 0 and v_002 = 0  then 1 else v_003/v_002 end;
             v_ldf_004:=case when v_003 = 0 and v_004 <>0 then v_num when v_004 = 0 and v_003 = 0  then 1 else v_004/v_003 end;
             v_ldf_005:=case when v_004 = 0 and v_005 <>0 then v_num when v_005 = 0 and v_004 = 0  then 1 else v_005/v_004 end;
             v_ldf_006:=case when v_005 = 0 and v_006 <>0 then v_num when v_006 = 0 and v_005 = 0  then 1 else v_006/v_005 end;
             v_ldf_007:=case when v_006 = 0 and v_007 <>0 then v_num when v_007 = 0 and v_006 = 0  then 1 else v_007/v_006 end;
             v_ldf_008:=case when v_007 = 0 and v_008 <>0 then v_num when v_008 = 0 and v_007 = 0  then 1 else v_008/v_007 end;
             v_ldf_009:=case when v_008 = 0 and v_009 <>0 then v_num when v_009 = 0 and v_008 = 0  then 1 else v_009/v_008 end;
             v_ldf_010:=case when v_009 = 0 and v_010 <>0 then v_num when v_010 = 0 and v_009 = 0  then 1 else v_010/v_009 end;
             v_ldf_011:=case when v_010 = 0 and v_011 <>0 then v_num when v_011 = 0 and v_010 = 0  then 1 else v_011/v_010 end;
             v_ldf_012:=case when v_011 = 0 and v_012 <>0 then v_num when v_012 = 0 and v_011 = 0  then 1 else v_012/v_011 end;
             v_ldf_013:=case when v_012 = 0 and v_013 <>0 then v_num when v_013 = 0 and v_012 = 0  then 1 else v_013/v_012 end;
             v_ldf_014:=case when v_013 = 0 and v_014 <>0 then v_num when v_014 = 0 and v_013 = 0  then 1 else v_014/v_013 end;
             v_ldf_015:=case when v_014 = 0 and v_015 <>0 then v_num when v_015 = 0 and v_014 = 0  then 1 else v_015/v_014 end;
             v_ldf_016:=case when v_015 = 0 and v_016 <>0 then v_num when v_016 = 0 and v_015 = 0  then 1 else v_016/v_015 end;
             v_ldf_017:=case when v_016 = 0 and v_017 <>0 then v_num when v_017 = 0 and v_016 = 0  then 1 else v_017/v_016 end;
             v_ldf_018:=case when v_017 = 0 and v_018 <>0 then v_num when v_018 = 0 and v_017 = 0  then 1 else v_018/v_017 end;
             v_ldf_019:=case when v_018 = 0 and v_019 <>0 then v_num when v_019 = 0 and v_018 = 0  then 1 else v_019/v_018 end;
             v_ldf_020:=case when v_019 = 0 and v_020 <>0 then v_num when v_020 = 0 and v_019 = 0  then 1 else v_020/v_019 end;
             v_ldf_021:=case when v_020 = 0 and v_021 <>0 then v_num when v_021 = 0 and v_020 = 0  then 1 else v_021/v_020 end;
             v_ldf_022:=case when v_021 = 0 and v_022 <>0 then v_num when v_022 = 0 and v_021 = 0  then 1 else v_022/v_021 end;
             v_ldf_023:=case when v_022 = 0 and v_023 <>0 then v_num when v_023 = 0 and v_022 = 0  then 1 else v_023/v_022 end;
             v_ldf_024:=case when v_023 = 0 and v_024 <>0 then v_num when v_024 = 0 and v_023 = 0  then 1 else v_024/v_023 end;
             v_ldf_025:=case when v_024 = 0 and v_025 <>0 then v_num when v_025 = 0 and v_024 = 0  then 1 else v_025/v_024 end;
             v_ldf_026:=case when v_025 = 0 and v_026 <>0 then v_num when v_026 = 0 and v_025 = 0  then 1 else v_026/v_025 end;
             v_ldf_027:=case when v_026 = 0 and v_027 <>0 then v_num when v_027 = 0 and v_026 = 0  then 1 else v_027/v_026 end;
             v_ldf_028:=case when v_027 = 0 and v_028 <>0 then v_num when v_028 = 0 and v_027 = 0  then 1 else v_028/v_027 end;
             v_ldf_029:=case when v_028 = 0 and v_029 <>0 then v_num when v_029 = 0 and v_028 = 0  then 1 else v_029/v_028 end;
             v_ldf_030:=case when v_029 = 0 and v_030 <>0 then v_num when v_030 = 0 and v_029 = 0  then 1 else v_030/v_029 end;
             v_ldf_031:=case when v_030 = 0 and v_031 <>0 then v_num when v_031 = 0 and v_030 = 0  then 1 else v_031/v_030 end;
             v_ldf_032:=case when v_031 = 0 and v_032 <>0 then v_num when v_032 = 0 and v_031 = 0  then 1 else v_032/v_031 end;
             v_ldf_033:=case when v_032 = 0 and v_033 <>0 then v_num when v_033 = 0 and v_032 = 0  then 1 else v_033/v_032 end;
             v_ldf_034:=case when v_033 = 0 and v_034 <>0 then v_num when v_034 = 0 and v_033 = 0  then 1 else v_034/v_033 end;
             v_ldf_035:=case when v_034 = 0 and v_035 <>0 then v_num when v_035 = 0 and v_034 = 0  then 1 else v_035/v_034 end;
             v_ldf_036:=case when v_035 = 0 and v_036 <>0 then v_num when v_036 = 0 and v_035 = 0  then 1 else v_036/v_035 end;
             v_ldf_037:=case when v_036 = 0 and v_037 <>0 then v_num when v_037 = 0 and v_036 = 0  then 1 else v_037/v_036 end;
             v_ldf_038:=case when v_037 = 0 and v_038 <>0 then v_num when v_038 = 0 and v_037 = 0  then 1 else v_038/v_037 end;
             v_ldf_039:=case when v_038 = 0 and v_039 <>0 then v_num when v_039 = 0 and v_038 = 0  then 1 else v_039/v_038 end;
             v_ldf_040:=case when v_039 = 0 and v_040 <>0 then v_num when v_040 = 0 and v_039 = 0  then 1 else v_040/v_039 end;
             v_ldf_041:=case when v_040 = 0 and v_041 <>0 then v_num when v_041 = 0 and v_040 = 0  then 1 else v_041/v_040 end;
             v_ldf_042:=case when v_041 = 0 and v_042 <>0 then v_num when v_042 = 0 and v_041 = 0  then 1 else v_042/v_041 end;
             v_ldf_043:=case when v_042 = 0 and v_043 <>0 then v_num when v_043 = 0 and v_042 = 0  then 1 else v_043/v_042 end;
             v_ldf_044:=case when v_043 = 0 and v_044 <>0 then v_num when v_044 = 0 and v_043 = 0  then 1 else v_044/v_043 end;
             v_ldf_045:=case when v_044 = 0 and v_045 <>0 then v_num when v_045 = 0 and v_044 = 0  then 1 else v_045/v_044 end;
             v_ldf_046:=case when v_045 = 0 and v_046 <>0 then v_num when v_046 = 0 and v_045 = 0  then 1 else v_046/v_045 end;
             v_ldf_047:=case when v_046 = 0 and v_047 <>0 then v_num when v_047 = 0 and v_046 = 0  then 1 else v_047/v_046 end;
             v_ldf_048:=case when v_047 = 0 and v_048 <>0 then v_num when v_048 = 0 and v_047 = 0  then 1 else v_048/v_047 end;
             v_ldf_049:=case when v_048 = 0 and v_049 <>0 then v_num when v_049 = 0 and v_048 = 0  then 1 else v_049/v_048 end;
             v_ldf_050:=case when v_049 = 0 and v_050 <>0 then v_num when v_050 = 0 and v_049 = 0  then 1 else v_050/v_049 end;
             v_ldf_051:=case when v_050 = 0 and v_051 <>0 then v_num when v_051 = 0 and v_050 = 0  then 1 else v_051/v_050 end;
             v_ldf_052:=case when v_051 = 0 and v_052 <>0 then v_num when v_052 = 0 and v_051 = 0  then 1 else v_052/v_051 end;
             v_ldf_053:=case when v_052 = 0 and v_053 <>0 then v_num when v_053 = 0 and v_052 = 0  then 1 else v_053/v_052 end;
             v_ldf_054:=case when v_053 = 0 and v_054 <>0 then v_num when v_054 = 0 and v_053 = 0  then 1 else v_054/v_053 end;
             v_ldf_055:=case when v_054 = 0 and v_055 <>0 then v_num when v_055 = 0 and v_054 = 0  then 1 else v_055/v_054 end;
             v_ldf_056:=case when v_055 = 0 and v_056 <>0 then v_num when v_056 = 0 and v_055 = 0  then 1 else v_056/v_055 end;
             v_ldf_057:=case when v_056 = 0 and v_057 <>0 then v_num when v_057 = 0 and v_056 = 0  then 1 else v_057/v_056 end;
             v_ldf_058:=case when v_057 = 0 and v_058 <>0 then v_num when v_058 = 0 and v_057 = 0  then 1 else v_058/v_057 end;
             v_ldf_059:=case when v_058 = 0 and v_059 <>0 then v_num when v_059 = 0 and v_058 = 0  then 1 else v_059/v_058 end;
             v_ldf_060:=case when v_059 = 0 and v_060 <>0 then v_num when v_060 = 0 and v_059 = 0  then 1 else v_060/v_059 end;
             v_ldf_061:=case when v_060 = 0 and v_061 <>0 then v_num when v_061 = 0 and v_060 = 0  then 1 else v_061/v_060 end;
             v_ldf_062:=case when v_061 = 0 and v_062 <>0 then v_num when v_062 = 0 and v_061 = 0  then 1 else v_062/v_061 end;
             v_ldf_063:=case when v_062 = 0 and v_063 <>0 then v_num when v_063 = 0 and v_062 = 0  then 1 else v_063/v_062 end;
             v_ldf_064:=case when v_063 = 0 and v_064 <>0 then v_num when v_064 = 0 and v_063 = 0  then 1 else v_064/v_063 end;
             v_ldf_065:=case when v_064 = 0 and v_065 <>0 then v_num when v_065 = 0 and v_064 = 0  then 1 else v_065/v_064 end;
             v_ldf_066:=case when v_065 = 0 and v_066 <>0 then v_num when v_066 = 0 and v_065 = 0  then 1 else v_066/v_065 end;
             v_ldf_067:=case when v_066 = 0 and v_067 <>0 then v_num when v_067 = 0 and v_066 = 0  then 1 else v_067/v_066 end;
             v_ldf_068:=case when v_067 = 0 and v_068 <>0 then v_num when v_068 = 0 and v_067 = 0  then 1 else v_068/v_067 end;
             v_ldf_069:=case when v_068 = 0 and v_069 <>0 then v_num when v_069 = 0 and v_068 = 0  then 1 else v_069/v_068 end;
             v_ldf_070:=case when v_069 = 0 and v_070 <>0 then v_num when v_070 = 0 and v_069 = 0  then 1 else v_070/v_069 end;
             v_ldf_071:=case when v_070 = 0 and v_071 <>0 then v_num when v_071 = 0 and v_070 = 0  then 1 else v_071/v_070 end;
             v_ldf_072:=case when v_071 = 0 and v_072 <>0 then v_num when v_072 = 0 and v_071 = 0  then 1 else v_072/v_071 end;
             
            insert into WEB_FIN_RI_LDF(
            t_crt_tm,t_upd_tm,c_kind_no,c_prod_no,c_insrnc_cde,c_dpt_cde,c_inwd_mrk,c_srs_case_mrk,n_got_prm,
            n_000 ,n_001 ,n_002 ,n_003 ,n_004 ,n_005 ,n_006 ,n_007 ,n_008 ,n_009 ,
            n_010 ,n_011 ,n_012 ,n_013 ,n_014 ,n_015 ,n_016 ,n_017 ,n_018 ,n_019 ,
            n_020 ,n_021 ,n_022 ,n_023 ,n_024 ,n_025 ,n_026 ,n_027 ,n_028 ,n_029 ,
            n_030 ,n_031 ,n_032 ,n_033 ,n_034 ,n_035 ,n_036 ,n_037 ,n_038 ,n_039 ,
            n_040 ,n_041 ,n_042 ,n_043 ,n_044 ,n_045 ,n_046 ,n_047 ,n_048 ,n_049 ,
            n_050 ,n_051 ,n_052 ,n_053 ,n_054 ,n_055 ,n_056 ,n_057 ,n_058 ,n_059 ,
            n_060 ,n_061 ,n_062 ,n_063 ,n_064 ,n_065 ,n_066 ,n_067 ,n_068 ,n_069 ,
            n_070 ,n_071 ,n_072 ,t_cal_tm, c_year, C_QUART,  C_MRK ,C_TYPE,c_pk_id)
          values(
            sysdate,sysdate,v_kind_no,v_prod_no,v_insrc_cde,v_dpt_cde,v_inwd_mrk,v_srs_case_mrk,v_got_prm,
            v_ldf_000 ,v_ldf_001 ,v_ldf_002 ,v_ldf_003 ,v_ldf_004 ,v_ldf_005 ,v_ldf_006 ,v_ldf_007 ,v_ldf_008 ,v_ldf_009 ,
            v_ldf_010 ,v_ldf_011 ,v_ldf_012 ,v_ldf_013 ,v_ldf_014 ,v_ldf_015 ,v_ldf_016 ,v_ldf_017 ,v_ldf_018 ,v_ldf_019 ,
            v_ldf_020 ,v_ldf_021 ,v_ldf_022 ,v_ldf_023 ,v_ldf_024 ,v_ldf_025 ,v_ldf_026 ,v_ldf_027 ,v_ldf_028 ,v_ldf_029 ,
            v_ldf_030 ,v_ldf_031 ,v_ldf_032 ,v_ldf_033 ,v_ldf_034 ,v_ldf_035 ,v_ldf_036 ,v_ldf_037 ,v_ldf_038 ,v_ldf_039 ,
            v_ldf_040 ,v_ldf_041 ,v_ldf_042 ,v_ldf_043 ,v_ldf_044 ,v_ldf_045 ,v_ldf_046 ,v_ldf_047 ,v_ldf_048 ,v_ldf_049 ,
            v_ldf_050 ,v_ldf_051 ,v_ldf_052 ,v_ldf_053 ,v_ldf_054 ,v_ldf_055 ,v_ldf_056 ,v_ldf_057 ,v_ldf_058 ,v_ldf_059 ,
            v_ldf_060 ,v_ldf_061 ,v_ldf_062 ,v_ldf_063 ,v_ldf_064 ,v_ldf_065 ,v_ldf_066 ,v_ldf_067 ,v_ldf_068 ,v_ldf_069 ,
            v_ldf_070 ,v_ldf_071 ,v_ldf_072 ,v_today   ,v_year,   v_quart    ,'2','2',v_pk_id
            );
            
      end loop;
   close cur_clm;
  commit;

  exception
  When Others Then
    Rollback;
    v_Sqlcode := Sqlcode;
    v_Sqlerrm := Substr(Sqlerrm, 1, 600);
  ROLLBACK;

  v_err_content:='proc:[P_Fin_RI_Report_Ldf],出错流水号:['||v_today||'],错误描述：['||SQLCODE||SQLERRM;
  insert into web_bas_fin_errorlog
  (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
  VALUES('007','001','0000', v_err_content,SYSDATE);
  COMMIT;
  v_return := -1;
end P_Fin_RI_Report_Ldf;
end P_FIN_RI_LDF;
/
