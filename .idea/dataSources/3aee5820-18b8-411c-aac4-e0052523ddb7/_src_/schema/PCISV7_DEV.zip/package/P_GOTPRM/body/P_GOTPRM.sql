CREATE package body p_gotprm is

 PROCEDURE P_Fin_Gotprm(v_today    IN VARCHAR2, --当前时间
                                            sDptCde    IN VARCHAR2, --机构编码
                                            v_cal_type IN CHAR, --手工 'm'-manual,自动 'a'-automatica'自动提取并传财务，'b'只提取准备金,'c'只传财务,'d' 冲回上期；
                                            v_return  OUT NUMBER
                                            ) IS
  --此存过只抽取满期保费(将满期和未到期分开) author shexiwan 2012-11-13
  --冲回上期数据已经全部放到rppre.finMadcrBackPre存过中
  --T_FIN_PLYEDR_COLDUE  在中意里是保批单业务接口表，和V6的 WEB_FIN_PRM_DUE 保费接口表对应
  v_dpt_cde              web_ply_base.c_dpt_cde%TYPE;--机构部门
  v_inward               web_ply_base.c_inwd_mrk%TYPE;--分入业务标志
  v_cur_no               web_ply_base.c_prm_cur%TYPE;--保费币种
  v_prod_no              web_ply_base.c_prod_no%TYPE;--产品代码，也称为险种，如0901
  v_ply_no               web_ply_base.c_ply_no%TYPE;--保单号
  v_edr_no               web_ply_base.c_edr_no%TYPE;--批单号
  v_sls_cde              web_ply_base.c_sls_cde%TYPE;--业务员代码
  v_bsns_typ             web_ply_base.c_bsns_typ%TYPE;--业务来源
  v_edr_type             web_ply_base.c_edr_type%TYPE;--批改类型
  v_coinsrnc_flg         web_ply_base.c_ci_mrk%TYPE;--共保标志
  v_tran_flag            WEB_FIN_PRM_DUE.c_Tran_Flag%type;--业务单据标志   自营-分入-共保
  v_insrnc_bgn_tm        web_ply_base.t_insrnc_bgn_tm%TYPE;--保险起期
  v_insrnc_end_tm        web_ply_base.t_insrnc_end_tm%TYPE;--保险止期
  v_salegrp_cde          web_ply_base.c_salegrp_cde%TYPE;--销售团队
  v_cal_amt                 NUMBER(16, 2); /*提取金额-法定*/
  v_act_amt                 NUMBER(16, 2); /*提取金额-会计*/
  v_bal_amt                 NUMBER(16, 2); /*提转金额*/
  v_past_cal_amt              NUMBER(16, 2); --以前提取的金额
  v_udr_date                 web_ply_base.t_udr_tm%TYPE;--核保日期
  v_ri_com                   web_ply_inwd.c_ced_com_cde%type;--分出公司
  v_info_type                CHAR(1);
  v_err_content              web_bas_fin_errorlog.c_err_content%TYPE;--日志错误信息
  nEdrPrjNo                  web_ply_base.n_edr_prj_no%type; --批改次数
  cClntMrk                   char(1);--web_ply_applicant.c_clnt_mrk%type;--客户类型  web_fin_prm_due 保费接口表也有
  v_bsns_new                 web_ply_base.c_bsns_subtyp%type;--业务来源细分
  v_insrnc_cde               web_ply_cvrg.c_cvrg_no%type;--险别代码
  v_amt                      web_ply_cvrg.n_amt%type;--险别金额
  v_prm                      web_ply_cvrg.n_prm%type;--险别保费  准备金提取时细化到单个险别的层面
  v_cal_tm                   date;--web_fin_mid_reserve.t_cal_tm%type;----web_fin_mid_reserve未到期责任准备金的中间表
  v_begin_time               DATE; --转回，区间的起期，(v_begin_time-v_end_time)*n_get_prm/保险期间      --会计期间的起期
  v_end_time                 DATE; --转回，区间的止期，(v_begin_time-v_end_time)*n_get_prm/保险期间
  v_lastcal_tm               DATE; --上一次的提取日期(约定:会计期间起期/上月末)
  v_comp_nme                 CHAR(1);
  vTmpVouNo                  VARCHAR2(30);
  v_cnt                      INT;
  v_jan_end_tm               DATE;
  v_get_amt                  NUMBER(16, 2); --记录系统自动提取部分的总和
  v_bak_amt                  NUMBER(16, 2); --记录系统自动转回部分的总和
  t_today_tm                 DATE;
  v_tms                      NUMBER(2);
  n_tms                      NUMBER(2);
  v_returncnt                INT;
  v_cha_mrk                  WEB_FIN_PRM_DUE.c_Cha_Mrk%type;--渠道标志
  v_rdr_seq_no               web_ply_cvrg.n_seq_no%type;--险别序号
  v_el_date                  NUMBER(20,14);
  v_sum_date                 NUMBER(20,14);
  v_ri_cal_amt               web_fin_col_res.N_RI_CAL_AMT%Type;
  v_ri_bal_amt               web_fin_col_res.n_ri_bal_amt%Type;
  v_count_num                int;
  v_bz_prm                   web_ply_cvrg.n_prm%type; --保证期保费
  v_bz_date                  int;--保证期天数
  v_bz_el_date               NUMBER(20,14);
  v_insrnc_bgn_tm_ply        DATE;--保单起期
  v_insrnc_end_tm_ply        DATE;--保单止期
  v_edr_typ_count            int;--批单批改保险期限统计
  v_insrnc_end_tm_new        DATE;--更改保险期限后的新保险止期
  v_insrnc_bgn_tm_new        DATE;--更改保险期限后的新保险起期
  num                        int; --错误点标记
  v_edr_end_tm               DATE;--如果止期没有时分秒，存放加了时分秒的止期
  v_insrnc_yxtm1             DATE;--批改保险期限的批单生效日期；
  v_insrnc_yxtm2             DATE;--该单的生效日期；
  v_ply_typ                  web_fin_mid_resply.c_ply_type%type;--未到期责任准备金临时中间表，保单类型
  v_normal_amt               web_fin_mid_resply.n_normal_amt%type;
  v_CAV_FLAG                 web_fin_madcr_pre.c_cav_flag%type;--借贷方向
  v_SBJT_NO                  web_fin_madcr_pre.c_SBJT_NO%type;--科目编码
  v_DPTACC_NO                web_fin_madcr_pre.c_DPTACC_NO%type;--做账机构
  v_RCPT_NO                  web_fin_madcr_pre.c_RCPT_NO%type;--业务单据流水号
  v_CHA_CLS                  web_fin_madcr_pre.c_CHA_CLS%type;--渠道类别
  v_CHA_CDE                  web_fin_madcr_pre.C_CHA_CDE%type;--渠道编码
  v_pay_prsn_cde             web_fin_madcr_pre.C_pay_prsn_cde%type;--付款人代码
  v_pay_prsn_name            web_fin_madcr_pre.C_pay_prsn_name%type;--付款人姓名
  v_CONT_CODE                web_fin_madcr_pre.C_CONT_CODE%type;--合约代码
  v_SEND_FLAG                web_fin_madcr_pre.C_SEND_FLAG%type;--传送标志
  v_pre_flag                 web_fin_madcr_pre.C_pre_flag%type;--准备金标志
  V_EXCH_AMT                 web_fin_madcr_pre.N_EXCH_AMT%type;
  V_RATE                     web_fin_madcr_pre.N_RATE%type;
  V_RATE_PRE                     web_fin_madcr_pre.N_RATE%type;
  V_RATE_JK                     web_fin_madcr_pre.N_RATE%type;
  V_RATE_YW                     web_fin_madcr_pre.N_RATE%type;
  v_edr_no_max               web_ply_base.c_edr_no%type;--最大的批单号
  v_tm_count                 Int;
  V_EDR_RSN                  web_ply_base.c_edr_rsn_bundle_cde%type;--批改原因，保单的批改原因为'0'
  v_got_prm                  NUMBER(16,2);
  v_prm_sum                  NUMBER(16,2);
  v_ply_noprm                NUMBER(16,2); --对应保单未满期保费
  v_ply_noprm1               NUMBER(16,2);--对应批单未满起保费
  v_min_tm                   number(16,2);
  v_min_tm1                  date;
  v_min_tm2                  date;
  v_kind_no                  VARCHAR2(10);
  v_count                    int;
  ----added by ctt 20110703---
  v_count1                   int;
  i int;
  v_insrnc_end_tm_org        date;--原保单保险止期
  ----------------------------
  v_resv_tm_1                date; --停驶止期
  ---hmy
  v_department_cde           web_fin_madcr_pre.c_department_cde%type;  --成本中心
  v_company_cde              web_fin_madcr_pre.c_company_cde%type;  --公司段
  v_Agri_Mrk                 web_ply_base.c_Agri_Mrk%type;  --涉农标志
  v_nat_typ                  WEB_ply_AGRO.c_nat_typ%type;  --
  --v_ply_typ                WEB_ply_AGRO.c_ply_typ%type;
  count2                     int;
  v_count3                   int;
  v_usage_cde                web_ply_vhl.c_usage_cde%type;  --使用性质
  v_flag_ny                  char(1);  ---已决未决标志
  v_pend_source              web_clm_pend.c_pend_source%type;  --未决表中的数据来源
  v_fee_prop                 web_ply_fee.n_fee_prop%type;      --手续费比率
  v_insrnc_bgn_tm1           date;
  v_insrnc_end_tm1           date;
  v_edr_bgn_tm1              date;
  v_edr_end_tm1              date;
  v_app_no                   web_ply_fee.c_app_no%type;
  v_vhl_type             web_ply_vhl.c_vhl_typ%type;
   v_bill_year                varchar2(4);
  v_bill_month               varchar2(4);
  v_billprd_type             varchar2(4);
  v_month_rbk_mrk            varchar2(4);
  v_fee                      number(20,2);
  v_i                        number(20);
  v_j                        number(20);
  v_bill_prd                 varchar2(4);
  v_emp_rate                 number(20,8);
  v_bill_prd_year            varchar2(30);   
  --抽取数据到中间表
  CURSOR cur_bur_res IS
    --游标修改 modify by shexiwan 2012-10-20
    SELECT
           base.c_ply_no,
           nvl(base.c_edr_no,'---'), /*保单没有批单号*/
           base.c_dpt_cde,
           base.c_prm_cur,
           base.c_prod_no,
           /*insured.c_insured_nme,insured.c_insured_cde,*/
           base.c_sls_cde,
           /*base.c_bsns_typ,*/nvl(base.C_SALEGRP_CDE,'02'),
           base.c_inwd_mrk,--分入业务标志
           decode(base.n_edr_prj_no,0,base.t_insrnc_bgn_tm,base.t_edr_bgn_tm),
           decode(base.n_edr_prj_no,0,base.t_insrnc_end_tm,base.t_edr_end_tm),
           base.t_udr_tm,
           base.c_salegrp_cde,
           base.c_ci_mrk,
           /*applicant.c_app_nme,applicant.c_clnt_mrk,*/--a.c_yl4,
           base.c_bsns_subtyp,--a.c_bsns_new,
           NVL(base.c_edr_type,'0'),--批改类型,0为保单
           base.n_edr_prj_no,
           ply.c_cvrg_no,--cvrg.c_cvrg_no,/*险别代码*/
           0,--NVL(cvrg.n_amt, 0),
           ply.n_prm,--cvrg.n_prm,
           0,--cvrg.n_seq_no,
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           nvl(base.c_edr_rsn_bundle_cde,'0'), --批改原因
           ply.n_prm,--cvrg.n_prm,                         --保单总保费
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_edr_bgn_tm,
           base.t_edr_end_tm,
           base.c_app_no,
           nvl(ply.n_fee_prop,0),
           ply.c_kind_no
    FROM WEB_FIN_PLYEDR ply,WEB_PLY_BASE BASE
    WHERE PLY.C_PLY_NO = BASE.C_PLY_NO
      AND PLY.C_EDR_NO = nvl(BASE.C_EDR_NO,'---')
      AND trunc(base.t_insrnc_bgn_tm) <= t_today_tm --已起保
      AND DECODE(BASE.N_EDR_PRJ_NO,0,trunc(BASE.T_INSRNC_BGN_TM),trunc(BASE.T_EDR_BGN_TM))<=t_today_tm
      And trunc(base.t_udr_tm)<=t_today_tm --针对倒签单的情况
      --未止保
      AND DECODE(BASE.N_EDR_PRJ_NO,0,trunc(BASE.T_INSRNC_END_TM),trunc(BASE.T_EDR_END_TM))>t_today_tm
      AND base.c_dpt_cde = sDptCde
     /* and base.c_ply_no = '2000009012011000002'*/;
   -------------------------保单数据的提取，提取车险的数据，细化到险别-----------------------------------------------
   /* SELECT base.c_ply_no,
           nvl(base.c_edr_no,'---'),
           base.c_dpt_cde,
           base.c_prm_cur,
           base.c_prod_no,
           base.c_sls_cde,
           nvl(base.C_SALEGRP_CDE,'02'),
           base.c_inwd_mrk,--分入业务标志
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_udr_tm,
           base.c_salegrp_cde,
           base.c_ci_mrk,
           base.c_bsns_subtyp,--a.c_bsns_new,
           NVL(base.c_edr_type,'0'),--批改类型,0为保单
           base.n_edr_prj_no,
           cvrg.c_cvrg_no,\*险别代码*\
           NVL(cvrg.n_amt, 0),
           cvrg.n_prm,
           cvrg.n_seq_no,
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           nvl(base.c_edr_rsn_bundle_cde,'0'), --批改原因
           cvrg.n_prm,                          --保单总保费
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_edr_bgn_tm,
           base.t_edr_end_tm,
           base.c_app_no
      FROM web_ply_base base, web_ply_cvrg cvrg--,web_ply_fee fee
     WHERE base.c_edr_no is null
       and base.n_edr_prj_no = '0'
       and substr(base.c_prod_no,1,2) = '03'--车险细化到险别
       and base.c_prod_no <> '0320'
       and base.c_app_no = cvrg.c_app_no(+) --分险别
       and trunc(base.t_insrnc_bgn_tm) <= t_today_tm --已起保
       and base.c_dpt_cde = sDptCde
       And trunc(base.t_udr_tm)<=t_today_tm --针对倒签单的情况
       --and base.c_ply_no = '2000009012011000002'
-----------------------11----------------------------------------------------------------------
    UNION ALL
 ---------------------------保单数据的提取，非车只需要到险种就可以---------------------------------------
    SELECT base.c_ply_no,
           nvl(base.c_edr_no,'---'), \*保单没有批单号*\
           base.c_dpt_cde,
           base.c_prm_cur,
           base.c_prod_no,
           base.c_sls_cde,
           nvl(base.C_SALEGRP_CDE,'02'),
           base.c_inwd_mrk,--分入业务标志
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_udr_tm,
           base.c_salegrp_cde,
           base.c_ci_mrk,
           base.c_bsns_subtyp,--a.c_bsns_new,
           base.c_edr_type,--批改类型
           base.n_edr_prj_no,
           '---',--险别代码，非车险不细算到险别
           NVL(base.n_amt, 0),
           base.n_prm,
           1,--非车险无险别序号，因为只到险种
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           nvl(base.c_edr_rsn_bundle_cde,'0'), --批改原因
           base.n_prm,                          --保单总保费
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_edr_bgn_tm,
           base.t_edr_end_tm,
           base.c_app_no
      FROM web_ply_base base\*,web_ply_insured insured,web_ply_applicant applicant*\
     WHERE base.c_edr_no is null
       and base.n_edr_prj_no = '0'
       and trunc(base.t_insrnc_bgn_tm) <= t_today_tm --已起保
       and base.c_dpt_cde = sDptCde
       And trunc(base.t_udr_tm)<=t_today_tm --针对倒签单的情况
       --and base.c_ply_no = '2000009012011000002'
       --add by shexiwan 为提高效率
       and exists (
           select 1 from web_prd_prod prod
           where prod.c_prod_no = base.c_prod_no
           and (prod.c_prod_no='0320' or prod.c_kind_no not in('03','06')))

----------------------------------------------------------------------------------------------
    UNION ALL

----------------------------批单数据的提取，车险细化到险别，----------------------------------------
    SELECT edrbase.c_ply_no ,
           nvl(edrbase.c_edr_no,'---'),
           edrbase.c_dpt_cde,
           edrbase.c_prm_cur,
           edrbase.c_prod_no,
           edrbase.c_sls_cde,
           nvl(edrbase.C_SALEGRP_CDE,'02'),
           edrbase.c_inwd_mrk,--分入业务标志
           edrbase.t_edr_bgn_tm,
           NVL(edrbase.t_edr_end_tm, edrbase.t_insrnc_end_tm),
           edrbase.t_udr_tm,
           edrbase.c_salegrp_cde,
           edrbase.c_ci_mrk,
           edrbase.c_bsns_subtyp,
           edrbase.c_edr_type,
           edrbase.n_edr_prj_no,
           edrcvrg.c_cvrg_no,
           NVL(edrcvrg.n_amt_var, 0),
           edrcvrg.n_prm_var,
           edrcvrg.n_seq_no,
           edrbase.t_insrnc_bgn_tm,
           edrbase.t_insrnc_end_tm,
           nvl(edrbase.c_edr_rsn_bundle_cde,'0'), --批改原因
           edrcvrg.n_prm, --保单总保费
           edrbase.t_insrnc_bgn_tm,
           edrbase.t_insrnc_end_tm,
           edrbase.t_edr_bgn_tm,
           edrbase.t_edr_end_tm,
           edrbase.c_app_no
      FROM web_ply_base edrbase , web_ply_cvrg edrcvrg\*,web_ply_applicant edrapplicant,web_ply_insured edrinsured*\
     WHERE edrbase.c_edr_no is not NULL
       and edrbase.c_edr_no = edrcvrg.c_edr_no(+) --分险别
       and (edrcvrg.n_prm_var <> 0 or edrcvrg.n_amt_var <> 0 or  edrbase.c_edr_rsn_bundle_cde like '%12%')--保费发生变化
       and substr(edrbase.c_prod_no,1,2) = '03' --车险细化到险别
       and edrbase.c_prod_no <> '0320'        --add by shexiwwan 2011-11-10
       and trunc(edrbase.t_edr_bgn_tm) <= t_today_tm --已生效
       and trunc(edrbase.t_insrnc_bgn_tm) <= t_today_tm --已起保
       and edrbase.c_dpt_cde = sDptCde
       And trunc(edrbase.t_udr_tm)<=t_today_tm
       --and edrbase.c_ply_no = '2000009012011000002'

      union all
----------------------------------------------批单数据的提取，非车只是到险种-----------------------------------
      SELECT edrbase.c_ply_no ,
           nvl(edrbase.c_edr_no,'---'),
           edrbase.c_dpt_cde,
           edrbase.c_prm_cur,
           edrbase.c_prod_no,
           edrbase.c_sls_cde,
           nvl(edrbase.C_SALEGRP_CDE,'02'),
           edrbase.c_inwd_mrk,--分入业务标志
           edrbase.t_edr_bgn_tm,
           NVL(edrbase.t_edr_end_tm, edrbase.t_insrnc_end_tm),
           edrbase.t_udr_tm,
           edrbase.c_salegrp_cde,
           edrbase.c_ci_mrk,
           edrbase.c_bsns_subtyp,
           edrbase.c_edr_type,
           edrbase.n_edr_prj_no,
           '---',
           NVL(edrbase.n_amt_var, 0),
           case when edrbase.c_edr_type='2' then (select -n_prm from web_ply_base where c_ply_no=edrbase.c_ply_no and n_edr_prj_no=0)
             else edrbase.n_prm_var end,
           1,--非车没有细化到险别
           edrbase.t_insrnc_bgn_tm,
           edrbase.t_insrnc_end_tm,
           nvl(edrbase.c_edr_rsn_bundle_cde,'0'), --批改原因
           edrbase.n_prm,                          --保单总保费
           edrbase.t_insrnc_bgn_tm,
           edrbase.t_insrnc_end_tm,
           edrbase.t_edr_bgn_tm,
           edrbase.t_edr_end_tm,
           edrbase.c_app_no
      FROM web_ply_base edrbase\* ,web_ply_applicant edrapplicant,web_ply_insured edrinsured*\
     WHERE edrbase.c_edr_no is not NULL
       and (edrbase.c_edr_type='2' or (edrbase.n_prm_var <> 0 or edrbase.n_amt_var <> 0 ) or edrbase.c_edr_rsn_bundle_cde like '%12%') --保费发生变化
       and trunc(edrbase.t_edr_bgn_tm) <= t_today_tm --已生效
       and trunc(edrbase.t_insrnc_bgn_tm) <= t_today_tm --已生效
       and edrbase.c_dpt_cde = sDptCde
       And trunc(edrbase.t_udr_tm)<=t_today_tm
       --and edrbase.c_ply_no = '2000009012011000002'
        --add by shexiwan 为提高效率
       and exists (
           select 1 from web_prd_prod prod where prod.c_prod_no = edrbase.c_prod_no
           and (prod.c_prod_no='0320' or prod.c_kind_no not in('03','06')))
 -------------意健险
 union all

 SELECT base.c_ply_no,
           nvl(base.c_edr_no,'---'),
           base.c_dpt_cde,
           base.c_prm_cur,
           base.c_prod_no,
           base.c_sls_cde,
           nvl(base.C_SALEGRP_CDE,'02'),
           base.c_inwd_mrk,--分入业务标志
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_udr_tm,
           base.c_salegrp_cde,
           base.c_ci_mrk,
           base.c_bsns_subtyp,--a.c_bsns_new,
           NVL(base.c_edr_type,'0'),--批改类型,0为保单
           base.n_edr_prj_no,
           cvrg.c_cvrg_no,\*险别代码*\
           NVL(cvrg.n_amt, 0),
           cvrg.n_prm,
           cvrg.n_seq_no,
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           nvl(base.c_edr_rsn_bundle_cde,'0'), --批改原因
           cvrg.n_prm,                          --保单总保费
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_edr_bgn_tm,
           base.t_edr_end_tm,
           base.c_app_no
      FROM web_ply_base base, web_ply_cvrg cvrg,web_ply_fee fee
     WHERE base.c_app_no = cvrg.c_app_no(+) --分险别
       and case when base.c_edr_no is null then trunc(base.t_insrnc_bgn_tm) else trunc(base.t_edr_bgn_tm) <= t_today_tm --已起保
       and base.c_dpt_cde = sDptCde
       And trunc(base.t_udr_tm)<=t_today_tm
       and substr(base.c_prod_no,1,2) = '06'--车险细化到险别
       and trunc(base.t_crt_tm)>=to_date('2012-09-07','yyyy-mm-dd')

   union all

   SELECT base.c_ply_no,
           nvl(base.c_edr_no,'---'),
           base.c_dpt_cde,
           base.c_prm_cur,
           base.c_prod_no,
           base.c_sls_cde,
           nvl(base.C_SALEGRP_CDE,'02'),
           base.c_inwd_mrk,--分入业务标志
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_udr_tm,
           base.c_salegrp_cde,
           base.c_ci_mrk,
           base.c_bsns_subtyp,--a.c_bsns_new,
           NVL(base.c_edr_type,'0'),--批改类型,0为保单
           base.n_edr_prj_no,
           cvrg.c_cvrg_no,\*险别代码*\
           NVL(cvrg.n_amt, 0),
           cvrg.n_prm,
           cvrg.n_seq_no,
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           nvl(base.c_edr_rsn_bundle_cde,'0'), --批改原因
           cvrg.n_prm,                          --保单总保费
           base.t_insrnc_bgn_tm,
           base.t_insrnc_end_tm,
           base.t_edr_bgn_tm,
           base.t_edr_end_tm,
           base.c_app_no
      FROM web_ply_base base,web_ply_fee fee
     WHERE case when base.c_edr_no is null then trunc(base.t_insrnc_bgn_tm) else trunc(base.t_edr_bgn_tm) <= t_today_tm --已起保
       and base.c_dpt_cde = sDptCde
       And trunc(base.t_udr_tm)<=t_today_tm
       and substr(base.c_prod_no,1,2) = '06'--车险细化到险别
       and trunc(base.t_crt_tm)<=to_date('2012-09-06','yyyy-mm-dd')
       ;*/
       
     /*cursor cur_cont is
      select d.c_kind_no,p.c_prod_no,m.c_uw_year,m.c_uw_month,m.c_billprd_type,m.n_month_rbk_mrk,
         case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end,
         case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end,
         m.c_bill_prd,m.c_bill_prd_year
      from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,WEB_RI_INTER_cont_BILL_prod p
      where-- m.c_pk_id = d.c_main_pk_id
          decode(m.n_month_rbk_mrk, -1, substr(m.c_bill_no, 2), m.c_bill_no) = d.c_bill_no
      and d.c_pk_id = p.c_bill_dtl_pk_id(+)
      and m.c_bill_year||m.c_bill_month<=to_char(t_today_tm,'yyyymm')
      \*and m.c_bill_month<=to_char(t_today_tm,'mm')*\;*/
     cursor cur_cont is
      select d.c_kind_no,p.c_prod_no,m.c_uw_year,m.c_uw_month,m.c_billprd_type,m.n_month_rbk_mrk,
         --case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end,
         decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end ),
         --case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end,
         decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end ),
         m.c_bill_prd,m.c_bill_prd_year,M.C_FEE_CUR
      from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,WEB_RI_INTER_cont_BILL_prod p
      where --m.c_pk_id = d.c_main_pk_id
          decode(m.n_month_rbk_mrk, -1, substr(m.c_bill_no, 2), m.c_bill_no) = d.c_bill_no
      and d.c_pk_id = p.c_bill_dtl_pk_id(+)/*
      and m.c_bill_year||m.c_bill_month<=to_char(t_today_tm,'yyyymm')*/;

BEGIN
  /*IF V_CAL_TYPE ='b' then
        delete from web_fin_mid_resply ;
        delete from web_fin_col_res;
  end if;*/

  t_today_tm := TO_DATE(v_today||' 23:59:59', 'YYYY-MM-DD hh24:mi:ss');

  --t_today_tm :=TO_DATE(v_today,'YYYY-MM-DD');
  v_comp_nme := 'x';
  v_return   := 0;
  num:=0;
  v_past_cal_amt :=0;--以前提取的金额
  --取掉查询会计期间表 delete by shexiwan 2012-01-10
  /*IF V_CAL_TYPE in('a','b','c') THEN--自动提取情况（根据代码知自动提取发生在每个会计期间期末）
    v_info_type := '1'; --挂帐信息
    SELECT TRUNC(c_bgn_tm), TRUNC(c_end_tm)
      INTO v_begin_time, v_end_time
      FROM WEB_FIN_ACCNTPERIOD--会计期间表
     WHERE TRUNC(c_end_tm) = TO_DATE(v_today, 'YYYY-MM-DD');
    v_lastcal_tm := TRUNC(v_begin_time) - 1;--只是减了一天
  ELSIF V_CAL_TYPE = 'm' THEN--此处可能是人工提取，故可能发生在一个会计期间内的任意一天
    v_info_type := '2'; --试算信息，
    v_end_time  := trunc(t_today_tm);
    SELECT TRUNC(c_bgn_tm)
      INTO v_begin_time
      FROM web_FIN_ACCNTPERIOD
     WHERE c_end_tm >= trunc(t_today_tm)
       AND c_bgn_tm <= trunc(t_today_tm);
    v_lastcal_tm := TRUNC(v_begin_time) - 1;--只是减了一天,（假定会计期间是连续的，且只在月末提取准备金）
  END IF;*/
  IF V_CAL_TYPE in('a','b','c') THEN--自动提取情况（根据代码知自动提取发生在每个会计期间期末）
    v_info_type := '1'; --挂帐信息
  ELSIF V_CAL_TYPE = 'm' THEN--此处可能是人工提取，故可能发生在一个会计期间内的任意一天
    v_info_type := '2'; --试算信息，
  END IF;
  v_lastcal_tm:=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(t_today_tm) + 1, -2)));
  --IF V_CAL_TYPE = 'm' THEN
    --手动提取时候,如系统存在上次手动提取而没有确认生成凭证的部分.删除那部分数据.
  --  DELETE FROM web_FIN_PREPLY WHERE c_info_type = '2';
  --END IF;

  IF V_CAL_TYPE in('a','b') THEN
  --开始抽取数据
  OPEN cur_bur_res;--游标cur_bur_res通过4个unnion从业务系统里抽取数据
  LOOP
    FETCH cur_bur_res
      INTO v_ply_no, v_edr_no, v_dpt_cde, v_cur_no, v_prod_no, /*v_insrnt_cnm, v_insrnt_cde,*/
      v_sls_cde, v_bsns_typ, v_inward, v_insrnc_bgn_tm, v_insrnc_end_tm, v_udr_date,
      v_salegrp_cde, v_coinsrnc_flg, /*v_app_nme, cClntMrk,*/ v_bsns_new, v_edr_type, nEdrPrjNo,
      v_insrnc_cde, v_amt, v_prm, v_rdr_seq_no,v_insrnc_bgn_tm_ply,v_insrnc_end_tm_ply,V_EDR_RSN,
      v_prm_sum,v_insrnc_bgn_tm1,v_insrnc_end_tm1,v_edr_bgn_tm1,v_edr_end_tm1,v_app_no,v_fee_prop,v_kind_no;

    EXIT WHEN cur_bur_res%NOTFOUND;

    --判断业务性质
    IF v_inward = '0' THEN
      v_tran_flag := '1'; --自营
    ELSIF v_inward = '1' THEN
      v_tran_flag := '2'; --分入
    ELSE
      v_tran_flag := '1';
    END IF;

    IF v_coinsrnc_flg='3' THEN
      v_tran_flag := '3';--共保
    END IF;
   
  --对分入单保险止期没有时分秒的进行处理 add by shexiwan
  if v_inward = '1' and nvl(v_edr_no,'---')='---' and to_char(v_insrnc_end_tm,'hh24:mi:ss')='00:00:00' then
     v_insrnc_end_tm:=to_date(to_char(v_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
     v_insrnc_end_tm_ply:= v_insrnc_end_tm;
  end if;
  --对批单止期没有时分秒的进行处理 add by shexiwan
  if to_char(v_insrnc_end_tm,'hh24:mi:ss')='00:00:00' and nvl(v_edr_no,'---')<>'---' then
     v_insrnc_end_tm:=to_date(to_char(v_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
     v_insrnc_end_tm_ply:= v_insrnc_end_tm;
  end if;

  if nvl(v_edr_no,'---')='---' then /*保单*/
    /*满期保费  ＝ （保单保费/(INT(保险止期)-保险起期+1))×(评估日－保险起期+1) --就算法
      满期保费  ＝  (保单保费/(保险止期-保险起期))×(评估日－保险起期)  --新算法
    未满期保费 ＝ 保单保费 － 满期保费*/
      v_got_prm:= v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);--保险止期不取整 modify by shexiwwan 2011-08-18
      v_cal_amt:= v_prm-v_got_prm;

  else /*批单*/
       if substr(v_prod_no,1,2)='03' then /*车险*/
            if V_EDR_RSN ='28' then
            /*如果是第一次停驶批改：
    满期保费＝批单保费+对应保批单未满期保费/批改后保险止期－停驶止期×min(评估日－停驶止期,0)
    －对应保批单未满期保费/批改前保险止期－停驶起期+1×[min(评估日,批改前保险止期)－停驶起期+1]

    如果是第二次或以上的停驶批改：
    满期保费＝min(批单保费,0)

    对于以上两种情况，
    未满期保费＝批单保费－满期保费

    对应保批单未满期保费：以批单生效日期为评估日，该批单对应的所有保单、批单的未满期保费之和。
        */
            select count(*) into v_count
            from web_ply_base
            where c_edr_no <v_edr_no and c_ply_no=v_ply_no and c_edr_rsn_bundle_cde=V_EDR_RSN;

                if v_count=0 then
                  --select b.n_prm*(t_today_tm-t_insrnc_bgn_tm+1)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                  /*select b.n_prm - b.n_prm*(t_today_tm-t_insrnc_bgn_tm+1)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                  into v_ply_noprm
                  from web_ply_base a,web_ply_cvrg b
                  where a.c_ply_no=v_ply_no and a.c_ply_no=b.c_ply_no
                  and b.c_cvrg_no=v_insrnc_cde
                  and a.c_edr_no is null
                  and b.c_edr_no is null;

                  --select nvl(b.n_prm_var*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                  select nvl(b.n_prm_var,0) - nvl(b.n_prm_var*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                  into v_ply_noprm1
                  from web_ply_base a,web_ply_cvrg b
                  where a.c_ply_no=v_ply_no and a.c_ply_no=b.c_ply_no
                  and b.c_cvrg_no=v_insrnc_cde and a.c_edr_no=b.c_edr_no
                  and a.c_edr_no <v_edr_no
                  and a.c_edr_no is not null
                  and b.c_edr_no is not null;*/

          /*停驶止起*/
            select nvl(t_resv_tm_1,t_edr_end_tm) into v_resv_tm_1 from web_ply_base where c_edr_no=v_edr_no; /*停驶止起，如果没有复驶，就是空的,就取出来批单的保险止期*/
            --保批单未满期
            v_ply_noprm:=p_fin_gotprm(nEdrPrjNo,v_kind_no,v_ply_no,v_resv_tm_1);
            if trunc(t_today_tm)<trunc(v_resv_tm_1) then  --min((t_today_tm-trunc(v_insrnc_end_tm)),0)
              v_min_tm:= trunc(t_today_tm)-v_resv_tm_1 ;
            else v_min_tm:=0 ;
            end if;

                 v_min_tm2:=  case when trunc(t_today_tm)<trunc(v_insrnc_end_tm_ply) then trunc(t_today_tm) else trunc(v_insrnc_end_tm_ply) end;--min(t_today_tm,trunc(v_insrnc_end_tm_ply))

                    v_got_prm:=(v_prm+v_ply_noprm/*+v_ply_noprm1*/)*v_min_tm/(trunc(v_insrnc_end_tm)-v_resv_tm_1+1)
                             -(v_ply_noprm/*+v_ply_noprm1*/)*(v_min_tm2-v_resv_tm_1+1)/(trunc(v_insrnc_end_tm_ply)-v_resv_tm_1+1);

                 else
                    v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
                 end if;
               v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='29'then
            /*满期保费＝min(批单保费,0)
             未满期保费＝批单保费－满期保费
            */
              v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
              v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN = 'c1' then --in('s1','c1') then --modify by shexiwan 2011-08-18 全单退保修改为和一般批改相同的算法
            /*满期保费＝－保单保费/(int(保险止期)－保险起期+1)×(评估日－保险起期+1) --就算法
              满期保费＝－保单保费/(保险止期－保险起期)×(评估日－保险起期)          --新算法
             未满期保费＝－保单保费－满期保费
          */
                 v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                 v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN between 's2' and 's8' /*and trunc(v_insrnc_bgn_tm)<=to_date('2011-08-12','yyyy-mm-dd')*/ then/*'31' and '37'*/
            --modify by shexiwan 2011-09-20 由于车险退保,全单退保 在2011-08-12之后的批改前保险止期=批单生效日期,因此在此之前的 满期算法不变,之后的则 未满期=0,满期=保费收入
            /*满期保费＝批单保费/（批改前保险止期－批单生效日期+1）×(评估日－批单生效日期+1)
          未满期保费＝批单保费－满期保费
          */
                   select a.t_insrnc_end_tm into v_insrnc_end_tm_ply from web_ply_base a where a.c_ply_no = v_ply_no and a.n_edr_prj_no = 0;
                   v_insrnc_end_tm:=v_insrnc_end_tm_ply;

                 v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
                 v_cal_amt:= v_prm-v_got_prm;
            /*elsif V_EDR_RSN in('s1','s2') and trunc(v_insrnc_bgn_tm)>to_date('2011-08-12','yyyy-mm-dd') then --add by shexiwan 2011-09-20 退保,全单退保 的保险止期=批单的生效日期
                v_got_prm:=v_prm;
                v_cal_amt:=0;*/
            else   /* if V_EDR_RSN between '01' and '27' then*/
            /*满期保费＝批单保费/（保险止期-批单生效日期+1）×(评估日－批单生效日期+1)
    未满期保费＝批单保费－满期保费*/
              if V_EDR_RSN = 's1' then
                 select a.t_insrnc_end_tm into v_insrnc_end_tm_ply from web_ply_base a where a.c_ply_no = v_ply_no and a.n_edr_prj_no = 0;
                 v_insrnc_end_tm:=v_insrnc_end_tm_ply;
              end if;
              v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
               v_cal_amt:= v_prm-v_got_prm;
            end if;


       else  /*非车险*/
            if V_EDR_RSN = '12' then/*'11'批改保险期限*/
            /*如果是第一次批改：
            满期保费
            ＝批单保费+对应保批单未满期保费/(批改后保险止期-批单生效日期+1)×[min(评估日,批改后保险止期)－批单生效日期+1]
            －对应保批单未满期保费/(批改前保险止期-批单生效日期+1)×[min(评估日,批改前保险止期)－批单生效日期+1]

            如果是第二次或以上的批改：
            满期保费＝min(批单保费,0)

            对于以上两种情况，
            未满期保费＝批单保费－满期保费
            */
            select count(*) into v_count
            from web_ply_base
            where c_edr_no <v_edr_no and c_ply_no=v_ply_no and c_edr_rsn_bundle_cde=V_EDR_RSN;
           /* select count(1) into v_count1
            from web_ply_base
            where n_edr_prj_no<nEdrPrjNo and c_ply_no=v_ply_no;*/
                if v_count=0 then/*第一次批改*/
                 /*if v_coinsrnc_flg<>'3' then
                   begin
                       --保单未满期
                       select a.n_prm-a.n_prm*(v_insrnc_bgn_tm-t_insrnc_bgn_tm)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                        into v_ply_noprm
                        from web_ply_base a
                        where a.c_ply_no=v_ply_no and a.n_edr_prj_no=nEdrPrjNo-1;
                        exception when no_data_found then
                          v_ply_noprm:=0;
                   end;
                   --批单未满期
                   --v_ply_noprm1:=v_prm_var - v_prm_var*(t_today_tm-v_insrnc_bgn_tm+1)/(trunc);
                   select t_insrnc_end_tm
                   into v_insrnc_end_tm_org
                   from web_ply_base
                   where c_ply_no=v_ply_no
                         and n_edr_prj_no=0;
                  \* begin
                     select nvl(a.n_prm_var,0)-nvl(nvl(a.n_prm_var,0)*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                        into v_ply_noprm1
                        from web_ply_base a
                        where a.c_ply_no=v_ply_no
                        and a.n_edr_prj_no=nEdrPrjNo;
                        exception when no_data_found then
                          v_ply_noprm1:=0;
                   end;*\
                  \*   if v_count1=1 then
                        select a.n_prm-a.n_prm*(t_today_tm-t_insrnc_bgn_tm+1)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                        into v_ply_noprm
                        from web_ply_base a
                        where a.c_ply_no=v_ply_no and a.n_edr_prj_no=nEdrPrjNo-1;
                     else

                        select nvl(a.n_prm_var,0)-nvl(nvl(a.n_prm_var,0)*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                        into v_ply_noprm
                        from web_ply_base a
                        where a.c_ply_no=v_ply_no
                        and a.n_edr_prj_no=nEdrPrjNo-i;
                     end if;*\
                  else
                     if nEdrPrjNo-1=0 then
                        select a.n_ci_own_prm-a.n_ci_own_prm*(t_today_tm-v_insrnc_bgn_tm\*t_insrnc_bgn_tm*\+1)/(trunc(t_insrnc_end_tm)-v_insrnc_bgn_tm\*t_insrnc_bgn_tm*\+1)
                        into v_ply_noprm
                        from web_ply_base a
                        where a.c_ply_no=v_ply_no and a.n_edr_prj_no=nEdrPrjNo-1;
                     else
                        select nvl(c.n_ci_prm_var,0)-nvl(nvl(c.n_ci_prm_var,0)*(t_today_tm-a.t_edr_bgn_tm+1)/(trunc(a.t_edr_end_tm)-a.t_edr_bgn_tm+1),0)
                        into v_ply_noprm
                        from web_ply_ci c,web_ply_base a
                        where a.c_ply_no=v_ply_no
                        and a.n_edr_prj_no=nEdrPrjNo-1
                        and a.c_ply_no=c.c_ply_no
                        and a.n_edr_prj_no=c.n_edr_prj_no;
                     end if;
                 end if;*/
                 --保批单的未满期
                 select t_insrnc_end_tm into v_insrnc_end_tm_org from web_ply_base
                  where c_ply_no=v_ply_no
                         and n_edr_prj_no=0;
                 ---修改批改保险期限的批单计算方法 以前的程序存在问题 2011-10 modif by shexiwan
                 v_ply_noprm:=p_fin_gotprm(nEdrPrjNo,v_kind_no,v_ply_no,v_insrnc_bgn_tm);
                 v_min_tm1 := case
                           when trunc(t_today_tm) < trunc(v_insrnc_end_tm_ply) then
                            trunc(t_today_tm)
                           else
                            trunc(v_insrnc_end_tm_ply)
                         end; --min(t_today_tm,trunc(v_insrnc_end_tm))
                v_min_tm2 := case
                           when trunc(t_today_tm) < trunc(v_insrnc_end_tm_org) then
                            trunc(t_today_tm)
                           else
                            trunc(v_insrnc_end_tm_org)
                         end; --min(t_today_tm,trunc(v_insrnc_end_tm_ply))

                v_got_prm := (v_prm + v_ply_noprm) *
                         (v_min_tm1 - v_insrnc_bgn_tm + 1) /
                         (trunc(v_insrnc_end_tm_ply) - v_insrnc_bgn_tm + 1) -
                         v_ply_noprm * (v_min_tm2 - v_insrnc_bgn_tm + 1) /
                         (trunc(v_insrnc_end_tm_org) - v_insrnc_bgn_tm + 1);

/*
                 v_min_tm1:=  case when t_today_tm<trunc(v_insrnc_end_tm) then t_today_tm else trunc(v_insrnc_end_tm) end;--min(t_today_tm,trunc(v_insrnc_end_tm))
                 v_min_tm2:=  case when t_today_tm<trunc(v_insrnc_end_tm_ply) then t_today_tm else trunc(v_insrnc_end_tm_ply) end;--min(t_today_tm,trunc(v_insrnc_end_tm_ply))

                    v_got_prm:=(v_prm+v_ply_noprm)*(v_min_tm1-v_insrnc_bgn_tm+1)/(trunc(v_insrnc_end_tm)-v_insrnc_bgn_tm+1)
                             -v_ply_noprm*(v_min_tm2-v_insrnc_bgn_tm+1)/(trunc(v_insrnc_end_tm_ply)-v_insrnc_bgn_tm_ply+1);
*/
                 else
                    v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
                 end if;
               v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='c1' then --注销保单,那保单对应的批单呢?就不用管吗?'22'
            /*
            满期保费＝－保单保费×评估日-保险起期+1/保险止期-保险起期+1
            未满期保费＝－保单保费－满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                  v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='c2' then/*'23'*/
            /*满期保费＝保单保费×评估日-保险起期+1/保险止期-保险起期+1
            未满期保费＝保单保费－满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                  v_cal_amt:=v_prm-v_got_prm;

            elsif V_EDR_RSN ='c3' then/*'24'*/
            /*满期保费＝－被注销批单满期保费
            未满期保费＝－被注销批单未满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);
                  v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN ='c5' then/*'25'*/
            /*满期保费＝被注销批单满期保费
            未满期保费＝被注销保单未满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);
                  v_cal_amt:= v_prm-v_got_prm;
            else
            /*满期保费＝批单保费/保险止期-批单生效日期+1×(评估日－批单生效日期+1)
              未满期保费＝批单保费－满期保费
            */
               --v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm+1)/(trunc(v_insrnc_end_tm_ply)-v_insrnc_bgn_tm+1);
               v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
               v_cal_amt:= v_prm-v_got_prm;

            end if;

         end if;
  end if;


    /*if trunc(v_insrnc_end_tm)<=trunc(t_today_tm) then \*如果保单止期<评估日,在评估日前已经止保了*\
      v_got_prm:=v_prm;
      v_cal_amt:=0;
    end if;*/
    if v_kind_no = '03' and V_EDR_RSN  in('s1','s2') and trunc(v_insrnc_end_tm)<=trunc(t_today_tm) then
       v_got_prm:=v_prm;
       v_cal_amt:=0;
       NUM:=NUM+1;
    else
       if trunc(v_insrnc_end_tm)<=trunc(t_today_tm)  then /*如果保单止期<评估日,在评估日前已经止保了*/
          v_got_prm:=v_prm;
          v_cal_amt:=0;
        end if;
    end if;


--会计准备金：该评估单位的初始未到期责任准备金=该评估单位的未满期保费*（1-该评估单位的首日费用率）
 --险类代码为12是精算自定义的一个代码,若以后承保添加新的险类的代码为12,则需注意  add by shexiwan
 v_kind_no:=Rpfunction.getKindNo(v_kind_no,v_prod_no,v_insrnc_cde);
  --V_RATE := get_rate(v_cur_no,'01',trunc(t_today_tm));--满期保费将外币折算为人民币,且满期保费表中的币种全为人民币 modify by shexiwan 2011-07-28
   if v_cur_no<>'01' then  --采用新的汇率转换 modify by 2011-08-11
      V_RATE := get_rate(v_cur_no,'01',TRUNC(t_today_tm));--get_rate(v_cur_no,'01',v_cal_tm);
   else
      V_RATE:=1;
   end if;
      INSERT INTO web_fin_mid_gotprm(c_pre_no,c_ply_no,c_edr_no,c_dpt_cde,c_prod_no,
                                  c_insrnc_cde,c_cur_cde,c_bsns_typ,n_cal_amt,t_cal_tm,
                                  c_cal_typ,c_tran_flag,t_insrnc_bgn_tm,t_insrnc_end_tm,c_ri_type,
                                  c_ri_com,c_clnt_mrk,n_amt,n_prm,n_bal_amt,
                                  n_seq_no,c_kind_no,t_edr_bgn_tm,t_edr_end_tm,N_GOTPRM)
       VALUES (  'gotprm',v_ply_no,nvl(v_edr_no,'---'),v_dpt_cde,v_prod_no,
          v_insrnc_cde,'01',v_bsns_typ,v_got_prm*V_RATE,trunc(t_today_tm),
          '1',v_tran_flag,v_insrnc_bgn_tm1,v_insrnc_end_tm1,'1',
          v_ri_com,cClntMrk,v_amt,v_prm,v_got_prm*V_RATE,
          0,v_kind_no,v_edr_bgn_tm1,v_edr_end_tm1,v_got_prm);

  END LOOP;
  CLOSE cur_bur_res;--业务数据集游标的结束
  
  
  --合约分入 add by sehxiwan 2012-11-29 begin
  if sDptCde = '00' then
       V_I:=0;
      V_J:=0;
      OPEN cur_cont;--游标cur_bur_res通过4个unnion从业务系统里抽取数据
      LOOP
        FETCH cur_cont
          INTO v_kind_no,v_prod_no,v_bill_year,v_bill_month,v_billprd_type,v_month_rbk_mrk,v_prm,v_fee,v_bill_prd,v_bill_prd_year,v_cur_no;
        EXIT WHEN cur_cont%NOTFOUND;
       if v_prm <> 0 then
       V_I:=V_I+1;
       V_J:=V_J+1;
       v_ply_no:='CON'||to_char(t_today_tm,'yyyymmdd')||'0000'||V_I;--虚拟一个保单号
       
       
       /*m.c_uw_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_udr_tm,     --核保日期
       m.c_uw_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_edr_bgn_tm,
       to_number(m.c_uw_year)+1||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-14 23:59:59'                               as t_edr_end_tm,*/
       /*if upper(v_billprd_type) = 'S' then
      if v_bill_prd = 'Q1' then
         v_bill_month:='-01';
      elsif v_bill_prd = 'Q2' then
         v_bill_month:='-04';
      elsif v_bill_prd = 'Q3' then
         v_bill_month:='-07';
      else
         v_bill_month:='-10';
      end if;*/
       if upper(v_billprd_type) = 'S' or v_month_rbk_mrk = '-1' then
          v_edr_no:='CONEDR'||to_char(t_today_tm,'yyyymmdd')||'0000'||V_I;--虚拟一个保单号
          if v_bill_prd = 'Q1' THEN
             v_bill_month:='-02';
          ELSIF v_bill_prd = 'Q2' THEN
             v_bill_month:='-05';
          ELSIF v_bill_prd = 'Q3' THEN
             v_bill_month:='-08';
          ELSE
             v_bill_month:='-11';
          END IF;
          v_bill_year:=v_bill_prd_year;
          v_insrnc_bgn_tm:=to_date(v_bill_year||v_bill_month||'-15 00:00:00','yyyy-mm-dd hh24:mi:ss');
          v_insrnc_end_tm:=to_date(to_number(v_bill_year)+1||v_bill_month||'-14 23:59:59','yyyy-mm-dd hh24:mi:ss');  
       else
           v_edr_no:='---';
          /*if v_bill_month in ('01','02','03') then
             v_bill_month:='-02';
          elsif v_bill_month in ('04','05','06') then
             v_bill_month:='-05';
          elsif v_bill_month in ('07','08','09') then
             v_bill_month:='-08';
          else
             v_bill_month:='-11';
          end if;*/
          v_insrnc_bgn_tm:=to_date(v_bill_year||v_bill_month||'-15 00:00:00','yyyy-mm-dd hh24:mi:ss');
          v_insrnc_end_tm:=to_date(to_number(v_bill_year)+1||v_bill_month||'-14 23:59:59','yyyy-mm-dd hh24:mi:ss');
       end if;

      if nvl(v_edr_no,'---')='---' then /*保单*/
          v_got_prm:= v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);--保险止期不取整 modify by shexiwwan 2011-08-18
          v_cal_amt:= v_prm-v_got_prm;
      else
          v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);
          v_cal_amt:= v_prm-v_got_prm;

      end if;

      if trunc(v_insrnc_end_tm)<=trunc(t_today_tm)  then /*如果保单止期<评估日,在评估日前已经止保了*/
          v_got_prm:=v_prm;
          v_cal_amt:=0;
      end if;


    --会计准备金：该评估单位的初始未到期责任准备金=该评估单位的未满期保费*（1-该评估单位的首日费用率）
     --险类代码为12是精算自定义的一个代码,若以后承保添加新的险类的代码为12,则需注意  add by shexiwan
     v_kind_no:=Rpfunction.getKindNo(v_kind_no,v_prod_no,v_insrnc_cde);
     v_fee_prop:=v_fee/v_prm;
     --V_RATE:=v_fee_prop+0.001305;
     --V_RATE:=v_fee_prop+0.001305+0.0575;
     /*select sum(a.n_rate) into v_rate from web_fin_ibnr_rate a 
    where a.c_cde in('015004','015001') and c_kind_no=v_kind_no;
    V_RATE:=v_fee_prop+v_rate;
    -----------------------------------------------------------------------------------------------------------------------
         if v_inward <> '1' then
            V_RATE:= V_RATE + v_fee_prop;    --add by shexiwan 2011-11-11
         end if;

         v_act_amt :=v_cal_amt*(1-V_RATE);--会计未到期

        V_RATE := 1;*/--get_rate(v_cur_no,'01',trunc(t_today_tm));
        --V_RATE:=1;--未到期的按原币种金额
        v_dpt_cde:='00';
        if v_prod_no is null or v_prod_no = '' then
           v_prod_no:=v_kind_no||'00';
        end if;
        --v_cur_no:='01';
        v_bsns_typ:='02';
        v_salegrp_cde:='02';v_insrnc_cde:='---';
        
        if v_cur_no<>'01' then  --采用新的汇率转换 modify by 2011-08-11
           V_RATE := get_rate(v_cur_no,'01',TRUNC(t_today_tm));--get_rate(v_cur_no,'01',v_cal_tm);
        else
           V_RATE:=1;
        end if;
        
          INSERT INTO web_fin_mid_gotprm
             (c_pre_no,c_ply_no,c_edr_no,c_dpt_cde,c_prod_no,
              c_insrnc_cde,c_cur_cde,c_bsns_typ,n_cal_amt,t_cal_tm,
              c_cal_typ,c_tran_flag,t_insrnc_bgn_tm,t_insrnc_end_tm,c_ri_type,
              c_ri_com,c_clnt_mrk,n_amt,n_prm,n_bal_amt,
              n_seq_no,c_kind_no,t_edr_bgn_tm,t_edr_end_tm,N_GOTPRM)
          VALUES('gotprm',v_ply_no,nvl(v_edr_no,'---'),'00',v_prod_no,
              v_insrnc_cde,'01',v_bsns_typ,v_got_prm*V_RATE,trunc(t_today_tm),
              '1','2',v_insrnc_bgn_tm,v_insrnc_end_tm,'1',
              v_ri_com,cClntMrk,v_amt,v_prm,v_got_prm*V_RATE,
              0,v_kind_no,null,null,v_got_prm);
        end if;
      END LOOP;
      CLOSE cur_cont;--业务数据集游标的结束
    end if;

----------------------------------------------------------------------------------------------------------------------------
end if;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      --RAISE;
      DBMS_OUTPUT.PUT_LINE('exception' || '*' || vTmpVouNo || SQLERRM);
      ROLLBACK;
      v_err_content := 'proc:[P_Fin_Gotprmply],出错流水号：[' || v_today ||
                       v_cal_type ||' '||v_ply_no || '],错误描述：[' || SQLCODE ||SQLERRM;

      --注释便于调试 2010-08-25
      INSERT INTO web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode(4), '001', '0000', v_err_content, SYSDATE);
      COMMIT;
    v_return := -1;
    END;

END;

end p_gotprm;
/
