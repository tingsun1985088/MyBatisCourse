CREATE package rpPre is
 procedure finMadcrBackPre(v_date in date,succflag out varchar2); ----冲上期数据
 procedure finmidPre(v_date in date,succflag out varchar2);  --准备金按一定的维度汇总到web_fin_madcr_pre中
 procedure finintfPre(v_date in date,succflag out varchar2);  --准备金汇总
 procedure finPreToFin(v_date in date,succflag out varchar2);  --对接与财务系统的接口
 
end rpPre;
/
