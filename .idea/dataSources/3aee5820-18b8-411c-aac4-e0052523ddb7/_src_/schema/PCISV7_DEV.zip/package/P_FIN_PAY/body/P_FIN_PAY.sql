CREATE package body p_fin_pay is
v_err_content               web_bas_fin_errorlog.c_err_content%TYPE;--日志错误信息
    v_Sqlcode                   Number;
    v_Sqlerrm                   Varchar2(600);
    v_inwd_mrk                  varchar2(10);
    v_srs_case_mrk              varchar2(10);
    v_got_prm                   number(20,2);
    v_accnt_tm                  date;
    v_insrc_cde                 Varchar2(10);
    v_dpt_cde                   Varchar2(10);
    v_kind_no                   Varchar2(10);
    v_prod_no                   Varchar2(10);
    v_year                      Varchar2(4);
    v_quart                     Varchar2(2);
    v_year1                      Varchar2(4);
    v_quart1                     Varchar2(2);
    v_bgn_tm                    date;
    v_end_tm                    date;
    v_start_tm                  date;
    v_over_tm                   date;
    v_upd_col                   varchar2(1000);
    v_upd_col2                  varchar2(10);
    v_col_tmp                   number;
    v_sql                       varchar2(1000);
    v_sql2                      varchar2(1000);
    v_flg                       char(1);
    j                           number(10);
    v_begin_year                varchar2(4);
    v_begin_quart               varchar2(4);
    v_000                       number(20,2);
    v_001                       number(20,2);
    v_002                       number(20,2);
    v_003                       number(20,2);
    v_004                       number(20,2);
    v_005                       number(20,2);
    v_006                       number(20,2);
    v_007                       number(20,2);
    v_008                       number(20,2);
    v_009                       number(20,2);
    v_010                       number(20,2);
    v_011                       number(20,2);
    v_012                       number(20,2);
    v_013                       number(20,2);
    v_014                       number(20,2);
    v_015                       number(20,2);
    v_016                       number(20,2);
    v_017                       number(20,2);
    v_018                       number(20,2);
    v_019                       number(20,2);
    v_020                       number(20,2);
    v_021                       number(20,2);
    v_022                       number(20,2);
    v_023                       number(20,2);
    v_024                        number(20,2);
    v_025                        number(20,2);
    v_026                        number(20,2);
    v_027                        number(20,2);
    v_028                        number(20,2);
    v_029                        number(20,2);
    v_030                        number(20,2);
    v_031                        number(20,2);
    v_032                        number(20,2);
    v_033                        number(20,2);
    v_034                        number(20,2);
    v_035                        number(20,2);
    v_036                        number(20,2);
    v_037                        number(20,2);
    v_038                        number(20,2);
    v_039                        number(20,2);
    v_040                        number(20,2);
    v_041                        number(20,2);
    v_042                        number(20,2);
    v_043                        number(20,2);
    v_044                        number(20,2);
    v_045                        number(20,2);
    v_046                        number(20,2);
    v_047                        number(20,2);
    v_048                        number(20,2);
    v_049                        number(20,2);
    v_050                        number(20,2);
    v_051                        number(20,2);
    v_052                        number(20,2);
    v_053                        number(20,2);
    v_054                        number(20,2);
    v_055                        number(20,2);
    v_056                        number(20,2);
    v_057                        number(20,2);
    v_058                        number(20,2);
    v_059                        number(20,2);
    v_060                        number(20,2);
    v_061                        number(20,2);
    v_062                        number(20,2);
    v_063                        number(20,2);
    v_064                        number(20,2);
    v_065                        number(20,2);
    v_066                        number(20,2);
    v_067                        number(20,2);
    v_068                        number(20,2);
    v_069                        number(20,2);
    v_070                        number(20,2);
    v_071                        number(20,2);
    v_072                        number(20,2);
    today                        date;
    v_clm_amt                    number(20,2);
    v_pk_id                       varchar2(50);
    v_count                       number;
    v_i                           number;
    emp_elv                     number(20,6);
    --再保前已决赔付率流量
    procedure P_fin_pay_amt(v_today varchar2, v_cal_type in char, v_return out varchar2)
      is
        cursor cur_clm is
         select distinct a.c_kind_no as c_kind_no,a.c_prod_no as c_prod_no,c_year,c_quart
        from WEB_FIN_REPORT a 
        where trunc(a.t_cal_tm) = trunc(today);
      begin
        v_return:=1;
        v_i:=1;
        today:=to_date(v_today,'yyyy-mm-dd');
        delete from WEB_FIN_PAY_AMT a where a.t_cal_tm = today;
        --取评估日季度的最后一个月
        v_start_tm:=TRUNC(ADD_MONTHS(today,3), 'Q' )-1;
        --默认起期
        v_over_tm:=to_date('2011-04-01','yyyy-mm-dd');
        --评估日已起期之间有多少个季度
        j:=MONTHS_BETWEEN(to_date(to_char(v_start_tm,'yyyymm'),'yyyymm'),to_date(to_char(v_over_tm,'yyyymm'),'yyyymm'));
        j:=j/3-1;

        for v_cur in cur_clm loop
          
           v_kind_no:=v_cur.c_kind_no;
           v_prod_no:=v_cur.c_prod_no;
           v_year:=v_cur.c_year;
           v_quart:=v_cur.c_quart;
           v_pk_id:=to_char(today,'yyyymmdd')||'0000'||v_i;
           
           INSERT INTO WEB_FIN_PAY_AMT(T_CAL_TM,C_KIND_NO,C_PROD_NO,T_CRT_TM,C_YEAR,C_QUART,c_pk_id)
           VALUES(today,V_KIND_NO,v_prod_no,SYSDATE,v_year,v_quart,v_pk_id);
           
           for v_col in 0..j loop
              v_bgn_tm:=add_months(trunc(v_start_tm,'Q'),-v_col*3);
              --v_year1:=to_char(v_bgn_tm,'yyyy');
              --v_quart1:= to_char(v_bgn_tm,'q');
              v_upd_col:='1';
              
              if v_col<=9 then
                 v_upd_col:='0'||v_col;
              else
                 v_upd_col:=v_col;
              end if;

             v_upd_col:='N_0'||v_upd_col;

             v_sql:='SELECT  '||v_upd_col||'  FROM WEB_FIN_AMT ';
             v_sql:=v_sql||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
             v_sql:=v_sql||' AND C_KIND_NO='''||V_KIND_NO||''' AND C_PROD_NO='''||V_PROD_NO||'''';
             V_SQL:=V_SQL||' AND C_YEAR ='''||v_year||'''' ;
             V_SQL:=V_SQL||' AND C_QUART ='''||v_quart||'''' ;

             EXECUTE IMMEDIATE v_sql INTO v_clm_amt;

             begin
                 select sum(a.n_got_prm) into v_got_prm from web_fin_gotprm_quarts a 
                 where trunc(a.t_cal_tm) = today and a.c_year = v_year 
                 and a.c_quart = v_quart and a.c_kind_no = v_kind_no
                 and decode(a.c_prod_no,'0320','0320','---') = v_prod_no;
             exception when no_data_found then
                 v_got_prm:=0;
             end;
             
            if v_clm_amt is not null then
             
                if nvl(v_got_prm,0) = 0 then
                   emp_elv:=0;
                else
                   emp_elv:= v_clm_amt/v_got_prm;
                end if;
                v_sql2:=' UPDATE WEB_FIN_PAY_AMT ';
                v_sql2:=v_sql2||' SET '||v_upd_col||'';
                v_sql2:=v_sql2||' = '||emp_elv;
                v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
                v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
                v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
                v_sql2:=v_sql2||' AND c_year = '''||v_year||'''';
                v_sql2:=v_sql2||' AND c_quart = '''||v_quart||'''';
                
                EXECUTE IMMEDIATE v_sql2;
            end if;
            v_i:=v_i+1;
            
         end loop;
      end loop;
      commit;
      exception
      When Others Then
        Rollback;
        v_Sqlcode := Sqlcode;
        v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;

      v_err_content:='proc:[P_fin_pay_amt],出错流水号:['||today||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end P_fin_pay_amt;
      
      --再保前已决赔付率流量
    procedure P_fin_pay_report(v_today varchar2, v_cal_type in char, v_return out varchar2)
      is
        cursor cur_clm is
         select distinct a.c_kind_no as c_kind_no,a.c_prod_no as c_prod_no,c_year,c_quart
        from WEB_FIN_REPORT a 
        where trunc(a.t_cal_tm) = trunc(today);
      begin
        v_return:=1;
        v_i:=1;
        today:=to_date(v_today,'yyyy-mm-dd');
        delete from WEB_FIN_PAY_REPORT a where a.t_cal_tm = today;
        --取评估日季度的最后一个月
        v_start_tm:=TRUNC(ADD_MONTHS(today,3), 'Q' )-1;
        --默认起期
        v_over_tm:=to_date('2011-04-01','yyyy-mm-dd');
        --评估日已起期之间有多少个季度
        j:=MONTHS_BETWEEN(to_date(to_char(v_start_tm,'yyyymm'),'yyyymm'),to_date(to_char(v_over_tm,'yyyymm'),'yyyymm'));
        j:=j/3-1;

        for v_cur in cur_clm loop
          
           v_kind_no:=v_cur.c_kind_no;
           v_prod_no:=v_cur.c_prod_no;
           v_year:=v_cur.c_year;
           v_quart:=v_cur.c_quart;
           v_pk_id:=to_char(today,'yyyymmdd')||'0000'||v_i;
           
           INSERT INTO WEB_FIN_PAY_REPORT(T_CAL_TM,C_KIND_NO,C_PROD_NO,T_CRT_TM,C_YEAR,C_QUART,c_pk_id)
           VALUES(today,V_KIND_NO,v_prod_no,SYSDATE,v_year,v_quart,v_pk_id);
           
           for v_col in 0..j loop
              v_bgn_tm:=add_months(trunc(v_start_tm,'Q'),-v_col*3);
              --v_year1:=to_char(v_bgn_tm,'yyyy');
              --v_quart1:= to_char(v_bgn_tm,'q');
              v_upd_col:='1';
              
              if v_col<=9 then
                 v_upd_col:='0'||v_col;
              else
                 v_upd_col:=v_col;
              end if;

             v_upd_col:='N_0'||v_upd_col;

             v_sql:='SELECT  '||v_upd_col||'  FROM WEB_FIN_REPORT ';
             v_sql:=v_sql||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
             v_sql:=v_sql||' AND C_KIND_NO='''||V_KIND_NO||''' AND C_PROD_NO='''||V_PROD_NO||'''';
             V_SQL:=V_SQL||' AND C_YEAR ='''||v_year||'''' ;
             V_SQL:=V_SQL||' AND C_QUART ='''||v_quart||'''' ;

             EXECUTE IMMEDIATE v_sql INTO v_clm_amt;

             begin
                 select sum(a.n_got_prm) into v_got_prm from web_fin_gotprm_quarts a 
                 where trunc(a.t_cal_tm) = today and a.c_year = v_year 
                 and a.c_quart = v_quart and a.c_kind_no = v_kind_no
                 and decode(a.c_prod_no,'0320','0320','---') = v_prod_no;
             exception when no_data_found then
                 v_got_prm:=0;
             end;
             
            if v_clm_amt is not null then
             
                if nvl(v_got_prm,0) = 0 then
                   emp_elv:=0;
                else
                   emp_elv:= v_clm_amt/v_got_prm;
                end if;
                v_sql2:=' UPDATE WEB_FIN_PAY_REPORT ';
                v_sql2:=v_sql2||' SET '||v_upd_col||'';
                v_sql2:=v_sql2||' = '||emp_elv;
                v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
                v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
                v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
                v_sql2:=v_sql2||' AND c_year = '''||v_year||'''';
                v_sql2:=v_sql2||' AND c_quart = '''||v_quart||'''';
                
                EXECUTE IMMEDIATE v_sql2;
            end if;
            v_i:=v_i+1;
            
         end loop;
      end loop;
      commit;
    exception
      When Others Then
        Rollback;
        v_Sqlcode := Sqlcode;
        v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;

      v_err_content:='proc:[P_fin_pay_report],出错流水号:['||today||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
      end P_fin_pay_report;
      
      ------
      procedure P_fin_bac_pay_amt(v_today varchar2, v_cal_type in char, v_return out varchar2)
      is
        cursor cur_clm is
         select distinct a.c_kind_no as c_kind_no,a.c_prod_no as c_prod_no,c_year,c_quart
        from WEB_FIN_BAC_AMT a 
        where trunc(a.t_cal_tm) = trunc(today);
      begin
        v_return:=1;
        v_i:=1;
        today:=to_date(v_today,'yyyy-mm-dd');
        delete from WEB_FIN_BAC_PAY_AMT a where a.t_cal_tm = today;
        --取评估日季度的最后一个月
        v_start_tm:=TRUNC(ADD_MONTHS(today,3), 'Q' )-1;
        --默认起期
        v_over_tm:=to_date('2011-04-01','yyyy-mm-dd');
        --评估日已起期之间有多少个季度
        j:=MONTHS_BETWEEN(to_date(to_char(v_start_tm,'yyyymm'),'yyyymm'),to_date(to_char(v_over_tm,'yyyymm'),'yyyymm'));
        j:=j/3-1;

        for v_cur in cur_clm loop
          
           v_kind_no:=v_cur.c_kind_no;
           v_prod_no:=v_cur.c_prod_no;
           v_year:=v_cur.c_year;
           v_quart:=v_cur.c_quart;
           v_pk_id:=to_char(today,'yyyymmdd')||'0000'||v_i;
           
           INSERT INTO WEB_FIN_BAC_PAY_AMT(T_CAL_TM,C_KIND_NO,C_PROD_NO,T_CRT_TM,C_YEAR,C_QUART,c_pk_id)
           VALUES(today,V_KIND_NO,v_prod_no,SYSDATE,v_year,v_quart,v_pk_id);
           
           for v_col in 0..j loop
              v_bgn_tm:=add_months(trunc(v_start_tm,'Q'),-v_col*3);
              --v_year1:=to_char(v_bgn_tm,'yyyy');
              --v_quart1:= to_char(v_bgn_tm,'q');
              v_upd_col:='1';
              
              if v_col<=9 then
                 v_upd_col:='0'||v_col;
              else
                 v_upd_col:=v_col;
              end if;

             v_upd_col:='N_0'||v_upd_col;

             v_sql:='SELECT  '||v_upd_col||'  FROM WEB_FIN_BAC_AMT ';
             v_sql:=v_sql||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
             v_sql:=v_sql||' AND C_KIND_NO='''||V_KIND_NO||''' AND C_PROD_NO='''||V_PROD_NO||'''';
             V_SQL:=V_SQL||' AND C_YEAR ='''||v_year||'''' ;
             V_SQL:=V_SQL||' AND C_QUART ='''||v_quart||'''' ;

             EXECUTE IMMEDIATE v_sql INTO v_clm_amt;

             begin
                 select sum(a.N_BAC_GOT_PRM) into v_got_prm from web_fin_gotprm_quarts a 
                 where trunc(a.t_cal_tm) = today and a.c_year = v_year 
                 and a.c_quart = v_quart and a.c_kind_no = v_kind_no
                 and decode(a.c_prod_no,'0320','0320','---') = v_prod_no;
             exception when no_data_found then
                 v_got_prm:=0;
             end;
             
            if v_clm_amt is not null then
             
                if nvl(v_got_prm,0) = 0 then
                   emp_elv:=0;
                else
                   emp_elv:= v_clm_amt/v_got_prm;
                end if;
                v_sql2:=' UPDATE WEB_FIN_BAC_PAY_AMT ';
                v_sql2:=v_sql2||' SET '||v_upd_col||'';
                v_sql2:=v_sql2||' = '||emp_elv;
                v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
                v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
                v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
                v_sql2:=v_sql2||' AND c_year = '''||v_year||'''';
                v_sql2:=v_sql2||' AND c_quart = '''||v_quart||'''';
                
                EXECUTE IMMEDIATE v_sql2;
            end if;
            v_i:=v_i+1;
            
         end loop;
      end loop;
      commit;
      exception
      When Others Then
        Rollback;
        v_Sqlcode := Sqlcode;
        v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;

      v_err_content:='proc:[P_fin_bac_pay_amt],出错流水号:['||today||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end P_fin_bac_pay_amt;
    
    
    procedure P_fin_bac_pay_report(v_today varchar2, v_cal_type in char, v_return out varchar2)
      is
        cursor cur_clm is
         select distinct a.c_kind_no as c_kind_no,a.c_prod_no as c_prod_no,c_year,c_quart
        from WEB_FIN_BAC_REPORT a 
        where trunc(a.t_cal_tm) = trunc(today);
      begin
        v_return:=1;
        v_i:=1;
        today:=to_date(v_today,'yyyy-mm-dd');
        delete from WEB_FIN_PAY_REPORT a where a.t_cal_tm = today;
        --取评估日季度的最后一个月
        v_start_tm:=TRUNC(ADD_MONTHS(today,3), 'Q' )-1;
        --默认起期
        v_over_tm:=to_date('2011-04-01','yyyy-mm-dd');
        --评估日已起期之间有多少个季度
        j:=MONTHS_BETWEEN(to_date(to_char(v_start_tm,'yyyymm'),'yyyymm'),to_date(to_char(v_over_tm,'yyyymm'),'yyyymm'));
        j:=j/3-1;

        for v_cur in cur_clm loop
          
           v_kind_no:=v_cur.c_kind_no;
           v_prod_no:=v_cur.c_prod_no;
           v_year:=v_cur.c_year;
           v_quart:=v_cur.c_quart;
           v_pk_id:=to_char(today,'yyyymmdd')||'0000'||v_i;
           
           INSERT INTO WEB_FIN_BAC_PAY_REPORT(T_CAL_TM,C_KIND_NO,C_PROD_NO,T_CRT_TM,C_YEAR,C_QUART,c_pk_id)
           VALUES(today,V_KIND_NO,v_prod_no,SYSDATE,v_year,v_quart,v_pk_id);
           
           for v_col in 0..j loop
              v_bgn_tm:=add_months(trunc(v_start_tm,'Q'),-v_col*3);
              --v_year1:=to_char(v_bgn_tm,'yyyy');
              --v_quart1:= to_char(v_bgn_tm,'q');
              v_upd_col:='1';
              
              if v_col<=9 then
                 v_upd_col:='0'||v_col;
              else
                 v_upd_col:=v_col;
              end if;

             v_upd_col:='N_0'||v_upd_col;

             v_sql:='SELECT  '||v_upd_col||'  FROM WEB_FIN_BAC_REPORT ';
             v_sql:=v_sql||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
             v_sql:=v_sql||' AND C_KIND_NO='''||V_KIND_NO||''' AND C_PROD_NO='''||V_PROD_NO||'''';
             V_SQL:=V_SQL||' AND C_YEAR ='''||v_year||'''' ;
             V_SQL:=V_SQL||' AND C_QUART ='''||v_quart||'''' ;

             EXECUTE IMMEDIATE v_sql INTO v_clm_amt;

             begin
                 select sum(a.n_Bac_Got_Prm) into v_got_prm from web_fin_gotprm_quarts a 
                 where trunc(a.t_cal_tm) = today and a.c_year = v_year 
                 and a.c_quart = v_quart and a.c_kind_no = v_kind_no
                 and decode(a.c_prod_no,'0320','0320','---') = v_prod_no;
             exception when no_data_found then
                 v_got_prm:=0;
             end;
             
            if v_clm_amt is not null then
             
                if nvl(v_got_prm,0) = 0 then
                   emp_elv:=0;
                else
                   emp_elv:= v_clm_amt/v_got_prm;
                end if;
                v_sql2:=' UPDATE WEB_FIN_BAC_PAY_REPORT ';
                v_sql2:=v_sql2||' SET '||v_upd_col||'';
                v_sql2:=v_sql2||' = '||emp_elv;
                v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
                v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
                v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
                v_sql2:=v_sql2||' AND c_year = '''||v_year||'''';
                v_sql2:=v_sql2||' AND c_quart = '''||v_quart||'''';
                
                EXECUTE IMMEDIATE v_sql2;
            end if;
            v_i:=v_i+1;
            
         end loop;
      end loop;
      commit;
    exception
      When Others Then
        Rollback;
        v_Sqlcode := Sqlcode;
        v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;

      v_err_content:='proc:[P_fin_bac_pay_report],出错流水号:['||today||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
      end P_fin_bac_pay_report;
end p_fin_pay;
/
