CREATE PACKAGE RPT_IFACE_OPTIMIZE IS
  PROCEDURE P_GET_REPORT(T_BGN_TM  IN DATE,
                         T_END_TM  IN DATE,
                         DPTLEN    IN INT,
                         V_C_TYPE  IN VARCHAR2,
                         V_RET_STA OUT NUMBER);

  /*PROCEDURE Ri_Iface_Measure(
  v_beg_tm  IN       VARCHAR2,
  v_end_tm  IN    VARCHAR2,
  n_dptlen  IN       INT,
  v_err_str OUT      VARCHAR2);*/
  PROCEDURE P_CIRCI_FORMULA_ADD(C_REPORT_TYPE   VARCHAR2,
                                C_INSERT_UPDATE INTEGER);
END RPT_IFACE_OPTIMIZE;
/
