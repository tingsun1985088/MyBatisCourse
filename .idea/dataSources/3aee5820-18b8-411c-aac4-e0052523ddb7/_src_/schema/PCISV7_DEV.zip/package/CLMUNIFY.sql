CREATE PACKAGE "CLMUNIFY" is
  --????
  PROCEDURE checkClmUnify( --starte     IN       WEB_FIN_RPCLMCUSTOMER.C_BALA_MRK%TYPE,
                          v_rcpt_no       IN WEB_FIN_RPCLMCUSTOMER.C_Rcpt_No%type, --???
                          v_emp_cde       IN WEB_FIN_RPCLMCUSTOMER.c_Check_Cde%type, --???
                          v_dptacc_cde    IN web_pay_seemoney_config.c_dptacc_cde%type, --????
                          v_type          IN VARCHAR2, --????
                          v_overrule_mind IN WEB_FIN_RPCLMCUSTOMER.c_recv_bank_reason%TYPE, --??
                          v_succsflag     IN OUT NUMBER);
  --??????
  PROCEDURE checkRollClmUnify( --starte     IN       WEB_FIN_RPCLMCUSTOMER.C_BALA_MRK%TYPE,
                              v_rcpt_no       IN WEB_FIN_RPROLLCLMCUSTOMER.C_Rcpt_No%type, --???
                              v_emp_cde       IN WEB_FIN_RPROLLCLMCUSTOMER.c_Check_Cde%type, --???
                              v_dptacc_cde    IN web_pay_seemoney_config.c_dptacc_cde%type, --????
                              v_type          IN VARCHAR2, --????
                              v_overrule_mind IN WEB_FIN_RPROLLCLMCUSTOMER.c_recv_bank_reason%TYPE, --??
                              v_succsflag     IN OUT NUMBER);
end ClmUnify;










/
