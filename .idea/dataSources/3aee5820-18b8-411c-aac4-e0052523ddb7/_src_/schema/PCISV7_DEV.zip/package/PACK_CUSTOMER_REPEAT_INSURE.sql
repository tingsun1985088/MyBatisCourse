CREATE package PACK_CUSTOMER_REPEAT_INSURE is

  PROCEDURE P_LIABILITY_INSURANCE_REPEAT(CAppType  IN VARCHAR2,
                                         CProdNo   IN VARCHAR2,
                                         CAppNo    IN VARCHAR2,
                                         CPlyNo    IN VARCHAR2,
                                         NEdrPrjNo IN NUMBER,
                                         CResult   OUT VARCHAR2);
  PROCEDURE P_HEALTH_INSURANCE_LIMIT(CAppType    IN VARCHAR2,
                                     CPlyNo      IN VARCHAR2,
                                     NAmt        IN NUMBER,
                                     NAmtChgRate IN NUMBER,
                                     CCertType   VARCHAR2,
                                     CCertNo     VARCHAR2,
                                     CResult     OUT VARCHAR2);
end PACK_CUSTOMER_REPEAT_INSURE;
/
