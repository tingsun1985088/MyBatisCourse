CREATE VIEW V_CLM_VHL_PAYSY AS select m.c_clm_no c_clm_no,
       ''         c_rpt_no,
       m.c_ply_no c_ply_no,
       to_char(m.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_bgn_tm,
       to_char(m.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_end_tm,
       case when substr(m.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm1,
       dpt2.c_dpt_cnm  as c_dpt_cnm2,
       '商业车险'        c_kind_name,--险类,
       prod.c_nme_cn     c_prod_name,--产品,
       cvrg.c_nme_cn c_cvrg_name,
       '个人'        c_group_mrk,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no
              and rownum = 1 ) as c_stk_mrk,
       decode(nvl(m.c_Inward,'0'),'0','非分入','分入') as c_inwd_mrk,
       '---'        as C_RS_MRK ,/*是否人伤*/
       '人民币'     c_pay_cur,
       /*nvl(duty.N_IC_AMT, 0) +
       \*nvl(ic.n_jq_help_fee, 0) *
       decode(nvl(ic.n_yfjq_amt, 0),
              0,
              0,
              nvl(duty.n_ic_amt, 0) / ic.n_yfjq_amt)+*\
       (case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end )
       +
       \*decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)*\
       (case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)
                                 else
                                     0
                            end)*/
       DTL.N_SUM_ESTMT_AMT n_pay_amt,--原币种已决赔款,
       /*nvl(duty.N_IC_AMT, 0) +
       (case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end )
       +
       \*decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)*\
       (case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)
                                 else
                                     0
                            end)*/
       DTL.N_SUM_ESTMT_AMT n_pay_rmbamt,
       '人民币'     c_clmfee_cur,
       /*CASE
                             WHEN ic.N_YFJQ_AMT = 0 THEN
                              ic.T_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_DUTY_LST
                                WHERE C_IC_RDR_LST_ID = ic.C_IC_ID)
                             ELSE
                              ic.T_FEE_AMT_CAL *
                             \* decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)) / ic.N_YFJQ_AMT)*\
                           \*无责代赔在2011-11-24前后的处理方式不同*\
                           case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0))/ ic.N_YFJQ_AMT)
                                 else
                                     decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     duty.n_ic_amt/ ic.N_YFJQ_AMT)
                            end
                           END*/
            /*ROUND(nvl(DTL.N_CLM_FEE,0),2)*/nvl(DTL.N_CLM_FEE,0)  AS  n_clmfee_amt,/*原币种已决直接理赔费用,*/
      /*CASE
                             WHEN ic.N_YFJQ_AMT = 0 THEN
                              ic.T_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_DUTY_LST
                                WHERE C_IC_RDR_LST_ID = ic.C_IC_ID)
                             ELSE
                              ic.T_FEE_AMT_CAL *
                             \* decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)) / ic.N_YFJQ_AMT)*\
                           \*无责代赔在2011-11-24前后的处理方式不同*\
                           case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0))/ ic.N_YFJQ_AMT)
                                 else
                                     decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     duty.n_ic_amt/ ic.N_YFJQ_AMT)
                            end
                           END*/
        /*ROUND(nvl(DTL.N_CLM_FEE,0),2)*/nvl(DTL.N_CLM_FEE,0)  AS  n_clmfee_rmbamt,/*折合人民币已决直接理赔费用,*/
       '人民币'     c_nopay_cur,/*未决赔款币种,*/
       0            n_nopay_amt,/*原币种未决赔款,*/
       0            n_nopay_rmbamt,/*折合人民币未决赔款,*/
       '人民币'     c_noclmfee_cur,/*未决直接理赔费用币种,*/
       0            n_noclmfee_amt,/*原币种未决直接理赔费用,*/
       0            n_noclmfee_rmbamt,/*折合人民币未决直接理赔费用,*/
       to_char(M.T_ACCDNT_TM,'yyyy-mm-dd hh24:mi:ss') t_acdnt_tm,/*出险时间,*/
       to_char(M.T_RPT_TM,'yyyy-mm-dd hh24:mi:ss')   t_rpt_tm,/*报案时间,*/
       to_char(M.T_CLM_RGST_TM,'yyyy-mm-dd hh24:mi:ss') T_RGST_TM,/*立案时间,*/
       to_char(DTL.T_ASSESS_TM,'yyyy-mm-dd hh24:mi:ss') t_end_tm,/*结案时间,*/
       '已决'                                           c_pay_mrk,
       m.c_kind_no,
       m.c_prod_no,
       M.C_JY_FLAG --1或空 软通 2 精友
  from /*web_clm_ic              ic,
       web_clm_main            m,
       web_clm_endcase_zm      endcase,
       web_clm_ic_rdr_duty_lst duty,
       web_clm_rpt_zm          rpt,*/
       WEB_FIN_CLM_MAIN           M,
       WEB_FIN_CLM_DETAIL         DTL,
       web_prd_cvrg            cvrg,
       --web_clm_rgst            rgst,
       web_org_dpt             dpt,
       web_org_dpt             dpt2,
       web_prd_prod            prod,
       web_fin_accntquart         acc
 where /*ic.c_clm_no = m.c_clm_no
   and ic.c_ic_id = duty.c_ic_rdr_lst_id
   and m.c_clm_no = endcase.c_clm_no
   and m.c_clm_no = rpt.c_clm_no*/
   --and m.c_inwd_mrk = '0'
      M.C_CLM_NO = DTL.C_CLM_NO

   and acc.c_mrk = '2'
   AND DTL.C_PROD_NO = PROD.C_PROD_NO
   /*and endcase.c_endcase_status = '03'
   and endcase.c_end_type in ('02', '03')
   and ic.c_ic_status = '03'
   and ic.c_ic_type in ('0', '5')
   and ic.n_ic_num = endcase.n_endcase_no*/
   and M.t_rpt_tm <= acc.t_end_tm
   and DTL.T_ASSESS_TM <= acc.t_end_tm
   and DTL.T_ASSESS_TM >= acc.t_bgn_tm
   and substr(DTL.C_INSRNC_CDE, 1, 6) = cvrg.c_cvrg_no
   --and m.c_clm_no = rgst.c_clm_no
   and dpt.c_dpt_cde = substr(m.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(m.c_dpt_cde,1,4)
   AND DTL.N_SUM_ESTMT_AMT + DTL.N_CLM_FEE <> 0
   AND DTL.C_CLM_MAINSTATUS IN ('38','39') --结案状态
   AND M.C_PROD_NO <> '0320'
   and DTL.c_prod_no <> '0320'
   AND m.c_kind_no = '03'
   AND DTL.C_KIND_NO = '03'
/*select --已决赔款 商业车险
       c_clm_no  ,c_rpt_no ,c_ply_no ,t_insrnc_bgn_tm ,t_insrnc_end_tm ,
       c_dpt_cnm1 ,c_dpt_cnm2,c_kind_name ,c_prod_name ,c_cvrg_name ,c_group_mrk ,c_stk_mrk ,
       c_inwd_mrk ,C_RS_MRK,c_pay_cur ,n_pay_amt ,n_pay_rmbamt ,
       c_clmfee_cur ,n_clmfee_amt ,n_clmfee_rmbamt ,
       c_nopay_cur ,n_nopay_amt ,n_nopay_rmbamt ,
       c_noclmfee_cur ,n_noclmfee_amt ,n_noclmfee_rmbamt ,
       t_acdnt_tm , t_rpt_tm ,T_RGST_TM ,t_end_tm,c_pay_mrk,c_kind_no,c_prod_no,c_jy_flag
from(
select m.c_clm_no c_clm_no,--赔案号,
       ''         c_rpt_no,--报案号,
       m.c_ply_no c_ply_no,--保单号,
       to_char(m.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_bgn_tm,--保单保险起期,
       to_char(m.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_end_tm,--保单保险止期,
       --dpt.c_dpt_cnm     c_dpt_cnm,--机构名称,
       case when substr(m.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm1,
       dpt2.c_dpt_cnm  as c_dpt_cnm2,
       '商业车险'        c_kind_name,--险类,
       prod.c_nme_cn     c_prod_name,--产品,
       cvrg.c_nme_cn     c_cvrg_name,--险别,
       '个人'            c_group_mrk,--团单标志,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no
              and rownum = 1 ) as c_stk_mrk,--股东标志,
       decode(nvl(m.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,--分入标志,
       '---'        as C_RS_MRK ,--是否人伤
       '人民币'     c_pay_cur,--已决赔款币种,
       nvl(rdr.N_IC_AMT, 0) +nvl(rdr.n_help_amt,0)+
      (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            --nvl(rdr.n_prepay_amt, 0)
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end )
            end)
        n_pay_amt,--原币种已决赔款,
       nvl(rdr.N_IC_AMT, 0)+nvl(rdr.n_help_amt,0)+
       (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
           --nvl(rdr.n_prepay_amt, 0)
           (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end )
           end)
        as  n_pay_rmbamt,--折人民币已决赔款,
       '人民币'     c_clmfee_cur,--已决直接理赔费用币种,
        \*CASE WHEN ic.N_YFSY_AMT = 0 THEN
                  ic.B_FEE_AMT_CAL /
                       (SELECT COUNT(1)
                           FROM WEB_CLM_IC_RDR_LST
                           WHERE C_IC_ID = ic.C_IC_ID)
                      ELSE
                         ic.B_FEE_AMT_CAL *
                            decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     rdr.n_ic_amt / ic.N_YFSY_AMT)
                      END  原币种已决直接理赔费用,*\
       CASE when (select count(1) from web_clm_other_fee_lst lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (
                         case    WHEN ic.N_YFSY_AMT = 0 THEN
                              ic.B_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_LST
                                WHERE C_IC_ID = ic.C_IC_ID)
                             ELSE
                              ic.B_FEE_AMT_CAL *
                              decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     (rdr.n_ic_amt+nvl(rdr.n_help_amt,0)) / ic.N_YFSY_AMT)
                           END)end  \*payfee2,--*\n_clmfee_amt,--原币种已决直接理赔费用,
       \*CASE WHEN ic.N_YFSY_AMT = 0 THEN
                 ic.B_FEE_AMT_CAL /
                   (SELECT COUNT(1)
                      FROM WEB_CLM_IC_RDR_LST
                      WHERE C_IC_ID = ic.C_IC_ID)
              ELSE
                ic.B_FEE_AMT_CAL *
                  decode(ic.N_YFSY_AMT,
                     0,
                     0,
                     rdr.n_ic_amt / ic.N_YFSY_AMT)
             END    折合人民币已决直接理赔费用,*\
       CASE when (select count(1) from web_clm_other_fee_lst lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (
                         case    WHEN ic.N_YFSY_AMT = 0 THEN
                              ic.B_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_LST
                                WHERE C_IC_ID = ic.C_IC_ID)
                             ELSE
                              ic.B_FEE_AMT_CAL *
                              decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     (rdr.n_ic_amt+nvl(rdr.n_help_amt,0)) / ic.N_YFSY_AMT)
                           END)end   n_clmfee_rmbamt,--折合人民币已决直接理赔费用,
       '人民币'     c_nopay_cur,--未决赔款币种,
       0            n_nopay_amt,--原币种未决赔款,
       0            n_nopay_rmbamt,--折合人民币未决赔款,
       '人民币'     c_noclmfee_cur,--未决直接理赔费用币种,
       0            n_noclmfee_amt,--原币种未决直接理赔费用,
       0            n_noclmfee_rmbamt,--折合人民币未决直接理赔费用,
       to_char(rpt.t_acdnt_tm,'yyyy-mm-dd hh24:mi:ss')   t_acdnt_tm,--出险时间,
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')     t_rpt_tm,  --报案时间,
       to_char(RGST.T_RGST_TM,'yyyy-mm-dd hh24:mi:ss')   T_RGST_TM, --立案时间,
       to_char(endcase.t_end_tm,'yyyy-mm-dd hh24:mi:ss') t_end_tm,   --结案时间
       '已决'                                            c_pay_mrk,
       m.c_kind_no,
       m.c_prod_no,
       '1' c_jy_flag --1 软通 2 精友
  from web_clm_ic         ic,
       web_clm_main       m,
       web_clm_endcase_zm endcase,
       web_clm_ic_rdr_lst rdr,
       web_clm_rpt_zm     rpt,
       web_clm_rgst       rgst,--立案表
       --web_prd_kind       kind,
       web_prd_prod       prod,
       web_prd_cvrg       cvrg,
       web_org_dpt        dpt,
       web_org_dpt        dpt2,
       web_fin_accntquart      acc
 where ic.c_clm_no = m.c_clm_no
   and ic.c_ic_id = rdr.c_ic_id
   and m.c_clm_no = rpt.c_clm_no
   and m.c_clm_no = endcase.c_clm_no
   and m.c_inwd_mrk = '0'
   and acc.c_mrk = '2'
   and endcase.c_endcase_status = '03'
   and endcase.c_end_type in ('02', '03')
   and ic.c_ic_status = '03'
   and endcase.t_end_tm >= acc.t_bgn_tm
   and ic.n_ic_num = endcase.n_endcase_no
   and rpt.t_rpt_tm <= acc.t_end_tm
   and endcase.t_end_tm <= acc.t_end_tm
   --and m.c_kind_no = kind.c_kind_no
   and m.c_prod_no = prod.c_prod_no
   and substr(rdr.c_rdr_cde, 1, 6) = cvrg.c_cvrg_no
   and m.c_clm_no = rgst.c_clm_no
   and dpt.c_dpt_cde = substr(m.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(m.c_dpt_cde,1,4)
   --20140111增加精友理赔数据
   UNION ALL
   select m.c_clm_no c_clm_no,
       ''         c_rpt_no,
       m.c_ply_no c_ply_no,
       to_char(BASE.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_bgn_tm,
       to_char(BASE.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_end_tm,
       case when substr(m.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm1,
       dpt2.c_dpt_cnm  as c_dpt_cnm2,
       '商业车险'        c_kind_name,--险类,
       prod.c_nme_cn     c_prod_name,--产品,
       cvrg.c_nme_cn     c_cvrg_name,--险别,
       '个人'        c_group_mrk,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no
              and rownum = 1 ) as c_stk_mrk,
       decode(nvl(m.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,
       '---'        as C_RS_MRK ,\*是否人伤*\
       '人民币'     c_pay_cur,
       (NVL(R.N_AMT,0) + NVL(R.N_CHECKLOS_HELP_FEE,0)) n_pay_amt,--原币种已决赔款,
       (NVL(R.N_AMT,0) + NVL(R.N_CHECKLOS_HELP_FEE,0)) n_pay_rmbamt,
       '人民币'     c_clmfee_cur,
       NVL(r.n_clmfee_amt,0)  n_clmfee_amt,\*原币种已决直接理赔费用,*\
       NVL(r.n_clmfee_amt,0)  n_clmfee_rmbamt,\*折合人民币已决直接理赔费用,*\
       '人民币'     c_nopay_cur,\*未决赔款币种,*\
       0            n_nopay_amt,\*原币种未决赔款,*\
       0            n_nopay_rmbamt,\*折合人民币未决赔款,*\
       '人民币'     c_noclmfee_cur,\*未决直接理赔费用币种,*\
       0            n_noclmfee_amt,\*原币种未决直接理赔费用,*\
       0            n_noclmfee_rmbamt,\*折合人民币未决直接理赔费用,*\
       to_char(m.t_acdnt_tm,'yyyy-mm-dd hh24:mi:ss') t_acdnt_tm,\*出险时间,*\
       to_char(m.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')   t_rpt_tm,\*报案时间,*\
       to_char(m.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') T_RGST_TM,\*立案时间,*\
       to_char(R.t_Update,'yyyy-mm-dd hh24:mi:ss') t_end_tm,\*结案时间,*\
       '已决'                                           c_pay_mrk,
       m.c_kind_no,
       m.c_prod_no,
       '2' c_jy_flag --1 软通 2 精友
  from WEB_CLM_MAIN_JY            m,
       WEB_PLY_BASE             BASE,
       WEB_CLM_READY_AMT       R,
       web_prd_cvrg            cvrg,
       web_org_dpt             dpt,
       web_org_dpt             dpt2,
       web_prd_prod            prod,
       web_fin_accntquart         acc
 where m.c_clm_no = r.c_clm_main_id
   and m.t_rpt_tm <= acc.t_end_tm --报案时间在评估月内的数据
   --and m.t_rpt_tm >= acc.t_bgn_tm
   and R.t_Update <= acc.t_end_tm
   and R.t_Update >= acc.t_bgn_tm
   and substr(R.c_Rdr_Cde, 1, 6) = cvrg.c_cvrg_no(+) --险别
   and m.c_prod_no = prod.c_prod_no
   and R.c_task_type in ('38','39') --结案状态
   and dpt.c_dpt_cde = substr(m.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(m.c_dpt_cde,1,4)
   AND BASE.C_PLY_NO = M.C_PLY_NO
   AND BASE.N_EDR_PRJ_NO = 0 --取对应保单的起止期
   AND m.c_prod_no <> '0320' --商车
   and acc.c_mrk = '2'
   AND R.C_JY_FLAG = '2' --精友数据标识
   \*AND NOT EXISTS
        (SELECT 1 FROM WEB_CLM_CNL_JY CNL WHERE CNL.C_CLM_NO = M.C_CLM_NO)----不存在销案，精友数据销案也会结案*\
   )where n_pay_amt + n_clmfee_amt <> 0*/
/
