CREATE VIEW V_RICLM_SUM AS select --再保分出按险类汇总(保费收入,满期保费,手续费)
       decode(typ,'2','未决赔款','1','已决赔款') as 险类,
       round(max(type1),2) 企业财产险,round(max(type2),2) 家庭财产险,round(max(type3),2) 工程险,round(max(type4),2) 责任保险,
       round(max(type5),2) 信用保证险,round(max(type6),2) 商业车险,round(max(type7),2) 交强险,round(max(type8),2) 船舶保险,
       round(max(type9),2) 货物运输保险,round(max(type10),2) 特殊风险保险,round(max(type11),2) 农业保险,
       round(max(type12),2) 意外伤害保险,round(max(type13),2) 短期健康保险,round(max(type14),2) 其他
from(
select --再保分出按险类汇总(保费收入,满期保费,手续费)
        --decode(typ,'1','未决赔款','2','已决赔款'),
        typ,
        case kindName when '企业财产险' then sum(pay+nopay) else 0 end type1,
        case kindName when '家庭财产险' then sum(pay+nopay) else 0 end type2,
        case kindName when '工程险' then sum(pay+nopay) else 0 end type3,
        case kindName when '责任保险' then sum(pay+nopay) else 0 end type4,
        case kindName when '信用保证险' then sum(pay+nopay) else 0 end type5,
        case kindName when '商业车险' then sum(pay+nopay) else 0 end type6,
        case kindName when '交强险' then sum(pay+nopay) else 0 end type7,
        case kindName when '船舶保险' then sum(pay+nopay) else 0 end type8,
        case kindName when '货物运输保险' then sum(pay+nopay) else 0 end type9,
        case kindName when '特殊风险保险' then sum(pay+nopay) else 0 end type10,
        case kindName when '农业保险' then sum(pay+nopay) else 0 end type11,
        case kindName when '意外伤害保险' then sum(pay+nopay) else 0 end type12,
        case kindName when '短期健康保险' then sum(pay+nopay) else 0 end type13,
        case kindName when '其他' then sum(pay+nopay) else 0 end type14
from(
--再保分出未决赔款
select '2' as typ,kindname,0 as pay,0 as payclmfee,sum(nopay) as nopay ,sum(nopayclmfee)as nopayclmfee  from (
--非车
select '2' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
       case when pend.c_cvrg_no is not null then decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')
         else rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'')  end as  kindName,
       0 as pay,0 as payclmfee,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt * (nvl(pend.n_this_pend,0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm) /clm.n_cal_amt_sum)
         else ced.n_clm_amt * (nvl(pend.n_this_pend,0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm) /clm.n_cal_amt_sum)*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end  nopay,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*(nvl(pend.n_clmfee,0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm)/clm.n_cal_amt_sum)
         else ced.n_clm_amt*(nvl(pend.n_clmfee,0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm)/clm.n_cal_amt_sum)*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end  nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_clm_main      m,
       web_clm_pend      pend,
       web_prd_cvrg      cvrg,
       web_fin_accntquart acc,
       (select c_clm_no,a.n_pend_tms,(CASE WHEN nvl(sum(NVL(a.n_this_pend,0) * get_rate(NVL(a.c_pend_cur,'01'),'01',a.t_end_tm) + nvl(a.n_clmfee,0) * get_rate(NVL(a.c_Clmfee_Cur,'01'),'01',a.t_end_tm)),1) = 0 THEN 1 ELSE nvl(sum(NVL(a.n_this_pend,0) * get_rate(NVL(a.c_pend_cur,'01'),'01',a.t_end_tm) + nvl(a.n_clmfee,0) * get_rate(NVL(a.c_Clmfee_Cur,'01'),'01',a.t_end_tm)),1) END) n_cal_amt_sum
          from web_clm_pend a,web_fin_accntquart a
         where a.t_pend_tm <= a.t_end_tm and a.c_mrk = '2' group by c_clm_no,n_pend_tms) clm
 where due.c_clm_no = ced.c_clm_no
   and clm.c_clm_no = pend.c_clm_no
   and clm.n_pend_tms = pend.n_pend_tms
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_clm_no = m.c_clm_no
   and due.c_status IN ('B','C')--= 'C'
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   --and trunc(due.t_ridue_tm) <= acc.t_end_tm
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   and pend.c_clm_no = due.c_clm_no
   and acc.c_mrk = '2'
   and pend.c_cvrg_no = cvrg.c_cvrg_no(+)
   and pend.n_pend_tms =
       (select max(n_pend_tms) from web_clm_pend
         where c_clm_no = pend.c_clm_no
           and t_pend_tm <= acc.t_end_tm)
   and pend.c_pend_source <> '6'
    and not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and c.t_cnl_tm <=acc.t_end_tm) or
            ( c.c_cnl_typ='1' and c.t_chk_tm <= acc.t_end_tm
             and ((c.t_renew_tm is not null and c.t_renew_tm > acc.t_end_tm) or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)
                                  from web_clm_cancel
                                 where t_chk_tm <= acc.t_end_tm
                                   and c_chk_conc = '0'
                                   and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1'))
            and  c.c_chk_conc = '0' )  and c_clm_no = due.c_clm_no)
--商车未决赔款
union all
select '2' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
        rpfunction.getKindName(substr(due.c_prod_no,1,2),due.c_prod_no,'')  as  kindName,
       0 as pay,0 as payclmfee,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*(DTL.N_SUM_ESTMT_AMT/due.n_ri_clm_amt)
         else ced.n_clm_amt*(DTL.N_SUM_ESTMT_AMT/due.n_ri_clm_amt)*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end  nopay,
       0 nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       WEB_FIN_CLM_DETAIL DTL,-- ready,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   --and substr(ready.c_rdr_cde,1,6) = cvrg.c_cvrg_no
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   --and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') /*从201308开始有分出赔案*/
   --and due.t_ridue_tm <= acc.t_end_tm
   and DTL.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
   and DTL.C_CLM_NO = due.c_clm_no
   and DTL.N_SEQ_NUM =
       (select max(N_SEQ_NUM)
          from WEB_FIN_CLM_DETAIL DT
         where DT.C_CLM_NO = DTL.C_CLM_NO
           and DT.T_ASSESS_TM <= acc.t_end_tm
           and DT.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
           --and c_jy_flag is null
           )
   AND NOT EXISTS (SELECT 1
      FROM WEB_CLM_CNCL CNL
     WHERE CNL.C_CLM_MAIN_ID = DTL.C_CLM_NO
       AND CNL.C_CHECK_OPN = '1'
       AND CNL.T_CHECK_TM <= acc.t_end_tm
       AND CNL.C_CLM_MAIN_ID NOT IN ('400000103202014000004','400000103202014000010') --对接时产生的重复赔案号，从精友取数
       )
   AND NOT EXISTS (SELECT 1
        FROM WEB_CLM_CNL_JY JY
       WHERE JY.C_CLM_NO = DTL.C_CLM_NO
         AND JY.T_CNL_TM <= acc.t_end_tm
         AND JY.C_CLM_NO NOT IN ('400000103202014000006','400000103202014000009')--对接时产生的重复赔号，从软通取数
         --AND JY.C_CLM_NO <> '400000103202014000006'--特殊处理
         )
    AND DTL.C_CLM_MAINSTATUS NOT IN ('38','39')
    AND DTL.C_KIND_NO = '03'
   /*and due.c_clm_no not in
       (select cncl.c_clm_main_id
          from web_clm_cncl_42 cncl
         where cncl.t_check_tm <= acc.t_end_tm
           and cncl.c_check_opn = '1'
           and cncl.t_check_tm >= to_date('2013-08-01','yyyy-mm-dd')
        )
   and not exists (
            select 1 from web_clm_endcase_zm_42 endcase
            where endcase.c_clm_no = due.c_clm_no
              and endcase.c_endcase_status = '03' --确认结案
              and endcase.c_end_type = '02'       --正常结案
              and endcase.t_end_tm <= acc.t_end_tm)
  and ready.c_jy_flag is null--软通数据*/
/*select '2' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
        rpfunction.getKindName(substr(due.c_prod_no,1,2),due.c_prod_no,'')  as  kindName,
       0 as pay,0 as payclmfee,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)
         else ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end  nopay,
       0 nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_clm_ready_amt_42 ready,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   --and substr(ready.c_rdr_cde,1,6) = cvrg.c_cvrg_no
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   --and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   --and due.t_ridue_tm <= acc.t_end_tm
   and ready.t_update >= to_date('2013-08-01','yyyy-mm-dd')
   and ready.c_clm_main_id = due.c_clm_no
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt_42
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <= acc.t_end_tm
           and t_update >= to_date('2013-08-01','yyyy-mm-dd')
           and c_jy_flag is null)
   and due.c_clm_no not in
       (select cncl.c_clm_main_id
          from web_clm_cncl_42 cncl
         where cncl.t_check_tm <= acc.t_end_tm
           and cncl.c_check_opn = '1'
           and cncl.t_check_tm >= to_date('2013-08-01','yyyy-mm-dd')
        )
   and not exists (
            select 1 from web_clm_endcase_zm_42 endcase
            where endcase.c_clm_no = due.c_clm_no
              and endcase.c_endcase_status = '03' --确认结案
              and endcase.c_end_type = '02'       --正常结案
              and endcase.t_end_tm <= acc.t_end_tm)
  and ready.c_jy_flag is null--软通数据
--20140113精友理赔修改
union all
select '2' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
        rpfunction.getKindName(substr(due.c_prod_no,1,2),due.c_prod_no,'')  as  kindName,
       0 as pay,0 as payclmfee,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*(greatest(NVL(ready.n_amt,0)+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)
         else ced.n_clm_amt*(greatest(NVL(ready.n_amt,0)+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end  nopay,
       0 nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_clm_ready_amt_42 ready,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and ready.t_update >= to_date('2013-08-01','yyyy-mm-dd')
   and ready.c_clm_main_id = due.c_clm_no
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt_42
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <= acc.t_end_tm
           AND C_JY_FLAG = '2')
   and NOT EXISTS
       (select 1
          from web_clm_CNL_JY CNL
         where CNL.T_CNL_TM <= acc.t_end_tm
           and CNL.C_CLM_NO = READY.C_CLM_MAIN_ID
        )
  \* and not exists (
            select 1 from web_clm_ready_amt_42 R
            where R.C_CLM_MAIN_ID = due.c_clm_no
              and R.C_TASK_TYPE IN ('38','39') --结案
              and R.T_UPDATE <= acc.t_end_tm
              AND R.C_JY_FLAG = '2'
              )*\
   AND READY.C_JY_FLAG = '2' --精友数据*/
   ) group by kindname
union all
--再保分出已决赔款汇总(new)
--select '2' as typ,kindname ,sum(pay) ,sum(payclmfee) ,0 as nopay,0 as nopayclmfee from (
select
       '1' as typ,
       --rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'') as  kindName,
       case when pend.c_cvrg_no is not null then decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')
         else rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'')  end as  kindName,
       CASE WHEN ced.c_riclm_cur='01' THEN ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))
       ELSE ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))*
            get_rate(ced.c_riclm_cur,'01',acc.t_end_tm) END
            pay,--折合人民币已决赔款,

      case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))
         else ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end   payclmfee,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due due,web_ri_clm_ced ced,
        web_prd_prod prod,web_prd_cvrg  cvrg, web_fin_accntquart acc,
        (select c_clm_no,sum(nvl(n_this_dtmd,0) * get_rate(NVL(c_pend_cur,'01'),'01',a.t_end_tm)) as n_this_dtmd ,sum(nvl(n_clmfee,0) * get_rate(NVL(c_Clmfee_Cur,'01'),'01',a.t_end_tm))as n_clmfee,c_pend_source,c_cvrg_no
        from web_clm_pend ,web_fin_accntquart a
         where t_pend_tm <= a.t_end_tm and a.c_mrk = '2' and c_pend_source='6' group by  c_clm_no,c_pend_source,c_cvrg_no) pend
   where
        due.c_clm_no = ced.c_clm_no
    and due.n_clm_tms =ced.n_clm_tms
    and due.n_rbk_seq=ced.n_rbk_seq
    and due.n_split_seq = ced.n_split_seq
    and due.c_prod_no = prod.c_prod_no
    and cvrg.c_cvrg_no(+) = pend.c_cvrg_no
    and due.c_status IN ('B','C') --= 'C'
    and prod.c_kind_no <> '03'
    and due.n_rbk_seq=0
    and ced.c_cont_cde not in('BB','04','AR') --不是我司
    and due.t_ridue_tm <= acc.t_end_tm
    and due.c_clm_no=pend.c_clm_no
    and pend.c_pend_source='6'
    and acc.c_mrk = '2'
union all
--商车已决赔款
select
       '1' as typ,
       '商业车险' as  kindName,
       ced.n_clm_amt*
            DTL.N_SUM_ESTMT_AMT/decode(nvl(due.n_ri_clm_amt,0),0,1,due.n_ri_clm_amt) as pay,--折合人民币已决赔款,
      0 as payclmfee,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due   due,
       web_ri_clm_ced   ced,
       WEB_FIN_CLM_DETAIL DTL,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   AND due.n_clm_tms = dtl.n_clm_tms
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') /*从201308开始有分出赔案*/
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = DTL.C_CLM_NO
   AND DTL.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
   AND DTL.C_CLM_MAINSTATUS IN ('38','39')
   AND DTL.C_KIND_NO = '03'
  /* and ic.t_ic_tm >= to_date('2013-08-01','yyyy-mm-dd')
   and ic.c_ic_id = rdr.c_ic_id
   and ic.c_clm_no = endcase.c_clm_no
   and ic.n_ic_num = endcase.n_endcase_no*/
/*select
       '1' as typ,
       '商业车险' as  kindName,
       ced.n_clm_amt*
           (rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt as pay,--折合人民币已决赔款,
      ced.n_clm_amt*\*ic.B_FEE_AMT_CAL**\(1-(rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt) as payclmfee,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due   due,
       web_ri_clm_ced   ced,
       web_clm_ic_42        ic,
       web_clm_ic_rdr_lst_42 rdr,
       web_clm_endcase_zm_42 endcase,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = ic.c_clm_no
   and ic.t_ic_tm >= to_date('2013-08-01','yyyy-mm-dd')
   and ic.c_ic_id = rdr.c_ic_id
   and ic.c_clm_no = endcase.c_clm_no
   and ic.n_ic_num = endcase.n_endcase_no
  --20140113精友理理赔修改
  UNION ALL
  select
       '1' as typ,
       '商业车险' as  kindName,
      ced.n_clm_amt*(NVL(READY.N_AMT,0) + NVL(READY.N_CHECKLOS_HELP_FEE,0))/due.n_ri_clm_amt as pay,--折合人民币已决赔款,
      ced.n_clm_amt*(NVL(READY.N_AMT,0) + NVL(READY.N_CHECKLOS_HELP_FEE,0))/due.n_ri_clm_amt as payclmfee,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due   due,
       web_ri_clm_ced   ced,
       web_clm_ready_amt_42 READY,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = ready.c_clm_main_id
   and ready.c_task_type in ('38','39')
   and ready.t_update <= acc.t_end_tm
   AND READY.C_JY_FLAG = '2' --精友数据*/
   --AND NOT EXISTS (SELECT 1 FROM WEB_CLM_CNL_JY CNL WHERE CNL.C_CLM_NO = READY.C_CLM_MAIN_ID)
) group by kindName,typ
)group by typ
--理赔费用
union all
select --再保分出按险类汇总(保费收入,满期保费,手续费)
       decode(typ,'4','直接理赔费用-未决','3','直接理赔费用-已决') as 险类,
       round(max(type1),2) 企业财产险,round(max(type2),2) 家庭财产险,round(max(type3),2) 工程险,round(max(type4),2) 责任保险,
       round(max(type5),2) 信用保证险,round(max(type6),2) 商业车险,round(max(type7),2) 交强险,round(max(type8),2) 船舶保险,
       round(max(type9),2) 货物运输保险,round(max(type10),2) 特殊风险保险,round(max(type11),2) 农业保险,
       round(max(type12),2) 意外伤害保险,round(max(type13),2) 短期健康保险,round(max(type14),2) 其他
from(
select  typ,
        case kindName when '企业财产险' then sum(payclmfee+nopayclmfee) else 0 end type1,
        case kindName when '家庭财产险' then sum(payclmfee+nopayclmfee) else 0 end type2,
        case kindName when '工程险' then sum(payclmfee+nopayclmfee) else 0 end type3,
        case kindName when '责任保险' then sum(payclmfee+nopayclmfee) else 0 end type4,
        case kindName when '信用保证险' then sum(payclmfee+nopayclmfee) else 0 end type5,
        case kindName when '商业车险' then sum(payclmfee+nopayclmfee) else 0 end type6,
        case kindName when '交强险' then sum(payclmfee+nopayclmfee) else 0 end type7,
        case kindName when '船舶保险' then sum(payclmfee+nopayclmfee) else 0 end type8,
        case kindName when '货物运输保险' then sum(payclmfee+nopayclmfee) else 0 end type9,
        case kindName when '特殊风险保险' then sum(payclmfee+nopayclmfee) else 0 end type10,
        case kindName when '农业保险' then sum(payclmfee+nopayclmfee) else 0 end type11,
        case kindName when '意外伤害保险' then sum(payclmfee+nopayclmfee) else 0 end type12,
        case kindName when '短期健康保险' then sum(payclmfee+nopayclmfee) else 0 end type13,
        case kindName when '其他' then sum(payclmfee+nopayclmfee) else 0 end type14
from(

--再保分出已决赔款汇总(new)
--select '2' as typ,kindname ,sum(pay) ,sum(payclmfee) ,0 as nopay,0 as nopayclmfee from (
select
       '3' as typ,
       --rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'') as  kindName,
       case when pend.c_cvrg_no is not null then decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')
         else rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'')  end as  kindName,
       CASE WHEN ced.c_riclm_cur='01' THEN ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))
       ELSE ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))*
            get_rate(ced.c_riclm_cur,'01',acc.t_end_tm) END
            pay,--折合人民币已决赔款,

      case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))
         else ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end   payclmfee,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due due,web_ri_clm_ced ced,
        web_prd_prod prod,web_prd_cvrg      cvrg, web_fin_accntquart acc,
        (select c_clm_no,sum(nvl(n_this_dtmd,0) * get_rate(NVL(c_pend_cur,'01'),'01',a.t_end_tm)) as n_this_dtmd ,sum(nvl(n_clmfee,0) * get_rate(NVL(c_Clmfee_Cur,'01'),'01',a.t_end_tm))as n_clmfee,c_pend_source,c_cvrg_no
        from web_clm_pend ,web_fin_accntquart a
         where t_pend_tm <= a.t_end_tm and a.c_mrk = '2' and c_pend_source='6' group by  c_clm_no,c_pend_source,c_cvrg_no) pend
   where
        due.c_clm_no = ced.c_clm_no
    and due.n_clm_tms =ced.n_clm_tms
    and due.n_rbk_seq=ced.n_rbk_seq
    and due.n_split_seq = ced.n_split_seq
    and due.c_prod_no = prod.c_prod_no
    and due.c_status IN ('B','C') --= 'C'
    and cvrg.c_cvrg_no(+) = pend.c_cvrg_no
    and prod.c_kind_no != '03'
    and due.n_rbk_seq=0
    and ced.c_cont_cde not in('BB','04','AR') --不是我司
    and due.t_ridue_tm <= acc.t_end_tm
    and due.c_clm_no=pend.c_clm_no
    and pend.c_pend_source='6'
    and acc.c_mrk = '2'
--) group by kindName
union all
--商车已决理赔费用
select
       '3' as typ,
       '商业车险' as  kindName,
       /*ced.n_clm_amt*
            DTL.N_SUM_ESTMT_AMT/due.n_ri_clm_amt*/0 as pay,--折合人民币已决赔款,
      ced.n_clm_amt*nvl(DTL.N_CLM_FEE,0)/decode(nvl(due.n_ri_clm_amt,0),0,1,due.n_ri_clm_amt) as payclmfee ,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due   due,
       web_ri_clm_ced   ced,
       WEB_FIN_CLM_DETAIL DTL,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_clm_tms = ced.n_clm_tms
   AND due.n_clm_tms = dtl.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') /*从201308开始有分出赔案*/
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = DTL.C_CLM_NO
   AND DTL.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
   AND DTL.C_CLM_MAINSTATUS IN ('38','39')
   AND DTL.C_KIND_NO = '03'
/*select
       '3' as typ,
       '商业车险' as  kindName,
       ced.n_clm_amt*
           (rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt as pay,--折合人民币已决赔款,
      ced.n_clm_amt*\*ic.B_FEE_AMT_CAL**\(CASE when (select count(1) from web_clm_other_fee_lst lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (case    WHEN ic.N_YFSY_AMT = 0 THEN
                              ic.B_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM web_clm_ic_rdr_lst_42
                                WHERE C_IC_ID = ic.C_IC_ID)
                             ELSE
                              ic.B_FEE_AMT_CAL *
                              decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     (rdr.n_ic_amt+nvl(rdr.n_help_amt,0)) / ic.N_YFSY_AMT)
                           END)end)/due.n_ri_clm_amt as payclmfee,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due   due,
       web_ri_clm_ced   ced,
       web_clm_ic_42        ic,
       web_clm_ic_rdr_lst_42 rdr,
       web_clm_endcase_zm_42 endcase,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = ic.c_clm_no
   and ic.t_ic_tm >= to_date('2013-08-01','yyyy-mm-dd')
   and ic.c_ic_id = rdr.c_ic_id
   and ic.c_clm_no = endcase.c_clm_no
   and ic.n_ic_num = endcase.n_endcase_no
   --and rdr.n_ic_amt + rdr.n_prepay_amt <> 0
--20140113精友理理赔修改
  UNION ALL
  select
       '3' as typ,
       '商业车险' as  kindName,
      ced.n_clm_amt*nvl(READY.n_Amt,0)/due.n_ri_clm_amt as pay,--折合人民币已决赔款,
      ced.n_clm_amt*nvl(READY.n_Clmfee_Amt,0)/due.n_ri_clm_amt as payclmfee,
      0 as nopay,0 as nopayclmfee
   from web_ri_clm_due   due,
       web_ri_clm_ced   ced,
       web_clm_ready_amt_42 READY,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = ready.c_clm_main_id
   and ready.c_task_type in ('38','39')
   and ready.t_update <= acc.t_end_tm
   AND READY.C_JY_FLAG = '2' --精友数据*/
   --AND NOT EXISTS (SELECT 1 FROM WEB_CLM_CNL_JY CNL WHERE CNL.C_CLM_NO = READY.C_CLM_MAIN_ID)
union all
--再保分出未决理赔费用
select '4' as typ,kindname,0 as pay,0 as payclmfee,sum(nopay) as nopay ,sum(nopayclmfee)as nopayclmfee  from (
--商车未决理赔费用
select '4' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
        rpfunction.getKindName(substr(due.c_prod_no,1,2),due.c_prod_no,'')  as  kindName,
       0 as pay,0 as payclmfee,
       0 nopay,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*nvl(DTL.N_CLM_FEE,0)/due.n_ri_clm_amt
         else ced.n_clm_amt*nvl(DTL.N_CLM_FEE,0)/due.n_ri_clm_amt*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       WEB_FIN_CLM_DETAIL DTL,-- ready,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   --and substr(ready.c_rdr_cde,1,6) = cvrg.c_cvrg_no
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   --and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') /*从201308开始有分出赔案*/
   --and due.t_ridue_tm <= acc.t_end_tm
   and DTL.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
   and DTL.C_CLM_NO = due.c_clm_no
   and DTL.N_SEQ_NUM =
       (select max(N_SEQ_NUM)
          from WEB_FIN_CLM_DETAIL DT
         where DT.C_CLM_NO = DTL.C_CLM_NO
           and DT.T_ASSESS_TM <= acc.t_end_tm
           and DT.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
           --and c_jy_flag is null
           )
   AND NOT EXISTS (SELECT 1
      FROM WEB_CLM_CNCL CNL
     WHERE CNL.C_CLM_MAIN_ID = DTL.C_CLM_NO
       AND CNL.C_CHECK_OPN = '1'
       AND CNL.T_CHECK_TM <= acc.t_end_tm
       AND CNL.C_CLM_MAIN_ID NOT IN ('400000103202014000004','400000103202014000010') --对接时产生的重复赔案号，从精友取数
       )
     AND NOT EXISTS (SELECT 1
        FROM WEB_CLM_CNL_JY JY
       WHERE JY.C_CLM_NO = DTL.C_CLM_NO
         AND JY.T_CNL_TM <= acc.t_end_tm
         AND JY.C_CLM_NO NOT IN ('400000103202014000006','400000103202014000009')--对接时产生的重复赔号，从软通取数
         --AND JY.C_CLM_NO <> '400000103202014000006'--特殊处理
         )
     AND DTL.C_CLM_MAINSTATUS NOT IN ('38','39')
     AND DTL.C_KIND_NO = '03'
/*select '4' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
        rpfunction.getKindName(substr(due.c_prod_no,1,2),due.c_prod_no,'')  as  kindName,
       0 as pay,0 as payclmfee,
       0 nopay,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*nvl(ready.n_clmfee_amt,0)/due.n_ri_clm_amt
         else ced.n_clm_amt*nvl(ready.n_clmfee_amt,0)/due.n_ri_clm_amt*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_clm_ready_amt_42 ready,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   --and substr(ready.c_rdr_cde,1,6) = cvrg.c_cvrg_no
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   --and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   --and due.t_ridue_tm <= acc.t_end_tm
   and ready.t_update >= to_date('2013-08-01','yyyy-mm-dd')
   and ready.c_clm_main_id = due.c_clm_no
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt_42
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <= acc.t_end_tm
           and t_update >= to_date('2013-08-01','yyyy-mm-dd'))
   and due.c_clm_no not in
       (select cncl.c_clm_main_id
          from web_clm_cncl_42 cncl
         where cncl.t_check_tm <= acc.t_end_tm
           and cncl.c_check_opn = '1'
           and cncl.t_check_tm >= to_date('2013-08-01','yyyy-mm-dd')
        )
   and not exists (
            select 1 from web_clm_endcase_zm_42 endcase
            where endcase.c_clm_no = due.c_clm_no
              and endcase.c_endcase_status = '03' --确认结案
              and endcase.c_end_type = '02'       --正常结案
              and endcase.t_end_tm <= acc.t_end_tm)
--20140113精友理赔修改
union all
select '4' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
        rpfunction.getKindName(substr(due.c_prod_no,1,2),due.c_prod_no,'')  as  kindName,
       0 as pay,0 as payclmfee,
       0 as nopay,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*nvl(ready.n_clmfee_amt,0)/due.n_ri_clm_amt
         else ced.n_clm_amt*nvl(ready.n_clmfee_amt,0)/due.n_ri_clm_amt*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_clm_ready_amt_42 ready,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no like '03%'
   and due.c_status IN ('B','C')
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and ready.t_update >= to_date('2013-08-01','yyyy-mm-dd')
   and ready.c_clm_main_id = due.c_clm_no
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt_42
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <= acc.t_end_tm
           AND C_JY_FLAG = '2')
   and NOT EXISTS
       (select 1
          from web_clm_CNL_JY CNL
         where CNL.T_CNL_TM <= acc.t_end_tm
           and CNL.C_CLM_NO = READY.C_CLM_MAIN_ID
        )*/
   /*and not exists (
            select 1 from web_clm_ready_amt_42 R
            where R.C_CLM_MAIN_ID = due.c_clm_no
              and R.C_TASK_TYPE IN ('38','39') --结案
              and R.T_UPDATE <= acc.t_end_tm
              AND R.C_JY_FLAG = '2'
              )
   AND READY.C_JY_FLAG = '2' --精友数据*/
union all
--非车未决理赔费用
select '4' as typ,
       --rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'') as  kindName,
       case when pend.c_cvrg_no is not null then decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')
         else rpfunction.getKindName(m.c_kind_no,m.c_prod_no,'')  end as  kindName,
       0 as pay,0 as payclmfee,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt * (nvl(pend.n_this_pend,0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm)/clm.n_cal_amt_sum)
         else ced.n_clm_amt * (nvl(pend.n_this_pend,0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm)/clm.n_cal_amt_sum)*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end  nopay,
       case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*(nvl(pend.n_clmfee,0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm)/clm.n_cal_amt_sum)
         else ced.n_clm_amt*(nvl(pend.n_clmfee,0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm)/clm.n_cal_amt_sum)*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end  nopayclmfee
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_clm_main      m,
       web_clm_pend      pend,
       web_prd_cvrg      cvrg,
       web_fin_accntquart acc,
       (select c_clm_no,a.n_pend_tms,(CASE WHEN nvl(sum(NVL(a.n_this_pend,0) * get_rate(NVL(a.c_pend_cur,'01'),'01',a.t_end_tm) + nvl(a.n_clmfee,0) * get_rate(NVL(a.c_Clmfee_Cur,'01'),'01',a.t_end_tm)),1) = 0 THEN 1 ELSE nvl(sum(NVL(a.n_this_pend,0) * get_rate(NVL(a.c_pend_cur,'01'),'01',a.t_end_tm) + nvl(a.n_clmfee,0) * get_rate(NVL(a.c_Clmfee_Cur,'01'),'01',a.t_end_tm)),1) END) n_cal_amt_sum
          from web_clm_pend a,web_fin_accntquart a
         where a.t_pend_tm <= a.t_end_tm and a.c_mrk = '2' group by c_clm_no,n_pend_tms) clm
 where due.c_clm_no = ced.c_clm_no
   and clm.c_clm_no = pend.c_clm_no
   and clm.n_pend_tms = pend.n_pend_tms
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_clm_no = m.c_clm_no
   and acc.c_mrk = '2'
   and due.c_status IN ('B','C')
   and cvrg.c_cvrg_no(+) = pend.c_cvrg_no
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   --and trunc(due.t_ridue_tm) <= acc.t_end_tm
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   and pend.c_clm_no = due.c_clm_no
   and pend.n_pend_tms =
       (select max(n_pend_tms) from web_clm_pend
         where c_clm_no = pend.c_clm_no
           and t_pend_tm <= acc.t_end_tm)
   and pend.c_pend_source <> '6'
   --撤销案件处理
    and not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and c.t_cnl_tm <=acc.t_end_tm) or
            ( c.c_cnl_typ='1' and c.t_chk_tm <= acc.t_end_tm
             and ((c.t_renew_tm is not null and c.t_renew_tm >acc.t_end_tm) or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)
                                  from web_clm_cancel
                                 where t_chk_tm <= acc.t_end_tm
                                   and c_chk_conc = '0'
                                   and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1'))
            and  c.c_chk_conc = '0' )  and c_clm_no = due.c_clm_no)
   ) group by kindname
) group by kindName,typ
)group by typ
/
