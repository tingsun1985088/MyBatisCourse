CREATE VIEW V_PLY_AMT_MD AS select --按险类汇总(保费收入,满期保费,手续费)
       typ 险类,max(type1) 企业财产险,max(type2) 家庭财产险,max(type3) 工程险,max(type4) 责任保险,
       max(type5) 信用保证险,max(type6) 商业车险,max(type7) 交强险,max(type8) 船舶保险,
       max(type9) 货物运输保险,max(type10) 特殊风险保险,max(type11) 农业保险,
       max(type12) 意外伤害保险,max(type13) 短期健康保险,max(type14) 其他
from (
select  case c.t when '1' then '保费收入'  when '2' then '满期保费' when '3' then '手续费' end typ,
        case kindName when '企业财产险' then sum(nPrm) else 0 end type1,
        case kindName when '家庭财产险' then sum(nPrm) else 0 end type2,
        case kindName when '工程险' then sum(nPrm) else 0 end type3,
        case kindName when '责任保险' then sum(nPrm) else 0 end type4,
        case kindName when '信用保证险' then sum(nPrm) else 0 end type5,
        case kindName when '商业车险' then sum(nPrm) else 0 end type6,
        case kindName when '交强险' then sum(nPrm) else 0 end type7,
        case kindName when '船舶保险' then sum(nPrm) else 0 end type8,
        case kindName when '货物运输保险' then sum(nPrm) else 0 end type9,
        case kindName when '特殊风险保险' then sum(nPrm) else 0 end type10,
        case kindName when '农业保险' then sum(nPrm) else 0 end type11,
        case kindName when '意外伤害保险' then sum(nPrm) else 0 end type12,
        case kindName when '短期健康保险' then sum(nPrm) else 0 end type13,
        case kindName when '其他' then sum(nPrm) else 0 end type14
 from (
--保费收入
select '1' as t,
       a.n_amt as nPrm,
       rpfunction.getKindName(a.c_kind_no,a.c_prod_no,'')  as kindName

 from web_fin_plyedr_md a ,
       web_fin_accntquart acc
where  a.t_cal_tm <= acc.t_end_tm
   and acc.c_mrk = '2'
   --and c_inwd_mrk <> '1'
   AND A.N_AMT <> 0
)c group by c.t,kindName
) group by typ
/
