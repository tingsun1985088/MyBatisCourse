CREATE VIEW V_FIN_TMPDCR AS SELECT
C_BAL_TYPE              ,
C_BANK_CDE              ,
C_BSNS_TYP              ,
C_CAV_FLAG              ,
C_CAV_NO                ,
C_CHA_CDE               ,
C_CHA_CLS               ,
C_CHA_MRK               ,
C_CHECK_NO              ,
C_CHR_CUR_NO            ,
C_COMPANY_CDE           ,
C_CONT_CODE             ,
C_CON_DPT_CDE           ,
C_COST_CDE              ,
C_CURRENT_DPT_CDE       ,
C_CUR_NO                ,
C_DEPARTMENT_CDE        ,
C_DPTACC_NO             ,
C_DPT_CDE               ,
C_FINBANK_CDE           ,
C_FLOW_NO               ,
C_ITEM_NO               ,
C_KIND_NO               ,
C_PAY_NAME              ,
C_PAY_PRSN_CDE          ,
C_PAY_PRSN_NAME         ,
C_PLY_NO                ,
C_PROD_NO               ,
C_RCPT_NO               ,
C_RI_COM                ,
C_RP_TYPE               ,
C_SALEGRP_CDE           ,
C_SBJT_MEMO             ,
C_SBJT_NO               ,
C_SEND_FLAG             ,
C_SEQ_NO                ,
C_SERVICETYPE_NO        ,
C_SLS_CDE               ,
C_VOU_MEMO              ,
C_VOU_NO                ,
N_AMT                   ,
N_EXCH_AMT              ,
N_RATE                  ,
T_CRT_TM                ,
T_END_TM                ,
T_RP_TM
/*
C_CHECK_CDE
C_CHECK_FLAG
C_DIFVOU_NO
C_PERIOD_NAME
C_PREREAL_FLAG
C_VOUCHER_NO
N_TOTAL_AMT
REQUEST_ID

*/
FROM  WEB_FIN_TMP_DCR

/
