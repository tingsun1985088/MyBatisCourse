CREATE VIEW V_RICLM_VHL_PAYJQ AS select /*再保分出已决赔款交强*/
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       duty.c_duty_cnm as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,
       decode(nvl(due.c_stock_mrk, '0'), '192002', '股东', '非股东') as c_stk_mrk,
       cur.c_cur_cnm   as  c_pay_cur,
       sum(ced.n_clm_amt*(duty.n_ic_amt+(case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end ))/due.n_ri_clm_amt)    as n_pay,
       sum(ced.n_clm_amt*(duty.n_ic_amt+(case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end ))/due.n_ri_clm_amt)    as n_pay_rmb,
       cur.c_cur_cnm   as c_clmfee_cur,
       sum(ced.n_clm_amt*ic.T_FEE_AMT_CAL*(1-(duty.n_ic_amt+(case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end ))/due.n_ri_clm_amt))   as n_clmfee,
       sum(ced.n_clm_amt*ic.T_FEE_AMT_CAL*(1-(duty.n_ic_amt+(case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end ))/due.n_ri_clm_amt))   as n_clmfee_rmb,
       '人民币'        as c_nopay_cur,
       0               as n_nopay,
       0               as n_nopay_rmb,
       '人民币'        as c_noclmfee_cur,
       0               as n_noclmfee,
       0               as n_noclmfee_rmb,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm, /*出险时间*/
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,    /*报案时间*/
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,   /*立案时间*/
       ''                                               as t_endcase_tm,/*结案时间*/
       prod.c_kind_no,prod.c_prod_no
  from web_ri_clm_due    due,
       web_ri_clm_ced    ced,
       web_prd_prod      prod,
       web_org_dpt       dpt,
       web_org_dpt       dpt2,
       web_clm_rpt_zm   rpt,
       web_ply_base      base,
       web_bas_fin_cur   cur,
       web_clm_ic        ic,
       web_clm_endcase_zm endcase,
       web_clm_ic_rdr_duty_lst duty,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and due.c_ply_no = base.c_ply_no
   and due.n_edr_prj_no = base.n_edr_prj_no
   and due.c_prod_no = '0320'
   and due.c_clm_no = rpt.c_clm_no
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') /*从201308开始有分出赔案*/
   and due.c_clm_no = ic.c_clm_no
   and ic.c_clm_no = endcase.c_clm_no
   and ic.n_ic_num = endcase.n_endcase_no
   and ic.t_ic_tm >= to_date('2013-08-01','yyyy-mm-dd')
   and rpt.t_rpt_tm >= to_date('2013-08-01','yyyy-mm-dd')
   and ic.c_ic_id = duty.c_ic_rdr_lst_id
 group by
       due.c_clm_no,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
       substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
       prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') ,
       prod.c_kind_no,prod.c_prod_no,duty.c_duty_cnm
/
