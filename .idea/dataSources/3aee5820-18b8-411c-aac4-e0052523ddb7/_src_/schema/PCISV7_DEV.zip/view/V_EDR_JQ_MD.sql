CREATE VIEW V_EDR_JQ_MD AS select --再保前批单明细(非车,交强险)
      nvl(a.c_edr_no, '---') as c_edr_no,
      case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
      dpt2.c_dpt_cnm as  c_dpt_three,
      rpfunction.getKindName(prod.c_kind_no,a.c_prod_no,'')  as c_kind_name,
      prod.c_nme_cn          as c_prod_name,
      '---'                  as c_cvrg_name,
      decode(nvl(a.c_grp_mrk, '0'), '0','个人', '团单')  as c_grp_mrk,
      decode(a.c_stk_mrk,'192002','股东','非股东') as c_stk_mrk, --股东标志
      decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入')  as c_inwd_mrk,
      cur.c_cur_cnm          as c_cur_name,
      case when a.c_ci_mrk = '3' then (select ci.n_ci_amt_var from web_ply_ci ci where ci.c_app_no = a.c_app_no)
          else a.n_amt end  as n_prm,

       'T'||to_char(a.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(a.t_edr_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_bgn_tm,
       'T'||to_char(a.t_edr_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_end_tm,
       get_edrsn(a.c_app_no,prod.c_kind_no) as c_edr_rsn,
       decode(nvl(a.c_edr_type,'1'),'1','一般批改','3','退保','2','注销') as c_edr_type,
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日

       prod.c_kind_no,
       a.c_prod_no,
       --a.t_vehicle_layoff_end_tm as layofftm --停驶止期
       (a.t_vehicle_layoff_end_tm + 1/24/60/60) as resumtm ,--停驶起期+1秒为 复驶起期
       a.t_vehicle_layoff_bgn_tm as layoffbgntm --停驶起期
  from web_fin_plyedr_md a/*,web_ply_base base*/,web_prd_prod prod,
       web_org_dpt dpt,web_bas_fin_cur cur,web_org_dpt dpt2,
       web_fin_accntquart acc
 where acc.c_mrk = '2'
   and a.t_cal_tm <= acc.t_end_tm
   and a.t_cal_tm >= acc.t_bgn_tm
   and nvl(a.c_edr_no, '---') <> '---'
   and a.c_prod_no = prod.c_prod_no
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
   and substr(a.c_dpt_cde,1,4) = dpt2.c_dpt_cde
   and a.c_amt_cur = cur.c_cur_cde
   and a.c_prod_no = '0320'
   AND A.N_AMT <> 0
/
