CREATE VIEW V_FIN_SHARE_DUE AS SELECT
C_BILL_TYP            ,
C_BILL_YM             ,
C_CONT_CDE            ,
C_CRT_CDE             ,
C_DPT_CDE             ,
C_FEE_CUR             ,
C_FEE_TYP             ,
C_PROD_NO             ,
C_RI_COM              ,
C_UPD_CDE             ,
N_FEE_AMT             ,
T_DUE_TM              ,
N_PAID_AMT            ,
T_PAID_TM             ,
T_CRT_TM              ,
T_UPD_TM
/*
C_BILL_MRK
C_BILL_NO
C_BILL_PK_ID
C_BS_ATTR
C_CONT_ID
C_DUE_MRK
C_RIBILL_PK_ID
C_RP_FLAG
C_STOCK_MRK
C_UW_YM
C_XL_MRK
N_BILL_INST
T_BAL_END_TM
*/
FROM WEB_FIN_RIBILL_DUE

/
