CREATE VIEW V_EDR_INWD_MD AS select --再保前批单明细(分入)
       inwd.c_edr_no  as c_edr_no,     --批单号
       dpt.c_dpt_cnm  as c_dpt_cnm,    --机构
       '---'          as c_dpt_three,    --机构
       rpfunction.getKindName(ply.c_kind_no,base.c_prod_no,'')  as c_kind_name, --险类
       prod.c_nme_cn  as c_prod_name,  --产品
       '---'          as c_cvrg_name,  --险别
       '---'          as c_grp_mrk,    --团单标志
       '---'          as c_stk_mrk,    --股东标志
       '分入'         as c_inwd_mrk,   --分入标志
       cur.c_cur_cnm  as c_cur_name,   --币种
       ply.n_amt as n_prm, --原币种批单保费
                  --折人民币原币种批单保费
       'T'||to_char(base.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(base.t_edr_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_bgn_tm, --批单生效日期
       'T'||to_char(base.t_edr_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_end_tm, --批单止期
       get_edrsn(base.c_app_no,ply.c_kind_no) as c_edr_rsn,               --批改原因
       decode(nvl(base.c_edr_type,'1'),'1','一般批改','3','退保','2','注销') as c_edr_type,--批改类型
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_cal_tm,--评估日

       /*ply.c_kind_no,
       base.c_prod_no*/
       rpfunction.getKindNo(ply.c_kind_no ,ply.c_prod_no,'') as c_kind_no,
       ply.c_prod_no    as c_prod_no
from web_fin_plyedr_md ply,
     web_ply_inwd inwd,
     web_ply_base base,
     web_org_dpt dpt,
     web_prd_prod prod,
     web_bas_fin_cur cur,
     web_fin_accntquart acc
where inwd.c_app_no = base.c_app_no
  and base.c_dpt_cde = dpt.c_dpt_cde
  and base.c_edr_no is not null
  and ply.c_edr_no = base.c_edr_no
  and base.c_prod_no = prod.c_prod_no
  and ply.c_amt_cur = cur.c_cur_cde
  and ply.t_cal_tm <= acc.t_end_tm
  and ply.t_cal_tm >= acc.t_bgn_tm
  and acc.c_mrk = '2'
  and ply.c_inwd_mrk = '1'
  AND ply.n_amt <> 0
/
