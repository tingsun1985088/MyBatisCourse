CREATE VIEW V_CLM_NOVHL_PAY AS select --已决赔款 非车险 20140221 非车赔款增加币种修改
       a.c_clm_no  as c_clm_no,
       ''          as c_rpt_no,
       a.c_ply_no  as c_ply_no,
       to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       dpt2.c_dpt_cnm  as 三级机构,
       rpfunction.getKindName(a.c_kind_no,a.c_prod_no,'')  as c_kind_name,
       prod.c_nme_cn     as c_prod_name,
       '---'             as c_cvrg_name,
       (select decode(nvl(plybase.c_grp_mrk,0),0,'个人','团单')
          from web_ply_base plybase where plybase.c_ply_no = a.c_ply_no and plybase.n_edr_prj_no=a.n_edr_prj_no) as c_grp_mrk,
         (select decode(nvl(applic.c_stk_mrk,0),0,'非股东','股东')
         from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no
              and applic.n_edr_prj_no=a.n_edr_prj_no )   as c_stk_mrk,
       decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,
       '---'  c_rs_mrk,
       clmcur.c_Cur_Cnm   as  c_pay_cur,
       nvl(pend.n_this_dtmd, 0)  as n_pay,     --原币种已决赔款,
       nvl(pend.n_this_dtmd, 0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm)  as n_pay_rmb, --折合人民币已决赔款,
       FEECUR.C_CUR_CNM         as c_clmfee_cur,   --已决直接理赔费用币种,
       nvl(pend.n_clmfee, 0)  as n_clmfee,    --原币种已决直接理赔费用,
       nvl(pend.n_clmfee, 0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm)  as n_clmfee_rmb,--折合人民币已决直接理赔费用
       '人民币'     as c_nopay_cur,    --未决赔款币种,
       0            as n_nopay,        --原币种未决赔款,
       0            as n_nopay_rmb,    --折合人民币未决赔款,
       '人民币'     as c_noclmfee_cur, --未决直接理赔费用币种,
       0            as n_noclmfee,     --原币种未决直接理赔费用,
       0            as n_noclmfee_rmb, --折合人民币未决直接理赔费用,
       to_char(acc.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,   --报案时间,
       to_char(RGST.T_RGST_TM,'yyyy-mm-dd hh24:mi:ss')  as t_rgst_tm,  --立案时间,
       to_char(pend.t_Pend_Tm,'yyyy-mm-dd hh24:mi:ss') as t_endcase_tm,--结案时间
       '已决' c_pay_mrk,
       a.c_kind_no,
       a.c_prod_no

  from web_clm_pend pend,
       web_clm_rpt  rpt,
       web_clm_main a,
       --web_prd_kind kind,
       web_clm_accdnt acc,
       web_prd_prod prod,
       web_clm_rgst rgst,
       web_org_dpt  dpt,
       web_org_dpt dpt2,
       /*web_clm_adjust adj,
       web_clm_endcase endcase,*/
       web_fin_accntquart acc,
       web_bas_fin_cur clmcur,
       web_bas_fin_cur feecur
 where pend.c_clm_no = rpt.c_clm_no
   AND NVL(PEND.C_PEND_CUR,'01') = clmcur.c_Cur_Cde
   AND NVL(PEND.C_CLMFEE_CUR,'01') = FEECUR.C_CUR_CDE
   and a.c_inwd_mrk <> '1'
   and acc.c_mrk = '2'
   and pend.c_cvrg_no is null
   and pend.c_pend_source = '6'
   and pend.t_pend_tm >= acc.t_bgn_tm
   and rpt.t_rpt_tm <= acc.t_end_tm
   and pend.t_pend_tm <= acc.t_end_tm
   and nvl(acc.n_acc_tms,1) =
       (case when a.c_kind_no = '11' then (select max(n_acc_tms) from web_clm_accdnt where c_clm_no = a.c_clm_no and t_crt_tm <= acc.t_end_tm) else 1 end )
   and rpt.c_clm_no = a.c_clm_no
   --and a.c_clm_no = pend.c_clm_no
   --and a.c_kind_no = kind.c_kind_no
   and a.c_clm_no=acc.c_clm_no
   and a.c_prod_no = prod.c_prod_no
   and a.c_clm_no = rgst.c_clm_no
   /*and adj.c_clm_no = a.c_clm_no
   and adj.n_clm_tms = a.n_clm_tms
   --and trunc(endcase.t_endcase_tm) >=to_date('2012-10-01','yyyy-mm-dd')
   and adj.c_adjust_pk_id = endcase.c_adjust_pk_id

   and endcase.c_clm_no = a.c_clm_no*/
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(a.c_dpt_cde,1,4)
union all
--已决赔款 非车险(分人)
select a.c_clm_no  as c_clm_no,
       ''          as c_rpt_no,--报案号,
       a.c_ply_no  as c_ply_no,
       to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       dpt.c_dpt_cnm     as c_dpt_cnm,
       '---'             as 三级机构,
       rpfunction.getKindName(a.c_kind_no,a.c_prod_no,'') as c_kind_name,
       prod.c_nme_cn     as c_prod_name,
       '---'             as c_cvrg_name,
       (select decode(nvl(plybase.c_grp_mrk,0),0,'个人','团单')
          from web_ply_base plybase where plybase.c_ply_no = a.c_ply_no and plybase.n_edr_prj_no=a.n_edr_prj_no) as c_grp_mrk,--团单标志,
         (select decode(nvl(applic.c_stk_mrk,0),0,'非股东','股东')
         from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no
              and applic.n_edr_prj_no=a.n_edr_prj_no )   as c_stk_mrk, --股东标志,
       decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,
       '---'  c_rs_mrk,
       clmcur.c_Cur_Cnm        as c_pay_cur,
       nvl(pend.n_this_dtmd, 0)  as n_pay,     -- 原币种已决赔款,
       nvl(pend.n_this_dtmd, 0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm)  as n_pay_rmb, --折合人民币已决赔款,
       FEECUR.C_CUR_CNM             as c_clmfee_cur,--已决直接理赔费用币种,
       nvl(pend.n_clmfee, 0) as n_clmfee,    --原币种已决直接理赔费用,
       nvl(pend.n_clmfee, 0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm) as n_clmfee_rmb,--折合人民币已决直接理赔费用,
       '人民币'     as c_nopay_cur,--未决赔款币种,
       0            as n_nopay,--原币种未决赔款,
       0            as n_nopay_rmb,--折合人民币未决赔款,
       '人民币'     as c_noclmfee_cur,--未决直接理赔费用币种,
       0            as n_noclmfee,--原币种未决直接理赔费用,
       0            as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
       to_char(acc.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm, --报案时间,
       to_char(RGST.T_RGST_TM,'yyyy-mm-dd hh24:mi:ss')  as t_rgst_tm,--立案时间,
       --to_char(pend.t_pend_tm,'yyyy-mm-dd hh24:mi:ss') 结案时间
       to_char(pend.t_pend_tm,'yyyy-mm-dd hh24:mi:ss') as t_endcase_tm,--结案时间
       '已决' c_pay_mrk,
       a.c_kind_no,
       a.c_prod_no

  from web_clm_pend pend,
       web_clm_rpt  rpt,
       web_clm_main a,
       --web_prd_kind kind,
       web_clm_accdnt acc,
       web_prd_prod prod,
       web_clm_rgst rgst,
       web_org_dpt  dpt,
       web_fin_accntquart acc,
       web_bas_fin_cur clmcur,
       web_bas_fin_cur feecur
 where pend.c_clm_no = rpt.c_clm_no
   AND NVL(PEND.C_PEND_CUR,'01') = clmcur.c_Cur_Cde
   AND NVL(PEND.C_CLMFEE_CUR,'01') = FEECUR.C_CUR_CDE
   and a.c_inwd_mrk = '1'
   and acc.c_mrk = '2'
   and pend.c_cvrg_no is null
   and pend.c_pend_source = '6'
   and pend.t_pend_tm >= acc.t_bgn_tm
   and pend.t_pend_tm <= acc.t_end_tm
   AND rpt.t_rpt_tm <= acc.t_end_tm
   and rpt.c_clm_no = a.c_clm_no
   --and a.c_clm_no = pend.c_clm_no
   --and a.c_kind_no = kind.c_kind_no
   and a.c_clm_no=acc.c_clm_no
   and a.c_prod_no = prod.c_prod_no
   and a.c_clm_no = rgst.c_clm_no(+)
   and dpt.c_dpt_cde = a.c_dpt_cde
/
