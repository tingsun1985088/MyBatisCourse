CREATE VIEW V_CORE_PSN AS SELECT T.C_EMP_CDE AS PSN_CODE, --代码
           T.C_EMP_CNM AS PSN_NAME, --名称
           T.C_DPT_CDE AS DEPT_CODE, -- 所属机构代码
           T.C_CTFCT_TYP AS CARD_TYPE, -- 证件类型
           T.C_CTFCT_NO AS CARD_NO, -- 证件号码
           T.C_TEL AS TEL_NO, -- 电话
           T.C_EMAIL AS EMAIL, -- 邮箱
           '' AS ADDR --地址（核心目前没有员工地址信息）
      FROM WEB_ORG_EMP T
     WHERE T.C_EMP_CDE IN (SELECT C_SLS_CDE FROM WEB_ORG_SALES) -- 临时使用判断条件，后续员工表总会增加字段判断是否为业务员
/
