CREATE VIEW V_FIN_CAVBILL AS SELECT
C_BANKRET_TM   		,
C_BFN_NO                ,
C_CARD_NO               ,
C_CAV_PK_ID             ,
C_CHECK_CDE             ,
C_CHECK_FLAG            ,
C_CHECK_MEMO            ,
C_CUR_CDE               ,
C_DPT_CDE               ,
C_GATHER_FLAG           ,
C_OPER_CDE              ,
C_POS_NO                ,
C_REF_CDE               ,
C_REPLACE_FLAG          ,
C_RP_TYPE               ,
N_SUM_AMT               ,
T_CAV_TM                ,
T_CHECK_TM              ,
T_UPD_TM                /*,
C_SREF_NO               ,
C_UPD_CDE               ,
T_CRT_TM                ,
C_CRT_CDE               ,
C_MULTICAV_FLAG         ,*/
FROM web_fin_cav_bill

/
