CREATE VIEW V_FIN_CHECK AS SELECT
C_BANK_CDE        ,
C_CHECK_CDE       ,
C_CHECK_NO        ,
C_CUR_CDE         ,
C_FLAG            ,
C_PLY_NO          ,
C_PRINT_NO        ,
C_RCPT_NO         ,
N_AMT             ,
T_CRT_TM          ,
T_UPD_TM

/*
C_EDR_NO
C_PRMDUE_PK_ID

*/

FROM WEB_FIN_CHECK

/
