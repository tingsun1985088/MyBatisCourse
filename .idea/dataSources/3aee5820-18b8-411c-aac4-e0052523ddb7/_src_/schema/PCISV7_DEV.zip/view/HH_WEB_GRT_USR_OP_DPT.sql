CREATE VIEW HH_WEB_GRT_USR_OP_DPT AS SELECT
c_oper_id as c_oper_id,
c_dpt_cde as c_dpt_cde
FROM web_grt_usr_op_dpt
/
