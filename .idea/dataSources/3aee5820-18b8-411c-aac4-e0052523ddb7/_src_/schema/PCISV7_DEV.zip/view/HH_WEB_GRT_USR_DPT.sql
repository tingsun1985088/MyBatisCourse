CREATE VIEW HH_WEB_GRT_USR_DPT AS SELECT
c_pk_id as c_pk_id,
c_oper_id as c_oper_id,
c_dpt_cde as c_dpt_cde,
c_dat_dpt_cde as c_dat_dpt_cde,
c_sub_dpt as c_sub_dpt
FROM web_grt_usr_dpt
/
