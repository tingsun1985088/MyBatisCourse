CREATE VIEW V_FIN_CAVOBJECT AS SELECT
C_BBXRXLC_LB						,
C_BSNS_TYP              ,
C_CAV_DIR               ,
C_CHA_CDE               ,
C_CHA_CLS               ,
C_CURT_DPT_CDE          ,
C_CUR_CDE               ,
C_CUSTOMER_ACCOUNTS     ,
C_DPT_CDE               ,
N_ITEM_NO               ,
C_PAYER_NME             ,
C_PRE_FLAG              ,
C_PROD_NO               ,
C_SBJT_NO               ,
C_SLS_CDE               ,
N_AMT                   ,
N_PRE_AMT               ,

C_CAV_PK_ID,
C_OPREMNY_PK_ID,
1

/*
C_CAVOBJ_PK_ID					,
C_CAVRPTYP_PK_ID        ,
C_CAV_PK_ID             ,
C_CRT_CDE               ,
C_OPREMNY_PK_ID         ,
C_UPD_CDE               ,
T_CRT_TM                ,
T_UPD_TM
*/
FROM WEB_FIN_CAV_OBJ

/
