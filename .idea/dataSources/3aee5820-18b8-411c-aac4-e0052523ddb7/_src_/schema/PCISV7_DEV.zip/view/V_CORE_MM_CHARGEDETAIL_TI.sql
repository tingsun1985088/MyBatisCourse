CREATE VIEW V_CORE_MM_CHARGEDETAIL_TI AS (SELECT T.DATATYPE,
           c."ID",
           c."SEQCHARGE",
           c."SUBCOMPANY",
           c."POLICYNO",
           c."ENDORSENO",
           'CNY' AS currencycode,
           ---  c."CURRENCYCODE",
           c."CLASSESCODE",
           -- c."AMOUNT",
           Get_Rate_New (
              DECODE (c.currencycode,
                      'CNY', '01',
                      'HKD', '02',
                      'USD', '03',
                      'GBP', '04',
                      'EUR', '12'),
              '01',
              c.AMOUNT,
              ti.startdate,
              ti.signdate,
              0)
              AS AMOUNT,
           c."BATCHID",
           c."SOURCE",
           c."STATUS",
           c."SUCFLAG",
           c."SUMCYC",
           c."RETURNMSG",
           c."C_CRT_CDE",
           c."T_CRT_TM",
           c."T_UPD_TM",
           c."C_UPD_CDE"
      FROM MM_CHARGEDETAIL_TI C
           LEFT JOIN MM_POLICYLIST_TI T
              ON C.SEQCHARGE = T.ID
           LEFT JOIN mm_policy_ti ti
              ON ti.policyno = t.policyno AND ti.id = t.seqpolicy
     WHERE t.billno IS NOT NULL AND ti.certitype = '3' ---WHERE t.datatype='01'--手续费
                                                      ---datatype 请参见收费提供的接口文档
                                                              ---billno 专为销管设定
   )
/
