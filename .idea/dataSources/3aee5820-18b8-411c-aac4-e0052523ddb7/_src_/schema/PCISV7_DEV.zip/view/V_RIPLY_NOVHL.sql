CREATE VIEW V_RIPLY_NOVHL AS select --再保分出保单明细
       ply.c_ply_no   as c_ply_no,
       case when substr(ply.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm) as 三级机构,
       rpfunction.getKindName(ply.c_kind_no,ply.c_prod_no,'')  as c_kind_name,
       prod.c_nme_cn  as c_prod_name,
       '---'          as c_cvrg_name,
       decode(nvl(base.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk,
       decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东') as c_stk_mrk,
       sum(ply.n_prm)/base.n_prm as n_split_prop,--分出比例,
       cur.c_cur_cnm      as c_prmcur_name,--分出保费保单的币种,
       sum(ply.n_prm) as n_prm,--原币种分出保费保单,
       sum(case when ply.c_prm_cur = '01' then ply.n_prm
         else ply.n_prm*
           get_rate(ply.c_prm_cur,'01',acc.t_end_tm) end) as n_prm_rmb,--折合人民币分出保费保单,
       to_char(ply.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       to_char(ply.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss')  as t_insrnc_bgn_tm,--保单保险起期,
       --to_char(p.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')  as t_insrnc_end_tm,--保单保险止期,
       case when base.c_inwd_mrk = '1' and to_char(ply.t_insrnc_end_tm,'hh24:mi:ss')='00:00:00' then
           to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59' else to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')
       end as t_insrnc_end_tm,--保单保险止期,
       --decode(to_char(p.t_insrnc_end_tm,'hh24:mi:ss'),'00:00:00',to_char(p.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59',to_char(p.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')) as t_insrnc_end_tm,
       to_char(trunc(acc.t_end_tm),'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       cur.c_cur_cnm    as c_feecur_name,--摊回手续费币种,
       sum(ply.n_fee)        as n_fee,--原币种摊回手续费,
       sum(case when ply.c_prm_cur = '01' then ply.n_fee
         else ply.n_fee*
           get_rate(ply.c_prm_cur,'01',acc.t_end_tm) end)  as n_fee_rmb,--折合人民币摊回手续费,
       ply.n_fee_prop as n_comm_prpt,--手续费比率
       prod.c_kind_no,ply.c_prod_no,
       sum(case when base.c_prm_cur = '01' then base.n_prm
         else base.n_prm*
           get_rate(base.c_prm_cur,'01',acc.t_end_tm) end) as n_oprm_rmb
      from web_fin_ri_plyedr ply,
           web_ply_base base,
           web_ply_applicant app,
           web_prd_prod prod,
           web_org_dpt dpt,
           web_bas_fin_cur cur,
           web_org_dpt dpt2,
           web_fin_accntquart acc
      where prod.c_prod_no = ply.c_prod_no
        and ply.c_app_no = base.c_app_no
        and ply.c_app_no = app.c_app_no(+)
        and ply.c_kind_no <> '03'
        and dpt.c_dpt_cde = substr(ply.c_dpt_cde,1,2)
        and substr(ply.c_dpt_cde,1,4) = dpt2.c_dpt_cde
        and ply.c_ply_no= base.c_ply_no
        and base.n_edr_prj_no = 0
        and ply.n_edr_prj_no = 0
        and ply.c_prm_cur = cur.c_cur_cde
        and acc.c_mrk = '2'
        and ply.t_due_tm <= acc.t_end_tm
        ------------------
        group by ply.c_ply_no,
                 ply.c_kind_no,ply.c_prod_no,
                 base.c_inwd_mrk,
                 case when substr(ply.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end,   --机构
                 dpt2.c_dpt_cnm,
                 prod.c_nme_cn,--ced.c_ri_brkr,
                 dpt.c_dpt_cnm,base.n_prm,
                 ply.c_prod_no,prod.c_kind_no,
                 cur.c_cur_cnm,
                 ply.c_prm_cur,base.c_inwd_mrk,
                 decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东'),
                 --decode(base.c_ci_mrk,'3',base.n_ci_own_prm,nvl(p.n_prm, 0)),
                 ply.n_fee_prop,base.c_grp_mrk,trunc(acc.t_end_tm),
                 to_char(ply.t_udr_tm,'yyyy-mm-dd hh24:mi:ss'),
                 to_char(ply.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
                 case when base.c_inwd_mrk = '1' and to_char(ply.t_insrnc_end_tm,'hh24:mi:ss')='00:00:00' then
                     to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59' else to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')
                 end
/
