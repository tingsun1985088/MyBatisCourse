CREATE VIEW V_CORE_DEPT AS SELECT T.C_DPT_CDE     AS DEPT_CODE, -- 机构编码
           T.C_DPT_CNM     AS DEPT_NAME, -- 机构名称
           T.N_DPT_LEVL    AS LV, -- 机构等级（从0开始）
           T.C_SNR_DPT     AS UP_CODE, -- 上级机构
           T.C_DPT_REL_CDE AS TREE_INF, -- 层级关系
           T.C_IS_VALID    AS STATUS -- 状态（0无效、1有效）
      FROM WEB_ORG_DPT T
/
