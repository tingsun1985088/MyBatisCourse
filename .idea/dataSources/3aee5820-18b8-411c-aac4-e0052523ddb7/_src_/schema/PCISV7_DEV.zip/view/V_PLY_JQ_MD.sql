CREATE VIEW V_PLY_JQ_MD AS select --再保前保单明细(交强险)
       'P'||a.c_ply_no    as c_ply_no,    --保单号
       case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
       dpt2.c_dpt_cnm as  c_dpt_three,
       --rpfunction.getKindName(prod.c_kind_no,a.c_prod_no,'')  as c_kind_name, --险类
       '交强险'      as c_kind_name, --险类
       --prod.c_nme_cn as c_prod_name,   --产品
       '机动车交通事故责任强制保险'  as c_prod_name,   --产品
       '---'         as c_cvrg_name,   --险别
       decode(nvl(a.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk, --团单标志
       decode(a.c_stk_mrk,'192002','股东','非股东') as c_stk_mrk, --股东标志
       decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入')  as c_inwd_mrk,--分入标志
       cur.c_cur_cnm as c_prmcur_name,                                  --币种
       a.n_Amt as n_prm,
       'T'||to_char(a.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm, --保险起期
       'T'||to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm, --保险止期
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_cal_tm,
       '03'           as c_kind_no,
       a.c_prod_no    as c_prod_no,
       a.t_insrnc_bgn_tm as bgnTm,
       a.t_insrnc_end_tm as endTm
  from --web_ply_base a, WEB_ply_FEE f,
       web_fin_plyedr_MD a,
       web_bas_fin_cur cur,
       web_org_dpt dpt,web_org_dpt dpt2,WEB_FIN_ACCNTQUART acc
 where acc.c_mrk = '2'
   and a.t_cal_tm <= acc.t_end_tm
   and a.t_cal_tm >= acc.t_bgn_tm
   and nvl(a.c_edr_no, '---') = '---'
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
   and substr(a.c_dpt_cde,1,4) = dpt2.c_dpt_cde
   and a.C_AMT_CUR = cur.c_cur_cde
   and a.c_prod_no = '0320'
/
