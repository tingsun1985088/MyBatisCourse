CREATE VIEW V_PLY_DETAIL AS select "C_PLY_NO","C_DPT_CNM","三级机构","C_KIND_NAME","C_PROD_NAME","C_CVRG_NAME",
       "C_GRP_MRK","C_STK_MRK","C_INWD_MRK","C_PRMCUR_NAME","N_PRM","N_PRM_RMB",
       "T_UDR_TM","T_INSRNC_BGN_TM","T_INSRNC_END_TM","T_CAL_TM","N_FEE_PROP",
       "C_FEECUR_NAME","N_FEE","N_FEE_RMB"--,"C_KIND_NO","C_PROD_NO"
 from v_ply_inwd a      --分入(保单)
union all
select "C_PLY_NO","C_DPT_CNM","三级机构","C_KIND_NAME","C_PROD_NAME","C_CVRG_NAME",
       "C_GRP_MRK","C_STK_MRK","C_INWD_MRK","C_PRMCUR_NAME","N_PRM","N_PRM_RMB",
       "T_UDR_TM","T_INSRNC_BGN_TM","T_INSRNC_END_TM","T_CAL_TM","N_FEE_PROP",
       "C_FEECUR_NAME","N_FEE","N_FEE_RMB"--,"C_KIND_NO","C_PROD_NO"
 from v_ply_novhl a     --非车(保单)
/
