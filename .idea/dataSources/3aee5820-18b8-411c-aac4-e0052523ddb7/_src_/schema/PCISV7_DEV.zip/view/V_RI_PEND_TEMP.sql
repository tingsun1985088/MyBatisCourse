CREATE VIEW V_RI_PEND_TEMP AS select cd.c_ply_no,
cd.n_split_seq,
cd.c_clm_no ,
cd.n_pend_tms,
cd.t_ridue_tm,
cd.t_accdnt_tm,
cd.n_ri_clm_amt,
cd.c_ri_cur
from web_ri_pend_due cd
where 1=1
and to_char(cd.t_ridue_tm,'yyyy') = '2012'
and to_char(cd.t_ridue_tm,'MM') in ('01','02','03')
           ----and cd.c_status = 'C' --在出季账后才导出清单,所以状态为C,但是现在提前导出清单所以注释
and cd.c_ri_cur = '01'
and cd.c_pend_pk_id like 'zhaow%'

/
