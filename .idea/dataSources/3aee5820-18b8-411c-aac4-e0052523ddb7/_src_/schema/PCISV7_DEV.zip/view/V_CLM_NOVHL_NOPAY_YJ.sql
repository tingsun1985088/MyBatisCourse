CREATE VIEW V_CLM_NOVHL_NOPAY_YJ AS select --非车未决明细(非分人)
         a.c_clm_no      as c_clm_no,
         '---'              as c_rpt_no,
         a.c_ply_no      as c_ply_no,
         to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
         to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
         --dpt.c_dpt_cnm   as 机构名称,--c_dpt_cnm,
         case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
         dpt2.c_dpt_cnm  as c_dpt_three,
         --rpfunction.getKindName(a.c_kind_no,a.c_prod_no,'')  as 险类,--c_kind_name,
         decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')  as c_kind_name,
         prod.c_nme_cn   as c_prod_name,
         '---'           as c_cvrg_name,
         (select decode(nvl(plybase.c_grp_mrk,0),0,'个人','团单')
          from web_ply_base plybase where plybase.c_ply_no = a.c_ply_no
           and plybase.n_edr_prj_no=a.n_edr_prj_no)  as c_grp_mrk,
         (select decode(nvl(applic.c_stk_mrk,0),0,'非股东','股东')
         from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no
              and applic.n_edr_prj_no=a.n_edr_prj_no ) as c_stk_mrk,
         decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,
         '---'        as  c_rs_mrk,
         '人民币'     as  c_pay_cur,
         0            as  n_pay,
         0            as  n_pay_rmb,--
         '人民币'     as  c_clmfee_cur,--
         0            as  n_clmfee,--
         0            as  n_clmfee_rmb,--
         clmcur.c_Cur_Cnm     as  c_nopay_cur,--
         nvl(pend.n_this_pend, 0) as n_nopay,--
         nvl(pend.n_this_pend, 0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm) as n_nopay_rmb,--
         FEECUR.C_CUR_CNM     as c_noclmfee_cur, --
         nvl(pend.n_clmfee, 0) as n_noclmfee,--
         nvl(pend.n_clmfee, 0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm) as n_noclmfee_rmb,--
         to_char(accdnt.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--
         to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')       as t_rpt_tm,--
         to_char(RGST.T_RGST_TM,'yyyy-mm-dd hh24:mi:ss')     as t_rgst_tm,--
         ''                                                  as t_endcase_tm,--
         '未决'                                              as c_pay_mrk,
         a.c_kind_no,
         a.c_prod_no
    from web_clm_pend   pend,
         web_clm_main   a,
         web_clm_rpt    rpt,
         web_clm_accdnt accdnt,
         WEB_CLM_RGST   RGST,
         --web_prd_kind   kind,
         web_prd_prod   prod,
         web_org_dpt    dpt,
         web_org_dpt    dpt2,
         web_prd_cvrg   cvrg,
         web_fin_accntquart acc,
         web_bas_fin_cur clmcur,
         web_bas_fin_cur feecur
   where a.c_clm_no = pend.c_clm_no
     and a.c_inwd_mrk <> '1'
     --and a.c_kind_no = kind.c_kind_no
     AND NVL(PEND.C_PEND_CUR,'01') = clmcur.c_Cur_Cde
     AND NVL(PEND.C_CLMFEE_CUR,'01') = FEECUR.C_CUR_CDE
     and a.c_prod_no = prod.c_prod_no
     and a.c_clm_no = rpt.c_clm_no
     and a.c_clm_no = accdnt.c_clm_no
     and a.c_clm_no = RGST.c_Clm_No(+)
     and acc.c_mrk = '2'
     and pend.c_cvrg_no is not null
     and pend.n_pend_tms =
         (select max(n_pend_tms)
            from web_clm_pend
           where c_clm_no = pend.c_clm_no
             and t_pend_tm <= acc.t_end_tm)
     and pend.c_pend_source <> '6'
    and
     --撤销案件处理
      not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and c.t_cnl_tm <= acc.t_end_tm) or
            ( c.c_cnl_typ='1' and c.t_chk_tm <= acc.t_end_tm
             and (c.t_renew_tm is not null and  c.t_renew_tm > acc.t_end_tm or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)
                                  from web_clm_cancel
                                 where t_chk_tm <= acc.t_end_tm
                                   and c_chk_conc = '0'
                                   and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1')
            and  c.c_chk_conc = '0' ))  and c_clm_no = a.c_clm_no)
    and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
    and dpt2.c_dpt_cde = substr(a.c_dpt_cde,1,4)
    and pend.c_cvrg_no = cvrg.c_cvrg_no

union all
--非车未决明细(分人)
select   a.c_clm_no      as c_clm_no,
         ''              as c_rpt_no,
         a.c_ply_no      as c_ply_no,
         to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
         to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
         dpt.c_dpt_cnm   as c_dpt_cnm,
         '---'           as 三级机构,
         --rpfunction.getKindName(a.c_kind_no,a.c_prod_no,'')  as c_kind_name,
         decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')  as 险类,
         prod.c_nme_cn   as c_prod_name,
         '---'           as c_cvrg_name,
         (select decode(nvl(plybase.c_grp_mrk,0),0,'个人','团单')
          from web_ply_base plybase where plybase.c_ply_no = a.c_ply_no and plybase.n_edr_prj_no=a.n_edr_prj_no) as c_grp_mrk,
         (select decode(nvl(applic.c_stk_mrk,0),0,'非股东','股东')
         from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no
              and applic.n_edr_prj_no=a.n_edr_prj_no ) as c_stk_mrk,--  股东标志,
         decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,-- 分入标志,
         '---'        as  c_rs_mrk,
         '人民币'     as  c_pay_cur,--已决赔款币种,
         0            as n_pay,--原币种已决赔款,
         0            as n_pay_rmb,--折合人民币已决赔款,
         '人民币'     as c_clmfee_cur,--已决直接理赔费用币种,
         0            as n_clmfee,--原币种已决直接理赔费用,
         0            as n_clmfee_rmb,--折合人民币已决直接理赔费用,
         clmcur.c_Cur_Cnm     as c_nopay_cur,-- 未决赔款的币种,
         nvl(pend.n_this_pend, 0)  as n_nopay,--原币种未决赔款,
         nvl(pend.n_this_pend, 0) * get_rate(NVL(pend.c_pend_cur,'01'),'01',acc.t_end_tm) as n_nopay_rmb,-- 折合人民币未决赔款,
         FEECUR.C_CUR_CNM     as c_noclmfee_cur, --  未决直接理赔费用币种,
         nvl(pend.n_clmfee, 0)  as n_noclmfee,--原币种未决直接理赔费用,
         nvl(pend.n_clmfee, 0) * get_rate(NVL(pend.c_Clmfee_Cur,'01'),'01',acc.t_end_tm) as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
         to_char(accdnt.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss')  as t_accdnt_tm,-- 出险时间,
         to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')        as t_rpt_tm, --报案时间,
         to_char(RGST.T_RGST_TM,'yyyy-mm-dd hh24:mi:ss')      as t_rgst_tm,--立案时间,
         ''                                                   as t_endcase_tm,--结案时间
         '未决'                                               as c_pay_mrk,
         a.c_kind_no,
         a.c_prod_no
    from web_clm_pend   pend,
         web_clm_main   a,
         web_clm_rpt    rpt,
         web_clm_accdnt accdnt,
         WEB_CLM_RGST   RGST,
         web_prd_prod   prod,
         web_org_dpt    dpt,
         web_prd_cvrg   cvrg,
         web_fin_accntquart acc,
         web_bas_fin_cur clmcur,
         web_bas_fin_cur feecur
   where a.c_clm_no = pend.c_clm_no
     AND NVL(PEND.C_PEND_CUR,'01') = clmcur.c_Cur_Cde
     AND NVL(PEND.C_CLMFEE_CUR,'01') = FEECUR.C_CUR_CDE
     and a.c_inwd_mrk = '1'
     and a.c_prod_no = prod.c_prod_no
     and a.c_clm_no = rpt.c_clm_no
     and a.c_clm_no = accdnt.c_clm_no
     and a.c_clm_no = RGST.c_Clm_No(+)
     and acc.c_mrk = '2'
     and pend.c_cvrg_no is not null
     and pend.n_pend_tms =
         (select max(n_pend_tms)
            from web_clm_pend
           where c_clm_no = pend.c_clm_no
             and t_pend_tm <= acc.t_end_tm)
    and pend.c_pend_source <> '6'
    and
     --撤销案件处理
    not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and c.t_cnl_tm<=acc.t_end_tm) or
            ( c.c_cnl_typ='1' and c.t_chk_tm <= acc.t_end_tm
             and ((c.t_renew_tm is not null and c.t_renew_tm > acc.t_end_tm) or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)
                                  from web_clm_cancel
                                 where t_chk_tm <= acc.t_end_tm
                                   and c_chk_conc = '0'
                                   and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1'))
            and  c.c_chk_conc = '0' )  and c_clm_no = a.c_clm_no)
    and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
    and pend.c_cvrg_no = cvrg.c_cvrg_no
/
