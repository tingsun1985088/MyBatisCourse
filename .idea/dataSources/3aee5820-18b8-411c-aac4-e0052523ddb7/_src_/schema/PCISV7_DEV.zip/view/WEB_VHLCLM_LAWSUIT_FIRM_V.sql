CREATE VIEW WEB_VHLCLM_LAWSUIT_FIRM_V AS (
SELECT c_Pk_Id         AS c_Id,
  c_Law_Firm_Code      AS c_Law_Firm_No,
  c_Law_Firm_Name      AS c_Law_Firm_Nme,
  c_Law_Firm_Head_Name AS c_Ctt_Nme,
  c_Call               AS c_Ctt_Tel,
  c_Contact_Email      AS c_Ctt_Mail,
  t_Signing_Start_Time AS t_Coop_Start_Tm,
  t_Signing_End_Time   AS t_Coop_End_Tm,
  c_Status             AS c_State,
  c_Note               AS c_Rmk,
  '1'                  AS c_New_Flg,
  1                    AS n_Track_Num,
  c_Creator            AS c_Crt_Cde,
  t_Creation_Time      AS t_Crt_Tm,
  c_Modifier           AS c_Upd_Cde,
  t_Upd_Time           AS t_Upd_Tm,
  NULL                 AS c_Trans_Mrk,
  NULL                 AS t_Trans_Tm,
  (SELECT WM_CONCAT(T2.area_name) FROM Web_Vhlclm_LAW_AREA T2 WHERE T2.law_id = a.C_PK_ID) AS c_Address
FROM Web_Vhlclm_Ls_Law_Firm  a
UNION
SELECT t.c_id,
  t.c_law_firm_no,
  t.c_law_firm_nme,
  t.c_ctt_nme,
  t.c_ctt_tel,
  t.c_ctt_mail,
  t.t_coop_start_tm,
  t.t_coop_end_tm,
  t.c_state,
  t.c_rmk,
  t.c_new_flg,
  t.n_track_num,
  t.c_crt_cde,
  t.t_crt_tm,
  t.c_upd_cde,
  t.t_upd_tm,
  t.c_trans_mrk,
  t.t_trans_tm,
  t.c_address
FROM web_vhlclm_lawsuit_firm t
WHERE t.c_new_flg ='1'
)
/
