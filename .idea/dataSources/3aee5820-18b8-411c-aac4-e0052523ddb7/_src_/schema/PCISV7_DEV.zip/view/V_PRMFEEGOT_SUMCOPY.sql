CREATE VIEW V_PRMFEEGOT_SUMCOPY AS select --按险类汇总(保费收入,满期保费,手续费)
       typ 险类,max(type1) 企业财产险,max(type2) 家庭财产险,max(type3) 工程险,max(type4) 责任保险,
       max(type5) 信用保证险,max(type6) 商业车险,max(type7) 交强险,max(type8) 船舶保险,
       max(type9) 货物运输保险,max(type10) 特殊风险保险,max(type11) 农业保险,
       max(type12) 意外伤害保险,max(type13) 短期健康保险,max(type14) 其他
from (
select  case c.t when '1' then '保费收入'  when '2' then '满期保费' when '3' then '手续费' end typ,
        case kindName when '企业财产险' then sum(nPrm) else 0 end type1,
        case kindName when '家庭财产险' then sum(nPrm) else 0 end type2,
        case kindName when '工程险' then sum(nPrm) else 0 end type3,
        case kindName when '责任保险' then sum(nPrm) else 0 end type4,
        case kindName when '信用保证险' then sum(nPrm) else 0 end type5,
        case kindName when '商业车险' then sum(nPrm) else 0 end type6,
        case kindName when '交强险' then sum(nPrm) else 0 end type7,
        case kindName when '船舶保险' then sum(nPrm) else 0 end type8,
        case kindName when '货物运输保险' then sum(nPrm) else 0 end type9,
        case kindName when '特殊风险保险' then sum(nPrm) else 0 end type10,
        case kindName when '农业保险' then sum(nPrm) else 0 end type11,
        case kindName when '意外伤害保险' then sum(nPrm) else 0 end type12,
        case kindName when '短期健康保险' then sum(nPrm) else 0 end type13,
        case kindName when '其他' then sum(nPrm) else 0 end type14
 from (
--保费收入
select '1' as t,
       case when a.c_prm_cur = '01' then
         case
                 when a.n_edr_prj_no = 0 then
                 (case when a.c_ci_mrk = '3' then a.n_ci_own_prm else a.n_prm end)
                 else nvl(a.n_prm_var,0) end
         else (case
                 when a.n_edr_prj_no = 0 then
                 (case when a.c_ci_mrk = '3' then a.n_ci_own_prm else a.n_prm end)
                 else nvl(a.n_prm_var,0) end
              )*
              get_rate(a.c_prm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
               end as nPrm,
       rpfunction.getKindName(kind.c_kind_no,a.c_prod_no,'')  as kindName

 from web_ply_base a ,web_prd_kind kind

where  substr(a.c_prod_no,1,2) = kind.c_kind_no
   and decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_bgn_tm),trunc(a.t_edr_bgn_tm)) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and trunc(a.t_udr_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))

union all
--满期保费
select '2' t,sum(a.N_CAL_AMT) nPrm,a.kind kindName from (
select rpfunction.getKindName(a.c_kind_no,a.c_prod_no,'') as kind,
       sum(a.N_CAL_AMT) N_CAL_AMT--满期保费
  from web_fin_mid_gotprm a
  where trunc(t_cal_tm) = trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
  group by a.c_kind_no, a.c_prod_no
 ) a group by a.kind

union all
--手续费
--非分人
select  '3' typ,
       case when a.c_prm_cur = '01' then nvl(f.N_FEE,0)
         else f.N_FEE* get_rate(a.c_prm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
          end as nPrm,
       rpfunction.getKindName(kind.c_kind_no,a.c_prod_no,'') as  kindname
  from web_ply_base a, WEB_ply_FEE f, web_prd_kind kind
 where  a.c_app_no = f.c_app_no
and decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_bgn_tm),trunc(a.t_edr_bgn_tm)) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and trunc(a.t_udr_tm)<= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and f.C_FEETYP_CDE = 'S'
   and a.c_inwd_mrk <> '1'
   and substr(a.c_prod_no, 1, 2) = kind.c_kind_no
--分入
union all
select  '3' typ,
       case when inwd.c_inwd_cur_cde = '01' then decode(nvl(a.n_edr_prj_no,0),0,inwd.N_INWD_COMM,inwd.n_inwd_comm_var)
         else decode(nvl(a.n_edr_prj_no,0),0,inwd.N_INWD_COMM,inwd.n_inwd_comm_var)*get_rate(inwd.c_inwd_cur_cde,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
       end as nPrm,
       rpfunction.getKindName(kind.c_kind_no,a.c_prod_no,'') as  kindname
  from web_ply_base a,web_ply_inwd inwd, web_prd_kind kind
 where  a.c_app_no = inwd.c_app_no
   and decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_bgn_tm),trunc(a.t_edr_bgn_tm)) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and trunc(a.t_udr_tm)<= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and a.c_inwd_mrk = '1'
   and substr(a.c_prod_no, 1, 2) = kind.c_kind_no
)c group by c.t,kindName
) group by typ
/
