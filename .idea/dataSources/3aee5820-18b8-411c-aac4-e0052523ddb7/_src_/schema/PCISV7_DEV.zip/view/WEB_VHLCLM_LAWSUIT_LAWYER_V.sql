CREATE VIEW WEB_VHLCLM_LAWSUIT_LAWYER_V AS (

SELECT ID             AS C_ID,
  ID                  AS C_LAWYER_NO,
  LAWYERNAME          AS C_LAWYER_NME,
  PROFESSIONALNO      AS C_CERT_NO,
  PHONE               AS C_PHONE,
  CHARGES             AS N_LAW_AMT,
  CARINSURANCECHARGES AS N_WARN_AMT,
  RISKAGENTCHARGES    AS C_WARN_PROP,
  LAWFIRMS            AS C_LAW_FIRM_NO,
  STATE               AS C_STATE,
  NOTE                AS C_RMK,
  '1'                 AS C_NEW_FLG,
  1                   AS N_TRACK_NUM,
  OPERATION           AS C_CRT_CDE,
  CRTTIME             AS T_CRT_TM,
  MODIFIER            AS C_UPD_CDE,
  UPDTIME             AS T_UPD_TM,
	'0' 								as C_LAWYER_TYPR,	
  NULL                AS C_TRANS_MRK,
  NULL                AS T_TRANS_TM
FROM WEB_VHLCLM_LY_LAWYER
UNION
SELECT t.c_id,
  t.c_lawyer_no,
  t.c_lawyer_nme,
  t.c_cert_no,
  t.c_phone,
  TO_CHAR (t.n_law_amt)   AS n_law_amt ,
  TO_CHAR ( t.n_warn_amt) AS n_warn_amt,
  t.c_warn_prop,
  t.c_law_firm_no,
  t.c_state,
  t.c_rmk,
  t.c_new_flg,
  t.n_track_num,
  t.c_crt_cde,
  t.t_crt_tm,
  t.c_upd_cde,
  t.t_upd_tm,
  '1' 			as C_LAWYER_TYPR,	
  t.c_trans_mrk,
  t.t_trans_tm 
  
FROM Web_Vhlclm_Lawsuit_Lawyer t
WHERE t.c_New_Flg = '1' )
/
