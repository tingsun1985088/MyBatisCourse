CREATE VIEW HH_WEB_PRD_PROD AS SELECT
c_prod_no,
c_nme_cn,
c_kind_no,
c_cnm_abr,
c_status,
c_insrnc_long,
c_plyno_flag,
c_rate_flag,
c_inst_flag,
c_fincvrg_flag,
c_clmedr_flag,
c_bs_type,
c_pkg_flag,
c_ins_end_flag,
c_fixed_amt_flag,
c_tab_disp_flag,
c_grp_flag,
c_per_flag,
c_sepa_cvrg_flag,
n_criterion_time,
c_criterion_time_unit
 FROM web_prd_prod
/
COMMENT ON VIEW HH_WEB_PRD_PROD IS '产品基本信息表'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_PROD_NO IS '产品代码'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_NME_CN IS '中文名称'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_KIND_NO IS '大类代码'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_CNM_ABR IS '中文简称'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_STATUS IS '启用标志:0:未启用,  1:启用'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_INSRNC_LONG IS '长短期标志: 1 :长期险,  2: 短期险'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_PLYNO_FLAG IS '保单号是否允许手工录入'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_RATE_FLAG IS '短期费率方式(D-按日;M-按月;O-其他)'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_INST_FLAG IS '分期付款标志'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_FINCVRG_FLAG IS '是否按险别核算标志(0:否,  1:是)'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_CLMEDR_FLAG IS '赔款后生成减保额批单标志'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_BS_TYPE IS '业务大类(0 :车险 , 1: 财产险,  2:  意康险,  3:农险)'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_PKG_FLAG IS '是否组合产品'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_GRP_FLAG IS '是否团单：''0'' 否,''1''是'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_PER_FLAG IS '是否个单：''0'' 否,''1''是'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_SEPA_CVRG_FLAG IS '主险tab标志（1为分开，0或空为不分开）'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.N_CRITERION_TIME IS '标准承保期限'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD.C_CRITERION_TIME_UNIT IS '标准承保期限单位'
/
