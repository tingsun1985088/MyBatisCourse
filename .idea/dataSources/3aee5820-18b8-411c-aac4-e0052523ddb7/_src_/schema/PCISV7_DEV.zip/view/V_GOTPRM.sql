CREATE VIEW V_GOTPRM AS select --再保前满期保费
       a.t_cal_tm as t_cal_tm,
       rpfunction.getKindNo(a.c_kind_no,a.c_prod_no,'') as kindNo,
       sum(a.n_cal_amt) as nCalAmt
  from web_fin_mid_gotprm a
  group by
        a.t_cal_tm,
        rpfunction.getKindNo(a.c_kind_no,a.c_prod_no,'')
/
