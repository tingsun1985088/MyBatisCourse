CREATE VIEW V_PAY AS select --再保前手续费
       '3' typ,
       a.c_prm_cur as feeCur,
       nvl(f.N_FEE,0) as nFee,
       rpfunction.getKindName(kind.c_kind_no,a.c_prod_no,'') as  kindNo,
       decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_bgn_tm),trunc(a.t_edr_bgn_tm)) as bgnTm,
       decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_end_tm),trunc(a.t_edr_end_tm)) as endTm,
       trunc(a.t_udr_tm) as udrTm
  from web_ply_base a, WEB_ply_FEE f, web_prd_kind kind
 where a.c_app_no = f.c_app_no
   and substr(a.c_prod_no, 1, 2) = kind.c_kind_no
   and a.c_inwd_mrk <> '1'
   and f.C_FEETYP_CDE = 'S'
--分入
union all
select  '3' typ,
       inwd.c_inwd_cur_cde as feeCur,
       decode(nvl(a.n_edr_prj_no,0),0,inwd.N_INWD_COMM,inwd.n_inwd_comm_var) as nFee,
       rpfunction.getKindName(kind.c_kind_no,a.c_prod_no,'') as  kindNo,
       decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_bgn_tm),trunc(a.t_edr_bgn_tm)) as bgnTm,
       decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_end_tm),trunc(a.t_edr_end_tm)) as endTm,
       trunc(a.t_udr_tm) as udrTm
  from web_ply_base a,web_ply_inwd inwd, web_prd_kind kind
 where  a.c_app_no = inwd.c_app_no
   and substr(a.c_prod_no, 1, 2) = kind.c_kind_no
   and a.c_inwd_mrk = '1'
/
