CREATE VIEW V_FIN_PLYEDR_COLDUE AS SELECT
C_ACCNT_FLAG          ,
C_AGREE_CDE           ,
C_AGT_AGR_NO          ,
C_APP_NME             ,
C_ARP_FLAG            ,
C_BALA_MRK            ,
C_BANK_ACCOUNT        ,
C_BANK_CDE            ,
C_BATCH_NO            ,
C_BFN_NO              ,
C_BSNS_TYP            ,
C_CHA_CDE             ,
C_CHA_CLS             ,
C_CHA_MRK             ,
C_CLNT_MRK            ,
C_COMPARE_FALG        ,
C_CON_DPT_CDE         ,
C_CRT_CDE             ,
C_BS_CUR              ,
C_CUSTOMER_ACCOUNTS   ,
C_DPTACC_CDE          ,
C_DPT_CDE             ,
C_EDR_NO              ,
C_EDR_RSN             ,
C_EDR_TYP             ,
C_FEETYP_CDE          ,
C_LCN_NO              ,
C_MAIN_CON_CDE        ,
C_OPT_NO              ,
C_PLY_NO              ,
C_PRN_NO              ,
C_PROD_NO             ,
C_RCPT_NO             ,
C_ROLLBACK_MARK       ,
C_RP_CUR              ,
C_SLSGRP_CDE          ,
C_SLS_CDE             ,
C_TO_FIN_FLAG         ,
C_TRAN_FLAG           ,
C_UPD_CDE             ,
N_CAN_SUM             ,
N_BS_AMT              ,
N_PAID_AMT            ,
N_OTHER_AMT           ,
N_RP_AMT              ,
N_TMS                 ,
T_AGREE_TM            ,
T_DUE_TM              ,
T_BLN_TM              ,
T_RP_TM               ,
T_PAID_TM             ,
T_CRT_TM              ,
T_INSRNC_BGN_TM       ,
T_INSRNC_END_TM       ,
T_PAY_END_TM          ,
T_PAY_BGN_TM          ,
T_UPD_TM              ,

null,
null,
C_APP_NME,
C_PAYER_CDE,
C_APP_NO,
C_BS_CUR,
NULL,
N_BS_AMT,
NULL,
N_RP_AMT,
NULL,
NULL,
NULL


/*
C_ACCOUNT
C_APP_NO
C_CIRC_VHL_TYP
C_DUE_CUR
C_DUE_MRK
C_INST_MRK
C_LONGSHORT_FLAG
C_PAYER_CDE
C_PAYER_NME
C_PAY_MDE_CDE
C_PKGINFO_PK_ID
C_PLY_MRK
C_PRMDUE_PK_ID
C_RP_FLAG
N_DUE_AMT
N_PRE_AMT
N_SHARES_NO
N_TAX_RATE
*/
FROM WEB_FIN_PRM_DUE

/
