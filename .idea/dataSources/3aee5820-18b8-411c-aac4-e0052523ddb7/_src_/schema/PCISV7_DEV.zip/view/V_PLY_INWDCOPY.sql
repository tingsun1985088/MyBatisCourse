CREATE VIEW V_PLY_INWDCOPY AS select --再保前保单明细(分入)
       inwd.c_ply_no as c_ply_no,
       dpt.c_dpt_cnm   as c_dpt_cnm,
       '---'          as 三级机构,    --机构
       rpfunction.getKindName(kind.c_kind_no,base.c_prod_no,'') as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       '---'           as c_cvrg_name,
       decode(nvl(base.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk,
       '---'           as c_stk_mrk,
       '分入'          as c_inwd_mrk,
       cur.c_cur_cnm   as c_prmcur_name,
       inwd.n_own_gr_prm as n_prm,
       case when inwd.c_inwd_cur_cde = '01' then nvl(inwd.n_own_gr_prm,0)
         else
           nvl(inwd.n_own_gr_prm,0)*get_rate(inwd.c_inwd_cur_cde,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
        end  as n_prm_rmb,
       to_char(base.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       --to_char(base.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59' 保单保险止期,
       decode(to_char(base.t_insrnc_end_tm,'hh24:mi:ss'),'00:00:00',to_char(base.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59',to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')) as t_insrnc_end_tm,
       to_char(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       inwd.n_inwd_comm_rate as n_fee_prop,
       cur.c_cur_cnm         as c_feecur_name,
       inwd.N_INWD_COMM      as n_fee,
       case when inwd.c_inwd_cur_cde = '01' then inwd.N_INWD_COMM
         else inwd.N_INWD_COMM*get_rate(inwd.c_inwd_cur_cde,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
       end as n_fee_rmb,
       prod.c_kind_no,
       prod.c_prod_no

from web_ply_inwd inwd,
     web_ply_base base,
     web_org_dpt dpt,
     web_prd_kind kind,
     web_prd_prod prod,
     web_bas_fin_cur cur
where inwd.c_app_no = base.c_app_no
  and base.c_dpt_cde = dpt.c_dpt_cde
  and base.c_edr_no is null
  and substr(base.c_prod_no,1,2) = kind.c_kind_no
  and base.c_prod_no = prod.c_prod_no
  and inwd.C_INWD_CUR_CDE = cur.c_cur_cde
  and trunc(base.t_udr_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
  and trunc(base.t_insrnc_bgn_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
/
