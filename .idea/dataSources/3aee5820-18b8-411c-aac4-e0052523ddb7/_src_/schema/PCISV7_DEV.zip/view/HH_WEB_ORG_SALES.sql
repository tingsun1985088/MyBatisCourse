CREATE VIEW HH_WEB_ORG_SALES AS SELECT
c_dpt_cde,
c_sls_cde,
c_sls_nme,
c_salegrp_cde,
c_ctfct_typ,
c_ctfct_no,
c_sls_typ,
c_teamleader_flag,
c_mobile
 FROM WEB_ORG_SALES
/
COMMENT ON VIEW HH_WEB_ORG_SALES IS 'snapshot table for snapshot REPORTHH1.hh_WEB_ORG_SALES'
/
COMMENT ON COLUMN HH_WEB_ORG_SALES.C_DPT_CDE IS '  此代码为机构内部代码，存储在业务表中的代码此代码为系统自动生成的流水号，可以用6位的序列号'
/
COMMENT ON COLUMN HH_WEB_ORG_SALES.C_SLS_CDE IS '  就是员工代码'
/
COMMENT ON COLUMN HH_WEB_ORG_SALES.C_CTFCT_TYP IS '120001-身份证; 120002-护照; 120003-军人证; 120004-证执业证号; 120009-其它'
/
COMMENT ON COLUMN HH_WEB_ORG_SALES.C_SLS_TYP IS '  合同、个人代理、其他、在职。合同、个人代理指系统员工，其他、在职指代理人。'
/
