CREATE VIEW HH_WEB_CUS_CONFER AS SELECT
  c_agt_agr_cde  ,
  c_agt_agr_no  ,
  n_sub_co_no     ,
  c_auth_mrk  ,
  c_per_org_mrk    ,
  c_udr_mrk     ,
  c_clnt_cde   ,
  c_clnt_nme ,
  c_dpt_cde    ,
  t_effc_tm    ,
  t_co_strt_tm  ,
  t_co_end_tm    ,
  c_sls_cde  ,
  c_co_cnt   ,
  c_undr_prsn  ,
  c_agt_undr   ,
  t_undr_tm    ,
  c_undr_dpt   ,
  n_bal_cyc  ,
  c_query_mrk    ,
  c_status   ,
  c_verify_status ,
  c_verify_his_opn ,
  c_verify_opn   ,
  c_crt_cde   ,
  t_crt_tm   ,
  c_upd_cde   ,
  t_upd_tm   ,
  c_confer_typ   ,
  c_cha_cls  ,
  c_trans_mrk  ,
  t_trans_tm  ,
  c_is_sysnch   ,
  c_sys_stat  ,
  c_error_info   ,
  t_sysnch_time   ,
  c_action_typ  ,
  c_del
 FROM WEB_CUS_CONFER
/
COMMENT ON VIEW HH_WEB_CUS_CONFER IS '代理协议管理、代理协议审核'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_AGT_AGR_CDE IS '协议内部码  '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_AGT_AGR_NO IS '协议编码  每次有补充协议时，在此号码后加_补充协议号'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.N_SUB_CO_NO IS '补充协议号 默认为1'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_AUTH_MRK IS '授权标志    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_PER_ORG_MRK IS '个人机构标志'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_UDR_MRK IS '核保标志    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_CLNT_CDE IS '代理人代码  '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_CLNT_NME IS '客户名称    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_DPT_CDE IS '经办部门    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_EFFC_TM IS '签订日期    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_CO_STRT_TM IS '协议起期    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_CO_END_TM IS '协议止期    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_SLS_CDE IS '经办人      '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_CO_CNT IS '协议内容    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_UNDR_PRSN IS '核保人      '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_AGT_UNDR IS '代理出单    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_UNDR_TM IS '审核日期    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_UNDR_DPT IS '核保机构    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.N_BAL_CYC IS '结费周期    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_QUERY_MRK IS '特殊查询标志'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_STATUS IS '协议状态 0=暂存；1=待审核；2=待修改；3=同意'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_VERIFY_STATUS IS '审核意见 1=同意；0=修改'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_VERIFY_HIS_OPN IS '历史审核意见'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_VERIFY_OPN IS '当前审核意见'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_CRT_CDE IS '创建人员    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_CRT_TM IS '创建时间    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_UPD_CDE IS '修改人员    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_UPD_TM IS '修改时间    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_CONFER_TYP IS '协议类型 (代理协议,合作协议,预约协议)'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_CHA_CLS IS '渠道类别    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_TRANS_MRK IS '迁移标志    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_TRANS_TM IS '迁移时间    '
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_IS_SYSNCH IS '是否同步 0-否, 1-是'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_SYS_STAT IS '同步结果状态 0-同步失败, 1-同步成功'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_ERROR_INFO IS '同步信息 主要记录错误信息'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.T_SYSNCH_TIME IS '同步时间'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_ACTION_TYP IS '操作类型0-add,1-update,2-del'
/
COMMENT ON COLUMN HH_WEB_CUS_CONFER.C_DEL IS '逻辑删除标志 0-无效 1-有效'
/
