CREATE VIEW V_RICLM_VHL_PAYSY AS select /*再保分出已决赔款商车*/
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       CVRG.C_NME_CN   as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,
       decode(nvl(due.c_stock_mrk, '0'), '192002', '股东', '非股东') as c_stk_mrk,
       cur.c_cur_cnm   as  c_pay_cur,
       sum(ced.n_clm_amt*DTL.N_SUM_ESTMT_AMT
           /*(rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))*//decode(nvl(due.n_ri_clm_amt,0),0,1,due.n_ri_clm_amt)) as n_pay,
       sum(ced.n_clm_amt* DTL.N_SUM_ESTMT_AMT
           /*(rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))*//decode(nvl(due.n_ri_clm_amt,0),0,1,due.n_ri_clm_amt)) as n_pay_rmb,
       cur.c_cur_cnm   as c_clmfee_cur,

       sum(/*(CASE when (select count(1) from web_clm_other_fee_lst_42 lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (
                         case    WHEN ic.N_YFSY_AMT = 0 THEN
                              ic.B_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_LST_42
                                WHERE C_IC_ID = ic.C_IC_ID)
                             ELSE
                              ic.B_FEE_AMT_CAL *
                              decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     (rdr.n_ic_amt+nvl(rdr.n_help_amt,0)) / ic.N_YFSY_AMT)
                           END)end)*/ DTL.N_CLM_FEE * ced.n_clm_prpt)  as n_clmfee,--原币种已决直接理赔费用,
       sum(/*(CASE when (select count(1) from web_clm_other_fee_lst_42 lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (
                         case    WHEN ic.N_YFSY_AMT = 0 THEN
                              ic.B_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_LST_42
                                WHERE C_IC_ID = ic.C_IC_ID)
                             ELSE
                              ic.B_FEE_AMT_CAL *
                              decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     (rdr.n_ic_amt+nvl(rdr.n_help_amt,0)) / ic.N_YFSY_AMT)
                           END) end)*/ DTL.N_CLM_FEE * ced.n_clm_prpt) as n_clmfee_rmb,--折合人民币已决直接理赔费用,
      /* sum(ced.n_clm_amt*\*ic.B_FEE_AMT_CAL**\(1-(rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt))   as n_clmfee,
       sum(ced.n_clm_amt*\*ic.B_FEE_AMT_CAL**\(1-(rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt))   as n_clmfee_rmb,*/
       '人民币'        as c_nopay_cur,
       0               as n_nopay,
       0               as n_nopay_rmb,
       '人民币'        as c_noclmfee_cur,
       0               as n_noclmfee,
       0               as n_noclmfee_rmb,
       to_char(M.T_ACCDNT_TM,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm, /*出险时间*/
       to_char(M.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,    /*报案时间*/
       to_char(M.T_CLM_RGST_TM,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,   /*立案时间*/
       to_char(DTL.T_ASSESS_TM,'yyyy-mm-dd hh24:mi:ss')as t_endcase_tm,/*结案时间*/
       prod.c_kind_no,prod.c_prod_no,'已决' as d_state,'1' as C_JY_FLAG --1软通 2精友
  from web_ri_clm_due   due,
       web_ri_clm_ced   ced,
       web_prd_prod      prod,
       web_org_dpt       dpt,
       web_org_dpt       dpt2,
       --web_clm_rpt_zm_42    rpt,
       web_ply_base      base,
       web_bas_fin_cur   cur,
       WEB_PRD_CVRG CVRG,
       /*web_clm_ic_42        ic,
       web_clm_ic_rdr_lst_42 rdr,
       web_clm_endcase_zm_42 endcase,*/
       WEB_FIN_CLM_MAIN M,
       WEB_FIN_CLM_DETAIL DTL,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   AND SUBSTR(DTL.C_INSRNC_CDE,1,6) = CVRG.C_CVRG_NO
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_clm_tms = ced.n_clm_tms
   AND DUE.N_CLM_TMS = DTL.N_CLM_TMS
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and due.c_ply_no = base.c_ply_no
   and due.n_edr_prj_no = base.n_edr_prj_no
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   --and due.c_clm_no = rpt.c_clm_no
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') /*从201308开始有分出赔案*/
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = M.C_CLM_NO
   --and ic.t_ic_tm >= to_date('2013-08-01','yyyy-mm-dd')
   AND M.C_CLM_NO = DTL.C_CLM_NO
   and M.t_rpt_tm >= to_date('2013-08-01','yyyy-mm-dd')
   AND DTL.C_CLM_MAINSTATUS IN ('38','39')
   AND DTL.C_KIND_NO = '03'
   /*and ic.c_ic_id = rdr.c_ic_id
   and ic.c_clm_no = endcase.c_clm_no
   and ic.n_ic_num = endcase.n_endcase_no*/
   --and rdr.n_ic_amt + rdr.n_prepay_amt <> 0
 group by
       due.c_clm_no,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
       substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
       prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
       to_char(M.T_ACCDNT_TM,'yyyy-mm-dd hh24:mi:ss'),
       to_char(M.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
       to_char(M.T_CLM_RGST_TM,'yyyy-mm-dd hh24:mi:ss') ,
       prod.c_kind_no,prod.c_prod_no,DTL.T_ASSESS_TM,CVRG.C_NME_CN
/*select \*再保分出已决赔款商车*\
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       rdr.c_rdr_cnm   as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,
       decode(nvl(due.c_stock_mrk, '0'), '192002', '股东', '非股东') as c_stk_mrk,
       cur.c_cur_cnm   as  c_pay_cur,
       sum(ced.n_clm_amt*
           (rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt) as n_pay,
       sum(ced.n_clm_amt*
           (rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt) as n_pay_rmb,
       cur.c_cur_cnm   as c_clmfee_cur,

       sum((CASE when (select count(1) from web_clm_other_fee_lst_42 lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (
                         case    WHEN ic.N_YFSY_AMT = 0 THEN
                              ic.B_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_LST_42
                                WHERE C_IC_ID = ic.C_IC_ID)
                             ELSE
                              ic.B_FEE_AMT_CAL *
                              decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     (rdr.n_ic_amt+nvl(rdr.n_help_amt,0)) / ic.N_YFSY_AMT)
                           END)end) * ced.n_clm_prpt)  as n_clmfee,--原币种已决直接理赔费用,
       sum((CASE when (select count(1) from web_clm_other_fee_lst_42 lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (
                         case    WHEN ic.N_YFSY_AMT = 0 THEN
                              ic.B_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_LST_42
                                WHERE C_IC_ID = ic.C_IC_ID)
                             ELSE
                              ic.B_FEE_AMT_CAL *
                              decode(ic.N_YFSY_AMT,
                                     0,
                                     0,
                                     (rdr.n_ic_amt+nvl(rdr.n_help_amt,0)) / ic.N_YFSY_AMT)
                           END) end) * ced.n_clm_prpt) as n_clmfee_rmb,--折合人民币已决直接理赔费用,
      \* sum(ced.n_clm_amt*\*ic.B_FEE_AMT_CAL**\(1-(rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt))   as n_clmfee,
       sum(ced.n_clm_amt*\*ic.B_FEE_AMT_CAL**\(1-(rdr.n_ic_amt+rdr.n_help_amt+
           (case when ic.c_ic_type='5' then 0  when length(rdr.c_rdr_cde)<> 6 then 0 else
            (case when endcase.c_end_type = '03' then 0 else nvl(rdr.n_prepay_amt, 0) end ) end))/due.n_ri_clm_amt))   as n_clmfee_rmb,*\
       '人民币'        as c_nopay_cur,
       0               as n_nopay,
       0               as n_nopay_rmb,
       '人民币'        as c_noclmfee_cur,
       0               as n_noclmfee,
       0               as n_noclmfee_rmb,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm, \*出险时间*\
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,    \*报案时间*\
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,   \*立案时间*\
       to_char(endcase.t_end_tm,'yyyy-mm-dd hh24:mi:ss')as t_endcase_tm,\*结案时间*\
       prod.c_kind_no,prod.c_prod_no,'已决' as d_state,'1' as C_JY_FLAG --1软通 2精友
  from web_ri_clm_due_42   due,
       web_ri_clm_ced_42   ced,
       web_prd_prod_42      prod,
       web_org_dpt_42       dpt,
       web_org_dpt_42       dpt2,
       web_clm_rpt_zm_42    rpt,
       web_ply_base_42      base,
       web_bas_fin_cur_42   cur,
       web_clm_ic_42        ic,
       web_clm_ic_rdr_lst_42 rdr,
       web_clm_endcase_zm_42 endcase,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and due.c_ply_no = base.c_ply_no
   and due.n_edr_prj_no = base.n_edr_prj_no
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   and due.c_clm_no = rpt.c_clm_no
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and due.c_clm_no = ic.c_clm_no
   and ic.t_ic_tm >= to_date('2013-08-01','yyyy-mm-dd')
   and rpt.t_rpt_tm >= to_date('2013-08-01','yyyy-mm-dd')
   and ic.c_ic_id = rdr.c_ic_id
   and ic.c_clm_no = endcase.c_clm_no
   and ic.n_ic_num = endcase.n_endcase_no
   --and rdr.n_ic_amt + rdr.n_prepay_amt <> 0
 group by
       due.c_clm_no,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
       substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
       prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') ,
       prod.c_kind_no,prod.c_prod_no,rdr.c_rdr_cnm,endcase.t_end_tm
  --20140113精友理赔修改
  UNION ALL
  select \*再保分出已决赔款商车*\
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       CVRG.C_NME_CN   as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,
       decode(nvl(due.c_stock_mrk, '0'), '192002', '股东', '非股东') as c_stk_mrk,
       cur.c_cur_cnm   as  c_pay_cur,
       sum(ced.n_clm_amt*(NVL(READY.N_AMT,0) + NVL(READY.N_CHECKLOS_HELP_FEE,0))/due.n_ri_clm_amt) as n_pay,
       sum(ced.n_clm_amt*(NVL(READY.N_AMT,0) + NVL(READY.N_CHECKLOS_HELP_FEE,0))/due.n_ri_clm_amt) as n_pay_rmb,
       cur.c_cur_cnm   as c_clmfee_cur,

       sum(NVL(READY.N_CLMFEE_AMT,0) * ced.n_clm_prpt)  as n_clmfee,--原币种已决直接理赔费用,
       sum(NVL(READY.N_CLMFEE_AMT,0) * ced.n_clm_prpt) as n_clmfee_rmb,--折合人民币已决直接理赔费用,
       '人民币'        as c_nopay_cur,
       0               as n_nopay,
       0               as n_nopay_rmb,
       '人民币'        as c_noclmfee_cur,
       0               as n_noclmfee,
       0               as n_noclmfee_rmb,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm, \*出险时间*\
       to_char(MJ.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,    \*报案时间*\
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,   \*立案时间*\
       to_char(READY.t_Update,'yyyy-mm-dd hh24:mi:ss')as t_endcase_tm,\*结案时间*\
       prod.c_kind_no,prod.c_prod_no,'已决' as d_state,'2' as C_JY_FLAG --1软通 2精友
  from web_ri_clm_due_42    due,
       web_ri_clm_ced_42    ced,
       web_prd_prod_42      prod,
       web_org_dpt_42       dpt,
       web_org_dpt_42       dpt2,
       web_ply_base_42      base,
       web_bas_fin_cur_42   cur,
       web_fin_accntquart   acc,
       WEB_CLM_MAIN_JY      MJ,
       WEB_CLM_READY_AMT_42 READY,
       WEB_PRD_CVRG_42      CVRG
 where due.c_clm_no = ced.c_clm_no
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_clm_tms = ced.n_clm_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and due.c_ply_no = base.c_ply_no
   and due.n_edr_prj_no = base.n_edr_prj_no
   and due.c_clm_no = MJ.c_clm_no
   AND DUE.C_CLM_NO = READY.C_CLM_MAIN_ID
   and due.c_status IN ('B','C')
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   AND SUBSTR(READY.C_RDR_CDE,1,6) = CVRG.C_CVRG_NO(+)
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and READY.T_UPDATE >= to_date('2013-08-01','yyyy-mm-dd')
   and due.c_prod_no <> '0320'
   and due.c_prod_no like '03%'
   AND READY.C_TASK_TYPE IN ('38','39')
   AND MJ.C_PROD_NO <> '0320' --商车
   AND READY.C_JY_FLAG = '2' --精友数据
   --AND NOT EXISTS (SELECT 1 FROM WEB_CLM_CNL_JY CNL WHERE CNL.C_CLM_NO = MJ.C_CLM_NO)
   --and rdr.n_ic_amt + rdr.n_prepay_amt <> 0
 group by
       due.c_clm_no,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
       substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
       prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
       to_char(mj.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') ,
       prod.c_kind_no,prod.c_prod_no,CVRG.C_NME_CN,READY.t_Update*/
/
