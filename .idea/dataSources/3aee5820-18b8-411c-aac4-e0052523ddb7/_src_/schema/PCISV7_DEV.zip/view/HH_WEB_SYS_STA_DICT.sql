CREATE VIEW HH_WEB_SYS_STA_DICT AS SELECT
c_pk_id as c_pk_id,
c_par_cde as c_par_cde ,
c_par_cnm as c_par_cnm,
c_cde as c_cde,
c_cnm as c_cnm,
c_map_cde as c_map_cde,
c_is_valid as c_is_valid,
c_trans_mrk as c_trans_mrk,
t_trans_tm as t_trans_tm
FROM WEB_SYS_STA_DICT
/
COMMENT ON VIEW HH_WEB_SYS_STA_DICT IS '记录系统固有的数据字典，包括一些状态、标志等，不公开给用户修改
同时用于记录一些系统固定代码与不同保险公司外部代码的映射，程序中用固定的代码
c_map_cde为*号表示仅供查看的静态字典
C_PK_ID第一位的编码规则：
''1''  承保
''2''  理赔
''3''  再保
''4''  收付
''5''  公共'
/
COMMENT ON COLUMN HH_WEB_SYS_STA_DICT.C_PK_ID IS '唯一序列号'
/
COMMENT ON COLUMN HH_WEB_SYS_STA_DICT.C_PAR_CDE IS '分类码（可以用拼音字母缩写）'
/
COMMENT ON COLUMN HH_WEB_SYS_STA_DICT.C_PAR_CNM IS '分类名称'
/
COMMENT ON COLUMN HH_WEB_SYS_STA_DICT.C_CDE IS '代码'
/
COMMENT ON COLUMN HH_WEB_SYS_STA_DICT.C_CNM IS '中文名称'
/
COMMENT ON COLUMN HH_WEB_SYS_STA_DICT.C_MAP_CDE IS '映射码，外部代码，可能根据不同的保险公司需要进行调整,*号表示仅供查看的静态字典
'
/
COMMENT ON COLUMN HH_WEB_SYS_STA_DICT.C_IS_VALID IS '有效标志'
/
