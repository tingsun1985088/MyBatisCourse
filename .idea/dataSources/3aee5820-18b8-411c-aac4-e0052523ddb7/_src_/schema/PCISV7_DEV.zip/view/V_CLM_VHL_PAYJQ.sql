CREATE VIEW V_CLM_VHL_PAYJQ AS select m.c_clm_no c_clm_no,
       ''         c_rpt_no,
       m.c_ply_no c_ply_no,
       to_char(m.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_bgn_tm,
       to_char(m.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_end_tm,
       case when substr(m.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm1,
       dpt2.c_dpt_cnm  as c_dpt_cnm2,
       '交强险'   c_kind_name,
       '机动车交通事故责任强制保险' as c_prod_name,
       cvrg.c_nme_cn c_cvrg_name,
       '个人'        c_group_mrk,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no
              and rownum = 1 ) as c_stk_mrk,
       decode(nvl(m.c_Inward,'0'),'0','非分入','分入') as c_inwd_mrk,
       '---'        as C_RS_MRK ,/*是否人伤*/
       '人民币'     c_pay_cur,
       /*nvl(duty.N_IC_AMT, 0) +
       \*nvl(ic.n_jq_help_fee, 0) *
       decode(nvl(ic.n_yfjq_amt, 0),
              0,
              0,
              nvl(duty.n_ic_amt, 0) / ic.n_yfjq_amt)+*\
       (case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end )
       +
       \*decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)*\
       (case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)
                                 else
                                     0
                            end)*/
       DTL.N_SUM_ESTMT_AMT n_pay_amt,--原币种已决赔款,
       /*nvl(duty.N_IC_AMT, 0) +
       (case when endcase.c_end_type = '03' then 0 else nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) end )
       +
       \*decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)*\
       (case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)
                                 else
                                     0
                            end)*/
       DTL.N_SUM_ESTMT_AMT n_pay_rmbamt,
       '人民币'     c_clmfee_cur,
       /*CASE
                             WHEN ic.N_YFJQ_AMT = 0 THEN
                              ic.T_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_DUTY_LST
                                WHERE C_IC_RDR_LST_ID = ic.C_IC_ID)
                             ELSE
                              ic.T_FEE_AMT_CAL *
                             \* decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)) / ic.N_YFJQ_AMT)*\
                           \*无责代赔在2011-11-24前后的处理方式不同*\
                           case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0))/ ic.N_YFJQ_AMT)
                                 else
                                     decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     duty.n_ic_amt/ ic.N_YFJQ_AMT)
                            end
                           END*/
            /*ROUND(nvl(DTL.N_CLM_FEE,0),2)*/nvl(DTL.N_CLM_FEE,0)  AS  n_clmfee_amt,/*原币种已决直接理赔费用,*/
      /*CASE
                             WHEN ic.N_YFJQ_AMT = 0 THEN
                              ic.T_FEE_AMT_CAL /
                              (SELECT COUNT(1)
                                 FROM WEB_CLM_IC_RDR_DUTY_LST
                                WHERE C_IC_RDR_LST_ID = ic.C_IC_ID)
                             ELSE
                              ic.T_FEE_AMT_CAL *
                             \* decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)) / ic.N_YFJQ_AMT)*\
                           \*无责代赔在2011-11-24前后的处理方式不同*\
                           case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                 decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0))/ ic.N_YFJQ_AMT)
                                 else
                                     decode(ic.N_YFJQ_AMT,
                                     0,
                                     0,
                                     duty.n_ic_amt/ ic.N_YFJQ_AMT)
                            end
                           END*/
        /*ROUND(nvl(DTL.N_CLM_FEE,0),2)*/nvl(DTL.N_CLM_FEE,0)  AS  n_clmfee_rmbamt,/*折合人民币已决直接理赔费用,*/
       '人民币'     c_nopay_cur,/*未决赔款币种,*/
       0            n_nopay_amt,/*原币种未决赔款,*/
       0            n_nopay_rmbamt,/*折合人民币未决赔款,*/
       '人民币'     c_noclmfee_cur,/*未决直接理赔费用币种,*/
       0            n_noclmfee_amt,/*原币种未决直接理赔费用,*/
       0            n_noclmfee_rmbamt,/*折合人民币未决直接理赔费用,*/
       to_char(M.T_ACCDNT_TM,'yyyy-mm-dd hh24:mi:ss') t_acdnt_tm,/*出险时间,*/
       to_char(M.T_RPT_TM,'yyyy-mm-dd hh24:mi:ss')   t_rpt_tm,/*报案时间,*/
       to_char(M.T_CLM_RGST_TM,'yyyy-mm-dd hh24:mi:ss') T_RGST_TM,/*立案时间,*/
       to_char(DTL.T_ASSESS_TM,'yyyy-mm-dd hh24:mi:ss') t_end_tm,/*结案时间,*/
       '已决'                                           c_pay_mrk,
       m.c_kind_no,
       m.c_prod_no,
       M.C_JY_FLAG --1或空 软通 2 精友
  from /*web_clm_ic              ic,
       web_clm_main            m,
       web_clm_endcase_zm      endcase,
       web_clm_ic_rdr_duty_lst duty,
       web_clm_rpt_zm          rpt,*/
       WEB_FIN_CLM_MAIN           M,
       WEB_FIN_CLM_DETAIL         DTL,
       web_prd_cvrg            cvrg,
       --web_clm_rgst            rgst,
       web_org_dpt             dpt,
       web_org_dpt             dpt2,
       web_fin_accntquart         acc
 where /*ic.c_clm_no = m.c_clm_no
   and ic.c_ic_id = duty.c_ic_rdr_lst_id
   and m.c_clm_no = endcase.c_clm_no
   and m.c_clm_no = rpt.c_clm_no*/
   --and m.c_inwd_mrk = '0'
      M.C_CLM_NO = DTL.C_CLM_NO
   and acc.c_mrk = '2'
   /*and endcase.c_endcase_status = '03'
   and endcase.c_end_type in ('02', '03')
   and ic.c_ic_status = '03'
   and ic.c_ic_type in ('0', '5')
   and ic.n_ic_num = endcase.n_endcase_no*/
   and M.t_rpt_tm <= acc.t_end_tm
   and DTL.T_ASSESS_TM <= acc.t_end_tm
   and DTL.T_ASSESS_TM >= acc.t_bgn_tm
   AND DTL.C_CLM_MAINSTATUS IN ('38','39') --结案状态
   and substr(DTL.C_INSRNC_CDE, 1, 6) = cvrg.c_cvrg_no
   --and m.c_clm_no = rgst.c_clm_no
   and dpt.c_dpt_cde = substr(m.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(m.c_dpt_cde,1,4)
   AND DTL.N_SUM_ESTMT_AMT + DTL.N_CLM_FEE <> 0
   and m.c_prod_no = '0320'
   AND m.c_kind_no = '03'
   AND DTL.C_KIND_NO = '03'
   AND DTL.C_PROD_NO = '0320'
   --AND m.C_CLM_NO <> '400000103202014000004' --对接时产生的重复赔案号，从精友取数
   --20140111增加精友理赔数据
   /*UNION ALL
   select m.c_clm_no c_clm_no,
       ''         c_rpt_no,
       m.c_ply_no c_ply_no,
       to_char(BASE.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_bgn_tm,
       to_char(BASE.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_end_tm,
       case when substr(m.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm1,
       dpt2.c_dpt_cnm  as c_dpt_cnm2,
       '交强险'   c_kind_name,
       '机动车交通事故责任强制保险' as c_prod_name,
       cvrg.c_nme_cn c_cvrg_name,
       '个人'        c_group_mrk,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no
              and rownum = 1 ) as c_stk_mrk,
       decode(nvl(m.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,
       '---'        as C_RS_MRK ,\*是否人伤*\
       '人民币'     c_pay_cur,
       (NVL(R.N_AMT,0) + NVL(R.N_CHECKLOS_HELP_FEE,0)) n_pay_amt,--原币种已决赔款,
       (NVL(R.N_AMT,0) + NVL(R.N_CHECKLOS_HELP_FEE,0)) n_pay_rmbamt,
       '人民币'     c_clmfee_cur,
       NVL(r.n_clmfee_amt,0)  n_clmfee_amt,\*原币种已决直接理赔费用,*\
       NVL(r.n_clmfee_amt,0)  n_clmfee_rmbamt,\*折合人民币已决直接理赔费用,*\
       '人民币'     c_nopay_cur,\*未决赔款币种,*\
       0            n_nopay_amt,\*原币种未决赔款,*\
       0            n_nopay_rmbamt,\*折合人民币未决赔款,*\
       '人民币'     c_noclmfee_cur,\*未决直接理赔费用币种,*\
       0            n_noclmfee_amt,\*原币种未决直接理赔费用,*\
       0            n_noclmfee_rmbamt,\*折合人民币未决直接理赔费用,*\
       to_char(m.t_acdnt_tm,'yyyy-mm-dd hh24:mi:ss') t_acdnt_tm,\*出险时间,*\
       to_char(m.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')   t_rpt_tm,\*报案时间,*\
       to_char(m.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') T_RGST_TM,\*立案时间,*\
       to_char(R.t_Update,'yyyy-mm-dd hh24:mi:ss') t_end_tm,\*结案时间,*\
       '已决'                                           c_pay_mrk,
       m.c_kind_no,
       m.c_prod_no,
       '2' c_jy_flag --1 软通 2 精友
  from WEB_CLM_MAIN_JY            m,
       WEB_PLY_BASE            BASE,
       WEB_CLM_READY_AMT       R,
       web_prd_cvrg            cvrg,
       web_org_dpt             dpt,
       web_org_dpt             dpt2,
       web_fin_accntquart         acc
 where m.c_clm_no = r.c_clm_main_id
   and m.t_rpt_tm <= acc.t_end_tm --报案时间在评估月内的数据
   --and m.t_rpt_tm >= acc.t_bgn_tm
   and R.t_Update <= acc.t_end_tm
   and R.t_Update >= acc.t_bgn_tm
   and substr(R.c_Rdr_Cde, 1, 6) = cvrg.c_cvrg_no(+) --险别
   and R.c_task_type in ('38','39') --结案状态
   and dpt.c_dpt_cde = substr(m.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(m.c_dpt_cde,1,4)
   AND BASE.C_PLY_NO = M.C_PLY_NO
   AND BASE.N_EDR_PRJ_NO = 0 --取对应保单的起止期
   AND m.c_prod_no = '0320' --交强险
   and acc.c_mrk = '2'
   --AND NOT EXISTS (SELECT 1 FROM WEB_CLM_CNL_JY CNL WHERE CNL.C_CLM_NO = M.C_CLM_NO) --不存在销案，精友数据销案也会结案
   AND R.C_JY_FLAG = '2' --精友数据标识
   AND M.C_CLM_NO NOT IN ('400000103202014000006','400000103202014000009')--对接时产生的重复赔号，从软通取数
   */
/
