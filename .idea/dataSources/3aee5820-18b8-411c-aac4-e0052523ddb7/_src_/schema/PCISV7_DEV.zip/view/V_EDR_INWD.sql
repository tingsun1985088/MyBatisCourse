CREATE VIEW V_EDR_INWD AS select --再保前批单明细(分入)
       inwd.c_edr_no  as c_edr_no,     --批单号
       dpt.c_dpt_cnm  as c_dpt_cnm,    --机构
       '---'          as c_dpt_three,    --机构
       rpfunction.getKindName(ply.c_kind_no,base.c_prod_no,'')  as c_kind_name, --险类
       prod.c_nme_cn  as c_prod_name,  --产品
       '---'          as c_cvrg_name,  --险别
       '---'          as c_grp_mrk,    --团单标志
       '---'          as c_stk_mrk,    --股东标志
       '分入'         as c_inwd_mrk,   --分入标志
       cur.c_cur_cnm  as c_cur_name,   --币种
       inwd.n_own_gr_prm_var as n_prm, --原币种批单保费
       case when inwd.c_inwd_cur_cde = '01' then nvl(inwd.n_own_gr_prm_var,0)
         else
           nvl(inwd.n_own_gr_prm_var,0)*get_rate(inwd.c_inwd_cur_cde,'01',trunc(acc.t_end_tm))
        end  as n_prm_rmb,             --折人民币原币种批单保费
       'T'||to_char(base.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(base.t_edr_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_bgn_tm, --批单生效日期
       'T'||to_char(base.t_edr_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_end_tm, --批单止期
       get_edrsn(base.c_app_no,ply.c_kind_no) as c_edr_rsn,               --批改原因
       decode(nvl(base.c_edr_type,'1'),'1','一般批改','3','退保','2','注销') as c_edr_type,--批改类型
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_cal_tm,--评估日
       inwd.n_inwd_comm_rate as n_fee_prop,
       cur.c_cur_cnm         as c_feecur_name,
       inwd.n_inwd_comm_var  as n_fee,
       case when inwd.c_inwd_cur_cde = '01' then inwd.n_inwd_comm_var
         else inwd.n_inwd_comm_var*get_rate(inwd.c_inwd_cur_cde,'01',trunc(acc.t_end_tm))
       end  as n_fee_rmb,
       /*ply.c_kind_no,
       base.c_prod_no*/
       rpfunction.getKindNo(ply.c_kind_no ,ply.c_prod_no,'') as c_kind_no,
       ply.c_prod_no    as c_prod_no
from web_fin_plyedr ply,
     web_ply_inwd inwd,
     web_ply_base base,
     web_org_dpt dpt,
     web_prd_prod prod,
     web_bas_fin_cur cur,
     web_fin_accntquart acc
where inwd.c_app_no = base.c_app_no
  and base.c_dpt_cde = dpt.c_dpt_cde
  and base.c_edr_no is not null
  and ply.c_edr_no = base.c_edr_no
  and base.c_prod_no = prod.c_prod_no
  and inwd.C_INWD_CUR_CDE = cur.c_cur_cde
  and ply.t_cal_tm <= acc.t_end_tm
  --and ply.t_cal_tm >= acc.t_bgn_tm
  and acc.c_mrk = '2'
  and ply.c_inwd_mrk = '1'
UNION ALL
select --再保前批单明细(合约分入)
       '' as c_edr_no,
       '泰山财产保险股份有限公司总公司'   as c_dpt_cnm,
       ri.c_com_cnm          as c_dpt_three,    --机构
       rpfunction.getKindName(d.c_kind_no,prod.c_prod_no,'') as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       '---'           as c_cvrg_name,
       '个人'          as c_grp_mrk,
       '---'           as c_stk_mrk,
       '分入'          as c_inwd_mrk,
       '人民币'        as c_prmcur_name,
       --case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end       as n_prm,
       --case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end       as n_prm_rmb,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end )   as n_prm,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end )   as n_prm_rmb,
       /*m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_udr_tm,     --核保日期*/
       'T'||to_char(m.t_to_fin_tm,'yyyy-mm-dd hh24:mi:ss')                              as t_udr_tm,
       /*'T'||m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_edr_bgn_tm,
       'T'||TO_CHAR(to_number(m.c_bill_prd_year)+1||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end))||'-14 23:59:59'                               as t_edr_end_tm,*/
       'T'||(
            case when upper(c_billprd_type) <> 'S' then m.c_uw_year ||'-'|| m.c_uw_month ||'-15 00:00:00'
              else m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'
            end
       )  as t_edr_bgn_tm,
       'T'||(
            case when upper(c_billprd_type) <> 'S' then to_number(m.c_uw_year)+1 ||'-'|| m.c_uw_month ||'-14 23:59:59'
              else to_number(m.c_bill_prd_year)+1||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-14 23:59:59'
            end
       ) as t_edr_end_tm,
       '' as c_edr_rsn,
       '一般批改' as c_edr_type,
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       round((case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end
        /case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end
       ),4)               as n_fee_prop,
       '人民币'         as c_feecur_name,
       --case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end   as n_fee,
       --case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end   as n_fee_rmb,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end )  as n_fee,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end )  as n_fee_rmb,
       /*d.c_kind_no,*/rpfunction.getKindNo(d.c_kind_no ,prod.c_prod_no,'') as c_kind_no,
       prod.c_prod_no
from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,WEB_RI_INTER_cont_BILL_prod p,
     web_prd_prod prod,web_ri_com ri,web_fin_accntquart acc
where decode(m.n_month_rbk_mrk, -1, substr(m.c_bill_no, 2), m.c_bill_no) = d.c_bill_no
  and d.c_pk_id = p.c_bill_dtl_pk_id(+)
  and p.c_prod_no = prod.c_prod_no(+)
  and m.c_ri_com = ri.c_com_cde
  and m.c_to_fin_mrk = '1'
  and acc.c_mrk = '2'
  and m.t_crt_tm <= acc.t_end_tm
  and m.t_to_fin_tm <= acc.t_end_tm
  and (upper(c_billprd_type) = 'S' or nvl(n_month_rbk_mrk,1) = -1 )
  and (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end) <>0
--再保前批单明细(合约分入)
/*select '' as c_edr_no,
       '泰山财产保险股份有限公司总公司'   as c_dpt_cnm,
       ri.c_com_cnm          as c_dpt_three,    --机构
       rpfunction.getKindName(d.c_kind_no,prod.c_prod_no,'') as c_kind_name,
       nvl(prod.c_nme_cn,'---')   as c_prod_name,
       '---'           as c_cvrg_name,
       '个人'          as c_grp_mrk,
       '---'           as c_stk_mrk,
       '分入'          as c_inwd_mrk,
       '人民币'        as c_prmcur_name,
      \* case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end       as n_prm,
       case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end       as n_prm_rmb,*\
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end )   as n_prm,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end )   as n_prm_rmb,
       'T'||m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_udr_tm,     --核保日期
       'T'||m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_edr_bgn_tm,
       'T'||TO_CHAR(to_number(m.c_bill_prd_year)+1)||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-14 23:59:59'                               as t_edr_end_tm,
       '' as c_edr_rsn,
       '一般批改' as c_edr_type,
       to_char(acc.t_end_tm,'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       round((case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end
        /(case when p.c_pk_id is null then decode(d.n_inter_prm,0,1) else decode(p.n_inter_prm,0,1) end)
       ),4)               as n_fee_prop,
       '人民币'         as c_feecur_name,
       \*case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end   as n_fee,
       case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end   as n_fee_rmb,*\
         decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end )  as n_fee,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end )  as n_fee_rmb,
       \*d.c_kind_no, *\rpfunction.getKindNo(d.c_kind_no ,prod.c_prod_no,'') as c_kind_no,
        prod.c_prod_no

from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,WEB_RI_INTER_cont_BILL_prod p,
     web_prd_prod prod,web_ri_com ri,web_fin_accntquart acc
where \*m.c_pk_id = d.c_main_pk_id
  and d.c_pk_id = p.c_bill_dtl_pk_id(+)
  and p.c_prod_no = prod.c_prod_no(+)
  and m.c_ri_com = ri.c_com_cde
  and m.c_fee_cur = cur.c_cur_cde
  and m.c_to_fin_mrk = '1'
  and acc.c_mrk = '2'
  and (upper(c_billprd_type) = 'S' or nvl(n_month_rbk_mrk,1) = -1 )
  --and (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end) <>0

 \*and to_date(m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15','YYYY-MM-DD')>= acc.t_bgn_tm*\
  and TO_DATE(m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15','YYYY-MM-DD') <= acc.t_end_tm;*\
  decode(m.n_month_rbk_mrk, -1, substr(m.c_bill_no, 2), m.c_bill_no) = d.c_bill_no
  and d.c_pk_id = p.c_bill_dtl_pk_id(+)
  and p.c_prod_no = prod.c_prod_no(+)
  and m.c_ri_com = ri.c_com_cde
  and m.c_to_fin_mrk = '1'
  and acc.c_mrk = '2'
  and m.t_crt_tm <= acc.t_end_tm
  and m.t_to_fin_tm <= acc.t_end_tm
  and (upper(c_billprd_type) = 'S' or nvl(n_month_rbk_mrk,1) = -1 )
  and (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end) <>0*/
/
