CREATE VIEW V_RICLM_PAYCOPY AS select --再保分出已决赔款明细
      due.c_clm_no as c_clm_no,'' as c_rpt_no,due.c_ply_no as c_ply_no,
      to_char(plyedr.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
      to_char(plyedr.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
      --dpt.c_dpt_cnm   as c_dpt_cnm,
      case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
      decode(plyedr.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as 三级机构,
      rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'')  as c_kind_name,
      prod.c_nme_cn   as c_prod_name,
      '---'           as c_cvrg_name,
      decode(nvl(plyedr.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,--团单标志,
      decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东') as c_stk_mrk,--股东标志,
       --ced.n_clm_amt,
      cur.c_cur_cnm  as  c_pay_cur,--已决赔款的币种,
      sum(ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee)))  as n_pay,--原币种已决赔款,
      sum(CASE WHEN ced.c_riclm_cur='01' THEN ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))
       ELSE ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))*
              get_rate(ced.c_riclm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))) END)
            as n_pay_rmb,--折合人民币已决赔款,
      cur.c_cur_cnm  as c_clmfee_cur,--已决直接理赔费用币种,
      sum(ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/(pend.n_this_dtmd+pend.n_clmfee))) as n_clmfee,--原币种已决直接理赔费用,
      sum(case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))
         else ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))*
             get_rate(ced.c_riclm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
          end )  as n_clmfee_rmb,--折合人民币已决直接理赔费用,

      '人民币'       as c_nopay_cur,-- 未决赔款币种,
      0              as n_nopay,-- 原币种未决赔款,
      0              as n_nopay_rmb,-- 折合人民币未决赔款,
      '人民币'       as c_noclmfee_cur, -- 未决直接理赔费用币种,
      0              as n_noclmfee,--原币种未决直接理赔费用,
      0              as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
      to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,出险时间,
      ''                                               as t_rpt_tm,--报案时间,报案时间,
      to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,--立案时间,立案时间,
      to_char(due.t_cls_tm,'yyyy-mm-dd hh24:mi:ss')    as t_endcase_tm,--结案时间结案时间
      prod.c_kind_no,
      prod.c_prod_no
   from web_ri_clm_due due,web_ri_clm_ced ced,
        web_prd_prod prod,web_ply_base plyedr,
        --web_prd_kind kind,
        web_org_dpt dpt,web_org_dpt dpt2,
       -- web_clm_pend pend,
       (select c_clm_no,sum(n_this_dtmd) as n_this_dtmd ,sum(n_clmfee)as n_clmfee,c_pend_source
        from web_clm_pend where c_pend_source='6' group by  c_clm_no,c_pend_source) pend,
        web_ply_applicant app,
        web_bas_fin_cur cur
   where
        due.c_clm_no = ced.c_clm_no
    and due.n_clm_tms =ced.n_clm_tms
    and due.n_rbk_seq=ced.n_rbk_seq
    and due.n_split_seq = ced.n_split_seq
    and due.c_prod_no = prod.c_prod_no

    and due.c_ply_no = plyedr.c_ply_no

    and nvl(due.n_edr_prj_no,0) = plyedr.n_edr_prj_no
    AND app.c_app_no=plyedr.c_app_no
    and due.c_status = 'C'
    and prod.c_kind_no != '03'
    and due.n_rbk_seq=0
    and ced.c_cont_cde not in('BB','04','AR') --不是我司
    and trunc(due.t_ridue_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
    --and prod.c_kind_no = kind.c_kind_no
    and due.c_clm_no=pend.c_clm_no
    and pend.c_pend_source='6'
    and ced.c_riclm_cur = cur.c_cur_cde
    and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
    and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
    group by
          due.c_clm_no, due.c_ply_no, to_char(plyedr.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
          to_char(plyedr.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
          prod.c_nme_cn,plyedr.c_grp_mrk,app.c_stk_mrk,cur.c_cur_cnm,
          to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
          to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss'),
          to_char(due.t_cls_tm,'yyyy-mm-dd hh24:mi:ss'),
          prod.c_kind_no,prod.c_prod_no,
          substr(due.c_dpt_cde,1,4),plyedr.c_inwd_mrk,dpt2.c_dpt_cnm
/
