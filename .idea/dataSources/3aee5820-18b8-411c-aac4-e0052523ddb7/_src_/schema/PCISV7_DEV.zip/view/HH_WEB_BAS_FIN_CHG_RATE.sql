CREATE VIEW HH_WEB_BAS_FIN_CHG_RATE AS SELECT
c_chgrate_pk_id as c_chgrate_pk_id,
c_cur_cde1 as c_cur_cde1 ,
c_cur_cde2 as c_cur_cde2,
n_chg_rte as n_chg_rte,
t_effc_tm as t_effc_tm,
t_expd_tm as t_expd_tm,
t_adb_tm as t_adb_tm,
c_is_valid as c_is_valid,
c_crt_cde as c_crt_cde,
t_crt_tm as t_crt_tm,
c_upd_cde as c_upd_cde ,
t_upd_tm as t_upd_tm,
c_trans_mrk as c_trans_mrk,
t_trans_tm as t_trans_tm
FROM WEB_BAS_FIN_CHG_RATE
/
COMMENT ON VIEW HH_WEB_BAS_FIN_CHG_RATE IS 'snapshot table for snapshot REPORTHH1.HH_WEB_BAS_FIN_CHG_RATE'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.C_CHGRATE_PK_ID IS '汇率转换主键？'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.C_CUR_CDE1 IS '货币一'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.C_CUR_CDE2 IS '货币二'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.N_CHG_RTE IS '兑换率'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.T_EFFC_TM IS '有效起期'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.T_EXPD_TM IS '有效止期'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.T_ADB_TM IS '失效时间'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.C_IS_VALID IS '是否有效'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.C_CRT_CDE IS '创建人员'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.T_CRT_TM IS '创建时间'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.C_UPD_CDE IS '修改人员'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.T_UPD_TM IS '修改时间'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.C_TRANS_MRK IS '迁移标识'
/
COMMENT ON COLUMN HH_WEB_BAS_FIN_CHG_RATE.T_TRANS_TM IS '迁移时间'
/
