CREATE VIEW V_CLM_VHL_PAYSY_COP AS SELECT a.c_clm_no,--交强已决
       '---' as c_rpt_no,
       a.c_ply_no,
       'T'||to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_bgn_tm,--保单保险起期,
       'T'||to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_end_tm,--保单保险止期,
       case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else dpt.c_dpt_cnm end as c_dpt_cnm,
       dpt2.c_dpt_cnm  as c_dpt_three,
       '商业车险'      as  c_kind_name,--险类,
       prod.c_nme_cn   as  c_prod_name,--产品,
       cvrg.c_nme_cn   as  c_cvrg_name,
       decode(base.c_grp_mrk,'1','团单','个人') as c_grp_mrk,
       decode(c_stk_mrk,'192002','股东','非股东') as c_stk_mrk,
       decode(nvl(a.c_inward,'0'),'0','非分入','分入') as c_inwd_mrk,--分入标志,
       decode(a.c_is_csul,'1','人伤','---') as c_rs_mrk,
       '人民币'     c_pay_cur,--已决赔款币种,
       b.n_sum_estmt_amt as n_pay_amt, --已决赔款
       b.n_sum_estmt_amt as n_pay_amt_rmb, --已决赔款
       '人民币'          as c_clmfee_cur,
       b.n_clm_fee       as n_clmfee_amt,
       b.n_clm_fee       as n_clmfee_amt_rmb,
       0                 as n_nopay_amt,--原币种未决赔款,
       0                 as n_nopay_rmbamt,--折合人民币未决赔款,
       '人民币'          as c_noclmfee_cur,--未决直接理赔费用币种,
       0                 as n_noclmfee_amt,--原币种未决直接理赔费用,
       0                 as n_noclmfee_rmbamt,--折合人民币未决直接理赔费用,
       'T'||to_char(a.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') t_acdnt_tm,--出险时间,
       'T'||to_char(a.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')   t_rpt_tm,--报案时间,
       'T'||to_char(a.t_clm_rgst_tm,'yyyy-mm-dd hh24:mi:ss') T_RGST_TM,--立案时间,
       'T'||to_char(B.T_ASSESS_TM,'yyyy-mm-dd hh24:mi:ss') t_end_tm,--结案时间
       '已决' as c_pay_mrk,
       '03' as c_kind_no

FROM RPT_CLM_PEND_INSRNC b, rpt_clm_main a,web_org_dpt dpt,web_org_dpt dpt2,web_prd_prod prod,
     web_prd_cvrg cvrg,web_ply_base base,web_ply_applicant app,web_fin_accntquart acc
 WHERE b.c_clm_no = a.c_clm_no
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(a.c_dpt_cde,1,4)
   and substr(b.c_insrnc_cde, 1, 6) = cvrg.c_cvrg_no
   and a.c_prod_no = prod.c_prod_no
   and a.c_ply_no = base.c_ply_no
   and a.n_edr_prj_no = base.n_edr_prj_no
   and base.c_app_no = app.c_app_no
   and b.c_clm_mainstatus  in ('6', '38', '39') --结案
   and B.T_ASSESS_TM >= acc.t_bgn_tm
   and B.T_ASSESS_TM <= acc.t_end_tm
   and acc.c_mrk = '2'
   and a.c_kind_no = '03'
   and a.c_prod_no <> '0320'
/
