CREATE VIEW HH_WEB_CUS_CHA AS SELECT
c_cha_cde,
c_cha_nme,
c_cha_abbr,
c_cha_cls,
c_cha_type,
c_dpt_cde,
c_cha_mrk,
c_certf_no,
c_tel,
c_addr,
c_front_back_mrk,
c_auth_mrk,
c_stock_memo,
c_status,
c_handle,
c_cha_subtype,
c_trans_mrk,
c_action_typ
 FROM WEB_CUS_CHA
/
COMMENT ON VIEW HH_WEB_CUS_CHA IS 'snapshot table for snapshot REPORTHH1.hh_WEB_CUS_CHA'
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CHA_CDE IS '渠道编码      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CHA_NME IS '渠道名称      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CHA_ABBR IS '渠道简称      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CHA_CLS IS '渠道类别      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CHA_TYPE IS '渠道类别细分  '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_DPT_CDE IS '机构部门      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CHA_MRK IS '个人法人性质  '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CERTF_NO IS '证件号码      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_TEL IS '电话          '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_ADDR IS '地址          '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_FRONT_BACK_MRK IS '前后沿标志    '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_AUTH_MRK IS '授权标志      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_STOCK_MEMO IS '股东介绍      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_STATUS IS '中介状态      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_HANDLE IS '经办人        '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_CHA_SUBTYPE IS '渠道子类型    '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_TRANS_MRK IS '迁移标志      '
/
COMMENT ON COLUMN HH_WEB_CUS_CHA.C_ACTION_TYP IS '操作类型0-add,1-update,2-del'
/
