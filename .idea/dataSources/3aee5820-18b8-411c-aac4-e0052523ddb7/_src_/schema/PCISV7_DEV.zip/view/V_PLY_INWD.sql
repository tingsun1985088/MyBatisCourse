CREATE VIEW V_PLY_INWD AS select /*再保前保单明细(临分分入)*/
       'P'||ply.c_ply_no as c_ply_no,
       dpt.c_dpt_cnm     as c_dpt_cnm,
       '---'             as c_dpt_three,
       rpfunction.getKindName(ply.c_kind_no,ply.c_prod_no,'') as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       '---'           as c_cvrg_name,
       decode(nvl(ply.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk,
       '---'           as c_stk_mrk,
       '分入'          as c_inwd_mrk,
       cur.c_cur_cnm   as c_prmcur_name,
       ply.n_prm       as n_prm,
       case when ply.c_prm_cur='01' then ply.n_prm
         else ply.n_prm*get_rate(ply.c_prm_cur,'01',acc.t_end_tm)
        end  as n_prm_rmb,
       'T'||to_char(ply.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(ply.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       'T'||decode(to_char(ply.t_insrnc_end_tm,'hh24:mi:ss'),'00:00:00',to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59',to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')) as t_insrnc_end_tm,
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_cal_tm,--评估日
       ply.n_fee_prop        as n_fee_prop,
       cur.c_cur_cnm         as c_feecur_name,
       ply.n_fee             as n_fee,
       case when ply.c_prm_cur = '01' then ply.n_fee
         else ply.n_fee*get_rate(ply.c_prm_cur,'01',acc.t_end_tm)
       end as n_fee_rmb,
       /*prod.c_kind_no,
       prod.c_prod_no*/
       rpfunction.getKindNo(ply.c_kind_no ,ply.c_prod_no,'') as c_kind_no,
       ply.c_prod_no    as c_prod_no,
       '' as bgntm ,
       '' as endtm
from web_fin_plyedr ply,
     web_org_dpt dpt,
     web_prd_prod prod,
     web_bas_fin_cur cur,
     web_ply_inwd inwd,
     WEB_FIN_ACCNTQUART acc
where ply.c_dpt_cde = dpt.c_dpt_cde
  and ply.c_inwd_mrk = '1'
  and nvl(ply.c_edr_no,'---')= '---'
  and ply.c_prod_no = prod.c_prod_no
  and ply.c_prm_cur = cur.c_cur_cde
  and acc.c_mrk = '2'
  and ply.c_app_no = inwd.c_app_no
  --and ply.t_udr_tm >= acc.t_bgn_tm
  and ply.t_cal_tm <= acc.t_end_tm
UNION ALL
select /*再保前保单明细(合约分入)*/
       '---' as c_ply_no,
       '泰山财产保险股份有限公司总公司'   as c_dpt_cnm,
       ri.c_com_cnm          as c_dpt_three,
       rpfunction.getKindName(d.c_kind_no,prod.c_prod_no,'') as c_kind_name,
       nvl(prod.c_nme_cn,'---')   as c_prod_name,
       '---'           as c_cvrg_name,
       '个人'          as c_grp_mrk,
       '---'           as c_stk_mrk,
       '分入'          as c_inwd_mrk,
       cur.c_cur_cnm   as c_prmcur_name,
       case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end       as n_prm,
       (case when m.c_fee_cur = '01' then 1 else get_rate(m.c_fee_cur, '01', acc.t_End_Tm) end)*
       (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end)     as n_prm_rmb,
       'T'||m.c_uw_year ||'-'|| m.c_uw_month ||'-15 00:00:00'                           as t_udr_tm,
       'T'||m.c_uw_year ||'-'|| m.c_uw_month ||'-15 00:00:00'                           as t_insrnc_bgn_tm,
       'T'||to_char(to_number(m.c_uw_year)+1) ||'-'|| m.c_uw_month ||'-14 23:59:59'     as t_insrnc_end_tm,
       'T'||to_char(acc.t_End_Tm,'YYYY-MM-DD HH24:MI:SS') as t_cal_tm,
       round((case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end
        /(case when p.c_pk_id is null then decode(d.n_inter_prm,0,1) else decode(p.n_inter_prm,0,1) end)
       ),4)               as n_fee_prop,
       cur.c_cur_cnm      as c_feecur_name,
       case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end   as n_fee,
       (case when m.c_fee_cur = '01' then 1 else get_rate(m.c_fee_cur, '01', acc.t_End_Tm) end)*
       ( case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end)     as n_fee_rmb,

       /*d.c_kind_no*/rpfunction.getKindNo(d.c_kind_no ,prod.c_prod_no,'') as c_kind_no,
       prod.c_prod_no,
       '' as bgntm ,
       '' as endtm
from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,
     WEB_RI_INTER_cont_BILL_prod p,web_prd_prod prod,web_ri_com ri,
     WEB_FIN_ACCNTQUART ACC,WEB_BAS_FIN_CUR CUR
where m.c_pk_id = d.c_main_pk_id
  and d.c_pk_id = p.c_bill_dtl_pk_id(+)
  and p.c_prod_no = prod.c_prod_no(+)
  and m.c_ri_com = ri.c_com_cde
  and m.c_fee_cur = cur.c_cur_cde
  and upper(c_billprd_type) <> 'S' /*季度帐*/
  and nvl(n_month_rbk_mrk,1) in ('0','1')  /*正单*/
  and m.c_to_fin_mrk = '1'
  and acc.c_mrk = '2'
  --and (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end) <>0
  and to_date(m.c_uw_year ||'-'|| m.c_uw_month ||'-15','yyyy-mm-dd') <= acc.t_end_tm
/
