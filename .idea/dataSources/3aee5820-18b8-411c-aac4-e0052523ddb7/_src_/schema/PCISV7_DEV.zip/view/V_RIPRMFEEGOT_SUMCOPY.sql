CREATE VIEW V_RIPRMFEEGOT_SUMCOPY AS select --再保分出按险类汇总(保费收入,满期保费,手续费)
       typ 险类,max(type1) 企业财产险,max(type2) 家庭财产险,max(type3) 工程险,max(type4) 责任保险,
       max(type5) 信用保证险,max(type6) 商业车险,max(type7) 交强险,max(type8) 船舶保险,
       max(type9) 货物运输保险,max(type10) 特殊风险保险,max(type11) 农业保险,
       max(type12) 意外伤害保险,max(type13) 短期健康保险,max(type14) 其他
from (
select  case typ when '1' then '分出保费'  when '2' then '满期保费' when '3' then '手续费' end typ,
        case kindName when '企业财产险' then sum(nPrm) else 0 end type1,
        case kindName when '家庭财产险' then sum(nPrm) else 0 end type2,
        case kindName when '工程险' then sum(nPrm) else 0 end type3,
        case kindName when '责任保险' then sum(nPrm) else 0 end type4,
        case kindName when '信用保证险' then sum(nPrm) else 0 end type5,
        case kindName when '商业车险' then sum(nPrm) else 0 end type6,
        case kindName when '交强险' then sum(nPrm) else 0 end type7,
        case kindName when '船舶保险' then sum(nPrm) else 0 end type8,
        case kindName when '货物运输保险' then sum(nPrm) else 0 end type9,
        case kindName when '特殊风险保险' then sum(nPrm) else 0 end type10,
        case kindName when '农业保险' then sum(nPrm) else 0 end type11,
        case kindName when '意外伤害保险' then sum(nPrm) else 0 end type12,
        case kindName when '短期健康保险' then sum(nPrm) else 0 end type13,
        case kindName when '其他' then sum(nPrm) else 0 end type14
 from (
--分出保费按险类汇总
select '1' as typ,
       rpfunction.getKindName(kind.c_kind_no,ced.c_prod_no,'') as kindName,
       case when ced.c_riprm_cur = '01' then nvl(ced.n_ced_prm,0)
         else ced.n_ced_prm*get_rate(ced.c_riprm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
          end as nPrm
 from web_prd_kind kind,web_ri_plyedr_ced ced
where substr(ced.c_prod_no,1,2) = kind.c_kind_no
and ced.c_cont_cde not in('BB','04','AR')
and exists (select 1
          from web_ri_plyedr_due b
         where b.c_app_no = ced.c_app_no
           and b.n_split_seq = ced.n_split_seq
           and b.n_rbk_seq = ced.n_rbk_seq
           and trunc(b.t_ridue_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and decode(ced.c_cont_cde,'FA',C_FAC_TO_FIN_MRK,'1') = '1'
           and trunc(b.t_udr_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and b.c_status = 'C')

union all
--再保满期保费
select '2' as typ,
       rpfunction.getKindName(a.c_kind_no,a.c_prod_no,'') as kindName,
       sum(a.N_CAL_AMT) N_CAL_AMT--满期保费
  from web_fin_ri_mid_gotprm a,web_prd_kind kind
 where trunc(t_cal_tm) = trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and a.c_kind_no = kind.c_kind_no
 group by kind.c_nme_cn, a.c_kind_no, a.c_prod_no

union all
--再保分出手续费汇总
select '3' as typ,
       rpfunction.getKindName(b.c_kind_no,a.c_prod_no,'') as kindName,
       case when a.c_riprm_cur = '01' then nvl(a.n_comm,0) +nvl(a.N_DUTY,0)
        else (a.n_comm+nvl(a.N_DUTY,0))*get_rate(a.c_riprm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
        end as nComm
 from web_ri_plyedr_ced a,web_prd_kind b
where substr(a.c_prod_no,1,2) =b.c_kind_no
  and a.c_cont_cde not in('BB','04','AR')
  and exists (select 1 from web_ri_plyedr_due b
         where b.c_app_no = a.c_app_no
           and b.n_split_seq = a.n_split_seq
           and b.n_rbk_seq = a.n_rbk_seq
           and decode(a.c_cont_cde,'FA',C_FAC_TO_FIN_MRK,'1') = '1'
           and trunc(b.t_ridue_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and decode(b.n_edr_prj_no,0,trunc(b.t_insrnc_bgn_tm),trunc(b.t_edr_bgn_tm))<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and trunc(b.t_udr_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and b.c_status = 'C' )
)c group by c.typ,kindName
) group by typ order by typ
/
