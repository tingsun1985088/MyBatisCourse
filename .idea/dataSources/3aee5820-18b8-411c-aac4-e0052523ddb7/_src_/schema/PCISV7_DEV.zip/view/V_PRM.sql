CREATE VIEW V_PRM AS select  --再保前保费收入
        '1' as typ,
         a.c_prm_cur as prmCur,
         case when a.n_edr_prj_no = 0 then
              (case when a.c_ci_mrk = '3' then a.n_ci_own_prm else a.n_prm end)
                 else nvl(a.n_prm_var,0) end
          as nPrm,
       rpfunction.getKindNo(kind.c_kind_no,a.c_prod_no,'')  as kindNo,
       decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_bgn_tm),trunc(a.t_edr_bgn_tm)) as bgnTm,
       decode(a.n_edr_prj_no,0,trunc(a.t_insrnc_end_tm),trunc(a.t_edr_end_tm)) as endTm,
       trunc(a.t_udr_tm) as udrTm

 from web_ply_base a ,web_prd_kind kind
where  substr(a.c_prod_no,1,2) = kind.c_kind_no
/
