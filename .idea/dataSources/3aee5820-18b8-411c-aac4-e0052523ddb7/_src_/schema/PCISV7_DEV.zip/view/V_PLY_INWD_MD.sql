CREATE VIEW V_PLY_INWD_MD AS select /*再保前保单明细(临分分入)*/
       'P'||ply.c_ply_no as c_ply_no,
       dpt.c_dpt_cnm     as c_dpt_cnm,
       '---'             as c_dpt_three,
       rpfunction.getKindName(ply.c_kind_no,ply.c_prod_no,'') as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       '---'           as c_cvrg_name,
       decode(nvl(ply.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk,
       '---'           as c_stk_mrk,
       '分入'          as c_inwd_mrk,
       cur.c_cur_cnm   as c_prmcur_name,
       ply.n_Amt       as n_prm,

       'T'||to_char(ply.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(ply.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       'T'||decode(to_char(ply.t_insrnc_end_tm,'hh24:mi:ss'),'00:00:00',to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59',to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')) as t_insrnc_end_tm,
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_cal_tm,--评估日

       /*prod.c_kind_no,
       prod.c_prod_no*/
       rpfunction.getKindNo(ply.c_kind_no ,ply.c_prod_no,'') as c_kind_no,
       ply.c_prod_no    as c_prod_no,
       '' as bgntm ,
       '' as endtm
from web_fin_plyedr_MD ply,
     web_org_dpt dpt,
     web_prd_prod prod,
     web_bas_fin_cur cur,
     web_ply_inwd inwd,
     WEB_FIN_ACCNTQUART acc
where ply.c_dpt_cde = dpt.c_dpt_cde
  and ply.c_inwd_mrk = '1'
  and nvl(ply.c_edr_no,'---')= '---'
  and ply.c_prod_no = prod.c_prod_no
  and ply.c_Amt_Cur = cur.c_cur_cde
  and acc.c_mrk = '2'
  and ply.c_app_no = inwd.c_app_no
  and ply.t_cal_tm >= acc.t_bgn_tm
  and ply.t_cal_tm <= acc.t_end_tm
/
