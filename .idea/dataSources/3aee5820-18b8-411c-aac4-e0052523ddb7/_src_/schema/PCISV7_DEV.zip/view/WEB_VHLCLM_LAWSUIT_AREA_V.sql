CREATE VIEW WEB_VHLCLM_LAWSUIT_AREA_V AS (

Select Id As c_Id, Law_Id As c_Prt_Id, Law_Firm_Num As c_Law_Firm_No, Province As c_Adr_Pro, City As c_Adr_Cty, Area_Name As c_Address, '1' As c_New_Flg, 1 As n_Track_Num, 'admin' As c_Crt_Cde, Sysdate As t_Crt_Tm, 'admin' As c_Upd_Cde, Sysdate As t_Upd_Tm, Null As c_Trans_Mrk, Null As t_Trans_Tm
  From Web_Vhlclm_Law_Area
union All
Select T."C_ID",T."C_PRT_ID",T."C_LAW_FIRM_NO",T."C_ADR_PRO",T."C_ADR_CTY",T."C_ADDRESS",T."C_NEW_FLG",T."N_TRACK_NUM",T."C_CRT_CDE",T."T_CRT_TM",T."C_UPD_CDE",T."T_UPD_TM",T."C_TRANS_MRK",T."T_TRANS_TM" FROM  web_vhlclm_lawsuit_area  t Where t.c_new_flg ='1')
/
