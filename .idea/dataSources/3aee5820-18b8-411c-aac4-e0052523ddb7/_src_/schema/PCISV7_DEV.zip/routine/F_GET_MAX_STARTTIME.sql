CREATE FUNCTION "F_GET_MAX_STARTTIME" (VSUBJNO IN VARCHAR2 ,VSUBJSTATUS IN VARCHAR2)
return DATE
AS
V_STARTDATE DATE;
begin
  select max(startdate)INTO V_STARTDATE from t_drivers n
    where n.subjno=VSUBJNO
          and n.subjstatus=VSUBJSTATUS;
  return(V_STARTDATE);
exception
when others then
return NULL;
end F_GET_MAX_STARTTIME;









/
