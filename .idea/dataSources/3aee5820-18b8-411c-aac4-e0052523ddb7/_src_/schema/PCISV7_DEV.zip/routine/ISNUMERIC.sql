CREATE FUNCTION "ISNUMERIC" (MyStr VARCHAR2) RETURN NUMBER
IS
/*lubin 判断是否为数字，如果是则返回数字，不是则返回0*/
  STR VARCHAR2(400);
  ISNUM NUMBER;
  NUM NUMBER;
BEGIN
     ISNUM:=0;
     STR:=TRIM(MyStr);
     IF TRIM(STR) IS NULL THEN
        return 0;
     END IF;
     BEGIN
          NUM:=TO_NUMBER(STR);
          return NUM;
          EXCEPTION
          WHEN INVALID_NUMBER THEN
              return 0;
          WHEN OTHERS THEN
              return 0;
     END;
END;








/
