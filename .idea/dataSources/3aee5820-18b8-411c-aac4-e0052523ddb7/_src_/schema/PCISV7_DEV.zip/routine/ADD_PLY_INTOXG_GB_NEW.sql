CREATE procedure ADD_PLY_INTOXG_GB_NEW(BEGINDATE IN DATE, ENDDATE IN DATE) IS
      v_task_start_date  date;
      v_task_end_date    date;
      v_sql_code        number;
      v_sql_msg         varchar2(4000) := ''; ---SQL错误信息

     /*************************************
      * 共保信息数据抽取到核心中间表总存过   *
      **************************************/

BEGIN

     select sysdate into v_task_start_date from dual;
        --  共保

      INSERT INTO PRPSBUSINESSCOINSFORWEB_temp(
            ID,                --   主键
            CERTINO,           --         业务号
            CERTITYPE,         --           业务类型
            POLICYNO,          --         保单号码
            SEQNO,             --       序号
            COINSURERCODE,     --               共保人代码
            COINSFLAG,         --           主/从共标志
            COINSRATE,         --           共保比例
            COINSAMOUNT,       --             共保保额
            PREAMOUNT,         --           共保保费
            COINSCOMM,         --           代理经纪费(共保手续)
            PLYFEE,            --       出单及相关费用
            COINSAMOUNTCHG,    --               共保保额变化
            PREAMOUNTCHG,      --             共保保费变化
            PLYFEECHG,         --           出单费变化
            CREATEDATE,        --           创建时间
            UPDATEDATE        --           修改时间
    )

   SELECT
          PRPSBUSINESSCOINSFORWEB_seq.Nextval,
          NVL(wpci.c_edr_no,wpci.c_ply_no),
          --(SELECT wpb.c_app_typ FROM web_ply_base wpb WHERE wpb.c_app_no= wpci.c_app_no),
          decode(wpb.c_app_typ,'A','P','E','E'),
          wpci.c_ply_no,
          wpci.n_seq_no,
          wpci.c_coinsurer_cde,
          wpci.c_chief_mrk,-- 主从标志
          wpci.n_ci_share,
          wpci.n_ci_amt,
          wpci.n_ci_prm,
          wpci.n_comm,
          wpci.n_ply_fee,
          wpci.n_ci_amt_var,
          wpci.n_ci_prm_var,
          wpci.n_ply_fee_var,
          wpci.t_crt_tm,
          wpci.t_upd_tm


     FROM web_ply_ci wpci
     --left join  web_ply_base a    on (a.c_Sys_Res   not  IN(select  distinct c_Sys_Res from web_ply_base where c_Sys_Res='ECARGO') OR a.c_sys_res IS NULL )
     left join web_ply_base wpb on  wpb.c_app_no = wpci.c_app_no
     LEFT JOIN  web_mid_fee_to_sales sales ON sales.c_app_no = wpb.c_app_no -- 送销管中间表
     where wpci.c_app_no=WPB.c_app_no
          AND (wpb.c_Sys_Res NOT IN('ECARGO') OR wpb.c_Sys_Res IS NULL)
           and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null)
             and wpb.c_ply_no not  in ('1103711000102000920170001000',
                    '1103711000102000920170001002',
                    '1103711000102000920170001003',
                    '1103711000102000920170001004',
                    '1103711000102000920170001005',
                    '1103711000102000920170001006',
                    '1103711000102000920170001007',
                    '1103711000102000920170001016',
                    '1103711000102000920170001017',
                    '1103711000102000920170001018',
                    '1103711000102000920170001019',
                    '1103711000102000920170001021',
                    '1103711000102000920170001022')
        and  wpci.t_crt_tm BETWEEN BEGINDATE AND ENDDATE;
     --wpci.t_upd_tm BETWEEN BEGINDATE AND ENDDATE;
    COMMIT;



   v_sql_code  :=0;
  v_sql_msg   :='NORMAL,SUCCESSFUL COMPLETION';
   SELECT SYSDATE INTO v_task_end_date FROM dual;

    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_GB_NEW',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    COMMIT;






EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg||' '||':'||SQLERRM; --记录错误原因
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_GB_NEW',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
       commit;
end ADD_PLY_INTOXG_GB_NEW;
/
