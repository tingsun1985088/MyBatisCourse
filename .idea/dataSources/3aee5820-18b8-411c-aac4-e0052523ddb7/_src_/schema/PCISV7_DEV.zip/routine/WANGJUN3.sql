CREATE FUNCTION WANGJUN3(C_RPT_NO IN VARCHAR2,
                                    V_C_SNR_NO IN VARCHAR2) RETURN VARCHAR2 IS
  V_TASK_START_DATE DATE;
  V_TASK_END_DATE   DATE;
  V_SQL_CODE        NUMBER;
  V_SQL_MSG         VARCHAR2(4000) := ''; ---SQL错误信息
  V_SQL             VARCHAR2(4000);
  FLAG              VARCHAR2(2); --本级状态
  FLAG1             VARCHAR2(2); -- 子集状态
  RETURNFLAG        VARCHAR2(2);

  -- 查询公共规则
 -- DECLARE
    CURSOR RULES IS

      SELECT T.C_SQL, T.C_PARAM, T.C_RULE, T.C_RULE_NO, T.C_BLOCK_MRK
        FROM WEB_VHLCLM_AUTO_APPROVE_RULE T
       WHERE  t.c_snr_no = V_C_SNR_NO;

BEGIN

  RETURNFLAG := '1';
  FLAG1      := '1';
  FLAG       := '1';

  --DBMS_OUTPUT.PUT_LINE(C_SNR_NO);


  declare
    numrow number;

  BEGIN
     numrow :=1;
    FOR RULE IN RULES LOOP
      --IF rule IS NOT NULL THEN
    DBMS_OUTPUT.PUT_LINE(RULE.C_RULE_NO);
      --declare FLAG VARCHAR2(2);
      --declare FLAG1 VARCHAR2(2);
    numrow :=numrow +1;
      BEGIN

        DBMS_OUTPUT.PUT_LINE(numrow);

      
      END;

    END LOOP;

  END;
  RETURN RETURNFLAG;

EXCEPTION

  WHEN OTHERS THEN
    RETURN '0';
    V_SQL_CODE := SQLCODE;
    V_SQL_MSG  := V_SQL_MSG || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO V_TASK_END_DATE FROM DUAL;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'WANGJUN1',
       V_TASK_START_DATE,
       V_TASK_END_DATE,
       TO_CHAR((V_TASK_END_DATE - V_TASK_START_DATE) * 86400),
       V_SQL_CODE,
       V_SQL_MSG);
    COMMIT;

END;
/
