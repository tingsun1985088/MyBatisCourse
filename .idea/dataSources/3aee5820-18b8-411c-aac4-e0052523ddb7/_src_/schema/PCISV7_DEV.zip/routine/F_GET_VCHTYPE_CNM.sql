CREATE FUNCTION F_GET_VCHTYPE_CNM(v_vchType VARCHAR2)
  RETURN VARCHAR2 AS
  v_vchCnm VARCHAR2(100);
BEGIN

  SELECT vchtype.c_nme_cn
    INTO v_vchCnm
    FROM web_vch_type vchtype
   WHERE vchtype.c_vch_type = v_vchType;

  RETURN v_vchCnm;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;

END;
/
