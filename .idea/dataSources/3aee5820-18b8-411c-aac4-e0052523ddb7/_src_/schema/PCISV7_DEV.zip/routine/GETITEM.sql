CREATE FUNCTION       "GETITEM"      (
       	/*????*/
        item_cde       in  varchar2,
        /*????(1:??; 2:??;
        3:??;  4:???; 5:????????)*/
        send_frequency in  varchar2,
        /*????(JD:???? ;XD????)*/
        date_type      in  varchar2,
        /*???  (?????????date_value????????
        ????????????????) */
        date_value     in  varchar2,
        /*????*/
        dept_code      in  varchar2,
        /*????
        LJ:???FS???
        LJTB?????LJHB????,FSTB????,FSHB????,
	      LJTBZZ???????LJHBZZ??????,FSTBZZ??????,
        FSHBZZ??????
        */
        value_type     in  varchar2)

RETURN VARCHAR AS
  CURRENT_MONTH           VARCHAR(7);
  C_VALUE_X               VARCHAR2(200);
  C_PRE_YEAR_RATE_X       VARCHAR2(200);
  C_PRE_MONTH_RATE_X      VARCHAR2(200);
  C_MARGIN_YEAR_RATE_X    VARCHAR2(200);
  C_MARGIN_MONTH_RATE_X   VARCHAR2(200);
  C_MARGIN_X              VARCHAR2(200);
BEGIN

--????????*****************************
SELECT GETMONTH(send_frequency,date_type,date_value)
 INTO CURRENT_MONTH
 FROM DUAL;


--??????*************************************
  SELECT
    C_VALUE,
    C_PRE_YEAR_RATE,
    C_PRE_MONTH_RATE,
    C_MARGIN_YEAR_RATE,
    C_MARGIN_MONTH_RATE,
    C_MARGIN
    INTO
      C_VALUE_X,
      C_PRE_YEAR_RATE_X,
      C_PRE_MONTH_RATE_X,
      C_MARGIN_YEAR_RATE_X,
      C_MARGIN_MONTH_RATE_X,
      C_MARGIN_X
    FROM
      T_ORIGINAL_DATA
    WHERE
      C_SUB_DEPT_CDE  = dept_code
      AND C_MONTH     = CURRENT_MONTH
      AND C_FREQUENCY = send_frequency
      AND C_ITEM_CDE  = item_cde;


--?????
IF trim(value_type) = 'LJ' THEN
  return C_VALUE_X;
END IF;

--?????
IF trim(value_type) = 'FS' THEN
  return C_MARGIN_X;
END IF;

--?????
IF trim(value_type) = 'LJTB' THEN
  return C_PRE_YEAR_RATE_X;
END IF;

--?????
IF trim(value_type) = 'LJHB' THEN
  return C_PRE_MONTH_RATE_X;
END IF;

--?????
IF trim(value_type) = 'FSTB' THEN
  return C_MARGIN_YEAR_RATE_X;
END IF;

--?????
IF trim(value_type) = 'FSHB' THEN
  return C_MARGIN_MONTH_RATE_X;
END IF;

--???????
IF trim(value_type) = 'LJTBZZ' THEN
  return C_PRE_YEAR_RATE_X-1;
END IF;

--???????
IF trim(value_type) = 'LJHBZZ' THEN
  return C_PRE_MONTH_RATE_X-1;
END IF;

--???????
IF trim(value_type) = 'FSTBZZ' THEN
  return C_MARGIN_YEAR_RATE_X-1;
END IF;

--???????
IF trim(value_type) = 'FSHBZZ' THEN
  return C_MARGIN_MONTH_RATE_X-1;
END IF;
--????????***********************************

EXCEPTION
  WHEN OTHERS THEN
      RETURN '0';

END;

/
