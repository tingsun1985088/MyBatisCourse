CREATE procedure ADD_PLY_INTOXG IS
      v_task_start_date  date;
      v_task_end_date    date;
      v_sql_code        number;
      v_sql_msg         varchar2(4000) := ''; ---SQL错误信息
      begintime         DATE;  --  同步开始时间
      endtime           DATE;  --  同步结束时间

      /*************************************
      * 核心保批单数据推送销管系统总存过   *
      **************************************/

BEGIN




     SELECT  to_date(to_char(operate_bgedate,'yyyy/mm/dd hh24:mi:ss'),'yyyy/mm/dd hh24:mi:ss') INTO begintime FROM T_SYNC_ADXG_LOG;
     --SELECT  to_date(to_char(operate_bgedate,'yyyy/mm/dd hh24:mi:ss'),'yyyy/mm/dd hh24:mi:ss')+5/1440 INTO endtime FROM T_SYNC_ADXG_LOG;
     SELECT to_date(to_char(sysdate -interval '2' minute,'yyyy/mm/dd hh24:mi:ss'),'yyyy/mm/dd hh24:mi:ss') INTO endtime from dual;
     UPDATE T_SYNC_ADXG_LOG SET operate_bgedate =endtime;
     --COMMIT:

    --UPDATE T_SYNC_ADXG_LOG SET operate_bgedate = (endtime+1/24/60/60);-- between and 闭区间
    --to_date(to_char(SYSDATE,'yyyy/mm/dd hh24')||':00:00','yyyy/mm/dd hh24:mi:ss')+70/1440 存过下次执行时间


    select sysdate into v_task_start_date from dual;
    select sysdate into v_task_end_date from dual;




    --begintime  :=to_date('2017/9/26 00:00:00', 'yyyy/MM/dd hh24:mi:ss');
    --endtime    :=to_date('2017/9/26 23:00:00', 'yyyy/MM/dd hh24:mi:ss');

    -- begintime  :=to_date('2018/04/04 00:00:00', 'yyyy/MM/dd hh24:mi:ss');
    -- endtime    :=to_date('2018/04/04 23:59:59', 'yyyy/MM/dd hh24:mi:ss');

    --------------




     execute   immediate 'truncate table PRPSBUSINESSFORWEB_temp';
     execute   immediate 'truncate table PRPSBUSINESSSUBFORWEB_temp';
     execute   immediate 'truncate table PRPSBUSINESSCOINSFORWEB_temp';


    -------------  调用存储过程 P E
    ADD_PLY_INTOXG_P_NOT03(begintime,endtime);  --   非车险保单数据
    ADD_PLY_INTOXG_P_03(begintime,endtime);     --   车险保单数据
    ADD_PLY_INTOXG_E_NOT03(begintime,endtime);  --   非车险批单数据
    ADD_PLY_INTOXG_E_03(begintime,endtime);     --   车险批单数据
    ADD_PLY_INTOXG_GB(begintime,endtime);       --   共保信息数据
    ADD_PLY_INTOXG_E_NOT03_FEEUPD(begintime,endtime);     --  非车险费用调整数据
    ADD_PLY_INTOXG_GB_FEEUPD(begintime,endtime);

   -- ADD_PLY_INTOXG_DLE;

    -------------  抽取到中间表后插入log表
    INSERT INTO PRPSBUSINESSFORWEB_log SELECT * FROM PRPSBUSINESSFORWEB_temp;
    INSERT INTO PRPSBUSINESSSUBFORWEB_log SELECT * FROM PRPSBUSINESSSUBFORWEB_temp;
    INSERT INTO PRPSBUSINESSCOINSFORWEB_log SELECT * FROM PRPSBUSINESSCOINSFORWEB_temp;

    ----------------   删除渠道业务但A比例为0的数据（销管方认为数据不合理） 201608231730
    --DELETE FROM PRPSBUSINESSSUBFORWEB_temp WHERE certino IN(      -----   共保信息表
    --SELECT certino FROM PRPSBUSINESSFORWEB_temp WHERE ifchannel='1' AND a1rate=0);

    --DELETE FROM PRPSBUSINESSCOINSFORWEB_temp WHERE certino IN(    -----  报批单子表
    --SELECT certino FROM PRPSBUSINESSFORWEB_temp WHERE ifchannel='1' AND a1rate=0);

    --DELETE FROM PRPSBUSINESSFORWEB_temp WHERE ifchannel='1' AND a1rate=0;   ------  报批单主表

    -------------  删除代理渠道手续费比例为0的数据
    --DELETE FROM PRPSBUSINESSSUBFORWEB_mistake WHERE certino IN(
    --SELECT certino FROM PRPSBUSINESSFORWEB_mistake WHERE ifchannel='1' AND a1rate=0);

    --DELETE FROM PRPSBUSINESSCOINSFORWEB_mk WHERE certino IN(
    --SELECT certino FROM PRPSBUSINESSFORWEB_mistake WHERE ifchannel='1' AND a1rate=0);

    --DELETE FROM PRPSBUSINESSFORWEB_mistake WHERE ifchannel='1' AND a1rate=0;


    --DELETE FROM PRPSBUSINESSSUBFORWEB_temp t WHERE  (t.premium =0 or  t.premium is NULL) and T.certitype='P';
    --DELETE FROM PRPSBUSINESSSUBFORWEB_temp T WHERE  (T.CHGPREMIUM=0 OR T.CHGPREMIUM IS NULL) AND (t.premium =0 or  t.premium is NULL) AND T.CERTITYPE='E';
    --COMMIT;
    /*delete  from PRPSBUSINESSFORWEB_temp  where substr( asciistr(usercode) ,0,1)='\'  ; --or usercode is  null;
    delete  from PRPSBUSINESSSUBFORWEB_temp  where substr( asciistr(usercode) ,0,1)='\' ;  --or usercode is  null;
    delete  from PRPSBUSINESSCOINSFORWEB_temp where    exists ( select certino from PRPSBUSINESSFORWEB_temp  where   substr( asciistr(usercode) ,0,1)='\'  ); --or usercode is  null);
*/


    --------  往销管中间表推送数据
   add_sales_end_intoxg;   --  暂时注掉测试
   --ADD_PLY_INSERT;
   v_sql_code  :=0;
   v_sql_msg   :='NORMAL,SUCCESSFUL COMPLETION';
   SELECT SYSDATE INTO v_task_end_date FROM dual;

    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    COMMIT;





EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg||' '|| dbms_utility.format_error_backtrace||':'||SQLERRM; --记录错误原因
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
       commit;
end ADD_PLY_INTOXG;
/
