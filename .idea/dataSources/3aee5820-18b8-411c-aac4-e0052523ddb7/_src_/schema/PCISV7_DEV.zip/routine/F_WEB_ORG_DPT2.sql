CREATE function            F_WEB_ORG_DPT2(v_dpt2 varchar2)
  return varchar2 as
  v_dpt  varchar2(30);
  v_dpt_1 varchar(30);
  v_dpt_2 varchar(30);
                     ----返回二级机构
begin
v_dpt:='';
v_dpt_1:='';
v_dpt_2:='';
select x.c_dpt_cde into  v_dpt from web_org_dpt x
where x.c_dpt_cde=v_dpt2;
      /*如果机构级别不为空*/
    select y.c_snr_dpt into v_dpt_1 from web_org_dpt y where y.n_dpt_levl='3'and y.c_dpt_cde=v_dpt2;
    select y.c_snr_dpt into v_dpt_2 from web_org_dpt y where y.n_dpt_levl='2' and y.c_dpt_cde=v_dpt_1;
  return v_dpt_2;
exception
  when others then
    return '0';
    end;
/
