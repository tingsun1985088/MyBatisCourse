CREATE FUNCTION       "GETMONTH"        (	    send_frequency in varchar2,
        date_type      in  varchar2,  --????(JD:???? ;XD????)
        date_value     in  varchar2   --???  (?????????date_value????????????????????????)
         )

RETURN VARCHAR AS

CURRENT_MONTH  VARCHAR2(7);
TEMP_MONTH     VARCHAR2(7);
RELATIVELY_MONTH        NUMBER(5,0);

BEGIN

IF date_type = 'JD' THEN --????????
  CURRENT_MONTH :=  date_value;
END IF;


IF SUBSTR(date_type,1,2) = 'XD' THEN --????????

  RELATIVELY_MONTH := TO_NUMBER(TRIM( SUBSTR(date_type,3,100)));
  TEMP_MONTH := date_value;

  --????????
  IF (TRIM(send_frequency) = '1' OR TRIM(send_frequency) = '2') THEN
   SELECT
      TO_CHAR(ADD_MONTHS(TO_DATE(TEMP_MONTH,'YYYY-MM'),RELATIVELY_MONTH),'YYYY-MM')
    INTO
      CURRENT_MONTH
    FROM
      DUAL;
  END IF;

  --?????
  IF TRIM(send_frequency) = '3'  THEN
   SELECT
      TO_CHAR(ADD_MONTHS(TO_DATE(TEMP_MONTH,'YYYY-MM'),RELATIVELY_MONTH*3),'YYYY-MM')
    INTO
      CURRENT_MONTH
    FROM
      DUAL;
  END IF;

  --??????
  IF TRIM(send_frequency) = '4'  THEN
   SELECT
      TO_CHAR(ADD_MONTHS(TO_DATE(TEMP_MONTH,'YYYY-MM'),RELATIVELY_MONTH*6),'YYYY-MM')
    INTO
      CURRENT_MONTH
    FROM
      DUAL;
  END IF;

  --?????
  IF TRIM(send_frequency) = '5'  THEN
   SELECT
      TO_CHAR(ADD_MONTHS(TO_DATE(TEMP_MONTH,'YYYY-MM'),RELATIVELY_MONTH*12),'YYYY-MM')
    INTO
      CURRENT_MONTH
    FROM
      DUAL;
  END IF;

END IF;


RETURN CURRENT_MONTH;


EXCEPTION
	WHEN OTHERS THEN
			RETURN '';

END;

/
