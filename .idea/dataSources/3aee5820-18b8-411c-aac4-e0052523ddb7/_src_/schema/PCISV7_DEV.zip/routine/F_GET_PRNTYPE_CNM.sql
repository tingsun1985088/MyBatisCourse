CREATE FUNCTION F_GET_PRNTYPE_CNM(v_vchType VARCHAR2)
  RETURN VARCHAR2 AS
  v_vchCnm VARCHAR2(100);
BEGIN

   select C_NME_CN
   INTO v_vchCnm
   from WEB_PRN_TYPE where C_PRN_TYPE in(SELECT C_PRN_TYPE
          FROM WEB_VCH_TYPE typ
         WHERE typ.c_vch_type = v_vchType AND rownum = 1)
           AND rownum = 1;

  RETURN v_vchCnm;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;

END;
/
