CREATE function wm_concat(value Varchar2) return Varchar2
     parallel_enable aggregate using string_sum_obj;
/
