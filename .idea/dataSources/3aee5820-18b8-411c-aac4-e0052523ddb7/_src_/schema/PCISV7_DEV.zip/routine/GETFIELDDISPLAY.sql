CREATE FUNCTION       "GETFIELDDISPLAY"(movefield    in varchar2,
                                             movesubfield in varchar2)
  RETURN VARCHAR AS
  pos1        NUMBER(5, 0);
  pos2        NUMBER(5, 0);
  pos0        NUMBER(5, 0);
  len         NUMBER(5, 0);
  movevalue   varchar(200);
  movedisplay varchar(200);
BEGIN

  movevalue := ' ';
  len       := 0;

  pos0 := INSTR(movefield, (movesubfield || '='));

  IF pos0 = 0 THEN
    RETURN ' ';
  END IF;

  pos1 := INSTR(movefield, (movesubfield || '=')) + LENGTH(movesubfield) + 1;
  pos2 := INSTR(movefield, ';', pos1);

  IF pos2 = 0 THEN
    len := 1000;
  END IF;

  IF pos2 <> 0 THEN
    len := pos2 - pos1;
  END IF;

  movevalue := substr(movefield, pos1, len);

  select t.c_dict_nme
    into movedisplay
    from t_dict_content t
   where t.c_dict_type_cde = movesubfield and t.c_dict_cde = movevalue;

  RETURN movedisplay;

EXCEPTION
  WHEN OTHERS THEN
    RETURN ' ';

END;

/
