CREATE FUNCTION F_RI_DETECT_DATA(TBGNDATE VARCHAR2,
                                            TCHGDATE VARCHAR2,
                                            TENDDATE VARCHAR2)
  RETURN VARCHAR2 IS
  V_ERROR_MSG VARCHAR2(1000); --问题信息
  V_COUNT     NUMBER; --统计条数
  V_COUNT1    NUMBER; --统计条数1
  V_FUN_POINT VARCHAR2(100); --节点
  V_SUM_COUNT NUMBER; --总问题数据
  --返回 商业NCD浮动原因
BEGIN

  V_SUM_COUNT := 0;

  ------------------------------------------------------------------------------------------------------------------------------
  V_FUN_POINT := 'v_point_001';
  V_ERROR_MSG := '存在同一风险单位保批单不一致问题!!!';
  --检测是否有同一风险单位保批单风险等级不一致
  --若有数据则存在有不一致情况，需确认
  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_PLY_NO, D.N_SPLIT_SEQ
            FROM WEB_RI_PLYEDR_DUE D
           WHERE 1 = 1
             AND D.N_RBK_SEQ = '0'
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ
          HAVING COUNT(DISTINCT D.C_RISK_LVL_CDE) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             D.N_SPLIT_SEQ AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE 1 = 1
         AND D.N_RBK_SEQ = '0'
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ
      HAVING COUNT(DISTINCT D.C_RISK_LVL_CDE) > 1;
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------------------------------------

  V_FUN_POINT := 'v_point_002';

  V_ERROR_MSG := '存在同一保单业务渠道不一致!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_PLY_NO, D.N_SPLIT_SEQ
            FROM WEB_RI_PLYEDR_DUE D
           WHERE 1 = 1
             AND D.N_RBK_SEQ = '0'
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ
          HAVING COUNT(DISTINCT D.C_BSNS_TYP) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE 1 = 1
         AND D.N_RBK_SEQ = '0'
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ
      HAVING COUNT(DISTINCT D.C_BSNS_TYP) > 1;
  
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------------------------------------

  V_FUN_POINT := 'v_point_003';

  V_ERROR_MSG := '存在同一保单出单机构不一致!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_PLY_NO, D.N_SPLIT_SEQ
            FROM WEB_RI_PLYEDR_DUE D
           WHERE 1 = 1
             AND D.N_RBK_SEQ = '0'
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ
          HAVING COUNT(DISTINCT D.C_BSNS_TYP) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE 1 = 1
         AND D.N_RBK_SEQ = '0'
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ
      HAVING COUNT(DISTINCT D.C_BSNS_TYP) > 1;
  
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------------------------------------

  V_FUN_POINT := 'v_point_004';

  V_ERROR_MSG := '保批单接口表存在同一风险单位、批改次数、期次、冲正序号重复数据!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT C_PLY_NO
            FROM WEB_RI_PLYEDR_DUE D
           WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_PLY_NO,
                    D.N_SPLIT_SEQ,
                    D.N_EDR_PRJ_NO,
                    D.N_TMS,
                    D.N_RBK_SEQ
          HAVING COUNT(1) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             D.N_SPLIT_SEQ AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_PLY_NO,
                D.N_SPLIT_SEQ,
                D.N_EDR_PRJ_NO,
                D.N_TMS,
                D.N_RBK_SEQ
      HAVING COUNT(1) > 1;
  
    COMMIT;
  
  END IF;

  -------------------------------------------------------------------------------------------------------------------------------
  V_FUN_POINT := 'v_point_005';

  V_ERROR_MSG := '已决赔案接口表存在同一险位、赔付次数、冲正序号重复数据!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT C_CLM_NO
            FROM WEB_RI_CLM_DUE D
           WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.N_CLM_TMS, D.N_RBK_SEQ
          HAVING COUNT(1) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_CLM_DUE D
       WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.N_CLM_TMS, D.N_RBK_SEQ
      HAVING COUNT(1) > 1;
  
    COMMIT;
  
  END IF;

  -------------------------------------------------------------------------------------------------------------------------------
  V_FUN_POINT := 'v_point_006';

  V_ERROR_MSG := '未决赔案接口表存在同一险位重复数据!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT C_CLM_NO
            FROM WEB_RI_PEND_DUE D
           WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.T_TORI_TM
          HAVING COUNT(1) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PEND_DUE D
       WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.T_TORI_TM
      HAVING COUNT(1) > 1;
  
    COMMIT;
  
  END IF;

  -----------------------------------------------------------------------------------------------------------------------------

  V_FUN_POINT := 'v_point_007';

  V_ERROR_MSG := '保批单分出比例不等于100%';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT DISTINCT D.C_PLY_NO
            FROM WEB_RI_PLYEDR_DUE D, WEB_RI_PLYEDR_CED B
           WHERE D.C_PLY_NO = B.C_PLY_NO
             AND D.N_SPLIT_SEQ = B.N_SPLIT_SEQ
             AND D.N_EDR_PRJ_NO = B.N_EDR_PRJ_NO
             AND D.N_RBK_SEQ = B.N_RBK_SEQ
             AND (D.C_DOC_TYP = 'A' AND D.N_TMS = B.N_TMS OR
                 D.C_DOC_TYP = 'E')
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ, D.N_EDR_PRJ_NO, D.N_RBK_SEQ
          HAVING SUM(B.N_CED_PRPT) > 1.001 OR SUM(B.N_CED_PRPT) < 0.999);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             D.N_SPLIT_SEQ AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D, WEB_RI_PLYEDR_CED B
       WHERE D.C_PLY_NO = B.C_PLY_NO
         AND D.N_SPLIT_SEQ = B.N_SPLIT_SEQ
         AND D.N_EDR_PRJ_NO = B.N_EDR_PRJ_NO
         AND D.N_RBK_SEQ = B.N_RBK_SEQ
         AND (D.C_DOC_TYP = 'A' AND D.N_TMS = B.N_TMS OR D.C_DOC_TYP = 'E')
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_PLY_NO, D.N_SPLIT_SEQ, D.N_EDR_PRJ_NO, D.N_RBK_SEQ
      HAVING SUM(B.N_CED_PRPT) > 1.001 OR SUM(B.N_CED_PRPT) < 0.999;
  
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------------------------------------

  --赔案摊回比例不等于100%

  V_FUN_POINT := 'v_point_008';

  V_ERROR_MSG := '赔案摊回比例不等于100%';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_CLM_NO,
                 D.N_SPLIT_SEQ,
                 D.N_CLM_TMS,
                 D.N_RBK_SEQ,
                 SUM(B.N_CLM_PRPT)
            FROM WEB_RI_CLM_DUE D, WEB_RI_CLM_CED B
           WHERE D.C_CLM_NO = B.C_CLM_NO
             AND D.N_SPLIT_SEQ = B.N_SPLIT_SEQ
             AND D.N_CLM_TMS = B.N_CLM_TMS
             AND D.N_RBK_SEQ = B.N_RBK_SEQ
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.N_CLM_TMS, D.N_RBK_SEQ
          HAVING SUM(B.N_CLM_PRPT) > 1.001 OR SUM(B.N_CLM_PRPT) < 0.999);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             D.N_SPLIT_SEQ AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_CLM_DUE D, WEB_RI_CLM_CED B
       WHERE D.C_CLM_NO = B.C_CLM_NO
         AND D.N_SPLIT_SEQ = B.N_SPLIT_SEQ
         AND D.N_CLM_TMS = B.N_CLM_TMS
         AND D.N_RBK_SEQ = B.N_RBK_SEQ
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.N_CLM_TMS, D.N_RBK_SEQ
      HAVING SUM(B.N_CLM_PRPT) > 1.001 OR SUM(B.N_CLM_PRPT) < 0.999;
  
    COMMIT;
  
  END IF;

  ---------------------------------------------------------------------------------------------------------------------------------

  --检测挂账日期不对的数据，正确的挂账日期为起核保大者

  V_FUN_POINT := 'v_point_009';

  V_ERROR_MSG := '挂账日期错误，正确的挂账日期为起核保大者';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_PLY_NO,
                 D.N_SPLIT_SEQ,
                 D.N_EDR_PRJ_NO,
                 TRUNC(D.T_DUE_TM),
                 TRUNC(D.T_UDR_TM),
                 TRUNC(D.T_INSRNC_BGN_TM),
                 TRUNC(D.T_EDR_BGN_TM)
            FROM WEB_RI_PLYEDR_DUE D
           WHERE 1 = 1
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_PLY_NO,
                    D.N_SPLIT_SEQ,
                    D.N_EDR_PRJ_NO,
                    D.N_TMS,
                    D.N_RBK_SEQ,
                    D.T_DUE_TM,
                    D.T_UDR_TM,
                    D.T_INSRNC_BGN_TM,
                    D.T_EDR_BGN_TM
          HAVING TRUNC(D.T_DUE_TM) <> GREATEST(TRUNC(D.T_UDR_TM), TRUNC(D.T_INSRNC_BGN_TM), TRUNC(NVL(D.T_EDR_BGN_TM, DATE '1999-1-1'))));

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             D.N_SPLIT_SEQ AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE 1 = 1
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_PLY_NO,
                D.N_SPLIT_SEQ,
                D.N_EDR_PRJ_NO,
                D.N_TMS,
                D.N_RBK_SEQ,
                D.T_DUE_TM,
                D.T_UDR_TM,
                D.T_INSRNC_BGN_TM,
                D.T_EDR_BGN_TM
      HAVING TRUNC(D.T_DUE_TM) <> GREATEST(TRUNC(D.T_UDR_TM), TRUNC(D.T_INSRNC_BGN_TM), TRUNC(NVL(D.T_EDR_BGN_TM, DATE '1999-1-1')));
  
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------------------------------------------------------

  --检测承保未轮询转入再保中间表数据，再保未转入

  V_FUN_POINT := 'v_point_010';

  V_ERROR_MSG := '存在承保未轮询数据未转入再保';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT B.C_APP_NO, B.C_PLY_NO
            FROM WEB_MID_RI_PLYEDR_CAR B
           WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_PLYEDR_DUE A
                    WHERE A.C_APP_NO = B.C_APP_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
          UNION ALL
          SELECT B.C_APP_NO, B.C_PLY_NO
            FROM WEB_MID_RI_PLYEDR B
           WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_PLYEDR_DUE A
                    WHERE A.C_APP_NO = B.C_APP_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT B.C_APP_NO, B.C_PLY_NO
                FROM WEB_MID_RI_PLYEDR_CAR B
               WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_PLYEDR_DUE A
                        WHERE A.C_APP_NO = B.C_APP_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
              UNION ALL
              SELECT B.C_APP_NO, B.C_PLY_NO
                FROM WEB_MID_RI_PLYEDR B
               WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_PLYEDR_DUE A
                        WHERE A.C_APP_NO = B.C_APP_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE) D;
    COMMIT;
  
  END IF;
  ------------------------------------------------------------------------------------------------------------------------------

  --检测理赔未论询转入再保中间表数据，再保未转入

  V_FUN_POINT := 'v_point_011';

  V_ERROR_MSG := '存在理赔未轮询数据未转入再保';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT B.C_CLM_NO, B.C_PLY_NO
            FROM WEB_MID_RI_CLM_DUE_CAR B
           WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_CLM_DUE A
                    WHERE A.C_CLM_NO = B.C_CLM_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
          UNION ALL
          SELECT B.C_CLM_NO, B.C_PLY_NO
            FROM WEB_MID_RI_CLM_DUE B
           WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_CLM_DUE A
                    WHERE A.C_CLM_NO = B.C_CLM_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT B.C_CLM_NO, B.C_PLY_NO
                FROM WEB_MID_RI_CLM_DUE_CAR B
               WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_CLM_DUE A
                        WHERE A.C_CLM_NO = B.C_CLM_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
              UNION ALL
              SELECT B.C_CLM_NO, B.C_PLY_NO
                FROM WEB_MID_RI_CLM_DUE B
               WHERE (B.C_IS_READ = '0' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_CLM_DUE A
                        WHERE A.C_CLM_NO = B.C_CLM_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE) D;
    COMMIT;
  
  END IF;
  ------------------------------------------------------------------------------------------------------------------------------

  --检测承保已轮询转入再保中间表数据，再保未转入

  V_FUN_POINT := 'v_point_012';

  V_ERROR_MSG := '存在承保已轮询数据未转入再保';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT B.C_APP_NO, B.C_PLY_NO
            FROM WEB_MID_RI_PLYEDR_CAR B
           WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_PLYEDR_DUE A
                    WHERE A.C_APP_NO = B.C_APP_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
          UNION ALL
          SELECT B.C_APP_NO, B.C_PLY_NO
            FROM WEB_MID_RI_PLYEDR B
           WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_PLYEDR_DUE A
                    WHERE A.C_APP_NO = B.C_APP_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT B.C_APP_NO, B.C_PLY_NO
                FROM WEB_MID_RI_PLYEDR_CAR B
               WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_PLYEDR_DUE A
                        WHERE A.C_APP_NO = B.C_APP_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
              UNION ALL
              SELECT B.C_APP_NO, B.C_PLY_NO
                FROM WEB_MID_RI_PLYEDR B
               WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_PLYEDR_DUE A
                        WHERE A.C_APP_NO = B.C_APP_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE) D;
    COMMIT;
  
  END IF;
  ------------------------------------------------------------------------------------------------------------------------------

  --检测理赔已轮询转入再保中间表数据，再保未转入

  V_FUN_POINT := 'v_point_013';

  V_ERROR_MSG := '存在理赔已论询数据未转入再保';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT B.C_CLM_NO, B.C_PLY_NO
            FROM WEB_MID_RI_CLM_DUE_CAR B
           WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_CLM_DUE A
                    WHERE A.C_CLM_NO = B.C_CLM_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
          UNION ALL
          SELECT B.C_CLM_NO, B.C_PLY_NO
            FROM WEB_MID_RI_CLM_DUE B
           WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_CLM_DUE A
                    WHERE A.C_CLM_NO = B.C_CLM_NO))
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
             AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT B.C_CLM_NO, B.C_PLY_NO
                FROM WEB_MID_RI_CLM_DUE_CAR B
               WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_CLM_DUE A
                        WHERE A.C_CLM_NO = B.C_CLM_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE
              UNION ALL
              SELECT B.C_CLM_NO, B.C_PLY_NO
                FROM WEB_MID_RI_CLM_DUE B
               WHERE (B.C_IS_READ = '1' OR NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_CLM_DUE A
                        WHERE A.C_CLM_NO = B.C_CLM_NO))
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') <= TENDDATE
                 AND TO_CHAR(B.T_DUE_TM, 'yyyymmdd') >= TBGNDATE) D;
    COMMIT;
  
  END IF;
  ------------------------------------------------------------------------------------------------------------------------------

  --检测未决接口中间表转入再保未决接口表数据，再保未转入

  V_FUN_POINT := 'v_point_014';

  V_ERROR_MSG := '存在未决接口表数据未转入再保';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT B.C_CLM_NO, B.C_PLY_NO
            FROM WEB_MID_RI_PEND_DUE B
           WHERE (NOT EXISTS
                  (SELECT 'X'
                     FROM WEB_RI_PEND_DUE A
                    WHERE A.C_CLM_NO = B.C_CLM_NO
                      AND TO_CHAR(A.T_TORI_TM, 'yyyymmdd') = TENDDATE))
             AND TO_CHAR(B.T_TORI_TM, 'yyyymmdd') = TENDDATE);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT B.C_CLM_NO, B.C_PLY_NO
                FROM WEB_MID_RI_PEND_DUE B
               WHERE (NOT EXISTS
                      (SELECT 'X'
                         FROM WEB_RI_PEND_DUE A
                        WHERE A.C_CLM_NO = B.C_CLM_NO
                          AND TO_CHAR(A.T_TORI_TM, 'yyyymmdd') = TENDDATE))
                 AND TO_CHAR(B.T_TORI_TM, 'yyyymmdd') = TENDDATE) D;
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------------------------------------

  --检测接口表未自动计算的保批单数据

  V_FUN_POINT := 'v_point_015';

  V_ERROR_MSG := '存在接口表未自动计算的保批单数据';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT B.C_APP_NO, B.C_PLY_NO
            FROM WEB_RI_PLYEDR_DUE B
           WHERE TO_CHAR(B.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND B.C_STATUS = 'A'
          UNION ALL
          SELECT B.C_CLM_NO, B.C_PLY_NO
            FROM WEB_RI_CLM_DUE B
           WHERE TO_CHAR(B.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
             AND B.C_STATUS = 'A'
          UNION ALL
          SELECT B.C_CLM_NO, B.C_PLY_NO
            FROM WEB_RI_PEND_DUE B
           WHERE TO_CHAR(B.T_TORI_TM, 'yyyymmdd') <= TENDDATE
             AND B.C_STATUS = 'A');

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT B.C_APP_NO, B.C_PLY_NO
                FROM WEB_RI_PLYEDR_DUE B
               WHERE TO_CHAR(B.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
                 AND B.C_STATUS = 'A'
              UNION ALL
              SELECT B.C_CLM_NO, B.C_PLY_NO
                FROM WEB_RI_CLM_DUE B
               WHERE TO_CHAR(B.T_RIDUE_TM, 'yyyymmdd') <= TENDDATE
                 AND B.C_STATUS = 'A'
              UNION ALL
              SELECT B.C_CLM_NO, B.C_PLY_NO
                FROM WEB_RI_PEND_DUE B
               WHERE TO_CHAR(B.T_TORI_TM, 'yyyymmdd') <= TENDDATE
                 AND B.C_STATUS = 'A') D;
    COMMIT;
  
  END IF;

  -------------------------------------------------------------------------------------------------------------------------------

  --检测车理赔已决接口表赔案号数量不等于已拆分子险的赔案号数量

  V_FUN_POINT := 'v_point_016';

  V_ERROR_MSG := '存在车理赔已决接口表赔案号数量与已拆分子险的赔案号数量不一致!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT DISTINCT D.C_CLM_NO
            FROM WEB_RI_CLM_DUE D --已决接口表
           WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE --再保挂账日期
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
             AND D.C_PROD_NO LIKE '03%' --产品代码 Product Code
             AND D.N_ORG_CLM_AMT != 0 --原赔付金额
           GROUP BY D.C_CLM_NO --赔案号
          MINUS
          SELECT DISTINCT A.CLAIMNO --主表 子表 险别表
            FROM MM_POLICY_TI A, MM_POLICYLIST_TI B, MM_CHARGEDETAIL_TI C
           WHERE A.ID = B.SEQPOLICY --关联mm_policy_ti主键
             AND B.ID = C.SEQCHARGE --
             AND A.CLAIMNO IN --赔案号
                 (SELECT D.C_CLM_NO
                    FROM WEB_RI_CLM_DUE D
                   WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
                     AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
                     AND D.C_PROD_NO LIKE '03%'
                     AND D.N_ORG_CLM_AMT != 0)
             AND EXISTS
           (SELECT 'X'
                    FROM WEB_RI_CLM_DUE DUE
                   WHERE A.POLICYNO = DUE.C_PLY_NO --保单号
                     AND A.CLAIMNO = DUE.C_CLM_NO
                     AND DUE.N_APP_NUM = A.SERIALNO --理算序号-华海需求(目前暂为送收付区分险别用) 、序号 
                     AND ((DUE.C_CLM_TYP NOT IN ('7', '8') AND --赔付类型
                         B.DATATYPE NOT IN
                         ('42', '43', '44', '45', '46', '47') OR
                         (DUE.C_CLM_TYP = '7' AND B.DATATYPE = '45') OR
                         (DUE.C_CLM_TYP = '8' AND B.DATATYPE = '42'))))
           GROUP BY A.CLAIMNO, --赔案号
                    A.SERIALNO, --序号  
                    C.POLICYNO, --保单号   
                    C.ENDORSENO, --批单号  
                    C.CURRENCYCODE, --币种代码
                    C.CLASSESCODE --业务险种 
           ORDER BY C_CLM_NO);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT <> 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT DISTINCT D.C_CLM_NO
                FROM WEB_RI_CLM_DUE D --已决接口表
               WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE --再保挂账日期
                 AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
                 AND D.C_PROD_NO LIKE '03%' --产品代码 Product Code
                 AND D.N_ORG_CLM_AMT != 0 --原赔付金额
               GROUP BY D.C_CLM_NO --赔案号
              MINUS
              SELECT DISTINCT A.CLAIMNO --主表 子表 险别表
                FROM MM_POLICY_TI       A,
                     MM_POLICYLIST_TI   B,
                     MM_CHARGEDETAIL_TI C
               WHERE A.ID = B.SEQPOLICY --关联mm_policy_ti主键
                 AND B.ID = C.SEQCHARGE --
                 AND A.CLAIMNO IN --赔案号
                     (SELECT D.C_CLM_NO
                        FROM WEB_RI_CLM_DUE D
                       WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
                         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
                         AND D.C_PROD_NO LIKE '03%'
                         AND D.N_ORG_CLM_AMT != 0)
                 AND EXISTS
               (SELECT 'X'
                        FROM WEB_RI_CLM_DUE DUE
                       WHERE A.POLICYNO = DUE.C_PLY_NO --保单号
                         AND A.CLAIMNO = DUE.C_CLM_NO
                         AND DUE.N_APP_NUM = A.SERIALNO --理算序号-华海需求(目前暂为送收付区分险别用) 、序号 
                         AND ((DUE.C_CLM_TYP NOT IN ('7', '8') AND --赔付类型
                             B.DATATYPE NOT IN
                             ('42', '43', '44', '45', '46', '47') OR
                             (DUE.C_CLM_TYP = '7' AND B.DATATYPE = '45') OR
                             (DUE.C_CLM_TYP = '8' AND B.DATATYPE = '42'))))
               GROUP BY A.CLAIMNO, --赔案号
                        A.SERIALNO, --序号  
                        C.POLICYNO, --保单号   
                        C.ENDORSENO, --批单号  
                        C.CURRENCYCODE, --币种代码
                        C.CLASSESCODE --业务险种 
               ORDER BY C_CLM_NO) D;
    COMMIT;
  
  END IF;

  -------------------------------------------------------------------------------------------------------------------------------

  --检测非车理赔已决接口表赔案号数量不等于已拆分子险的赔案号数量

  V_FUN_POINT := 'v_point_017';

  V_ERROR_MSG := '存在非车理赔已决接口表赔案号数量与已拆分子险的赔案号数量不一致!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT DISTINCT D.C_CLM_NO
            FROM WEB_RI_CLM_DUE D
           WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
             AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
             AND D.C_PROD_NO NOT LIKE '03%'
             AND D.N_ORG_CLM_AMT != 0
           GROUP BY D.C_CLM_NO
          MINUS
          SELECT DISTINCT A.CLAIMNO
            FROM MM_POLICY_TI A, MM_POLICYLIST_TI B, MM_CHARGEDETAIL_TI C
           WHERE A.ID = B.SEQPOLICY
             AND B.ID = C.SEQCHARGE
             AND A.CLAIMNO IN
                 (SELECT D.C_CLM_NO
                    FROM WEB_RI_CLM_DUE D
                   WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
                     AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
                     AND D.C_PROD_NO NOT LIKE '03%'
                     AND D.N_RI_CLM_AMT != 0)
             AND EXISTS
           (SELECT 'X'
                    FROM WEB_RI_CLM_DUE DUE
                   WHERE A.POLICYNO = DUE.C_PLY_NO
                     AND A.CLAIMNO = DUE.C_CLM_NO
                     AND DUE.N_CLM_TMS = REPLACE(A.PAYMENT_TYPE, '-', ''))
           GROUP BY A.CLAIMNO,
                    A.SERIALNO,
                    C.POLICYNO,
                    C.ENDORSENO,
                    C.CURRENCYCODE,
                    C.CLASSESCODE
           ORDER BY C_CLM_NO);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT <> 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT DISTINCT D.C_CLM_NO
                FROM WEB_RI_CLM_DUE D
               WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
                 AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
                 AND D.C_PROD_NO NOT LIKE '03%'
                 AND D.N_ORG_CLM_AMT != 0
               GROUP BY D.C_CLM_NO
              MINUS
              SELECT DISTINCT A.CLAIMNO
                FROM MM_POLICY_TI       A,
                     MM_POLICYLIST_TI   B,
                     MM_CHARGEDETAIL_TI C
               WHERE A.ID = B.SEQPOLICY
                 AND B.ID = C.SEQCHARGE
                 AND A.CLAIMNO IN
                     (SELECT D.C_CLM_NO
                        FROM WEB_RI_CLM_DUE D
                       WHERE TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') >= TBGNDATE
                         AND TO_CHAR(D.T_RIDUE_TM, 'yyyymmdd') < TENDDATE
                         AND D.C_PROD_NO NOT LIKE '03%'
                         AND D.N_RI_CLM_AMT != 0)
                 AND EXISTS
               (SELECT 'X'
                        FROM WEB_RI_CLM_DUE DUE
                       WHERE A.POLICYNO = DUE.C_PLY_NO
                         AND A.CLAIMNO = DUE.C_CLM_NO
                         AND DUE.N_CLM_TMS = REPLACE(A.PAYMENT_TYPE, '-', ''))
               GROUP BY A.CLAIMNO,
                        A.SERIALNO,
                        C.POLICYNO,
                        C.ENDORSENO,
                        C.CURRENCYCODE,
                        C.CLASSESCODE
               ORDER BY C_CLM_NO) D;
    COMMIT;
  
  END IF;

  -------------------------------------------------------------------------------------------------------------------------------

  --检测非车理赔在险位摊分表的多条重复数据

  V_FUN_POINT := 'v_point_018';

  V_ERROR_MSG := '存在非车理赔在险位摊分表的多条重复数据!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_CLM_NO,
                 D.C_RISK_UNIT_NME,
                 D.N_THIS_APPOAMT,
                 D.N_OLD_APPOAMT,
                 D.N_AMT,
                 D.N_SEQ_NO,
                 D.N_RI_CLM,
                 D.C_RISK_LVL_CDE
            FROM WEB_CLM_RISKUNIT_AMTAPPO D --险位摊分表
           GROUP BY D.C_CLM_NO,
                    D.C_RISK_UNIT_NME,
                    D.N_THIS_APPOAMT,
                    D.N_OLD_APPOAMT,
                    D.N_AMT,
                    D.N_SEQ_NO,
                    D.N_RI_CLM,
                    D.C_RISK_LVL_CDE
          HAVING COUNT(1) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_CLM_RISKUNIT_AMTAPPO D
       GROUP BY D.C_CLM_NO,
                D.C_RISK_UNIT_NME,
                D.N_THIS_APPOAMT,
                D.N_OLD_APPOAMT,
                D.N_AMT,
                D.N_SEQ_NO,
                D.N_RI_CLM,
                D.C_RISK_LVL_CDE
      HAVING COUNT(1) > 1;
  
    COMMIT;
  
  END IF;

  -------------------------------------------------------------------------------------------------------------------------------

  --检测分保、已决摊赔计算多次的数据

  V_FUN_POINT := 'v_point_019';

  V_ERROR_MSG := '已决赔案接口表存在分保、已决摊赔计算多次的数据';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_CLM_NO,
                 D.N_SPLIT_SEQ,
                 D.N_CLM_TMS,
                 D.N_RBK_SEQ,
                 SUM(D.N_CLM_PRPT) --摊回比例  
            FROM WEB_RI_CLM_CED D
           WHERE TO_CHAR(D.T_CRT_TM, 'yyyymmdd') >= TBGNDATE
           GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.N_CLM_TMS, D.N_RBK_SEQ
          HAVING SUM(D.N_CLM_PRPT) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_CLM_CED D
       WHERE TO_CHAR(D.T_CRT_TM, 'yyyymmdd') >= TBGNDATE
       GROUP BY D.C_CLM_NO, D.N_SPLIT_SEQ, D.N_CLM_TMS, D.N_RBK_SEQ
      HAVING SUM(D.N_CLM_PRPT) > 1;
  
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------------------------

  --检测未决接口表转入多次及未决摊赔计算多次

  V_FUN_POINT := 'v_point_020';

  V_ERROR_MSG := '未决赔案接口表存在未决接口表转入多次及未决摊赔计算多次的数据!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_CLM_NO,
                 D.N_SPLIT_SEQ,
                 D.N_RBK_SEQ,
                 D.C_PEND_YM,
                 D.C_PLY_NO,
                 D.N_PLY_TMS,
                 D.N_PLY_SPLIT_SEQ,
                 D.N_PLY_RBK_SEQ,
                 D.C_PROD_NO,
                 D.N_ORG_CLM_AMT,
                 D.N_RI_CLM_AMT
            FROM WEB_RI_PEND_DUE D
           WHERE TO_CHAR(D.T_TORI_TM, 'yyyymmdd') = TENDDATE
          --日期修改为当前日期的前一天
           GROUP BY D.C_CLM_NO,
                    D.N_SPLIT_SEQ,
                    D.N_RBK_SEQ,
                    D.C_PEND_YM,
                    D.C_PLY_NO,
                    D.N_PLY_TMS,
                    D.N_PLY_SPLIT_SEQ,
                    D.N_PLY_RBK_SEQ,
                    D.C_PROD_NO,
                    D.N_ORG_CLM_AMT,
                    D.N_RI_CLM_AMT
          HAVING COUNT(1) > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_CLM_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PEND_DUE D
       WHERE TO_CHAR(D.T_TORI_TM, 'yyyymmdd') = TENDDATE
      --日期修改为当前日期的前一天
       GROUP BY D.C_CLM_NO,
                D.N_SPLIT_SEQ,
                D.N_RBK_SEQ,
                D.C_PEND_YM,
                D.C_PLY_NO,
                D.N_PLY_TMS,
                D.N_PLY_SPLIT_SEQ,
                D.N_PLY_RBK_SEQ,
                D.C_PROD_NO,
                D.N_ORG_CLM_AMT,
                D.N_RI_CLM_AMT
      HAVING COUNT(1) > 1;
  
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------

  --检测分保计算分出情况不对的数据

  V_FUN_POINT := 'v_point_021';

  V_ERROR_MSG := '再保保批单接口表存在分保计算分出情况不对的数据';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_APP_NO, D.N_SPLIT_SEQ
             FROM WEB_RI_PLYEDR_DUE D
            WHERE /*d.c_prod_no not like '03%'-- ('033001', '033011', '033014')
                                                                                                                                                                                                                                                                                                                                                     and*/
            D.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyymmdd')
         AND D.C_RISK_LVL_CDE NOT IN ('00000000', '99999999', '00000')
         AND D.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyymmdd')
         AND D.N_RBK_SEQ = 0
         AND NOT EXISTS (SELECT 1
               FROM WEB_RI_PLYEDR_CED C
              WHERE C.C_APP_NO = D.C_APP_NO
                AND C.N_SPLIT_SEQ = D.N_SPLIT_SEQ
                AND C.N_RBK_SEQ = D.N_RBK_SEQ
                AND C.N_EDR_PRJ_NO = D.N_EDR_PRJ_NO
                AND C.C_CONT_CDE IN ('CPCR_QS',
                                     'FV_QSS',
                                     'Marine_QSS',
                                     'NM_QSS',
                                     'SV_QS',
                                     'Liability_Facility',
                                     'PI_QS'))
            ORDER BY C_PLY_NO DESC);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE /*d.c_prod_no not like '03%'-- ('033001', '033011', '033014')
                                                                                                                                                                                          and*/
       D.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyymmdd')
       AND D.C_RISK_LVL_CDE NOT IN ('00000000', '99999999', '00000')
       AND D.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyymmdd')
       AND D.N_RBK_SEQ = 0
       AND NOT EXISTS (SELECT 1
          FROM WEB_RI_PLYEDR_CED C
         WHERE C.C_APP_NO = D.C_APP_NO
           AND C.N_SPLIT_SEQ = D.N_SPLIT_SEQ
           AND C.N_RBK_SEQ = D.N_RBK_SEQ
           AND C.N_EDR_PRJ_NO = D.N_EDR_PRJ_NO
           AND C.C_CONT_CDE IN ('CPCR_QS',
                                'FV_QSS',
                                'Marine_QSS',
                                'NM_QSS',
                                'SV_QS',
                                'Liability_Facility',
                                'PI_QS'))
       ORDER BY C_PLY_NO DESC;
  
    COMMIT;
  
  END IF;

  ---------------------------------------------------------------------------------------------------------------

  --检查非车理赔没有写赔付类型的赔案

  V_FUN_POINT := 'v_point_022';

  V_ERROR_MSG := '存在非车理赔没有写赔付类型的赔案!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT T.PAYMENT_TYPE, T.CLAIMNO
            FROM MM_POLICY_TI T
           WHERE T.CLAIMNO IN
                 (SELECT D.C_CLM_NO
                    FROM WEB_RI_CLM_DUE D
                   WHERE TO_CHAR(D.T_RIDUE_TM, 'TCHGDATE') = TCHGDATE --挂账日期
                     AND D.C_CLM_NO LIKE '4%')
             AND T.PAYMENT_TYPE IS NULL);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             T.CLAIMNO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM MM_POLICY_TI T
       WHERE T.CLAIMNO IN
             (SELECT D.C_CLM_NO
                FROM WEB_RI_CLM_DUE D
               WHERE TO_CHAR(D.T_RIDUE_TM, 'TCHGDATE') = TCHGDATE --挂账日期
                 AND D.C_CLM_NO LIKE '4%')
         AND T.PAYMENT_TYPE IS NULL;
  
    COMMIT;
  
  END IF;

  -----------------------------------------------------------------------------------------------------------------

  --检查再保分出明细接口表自留额不对的数据

  V_FUN_POINT := 'v_point_023';

  V_ERROR_MSG := '再保分出明细接口表存在自留额不对的数据';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_PLY_NO, D.C_EDR_NO, D.N_SPLIT_SEQ, SUM(D.N_CED_PRPT)
            FROM WEB_RI_PLYEDR_CED D
           WHERE TO_CHAR(D.T_CRT_TM, 'TCHGDATE') = TCHGDATE
             AND D.C_CONT_CDE NOT IN ('AR', '04', 'BB', 'FA')
           GROUP BY D.C_PLY_NO, D.C_EDR_NO, D.N_SPLIT_SEQ
          HAVING SUM(D.N_CED_PRPT) >= 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_CED D
       WHERE TO_CHAR(D.T_CRT_TM, 'TCHGDATE') = TCHGDATE
         AND D.C_CONT_CDE NOT IN ('AR', '04', 'BB', 'FA')
       GROUP BY D.C_PLY_NO, D.C_EDR_NO, D.N_SPLIT_SEQ
      HAVING SUM(D.N_CED_PRPT) >= 1;
  
    COMMIT;
  
  END IF;

  -----------------------------------------------------------------------------------------------------------------

  --校查再保保批单风险单位表与保批单接口表风险等级不一致的数据

  V_FUN_POINT := 'v_point_024';

  V_ERROR_MSG := '再保保批单风险单位表与保批单接口表存在风险等级不一致的数据！';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT A.C_APP_NO, A.C_RISK_LVL_CDE, B.C_RISK_LVL_CDE
            FROM WEB_RI_PLYEDR_DUE A, WEB_PLY_RISK_UNIT B
           WHERE A.C_APP_NO = B.C_PLY_APP_NO
             AND A.N_SPLIT_SEQ = B.N_SEQ_NO
             AND A.N_EDR_PRJ_NO = B.N_EDR_PRJ_NO
             AND A.C_FAC_MRK = B.C_FAC_MRK
             AND A.C_RISK_LVL_CDE <> B.C_RISK_LVL_CDE
             AND TO_CHAR(A.T_RIDUE_TM, 'TCHGDATE') = TCHGDATE);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             A.C_APP_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE A, WEB_PLY_RISK_UNIT B
       WHERE A.C_APP_NO = B.C_PLY_APP_NO
         AND A.N_SPLIT_SEQ = B.N_SEQ_NO
         AND A.N_EDR_PRJ_NO = B.N_EDR_PRJ_NO
         AND A.C_FAC_MRK = B.C_FAC_MRK
         AND A.C_RISK_LVL_CDE <> B.C_RISK_LVL_CDE
         AND TO_CHAR(A.T_RIDUE_TM, 'TCHGDATE') = TCHGDATE;
  
    COMMIT;
  
  END IF;

  -----------------------------------------------------------------------------------------------------------------

  --校查再保保批单风险单位表与保批单接口表自留额不一致的数据

  V_FUN_POINT := 'v_point_025';

  V_ERROR_MSG := '再保保批单风险单位表与保批单接口表存在自留额不一致的数据！';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT A.C_PLY_NO, A.N_RET_AMT, B.N_RET_AMT
            FROM WEB_RI_PLYEDR_DUE A, WEB_PLY_RISK_UNIT B
           WHERE A.C_APP_NO = B.C_PLY_APP_NO
             AND A.N_SPLIT_SEQ = B.N_SEQ_NO
             AND A.N_EDR_PRJ_NO = B.N_EDR_PRJ_NO
             AND A.C_FAC_MRK = B.C_FAC_MRK
             AND A.C_RISK_LVL_CDE = B.C_RISK_LVL_CDE
             AND A.N_RBK_SEQ = '0'
             AND A.N_RET_AMT <> B.N_RET_AMT
             AND TO_CHAR(A.T_RIDUE_TM, 'TCHGDATE') = TCHGDATE);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             A.C_APP_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE A, WEB_PLY_RISK_UNIT B
       WHERE A.C_APP_NO = B.C_PLY_APP_NO
         AND A.N_SPLIT_SEQ = B.N_SEQ_NO
         AND A.N_EDR_PRJ_NO = B.N_EDR_PRJ_NO
         AND A.C_FAC_MRK = B.C_FAC_MRK
         AND A.C_RISK_LVL_CDE = B.C_RISK_LVL_CDE
         AND A.N_RBK_SEQ = '0'
         AND A.N_RET_AMT <> B.N_RET_AMT
         AND TO_CHAR(A.T_RIDUE_TM, 'TCHGDATE') = TCHGDATE;
  
    COMMIT;
  
  END IF;

  ------------------------------------------------------------------------------------------------

  --校查保批单接口表业务来源校验，临分分入保单、批单的业务来源为D01、B01

  V_FUN_POINT := 'v_point_026';

  V_ERROR_MSG := '再保保批单接口表存在临分分入保批单业务来源的数据！';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT DISTINCT D.C_BSNS_TYP, D.C_PLY_NO
            FROM WEB_RI_PLYEDR_DUE D
           WHERE 1 = 1
             AND D.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyy-mm-dd')
             AND D.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyy-mm-dd')
             AND LENGTH(D.C_BSNS_TYP) <> 10);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE 1 = 1
         AND D.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyy-mm-dd')
         AND D.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyy-mm-dd')
         AND LENGTH(D.C_BSNS_TYP) <> 10;
  
    COMMIT;
  
  END IF;

  -----------------------------------------------------------------------------------------------------------------

  --校查保批单接口表支付时间是否为空校验的数据

  V_FUN_POINT := 'v_point_027';

  V_ERROR_MSG := '再保保批单接口表存在支付时间为空校验的数据！';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT D.C_PLY_NO, D.T_PAY_TM
            FROM WEB_RI_PLYEDR_DUE D
           WHERE 1 = 1
             AND D.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyy-mm-dd')
             AND D.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyy-mm-dd')
             AND D.T_PAY_TM IS NULL);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.C_PLY_NO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM WEB_RI_PLYEDR_DUE D
       WHERE 1 = 1
         AND D.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyy-mm-dd')
         AND D.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyy-mm-dd')
         AND D.T_PAY_TM IS NULL;
  
    COMMIT;
  
  END IF;

  --------------------------------------------------------------------------------------------------------------------------------

  --校查当月保单数据，是否都能查到承保的子险信息

  V_FUN_POINT := 'v_point_028';

  V_ERROR_MSG := '当月保单有存在查不到承保的子险信息数据！';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT A.C_PLY_NO
            FROM WEB_RI_PLYEDR_DUE A
           WHERE A.C_DOC_TYP = 'A'
                /*AND A.T_RIDUE_TM BETWEEN DATE TBGNDATE AND DATE TENDDATE*/
             AND A.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyymmdd')
             AND A.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyymmdd')
           GROUP BY A.C_PLY_NO
           ORDER BY A.C_PLY_NO);

  SELECT COUNT(1)
    INTO V_COUNT1
    FROM (SELECT A.POLICYNO
            FROM MM_CHARGEDETAIL_TI A
           WHERE EXISTS
           (SELECT 'X'
                    FROM MM_POLICYLIST_TI B, MM_POLICY_TI C
                   WHERE A.SEQCHARGE = B.ID
                     AND C.ID = B.SEQPOLICY
                     AND C.POLICYNO IN
                         (SELECT F.C_PLY_NO
                            FROM WEB_RI_PLYEDR_DUE F
                           WHERE F.C_DOC_TYP = 'A'
                             AND F.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyymmdd')
                             AND F.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyymmdd')
                           GROUP BY F.C_PLY_NO)
                     AND C.CERTITYPE = '1'
                     AND C.CLAIMNO IS NULL)
             AND A.ENDORSENO IS NULL
           GROUP BY A.POLICYNO
          UNION ALL
          SELECT F.C_PLY_NO
            FROM WEB_RI_PLYEDR_DUE F
           WHERE F.C_DOC_TYP = 'A'
             AND F.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyymmdd')
             AND F.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyymmdd')
             AND NOT EXISTS (SELECT *
                    FROM MM_CHARGEDETAIL_TI A
                   WHERE A.POLICYNO = F.C_PLY_NO)
           GROUP BY F.C_PLY_NO
           ORDER BY POLICYNO);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT <> V_COUNT1) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG
      SELECT SYS_GUID() AS C_PK_ID,
             '0' AS C_TYPE,
             '0' AS C_STAUS,
             SYSDATE AS T_EXE_TM,
             'F_RI_DETECT_DATA' AS C_FUN_NME,
             V_FUN_POINT AS C_FUN_EXE_POINT,
             D.POLICYNO AS C_DOC_NO,
             '' AS N_SPLIT_SEQ,
             V_COUNT AS N_COUNT_EDATA,
             V_ERROR_MSG AS C_ERR_MSG,
             '' AS C_RESV_TXT_1,
             '' AS C_RESV_TXT_2,
             '' AS C_RESV_TXT_3,
             'Ri' AS C_CRT_CDE,
             SYSDATE AS T_CRT_TM,
             'Ri' AS C_UPD_CDE,
             SYSDATE AS T_UPD_TM
        FROM (SELECT A.POLICYNO
                FROM MM_CHARGEDETAIL_TI A
               WHERE EXISTS (SELECT 'X'
                        FROM MM_POLICYLIST_TI B, MM_POLICY_TI C
                       WHERE A.SEQCHARGE = B.ID
                         AND C.ID = B.SEQPOLICY
                         AND C.POLICYNO IN
                             (SELECT F.C_PLY_NO
                                FROM WEB_RI_PLYEDR_DUE F
                               WHERE F.C_DOC_TYP = 'A'
                                 AND F.T_RIDUE_TM >=
                                     TO_DATE(TBGNDATE, 'yyyymmdd')
                                 AND F.T_RIDUE_TM <
                                     TO_DATE(TENDDATE, 'yyyymmdd')
                               GROUP BY F.C_PLY_NO)
                         AND C.CERTITYPE = '1'
                         AND C.CLAIMNO IS NULL)
                 AND A.ENDORSENO IS NULL
               GROUP BY A.POLICYNO
              UNION ALL
              SELECT F.C_PLY_NO
                FROM WEB_RI_PLYEDR_DUE F
               WHERE F.C_DOC_TYP = 'A'
                 AND F.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyymmdd')
                 AND F.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyymmdd')
                 AND NOT EXISTS (SELECT *
                        FROM MM_CHARGEDETAIL_TI A
                       WHERE A.POLICYNO = F.C_PLY_NO)
               GROUP BY F.C_PLY_NO
               ORDER BY POLICYNO) D;
  
    COMMIT;
  
  END IF;

  -----------------------------------------------------------------------------------------------------------------

  SELECT COUNT(1)
    INTO V_COUNT
    FROM WEB_RI_PLYEDR_DUE D
   WHERE D.C_RISK_LVL_CDE NOT IN ('00000000', '99999999', '00000')
     AND D.T_RIDUE_TM >= TO_DATE(TBGNDATE, 'yyyymmdd')
     AND D.T_RIDUE_TM < TO_DATE(TENDDATE, 'yyyymmdd')
     AND D.N_RBK_SEQ = 0
     AND NOT EXISTS
   (SELECT 1
            FROM WEB_RI_PLYEDR_CED C
           WHERE C.C_APP_NO = D.C_APP_NO
             AND C.N_SPLIT_SEQ = D.N_SPLIT_SEQ
             AND C.N_RBK_SEQ = D.N_RBK_SEQ
             AND C.N_EDR_PRJ_NO = D.N_EDR_PRJ_NO
             AND C.C_CONT_ID IN (SELECT C_CONT_ID FROM WEB_RI_CONT_MAIN))
   ORDER BY C_PLY_NO DESC;

  ----------------------------------------------------------------------------------------------------

  RETURN V_SUM_COUNT;
  /*exception
  when others then
    return 11111111;*/
END F_RI_DETECT_DATA;
/
