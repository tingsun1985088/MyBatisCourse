CREATE FUNCTION "GET_EDR_PRM_SUM" (ply_no IN VARCHAR2,
                                           vstrd  DATE,
                                           vendd  DATE) RETURN NUMBER AS
  rcpt NUMBER(20, 2) := 0;
BEGIN

  SELECT SUM(n_prm_var)
    INTO rcpt
    FROM web_ply_base a
   WHERE a.c_app_typ = 'E'
     AND c_ply_no = ply_no
     AND a.t_udr_tm >= vstrd
     AND a.t_udr_tm <= vendd
     AND a.c_udr_mrk = '1';
  RETURN rcpt;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;








/
