CREATE FUNCTION "F_GET_PRESPLCONTRACT" (V_APLNO varchar2)
return varchar2 is
--对特别约定进行预处理，将同一个申请单的合并到一个去
V_SPLCONTRACT             varchar2(8000);
V_SPLCONTRACT_TEMP        varchar2(8000);
V_SPLCONTRACT_HEX         varchar2(8000); --十六进制特别约定
V_SPLCONTRACT_HEX_TEMP    varchar2(8000); --临时十六进制特别约定
V_size                    number ;
V_DUMP_HX                 varchar2(8000);
V_LENGTH                  number        ; --长度
V_NUM                     number        ;
V_ZTCD                    number        ;

begin

V_SPLCONTRACT :='';
V_SPLCONTRACT_TEMP      :='';
V_SPLCONTRACT_HEX_TEMP  :='';
V_SPLCONTRACT_HEX       :='';
V_size    :=0;
V_NUM     :=0;

for p in (select  serialno,SPLCONTENT from T_SPLCONTRACT where APLNO=V_APLNO--'AA00AA02DHA2010T001665'
and splcode='SPL'--and serialno in ('500')
order by serialno
)
loop
  V_NUM  :=V_NUM+1;
  select dump(p.SPLCONTENT,16) into V_DUMP_HX from dual ; --取16进制

--将开头的回车换行去掉

  V_DUMP_HX :=replace(V_DUMP_HX,': d,',': 0d,');--将回车替换掉
  V_DUMP_HX :=replace(V_DUMP_HX,': a,',': 0a,');--将换行替换掉
  V_DUMP_HX :=replace(V_DUMP_HX,': 9,',': 09,');--
  /*if(substrb(V_DUMP_HX,instr(V_DUMP_HX,':')+2,2)='d,')
  then
  V_DUMP_HX :='0d,'||substrb(V_DUMP_HX,instr(V_DUMP_HX,':')+5); --将开头的回车去掉
  end if ;
  if(substrb(V_DUMP_HX,instr(V_DUMP_HX,':')+2,2)='a,')
  then
  V_DUMP_HX :='0a,'||substrb(V_DUMP_HX,instr(V_DUMP_HX,':')+5); --将开头的换行去掉
  end if ;*/
  V_DUMP_HX :=replace(V_DUMP_HX,',d,d,a,',',0d,0a,0d,0a,');--回车换行如果是2个解析出来会漏掉一个a，所以将这样的加一个a
  V_DUMP_HX :=replace(V_DUMP_HX,',d,a,a,',',0d,0a,0d,0a,');--回车换行如果是2个解析出来会漏掉一个d，所以将这样的加一个d

  V_DUMP_HX :=replace(V_DUMP_HX,',d,',',0d,');--将回车替换掉
  V_DUMP_HX :=replace(V_DUMP_HX,',a,',',0a,');--将换行替换掉
  V_DUMP_HX :=replace(V_DUMP_HX,',9,',',09,');--第一次有没替换完的
  V_DUMP_HX :=replace(V_DUMP_HX,',9,',',09,');--再替换一次

  V_ZTCD :=lengthb(V_DUMP_HX);
  if(substrb(V_DUMP_HX,-2)=',d')
  then
  V_DUMP_HX :=substrb(V_DUMP_HX,0,V_ZTCD-2)||',0d'; --将末尾的回车去掉
  end if ;
  if(substrb(V_DUMP_HX,-2)=',a')
  then
  V_DUMP_HX :=substrb(V_DUMP_HX,0,V_ZTCD-2)||',0a'; --将末尾的换行去掉
  end if ;

  if(substrb(V_DUMP_HX,-2)=',9')
  then
  V_DUMP_HX :=substrb(V_DUMP_HX,0,V_ZTCD-2)||',09'; --
  end if ;


  V_size  :=instr(V_DUMP_HX,':'); --冒号出现的位置
  V_SPLCONTRACT_HEX :=V_SPLCONTRACT_HEX||substrb(V_DUMP_HX,V_size+2);--截取冒号之后的十六进制码
  select f_tcdh(V_SPLCONTRACT_HEX) into V_SPLCONTRACT_HEX from dual;--该函数返回的是将2位填充为4位之后的值，以便于后面的截取

  V_SPLCONTRACT_HEX :=replace(V_SPLCONTRACT_HEX,',','');--将，替换掉
  V_LENGTH  :=lengthb(V_SPLCONTRACT_HEX);--填充之后将，去掉的长度

  if(mod(V_LENGTH,4)=0) then  --如果是4的余数那么可以将**去掉直接转换为中文
    V_SPLCONTRACT_HEX_TEMP :=V_SPLCONTRACT_HEX;
    V_SPLCONTRACT_HEX_TEMP :=replace(V_SPLCONTRACT_HEX_TEMP,'**','');
    V_SPLCONTRACT_TEMP          :=HexToAsc(V_SPLCONTRACT_HEX_TEMP);--转换成中文
    V_SPLCONTRACT_HEX      :='';
  else --不是4的余数将余下的放到下一次的前面，本次只处理前面那些被4整除的那些

    V_SPLCONTRACT_HEX_TEMP :=substrb(V_SPLCONTRACT_HEX,0,V_LENGTH-(mod(V_LENGTH,4)));
    V_SPLCONTRACT_HEX_TEMP :=replace(V_SPLCONTRACT_HEX_TEMP,'**',''); --将** 去掉
    V_SPLCONTRACT_TEMP          :=HexToAsc(V_SPLCONTRACT_HEX_TEMP);--转换成中文
    V_SPLCONTRACT_HEX      :=substrb(V_SPLCONTRACT_HEX,-(mod(V_LENGTH,4)))||','; --截取最后剩下的那些

  end if ;

  V_SPLCONTRACT     :=V_SPLCONTRACT||V_SPLCONTRACT_TEMP;

end loop;

--V_SPLCONTRACT  :=HexToAsc(V_SPLCONTRACT) ;--由16进制转换成汉字
/*if(lengthb(V_SPLCONTRACT)>3999)then
V_SPLCONTRACT :=substrb(V_SPLCONTRACT,1,3999);
end if;*/

return V_SPLCONTRACT;

exception
when others then
return null;

end F_GET_PRESPLCONTRACT;









/
