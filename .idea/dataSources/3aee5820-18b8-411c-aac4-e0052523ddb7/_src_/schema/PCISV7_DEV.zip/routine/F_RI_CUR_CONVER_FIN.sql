CREATE FUNCTION f_ri_cur_conver_fin (
  V_CLM_NO VARCHAR2,
  V_CLM_TMS NUMBER,
  V_ASSESS_TM  DATE,
  V_FEE_TYPE VARCHAR2,
  V_INSRNC_CDE VARCHAR2,
  v_type number) ---------1 未决表数据  2 赔案  3 险别赔案 4预付
RETURN NUMBER
AS
  V_ESTMT_AMT NUMBER(16,2);
BEGIN
  V_ESTMT_AMT := 0;
  CASE
  WHEN V_TYPE = '1' THEN
    SELECT
       round(nvl(sum(N_SUM_ESTMT_aMT_VaR_YUaN),0),2)
    INTO V_ESTMT_AMT
    from rpt_clm_forcpedrcd
       where c_clm_no = v_clm_no and n_clm_tms = v_clm_tms
       and t_assess_tm = v_assess_tm and c_fee_type = v_fee_type;
  WHEN V_TYPE = '2' THEN
    SELECT
       ROUND(NVL(sum(N_SUM_CLM_AMT_YUAN),0),2)
       INTO V_ESTMT_AMT
       from rpt_clm_forcrdr
       WHERE C_CLM_NO = V_CLM_NO AND N_CLM_TMS = V_CLM_TMS
       AND C_FEE_TYPE = V_FEE_TYPE;
  WHEN V_TYPE = '3' THEN
    SELECT
       ROUND(NVL(sum(N_SUM_CLM_AMT_YUAN),0),2)
       INTO V_ESTMT_AMT
       from rpt_clm_forcrdr
       WHERE C_CLM_NO = V_CLM_NO AND N_CLM_TMS = V_CLM_TMS
       AND C_FEE_TYPE = V_FEE_TYPE
       AND C_INSRNC_CDE = V_INSRNC_CDE;
  WHEN V_TYPE = '4' THEN
    SELECT
      ROUND(NVL(SUM(N_PRE_AMT_YUAN),0),2)
      INTO V_ESTMT_AMT
      FROM RPT_CLM_FORCRDR
      WHERE C_CLM_NO = V_CLM_NO AND N_CLM_TMS = V_CLM_TMS
      AND C_FEE_TYPE = V_FEE_TYPE;
  ELSE
    RETURN 0;
  END CASE;
  RETURN V_ESTMT_AMT;

 exception
 when others then
   return 1;
end;

/
