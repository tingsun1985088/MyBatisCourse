CREATE FUNCTION       "CHECKITEMSUBDEPT"                                (	item_cde       IN  VARCHAR2,  --????
        send_frequency    IN  VARCHAR2,  --????(1:??; 2:??; 3:??;  4:???; 5:??)
        date_type      IN  VARCHAR2,  --????(JD:???? ;XD????)
        date_value     IN  VARCHAR2,  --???  (?????????date_value????????????????????????)
        sub_dept_code  IN  VARCHAR2,  --????
	      value_type     IN  VARCHAR2)  --????(LJ:???FS???
	                                    --LJTB?????LJHB????,FSTB????,FSHB????,
	                                    --LJTBZZ???????LJHBZZ??????,FSTBZZ??????,FSHBZZ??????)

RETURN VARCHAR AS
  CURRENT_MONTH           VARCHAR2(7);
  DEPT_TABLE              VARCHAR2(50);
  SQLVALUE                VARCHAR2(500);
  C_VALUE_X               VARCHAR2(200);
  C_MARGIN_X              VARCHAR2(200);
BEGIN

--????????*****************************

SELECT date_value
 INTO CURRENT_MONTH
 FROM DUAL;

--??????????????
SELECT 't_original_data'
 INTO DEPT_TABLE
 FROM DUAL;


--??????*************************************
--????send_frequency?????????????

  SQLVALUE:=
  ' SELECT '
    || ' SUM(C_VALUE), '
    || ' SUM(C_MARGIN)  '
    || ' FROM '
    || '   '|| DEPT_TABLE || ' T '
    || ' WHERE '
    || '   C_ITEM_CDE  = '''|| item_cde || ''''
    || '   AND C_SUB_DEPT_CDE IN (SELECT C_SUB_DEPT_CDE FROM T_CHECK_SUBDEPT WHERE C_SUB_CHECKDEPT_CDE=  '''|| sub_dept_code || ''')'
    || '   AND EXISTS (SELECT C_SUB_DEPT_CDE FROM T_SUB_DEPT WHERE C_SUB_DEPT_CDE =T.C_SUB_DEPT_CDE AND C_STATE = ''1'')'
    || '   AND C_MONTH     = '''|| CURRENT_MONTH || ''''
    || '   AND C_FREQUENCY = '''|| send_frequency || '''';

EXECUTE IMMEDIATE
  SQLVALUE
  INTO
    C_VALUE_X,
    C_MARGIN_X  ;


--?????
IF trim(value_type) = 'LJ' THEN
  RETURN C_VALUE_X;
END IF;

--?????
IF trim(value_type) = 'FS' THEN
  RETURN C_MARGIN_X;
END IF;

--????????***********************************

EXCEPTION
	WHEN OTHERS THEN
			RETURN '0';

END;

/
