CREATE function       f_getiface_item(c_content varchar2, /*内容*/
                                           c_split   varchar2, /*分割串*/
                                           i_pos     integer, /*位置*/
                                           flag      integer     /*是否剔出"符号*/
                                           )
  return varchar2 /*返回字符串*/
 as
  v_content varchar2(2000);
  v_item    varchar2(200);
  i         integer;
  j         integer;--记录要找的位置暂存变量
begin
  v_content:=c_content;
  i:=0;
  j:=0;
  while true loop
     i:=instr(v_content,c_split);
     if i<=0 then
        v_item:=v_content;
        if flag=1 then
          v_item:=substr(v_item,2,instr(substr(v_item,3),'"'));
        end if;
        exit;
     end if;
     j:=j+1;
     ---如果是要找的位置，开始分解出字符串
     if j=i_pos then
        v_item:=substr(v_content,1,i-1);
        if flag=1 then
           v_item:=substr(v_item,2,instr(substr(v_item,3),'"'));
        end if;
 exit;
     end if;
  ---把后面的串付给变量
     v_content:=substr(v_content,i+1);
   end loop;
  return v_item;
exception
  when others then
    return null;
end;

/
