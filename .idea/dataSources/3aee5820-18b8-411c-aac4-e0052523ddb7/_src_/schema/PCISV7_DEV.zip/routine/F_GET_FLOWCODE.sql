CREATE FUNCTION F_GET_FLOWCODE(v_flowType VARCHAR2)
--v_flowType 为当前流程类型
 RETURN VARCHAR2 AS
  v_FlowCode VARCHAR2(30);
  --查找当前机构上级机构集合，并返回指定级别的机构
BEGIN
  --查找直接上级机构
  IF v_flowType = 'HANDIN' THEN
    SELECT 'SJ' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_handin.nextval, 4, '0')
      INTO v_FlowCode
      FROM dual;
  ELSE
    v_FlowCode := NULL;
  END IF;

  RETURN v_FlowCode;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
/
