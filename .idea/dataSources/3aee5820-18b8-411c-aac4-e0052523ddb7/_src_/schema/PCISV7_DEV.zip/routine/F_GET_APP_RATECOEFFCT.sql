CREATE FUNCTION F_GET_APP_RATECOEFFCT(insrncBgnTm in varchar2,InsrncEndTime in varchar2,
          appInsrncBgnTm in varchar2,appInsrncEndTime in varchar2)
  return number
  as
    NUMOFDAY number;
    endyear varchar2(50);
    begyear varchar2(50);
    begdays varchar2(50);
    enddays varchar2(50);
    begday varchar2(50);
    endday varchar2(50);
    conf number;
  begin
    endyear := substr(appInsrncEndTime,0,4);
    begyear := substr(appInsrncBgnTm,0,4);
 --    select substr(InsrncEndTime,0,4) into endyear from dual;
     select (to_date(InsrncEndTime,'yyyy-MM-dd hh24:mi:ss')+ 1/(24*60*60)) - to_date(insrncBgnTm,'yyyy-MM-dd hh24:mi:ss') into NUMOFDAY from dual;
     begday := substr(appInsrncBgnTm,0,10);
     endday := substr(appInsrncEndTime,0,10);
 --  select substr(InsrncEndTime,0,4) into endMonth from dual;
     select case  when (MOD(endyear, 4) = 0 and MOD(endyear, 100) != 0) or
                  (MOD(endyear, 400) = 0) then  '366'  else   '365'  end into enddays from dual;

     select case  when (MOD(begyear, 4) = 0 and MOD(begyear, 100) != 0) or
                  (MOD(begyear, 400) = 0) then  '366'  else   '365'  end into begdays from dual;
     if begdays = '366' then
      if to_Date(begday,'yyyy-MM-dd') <= to_date(begyear||'-02-29','yyyy-MM-dd') and
        to_date(endday,'yyyy-MM-dd') > to_date(begyear||'-02-29','yyyy-MM-dd') then
        conf := NUMOFDAY/366;
      else
         conf :=NUMOFDAY/365;
      end if;
     elsif enddays = '366'then
       if to_date(endday,'yyyy-MM-dd') > to_date(endyear||'-02-29','yyyy-MM-dd') and
          to_Date(begday,'yyyy-MM-dd') <=  to_date(endyear||'-02-29','yyyy-MM-dd') then
       conf := NUMOFDAY/366;
      else
       conf := NUMOFDAY/365;

      end if;
    else
       conf := NUMOFDAY/365;
    end if;
    if conf > 1 then
      conf := 1;
    end if;
    return round(conf,6);
  end;
/
