CREATE FUNCTION F_GET_SUB_DPT(C_APP_NO IN VARCHAR2)
    RETURN VARCHAR2 AS

    V_APP_NO  VARCHAR2(50); --投保单出单机构
    V_DPT_CDE VARCHAR2(30); --投保单出单机构
    V_SUB_DPT VARCHAR2(30); --返回投保单出单分公司

  BEGIN
    V_APP_NO := C_APP_NO;

    --获取到投保单的出单机构
    SELECT T.C_DPT_CDE
      INTO V_DPT_CDE
      FROM WEB_APP_BASE T
     WHERE T.C_APP_NO = V_APP_NO;

    --获取到投保单出单分公司
    SELECT DECODE(X.C_DPT_REL_CDE,
                  '10',
                  '10', --如果当前是总公司 如:00 返回该总公司
                  SUBSTR(X.C_DPT_REL_CDE,
                         4,
                         DECODE(INSTR(X.C_DPT_REL_CDE, ';', 1, 2),
                                0,
                                LENGTH(X.C_DPT_REL_CDE) - 4 + 1,
                                INSTR(X.C_DPT_REL_CDE, ';', 1, 2) - 4))) C_DPT_CDE
      INTO V_SUB_DPT
      FROM WEB_ORG_DPT X
     WHERE X.C_DPT_CDE = V_DPT_CDE;

     RETURN V_SUB_DPT;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END F_GET_SUB_DPT;
/
