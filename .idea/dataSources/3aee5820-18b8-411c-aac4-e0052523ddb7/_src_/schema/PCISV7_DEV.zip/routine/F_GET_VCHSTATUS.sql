CREATE FUNCTION F_GET_VCHSTATUS(C_STATUS VARCHAR2)
  RETURN VARCHAR2 AS
  v_vchCnm VARCHAR2(100);
BEGIN

    SELECT dct.c_cnm
    INTO v_vchCnm
    FROM web_sys_sta_dict dct
    WHERE dct.c_par_cde = 'vch_sts'
    AND dct.c_cde = C_STATUS;

  RETURN v_vchCnm;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;

END;
/
