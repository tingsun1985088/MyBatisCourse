CREATE FUNCTION "F_FIN_GETCODE" (icFinTyp IN VARCHAR2)
RETURN VARCHAR2
AS
    v_Date            VARCHAR2(8);
    v_DptCde        VARCHAR2(11);
    v_SerieNo        VARCHAR2(12);
    n_SerieNo        NUMBER;
    v_FinTyp        VARCHAR2(2);
    V_COUNT            NUMBER;
    v_FinCde        VARCHAR2(21);
BEGIN
     v_Date := TO_CHAR(SYSDATE,'YYYYMMDD');
     v_DptCde := '0';
     v_FinTyp := LTRIM(RTRIM(icFinTyp));

     SELECT COUNT(*) INTO V_COUNT
     FROM WEB_BAS_FIN_SERIENO
     WHERE C_DPT_CDE = v_DptCde AND C_VCH_TYP=v_FinTyp AND C_TIME=v_Date;

     IF V_COUNT>0 THEN
          UPDATE WEB_BAS_FIN_SERIENO SET C_SERIE_NO=C_SERIE_NO+1
         WHERE C_DPT_CDE = v_DptCde AND C_VCH_TYP=v_FinTyp AND C_TIME=v_Date;
     ELSE
          INSERT INTO WEB_BAS_FIN_SERIENO(t_crt_tm,t_upd_tm,c_dpt_cde,c_vch_typ,C_TIME,C_SERIE_NO)
         VALUES(SYSDATE,SYSDATE,v_DptCde,v_FinTyp,v_Date,1);
     END IF;

     SELECT C_SERIE_NO INTO n_SerieNo
     FROM WEB_BAS_FIN_SERIENO
     WHERE C_DPT_CDE = v_DptCde AND C_VCH_TYP=v_FinTyp AND C_TIME=v_Date;

     v_SerieNo := trim(TO_CHAR(n_SerieNo,'00000000000'));
     v_FinCde := v_FinTyp || v_Date || v_SerieNo;
     RETURN v_FinCde;
EXCEPTION
    WHEN  OTHERS THEN
    dbms_output.put_line(SQLCODE);
      RETURN 0;
END;

/
