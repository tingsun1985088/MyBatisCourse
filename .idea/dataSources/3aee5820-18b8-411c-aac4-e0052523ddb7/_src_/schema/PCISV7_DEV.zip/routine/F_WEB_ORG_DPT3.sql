CREATE function            F_WEB_ORG_DPT3(v_dpt3 varchar2)
  return varchar2 as
  v_dpt  varchar2(30);
                     ----返回三级机构
begin
v_dpt:='';

select x.c_dpt_cde into  v_dpt from web_org_dpt x
where x.c_dpt_cde=v_dpt3;
      /*如果机构级别不为空*/
      select y.c_snr_dpt into v_dpt from web_org_dpt y where y.n_dpt_levl= 3 and y.c_dpt_cde=v_dpt3;
  return v_dpt;
exception
  when others then
    return '0';
end;
/
