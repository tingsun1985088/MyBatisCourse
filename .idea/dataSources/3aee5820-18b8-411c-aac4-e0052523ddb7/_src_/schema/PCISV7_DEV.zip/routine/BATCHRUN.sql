CREATE function       BATCHRUN(
 instr in STRING_ARRAY
) return STRING_ARRAY is

  outstr  STRING_ARRAY;
  valuex   varchar2(1000);
  formulax varchar2(10000);
  outstrList STRING_ARRAY :=STRING_ARRAY(1);

begin


outstrList.extend(instr.last-1);
for i in 1..instr.last loop
    /*????*/
    formulax := instr(i);
    /*????*/
    begin
        EXECUTE IMMEDIATE formulax into valuex;
        IF valuex is null then
          valuex :='0';
        end if;
    exception
    WHEN OTHERS THEN
        valuex :='????????????????????????';
    END;
    /*???*/
    outstrList(i) := valuex;
end loop;
return outstrList;

end BATCHRUN;

/
