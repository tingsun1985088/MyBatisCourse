CREATE function wangjun5(c_rpt_no   in varchar2,
                                    v_c_snr_no in varchar2,
                                    v_sql_msg  out varchar2)
  return varchar2 is
  v_task_start_date date;
  v_task_end_date   date;
  v_sql_code        number;
  v_sql             varchar2(4000);
  flag              varchar2(2); --本级状态
  flag1             varchar2(2); -- 子集状态
  returnflag        varchar2(2);
  msg               varchar2(2000);
  -- 查询公共规则
  -- declare
  cursor rules is
  
    select t.c_sql, t.c_param, t.c_rule, t.c_rule_no, t.c_block_mrk
      from web_vhlclm_auto_approve_rule t
     where t.c_statue = '1'
       and t.c_snr_no = v_c_snr_no
     order by t.n_order;

begin

  returnflag := '1';
  flag1      := '1';
  flag       := '1';

  declare
    numrow number;
  
  begin
    numrow := 1;
    for rule in rules loop
      numrow    := numrow + 1;
      begin
      
        declare
          xx varchar2(2);
        
          xx1 varchar2(2);
        
        begin
          xx := '1';
        
          if rule.c_sql is not null then
          
            v_sql      := f_change_sql(rule.c_sql,
                                       '',
                                       rule.c_param,
                                       c_rpt_no);
                                    
            xx         := f_check_right(v_sql, rule.c_rule);
            returnflag := xx;
           
          end if;
        
          if xx = '1' then
            xx1        := wangjun5(c_rpt_no, rule.c_rule_no, msg);
            returnflag := xx1;
          end if;
            v_sql_msg :=  v_sql_msg || rule.c_rule_no || v_sql   || '******' || msg;
        
          --并且关系 只要 有不满足  停止循环
          if (xx = '0' or xx1 = '0') and rule.c_block_mrk = '2' then
            returnflag := '0';
            return returnflag;
          end if;
        
          --或者关系 只要有 满足  停止循环 
          if (xx = '1' or xx1 = '1') and rule.c_block_mrk = '1' then
            returnflag := '1';
            return returnflag;
          end if;
        
          --或者 关系  全部满足  返回 不不满足
        
        end;
      
      end;
    
    end loop;
  
  end;
  return returnflag;

exception

  when others then
    return '0';
    v_sql_code := sqlcode;
    v_sql_msg  := v_sql_msg || ' ' || ' : ' || sqlerrm;
    --任务结束时间
    --select sysdate into v_task_end_date from dual;
    rollback;
    insert into load_his_log
      (sys, jobname, start_date, end_date, run_date, sql_code, sql_state)
    values
      ('pcisv7',
       'wangjun1',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    commit;
  
end;
/
