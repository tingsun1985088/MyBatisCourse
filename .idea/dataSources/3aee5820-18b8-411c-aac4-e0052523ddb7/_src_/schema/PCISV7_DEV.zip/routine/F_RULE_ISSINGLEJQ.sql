CREATE function F_rule_isSingleJQ(v_app_no varchar2)
  return number
as
  v_count number :=0 ;
begin
  SELECT count(*) into  v_count
    FROM WEB_APP_BASE t
   WHERE t.C_APP_NO = v_app_no
     AND t.c_prod_no in ('030001','030003','030005')
     and t.c_app_typ = 'A'
     --and nvl(t.c_sys_res,'0') ='0'
     and (select count(1)
            from web_ply_relation
           where n_id in (select n_id
                           from web_ply_relation k
                          where c_ply_app_no = v_app_no )) = 1
  ;
  if v_count >= 1 then
     v_count:= 1;
  else
     v_count:= 0;
  end if;

  return v_count;
exception
  when others then
    return 0;
end;
/
