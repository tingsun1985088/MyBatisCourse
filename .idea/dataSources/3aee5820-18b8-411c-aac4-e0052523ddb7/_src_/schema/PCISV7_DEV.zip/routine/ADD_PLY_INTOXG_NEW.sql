CREATE procedure ADD_PLY_INTOXG_NEW IS
      v_task_start_date  date;
      v_task_end_date    date;
      v_sql_code        number;
      v_sql_msg         varchar2(4000) := ''; ---SQL错误信息
      begintime         DATE;  --  同步开始时间
      endtime           DATE;  --  同步结束时间

BEGIN

    SELECT to_date(to_char(operate_enddate,'yyyy/mm/dd hh24')||':00:00','yyyy/mm/dd hh24:mi:ss') INTO begintime FROM T_SYNC_ADXG_LOG;
    SELECT to_date(to_char(operate_enddate,'yyyy/mm/dd hh24')||':00:00','yyyy/mm/dd hh24:mi:ss')+1/24 INTO endtime FROM T_SYNC_ADXG_LOG;
    UPDATE T_SYNC_ADXG_LOG SET operate_enddate =endtime;


    select sysdate into v_task_start_date from dual;
    select sysdate into v_task_end_date from dual;


    -------------  调用存储过程 P E
    ADD_PLY_INTOXG_P_NOT03_NEW(begintime,endtime);
    ADD_PLY_INTOXG_P_03_NEW(begintime,endtime);
    ADD_PLY_INTOXG_E_NOT03_NEW(begintime,endtime);
    ADD_PLY_INTOXG_E_03_NEW(begintime,endtime);
    ADD_PLY_INTOXG_GB_NEW(begintime,endtime);


    add_sales_end_intoxg;

    SELECT SYSDATE INTO v_task_end_date FROM dual;

    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_NEW',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    COMMIT;





EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_NEW',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
       commit;
end ADD_PLY_INTOXG_NEW;
/
