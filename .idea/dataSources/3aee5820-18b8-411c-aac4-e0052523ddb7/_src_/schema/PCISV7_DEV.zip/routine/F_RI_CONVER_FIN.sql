CREATE FUNCTION f_ri_conver_fin(m_param varchar2,
                                           m_flag  varchar2) 
 RETURN VARCHAR2 AS
  v_result varchar2(100);
BEGIN

  if (m_flag = 'feecur') then
  
    select decode(m_param,
                  '01',
                  'CNY',
                  '02',
                  'HKD',
                  '03',
                  'USD',
                  '05',
                  'JPY',
                  '12',
                  'EUR',
                  '47',
                  'SGD',
                  '04',
                  'GBP',
                  '07',
                  'CHF',
                  '42',
                  'KWD',
                  'CNY')
      into v_result
      from dual;
      
  elsif (m_flag = 'feetyp') then
    
    select case
             when m_param in ('ID1','E1','X1','X2','C1') then
              '01'
             when m_param in ('I1','IC2','RITFBPK','E2','D2','CPYF','ICC') then
              '02'
             when m_param in ('IC1','IC7','D1','D4','D7','RC','IC8','IC4','OE') then
              '08'
             when m_param in ('I1','PR') then
              '09'
             else
              m_param
           end
      into v_result
      from dual;
      
  else
    v_result := '1';
  end if;

  return v_result;

exception
  when others then
    return 1;
end;
/
