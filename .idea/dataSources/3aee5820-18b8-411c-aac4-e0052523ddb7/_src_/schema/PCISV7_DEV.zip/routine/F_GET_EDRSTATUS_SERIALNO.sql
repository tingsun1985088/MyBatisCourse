CREATE FUNCTION "F_GET_EDRSTATUS_SERIALNO" (VEDRNO in varchar2)
return  number
as
v_serialno number;
begin
select max(a.serialno) into v_serialno from t_edrstatus a
 where a.edrno=VEDRNO and a.poststatus='5';

  return(v_serialno);
  exception
when others then
return NULL;
end f_get_edrstatus_serialno;









/
