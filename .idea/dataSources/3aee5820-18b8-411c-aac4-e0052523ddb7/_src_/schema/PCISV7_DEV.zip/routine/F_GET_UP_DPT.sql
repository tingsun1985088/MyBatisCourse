CREATE FUNCTION F_GET_UP_DPT(v_dpt VARCHAR2, v_lvl NUMBER)
  --v_dpt 为当前机构代码
  --v_lvl 待查找机构的级别，-1 表示查找直接上级；指定级别机构时取0、1、2、3、4、5
  RETURN VARCHAR2 AS
  v_up_dpt VARCHAR2(30);
  --查找当前机构上级机构集合，并返回指定级别的机构
BEGIN
  --查找直接上级机构
  IF v_lvl = -1 THEN
    SELECT dpt.c_snr_dpt
      INTO v_up_dpt
      FROM web_org_dpt dpt
     WHERE dpt.c_dpt_cde = v_dpt;
    --查找指定级别的机构
  ELSIF v_lvl IN (0, 1, 2, 3, 4, 5) THEN
    SELECT dpt.c_dpt_cde
      INTO v_up_dpt
      FROM web_org_dpt dpt
     WHERE dpt.n_dpt_levl = v_lvl
     START WITH dpt.c_dpt_cde = v_dpt
    CONNECT BY PRIOR dpt.c_snr_dpt = dpt.c_dpt_cde
           AND dpt.n_dpt_levl >= v_lvl;
  END IF;

  RETURN v_up_dpt;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;

END;

/
