CREATE FUNCTION "F_GET_OPGRP" 
(V_EMP_CDE in varchar2, --员工代码
V_EMP_CNM in varchar2, --员工姓名
V_OWNDPT_CDE in varchar2, --员工所属机构
V_DPT_CDE in varchar2, --员工权限机构
V_OPGRP_CDE in varchar2, --员工角色代码
V_TYPE in varchar2 --要加的类型 1 加员工和权限 2 单加员工 3 单加权限  

)
RETURN VARCHAR2
AS
--传员工代码，操作机构和角色

v_task_start_date          date                    ;
v_task_end_date            date                    ;
v_sql_code                 number       :=0        ;
v_sql_msg                  VARCHAR2(4000) := ''    ; --sql错误信息
v_iNum                     NUMBER                  ;


BEGIN

  --任务开始时间和任务结束时间
  SELECT SYSDATE INTO v_task_start_date FROM dual;
  SELECT SYSDATE INTO v_task_end_date FROM dual;

if (V_TYPE in ('1','2')) then --加员工

delete from web_org_emp where C_EMP_CDE =V_EMP_CDE;
insert into web_org_emp 
      (
         C_EMP_CDE
        ,C_EMP_CNM
        ,C_DPT_CDE  --所属机构
        ,C_CRT_CDE
        ,T_CRT_TM
        ,C_UPD_CDE
        ,T_UPD_TM
        ,C_IS_VALID
        ,C_TRANS_MRK        /*迁入标记*/
        ,T_TRANS_TM         /*迁入时间*/
        
        ) 
values (
        V_EMP_CDE
       ,V_EMP_CNM
       ,V_OWNDPT_CDE
       ,'USER'
       ,sysdate
       ,'USER'
       ,sysdate
       ,'1'  --有效
       ,'1'
       ,sysdate  
       );
delete from web_org_sales where C_SLS_CDE =V_EMP_CDE;
insert into web_org_sales
   (  C_PK_ID
     ,C_DPT_CDE
     ,C_SLS_CDE
     ,C_SLS_NME
     ,C_SLS_TYP
     ,T_BGN_TM
     ,T_END_TM
     ,C_CRT_CDE
     ,T_CRT_TM
     ,C_UPD_CDE
     ,T_UPD_TM
     ,C_CTFCT_TYP
     ,C_CTFCT_NO
    )                                                                                         
values  
   (
     v_emp_cde
    ,nvl(V_OWNDPT_CDE,' ')
    ,V_emp_cde
    ,V_emp_cnm
    ,'020002'
    ,sysdate-50
    ,sysdate+10000
    ,'USER'
    ,sysdate
    ,'USER'
    ,sysdate
    ,'-'
    ,'-'                                                                                                                             

    ) ;
delete from web_org_oper where C_OPER_ID =V_EMP_CDE;
insert into  web_org_oper
  (
    C_OPER_ID
   ,C_OPER_CNM
   ,C_PASSWD
   ,C_IS_VALID
   ,T_PWD_STRT_TM
   ,T_PWD_END_TM
   ,C_SRC
   ,C_REL_CDE
   ,C_DPT_PERM
   ,C_DPT_DIFF
   ,C_PRD_DIFF
   ,C_OP_DIFF
   ,C_CRT_CDE
   ,T_CRT_TM
   ,C_UPD_CDE
   ,T_UPD_TM
   ,C_OWN_DPT_CDE
   ,c_id_no 
   )  
values
(
    V_emp_cde
   ,v_emp_cnm
   ,'1145'
   ,'1'
   ,sysdate-50
   ,sysdate+365*2
   ,'0'
   ,v_emp_cde 
   ,'0'
   ,'0'
   ,'0'
   ,'0'
   ,'USER'
   ,sysdate
   ,'USER'
   ,sysdate
   ,V_DPT_CDE
   ,V_emp_cde
 );

elsif (V_TYPE in ('1','3')) then


--将WEB_ORG_OPER where c_is_valid = '1'状态为1的插入到VHL_PORTAL用户的PORTAL_GROUP_USER中
    v_iNum := 0;
      select count(*) into v_iNum from  PORTAL_TEST.PORTAL_GROUP_USER a
       where c_memeber_id = V_EMP_CDE
      ;
      if (v_iNum = 0 ) then
        insert into  PORTAL.PORTAL_GROUP_USER values ('2',  V_EMP_CDE, '1');
      end if;
v_sql_msg :=V_EMP_CDE||V_DPT_CDE|| '删除WEB_GRT_USR_OP_DPT';

delete from WEB_GRT_USR_OP_DPT a where a.C_OPER_ID=V_EMP_CDE and a.C_DPT_CDE=V_DPT_CDE;

 v_sql_msg :=V_EMP_CDE|| '增量抽取数据到目的表WEB_GRT_USR_OP_DPT';
  insert  into   WEB_GRT_USR_OP_DPT (
          C_PK_ID
          ,C_OPER_ID
          ,C_DPT_CDE
          ,T_CRT_TM
          ,C_CRT_CDE
          ,C_TRANS_MRK        /*迁入标记*/
          ,T_TRANS_TM         /*迁入时间*/

     )
values (
      V_EMP_CDE||'_'||V_DPT_CDE
      ,V_EMP_CDE
      ,V_DPT_CDE
      ,sysdate
      ,'USER'
      ,'1'        /*迁入标记*/
      ,sysdate         /*迁入时间*/

)
;

   v_sql_msg := V_EMP_CDE||V_DPT_CDE||'删除WEB_GRT_USR_PROD';
delete from WEB_GRT_USR_PROD a where a.C_OPER_ID=V_EMP_CDE and a.C_DPT_CDE=V_DPT_CDE and a.C_PROD_NO='03';

   v_sql_msg := V_EMP_CDE||'增量抽取数据到目的表WEB_GRT_USR_PROD';
  insert  into   WEB_GRT_USR_PROD (
          C_PK_ID
         ,C_OPER_ID
         ,C_DPT_CDE
         ,C_PROD_NO
         ,C_NME_CN
         ,C_PROD_CAT
         ,C_CRT_CDE
         ,T_CRT_TM
         ,C_TRANS_MRK        /*迁入标记*/
         ,T_TRANS_TM         /*迁入时间*/

     )
values (
        V_EMP_CDE||'_'||V_DPT_CDE||'_'||'03'
        ,V_EMP_CDE
        ,V_DPT_CDE
        ,'03'
        ,'机动车辆险(大类)'
        ,'1'
        ,'USER'
        ,sysdate
        ,'1'        /*迁入标记*/
        ,sysdate         /*迁入时间*/
        );
    v_sql_msg := V_EMP_CDE||V_DPT_CDE||V_OPGRP_CDE||'删除WEB_GRT_USR_ROLE';
delete from WEB_GRT_USR_ROLE a where a.C_OPER_ID=V_EMP_CDE and a.C_DPT_CDE=V_DPT_CDE and a.C_OPGRP_CDE=V_OPGRP_CDE;

   v_sql_msg := V_EMP_CDE||V_DPT_CDE||V_OPGRP_CDE||'增量抽取数据到目的表WEB_GRT_USR_ROLE';

insert  into   WEB_GRT_USR_ROLE (
           C_PK_ID
           ,C_OPER_ID
           ,C_DPT_CDE
           ,C_OPGRP_CDE
           ,C_CRT_CDE
           ,T_CRT_TM
           ,C_TRANS_MRK        /*迁入标记*/
           ,T_TRANS_TM         /*迁入时间*/

     )
values (
         V_EMP_CDE||'_'||V_DPT_CDE||'_'||V_OPGRP_CDE
        ,V_EMP_CDE
        ,V_DPT_CDE
        ,V_OPGRP_CDE
        ,'USER'
        ,sysdate
        ,'1'        /*迁入标记*/
        ,sysdate         /*迁入时间*/

)
;

--自动发布

delete from web_grt_menu a where a.c_oper_id=V_EMP_CDE;
INSERT INTO web_grt_menu
            (c_oper_id, c_dpt_cde, c_op_cde, c_parent_cde, c_op_cnm, c_op_act,
             n_op_order, c_op_img, c_target)
   SELECT opdiff.c_oper_id, opdiff.c_dpt_cde, op.c_op_cde, op.c_parent_cde,
          op.c_op_cnm, dict.c_map_cde || op.c_op_act, op.n_op_order,
          op.c_op_img, op.c_target
     FROM web_grt_usr_op opdiff,
          web_grt_op op,
          web_sys_sta_dict dict,
          web_grt_usr_op_dpt usropdpt
    WHERE opdiff.c_op_cde = op.c_op_cde
      AND op.c_sub_sys_cde = dict.c_cde
      AND dict.c_par_cde = 'grt_sub_sys'
      AND opdiff.c_enabled = '1'
      AND op.c_op_type = '0'
      AND usropdpt.c_oper_id = opdiff.c_oper_id
      AND usropdpt.c_dpt_cde = opdiff.c_dpt_cde
      and opdiff.c_oper_id=V_EMP_CDE
   UNION
   (SELECT usrrole.c_oper_id, usrrole.c_dpt_cde, op.c_op_cde, op.c_parent_cde,
           op.c_op_cnm, dict.c_map_cde || op.c_op_act, op.n_op_order,
           op.c_op_img, op.c_target
      FROM web_grt_op op,
           web_grt_role_op rop,
           web_grt_role ROLE,
           web_grt_usr_role usrrole,
           web_sys_sta_dict dict,
           web_grt_usr_op_dpt usropdpt
     WHERE op.c_op_cde = rop.c_op_cde
       AND ROLE.c_opgrp_cde = usrrole.c_opgrp_cde
       AND op.c_sub_sys_cde = dict.c_cde
       AND dict.c_par_cde = 'grt_sub_sys'
       AND rop.c_opgrp_cde = ROLE.c_opgrp_cde
       AND op.c_op_type = '0'
       AND usropdpt.c_oper_id = usrrole.c_oper_id
       AND usropdpt.c_dpt_cde = usrrole.c_dpt_cde
       and usrrole.c_oper_id=V_EMP_CDE
    MINUS
    SELECT opdiff.c_oper_id, opdiff.c_dpt_cde, op.c_op_cde, op.c_parent_cde,
           op.c_op_cnm, dict.c_map_cde || op.c_op_act, op.n_op_order,
           op.c_op_img, op.c_target
      FROM web_grt_usr_op opdiff,
           web_grt_op op,
           web_sys_sta_dict dict,
           web_grt_usr_op_dpt usropdpt
     WHERE opdiff.c_op_cde = op.c_op_cde
       AND op.c_sub_sys_cde = dict.c_cde
       AND dict.c_par_cde = 'grt_sub_sys'
       AND opdiff.c_enabled = '0'
       AND op.c_op_type = '0'
       AND usropdpt.c_oper_id = opdiff.c_oper_id
       AND usropdpt.c_dpt_cde = opdiff.c_dpt_cde
       and opdiff.c_oper_id=V_EMP_CDE
       )
       ;

commit;

end if ;
  v_sql_code    :=0;
  v_sql_msg     := 'NORMAL, SUCCESSFUL COMPLETION';

--写任务日志
SELECT SYSDATE INTO v_task_end_date FROM dual;

return 'OK';

EXCEPTION
  WHEN  OTHERS THEN
  v_sql_msg :=v_sql_msg||SQLERRM;
    RETURN 'FAILED';
END ;










/
