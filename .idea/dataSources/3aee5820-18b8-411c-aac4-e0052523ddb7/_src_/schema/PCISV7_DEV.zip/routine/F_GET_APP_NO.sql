CREATE FUNCTION "F_GET_APP_NO" (CPlyEdrNo in varchar2)/*输入保单号或批单号*/
return varchar2  --返回保单或批单的申请单号
as
 v_PLYEDR_NO           varchar2(30);
 v_APP_PLYEDR_NO       varchar2(30);
 V_NUM               number      ;

BEGIN
	 v_PLYEDR_NO    :=CPlyEdrNo ;
	 v_NUM          :=0;
  select COUNT(1) into v_NUM from T_EDR_BASE
	where C_EDR_NO=v_PLYEDR_NO;
if(v_NUM>0) then
	select C_EDR_APP_NO into v_APP_PLYEDR_NO from T_EDR_BASE
	where C_EDR_NO=v_PLYEDR_NO;

else
	 v_NUM  :=0;
  select COUNT(1) into v_NUM from T_PLY_BASE
	where C_PLY_NO=v_PLYEDR_NO;
  if(v_NUM>0) then
	select C_PLY_APP_NO into v_APP_PLYEDR_NO from T_PLY_BASE
	where C_PLY_NO=v_PLYEDR_NO;
      else
	      v_APP_PLYEDR_NO := NULL;
  end if ;
 end if ;
return 	v_APP_PLYEDR_NO;

exception
when others then
return null;

END F_GET_APP_NO;








/
