CREATE FUNCTION F_GET_FLOWNO(v_flowTyp VARCHAR2)
  --v_flowTyp 为当前流程类型
 RETURN VARCHAR2 AS
  v_FlowNo VARCHAR2(30);
BEGIN
  --移动营销上交
  IF v_flowTyp = 'HANDIN' THEN
    SELECT 'SJ' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_handin.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --归档
  ELSIF v_flowTyp = 'PGHNO' THEN
    SELECT 'GD' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_pghno.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --移动营销寄送回销
  ELSIF v_flowTyp = 'SENDVERIFY' THEN
    SELECT 'JB' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_sendverify.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --下发（包括下发出库和领用配发）
  ELSIF v_flowTyp = 'OUTPRNNO' THEN
    SELECT 'CK' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_outprnno.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --激活卡激活校验接口/缴费状态回写接口/激活卡发送收付 JK VCHINTER
  ELSIF v_flowTyp = 'VCHINTER' THEN
    SELECT 'JK' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchinter.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --影像上传 YX IMAGEOPERATE
  ELSIF v_flowTyp = 'IMAGEOPERATE' THEN
    SELECT 'YX' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_imageoperate.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --单证调拨 DB VCHALLOT
  ELSIF v_flowTyp = 'VCHALLOT' THEN
    SELECT 'DB' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchallot.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --遗失 YS VCHLOSE
  ELSIF v_flowTyp = 'VCHLOSE' THEN
    SELECT 'YS' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchlose.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --销毁 XH VCHDESTROY
  ELSIF v_flowTyp = 'VCHDESTROY' THEN
    SELECT 'XH' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchdestroy.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --缴销 JX VCHHANCANCEL
  ELSIF v_flowTyp = 'VCHHANCANCEL' THEN
    SELECT 'JX' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchhancancel.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --单证申领 SL VCHAPPLY
  ELSIF v_flowTyp = 'VCHAPPLY' THEN
    SELECT 'SL' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchapply.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --作废销号 ZF VCHCANCEL
  ELSIF v_flowTyp = 'VCHCANCEL' THEN
    SELECT 'ZF' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchcancel.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --回收(卡单退卡/上缴) HS VCHBACK
  ELSIF v_flowTyp = 'VCHBACK' THEN
    SELECT 'HS' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchback.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --手动卡单注销 ZX VCHLOGOFF
  ELSIF v_flowTyp = 'VCHLOGOFF' THEN
    SELECT 'ZX' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchlogoff.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --交接 JJ VCHASSOC
  ELSIF v_flowTyp = 'VCHASSOC' THEN
    SELECT 'JJ' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchassoc.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --解锁 JS VCHDEBLOCK
  ELSIF v_flowTyp = 'VCHDEBLOCK' THEN
    SELECT 'JS' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchdeblock.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --预订单 YD VCHPREORDER
  ELSIF v_flowTyp = 'VCHPREORDER' THEN
    SELECT 'YD' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_vchpreorder.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --报表异步定制申请 BS ASYNREPORTAPPLY
  ELSIF v_flowTyp = 'ASYNREPORTAPPLY' THEN
    SELECT 'BS' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_asynreportapply.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  --特殊任务申请 TS SPECIALAPPLY
  ELSIF v_flowTyp = 'SPECIALAPPLY' THEN
    SELECT 'TS' || to_char(SYSDATE, 'yyyymmdd') ||
           lpad(seq_flow_specialapply.nextval, 4, '0')
      INTO v_FlowNo
      FROM dual;
  ELSE
    v_FlowNo := 'aaa';
  END IF;

  RETURN v_FlowNo;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'ccc';
END;

/
