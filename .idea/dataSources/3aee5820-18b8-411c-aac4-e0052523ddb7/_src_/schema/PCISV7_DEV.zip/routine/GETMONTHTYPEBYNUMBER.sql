CREATE function       GETMONTHTYPEBYNUMBER(CURRENTMONTH IN VARCHAR2) return varchar2 is
  Result varchar2(2);
  MONTHX VARCHAR2(2);
begin

  MONTHX := SUBSTR(CURRENTMONTH,6,2);

  IF MONTHX = '01'
     OR MONTHX = '02'
     OR MONTHX = '04'
     OR MONTHX = '05'
     OR MONTHX = '07'
     OR MONTHX = '08'
     OR MONTHX = '10'
     OR MONTHX = '11' THEN
     Result := '2';
  END IF;

  IF MONTHX = '03'
     OR MONTHX = '09' THEN
     Result := '3';
  END IF;

  IF MONTHX = '06' THEN
     Result := '4';
  END IF;

  IF MONTHX = '12' THEN
     Result := '5';
  END IF;

  return(Result);

EXCEPTION
	WHEN OTHERS THEN
			RETURN '';

end GETMONTHTYPEBYNUMBER;

/
