CREATE FUNCTION "GET_INSRNCDE_PRM33" (ply_no     IN VARCHAR2,
                                              vstrd      DATE,
                                              vendd      DATE,
                                              cinsrnccde VARCHAR2)
  RETURN NUMBER AS
  rcpt NUMBER(20, 2) := 0;
BEGIN

  SELECT /*+ index(a,idx_ply_rdr_plyno) */
   SUM(a.n_prm)
    INTO rcpt
    FROM web_ply_cvrg a, web_ply_base b
   WHERE a.c_app_no = b.c_app_no
     AND b.c_app_typ = 'A'
     AND a.c_ply_no = ply_no
     AND to_number(a.c_cvrg_no) = cinsrnccde;

  RETURN rcpt;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;








/
