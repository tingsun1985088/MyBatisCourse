CREATE FUNCTION F_RI_GETEDRCVRG_VAT(M_POLICYNO     VARCHAR2, -- 保单号
                                               M_ENDORSENO    VARCHAR2, --批单号
                                               M_REINID       VARCHAR2, --内账表ID
                                               M_SUBCOMPANY   VARCHAR2, -- 分公司
                                               M_CURRENCYCODE VARCHAR2, -- 币种代码
                                               M_AMOUNT       NUMBER, -- 金额，价税合计
                                               M_TAX_MRK      VARCHAR2, -- 险别属性(应税，免税)
                                               M_VAT_TAX_RATE NUMBER, -- 增值税率
                                               M_VAT_TAX      NUMBER) -- 增值税
  /*
  
     批单获取险别函数
  
  */

 RETURN NUMBER AS
  V_RESULT      NUMBER; --返回结果
  SURPLUSAMOUNT NUMBER := M_AMOUNT; --剩余金额
  I             NUMBER := 0; --执行次数
  NSUMAMT       NUMBER := 0; --总金额(险别总保费)
  AMTPRPT       NUMBER := 1; --保费占比
  CVRGAMT       NUMBER := 0; --险别金额（到再保）
  SUMROW        NUMBER := 0; --总行数
  V_SQL_CODE    NUMBER := 0;
  V_SQL_MSG     VARCHAR2(4000) := ''; --sql错误信息
  SURPLUSTAX    NUMBER := M_VAT_TAX; --剩余增值税

  CURSOR CS_CVRG IS
    SELECT SYS_GUID() AS ID, --  物理主键
           M_REINID AS SEQCHARGEDETAIL, --  业务系统传过来的接口明细表policylist.custseq
           M_REINID AS SEQCHARGE, --  关联字段，等于mm_policy_ti.id
           M_SUBCOMPANY AS SUBCOMPANY, --  分公司
           A.POLICYNO AS POLICYNO, --保单号
           M_ENDORSENO AS ENDORSENO, --批单号
           M_CURRENCYCODE AS CURRENCYCODE, --挂账币种
           A.CLASSESCODE AS CLASSESCODE, -- 险别
           SUM(A.AMOUNT) AS AMOUNT, --  金额
           '0' AS OPSTATUS, --核销状态 初始化为0
           'ISoftStone_RI' AS SOURCE, --
           SYSDATE AS TIMESTAMP, --时间戳
           SYSDATE AS LASTOPDATE, --最后操作时间
           '1' AS HIBERNATEVERSION, --版本号
           '' AS LANDID, --  落地进入td表后的id
           '' AS TAXESAMOUNT, --  进项税额
           '' AS TAXESRATE, --  税率
           '' AS CLASSESSTYPE, --  险别属性：0应税 1 免税 2 零税
           '' AS TAXESAMOUNTOUT, --  进项税额转出
           '' AS TAXSTR, --  税额结构  进项税必传:01-货物及加工、修理修配劳务的进项,02-运输服务的进项,03-电信服务的进项,04-建筑安装服务的进项,05-金融保险服务的进项,06-有形动产租赁的进项,07-有形动产租赁服务的进项,08-不动产租赁服务的进项,09-取得无形资产的进项,10-受让土地使用权的进项,11-生活服务的进项,12-用于购建不动产并一次性抵扣的进项,13-通行费的进项,14-其他的进项
           '' AS RETURNITEM, --  转出项目:01：免税项目用,02：集体福利、个人消费,03：非正常损失,04：简易计税方法征税项目用,05：免抵退税办法不得抵扣的进项税,06：额纳税检查调减进项税额,07：红字专用发票信息表注明的进项税额,08：上期留抵税额抵减欠税,09：上期留抵税额退税,99：其他应作进项税额转出的情形
           '' AS INVOICECODE, -- 发票代码
           '' AS INVOICENO, -- 发票号码
           '' AS INVOICEDATE --  开票日期
      FROM MM_CHARGEDETAIL_TI A
     WHERE EXISTS (SELECT 'X'
              FROM MM_POLICYLIST_TI B, MM_POLICY_TI C
             WHERE A.SEQCHARGE = B.ID
               AND C.ID = B.SEQPOLICY
               AND C.POLICYNO = M_POLICYNO
               AND C.ENDORSENO = M_ENDORSENO
               AND C.CERTITYPE = '1'
               AND C.CLAIMNO IS NULL)
     GROUP BY A.POLICYNO, A.CLASSESCODE;

BEGIN

  SELECT SUM(A.AMOUNT), COUNT(DISTINCT A.CLASSESCODE)
    INTO NSUMAMT, SUMROW
    FROM MM_CHARGEDETAIL_TI A
   WHERE EXISTS (SELECT 'X'
            FROM MM_POLICYLIST_TI B, MM_POLICY_TI C
           WHERE A.SEQCHARGE = B.ID
             AND C.ID = B.SEQPOLICY
             AND C.POLICYNO = M_POLICYNO
             AND C.ENDORSENO = M_ENDORSENO
             AND C.CERTITYPE = '1'
             AND C.CLAIMNO IS NULL);

  IF SUMROW = 0 THEN
  
    V_RESULT := 0;
  
  ELSE
  
    FOR REC IN CS_CVRG LOOP
      I := I + 1;
      -- rec.id := m_reinId || '_' || to_char(i);
      IF (SUMROW = I) THEN
      
        CVRGAMT := SURPLUSAMOUNT;
      ELSE
        AMTPRPT       := REC.AMOUNT / NSUMAMT; --获取险别占比
        CVRGAMT       := ROUND(M_AMOUNT * AMTPRPT, 2); --获取到险别的分保金额
        SURPLUSAMOUNT := SURPLUSAMOUNT - CVRGAMT;
      
      END IF;
    
      REC.AMOUNT := CVRGAMT; --金额
    
      IF M_TAX_MRK = '0' THEN
        -- 应税
      
        IF (SUMROW = I) THEN
        
          REC.TAXESAMOUNT := SURPLUSTAX;
        ELSE
        
          REC.TAXESAMOUNT := ROUND(M_VAT_TAX * AMTPRPT, 2); --获取到险别的增值税金额
          SURPLUSTAX      := SURPLUSTAX - REC.TAXESAMOUNT;
        END IF;
      
        REC.TAXESRATE := M_VAT_TAX_RATE; -- 增值税率
      ELSE
        -- 免税
      
        REC.TAXESAMOUNT := 0; -- 增值税
        REC.TAXESRATE   := 0.00;
      END IF;
      -- REC.CLASSESSTYPE := to_char(M_TAX_MRK); -- 险别属性
    
      -- INSERT INTO MM_CHARGEDETAIL_TI_FND VALUES REC;
      -- INSERT INTO WEB_RI_CHARGEDETAIL VALUES REC;
      INSERT INTO MM_CHARGEDETAIL_TI_FND
        (ID,
         SEQCHARGEDETAIL,
         SEQCHARGE,
         SUBCOMPANY,
         POLICYNO,
         ENDORSENO,
         CURRENCYCODE,
         CLASSESCODE,
         AMOUNT,
         OPSTATUS,
         SOURCE,
         TIMESTAMP,
         LASTOPDATE,
         HIBERNATEVERSION,
         LANDID,
         TAXESAMOUNT,
         TAXESRATE,
         CLASSESSTYPE,
         TAXESAMOUNTOUT,
         TAXSTR,
         RETURNITEM,
         INVOICECODE,
         INVOICENO,
         INVOICEDATE)
      VALUES
        (REC.ID,
         REC.SEQCHARGEDETAIL,
         REC.SEQCHARGE,
         REC.SUBCOMPANY,
         REC.POLICYNO,
         REC.ENDORSENO,
         REC.CURRENCYCODE,
         REC.CLASSESCODE,
         REC.AMOUNT,
         REC.OPSTATUS,
         REC.SOURCE,
         REC.TIMESTAMP,
         REC.LASTOPDATE,
         REC.HIBERNATEVERSION,
         REC.LANDID,
         REC.TAXESAMOUNT,
         REC.TAXESRATE,
         --REC.CLASSESSTYPE
         M_TAX_MRK,
         REC.TAXESAMOUNTOUT,
         REC.TAXSTR,
         REC.RETURNITEM,
         REC.INVOICECODE,
         REC.INVOICENO,
         REC.INVOICEDATE);
      --INSERT INTO WEB_RI_CHARGEDETAIL VALUES REC;     
      INSERT INTO WEB_RI_CHARGEDETAIL
        (ID,
         SEQCHARGEDETAIL,
         SEQCHARGE,
         SUBCOMPANY,
         POLICYNO,
         ENDORSENO,
         CURRENCYCODE,
         CLASSESCODE,
         AMOUNT,
         OPSTATUS,
         SOURCE,
         TIMESTAMP,
         LASTOPDATE,
         HIBERNATEVERSION,
         LANDID,
         TAXESAMOUNT,
         TAXESRATE,
         CLASSESSTYPE,
         TAXESAMOUNTOUT,
         TAXSTR,
         RETURNITEM,
         INVOICECODE,
         INVOICENO,
         INVOICEDATE)
      VALUES
        (REC.ID,
         REC.SEQCHARGEDETAIL,
         REC.SEQCHARGE,
         REC.SUBCOMPANY,
         REC.POLICYNO,
         REC.ENDORSENO,
         REC.CURRENCYCODE,
         REC.CLASSESCODE,
         REC.AMOUNT,
         REC.OPSTATUS,
         REC.SOURCE,
         REC.TIMESTAMP,
         REC.LASTOPDATE,
         REC.HIBERNATEVERSION,
         REC.LANDID,
         REC.TAXESAMOUNT,
         REC.TAXESRATE,
         REC.CLASSESSTYPE,
         REC.TAXESAMOUNTOUT,
         REC.TAXSTR,
         REC.RETURNITEM,
         REC.INVOICECODE,
         REC.INVOICENO,
         REC.INVOICEDATE);
    
    END LOOP;
  
    V_RESULT := I;
  
  END IF;

  RETURN V_RESULT;

EXCEPTION
  WHEN OTHERS THEN
  
    V_SQL_CODE := SQLCODE;
    V_SQL_MSG  := V_SQL_MSG || ' ' || ' : ' || SQLERRM;
    RETURN 0;
END;
/
