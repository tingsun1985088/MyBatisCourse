CREATE FUNCTION "F_GET_DPT_RELATION" (CDptCde in varchar2)/*机构代码*/
return varchar2  --返回关系码
as

 v_DPT_CDE           varchar2(30);

 v_DPT_CDE_TMP       varchar2(30);
 V_SNR_DPT           varchar2(30);
 V_SNR_DPT_TEMP      varchar2(30);
 V_DPT_REL_CDE       varchar2(100);
 V_NUM               number      ;
 v_sql_msg           varchar2(800);

BEGIN

--返回机构的内码
V_SNR_DPT_TEMP  :=CDptCde;
     select COUNT(1) into v_NUM
     from web_org_dpt a
     where a.C_DPT_CDE=V_SNR_DPT_TEMP;
     if(V_NUM>0) then
     select C_DPT_CDE,a.C_SNR_DPT
     into v_DPT_CDE,V_SNR_DPT
     from web_org_dpt a
     where a.C_DPT_CDE=V_SNR_DPT_TEMP;
     V_SNR_DPT_TEMP  :=V_SNR_DPT;
     V_DPT_REL_CDE   :=v_DPT_CDE;
     else
     V_SNR_DPT_TEMP  :=NULL ;
     V_DPT_REL_CDE   :='NO DATA!' ;
     END IF;

while  (V_SNR_DPT_TEMP is not null ) loop
        select count(1) into v_NUM
        from web_org_dpt a
        where a.C_DPT_CDE=V_SNR_DPT_TEMP;
   if (v_NUM>0) then
        select C_DPT_CDE,a.C_SNR_DPT
        into v_DPT_CDE_TMP,V_SNR_DPT_TEMP
        from web_org_dpt a
        where a.C_DPT_CDE=V_SNR_DPT_TEMP;
     V_DPT_REL_CDE :=v_DPT_CDE_TMP||';'||V_DPT_REL_CDE;
   else
   V_SNR_DPT_TEMP  :=NULL ;
         end if ;

   END LOOP;
return    V_DPT_REL_CDE;

exception
when others then
 v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/ ||
                  ' : ' || SQLERRM;
return null;

END F_GET_DPT_RELATION;










/
