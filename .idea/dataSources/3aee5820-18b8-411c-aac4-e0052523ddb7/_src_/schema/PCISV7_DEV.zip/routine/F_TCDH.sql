CREATE FUNCTION "F_TCDH" (sIn IN varchar2)
RETURN varchar2
IS
sperTmp varchar2(3999);
sTmp varchar2(3999);
ssinTmp varchar2(3999);
i integer;
j integer;
x integer;
BEGIN
i:=1;
j:=0;
stmp:='';
ssinTmp :=','||sIn;
loop
exit when i>lengthb(ssinTmp);
j:=i+1;
sperTmp:=substrb(ssinTmp,j,2);
x:=to_number(sperTmp,'XXXX');
if x<128 then
   sTmp:=sTmp||',**'||sperTmp;
else
   sTmp:=sTmp||','||sperTmp;
end if;
i:=i+3;

end loop;
return sTmp;
END;









/
