CREATE function       GETCHECKAREALESSSQL(currentmonth in varchar2,
                                       deptcode in varchar2,
                                       tablename varchar2)
return varchar2 is
  Result varchar2(2000);
  strSQL varchar2(2000);
begin


strSQL :=
'select '
||'    c_sub_dept_cde '
||'  from '
||'      t_sub_dept '
||'  where '
||'    c_dept_cde = ''' || deptcode || ''''
||'    and c_state=''1'''
||'    and c_sub_dept_cde not in '
||'    (select distinct c_sub_dept_cde '
||'       from ' || tablename
||'       where c_month = ''' || currentmonth || ''')'
;



  Result:=strSQL;
  return(Result);

EXCEPTION
	WHEN OTHERS THEN
			RETURN '';

end GETCHECKAREALESSSQL;

/
