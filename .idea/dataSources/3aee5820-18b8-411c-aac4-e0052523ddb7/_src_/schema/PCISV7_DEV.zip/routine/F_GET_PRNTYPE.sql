CREATE FUNCTION F_GET_PrnType(v_VchType VARCHAR2)
  RETURN VARCHAR2 AS
  v_PrnType VARCHAR2(20);
BEGIN

  SELECT prn.c_prn_type
    INTO v_PrnType
    FROM WEB_vch_type prn
   WHERE prn.C_Vch_Type = v_VchType;

  RETURN v_PrnType;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;

END;

/
