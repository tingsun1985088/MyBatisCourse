CREATE FUNCTION "F_GET_NEXT_EDRNO" (V_APLNO varchar2, V_EDRNO varchar2)
return varchar2 is
--根据投保单号和批单号取得下次批改的批单号
--如果V_EDRNO为空说明是保单
V_TMPEDR_NO varchar2(50);
V_PRJNO     number;

begin

V_TMPEDR_NO :='';

if(V_EDRNO is null ) then --如果为空说明是保单
V_PRJNO :=0;
else
--根据批单号取得本次批改的批改序号
select PRJNO into V_PRJNO from

(
select a.EDRNO EDRNO,row_number() over(PARTITION BY a.APLNO ORDER BY EDRSTARTDATE,a.EDRNO) PRJNO
from T_EDR a
where a.aplno=V_APLNO
) m
where m.edrno=V_EDRNO
;
end if;

--根据批改序号返回批单号
select EDRNO into V_TMPEDR_NO from

(
select a.EDRNO EDRNO,row_number() over(PARTITION BY a.APLNO ORDER BY EDRSTARTDATE,a.EDRNO) PRJNO
from T_EDR a
where a.aplno=V_APLNO
) m
where m.prjno=V_PRJNO+1
;

return V_TMPEDR_NO;

exception when others then
return '';

end F_GET_NEXT_EDRNO;









/
