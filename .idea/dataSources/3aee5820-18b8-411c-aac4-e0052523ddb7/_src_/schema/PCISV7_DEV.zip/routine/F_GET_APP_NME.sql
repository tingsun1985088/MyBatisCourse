CREATE FUNCTION "F_GET_APP_NME" (CPlyNo in varchar2)/*输入保单号*/
return varchar2  --返回投保人姓名
as
V_APP_NME              varchar2(4000);

BEGIN
 select nvl(C_APP_NME,' ') into V_APP_NME from T_PLY_BASE a where a.C_PLY_NO=CPlyNo;

return V_APP_NME;
exception
when others then
return ' ';

END F_GET_APP_NME;








/
