CREATE procedure ADD_PLY_INTOXG_E_03_1(BEGINDATE IN DATE, ENDDATE IN DATE) IS
      v_task_start_date  date;
      v_task_end_date    date;
      v_sql_code        number;
      v_sql_msg         varchar2(4000) := ''; ---SQL错误信息

BEGIN



  ---------------------------  车险批单  E

    BEGIN

    INSERT INTO  PRPSBUSINESSFORWEB_temp1(
            CERTIID             , --              --**流水号
            CERTINO             , --              业务号
            CERTINO1,
            POLICYNO            , --               保单号
            CERTITYPE           , --                业务类型
            CLASSCODE           , --                险类代码
            RISKCODE            , --               险种代码
            COMCODE             , --              二级机构代码
            IFCHANNEL           , --                是否渠道业务
            COINSFLAG           , --                联共保标志
            SHAREHOLDERFLAG     , --                      是否股东业务标识
            STARTDATE           , --                起保日期
            ENDDATE             , --              终保日期
            INPUTDATE           , --                录入日期
            UNDERWRITEENDDATE   , --                        核保日期
            SIGNDATE            , --               签单日期
            DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**4 E-CARGO系统
            BUSINESSNATURE      , --                     业务来源大类
            BUSINESSNATURESUB   , --                        业务来源中类
            BUSINESSNATUREMIN   , --                        业务来源小类
            APPLICODE           , --                投保人代码
            APPLINAME           , --                投保人名称
            APPLIADDRESS        , --                   投保人地址
            INSUREDCODE         , --                  被保险人代码
            INSUREDNAME         , --                  被保险人名称
            INSUREDADDRESS      , --                     被保险人地址
            --HANDLERCODE         , --                  经办人代码
            BRANCHCODE          , --                 归属业务部门
            TEAMCODE            , --               归属团队代码
            USERCODE            , --               归属业务员代码
            AGENTCODE           , --                归属代理人
            --AGENTUSERCODE       , --                    归属代理业务员
            AGREEMENTNO         , --                  代理人协议号
            --APPROVERCODE        , --                   复核人代码
            UNDERWRITECODE      , --                     最终核保人代码
            OPERATORCODE        , --                   操作员代码(录单人)
            MAKECOM             , --              录单人员归属机构
            --REINSFLAG           , --                商业分保标志
            BUSINESSFLAG        , --                   业务标识
            CURRENCY            , --               承保币种
            CNYEXCHRATE         , --                  承保汇率
            DISCOUNTRATE        , --                   总折扣率
            SUMAMOUNT           , --                总保险金额
            SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
            SUMPREMIUM          , --                 总保险费(折扣后总保费)
            ENDORTYPE           , --                批改类型
            ENDORDATE           , --                批改日期
            VALIDDATE           , --                生效日期(含时分秒)
            CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
            CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
            LICENSENO           , --                车牌号码(货运险存放发票号)
            CARKINDCODE         , --                  车辆使用类型(车险保单必填)
            --USEYEARS            , --               使用年限
            --COUNTRYNATURE       , --                    国别性质
            SEATCOUNT           , --                座位数
            TONCOUNT            , --               吨位数
            EXHAUSTSCALE        , --                   排量
            --MODELCODE           , --                厂牌车型
            IFRENEWAL           , --                是否续保
            OLDPOLICYNO         , --                  被续保单号
            GENERATEDATE        , --                   保批单生成日期
            CARSUBNATURECODE    , --                       车辆使用性质
            CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
            --ILOGDISRATE         , --                  ILOG手续费比例
            --PLATDISRATE         , --                  平台手续费比例
            A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
            BRATE              , --             B展业费比例
            C1RATE             , --              C1个人基础绩效费用比例
            DRATE               , --            D个人附加费用比例
            ERATE               , --            E机构销售管理费用比例
            IRATE               , --            I项目拓展费用费用比例
            JRATE               , --            J追加费用比例
            ISSETTLEMENT        , --                   是否结算标记
           -- COINSPLANFLAG       , --                    共保业务缴费方式
           -- BUSINESSDEPARTMENT  , --                         业务服务部门
            CREATEDATE          , --                 创建时间
            BIZNO,  -- 保险卡号
            BIZTYPE,  -- 单证类型
            TOTALPROTOCOLTNO, -- 预约协议号
            DATASTATUS,
            ITEMSTATUS,
            ISACCOUNT,  -- 是否挂账
            custseq     --  车险custseq

    )
    SELECT
            PRPSBUSINESSFORWEB_seq.Nextval,
            wpb.c_edr_no,
            wpb.c_edr_no,
            wpb.c_ply_no,
            wpb.c_app_typ,
            --(select c_kind_no from web_prd_prod wpp where wpp.c_prod_no=wpb.c_prod_no ),
            substr(wpb.c_prod_no,1,2),
            wpb.c_prod_no,
            --nvl(substr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),instr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),';',1,1)+1,instr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),';',1,2)-1-instr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),';',1,1)),wpb.c_dpt_cde),
            nvl(dp2.C_SNR_DPT,wpb.c_dpt_cde),
             decode(wpb.c_bsns_typ,'19001',0,1),
            decode(wpb.c_ci_mrk,'3','1','4','2','1','3','2','4','0'),--  共保标识  hexin  外部34
            --wpb.c_ci_mrk
            decode(wpb.c_cha_type,'1900103',1,0),
            (wpb.t_insrnc_bgn_tm+1/24/60/60), -- 起保日期
            wpb.t_insrnc_end_tm,
            --wpb.t_app_tm,
            wpb.t_crt_tm,
            wpb.t_udr_tm,
            --wpb.t_issue_tm,
            nvl(wpb.t_issue_tm,wpb.t_crt_tm),
            decode(wpb.c_sys_res,'ECARGO','4','1'),-- che chuan 1
            wpb.c_bsns_typ,
            wpb.c_cha_type,
            wpb.c_cha_subtype,
            wpa.c_app_cde,
            wpa.c_app_nme,
            wpa.c_clnt_addr,
            wpi.c_insured_cde,
            wpi.c_insured_nme,
            wpi.c_clnt_addr,
            --NULL,  经办人
            wpb.c_dpt_cde,
            wpb.c_salegrp_cde,
            wpb.c_sls_id,
            wpb.c_brkr_cde,
            --null,   归属代理业务员
            wpb.c_agt_agr_no,
            --null,   核心无复核人
            wpb.c_udr_cde,
            wpb.c_opr_cde,
           -- (SELECT woo.c_own_dpt_cde FROM web_org_oper woo WHERE woo.c_oper_id  = wpb.c_opr_cde), --录单员归属机构
             woo.c_own_dpt_cde,
            --null, 商业分保标识
            wpb.c_inwd_mrk,
            --wpb.c_prm_cur,-- 保费币种
            decode( wpb.c_prm_cur,'01','CNY','02','HKD','03','USD','04','GBP','12','EUR','05','JPY'),-- 保费币种
            wpb.n_prm_rmb_exch,-- 保费人民币汇率
            wpb.n_irr_ratio, -- 折扣率
            wpb.n_amt,
            nvl((wpb.n_base_prm-wpb.n_all_prm),0),  --总折扣费
            --wpb.n_prm,  --折扣后总保险金额
            wapv.n_prm_clean,  --  净费（价税分离后的保费）16/10/10
            wpb.c_edr_type,
            wpb.t_edr_app_tm,
            (wpb.t_edr_bgn_tm+1/24/60/60),
            wpb.n_amt_var,
            --wpb.n_prm_var,
            nvl(wapv.n_prm_var_clean,wpb.n_prm_var),  --  净费（价税分离后的保费变化量）16/10/10
            wpv.c_plate_no,
            wpv.c_vhl_typ,
            --  null,  使用年限
            --  null, 进出口标志
            wpv.n_seat_num,
            wpv.n_tonage,
            wpv.n_displacement,
            --wpv.c_model_cde,  厂牌车型代码
            --wpb.c_renew_mrk,
            decode(wpb.c_renew_mrk,'0','0','1','1','0'),
            wpb.c_orig_ply_no,
            --(wpb.t_insrnc_bgn_tm+1/24/60/60), -- 起保日期,  -- 报批单落地时间
            wpb.t_crt_tm,
            wpv.c_usage_cde,
            wpv.c_affirm_cde,
            --null,
            --null,
      /*      nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y0' ),0),
            nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y3' ),0),
            nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y2' ),0),
            nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y1' ),0),*/
             nvl(wpf.n_fee_prop,0),--y0
            nvl(wpf1.n_fee_prop,0),--y3
            nvl(wpf2.n_fee_prop,0),--y2
            nvl(wpf3.n_fee_prop,0),--y1
            --0.0,
            nvl(wpfe.n_fee_prop,0),--y4
            0.0,
            0.0,
            DECODE(wpb.c_ecargo_fee_typ,'1','1','0','0','1'),
            --NULL
            --null
            SYSDATE,
            /*(SELECT wco.c_card_no FROM WEB_CARD_ORLOG wco WHERE wco.c_app_no = wpb.c_app_no AND wco.c_ply_no=wpb.c_ply_no),
            (SELECT wco.c_card_type FROM WEB_CARD_ORLOG wco WHERE wco.c_app_no = wpb.c_app_no AND wco.c_ply_no=wpb.c_ply_no),*/
                wco.c_card_no    ,
            wco.c_card_type   ,
            wpb.c_oc_agr_no,
            '0',
            '0',
            --'1'
            --decode(wpb.c_bsns_typ,'19001',0,1),
            (CASE WHEN wpf.n_fee_prop='0'and wpf2.n_fee_prop='0' THEN '0' ELSE '1'END),
            cus.custseq
            /*(CASE WHEN wpb.t_crt_tm<to_date('2016/07/25 00:00:00','yyyy/mm/dd hh24:mi:ss') THEN '0'
                       WHEN wpb.t_crt_tm>=to_date('2016/07/25 00:00:00','yyyy/mm/dd hh24:mi:ss') THEN '1'
                         ELSE NULL END)*/


    FROM web_ply_base wpb
    LEFT JOIN  web_ply_applicant wpa ON wpa.c_app_no = wpb.c_app_no   --   根据投保单号关联投保人信息表
    LEFT JOIN  web_ply_insured wpi ON wpi.c_app_no = wpb.c_app_no     --   根据投保单号关联被保人信息表
    LEFT JOIN  WEB_PLY_VHL wpv ON wpv.c_app_no = wpb.c_app_no
     left join  web_org_dpt  dp1  on dp1.C_DPT_CDE=wpb.C_DPT_CDE
     left join  web_org_dpt  dp2  on dp2.C_DPT_CDE=dp1.C_SNR_DPT
      left join web_org_oper  woo  on  woo.c_oper_id  = wpb.c_opr_cde
     left join web_ply_fee   wpf  on  wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y0'
     left join web_ply_fee     wpf1    on  wpf1.c_app_no = wpb.c_app_no AND wpf1.c_feetyp_cde='Y3'
     left join web_ply_fee  wpf2 on   wpf2.c_app_no = wpb.c_app_no AND wpf2.c_feetyp_cde='Y2'
       left join  web_ply_fee wpf3 on wpf3.c_app_no = wpb.c_app_no AND wpf3.c_feetyp_cde='Y1'
     LEFT JOIN  (SELECT w.c_app_no,w.n_fee_prop FROM web_ply_fee w  WHERE w.c_feetyp_cde='Y4') wpfe on wpfe.c_app_no = wpb.c_app_no
    --LEFT JOIN  (SELECT w.c_app_no,w.n_fee_prop FROM web_ply_fee w  WHERE w.c_feetyp_cde='Y5') wpff on wpff.c_app_no = wpb.c_app_no
         left join WEB_CARD_ORLOG   wco  on  wco.c_app_no = wpb.c_app_no AND wco.c_ply_no=wpb.c_ply_no
    --LEFT JOIN  web_ply_fee wpf ON wpf.c_app_no = wpb.c_app_no
    left join web_app_base_vat wapv ON wapv.c_vat_query_cde = wpb.c_vat_query_cde   ---   根据价税分离码查询16/10/10
    left join (SELECT t.id,t.policyno,t.endorseno FROM mm_policy_ti t WHERE t.certitype='1') mmti on mmti.endorseno=wpb.c_edr_no   ---   车险传送custseq
    LEFT JOIN (SELECT ti.custseq,ti.seqpolicy,ti.policyno,ti.endorseno FROM mm_policylist_ti ti
                  WHERE  ti.datatype='1')   cus  ON cus.seqpolicy=mmti.id  AND cus.endorseno=wpb.c_edr_no

    WHERE    substr(wpb.c_prod_no,0,2)='03'
    AND wpb.c_app_typ='E'
    --AND wpb.c_ply_no in(SELECT ee FROM aaa WHERE ee<>'无')  --  0722
    AND wpb.c_edr_no IN(SELECT c_edr_no FROM dealwithmistake WHERE c_status='0' AND c_edr_no<>'无')
    AND (wpb.n_prm_var <>0 /*OR  wpb.n_prm_var IS NULL */)    --  保费变化量为0的不传销管
    AND (wpb.t_crt_tm BETWEEN begindate AND enddate OR wpb.t_crt_tm<=enddate)
     AND wpb.c_fee_flag='1'  ---  已后置
    AND wpf.t_upd_tm BETWEEN begindate AND enddate
    ;





  ---------------  -----------   子表车险 批单E


    INSERT INTO PRPSBUSINESSSUBFORWEB_temp1(
          --ID                 ,-- 主键
          CERTINO            ,--      业务号
          CERTINO1            ,
          CERTITYPE          ,--        业务类型
          POLICYNO           ,--       保单号码
          CLASSCODE          ,--        险类代码
          RISKCODE           ,--       险种代码
          ITEMKINDNO         ,--         序号
          COMCODE            ,--      归属机构代码
          TEAMCODE           ,--       归属团队代码
          KINDCODE           ,--       险别代码（核心）
          KINDNAME           ,--       险别名称（核心）
          ACOUNTKINDCODE     ,--             险别代码（收付）
          ACOUNTKINDNAME     ,--             险别名称收付）
          --ACCOUNTKINDCODE    ,--              对应财务险别
          STARTDATE          ,--        起保日期
          ENDDATE            ,--      终保日期
          CURRENCY           ,--       承保币种
          PREMIUM            ,--      折扣后保费
          CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
          CNYEXCHRATE        ,--          CNY的兑换率
         -- COINSRATE          ,--        共保份额
         -- COINSRATEFEE       ,--           共保金额
         -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
          AMOUNT             ,--     累计赔偿限额
          --PERACCLIMITFEE     ,--             每次事故赔偿限额
          --SEATCOUNT          ,--        投保乘客座位数
         -- PERSEATFEE         ,--         每座保费
          GENERATEDATE       ,--           保批单生成日期
          CERTIID            ,--      --**流水号
          USERCODE           ,--       归属业务员工号
          CREATEDATE         ,--         创建时间
          UPDATEDATE         ,--         修改时间
          ISDUTYfREE         --         此险别是否免税
    )
    SELECT
          --PRPSBUSINESSSUBFORWEB_seq.Nextval,
          wpc.c_edr_no,
          wpc.c_edr_no,
          --(SELECT wpb.c_app_typ FROM web_ply_base wpb WHERE wpb.c_app_no = wpc.c_app_no),
          wpb.c_app_typ,--  批单
          wpc.c_ply_no,
          --(select c_kind_no from web_prd_prod wpp where wpp.c_prod_no=wpb.c_prod_no ),
          substr(wpb.c_prod_no,1,2),
          wpb.c_prod_no,
          --wpc.n_seq_no,
          number_seq.nextval,  --  序号改为序列
          wpb.c_dpt_cde,
          wpb.c_salegrp_cde,-- tuandui
          wpc.c_cvrg_no,
      /*    (SELECT w1.c_nme_cn FROM web_prd_cvrg w1 WHERE w1.c_cvrg_no = wpc.c_cvrg_no),
          (SELECT DISTINCT wf.c_fin_prod FROM web_mid_busprod_con_finprod wf WHERE wf.c_bus_cvrg_no=wpc.c_cvrg_no AND wpb.c_prod_no=wf.c_bus_prod  AND wf.c_fin_prod IS NOT NULL),
          (SELECT DISTINCT wf.c_fin_prod_name FROM web_mid_busprod_con_finprod wf WHERE wf.c_bus_cvrg_no=wpc.c_cvrg_no AND wpb.c_prod_no=wf.c_bus_prod AND wf.c_fin_prod IS NOT NULL),*/
           w1.c_nme_cn,
            --wf.c_fin_prod,
           decode(wpc.c_cvrg_no,'033018','020301','030065','020102','030077','020207','030071','020208','030000',wf2.c_fin_prod,wf.c_fin_prod),
          -- wf.c_fin_prod_name,
           decode(wpc.c_cvrg_no,'033018','车损险（示范条款）','030065','车损附加险','030077','摩托车','030071','拖拉机','030000',wf2.c_fin_prod_name,wf.c_fin_prod_name),

          --null,
          nvl((wpc.t_bgn_tm+1/24/60/60),(wpb.t_insrnc_bgn_tm+1/24/60/60)),
          nvl(wpc.t_end_tm,wpb.t_insrnc_end_tm),
          decode( wpb.c_prm_cur,'01','CNY','02','HKD','03','USD','04','GBP','12','EUR','05','JPY'),-- 保费币种
          --wpb.c_prm_cur, --  保费币种
          --decode(wpc.n_prm,null,0,wpc.n_prm),--  折后保费
          nvl(decode(wpc.c_cvrg_no,'033018',hhh.summoney1,wacv.n_prm_clean),decode(wpc.n_prm,null,0,wpc.n_prm)),  ---   净费（价税分离后的保费）
          --wpc.n_prm_var,-- 保费变化量
          nvl(decode(wpc.c_cvrg_no,'033018',hhh.summoney2,wacv.n_prm_var_clean),wpc.n_prm_var),  ---   净费（价税分离后的保费变化量）
          wpb.n_prm_rmb_exch,--人民币汇率
          --null,
          --null,
          --null,
          nvl(wpc.n_indem_lmt,0),  --wpb.n_indem_lmt,-- 赔偿限额合计
          --null，
          --null,
          --null,
          --(wpc.t_bgn_tm+1/24/60/60),
          wpb.t_crt_tm,
          PRPSBUSINESSSUBFORWEB_seq.Nextval,
          wpb.c_sls_id,
          wpc.t_crt_tm,
          wpc.t_upd_tm,
          nvl((SELECT DISTINCT  wbcr.c_vat_typ from web_bas_cvrg_vat_rate wbcr WHERE wbcr.c_cvrg_no=wpc.c_cvrg_no AND wpc.c_cvrg_no LIKE'03%'),'0') -- 车险都为应税  0应1免2零       此险别是否免税

    FROM web_ply_cvrg  wpc
    left join web_ply_base wpb  on wpc.c_app_no=wpb.c_app_no
    left join web_prd_cvrg  w1 on  w1.c_cvrg_no = wpc.c_cvrg_no
    left join web_mid_busprod_con_finprod wf on wf.c_bus_cvrg_no=wpc.c_cvrg_no AND wpb.c_prod_no=wf.c_bus_prod AND wf.c_fin_prod IS NOT NULL
    left join web_bas_cvrg_vat_rate wbcr on  wbcr.c_cvrg_no=wpc.c_cvrg_no AND substr(wpc.c_cvrg_no,0,2)='03'
    LEFT JOIN WEB_PLY_VHL wpv ON wpv.c_app_no=wpc.c_app_no
    LEFT JOIN web_mid_busprod_con_finprod wf2 ON wf2.c_bus_prod=wpb.c_prod_no AND wf2.c_bus_cvrg_no=wpv.c_usage_cde
     LEFT JOIN web_app_cvrg_vat wacv ON wacv.c_vat_query_cde = wpb.c_vat_query_cde AND wacv.c_cvrg_no = wpc.c_cvrg_no -- decode(wpc.c_cvrg_no,'033018',sum(wacv2.n_prm_clean),wacv1.n_prm_clean),
    LEFT JOIN (SELECT SUM(wacv2.n_prm_clean) summoney1,SUM(wacv2.n_prm_var_clean) summoney2,wacv2.c_vat_query_cde FROM web_app_cvrg_vat wacv2 WHERE wacv2.c_cvrg_no like'%A' GROUP BY wacv2.c_vat_query_cde) hhh ON hhh.c_vat_query_cde=wpb.c_vat_query_cde
    left join  web_ply_fee  wpf on  wpb.c_app_no=wpf.c_app_no
    WHERE
      substr(wpc.c_cvrg_no,0,2) ='03'
    AND  exists(SELECT a.c_app_no FROM web_ply_base a LEFT JOIN web_ply_fee  wpf  on  wpf.c_app_no = a.c_app_no AND wpf.c_feetyp_cde='Y0' WHERE
                      a.c_app_typ='E'
                      AND (a.n_prm_var<>0 OR a.n_prm_var IS NULL)
                     -- AND wpb.c_ply_no in(SELECT ee FROM aaa WHERE ee<>'无')  --  0722
                      --AND wpb.c_edr_no IN(SELECT c_edr_no FROM dealwithmistake WHERE c_status='0')
                      AND a.c_fee_flag='1'
                      AND (a.t_crt_tm BETWEEN begindate AND enddate OR a.t_crt_tm<=enddate)
                      AND  wpf.t_upd_tm BETWEEN begindate AND enddate
                       )-- 主表保费变化量为0的不传销管
    --AND wpc.t_upd_tm BETWEEN begindate AND enddate
    AND wpb.c_app_typ='E'
    AND wpb.c_edr_no IN(SELECT c_edr_no FROM dealwithmistake WHERE c_status='0' AND c_edr_no<>'无')
    AND (wpb.n_prm_var<>0 OR wpb.n_prm_var IS NULL)
    AND wpb.c_fee_flag='1'  ----  add 2017-03-23
     and   wpf.c_feetyp_cde='Y0'
    AND (wpb.t_crt_tm BETWEEN begindate AND enddate
 OR wpb.t_crt_tm<= enddate
)
    AND wpf.t_upd_tm BETWEEN  begindate AND enddate

    --AND wpc.t_crt_tm BETWEEN begindate AND enddate

    ;


  END;
  COMMIT;







   SELECT SYSDATE INTO v_task_end_date FROM dual;

    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_E_03_1',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    COMMIT;






EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_E_03_1',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
       commit;
end ADD_PLY_INTOXG_E_03_1;
/
