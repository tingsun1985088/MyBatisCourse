CREATE FUNCTION f_get_seqval(v_seqname VARCHAR2) RETURN NUMBER AS
  n_val NUMBER(20);
BEGIN

  --查询当前序列
  EXECUTE IMMEDIATE 'select ' || v_seqname || '.nextval from dual'
    INTO n_val;
  --如序列为负数，说明可能正在重建，返回0
  IF n_val > 0 THEN
    RETURN n_val;
  ELSE
    --重复取数10次，直接成功为止
    FOR p IN (SELECT 1 FROM dual CONNECT BY LEVEL <= 10) LOOP
      EXECUTE IMMEDIATE 'select ' || v_seqname || '.nextval from dual'
        INTO n_val;
      --取序列值成功
      IF n_val > 0 THEN
        RETURN n_val;
      END IF;
    END LOOP;
    --取序列值失败
    RETURN NULL;
  END IF;

  --异常处理
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
/
