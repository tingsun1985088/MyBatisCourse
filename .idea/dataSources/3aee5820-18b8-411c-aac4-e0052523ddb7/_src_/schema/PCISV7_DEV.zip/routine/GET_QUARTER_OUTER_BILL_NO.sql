CREATE FUNCTION "GET_QUARTER_OUTER_BILL_NO" 
(f_type    IN VARCHAR2,
                                             f_type_no IN VARCHAR2,
                                             f_uw_year IN VARCHAR2,
                                             f_prod_no IN VARCHAR2,
                                             f_style IN VARCHAR2)
  RETURN VARCHAR2 is
  pragma AUTONOMOUS_TRANSACTION;

  fType VARCHAR2(50):=f_type;
  fTypeNo VARCHAR(50):=f_type_no;
  fUwYear VARCHAR2(50):=f_uw_year;
  fProdNo VARCHAR2(50):=f_prod_no;
  fStyle VARCHAR2(50) :=f_style;
  /* fType VARCHAR2(50):='P_IB';
  fTypeNo VARCHAR(50):='IB';
  fDptCde VARCHAR2(50):='0211010000000';
  fUwYear VARCHAR2(50):='2011';
  fProdNo VARCHAR2(50):='000000';*/
  --fStyle VARCHAR2(50) :='000';
  innerBillNo VARCHAR2(50) := NULL;
  seriano     number:=-1;
  serianoN    CHAR(20) := NULL;
BEGIN
 if (fUwYear is null) then
    fUwYear := trim(to_char(sysdate, 'yyyy'));
  end if;
  if (fProdNo is null) then
    fProdNo := '000000';
  end if;
  if(fType is null) then
    fType :='X_XX';
   end if;
  if (fTypeNo is null) then
    fTypeNo:=trim(substr(fType,3,4));
   end if;
  if (fStyle is null) then
    fStyle:='00000000';
   end if;
  SELECT t.n_seriano
    into seriano
    from web_sys_seriano t
   where t.c_vch_typ = fType
     and t.c_dpt_cde = '0000'
     and t.c_year = fUwYear
     and t.c_prod_no = fProdNo;
  if (seriano is not null) then
    seriano := seriano + 1;
    update web_sys_seriano t
       set t.n_seriano = seriano
     where t.c_vch_typ = fType
       and t.c_dpt_cde ='0000'
       and t.c_year = fUwYear
       and t.c_prod_no = fProdNo;
    commit;
    serianoN    := trim(to_char(seriano,fStyle));
    innerBillNo :=fTypeNo|| fUwYear ||fProdNo|| serianoN;
  end if;
  --DBMS_OUTPUT.PUT_LINE(innerBillNo);
  return innerBillNo;
exception
  when no_data_found then
   insert into web_sys_seriano (c_vch_typ,
                               c_dpt_cde,
                               c_prod_no,
                                  c_year,
                               n_seriano
                             )
                               values (fType,
                                       '0000',
                                       fProdNo,
                                       fUwYear,
                                       1
                               );
   commit;
   seriano:=1;
   serianoN    := trim(to_char(seriano,fStyle));
   innerBillNo :=fTypeNo|| fUwYear ||fProdNo|| serianoN;
    return innerBillNo;
END;






/
