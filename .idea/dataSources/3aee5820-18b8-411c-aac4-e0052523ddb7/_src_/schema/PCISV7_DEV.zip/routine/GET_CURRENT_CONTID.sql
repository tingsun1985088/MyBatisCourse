CREATE FUNCTION "GET_CURRENT_CONTID" (CContId in varchar2,CBillYear in varchar2)/*输入查询合约ID和账单年*/
return varchar2  --返回当前账单年合约ID
as
  current_contid          varchar2(30):=CContId;

BEGIN

SELECT max(m.c_cont_id) into current_contid
          FROM web_ri_cont_main m
           where m.c_uw_year<=CBillYear
         START WITH m.c_cont_id = CContId
        CONNECT BY PRIOR m.c_cont_id=m.c_orig_cont_id;


return   current_contid;

exception
when others then
return CContId;

END;






/
