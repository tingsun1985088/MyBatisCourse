CREATE FUNCTION F_RI_DETECT_DATA_VAT(TBGNDATE VARCHAR2,
                                            TENDDATE VARCHAR2)
  RETURN VARCHAR2 AS
  V_ERROR_MSG VARCHAR2(1000); --问题信息
  V_COUNT     NUMBER; --统计条数
  V_FUN_POINT VARCHAR2(100); --节点
  V_SUM_COUNT NUMBER; --总问题数据
  --返回 商业NCD浮动原因
BEGIN

  V_SUM_COUNT := 0;

  ------------------------------------------------------------------------------------------------------------------------------
    --检检测ced和ced_vat表中毛保费不一致问题
  --若有数据则存在有不一致情况，需确认

  V_FUN_POINT := 'vat_point_001';
  V_ERROR_MSG := '检测ced和ced_vat表中毛保费不一致!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT aaa.vatpk_id,aaa.pk_idprm,aaa.c_plyedrced_pk_id
            FROM (SELECT a.c_plyedrced_pk_id vatpk_id,
               a.n_ced_prm pk_idprm,
               b.c_plyedrced_pk_id,
               b.n_ced_prm,
               (a.n_ced_prm - b.n_ced_prm) diff
            FROM (SELECT ced.c_plyedrced_pk_id, ced.n_ced_prm,ced.c_ply_no
                from WEB_RI_PLYEDR_CED_vat ced
                 WHERE (c_app_no, n_split_seq, n_rbk_seq, n_tms) IN
                       (select c_app_no, n_split_seq, n_rbk_seq, n_tms
                          from WEB_RI_PLYEDR_DUE
                         where 1=1
                         AND t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                          )) a
          FULL OUTER JOIN

         (SELECT ced.c_plyedrced_pk_id, ced.n_ced_prm,ced.c_ply_no
           from WEB_RI_PLYEDR_CED ced
          WHERE (c_app_no, n_split_seq, n_rbk_seq, n_tms) IN
                (select c_app_no, n_split_seq, n_rbk_seq, n_tms
                   from WEB_RI_PLYEDR_DUE
                   where 1=1
                       AND t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                       )) b

            ON a.c_plyedrced_pk_id = b.c_plyedrced_pk_id) aaa
              WHERE aaa.diff <> 0);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       aaa.C_PLY_NO AS C_DOC_NO,
       aaa.n_split_seq AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
       V_ERROR_MSG AS C_ERR_MSG,
       aaa.vatpk_id AS C_RESV_TXT_1, --表WEB_RI_PLYEDR_CED_vat保单号c_plyedrced_pk_id
       '' AS C_RESV_TXT_2,
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       aaa.diff as N_DIFF      --毛保费差异额
  FROM (SELECT a.c_plyedrced_pk_id vatpk_id,
               a.c_ply_no,
               a.n_ced_prm pk_idprm,
               b.c_plyedrced_pk_id,
               b.n_ced_prm,
               a.n_split_seq,
               (a.n_ced_prm - b.n_ced_prm) diff
          FROM (SELECT ced.c_plyedrced_pk_id, ced.n_ced_prm, ced.c_ply_no,ced.n_split_seq
                  from WEB_RI_PLYEDR_CED_vat ced
                 WHERE (c_app_no, n_split_seq, n_rbk_seq, n_tms) IN
                       (select c_app_no, n_split_seq, n_rbk_seq, n_tms
                          from WEB_RI_PLYEDR_DUE
                         where 1=1
                        AND t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                        )) a
          FULL OUTER JOIN

         (SELECT ced.c_plyedrced_pk_id, ced.n_ced_prm, ced.c_ply_no,ced.n_split_seq
           from WEB_RI_PLYEDR_CED ced
          WHERE (c_app_no, n_split_seq, n_rbk_seq, n_tms) IN
                (select c_app_no, n_split_seq, n_rbk_seq, n_tms
                   from WEB_RI_PLYEDR_DUE
                  where 1=1
                         AND t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                         )) b

            ON a.c_plyedrced_pk_id = b.c_plyedrced_pk_id) aaa
        WHERE aaa.diff <> 0;

 COMMIT;

  END IF;

  ------------------------------------------------------------------------------------------------
  --------检测risk_unit和risk_unit_vat表险位未转入问题!!!
    V_FUN_POINT := 'vat_point_002';
  V_ERROR_MSG := 'risk_unit和risk_unit_vat表险位未转入!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (select ss.a1
           from (select unit.c_ply_app_no a1, vat.c_ply_app_no a2,vat.c_ply_riskunit_pk_id
            from web_ply_risk_unit unit,web_ply_risk_unit_vat vat
              where unit.c_pk_id = vat.c_ply_riskunit_pk_id(+)
              and (
                     unit.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                  or unit.t_upd_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                )) ss
                  where a2 is null);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.c_ply_no AS C_DOC_NO,
       '' AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
      ss.c_ply_riskunit_pk_id  AS C_RESV_TXT_1, --表web_ply_risk_unit_vat保单号c_ply_riskunit_pk_id
       ss.a1 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
    from (select unit.c_ply_app_no a1, vat.c_ply_app_no a2,vat.c_ply_riskunit_pk_id,vat.c_ply_no
            from web_ply_risk_unit unit,web_ply_risk_unit_vat vat
              where unit.c_pk_id = vat.c_ply_riskunit_pk_id(+)
              and (
                     unit.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                  or unit.t_upd_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                )) ss
                  where a2 is null;

 COMMIT;

  END IF;


--------------------------------------------------------------------------------------------------------------
 ---检测web_ri_plyedr_due_vat表保单未转入问题!!!
 V_FUN_POINT := 'vat_point_003';
  V_ERROR_MSG := 'web_ri_plyedr_due_vat表保单未转入!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (select ss.a1
          from (select due.c_app_no     a1,
               due.c_ply_no     b1,
               vat.c_ply_app_no a2,
               vat.c_ply_no     b2
          from web_ri_plyedr_due due, web_ri_plyedr_due_vat vat
         where due.c_plyedrdue_pk_id = vat.c_plyedrdue_pk_id(+)
               and due.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               ) ss
             where a2 is null);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.b1 AS C_DOC_NO,
       '' AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
      ss.c_plyedrdue_pk_id  AS C_RESV_TXT_1, --表web_ri_plyedr_due_vat保单号vat.c_plyedrdue_pk_id
       ss.a1 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
  from (select due.c_app_no     a1,
               due.c_ply_no     b1,
               vat.c_ply_app_no a2,
               vat.c_plyedrdue_pk_id,
               vat.c_ply_no     b2
          from web_ri_plyedr_due due, web_ri_plyedr_due_vat vat
         where due.c_plyedrdue_pk_id = vat.c_plyedrdue_pk_id(+)
               AND  due.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               ) ss
          where a2 is null;

 COMMIT;

  END IF;
-----------------------------------------------------------------------------------------------------
 --检测web_ri_plyedr_due_vat保批单税率为0
  V_FUN_POINT := 'vat_point_004';
  V_ERROR_MSG := 'web_ri_plyedr_due_vat保批单税率为0!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (select  vat.c_ply_no from web_ri_plyedr_due_vat vat where vat.c_vat_mrk='1' and vat.n_tax_amt <>0 and  vat.n_rates=0.00);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       vat.c_ply_no AS C_DOC_NO,
       vat.n_split_seq AS N_SPLIT_SEQ,  --拆分序号
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       vat.c_pk_id  AS C_RESV_TXT_1, --表web_ri_plyedr_due_vat保单号vat.c__pk_id
       vat.c_ply_app_no AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
       from web_ri_plyedr_due_vat vat
       where vat.c_vat_mrk='1' and vat.n_tax_amt <>0 and  vat.n_rates=0.00;

 COMMIT;

  END IF;


-----------------------------------------------------------------------------------------------------------------------
--检测web_ply_risk_unit_vat险位税率为0为零问题
  V_FUN_POINT := 'vat_point_005';
  V_ERROR_MSG := 'web_ply_risk_unit_vat险位税率为0!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (select vat.c_ply_app_no from web_ply_risk_unit_vat vat where vat.c_vat_mrk='1' and vat.n_tax_amt <>0 and  vat.n_rates=0.00);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       vat.c_ply_no AS C_DOC_NO,
       vat.n_seq_no AS N_SPLIT_SEQ,  --拆分序号
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       vat.c_pk_id  AS C_RESV_TXT_1, --表web_ri_plyedr_due_vat保单号vat.c__pk_id
       vat.c_ply_app_no AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
        from web_ply_risk_unit_vat vat
        where vat.c_vat_mrk='1' and vat.n_tax_amt <>0 and  vat.n_rates=0.00;


 COMMIT;

  END IF;

------------------------------------------------------------------------------------------------------------
---web_ri_fac_bid_main_vat表临分 临分未转入问题||||||
 V_FUN_POINT := 'vat_point_006';
 V_ERROR_MSG := 'web_ri_fac_bid_main_vat表临分保单未转入!!!';

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (select  ss.a1  from (select due.c_app_no a1,due.c_ply_no b1,vat.c_ply_app_no a2,vat.c_ply_no b2
             from web_ri_fac_bid_main due,web_ri_fac_bid_main_vat vat
             where due.c_fac_bid_main_pk_id=vat.c_fac_bid_main_pk_id(+)
              AND due.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
              )ss
               where a2 is null);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.b1 AS C_DOC_NO,
       ss.n_split_seq  AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
      ss.c_fac_bid_main_pk_id  AS C_RESV_TXT_1, --表web_ri_plyedr_due_vat保单号vat.c_plyedrdue_pk_id
       ss.a2 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
         '' as N_DIFF
       from (select due.c_app_no a1,due.c_ply_no b1,vat.c_ply_app_no a2,vat.c_ply_no b2,vat.c_fac_bid_main_pk_id ,vat.n_split_seq
             from web_ri_fac_bid_main due,web_ri_fac_bid_main_vat vat
             where due.c_fac_bid_main_pk_id=vat.c_fac_bid_main_pk_id(+)
              AND  due.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
              )ss
       where a2 is null;

 COMMIT;

  END IF;

--------------------------------------------------------------------------------------------------------
-----分出计算缺少增值税数据wenti
 V_FUN_POINT := 'vat_point_007';
 V_ERROR_MSG := 'web_ri_plyedr_ced 和 vat 表分出计算缺少增值税数据!!!';

   SELECT COUNT(1)
    INTO V_COUNT
    FROM (select ss.a1
          from (select due.c_app_no a1,
               due.c_ply_no b1,
               vat.c_app_no a2,
               vat.c_ply_no b2
          from web_ri_plyedr_ced due, web_ri_plyedr_ced_vat vat
         where due.c_plyedrced_pk_id = vat.c_plyedrced_pk_id(+)
         and exists (select 1 from web_ri_plyedr_due rt
             where rt.c_app_no = due.c_app_no and rt.n_edr_prj_no = due.n_edr_prj_no and rt.n_split_seq = due.n_split_seq
             and rt.n_tms = due.n_tms and rt.n_rbk_seq = due.n_rbk_seq
             and rt.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS'))
              ) ss
            where a2 is null);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.b1 AS C_DOC_NO,
       ss.n_split_seq  AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       ss.c_plyedrced_pk_id  AS C_RESV_TXT_1,
       ss.a2 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
       from (select due.c_app_no a1,
               due.c_ply_no b1,
               vat.c_app_no a2,
               vat.c_ply_no b2,
               due.c_plyedrced_pk_id,
               due.n_split_seq
          from web_ri_plyedr_ced due, web_ri_plyedr_ced_vat vat
         where due.c_plyedrced_pk_id = vat.c_plyedrced_pk_id(+)
         and exists (select 1 from web_ri_plyedr_due rt
             where rt.c_app_no = due.c_app_no and rt.n_edr_prj_no = due.n_edr_prj_no and rt.n_split_seq = due.n_split_seq
             and rt.n_tms = due.n_tms and rt.n_rbk_seq = due.n_rbk_seq
             and rt.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS'))
              ) ss
            where a2 is null;


 COMMIT;

  END IF;
---------------------------------------------------------------------------------------------------------------------
---险位业务表数据重复问题
 V_FUN_POINT := 'vat_point_008';
 V_ERROR_MSG := 'web_ply_risk_unit 险位业务表数据重复!!!';

   SELECT COUNT(1)
    INTO V_COUNT
    FROM (
       select ss.a1
         from (select unit.c_ply_app_no a1,
               count(*) over(partition by unit.c_ply_app_no, unit.n_seq_no) nums
          from web_ply_risk_unit unit
         where (
                  unit.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                  or unit.t_upd_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               )) ss
          where nums > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.b1 AS C_DOC_NO,
       ss.n_seq_no  AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       ss.c_pk_id  AS C_RESV_TXT_1,
       ss.a1 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
       from (select unit.c_ply_app_no a1,unit.c_ply_no b1 ,unit.c_pk_id ,unit.n_seq_no,
               count(*) over(partition by unit.c_ply_app_no, unit.n_seq_no) nums
          from web_ply_risk_unit unit
         where (
                  unit.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                  or unit.t_upd_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               )) ss
          where nums > 1;

 COMMIT;

  END IF;


 -----------------------------------------------------------------------------------------------------------
 -------险位VAT表数据重复
 V_FUN_POINT := 'vat_point_009';
 V_ERROR_MSG := 'web_ply_risk_unit_vat 险位业务表数据重复!!!';

   SELECT COUNT(1)
    INTO V_COUNT
    FROM (
      select ss.a1
         from (select unit.c_ply_app_no a1,
               vat.c_ply_app_no a2,
               count(1) over(partition by vat.c_ply_riskunit_pk_id) nums
          from web_ply_risk_unit unit, web_ply_risk_unit_vat vat
         where unit.c_pk_id = vat.c_ply_riskunit_pk_id
           and(
                 unit.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                 or unit.t_upd_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               )) ss
            where nums > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.b1 AS C_DOC_NO,
       ss.n_seq_no  AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       ss.c_ply_riskunit_pk_id  AS C_RESV_TXT_1,
       ss.a2 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
      from (select unit.c_ply_app_no a1,
               vat.c_ply_app_no a2,
               vat.c_ply_riskunit_pk_id,
               vat.c_ply_no b1,
               vat.n_seq_no,
               count(1) over(partition by vat.c_ply_riskunit_pk_id) nums
          from web_ply_risk_unit unit, web_ply_risk_unit_vat vat
         where unit.c_pk_id = vat.c_ply_riskunit_pk_id
           and(
                 unit.t_crt_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
                 or unit.t_upd_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               )) ss
        where nums > 1;

 COMMIT;

  END IF;

---------------------------------------------------------------------------------------------------------------
----保批单业务表数据重复

 V_FUN_POINT := 'vat_point_010';
 V_ERROR_MSG := 'web_ri_plyedr_due保批单业务表数据重复!!!';

   SELECT COUNT(1)
    INTO V_COUNT
    FROM (
         select ss.a1
        from (select due.c_app_no a1,
               due.c_ply_no b1,
               count(*) over(partition by due.c_app_no, due.n_split_seq, due.n_rbk_seq) nums
          from web_ri_plyedr_due due
         where  1=1
              AND due.t_ridue_tm BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               ) ss
         where nums > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.b1 AS C_DOC_NO,
       ss.n_split_seq  AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       ss.c_plyedrdue_pk_id  AS C_RESV_TXT_1,
       ss.a1 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
       from (select due.c_app_no a1,
               due.c_ply_no b1,
               due.c_plyedrdue_pk_id,
               due.n_split_seq,
               count(*) over(partition by due.c_app_no, due.n_split_seq, due.n_rbk_seq) nums
          from web_ri_plyedr_due due
          where  1=1
              AND due.t_ridue_tm BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
               ) ss
          where nums > 1;

 COMMIT;

  END IF;

-------------------------------------------------------------------------------------------------------------------------------
-----保批单VAT表数据重复

 V_FUN_POINT := 'vat_point_011';
 V_ERROR_MSG := 'web_ri_plyedr_due,web_ri_plyedr_due_vat保批单VAT表数据重复!!!';

   SELECT COUNT(1)
    INTO V_COUNT
    FROM (
         select ss.a1
        from (select due.c_app_no a1,
               due.c_ply_no b1,
               vat.c_ply_app_no a2,
               vat.c_ply_no b2,
               count(*) over(partition by vat.c_ply_app_no, vat.n_split_seq, vat.n_rbk_seq) nums,
               count(*) over(partition by vat.c_plyedrdue_pk_id, vat.n_rbk_seq) nums2
          from web_ri_plyedr_due due, web_ri_plyedr_due_vat vat
         where due.c_plyedrdue_pk_id = vat.c_plyedrdue_pk_id(+)
              AND due.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
              ) ss
           where nums > 1
            or nums2 > 1);

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ss.b1 AS C_DOC_NO,
       ss.n_split_seq  AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       ss.c_plyedrdue_pk_id  AS C_RESV_TXT_1,
       ss.a1 AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       '' as N_DIFF
       from (select due.c_app_no a1,
               due.c_ply_no b1,
               vat.c_ply_app_no a2,
               vat.c_ply_no b2,
               due.c_plyedrdue_pk_id,
               vat.n_split_seq,
               count(*) over(partition by vat.c_ply_app_no, vat.n_split_seq, vat.n_rbk_seq) nums,
               count(*) over(partition by vat.c_plyedrdue_pk_id, vat.n_rbk_seq) nums2
          from web_ri_plyedr_due due, web_ri_plyedr_due_vat vat
         where due.c_plyedrdue_pk_id = vat.c_plyedrdue_pk_id(+)
              AND due.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS')
              ) ss
        where nums > 1
          or nums2 > 1;


 COMMIT;

  END IF;


------------------------------------------------------------------------------------------------------------------------------------------
----------ced_vat  表的分出计算数据检查

 V_FUN_POINT := 'vat_point_012';
 V_ERROR_MSG := 'web_ri_plyedr_due_vat保批单VAT表数据重复!!!';

   SELECT COUNT(1)
    INTO V_COUNT
    FROM (
         select  ddd.c_app_no
           from (select
               t.c_pk_id,
               t.c_app_no,
               t.c_ply_no,
               t.n_split_seq,
               t.n_ced_prm, --毛保费
               t.n_ced_prm_old, --原业务表毛保费
               t.n_ri_ced_containtax_prm, --净保费
               t.n_ri_ced_tax_amt, -- 增值税
               t.n_ri_ced_vat_prm, --应税保费
               t.n_ri_ced_nvat_prm, -- 免税保费
               t.n_ced_prm - t.n_ri_ced_containtax_prm - t.n_ri_ced_tax_amt A1,
               t.n_ri_ced_containtax_prm - t.n_ri_ced_vat_prm -t.n_ri_ced_nvat_prm A2,
               t.n_ri_ced_containtax_prm + t.n_ri_ced_tax_amt -t.n_ri_ced_vat_prm - t.n_ri_ced_nvat_prm - t.n_ri_ced_tax_amt A3,
               t.n_ced_prm - t.n_ced_prm_old A4
          from WEB_RI_PLYEDR_CED_vat t
         where 1 = 1
           and exists
         (select 1
                  from web_ri_plyedr_due due
                 where due.c_app_no = t.c_app_no
                   and due.n_edr_prj_no = t.n_edr_prj_no
                   and due.n_split_seq = t.n_split_seq
                   and due.n_tms = t.n_tms
                   and due.n_rbk_seq = t.n_rbk_seq
                   and due.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS') )
                       ) ddd
           where ddd.A1 <> 0
               or ddd.A2 <> 0
               or ddd.A3 <> 0
               or A4 <> 0 );

  V_SUM_COUNT := V_SUM_COUNT + V_COUNT;

  IF (V_COUNT > 0) THEN
    INSERT INTO WEB_RI_DETECT_DATA_LOG_vat
      SELECT
      SYS_GUID() AS C_PK_ID,
       '0' AS C_TYPE,
       '0' AS C_STAUS,
       SYSDATE AS T_EXE_TM,
       'F_RI_DETECT_DATA_VAT' AS C_FUN_NME,
       V_FUN_POINT AS C_FUN_EXE_POINT,
       ddd.c_ply_no AS C_DOC_NO,
       ddd.n_split_seq  AS N_SPLIT_SEQ,
       V_COUNT AS N_COUNT_EDATA,
      V_ERROR_MSG AS C_ERR_MSG,
       ddd.c_pk_id  AS C_RESV_TXT_1,
       ddd.c_app_no  AS C_RESV_TXT_2,      --对应投保单号
       '' AS C_RESV_TXT_3,
       'Ri' AS C_CRT_CDE,
       SYSDATE AS T_CRT_TM,
       'Ri' AS C_UPD_CDE,
       SYSDATE AS T_UPD_TM,
       ddd.A3 as N_DIFF
      from (select
               t.c_pk_id,
               t.c_app_no,
               t.c_ply_no,
               t.n_split_seq,
               t.n_ced_prm, --毛保费
               t.n_ced_prm_old, --原业务表毛保费
               t.n_ri_ced_containtax_prm, --净保费
               t.n_ri_ced_tax_amt, -- 增值税
               t.n_ri_ced_vat_prm, --应税保费
               t.n_ri_ced_nvat_prm, -- 免税保费
               t.n_ced_prm - t.n_ri_ced_containtax_prm - t.n_ri_ced_tax_amt A1,
               t.n_ri_ced_containtax_prm - t.n_ri_ced_vat_prm -t.n_ri_ced_nvat_prm A2,
               t.n_ri_ced_containtax_prm + t.n_ri_ced_tax_amt -t.n_ri_ced_vat_prm - t.n_ri_ced_nvat_prm - t.n_ri_ced_tax_amt A3,
               t.n_ced_prm - t.n_ced_prm_old A4
          from WEB_RI_PLYEDR_CED_vat t
         where 1 = 1
           and exists
         (select 1
                  from web_ri_plyedr_due due
                 where due.c_app_no = t.c_app_no
                   and due.n_edr_prj_no = t.n_edr_prj_no
                   and due.n_split_seq = t.n_split_seq
                   and due.n_tms = t.n_tms
                   and due.n_rbk_seq = t.n_rbk_seq
                   and due.t_ridue_tm  BETWEEN TO_DATE(TBGNDATE,'YYYY-MM-DD HH24:MI:SS')  AND  TO_DATE(TENDDATE,'YYYY-MM-DD HH24:MI:SS') )
                       ) ddd
           where ddd.A1 <> 0
               or ddd.A2 <> 0
               or ddd.A3 <> 0
               or A4 <> 0 ;


 COMMIT;

  END IF;


--------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
  RETURN V_SUM_COUNT;
  /*exception
  when others then
    return 11111111;*/
END F_RI_DETECT_DATA_vat;
/
