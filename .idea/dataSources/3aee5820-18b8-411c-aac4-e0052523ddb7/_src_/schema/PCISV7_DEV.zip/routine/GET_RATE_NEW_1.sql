CREATE FUNCTION Get_Rate_New_1(
  cur_no_1 IN VARCHAR2,  /*要转化的币种*/
  cur_no_2 IN VARCHAR2, /*转化后的币种*/
  VN_AMT IN NUMBER, /*要转化的金额*/
  --VBGN_TM IN DATE /*月初*/
 VBGN_TM VARCHAR2 /*月初*/ --yyyy/mm
  )
RETURN NUMBER
AS
      -- CURSOR curhv_1 IS
      --   select   exchangerate from mm_conversionrate_tc   where CURRENCYCODE1=cur_no_1 and  CURRENCYCODE2=cur_no_2  AND STARTDATE=VBGN_TM;
       
        CURSOR curhv_1 IS 
        select  mm.exchangerate from mm_conversionrate_tc  MM, WEB_BAS_FIN_CUR CUR ,WEB_BAS_FIN_CUR CUR1
   where mm.CURRENCYCODE1=cur.C_CUR_UNT   and  mm.CURRENCYCODE2=cur1.C_CUR_UNT   
          and  CUR.C_CUR_CDE=cur_no_1     and  CUR.c_is_valid='1'
            and  CUR1.C_CUR_CDE=cur_no_2      and  CUR1.c_is_valid='1'
      --AND mm.STARTDATE=to_date(to_char(VBGN_TM,'yyyy/mm')||'01','yyyy/mm/dd');
       AND mm.STARTDATE=to_date(VBGN_TM||'01','yyyymm/dd');
      
    hv_ret NUMBER;
    nCount NUMBER;

BEGIN
     /*取提数月初汇率*/
       hv_ret := 1;
        OPEN curhv_1;
        FETCH curhv_1 INTO hv_ret;
        IF curhv_1%NOTFOUND THEN
             RETURN VN_AMT;
        END IF;
        CLOSE curhv_1;
      
    RETURN (hv_ret * VN_AMT);

EXCEPTION
  WHEN  OTHERS THEN
      RETURN VN_AMT;
END;
/
