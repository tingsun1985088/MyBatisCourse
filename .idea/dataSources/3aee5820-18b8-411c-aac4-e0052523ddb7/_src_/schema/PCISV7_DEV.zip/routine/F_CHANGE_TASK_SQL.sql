CREATE FUNCTION F_CHANGE_TASK_SQL(
                                        VSQL   CHAR,
                                        VPARAM VARCHAR2,
                                        CRPTID Varchar2,
                                        CRPTNO Varchar2,
                                        TASKID Varchar2,
                                        TASKNO Varchar2,
                                        ICNUM  Varchar2--理算序号
                                        ) 
                                        RETURN VARCHAR2 IS


 v_sql      VARCHAR2 (2000);


BEGIN

  SELECT  REPLACE(to_char(VSQL), 'v_crptno', CRPTNO) INTO v_sql FROM dual ;
  
  SELECT  REPLACE(v_sql, 'v_crptid', CRPTID) INTO v_sql FROM dual ;
  
  SELECT  REPLACE(v_sql, 'v_taskno', TASKNO) INTO v_sql FROM dual ;
  
  SELECT  REPLACE(v_sql, 'v_taskid', TASKID) INTO v_sql FROM dual ;
  
  SELECT  REPLACE(v_sql, 'v_icnum',  ICNUM) INTO v_sql FROM dual ;
  
  IF  VPARAM IS NOT NULL THEN
  
    SELECT  REPLACE(v_sql, '?',  VPARAM) INTO v_sql FROM dual ;
    
    END IF;

  RETURN v_sql;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;
/
