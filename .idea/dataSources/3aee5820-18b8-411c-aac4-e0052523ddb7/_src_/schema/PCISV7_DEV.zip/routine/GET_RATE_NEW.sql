CREATE FUNCTION Get_Rate_New(
  cur_no_1 IN VARCHAR2,  /*要转化的币种*/
  cur_no_2 IN VARCHAR2, /*转化后的币种*/
  VN_AMT IN NUMBER, /*要转化的金额*/
  VBGN_TM IN DATE, /*保险起期*/
  VUDR_TM IN DATE, /*核保日期*/
  VMAK IN VARCHAR2  /*0 保单 1 赔款*/
  )
RETURN NUMBER
AS
    CURSOR curhv IS
      SELECT  N_CHG_RTE
       FROM WEB_BAS_FIN_CHG_RATE
      WHERE C_CUR_cde1 = cur_no_1
       AND C_CUR_cde2 = cur_no_2
       AND VBGN_TM >= VUDR_TM
       and  T_EFFC_TM<=VBGN_TM
       and nvl(T_EXPD_TM,sysdate)>=VBGN_TM
     Union All
      SELECT  N_CHG_RTE
       FROM WEB_BAS_FIN_CHG_RATE
      WHERE C_CUR_cde1 = cur_no_1
       AND C_CUR_CDE2 = cur_no_2
       AND VBGN_TM < VUDR_TM
       and  T_EFFC_TM<=VUDR_TM
       and nvl(T_EXPD_TM,sysdate)>=VUDR_TM;

       CURSOR curhv1 IS
      SELECT  N_CHG_RTE
       FROM WEB_BAS_FIN_CHG_RATE
      WHERE C_CUR_CDE1 = cur_no_1
       AND C_CUR_CDE2 = cur_no_2
       AND VBGN_TM >= VUDR_TM
       and  T_EFFC_TM<=VBGN_TM-1
       and nvl(T_EXPD_TM,sysdate)>=VBGN_TM-1
     Union All
      SELECT  N_CHG_RTE
       FROM WEB_BAS_FIN_CHG_RATE
      WHERE C_CUR_CDE1 = cur_no_1
       AND C_CUR_CDE2 = cur_no_2
       AND VBGN_TM < VUDR_TM
       and  T_EFFC_TM<=VUDR_TM-1
       and nvl(T_EXPD_TM,sysdate)>=VUDR_TM-1;

       CURSOR curhv2 IS
      SELECT  N_CHG_RTE
       FROM WEB_BAS_FIN_CHG_RATE
      WHERE C_CUR_CDE1 = cur_no_1
       AND C_CUR_CDE2 = cur_no_2
       and  T_EFFC_TM<=VUDR_TM
       and nvl(T_EXPD_TM,sysdate)>=VUDR_TM;

    hv_ret NUMBER;
    nCount NUMBER;

BEGIN
     /*按照保单挂帐日取汇率，没有汇率，系统取上一日汇率，如果上一日仍没有汇率，取核保日汇率； modified by marui 2008-03-07*/
       hv_ret := 1;
       /* nCount :=0;
        SELECT  count(*) INTO nCount
          FROM T_CHG_RATE
         WHERE C_CUR_NO_1 = cur_no_1
           AND C_CUR_NO_2 = cur_no_2
           AND ((VBGN_TM >= VUDR_TM and  T_EFFC_TM<=VBGN_TM and nvl(T_EXPD_TM,sysdate)>=VBGN_TM)
            or (VBGN_TM < VUDR_TM and  T_EFFC_TM<=VUDR_TM and nvl(T_EXPD_TM,sysdate)>=VUDR_TM));
        IF nCount <>0 THEN*/
        OPEN curhv;
        FETCH curhv INTO hv_ret;
        IF curhv%NOTFOUND THEN
             --RETURN VN_AMT;
            OPEN curhv1;
            FETCH curhv1 INTO hv_ret;
            IF curhv1%NOTFOUND THEN
               IF VMAK = 0 THEN
                  OPEN curhv2;
                  FETCH curhv2 INTO hv_ret;
                  IF curhv2%NOTFOUND THEN
                      RETURN VN_AMT;
                  END IF;
                  CLOSE curhv2;
               ELSE
                   RETURN VN_AMT;
               END IF;
            END IF;
            CLOSE curhv1;
        END IF;
        CLOSE curhv;
       /* ELSE
            OPEN curhv1;
        FETCH curhv1 INTO hv_ret;
        IF curhv1%NOTFOUND THEN
             RETURN VN_AMT;
        END IF;
        CLOSE curhv1;
      END IF;*/
    RETURN (hv_ret * VN_AMT);

EXCEPTION
  WHEN  OTHERS THEN
      RETURN VN_AMT;
END;

/
