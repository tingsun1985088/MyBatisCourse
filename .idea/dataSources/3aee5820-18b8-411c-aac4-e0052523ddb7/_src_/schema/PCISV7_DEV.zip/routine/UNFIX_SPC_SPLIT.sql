CREATE function Unfix_Spc_Split(str   varchar2, --要分割的字符串(特别约定)
                                           split varchar2, --分隔符号
                                           num   number --分割的长度
                                           ) return varchar2 is
  result_str   varchar2(4000); --返回的字符串
  lv_str       varchar2(1000);
  currentIndex number;
  startIndex   number;
  endIndex     number;
  type str_type is table of varchar2(3000) index by binary_integer;
  arr str_type;
  startnum     number;

--特别约定按照固定长度拆分，add by sxp
begin
  result_str   := '';
  lv_str       := '';
  currentIndex := 0;
  startIndex   := 0;
  startnum  := 0;

 if 1 > length(trim(str)) then
      --首先将特别约定按照分隔符号(split)拆分成字符串数组，此处为:chr(10)
      loop
        currentIndex := currentIndex + 1;
        endIndex     := instr(str, split, 1, currentIndex);
        if (endIndex <= 0) then
          arr(currentIndex) := trim(substr(str, startIndex + 1, length(str)));
          exit;
        end if;

        arr(currentIndex) := trim(substr(str,
                                         startIndex + 1,
                                         endIndex - startIndex - 1));
        startIndex := endIndex;
      end loop;

      --针对每一条记录进行拆分
      for i in 1 .. currentIndex loop
        for j in 1 .. length(arr(i)) loop
          if num * j <= length(arr(i)) then
            lv_str := substr(arr(i), num * (j - 1) + 1, num);
          else
            lv_str     := substr(arr(i), num * (j - 1) + 1);--剩下的不足当前长度的内容
            result_str := result_str || replace(lv_str, chr(13), chr(10));--格式控制
            exit;
          end if;
          startnum := startnum+1;
          result_str := result_str || lv_str || chr(10);
        end loop;
      end loop;

      for i in result_str .. 10 loop
         result_str := result_str ||'　'||chr(10);
      end loop;

  else
      for i in 1 .. 10 loop
         result_str := result_str ||'　'||chr(10);
      end loop;
      end if;
  return result_str;
end Unfix_Spc_Split;
/
