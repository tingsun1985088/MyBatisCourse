CREATE FUNCTION "GET_DISCHG_SUM" (ctype   IN VARCHAR2, /* 标识：3-3年期，5-5年期, caojy add 6-5年期,zhanghui add 7,9-1年期*/
                          bgn_tm  IN DATE, /* 保险起期*/
                          end_tm  IN DATE, /* 保险止期*/
                          stat_tm IN DATE, /* 统计日期*/
                          icount  IN NUMBER /* 份数*/) RETURN NUMBER IS
    vsum   NUMBER(16, 2);
    imonth NUMBER;
  BEGIN
    IF TO_DATE(TO_CHAR(stat_tm, 'yyyymmdd'), 'yyyymmdd') -
       TO_DATE(TO_CHAR(bgn_tm, 'yyyymmdd'), 'yyyymmdd') >= 15 THEN
      /* 判断是否过保险期限*/
      IF stat_tm > end_tm THEN
        SELECT CEIL(MONTHS_BETWEEN(TO_DATE(TO_CHAR(end_tm, 'yyyymmdd'),
                                           'yyyymmdd') + 1,
                                   TO_DATE(TO_CHAR(bgn_tm, 'yyyymmdd'),
                                           'yyyymmdd')))
          INTO imonth
          FROM DUAL;
      ELSE
        SELECT CEIL(MONTHS_BETWEEN(TO_DATE(TO_CHAR(stat_tm, 'yyyymmdd'),
                                           'yyyymmdd') + 1,
                                   TO_DATE(TO_CHAR(bgn_tm, 'yyyymmdd'),
                                           'yyyymmdd')))
          INTO imonth
          FROM DUAL;
      END IF;

      /* 类型错误*/
      IF ctype NOT IN ('3', '5', '6','7','9') /*caojy add 6 2006-01-13*//*zhanghui add 7,9 2008-04-08*/
       THEN
        RETURN - 1;
      END IF;

      /* 3年期期限输入错误*/
      IF imonth > 36 AND ctype = '3' THEN
        RETURN - 2;
      END IF;

      /* 5年期期限输入错误*/
      IF imonth > 60 AND (ctype = '5' OR ctype = '6') /*caojy add 6 2006-01-13*/
       THEN
        RETURN - 3;
      END IF;

     /* 1年期期限输入错误*/
      IF imonth > 12 AND (ctype = '7' OR ctype = '9') /*zhanghui add 7,9 2008-04-08*/
       THEN
        RETURN - 3;
      END IF;
      /* 取出并计算退保金额*/
      SELECT n_sum * icount
        INTO vsum
        FROM T_RETURN_SUM
       WHERE c_type = ctype
         AND i_month = imonth;
    ELSE
      vsum := icount * 10000;
    END IF;

    RETURN(vsum);
  END;
end








/
