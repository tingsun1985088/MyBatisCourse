CREATE FUNCTION F_GET_RECV_ISSUE_TM(v_vchType VARCHAR2,v_bgnPrnNo VARCHAR2,v_endPrnNo VARCHAR2,
v_dptCde VARCHAR2,v_handle VARCHAR2,v_flag VARCHAR2) RETURN date AS
  v_ret_tm date;
BEGIN
  if v_flag = 'retVerTm' then 
    null;
  elsif v_flag='newDrawTm' then
    null;
  end if;
  RETURN v_ret_tm;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;

/
