CREATE function ri_cont_main_policy_upd(dstarttm in varchar2,
                                                  dendtm   in varchar2) return INTEGER IS

  pragma autonomous_transaction;
  result            integer := 0;
  v_count           integer := 0;

  /*
    查询合约是否终止，在时间段内已审核的本年度止期大于查询日期的数据

  */

begin
    --查询合约是否有变化 终止
  select count(1)
    into v_count
    from WEB_RI_CONT_MAIN  main
   where main.c_cont_status = 'P'
    
     and main.T_LOGOUT_TM is not null
     and main.T_LOGOUT_TM between to_date(dstarttm ||'000000', 'yyyy-mm-dd hh24:mi:ss') and to_date(dendtm ||'235959', 'yyyy-mm-dd hh24:mi:ss');

  commit;
  result := v_count;

  return(result);
end ri_cont_main_policy_upd;
/
