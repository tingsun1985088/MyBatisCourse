CREATE function F_rule_WX_0001_bk_20151022(v_app_no varchar2)
  return number
as
--根据投保单号判断是不是"交强+三者+不计免赔"  1是，0不是
  v_count number ;
  v_jsUnion_flag number ;

  v_app_no_SY varchar2(50);
  v_SY_flag number ;
begin
  --判断是否交商联合单
  select F_rule_isUnionJQSY(v_app_no) into v_jsUnion_flag from dual;
  if v_jsUnion_flag = 1 then
      --取得关联单中的商业险投保单号
      select c_ply_app_no into v_app_no_SY
        from web_ply_relation
       where n_id in (select n_id
                        from web_ply_relation k
                       where c_ply_app_no = v_app_no)
         and c_prod_no like '033%'
         and rownum <= 1;

      --判断商业险只投保了 三者+不计免赔
      SELECT count(*)  into v_SY_flag
          FROM WEB_APP_BASE t
         WHERE t.C_APP_NO = v_app_no_SY
           AND t.c_prod_no in ('033011','033014')
           and t.c_app_typ = 'A'
           --and nvl(t.c_sys_res,'0') ='00'
           and (select count(1) from WEB_APP_CVRG k where k.c_app_no =v_app_no_SY and k.c_cvrg_no  in ('033002','033018')) = 2
           and (select count(1) from WEB_APP_CVRG k where k.c_app_no = v_app_no_SY and k.c_cvrg_no not in ('033002','033018')) = 0
      ;
      if v_SY_flag >=1 then
         v_count := 1;
      else
         v_count := 0;
      end if;
  else
      v_count := 0;
  end if;

  return v_count;
exception
  when others then
    return 0;
end;
/
