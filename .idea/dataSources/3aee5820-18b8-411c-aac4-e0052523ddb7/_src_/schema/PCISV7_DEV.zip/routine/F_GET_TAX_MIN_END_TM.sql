CREATE FUNCTION "F_GET_TAX_MIN_END_TM" (VBILLNO IN VARCHAR2 )
return DATE
AS
V_ENDDATE DATE;
begin
  select MIN(ENDDATE)INTO V_ENDDATE from T_AutoShipRate n
    where n.BILLNO=VBILLNO
          and n.subjstatus='1';
  return(V_ENDDATE);
exception
when others then
return NULL;
end F_GET_TAX_MIN_END_TM;









/
