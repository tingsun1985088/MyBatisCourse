CREATE function       f_getcarcode(
 c_doc_no   varchar2,/*保单号、批单号*/
 c_doc_type  integer /*1：保单号；2：批单号；3：赔案号::赔付次数*/
) return varchar2 /*返回车型代码*/
as
  v_car_code  varchar2(10);
  v_plyedr_no  varchar2(50);
  v_plyedr_type integer;
  v_trace_str  varchar2(500);
begin
  case c_doc_type
  when 1 then
    select a.C_CAR_CODE into v_car_code
    from T_CARTYPE_EXCHANGE a left join T_PLY_VHL b on (a.C_BUS_TYPE=decode( b.C_FEE_ATR, '345001028', '---', '345010010', '---','345019012', '---','345019013', '---',b.C_USE_ATR) and a.C_CAR_TYPE=b.C_FEE_ATR and a.C_CAR_DETAIL=decode( b.C_FEE_ATR, '345001028', '---','345010010', '---','345019012', '---', '345019013', '---',b.C_VHL_TYP) )
     where b.c_ply_no=c_doc_no;
  when 2 then
    select a.C_CAR_CODE into v_car_code
    from T_CARTYPE_EXCHANGE a left join T_EDR_VHL b on (a.C_BUS_TYPE=decode( b.C_FEE_ATR, '345001028', '---', '345010010', '---','345019012', '---','345019013', '---',b.C_USE_ATR) and a.C_CAR_TYPE=b.C_FEE_ATR and a.C_CAR_DETAIL=decode( b.C_FEE_ATR, '345001028', '---', '345010010', '---','345019012', '---','345019013', '---',b.C_VHL_TYP) )
    where b.c_edr_no=c_doc_no;
  when 3 then
    select nvl(c_edr_no, c_ply_no), decode(c_edr_no, null, 1, 2)
    into v_plyedr_no, v_plyedr_type
    from t_clm_main
    where c_clm_no=substr( c_doc_no, 1, instr(c_doc_no, '::')-1 )
    and n_clm_tms = to_number( substr( c_doc_no, instr(c_doc_no, '::') + 2, length( c_doc_no ) - instr(c_doc_no, '::')-1 ) );
    v_car_code :=  f_getcarcode( v_plyedr_no, v_plyedr_type );
  else
   return '---';
  end case;
  return v_car_code;
exception
  when others then
   return '---';
end;

/
