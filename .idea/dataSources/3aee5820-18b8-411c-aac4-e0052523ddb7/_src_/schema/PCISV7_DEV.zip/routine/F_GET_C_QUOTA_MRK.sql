CREATE FUNCTION "F_GET_C_QUOTA_MRK" (V_APLNO in varchar2 )
return  varchar2
as
--取保单批单的'是否定额单'

  V_RESULT varchar2(30);

begin
  V_RESULT :='';
  /*if(V_APLNO like '_______________B%') then
  */
  --zxl110317
/*select  HAVEOWNGARAGE into V_RESULT from T_plc a ,t_subjauto b where a.aplno=V_APLNO and a.aplno=substr(b.subjno,1,22)
and b.startdate=a.startdate
and (b.startdate,b.enddate )
in (select min(startdate),min(enddate) from T_SubjAuto  m
    where m.subjno=b.subjno
   )
and b.subjstatus='1'
;*/
select  HAVEOWNGARAGE into V_RESULT from t_subjauto b 
where b.subjno like v_aplno||'%'
and b.subjstatus='1'
and rownum=1;
 /*else

  select  HAVEOWNGARAGE into V_RESULT from t_edr a ,t_subjauto b where a.edrno=V_APLNO and a.aplno=substr(b.subjno,1,22)
and b.Syscurrtime<=a.Syscurrtime
and (b.startdate,b.enddate ) in (select max(startdate),max(enddate) from T_SubjAuto n
                                 where n.subjno=b.subjno
                                   and n.Syscurrtime<=a.Syscurrtime
                                 )
and b.subjstatus='1'
;
  end if;*/
  return V_RESULT;
exception
when others then
return null;
end F_GET_C_QUOTA_MRK;









/
