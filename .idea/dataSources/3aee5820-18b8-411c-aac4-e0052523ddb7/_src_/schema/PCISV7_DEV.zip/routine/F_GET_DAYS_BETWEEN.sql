CREATE FUNCTION F_GET_DAYS_BETWEEN(insrncBgnTm in varchar2,InsrncEndTime in varchar2)
  return number
  as
    DAYS NUMBER;
  begin
    select (to_date(InsrncEndTime,'yyyy-MM-dd hh24:mi:ss')+(1/(24*60*60))) -to_date(insrncBgnTm,'yyyy-MM-dd hh24:mi:ss') into DAYS from dual;
    return trunc(DAYS);
  end;
/
