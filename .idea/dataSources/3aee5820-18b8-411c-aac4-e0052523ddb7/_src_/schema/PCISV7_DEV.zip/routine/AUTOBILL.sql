CREATE PROCEDURE "AUTOBILL" is
flag  varchar2(2);
begin
        rpAutoBill.p_premdueaccins(flag);--意外险
        rpAutoBill.p_premdueaccisc(flag);--商车险
       rpAutoBill.p_prmcontdue_accins(flag);--共保意外险
       rpAutoBill.P_paydue(flag); --手续费
       Rpautobill.p_premdue_ccs(flag); --车船税
       rpAutoBill.premdue(flag);          --不含意外险,共保、商业险保费
        rpAutoBill.premcontdue(flag);      -- 共保

end autoBill;

/
