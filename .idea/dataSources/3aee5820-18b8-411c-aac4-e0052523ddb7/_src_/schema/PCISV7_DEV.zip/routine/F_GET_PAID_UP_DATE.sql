CREATE FUNCTION "F_GET_PAID_UP_DATE" (
 vPlyno IN VARCHAR2,vEdrno IN VARCHAR2)
 --取实收时间
RETURN date
AS
  ret date;
BEGIN
  IF vPlyno = '' THEN
    RETURN null;
  END IF;
  IF vEdrno = '*' THEN --保单
    SELECT T_PAID_TM
    INTO ret
    FROM WEB_FIN_PRM_DUE
    WHERE c_ply_no=TRIM(vPlyno) and c_edr_no is null;
  ELSE
    SELECT T_PAID_TM
    INTO ret
    FROM WEB_FIN_PRM_DUE
    WHERE c_ply_no=TRIM(vPlyno) and c_edr_no = TRIM(vEdrno);
  END IF;

  RETURN ret;

EXCEPTION
 WHEN  OTHERS THEN
   RETURN '';
END;










/
