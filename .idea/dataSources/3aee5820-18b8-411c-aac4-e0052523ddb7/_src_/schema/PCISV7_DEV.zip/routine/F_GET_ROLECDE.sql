CREATE FUNCTION "F_GET_ROLECDE" (COPERID in varchar2,CDPTCDE in varchar2,ctype in varchar2 )/*员工代码、机构代码 类型 1 角色码 2 角色名称*/
return varchar2  --返回合并后的角色代码
as
--取合并角色代码的
 v_DPT_CDE           varchar2(30);

 V_OPGRP_CDE         varchar2(3000);
 V_OPGRP_NME         varchar2(3000);
 V_NUM               number      ;
 v_sql_msg           varchar2(800);

BEGIN

V_OPGRP_CDE :='';
V_OPGRP_NME :='';
for p in (select a.*,b.c_opgrp_cnm from web_grt_usr_role a,web_grt_role b
                  where a.c_Opgrp_Cde=b.c_Opgrp_Cde
                    and a.c_oper_id=COPERID
                    and a.c_dpt_cde=CDPTCDE order by a.c_opgrp_cde) loop
V_OPGRP_CDE :=p.c_opgrp_cde ||';'||V_OPGRP_CDE ;--代码
V_OPGRP_NME :=p.c_opgrp_cnm ||';'||V_OPGRP_NME; --名称

end loop;

if(ctype ='1' ) then
return    V_OPGRP_CDE;
else
return V_OPGRP_NME;
end if;

exception
when others then
 v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/ ||
                  ' : ' || SQLERRM;
return null;

END F_GET_ROLECDE;









/
