CREATE function fixSpecSplit(cAppNo in varchar2,splitNo in number,fixSpecLength number) return varchar2 as
   fixSpecNode  varchar2(3999); --总特约
   fixSpecNodeNext varchar2(3999);
   fixSpecNodeOther varchar2(3999);
  -- prodNo varchar2(6);
   x number; --声明变量
   flagNum number; --循环次数
    begin
      SELECT LISTAGG(content, '') WITHIN GROUP(ORDER BY n_seq_no) AS content into fixSpecNode
        from (
             select rownum||'、'||c_spec_content||'；' content,n_seq_no from (
              select t.c_spec_content , t.n_seq_no from web_App_Fix_Spec t where t.c_app_no = cAppNo
              order by  t.n_seq_no
          )
      );
      --如果特约长度超出规定长度，则裁掉多余部分
      if length(fixSpecNode) > fixSpecLength  then  --600
           fixSpecNode := substr(fixSpecNode, 0,fixSpecLength)||'剩余特约请见特约清单';
      end if;
/*       select t.c_prod_no into prodNo from web_bas_qry_info t where t.c_app_no=cAppNo;
   fixLength := length(fixSpecNode);
     If instr(prodNo,'030')=1 then
       --交强处理
        --如果长度超过600不拼接剩余长度
        if fixLength>fixSpecLength  then  --600
           fixSpecNode := substr(fixSpecNode, 0,fixSpecLength)||'剩余特约请见特约清单';
        end if;
     Else
       --商业处理
        if fixLength>fixSpecLength then  --370
          fixSpecNode := substr(fixSpecNode, 0,fixSpecLength)||'剩余特约请见特约清单';
        end if;
     End If;*/
     --如果符串长度大于入参字fixSpecLength 循环次数取 fixSpecLength/splitNo
      if length(fixSpecNode)< fixSpecLength  then
        flagNum := floor(length(fixSpecNode)/splitNo);
      else
         flagNum := floor(fixSpecLength/splitNo);
      end if;
     x := 0;
     WHILE x <flagNum LOOP
       x := x + 1;
       --取第一次循环的起始字符
       if x=1 then
         fixSpecNodeNext :=  substr(fixSpecNode ,0,splitNo)||CHR(10);
       end if;
       --截取到字符串末尾
      fixSpecNodeOther := substr(fixSpecNode ,(splitNo * x)+1, length(fixSpecNode));
      fixSpecNodeNext := fixSpecNodeNext||substr(fixSpecNodeOther,0,splitNo)||CHR(10);
    END LOOP;
    return fixSpecNodeNext;
    end fixSpecSplit;
/
