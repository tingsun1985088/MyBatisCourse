CREATE FUNCTION F_VHLCLM_TASK_AUTOAPPROVE(C_RPT_ID   IN VARCHAR2,
                                                     C_RPT_NO   IN VARCHAR2,
                                                     C_TASK_ID  IN VARCHAR2,
                                                     C_TASK_NO  IN VARCHAR2,
                                                     C_IC_NUM   IN VARCHAR2, --理算序号
                                                     V_C_SNR_NO IN VARCHAR2, --自核任务类型
                                                     N_Num      IN NUMBER)
  RETURN VARCHAR2 IS
  V_TASK_START_DATE DATE;
  V_TASK_END_DATE   DATE;
  V_SQL_CODE        NUMBER;
  V_SQL_MSG         VARCHAR2(4000) := ''; ---SQL错误信息
  V_SQL             VARCHAR2(4000);

  RETURNFLAG VARCHAR2(2);
  --msg               varchar2(4000);

  -- 查询公共规则
  -- DECLARE
  CURSOR RULES IS

    SELECT T.C_SQL,
           T.C_PARAM,
           T.C_RULE,
           T.C_RULE_NO,
           T.C_BLOCK_MRK,
           C_IS_BOTTOM
      FROM WEB_VHLCLM_AUTO_APPROVE_RULE T
     WHERE T.C_STATUE = '1'
       AND T.C_SNR_NO = V_C_SNR_NO
     ORDER BY t.n_order;

BEGIN
  RETURNFLAG := '1';

  --DBMS_OUTPUT.PUT_LINE(C_SNR_NO);

  declare
    numrow number;

  BEGIN
    numrow := N_Num + 1;
    FOR RULE IN RULES LOOP
      --IF rule IS NOT NULL THEN
      dbms_output.put_line('');
      dbms_output.put_line('编号' || rule.c_rule_no);
      dbms_output.put_line('执行顺序' || numrow);

      numrow := numrow + 1;
      BEGIN

        --  DBMS_OUTPUT.PUT_LINE(numrow);

        DECLARE
          XX VARCHAR2(2);

          XX1 VARCHAR2(2);

        BEGIN
          XX := '1'; --isrule
          IF RULE.C_SQL IS NOT NULL THEN
            --拼接sql
            V_SQL := F_CHANGE_TASK_SQL(RULE.C_SQL,
                                       RULE.C_PARAM,
                                       C_RPT_ID,
                                       C_RPT_NO,
                                       C_TASK_ID,
                                       C_TASK_NO,
                                       C_IC_NUM);

            dbms_output.put_line('sql规则' || V_SQL);

            --执行SQL
            XX := F_CHECK_RIGHT(V_SQL, RULE.C_RULE);
            dbms_output.put_line(rule.c_rule_no || '结果' || xx);
            RETURNFLAG := XX;

          END IF;

          IF XX = '1' Then
            --当前规则符合，
            --执行下级规则
            XX1 := F_VHLCLM_TASK_AUTOAPPROVE(C_RPT_ID,
                                             C_RPT_NO,
                                             C_TASK_ID,
                                             C_TASK_NO,
                                             C_IC_NUM,
                                             RULE.C_RULE_NO,
                                             numrow);

            DBMS_OUTPUT.PUT_LINE('结果' || XX1);

            RETURNFLAG := XX1;
          END IF;
          --并且关系 只要 有不满足  停止循环
          IF (XX = '0' OR XX1 = '0') AND RULE.C_BLOCK_MRK = '2' THEN

            RETURNFLAG := '0';
            dbms_output.put_line('返回' || returnflag);

               IF RETURNFLAG <> '1'And XX <>'1'  AND rule.C_IS_BOTTOM = '1' THEN
              --插入数据至规F_VHLCLM_TASK_AUTOAPPROVE则执行表
              insert into web_vhlclm_auto_approve_result
              values
                (sys_guid(),
                 C_RPT_NO,
                 C_TASK_ID,
                 rule.C_RULE_NO,
                 numrow,
                 'system',
                 sysdate,
                 'system',
                 sysdate,
                 '',
                 '');

            END IF;

            RETURN RETURNFLAG;

          END IF;

          --或者关系 只要有 满足  停止循环
          IF (XX = '1' and XX1 = '1') AND RULE.C_BLOCK_MRK = '1' THEN

            RETURNFLAG := '1';
            dbms_output.put_line('返回' || returnflag);

               IF RETURNFLAG <> '1'And XX <>'1' AND rule.C_IS_BOTTOM = '1' THEN
              --插入数据至规则执行表
              insert into web_vhlclm_auto_approve_result
              values
                (sys_guid(),
                 C_RPT_NO,
                 C_TASK_ID,
                 rule.C_RULE_NO,
                 numrow,
                 'system',
                 sysdate,
                 'system',
                 sysdate,
                 '',
                 '');

            END IF;

            RETURN RETURNFLAG;

          END IF;

          --或者 关系  全部满足  返回 不不满足

          --插入数据至规则执行表
            IF RETURNFLAG <> '1'And XX <>'1' AND rule.C_IS_BOTTOM = '1' THEN
            insert into web_vhlclm_auto_approve_result
            values
              (sys_guid(),
               C_RPT_NO,
               C_TASK_ID,
               rule.C_RULE_NO,
               numrow,
               'system',
               sysdate,
               'system',
               sysdate,
               '',
               '');

          END IF;
        END;

        --END IF;

      END;

    END LOOP;

  END;
  RETURN RETURNFLAG;

EXCEPTION

  WHEN OTHERS THEN
    RETURN '0';
    V_SQL_CODE := SQLCODE;
    V_SQL_MSG  := V_SQL_MSG || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO V_TASK_END_DATE FROM DUAL;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS,
       JOBNAME,
       START_DATE,
       END_DATE,
       RUN_DATE,
       SQL_CODE,
       SQL_STATE,
       C_RPT_NO,
       C_TASK_ID)
    VALUES
      ('pcisv7',
       'WANGJUN1',
       V_TASK_START_DATE,
       V_TASK_END_DATE,
       TO_CHAR((V_TASK_END_DATE - V_TASK_START_DATE) * 86400),
       V_SQL_CODE,
       V_SQL_MSG,
       C_RPT_NO,
       C_TASK_ID);


END;
/
