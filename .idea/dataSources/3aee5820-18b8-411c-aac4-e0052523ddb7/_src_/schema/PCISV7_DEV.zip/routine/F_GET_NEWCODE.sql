CREATE FUNCTION "F_GET_NEWCODE" (V_PAR_CDE_OLD varchar2, V_CDE_OLD varchar2)
return varchar2 is
--根据老系统的上级代码和代码，找到对应新系统的代码
V_CODE varchar2(400);

begin

V_CODE :='';

select a.c_cde into V_CODE from WEB_BAS_CODEDIFF a
where a.c_par_cde_old=V_PAR_CDE_OLD
and a.c_cde_old=V_CDE_OLD;

return V_CODE;

exception when others then
return V_CODE;

end F_GET_NEWCODE;









/
