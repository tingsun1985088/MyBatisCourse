CREATE FUNCTION F_UPPER_MONEY(P_NUM IN NUMBER DEFAULT NULL)
  RETURN VARCHAR2 IS
  /*Ver:1.0 Created By xsb on 2003-8-18 For:
  将金额数字(单位元)转换为大写(采用从低至高算法)
  数字整数部分不得超过16位,可以是负数。
  Ver：1.1 Modified By xsb on 2003-8-20 For:个位数处理也放在For循环中。
  Ver：1.2 Modified By xsb on 2003-8-22 For:分后不带整字。
  Ver：1.3 Modified By xsb on 2003-8-28 For:完善测试用例。
  测试用例:
  SET HEAD OFF
  SET FEED OFF
  select '无参数时='||f_upper_money() from dual;
  select 'null='||f_upper_money(null) from dual;
  select '0='||f_upper_money(0) from dual;
  select '0.01='||f_upper_money(0.01) from dual;
  select '0.126='||f_upper_money(0.126) from dual;
  select '01.234='||f_upper_money(01.234) from dual;
  select '10='||f_upper_money(10) from dual;
  select '100.1='||f_upper_money(100.1) from dual;
  select '100.01='||f_upper_money(100.01) from dual;
  select '10000='||f_upper_money(10000) from dual;
  select '10012.12='||f_upper_money(10012.12) from dual;
  select '20000020.01='||f_upper_money(20000020.01) from dual;
  select '3040506708.901='||f_upper_money(3040506708.901) from dual;
  select '40005006078.001='||f_upper_money(40005006078.001) from dual;
  select '-123456789.98='||f_upper_money(-123456789.98) from dual;
  select '123456789123456789.89='||f_upper_money(123456789123456789.89) from dual;
  test
  */
  RESULT      NVARCHAR2(100); --返回字符串
  NUM_ROUND   NVARCHAR2(100) := TO_CHAR(ABS(ROUND(P_NUM, 2))); --转换数字为小数点后2位的字符(正数)
  NUM_LEFT    NVARCHAR2(100); --小数点左边的数字
  NUM_RIGHT   NVARCHAR2(2); --小数点右边的数字
  STR1        NCHAR(10) := '零壹贰叁肆伍陆柒捌玖'; --数字大写
  STR2        NCHAR(16) := '元拾佰仟万拾佰仟亿拾佰仟万拾佰仟'; --数字位数(从低至高)
  NUM_PRE     NUMBER(1) := 1; --前一位上的数字
  NUM_CURRENT NUMBER(1); --当前位上的数字
  NUM_COUNT   NUMBER := 0; --当前数字位数
  NUM1        NUMBER;

BEGIN
  IF P_NUM IS NULL THEN
    RETURN NULL;
  END IF; --转换数字为null时返回null

  SELECT TO_CHAR(NVL(SUBSTR(TO_CHAR(NUM_ROUND),
                            1,
                            DECODE(INSTR(TO_CHAR(NUM_ROUND), '.'),
                                   0,
                                   LENGTH(NUM_ROUND),
                                   INSTR(TO_CHAR(NUM_ROUND), '.') - 1)),
                     0))
    INTO NUM_LEFT
    FROM DUAL; --取得小数点左边的数字
  SELECT SUBSTR(TO_CHAR(NUM_ROUND),
                DECODE(INSTR(TO_CHAR(NUM_ROUND), '.'),
                       0,
                       LENGTH(NUM_ROUND) + 1,
                       INSTR(TO_CHAR(NUM_ROUND), '.') + 1),
                2)
    INTO NUM_RIGHT
    FROM DUAL; --取得小数点右边的数字
  SELECT CASE
           WHEN LENGTH(NUM_LEFT) >= 8 THEN
            TO_NUMBER(SUBSTR(TO_CHAR(NUM_LEFT), -8, 4))
           ELSE
            TO_NUMBER(SUBSTR(TO_CHAR(NUM_LEFT),
                             -LENGTH(NUM_LEFT),
                             LENGTH(NUM_LEFT) - 4))
         END
    INTO NUM1
    FROM DUAL; ---取得千、百、十、万位上的数字
  IF LENGTH(NUM_LEFT) > 16 THEN
    RETURN '**********';
  END IF; --数字整数部分超过16位时

  --采用从低至高的算法，先处理小数点右边的数字
  IF LENGTH(NUM_RIGHT) = 2 THEN
    IF TO_NUMBER(SUBSTR(NUM_RIGHT, 1, 1)) = 0 THEN
      RESULT := '零' ||
                SUBSTR(STR1, TO_NUMBER(SUBSTR(NUM_RIGHT, 2, 1)) + 1, 1) || '分';
    ELSE
      RESULT := SUBSTR(STR1, TO_NUMBER(SUBSTR(NUM_RIGHT, 1, 1)) + 1, 1) || '角' ||
                SUBSTR(STR1, TO_NUMBER(SUBSTR(NUM_RIGHT, 2, 1)) + 1, 1) || '分';
    END IF;
  ELSIF LENGTH(NUM_RIGHT) = 1 THEN
    RESULT := SUBSTR(STR1, TO_NUMBER(SUBSTR(NUM_RIGHT, 1, 1)) + 1, 1) || '角整';
  ELSE
    RESULT := '整';
  END IF;
  --再处理小数点左边的数字
  FOR I IN REVERSE 1 .. LENGTH(NUM_LEFT) LOOP
    --(从低至高)
    NUM_COUNT   := NUM_COUNT + 1; --当前数字位数
    NUM_CURRENT := TO_NUMBER(SUBSTR(NUM_LEFT, I, 1)); --当前位上的数字
    IF NUM_CURRENT > 0 THEN
      --当前位上数字不为0按正常处理
      RESULT := SUBSTR(STR1, NUM_CURRENT + 1, 1) ||
                SUBSTR(STR2, NUM_COUNT, 1) || RESULT;
    ELSE
      --当前位上数字为0时
      IF NUM_COUNT = 5 THEN
        IF MOD(NUM_COUNT - 1, 4) = 0 AND NUM1 <> 0 THEN
          RESULT  := SUBSTR(STR2, NUM_COUNT, 1) || RESULT;
          NUM_PRE := 0; --元、万,亿前不准加零 --当前位是元、万或亿时
        END IF;
      ELSE
        IF MOD(NUM_COUNT - 1, 4) = 0 THEN
          RESULT  := SUBSTR(STR2, NUM_COUNT, 1) || RESULT;
          NUM_PRE := 0; --元、万,亿前不准加零
        END IF;
      END IF;
      IF NUM_PRE > 0 OR LENGTH(NUM_LEFT) = 1 THEN
        --上一位数字不为0或只有个位时
        RESULT := SUBSTR(STR1, NUM_CURRENT + 1, 1) || RESULT;
      END IF;
    END IF;
    NUM_PRE := NUM_CURRENT;
  END LOOP;

  IF P_NUM < 0 THEN
    --转换数字是负数时
    RESULT := '负' || RESULT;
  END IF;

  RETURN RESULT;

EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001, '数字转换大写出现错误！' || SQLERRM);
END;


/
