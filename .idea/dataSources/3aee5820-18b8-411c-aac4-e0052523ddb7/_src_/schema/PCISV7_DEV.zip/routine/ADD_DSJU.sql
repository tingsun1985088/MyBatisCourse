CREATE procedure Add_dsju as
  Cursor ss is
    select m.c_case_no
           from web_vhlclm_rgst r, web_vhlclm_main m
          where r.c_rpt_no = m.c_rpt_no
            and r.c_ply_typ = m.c_ply_typ
            and (m.c_dpt_cde in
                (SELECT t.c_dpt_cde as CDptCde
                    FROM web_org_dpt t
                   START WITH t.c_snr_dpt = '1041'
                  CONNECT BY PRIOR t.c_dpt_cde = t.c_snr_dpt) or
                m.c_dpt_cde = '1041')
            and r.c_rgst_no not in
                (select rg.c_rgst_no
                   from pcisv7.web_vhlclm_hn_consprotect_rgst rg)
            and r.t_rgst_tm >
                to_date('16-11-2017 20:00:00', 'dd-mm-yyyy hh24:mi:ss')
            order by r.t_rgst_tm desc;
Begin
  for b in ss loop
    BEGIN
      INSERT INTO AA
        (hongyan)
        SELECT count(SERIAL_NUM)
          FROM monitor_log t
         WHERE t.call_obj = b.call_obj;
      COMMIT;
    end;
  END loop;
END;
/
