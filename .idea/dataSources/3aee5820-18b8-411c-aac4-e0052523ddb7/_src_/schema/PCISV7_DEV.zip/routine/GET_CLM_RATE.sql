CREATE FUNCTION get_clm_rate(
  cur_no_1 in varchar2,
  cur_no_2 in varchar2,
  T_TIME   in date
  )
RETURN NUMBER
AS
    CURSOR curhv IS
      SELECT  N_CHG_RTE from Web_Bas_Fin_Chg_Rate a where C_CUR_CDE1 = cur_no_1 and C_CUR_CDE2 = cur_no_2
      and T_TIME>= a.t_effc_tm
      and T_TIME<= a.t_Expd_Tm
      ;
    hv_ret number;
BEGIN
    OPEN curhv;
    FETCH curhv into hv_ret;
    if curhv%notfound then
         return 1;
    end if;
    CLOSE curhv;

    return hv_ret;

EXCEPTION
  when  others then
      return 1;
END;
/
