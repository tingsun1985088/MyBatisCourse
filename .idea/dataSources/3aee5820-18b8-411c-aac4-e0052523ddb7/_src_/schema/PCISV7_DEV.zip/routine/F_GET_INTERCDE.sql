CREATE FUNCTION "F_GET_INTERCDE" (CDptCde in varchar2)/*机构代码*/
return varchar2  --返回机构内码
as

 v_DPT_CDE           varchar2(30);
 v_INTER_CDE         varchar2(30);
 V_NUM               number      ;

BEGIN
	v_DPT_CDE    :=CDptCde ;
  select COUNT(1) into v_NUM from T_DEPARTMENT
	where C_DPT_CDE=v_DPT_CDE;
  if(v_NUM>0) then
	select C_INTER_CDE into v_INTER_CDE from T_DEPARTMENT
	where C_DPT_CDE=v_DPT_CDE;
  end if ;
return 	v_INTER_CDE;

exception
when others then
return null;

END F_GET_INTERCDE;








/
