CREATE procedure ADD_PLY_INTOXG_1 IS
      v_task_start_date  date;
      v_task_end_date    date;
      v_sql_code        number;
      v_sql_msg         varchar2(4000) := ''; ---SQL????
      begintime         DATE;  --  ??????
      endtime           DATE;  --  ??????

BEGIN

    
    --endtime :=SYSDATE;
    /*SELECT operate_bgedate INTO begintime ADD_PLY_INTOXG_1;FROM T_SYNC_ADXG_LOG1;
    UPDATE T_SYNC_ADXG_LOG1 SET operate_bgedate = (endtime+1/24/60/60);-- between and ???
    */
    select sysdate into v_task_start_date from dual;
    select sysdate into v_task_end_date from dual;
    
         
     begintime  :=to_date('2019/5/21 17:27:47', 'yyyy/MM/dd hh24:mi:ss');
     endtime    :=to_date('2019/5/21 17:27:49', 'yyyy/MM/dd hh24:mi:ss');  
     
   /*  begintime  :=to_date('2016/4/4 00:00:00', 'yyyy/MM/dd hh24:mi:ss');
     endtime    :=to_date('2018/1/2 23:59:00', 'yyyy/MM/dd hh24:mi:ss');  */
     
     /*begintime  :=to_date('2016/3/3 15:34:22', 'yyyy/MM/dd hh24:mi:ss');
     endtime    :=to_date('2016/8/23 8:30:44', 'yyyy/MM/dd hh24:mi:ss');*/
     

    -------------- 
    

    
     execute   immediate 'truncate table PRPSBUSINESSFORWEB_temp1';
     execute   immediate 'truncate table PRPSBUSINESSSUBFORWEB_temp1';
     execute   immediate 'truncate table PRPSBUSINESSCOINSFORWEB_temp1';
     

     
     
    -------------  ?????? P E
    ADD_PLY_INTOXG_P_NOT03_1(begintime,endtime);
    ADD_PLY_INTOXG_P_03_1(begintime,endtime);
    ADD_PLY_INTOXG_E_NOT03_1(begintime,endtime);
    ADD_PLY_INTOXG_E_03_1(begintime,endtime);
    ADD_PLY_INTOXG_GB_1(begintime,endtime);
    
    /*INSERT INTO PRPSBUSINESSFORWEB_log1 SELECT * FROM PRPSBUSINESSFORWEB_temp1;
    INSERT INTO PRPSBUSINESSSUBFORWEB_log1 SELECT * FROM PRPSBUSINESSSUBFORWEB_temp1;
    INSERT INTO PRPSBUSINESSCOINSFORWEB_log1 SELECT * FROM PRPSBUSINESSCOINSFORWEB_temp1;*/
    
    
    --DELETE FROM PRPSBUSINESSSUBFORWEB_temp1 t WHERE  (t.premium =0 or  t.premium is NULL) and T.certitype='P'; 
    --DELETE FROM PRPSBUSINESSSUBFORWEB_temp1 T WHERE  (T.CHGPREMIUM=0 OR T.CHGPREMIUM IS NULL) AND (t.premium =0 or  t.premium is NULL) AND T.CERTITYPE='E';
    
    
    ----------------   ???????A???0??????????????? 201608231730
    --DELETE FROM PRPSBUSINESSSUBFORWEB_temp1 WHERE certino IN(      -----   ?????
    --SELECT certino FROM PRPSBUSINESSFORWEB_temp1 WHERE ifchannel='1' AND a1rate=0);
    
    --DELETE FROM PRPSBUSINESSCOINSFORWEB_temp1 WHERE certino IN(    -----  ?????
    --SELECT certino FROM PRPSBUSINESSFORWEB_temp1 WHERE ifchannel='1' AND a1rate=0);
    
    --DELETE FROM PRPSBUSINESSFORWEB_temp1 WHERE ifchannel='1' AND a1rate=0;   ------  ?????
    
    
/*    delete  from PRPSBUSINESSFORWEB_temp1  where substr( asciistr(usercode) ,0,1)='\'   or usercode is  null;
    delete  from PRPSBUSINESSSUBFORWEB_temp1  where substr( asciistr(usercode) ,0,1)='\'   or usercode is  null;
    delete  from PRPSBUSINESSCOINSFORWEB_temp1 where    exists ( select certino from PRPSBUSINESSFORWEB_temp  where   substr( asciistr(usercode) ,0,1)='\'   or usercode is  null);
*/
    ---------------   ????????????????
    add_sales_end_intoxg_1;
    

   SELECT SYSDATE INTO v_task_end_date FROM dual;

    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_1',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    COMMIT;  
    
    
    


EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --??????
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_1',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
       commit;
end ADD_PLY_INTOXG_1;
/
