CREATE FUNCTION       "GETMOVEFIELD"
(	      itemcode     in varchar2,
        movesubfield in varchar2)
RETURN VARCHAR AS
  fieldvalue  varchar(200);
BEGIN
  fieldvalue := '';
  select t.c_dict_cde into fieldvalue from t_item_adjunct t where t.c_item_no = itemcode and t.c_dict_type_cde = movesubfield;
  RETURN fieldvalue;

EXCEPTION
	WHEN OTHERS THEN
			RETURN '';

END;

/
