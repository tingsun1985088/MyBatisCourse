CREATE FUNCTION "F_GET_NEXT_TM" (CAplNo in varchar2,CEdrNo in varchar2 /*批单号,如果是保单则输入空*/,CTMCls in varchar2/*日期类型1返回生效起期2返回生效止期3返回下次核保日期*/)
return date
--取下次批改生效起期和批改生效止期  如果是保单批改次数输入0
--类别为1返回批改生效起期 2返回批改生效止期
as
 V_NEXT_BGN_TM       date; /*下次批改生效起期*/
 V_NEXT_END_TM       date; /*下次批改生效止期*/
 V_NEXT_UNDR_TM      date; /*下次批改核保日期*/
 V_TMP_EDR_NO        varchar2(30); --用于存放下次批改的批单号
 V_PRJNO             number;--用于存放本次批改的批改序号
 V_EDR_NO            varchar2(50);
BEGIN

V_NEXT_BGN_TM :=null;
V_NEXT_END_TM :=null;
V_NEXT_UNDR_TM :=null;
V_PRJNO :=0;
V_EDR_NO  :=CEdrNo;
if(V_EDR_NO is null  )then --批单号为空 ,说明是保单

select m.EDRNO into V_TMP_EDR_NO from
(
select a.EDRNO EDRNO,row_number() over(PARTITION BY a.APLNO ORDER BY EDRSTARTDATE,a.EDRNO) PRJNO
from T_EDR a
where a.aplno=CAplNo
) m
where m.prjno=1 --取批改序号为第一次批改的那张批单号
;
--取下次批改生效日期
select a.Edrstartdate/*,a.edr*/ into V_NEXT_BGN_TM/*,V_NEXT_END_TM*/ from T_EDR a
where a.edrno=V_TMP_EDR_NO;
--取下次批改核保日期
select  max(a.judgedate) into V_NEXT_UNDR_TM from T_EDRJUDGE a where a.EDRNO=V_TMP_EDR_NO
and a.edrjudgeopn='1' ;--取核保通过的

else

--根据传进来的批单号取得本次批改是第几次批改
select m.prjno into V_PRJNO from
(
select a.EDRNO EDRNO,row_number() over(PARTITION BY a.APLNO ORDER BY EDRSTARTDATE,a.EDRNO) PRJNO
from T_EDR a
where a.aplno=CAplNo
) m
where m.edrno=V_EDR_NO
;
--取下次批改的批单号
select m.EDRNO into V_TMP_EDR_NO from
(
select a.EDRNO EDRNO,row_number() over(PARTITION BY a.APLNO ORDER BY EDRSTARTDATE,a.EDRNO) PRJNO
from T_EDR a
where a.aplno=CAplNo
) m
where m.prjno=V_PRJNO+1 --取批改序号为第一次批改的那张批单号
;

--根据下次批改单号取得下次批改的生效起期和生效止期
select a.Edrstartdate/*,a.EDRENDDATE*/ into V_NEXT_BGN_TM/*,V_NEXT_END_TM*/ from T_EDR a
where a.edrno=V_TMP_EDR_NO;

--取下次批改核保日期
select  max(a.judgedate) into V_NEXT_UNDR_TM from T_EDRJUDGE a where a.EDRNO=V_TMP_EDR_NO
and a.edrjudgeopn='1' ;--取核保通过的
end if;

  if(CTMCls=1) then
  return V_NEXT_BGN_TM;
  elsif(CTMCls=2) then
  return V_NEXT_END_TM;
  elsif(CTMCls=3) then
  return V_NEXT_UNDR_TM;
  end if;

exception
when others then
return to_date('99991231 235959','yyyy-mm-dd hh24miss');

END F_GET_NEXT_TM;









/
