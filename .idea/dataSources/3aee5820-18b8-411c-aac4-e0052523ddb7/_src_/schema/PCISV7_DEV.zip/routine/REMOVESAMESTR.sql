CREATE function RemoveSameStr(oldStr varchar2, sign varchar2 := ',')
  return varchar2 is
  str          varchar2(1000);
  currentIndex number;
  startIndex   number;
  endIndex     number;
  type str_type is table of varchar2(30) index by binary_integer;
  arr    str_type;
  Result varchar2(1000);
begin
  -- 空字符串
  if oldStr is null then
    return('');
  end if;
  --字符串太长
  if length(oldStr) > 1000 then
    return(oldStr);
  end if;
  str          := oldStr;
  currentIndex := 0;
  startIndex   := 0;
  loop
    currentIndex := currentIndex + 1;
    endIndex     := instr(str, sign, 1, currentIndex);
    if (endIndex <= 0) then
      exit;
    end if;

    arr(currentIndex) := trim(substr(str,
                                     startIndex + 1,
                                     endIndex - startIndex - 1));
    startIndex := endIndex;
  end loop;
  --取最后一个字符串:
  arr(currentIndex) := substr(str, startIndex + 1, length(str));
  --去掉重复出现的字符串:
  for i in 1 .. currentIndex - 1 loop
    for j in i + 1 .. currentIndex loop
      if arr(i) = arr(j) then
        arr(j) := '';
      end if;
    end loop;
  end loop;
  str := '';
  for i in 1 .. currentIndex loop
    if arr(i) is not null then
      str := str || sign || arr(i);
      --数组置空:
      arr(i) := '';
    end if;
  end loop;
  --去掉前面的标识符:
  Result := substr(str, 2, length(str));
  return(Result);
end RemoveSameStr;
/
