CREATE FUNCTION "F_GET_DPTCDE" (CinterCde in varchar2)/*机构代码*/
return varchar2  --返回机构内码
as

 v_DPT_CDE           varchar2(30);
 v_INTER_CDE         varchar2(30);
 V_NUM               number      ;

BEGIN
	v_inter_CDE    :=CinterCde ;
  select COUNT(1) into v_NUM from T_DEPARTMENT
	where C_INTER_CDE=v_inter_CDE;
  if(v_NUM>0) then
	select C_DPT_CDE into v_DPT_CDE from T_DEPARTMENT
	where C_INTER_CDE=v_inter_CDE;
  end if ;
return 	v_DPT_CDE;

exception
when others then
return null;

END F_GET_DPTCDE;








/
