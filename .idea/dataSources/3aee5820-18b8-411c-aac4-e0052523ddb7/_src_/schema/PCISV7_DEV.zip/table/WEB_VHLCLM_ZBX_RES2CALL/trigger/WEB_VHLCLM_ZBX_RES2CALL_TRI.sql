CREATE TRIGGER WEB_VHLCLM_ZBX_RES2CALL_TRI
BEFORE INSERT
  ON WEB_VHLCLM_ZBX_RES2CALL
FOR EACH ROW
  begin  
   if inserting then 
      if :NEW."C_ID" is null then 
         select WEB_VHLCLM_ZBX_RES2CALL_SEQ.nextval into :NEW."C_ID" from dual; 
      end if; 
   end if; 
end;
/
