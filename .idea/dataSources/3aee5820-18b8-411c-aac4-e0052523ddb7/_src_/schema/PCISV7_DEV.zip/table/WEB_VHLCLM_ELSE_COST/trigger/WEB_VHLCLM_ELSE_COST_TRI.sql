CREATE TRIGGER WEB_VHLCLM_ELSE_COST_TRI
BEFORE INSERT
  ON WEB_VHLCLM_ELSE_COST
FOR EACH ROW
  begin  
   if inserting then 
      if :NEW."C_ID" is null then 
         select WEB_VHLCLM_ELSE_COST_SEQ.nextval into :NEW."C_ID" from dual; 
      end if; 
   end if; 
end;
/
