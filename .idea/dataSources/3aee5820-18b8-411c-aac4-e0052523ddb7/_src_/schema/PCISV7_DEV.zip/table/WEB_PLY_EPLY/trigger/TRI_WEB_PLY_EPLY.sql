CREATE TRIGGER TRI_WEB_PLY_EPLY
BEFORE INSERT
  ON WEB_PLY_EPLY
FOR EACH ROW
  BEGIN
  IF INSERTING THEN
    --110测试、UAT测试环境，如果是青分，则不处理。如果不是青分的，则电子单证默认不发送短信！！！
    if substr(:NEW.c_dpt_cde,1,4) <> '1073' then
     :NEW.c_if_message :='0';
    end if;
  END IF;
END;
/
