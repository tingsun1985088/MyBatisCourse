CREATE TRIGGER COPY_IMG
AFTER DELETE
  ON WEB_PLY_IMG_IDX
FOR EACH ROW
  begin
  insert into WEB_PLY_IMG_IDX_COPY values
    (:old.C_IMG_ID,
     :old.C_APP_NO,
     :old.C_PLY_NO,
     :old.C_IMG_TYP,
     :old.C_IMG_FILE_NME,
     :old.C_IMG_DESC,
     :old.C_CRT_CDE,
     :old.T_CRT_TM,
     :old.C_UPD_CDE,
     :old.T_UPD_TM,
     :old.C_TRANS_MRK,
     :old.T_TRANS_TM,
     :old.C_APP_TYP,
     :old.T_ADB_TM,
     :old.C_REMARK,
     :old.C_CHECK_MRK,
     sysdate);
end;
/
