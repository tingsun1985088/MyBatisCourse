CREATE PACKAGE BODY "AUTO_CONFIRMED3" IS
--?????????????????(???????)?????

--1.???????????? Definite insurance premium income
--PROCEDURE premincome;--WPC

--2.?????????? Advance receipt insurance premium carry-over actual receipt insurance premium
PROCEDURE actualprem
IS
	v_dptacc_cde		T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;

	v_prod_no		WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_pre_sum 		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_edr_type 		WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
	v_edr_no		WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no		WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_rcpt_no		WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_bal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;


	v_cav_flag		WEB_FIN_DCR.c_cav_flag%TYPE;
	v_cnt			INT;
	v_tmpcnt		INT;
	v_sbjt_no		WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_sbjt_memo		WEB_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo		WEB_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo		WEB_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1		WEB_FIN_MADCR.c_seq_no%TYPE;

	vSbjtNo			WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag		WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_feetyp_cde		T_FIN_PAYDUE.c_feetyp_cde%TYPE;
	v_tran_flag		T_FIN_PAYDUE.c_tran_flag%TYPE;
	v_err_content	 	T_FIN_ERRORLOG.c_err_content%TYPE;
    	v_seq_no    		WEB_FIN_DCR.c_seq_no%TYPE;
    	v_item_no    		WEB_FIN_DCR.c_item_no%TYPE;

	vToday  		VARCHAR(10);
	vBillToday  		VARCHAR(10);
	v_servicetype_no	WEB_FIN_DCR.c_servicetype_no%TYPE;
	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_department_cde	WEB_FIN_DCR.c_department_cde%TYPE;
	v_company_cde		WEB_FIN_DCR.c_company_cde%TYPE;

	--??????
        CURSOR cur_ifPrmInfo IS
	SELECT c_dpt_cde,
		c_prod_no,
		c_ply_no,
		n_amt,
		c_rcpt_no,
		t_crt_tm,
		c_cav_flag,
		c_seq_no,
		c_item_no,
		c_dptacc_no
	FROM WEB_FIN_DCR
	WHERE c_sbjt_no='212101'
		AND c_prereal_flag<>'1'
		AND  EXISTS (SELECT c_rcpt_no FROM WEB_FIN_PRM_DUE
		WHERE      t_due_tm <= TRUNC(SYSDATE)
		AND c_rcpt_no=WEB_FIN_DCR.c_rcpt_no);

BEGIN

--?????????
	--??
	OPEN cur_ifPrmInfo;
	LOOP
	    FETCH cur_ifPrmInfo
	    INTO v_dpt_cde,
                                             v_prod_no,
                                             v_ply_no,
                                             v_pre_sum,
                                             v_rcpt_no,
                                             v_bal_tm,v_cav_flag,v_seq_no,v_item_no,v_dptacc_cde;
	    EXIT WHEN cur_ifPrmInfo%NOTFOUND;

		SELECT c_department_cde,c_company_cde
		INTO v_department_cde,v_company_cde
		FROM t_department
		WHERE c_dpt_cde=v_dpt_cde;

		IF v_cav_flag='?' THEN
			v_pre_sum:=v_pre_sum;
		ELSE
			v_pre_sum:=-v_pre_sum;
		END IF;

		v_vou_memo:='??????????';
		v_servicetype_no:='1001';

		--?????
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;

		SELECT t_due_tm
		INTO v_bal_tm
		FROM WEB_FIN_PRM_DUE
		WHERE c_rcpt_no=v_rcpt_no;

		IF TO_CHAR(v_bal_tm,'YYYY-MM-DD')<>TO_CHAR(SYSDATE-1,'YYYY-MM-DD')  THEN
			 v_bal_tm:=SYSDATE;
		END IF;


		IF TO_CHAR(v_bal_tm,'YYYY-MM-DD')< TO_CHAR(SYSDATE-1,'YYYY-MM-DD')  THEN
			 v_bal_tm:=SYSDATE;
		END IF;

		--v_bal_tm:=trunc(SYSDATE);

			INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
				C_CUR_NO ,T_CRT_TM ,
				C_DPTACC_NO ,C_DPT_CDE  ,C_RCPT_NO,
				C_SLS_CDE ,C_PROD_NO ,
				C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
				C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
				c_sbjt_memo,c_ply_no,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_servicetype_no,c_kind_no,
				c_department_cde,c_company_cde,c_period_name)
			SELECT vTmpVouNo,
			   '1',
			   '?',
			   '212101',
			   v_pre_sum,
			   c_bs_cur,
			   v_bal_tm,
			   v_dptacc_cde,
			   c_dpt_cde,
			   c_rcpt_no,
			   C_SLS_CDE,
			   C_PROD_NO,
			   C_CHA_CLS,
			   C_CHA_CDE,
			   C_SLSGRP_CDE,
			   C_PAYer_CDE,
			  NULL,
			  NULL,
			  NULL,
			  '0',
			   C_bsns_typ,
			   c_payer_nme,
			   v_sbjt_memo,
			   c_ply_no,c_cha_mrk,
			   v_vou_memo,c_con_dpt_cde,v_servicetype_no,v_kind_no,
			   v_department_cde,v_company_cde,TO_CHAR(v_bal_tm,'YYYY-MM')
			FROM WEB_FIN_PRM_DUE
			WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no))
			and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);
			--AND c_prod_no NOT IN  ('0001','0002','0003');




			INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
				C_CUR_NO ,T_CRT_TM ,
				C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
				C_SLS_CDE ,C_PROD_NO ,
				C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
				C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
				c_ply_no,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_servicetype_no,c_kind_no,
				c_department_cde,c_company_cde,c_period_name,c_sbjt_memo)
			SELECT vTmpVouNo,
			    '2',
			    '?',
			    '112201',
			    v_pre_sum,
			    c_bs_cur,
			    v_bal_tm,
			    v_dptacc_cde,
			    c_dpt_cde,
			    c_rcpt_no,
			    C_SLS_CDE,
			    C_PROD_NO,
			    C_CHA_CLS,
			    C_CHA_CDE,
			    C_SLSGRP_CDE,
			    C_PAYer_CDE,
			   NULL,
			   NULL,
			   NULL,
			   '0',
			    C_bsns_typ,
			    c_payer_nme,
			    c_ply_no,
			    c_cha_mrk,
			    v_vou_memo,c_con_dpt_cde,v_servicetype_no,v_kind_no,
			    v_department_cde,v_company_cde,TO_CHAR(v_bal_tm,'YYYY-MM'),'0'
			FROM WEB_FIN_PRM_DUE
			WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no))
			--AND c_prod_no NOT IN  ('0001','0002','0003');
			and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);





			/*????*/
			UPDATE WEB_FIN_DCR
				SET c_prereal_flag='1'
				WHERE  c_seq_no = v_seq_no AND c_item_no=v_item_no;
			COMMIT;

	END LOOP;
	CLOSE cur_ifPrmInfo;



EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		ROLLBACK;
		dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);
		v_err_content:='proc:[actualprem],??????['||v_rcpt_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;


	END;
END;


--3.????? Handling charge disbursement
PROCEDURE handlingcharge
IS
 	/*
 	??????? 443101
		??????? 211101
	*/

	--????
	v_dptacc_cde	T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;

	v_prod_no		T_FIN_PAYDUE.c_prod_no%TYPE;
	v_get_prm  		T_FIN_PAYDUE.n_pay_amt%TYPE;
	v_dr_amt  		T_FIN_PAYDUE.n_pay_amt%TYPE;
	v_cr_amt  		T_FIN_PAYDUE.n_pay_amt%TYPE;
	v_na_prm  		T_FIN_PAYDUE.n_pay_amt%TYPE;	--????
	v_edr_no		T_FIN_PAYDUE.c_edr_no%TYPE;
	v_clm_no		T_FIN_PAYDUE.c_clm_no%TYPE;
	v_bal_tm		T_FIN_PAYDUE.t_bal_tm%TYPE;	--????
	v_ply_no		T_FIN_PAYDUE.c_ply_no%TYPE;

	v_vou_memo		T_FIN_MADCR.c_vou_memo%TYPE;
	v_tran_flag		T_FIN_PAYDUE.c_tran_flag%TYPE;
	v_servicetype_no	WEB_FIN_DCR.c_servicetype_no%TYPE;

	v_cmmcnt		INT;
	v_cnt			INT;
	v_tmpcnt		INT;
	vTmpVouNo		WEB_FIN_DCR.c_seq_no%TYPE;
	v_sbjt_memo		WEB_FIN_DCR.c_sbjt_memo%TYPE;
	v_feetyp_cde	T_FIN_PAYDUE.c_feetyp_cde%TYPE;

	v_drsbjt_no			WEB_FIN_DCR.c_sbjt_no%TYPE;  --shaosheng
	v_drcav_flag		WEB_FIN_DCR.C_CAV_FLAG%TYPE; --shaosheng
	v_crcav_flag		WEB_FIN_DCR.c_cav_flag%TYPE;


	v_ri_com 		VARCHAR2(4);/*???*/
	v_cont_code		VARCHAR2(2);/*????*/
	V_BILLCODE		VARCHAR2(25);/*???*/
	v_INTERNAL_MARK 	CHAR(1);/*??/??*/
	v_arp_flag		CHAR(1);
	v_con_dpt_cde		WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
	v_main_con_flag		WEB_FIN_PRM_DUE.c_main_con_cde%TYPE;
	v_err_content	T_FIN_ERRORLOG.c_err_content%TYPE;
	v_crsbjt_no		T_FIN_MADCR.c_sbjt_no%TYPE;
	v_rcpt_no		WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_kind_no	t_fin_prod.c_prod_no%TYPE;

	v_department_cde	WEB_FIN_DCR.c_department_cde%TYPE;
	v_company_cde		WEB_FIN_DCR.c_company_cde%TYPE;
	--??????
        CURSOR cur_ifnotcmmInfo IS
	SELECT c_rcpt_no,c_dpt_cde,c_prod_no,n_pay_amt,c_edr_no,t_bal_tm,
			c_ply_no,c_feetyp_cde,c_tran_flag,NVL(LENGTH(c_clm_no),0),c_arp_flag,
			c_main_con_flag,c_con_dpt_cde,c_clm_no
	FROM T_FIN_PAYDUE
	     WHERE c_accnt_flag IN ('00','10')
	     AND c_feetyp_cde='S' --AND n_pay_amt>0
	     AND t_bal_tm  >= sysdate -30
	     --AND c_prod_no NOT IN  ('0001','0002','0003')
	     ;	--???

	     --????????????????????????????????????????
	     --?????????
BEGIN

        /*
        ??????????????????????????????
        */
	--??????
	OPEN cur_ifnotcmmInfo;
	LOOP
	    FETCH cur_ifnotcmmInfo
	    INTO	v_rcpt_no,v_dpt_cde,v_prod_no,v_get_prm,v_edr_no,v_bal_tm,
			v_ply_no,v_feetyp_cde,v_tran_flag,v_cmmcnt,v_arp_flag,
			v_main_con_flag,v_con_dpt_cde,v_clm_no;

	    EXIT WHEN cur_ifnotcmmInfo%NOTFOUND;

	--????????
		SELECT  c_dptacc_cde,c_department_cde,c_company_cde
			INTO v_dptacc_cde,v_department_cde,v_company_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde =trim(v_dpt_cde);

		--???????
		--IF v_tran_flag='2' THEN
		--	;
		--END IF;


		--?????
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);


		v_dr_amt:=v_get_prm;
		v_cr_amt:=v_get_prm;
		v_drcav_flag:='?';
		v_crcav_flag:='?';

		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;



		IF v_clm_no IS NULL  OR v_clm_no=' ' THEN		--?????,????
			--???????443101
			--	??????? 211101
				--IF v_get_prm >0 THEN
					v_drsbjt_no:='443101';--?????
					v_crsbjt_no := '211101';--?????
					v_servicetype_no:='1007';
					v_vou_memo:='???????';
				--END IF;


		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
		SELECT 	vTmpVouNo,'1' ,v_drcav_flag ,v_drsbjt_no ,v_dr_amt ,
			c_cur_cde ,TRUNC(t_bal_tm) ,
			v_dptacc_cde ,c_dpt_cde ,c_rcpt_no,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,C_PAY_PRSN_CDE ,NULL,
			NULL ,NULL ,'0',C_bsns_typ,c_pay_name,
			v_sbjt_memo,c_cha_mrk,v_vou_memo,c_ply_no,v_con_dpt_cde,
			v_servicetype_no,v_kind_no,v_department_cde,v_company_cde
		FROM 	T_FIN_PAYDUE
		WHERE c_rcpt_no=trim(v_rcpt_no);

		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
		SELECT 	vTmpVouNo,'2' ,v_crcav_flag ,v_crsbjt_no ,v_cr_amt ,
			C_CUR_NO ,TRUNC(T_CRT_TM) ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,'0',C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			c_servicetype_no,v_kind_no,v_department_cde,v_company_cde
		FROM 	T_FIN_MADCR
		WHERE c_seq_no=trim(vTmpVouNo) AND c_item_no='1';

		UPDATE WEB_FIN_PAY_DUE
			SET c_accnt_flag=DECODE(c_accnt_flag,'10','11','00','01','00')
			WHERE c_rcpt_NO=v_rcpt_no;
		END IF;

		commit;
	END LOOP;
	CLOSE cur_ifnotcmmInfo;
	COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
--		----RAISE;
--		dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[handlingcharge],??????['||v_rcpt_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;
	END;


END;

--4.??????
PROCEDURE clmcharge
IS
	/*????????? */

	--????
	v_rcpt_no		WEB_FIN_CLM_DUE.c_rcpt_no%TYPE;


	--????
	v_dptacc_cde	T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;
	v_prod_no		WEB_FIN_CLM_DUE.c_prod_no%TYPE;
	v_get_prm  		WEB_FIN_CLM_DUE.n_bs_amt%TYPE;
	v_dr_amt  		WEB_FIN_CLM_DUE.n_bs_amt%TYPE;
	v_cr_amt  		WEB_FIN_CLM_DUE.n_bs_amt%TYPE;
	v_drcav_flag		WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_crcav_flag		WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_na_prm  		WEB_FIN_CLM_DUE.n_bs_amt%TYPE;	--????
	v_ply_no		WEB_FIN_CLM_DUE.c_ply_no%TYPE;
	v_pay_amt		WEB_FIN_CLM_DUE.n_bs_amt%TYPE;	--????
	v_cnt			INT;
	v_tmpcnt		INT;
	vTmpVouNo		WEB_FIN_MADCR.c_seq_no%TYPE;
	v_sbjt_memo		WEB_FIN_MADCR.c_sbjt_memo%TYPE;
	vSbjtNo			WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_feetyp_cde		WEB_FIN_CLM_DUE.c_feetyp_cde%TYPE;
	v_tran_flag		WEB_FIN_CLM_DUE.c_tran_flag%TYPE;
	v_con_dpt_cde	WEB_FIN_CLM_DUE.c_con_dpt_cde%TYPE;
	v_main_con_flag	WEB_FIN_CLM_DUE.c_main_con_cde%TYPE;

	v_vou_memo		WEB_FIN_DCR.c_vou_memo%TYPE;


	v_ri_com 		VARCHAR2(4);/*???*/
	v_cont_code		VARCHAR2(2);/*????*/
	v_billcode		VARCHAR2(25);/*???*/
	v_internal_mark CHAR(1);/*??/??*/
	v_arp_flag		CHAR(1);
	v_err_content	T_FIN_ERRORLOG.c_err_content%TYPE;
	v_eac_dcm_mrk	WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
	v_clm_no	WEB_FIN_CLM_DUE.c_clm_no%TYPE;
	v_total_preamt	WEB_FIN_CLM_DUE.n_bs_amt%TYPE;
	v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_department_cde	WEB_FIN_DCR.c_department_cde%TYPE;
	v_company_cde		WEB_FIN_DCR.c_company_cde%TYPE;
	v_pretyp_cde	WEB_FIN_CLM_DUE.c_pretyp_cde%TYPE;

	CURSOR cur_ifclmInfo IS
	SELECT c_rcpt_no
		FROM WEB_FIN_CLM_DUE
		WHERE c_accnt_flag IN ('00','10')
		--AND t_crt_tm  >= TO_DATE('2007-05-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
		 AND t_crt_tm  >= sysdate -30
			AND c_eac_dcm_mrk='2';/*1?????2???3 ??? 4??*/
BEGIN

	OPEN cur_ifclmInfo;
	LOOP
	    FETCH cur_ifclmInfo
	    INTO v_rcpt_no;
	    EXIT WHEN cur_ifclmInfo%NOTFOUND;

	--???????
		--??????
		SELECT c_dpt_cde,c_prod_no,n_bs_amt,c_ply_no,c_feetyp_cde,
			c_arp_flag,c_tran_flag,c_con_dpt_cde,
			c_main_con_cde,c_eac_dcm_mrk,c_clm_no
			INTO v_dpt_cde,v_prod_no,v_get_prm,v_ply_no,v_feetyp_cde,
			v_arp_flag,v_tran_flag,v_con_dpt_cde,
			v_main_con_flag,v_eac_dcm_mrk,v_clm_no
			FROM WEB_FIN_CLM_DUE
			WHERE c_rcpt_no=v_rcpt_no ;

		SELECT SUM(n_bs_amt)
		INTO v_total_preamt
		FROM WEB_FIN_CLM_DUE
		WHERE c_clm_no=v_clm_no
			AND c_eac_dcm_mrk IN ('1','5')
			AND (c_feetyp_cde IS NULL  OR c_feetyp_cde=' ' )
			AND (c_rollback_mark IS NULL OR c_rollback_mark <>'X');

		SELECT  c_dptacc_cde,c_department_cde,c_company_cde
			INTO v_dptacc_cde,v_department_cde,v_company_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde =trim(v_dpt_cde);

		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;


	--?????? 440101
	--?????? 215001

		v_cr_amt:=v_get_prm;
		v_dr_amt:=v_get_prm;

	IF v_feetyp_cde IS NULL OR 	v_feetyp_cde =' ' THEN
		v_vou_memo:='??????';
		v_servicetype_no:='1009';
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);

		 --/*?:????,?:????*/
		vSbjtNo := '440101';
		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
		SELECT 	vTmpVouNo,'1' ,'?' ,vSbjtNo ,v_dr_amt ,
			c_BS_cur ,TRUNC(t_crt_tm) ,
			v_dptacc_cde ,c_dpt_cde ,v_rcpt_no,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SLSGRP_CDE ,c_insrnt_cde ,NULL,
			NULL ,NULL ,'0',C_bsns_typ,c_payer_nme,
			v_sbjt_memo,c_cha_mrk,v_vou_memo,c_ply_no,c_con_dpt_cde,
			v_servicetype_no,v_kind_no,v_department_cde,v_company_cde
		FROM 	WEB_FIN_CLM_DUE
		WHERE c_rcpt_no=v_rcpt_no;

		vSbjtNo := '215001';
		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
		SELECT 	C_SEQ_NO ,'2' ,'?' ,vSbjtNo ,v_cr_amt ,
			C_CUR_NO ,TRUNC(T_CRT_TM) ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,'0',C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			v_servicetype_no,v_kind_no,v_department_cde,v_company_cde
		FROM WEB_FIN_MADCR
		WHERE c_seq_no=vTmpVouNo AND c_item_no='1';


		IF v_total_preamt<> 0  OR v_total_preamt IS NOT NULL THEN --/*?:????,?:????*/
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);
			vSbjtNo := '440101';
			v_vou_memo:='??????????';
			v_servicetype_no:='1010';

			INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
				C_CUR_NO ,T_CRT_TM ,
				C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
				C_SLS_CDE ,C_PROD_NO ,
				C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
				C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
				c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
				c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
			SELECT 	vTmpVouNo,'1' ,'?' ,vSbjtNo ,v_total_preamt ,
				c_BS_cur ,TRUNC(t_crt_tm) ,
				v_dptacc_cde ,c_dpt_cde ,v_rcpt_no,
				C_SLS_CDE ,C_PROD_NO ,
				C_CHA_CLS ,C_CHA_CDE ,C_SLSGRP_CDE ,c_insrnt_cde ,NULL,
				NULL ,NULL ,'0',C_bsns_typ,c_payER_nme,
				v_sbjt_memo,c_cha_mrk,v_vou_memo,c_ply_no,c_con_dpt_cde,
				v_servicetype_no,v_kind_no,v_department_cde,v_company_cde
			FROM 	WEB_FIN_CLM_DUE
			WHERE c_rcpt_no=v_rcpt_no;

			vSbjtNo := '113101';

			SELECT NVL(c_pretyp_cde,'0')
			INTO v_pretyp_cde
				FROM WEB_FIN_CLM_DUE
				WHERE c_rcpt_no=v_rcpt_no;

			IF v_pretyp_cde='0' THEN
				v_vou_memo:='??????????';
				v_servicetype_no:='1010';
				vSbjtNo := '113101';
			ELSIF v_pretyp_cde='1' THEN
				v_vou_memo:='??????????';
				v_servicetype_no:='1010';
				vSbjtNo := '113101';
			ELSIF v_pretyp_cde='2' THEN
				v_vou_memo:='??????????????';
				v_servicetype_no:='1150';
				vSbjtNo := '113102';
			ELSIF v_pretyp_cde='3' THEN
				v_vou_memo:='??????????????';
				v_servicetype_no:='1151';
				vSbjtNo := '113103';
			ELSIF v_pretyp_cde='4' THEN
				v_vou_memo:='???????????????';
				v_servicetype_no:='1149';
				vSbjtNo := '113104';
			END IF;


			/*
		113101????/????
		113102????/????
		113103????/????
		113104????/????

			*/

			INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
				C_CUR_NO ,T_CRT_TM ,
				C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
				C_SLS_CDE ,C_PROD_NO ,
				C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
				C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
				c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
				c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
			SELECT  vTmpVouNo,'2' ,'?' ,vSbjtNo ,v_total_preamt ,
				C_CUR_NO ,TRUNC(T_CRT_TM) ,
				C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
				C_SLS_CDE ,C_PROD_NO ,
				C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
				C_CONT_CODE ,C_VOU_NO ,'0',C_bsns_typ,C_pay_prsn_name,
				c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
				v_servicetype_no,v_kind_no,v_department_cde,v_company_cde
			FROM WEB_FIN_MADCR
			WHERE c_seq_no=vTmpVouNo AND c_item_no='1';

			UPDATE WEB_FIN_CLM_DUE
				SET c_rollback_mark='X'
				WHERE c_clm_no=v_clm_no AND c_eac_dcm_mrk IN ('1','5')
				AND c_feetyp_cde IS NULL
				AND (c_rollback_mark IS NULL OR c_rollback_mark <>'X');
		END IF;
	ELSE --????
		/*
			--?????????? 440103

			--????,????
			v_drsbjt_no:='440102';--????\??????440101
			v_crsbjt_no := '215002';--215001	?????\?????
		*/

		v_vou_memo:='?????';
		v_servicetype_no:='1011';
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);

		 --/*?:????,?:????*/
		vSbjtNo := '440102';
		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
		SELECT 	vTmpVouNo,'1' ,'?' ,vSbjtNo ,v_dr_amt ,
			c_BS_cur ,TRUNC(t_crt_tm) ,
			v_dptacc_cde ,c_dpt_cde ,v_rcpt_no,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SLSGRP_CDE ,c_insrnt_cde ,NULL,
			NULL ,NULL ,'0',C_bsns_typ,c_payER_nme,
			v_sbjt_memo,c_cha_mrk,v_vou_memo,c_ply_no,c_con_dpt_cde,
			v_servicetype_no,v_kind_no,v_department_cde,v_company_cde
		FROM 	WEB_FIN_CLM_DUE
		WHERE c_rcpt_no=v_rcpt_no;

		vSbjtNo := '215002';
		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			c_servicetype_no,c_kind_no,c_department_cde,c_company_cde)
		SELECT 	C_SEQ_NO ,'2' ,'?' ,vSbjtNo ,v_cr_amt ,
			C_CUR_NO ,TRUNC(T_CRT_TM) ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,'0',C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_cha_mrk,c_vou_memo,c_ply_no,c_con_dpt_cde,
			v_servicetype_no,v_kind_no,v_department_cde,v_company_cde
		FROM WEB_FIN_MADCR
		WHERE c_seq_no=vTmpVouNo AND c_item_no='1';



	END IF;
		UPDATE WEB_FIN_CLM_DUE
		SET c_accnt_flag=DECODE(c_accnt_flag,'10','11','00','01','00')
		WHERE c_rcpt_no=v_rcpt_no;

		commit;

	END LOOP;
	CLOSE cur_ifclmInfo;

	COMMIT;


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		ROLLBACK;

		v_err_content:='proc:[clmcharge],??????['||v_rcpt_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;
	END;

END;

--5.??
PROCEDURE gather
IS
	/*???????????,??????????????????*/
	/*?????*/
	v_drsbjt_no            WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_sbjt_no              WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_tmpsbjt_no           VARCHAR(20);

	v_dpt_cde              WEB_FIN_MADCR.c_dpt_cde%TYPE;
	v_dptacc_cde           WEB_FIN_MADCR.c_dptacc_no%TYPE;
	v_prod_no              WEB_FIN_MADCR.c_prod_no%TYPE;
	v_cur_no               WEB_FIN_MADCR_INTF.c_cur_no%TYPE;
	v_drcav_flag           WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_crcav_flag           WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_dramt                WEB_FIN_MADCR.n_amt%TYPE;
	v_cramt                WEB_FIN_MADCR.n_amt%TYPE;
	v_amt                  WEB_FIN_MADCR.n_amt%TYPE;
	v_vou_memo             VARCHAR(200);
	vTmpVouNo              VARCHAR(30);
	v_crt_tm               WEB_FIN_MADCR.t_crt_tm%TYPE;

	v_salegrp_cde           WEB_FIN_MADCR.c_salegrp_cde%TYPE;
	v_bsns_typ              WEB_FIN_MADCR.c_bsns_typ%TYPE;
	v_cha_mrk               WEB_FIN_MADCR.c_cha_mrk%TYPE;
	v_con_dpt_cde		WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
	--????????????  ORACLE?????????
	v_company_cde T_DEPARTMENT.c_company_cde%TYPE;
	v_department_cde T_DEPARTMENT.c_department_cde%TYPE;
	v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;

	v_err_content	 	WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
	v_makevou			VARCHAR2(1);
	v_check_flag		WEB_FIN_DCR.c_check_flag%TYPE;
	v_voucher_no		WEB_FIN_MADCR.c_voucher_no%TYPE;

	v_sbjt_memo	web_fin_dcr_intf.c_sbjt_memo%TYPE;
	v_period_name	web_fin_dcr_intf.c_period_name%TYPE;

	v_succsflag	INT;
	v_ri_com	web_fin_dcr_intf.c_ri_com%TYPE;
	v_total_amt	WEB_FIN_MADCR.n_total_amt%TYPE;
	v_ncompany	INT;
	v_nri		INT;

	v_voucompany_cde WEB_FIN_MADCR.c_company_cde%TYPE;
	v_voudepartment_cde WEB_FIN_MADCR.c_department_cde%TYPE;
	v_voudpt_cde	WEB_FIN_MADCR.c_dpt_cde%TYPE;
	v_voudptacc_cde	WEB_FIN_MADCR.c_dpt_cde%TYPE;
	l_bool     	boolean;

	CURSOR cur_ifgDetailma IS
	SELECT c_dpt_cde,c_kind_no,c_cur_no,SUM(n_amt)/2,TRUNC(t_crt_tm),c_servicetype_no
		FROM WEB_FIN_MADCR
		WHERE 	c_vou_no IS NULL
			AND  t_crt_tm < TRUNC(SYSDATE)
			and t_crt_tm >sysdate -30
			AND c_ri_com IS NULL
			AND c_servicetype_no NOT IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004','1127','1148','1133', '1135','1152','1129','1131','1101','1429','1431')
		GROUP BY c_dpt_cde,c_kind_no,c_cur_no,TRUNC(t_crt_tm) ,c_servicetype_no;

	CURSOR cur_ifriDetailma IS
	SELECT c_dpt_cde,c_kind_no,c_cur_no,SUM(n_amt)/2,TRUNC(t_crt_tm) ,c_servicetype_no,c_ri_com
		FROM WEB_FIN_MADCR
		WHERE 	c_vou_no IS NULL
			AND  t_crt_tm < TRUNC(SYSDATE)
			and t_crt_tm >sysdate -30
			AND c_ri_com IS NOT NULL
			AND c_servicetype_no NOT IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004','1127','1148','1133', '1135','1152','1129','1131','1101','1429','1431')
		GROUP BY c_dpt_cde,c_kind_no,c_cur_no,TRUNC(t_crt_tm) ,c_servicetype_no,c_ri_com;

        CURSOR cur_updgather IS
		SELECT  c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no
			FROM WEB_FIN_MADCR_INTF
			WHERE c_vou_no IS NULL
			and t_crt_tm >sysdate -30
			and  not  (c_servicetype_no='1007' AND c_prod_no  like '014%')
			--AND c_prod_no<>'014'
			--AND c_prod_no not like '00%'
			AND c_servicetype_no NOT IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004','1127','1148','1133', '1135','1152','1129','1131','1101','1429','1431')
			GROUP BY c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no;

        CURSOR cur_saveupdgather IS
		SELECT  c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no
			FROM WEB_FIN_MADCR_INTF
			WHERE c_vou_no IS NULL
			and t_crt_tm >sysdate -30
			and  (c_servicetype_no='1007' AND c_prod_no  like '014%')
			AND c_servicetype_no NOT IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004','1127','1148','1133', '1135','1152','1129','1131','1101','1429','1431')
			GROUP BY c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no;

	BEGIN

	OPEN cur_ifgDetailma;
	LOOP
	FETCH cur_ifgDetailma
	INTO
		v_dpt_cde,v_prod_no,v_cur_no,v_amt,v_crt_tm,v_servicetype_no;
	EXIT WHEN cur_ifgDetailma%NOTFOUND;

	--?????
	--Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
	--??????????
	--???????/????/????
	--select  TO_CHAR(123,'0000') from dual;
	--?????7??+?????2??+?/??4??+??????4?)
	--????
	--??????,???????/????/????
	SELECT COUNT(*)
		INTO v_ncompany
		FROM T_DEPARTMENT
		WHERE c_dpt_cde=trim(v_dpt_cde);





		/*
		?????? 1000
			??????	112201
			??????	410101

		?????? 1123
			????????-??????	122203
			???????\??	410205

		?????????? 1001
			????????????	212101
			??????	112201

		?????? 1009
			???????????	440101
			??????	215001

		????? 1011
			??????????	440102
			???????????	215001

		?????????? 1010
			??????	440101
			??????	113101

		??????? 1007
			???????	443101
			???????	211101

		5.1???????
		5.1?????
		?1??????????????????
		?????????????-?????? 122401 	1127 ???????????
			???????????-IBNR 122402  	1148 ????????????????
		???????????-?????? 421101
			?????????- IBNR 421102


		?2??????????????????
		???????????-?????? 450101 	1133 ?????????
			?????????-IBNR 450102 		1135 ????????????
			?????????-???? 450103 	1152 ?????????
		?????????-???????????????  216101
			???????-IBNR	216102
			???????-????  216103


		122401,???????????/???????????
		122402,???????????/IBNR
		122403,???????????/????

		450101,?????????/???
		450102,?????????/IBNR
		450103,?????????/????

		421101,?????????/??????
		421102,?????????/??????
		421103,?????????/????

		216101,???????/???
		216102,???????/IBNR
		216103,???????/???????

			v_drsbjt_no:='119113';
			v_crsbjt_no:='214614';
			v_vou_memo:='?????????';
			v_servicetype_no:='5000';
		*/

		v_drcav_flag:='?';
		v_crcav_flag:='?';
		v_dramt:=v_amt;
		v_cramt:=v_amt;
		v_makevou:='Y';

		IF v_servicetype_no='1000' THEN
		--IF v_vou_memo='??????' THEN
			v_vou_memo:='??????';
			v_drsbjt_no:='112201';
			v_sbjt_no:='410101';
		ELSIF v_servicetype_no='5000' THEN
		--IF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='119113';
			v_sbjt_no:='214614';

		ELSIF v_servicetype_no='1123' THEN
		--ELSIF v_vou_memo='??????' THEN
			v_drsbjt_no:='122203';
			v_sbjt_no:='410205';
			v_vou_memo:='??????';
		ELSIF v_servicetype_no='1001' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='212101';
			v_sbjt_no:='112201';
		ELSIF v_servicetype_no='1009' THEN
		--ELSIF v_vou_memo='??????' THEN
			v_vou_memo:='??????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='215001';
		ELSIF v_servicetype_no='1011' THEN
		--ELSIF v_vou_memo='?????' THEN
			v_vou_memo:='?????';
			v_drsbjt_no:='440102';
			v_sbjt_no:='215002';
		ELSIF v_servicetype_no='1010' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113101';
		ELSIF v_servicetype_no='1150' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113102';
		ELSIF v_servicetype_no='1151' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113103';
		ELSIF v_servicetype_no='1149' THEN
			v_vou_memo:='???????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113104';
		ELSIF v_servicetype_no='1007' THEN
		--ELSIF v_vou_memo='???????' THEN
			v_vou_memo:='???????';
			v_drsbjt_no:='443101';
			v_sbjt_no:='211101';
		ELSIF v_servicetype_no='1101' THEN
		--ELSIF v_vou_memo='????' THEN
			v_vou_memo:='????';
			v_drsbjt_no:='446106';
			v_sbjt_no:='214401';

		ELSIF v_servicetype_no='1127' THEN
		--ELSIF v_vou_memo='???????????' THEN
			v_vou_memo:='???????????';
			v_drsbjt_no:='122401';
			v_sbjt_no:='421101';
		ELSIF v_servicetype_no='1148' THEN
		--ELSIF v_vou_memo='????????????????' THEN
			v_vou_memo:='????????????????';
			v_drsbjt_no:='122402';
			v_sbjt_no:='421102';
		ELSIF v_servicetype_no='1133' THEN
		--ELSIF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='450101';
			v_sbjt_no:='216101';
		ELSIF v_servicetype_no='1135' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='450102';
			v_sbjt_no:='216102';
		ELSIF v_servicetype_no='1152' THEN
		--ELSIF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='450103';
			v_sbjt_no:='216103';

		ELSIF v_servicetype_no='1129' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='122301';
			v_sbjt_no:='450201';
		ELSIF v_servicetype_no='1131' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='450201';
			v_sbjt_no:='216201';

		ELSIF v_servicetype_no='1429' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='122302';
			v_sbjt_no:='450202';
		ELSIF v_servicetype_no='1431' THEN
		--ELSIF v_vou_memo='??????????????' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='450202';
			v_sbjt_no:='216202';

		ELSE
			v_makevou:='N';
		END IF;


		IF  v_ncompany =0 THEN
			v_err_content:='proc:[gather1],??????['||v_dpt_cde||SQLCODE||SQLERRM;

			INSERT INTO WEB_BAS_FIN_ERRORLOG
			(
				c_err_no,
				c_errtype_no,
				c_tran_type,
				c_err_content,
				t_crt_tm
			)
			VALUES(
				F_Fin_Getcode('e'),
				'001',	--??????
				'0000',	--??????
				v_err_content,
				SYSDATE
			);

		END IF;

		IF v_makevou='Y' AND v_ncompany >0 THEN
			SELECT c_company_cde,c_dptacc_cde,c_department_cde
				INTO v_company_cde,v_dptacc_cde,v_department_cde
				FROM T_DEPARTMENT
				WHERE c_dpt_cde=trim(v_dpt_cde);

			SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;

			v_salegrp_cde:='000';
			v_bsns_typ:='0';
			v_cha_mrk:='0';
			v_check_flag:='2';
			v_crt_tm:=TRUNC(v_crt_tm);
			BEGIN
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);



				INSERT INTO WEB_FIN_MADCR_INTF(
					c_seq_no,
					c_item_no,
					c_cav_flag,
					c_sbjt_no,
					n_amt,
					c_cur_no,
					t_crt_tm,
					c_dptacc_no,
					c_dpt_cde,
					c_prod_no,
					c_vou_memo,
					c_send_flag,
					c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
					c_servicetype_no
					)
				VALUES(
					vTmpVouNo,
					'1',
					v_drcav_flag,
					v_drsbjt_no,
					v_dramt,
					v_cur_no,
					TRUNC(v_crt_tm),
					v_dptacc_cde,
					v_dpt_cde,
					v_prod_no,
					v_vou_memo,
					'0',
					v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,
					v_servicetype_no
				);



				INSERT INTO WEB_FIN_MADCR_INTF(
					c_seq_no,
					c_item_no,
					c_cav_flag,
					c_sbjt_no,
					n_amt,
					c_cur_no,
					t_crt_tm,
					c_dptacc_no,
					c_dpt_cde,
					c_prod_no,
					c_vou_memo,
					c_send_flag,
					c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
					c_servicetype_no
					)
				VALUES(
					vTmpVouNo,
					'2',
					v_crcav_flag,
					v_sbjt_no,
					v_cramt,
					v_cur_no,
					TRUNC(v_crt_tm),
					v_dptacc_cde,
					v_dpt_cde,
					v_prod_no,
					v_vou_memo,
					'0',
					v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,v_servicetype_no
				);


				/*??????*/

				UPDATE WEB_FIN_MADCR
					SET c_vou_no=vTmpVouNo
					WHERE  c_dpt_cde=v_dpt_cde
						AND c_kind_no=v_prod_no
						AND c_cur_no=v_cur_no
						AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
						AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
						AND c_servicetype_no=v_servicetype_no
						AND c_vou_no IS NULL
						AND c_ri_com IS NULL
						AND c_rcpt_no IS NOT NULL;


				--????????????
				SELECT SUM(n_amt)/2
				INTO v_total_amt
					FROM WEB_FIN_MADCR_INTF
					WHERE c_seq_no=vTmpVouNo;

				UPDATE WEB_FIN_MADCR
					SET c_company_cde=v_company_cde,
					c_period_name=v_period_name,
					n_total_amt=v_total_amt
					WHERE c_vou_no=vTmpVouNo;


				UPDATE WEB_FIN_MADCR_INTF
					SET
					c_company_cde=v_company_cde,
					c_department_cde=v_department_cde,
					c_period_name=v_period_name,
					t_end_tm=SYSDATE,
					n_total_amt=v_total_amt,
					c_cur_no=DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no),
					c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),
					c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
					c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ)
					WHERE c_seq_no=vTmpVouNo;

			END;
			END IF;
			commit;

		END LOOP;
		CLOSE cur_ifgDetailma;


	OPEN cur_ifriDetailma;
	LOOP
	FETCH cur_ifriDetailma
	INTO v_dpt_cde,v_prod_no,v_cur_no,v_amt,v_crt_tm,v_servicetype_no,v_ri_com;
	EXIT WHEN cur_ifriDetailma%NOTFOUND;

	--?????
	--Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
	--??????????
	--???????/????/????
	--select  TO_CHAR(123,'0000') from dual;
	--?????7??+?????2??+?/??4??+??????4?)
	--????
	--??????,???????/????/????

	SELECT COUNT(*)
		INTO v_ncompany
		FROM T_DEPARTMENT
		WHERE c_dpt_cde=trim(v_dpt_cde);

	SELECT COUNT(*)
		INTO v_nri
		FROM t_fin_ri
		WHERE c_ri_com=v_ri_com;

	IF v_nri>0 AND v_ncompany >0 THEN
		SELECT c_company_cde,c_dptacc_cde,c_department_cde
			INTO v_company_cde,v_dptacc_cde,v_department_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde=trim(v_dpt_cde);

		SELECT c_finri_com
			INTO v_sbjt_memo
			FROM t_fin_ri
			WHERE c_ri_com=v_ri_com;

		SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;

			v_drcav_flag:='?';
			v_crcav_flag:='?';
			v_dramt:=v_amt;
			v_cramt:=v_amt;
			v_makevou:='Y';



			IF v_servicetype_no='1116' THEN
			--ELSIF v_vou_memo='??????' THEN
				v_vou_memo:='??????';
				v_drsbjt_no:='442101';
				v_sbjt_no:='211301';
			ELSIF v_servicetype_no='1117' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122201';
				v_sbjt_no:='420301';

			ELSIF v_servicetype_no='1118' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122202';
				v_sbjt_no:='420101';

			--ELSIF v_servicetype_no='1119' THEN
			--ELSIF v_vou_memo='????????' THEN

			ELSIF v_servicetype_no='1121' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122204';
				v_sbjt_no:='213101';

			ELSIF v_servicetype_no='1122' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='446104';
				v_sbjt_no:='211304';



			ELSIF v_servicetype_no='3000' THEN
			--ELSIF v_vou_memo='????????' THEN
				v_vou_memo:='????????';
				v_drsbjt_no:='211301';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='3001' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='211304';
				v_sbjt_no:='119603';

			ELSIF v_servicetype_no='4000' THEN
			--ELSIF v_vou_memo='????????' THEN
				v_vou_memo:='????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='211301';
			ELSIF v_servicetype_no='4001' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='211304';

			ELSIF v_servicetype_no='3002' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122201';
			ELSIF v_servicetype_no='3003' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122202';
			ELSIF v_servicetype_no='3004' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122204';


			ELSIF v_servicetype_no='4002' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122201';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='4003' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122202';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='4004' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122204';
				v_sbjt_no:='119603';

/*

	?????????????????
		??????????????????211301
		???????\???????? 119603?

	?????????????????
		???????\????????? 119603
		?????????????????211301

	------------------------------------------------------
	??????????????????????????
	???????\???????????? 119603
	?????????????122201  ?122202

	??????????????????????????
	?????????????122201
			 ???????\?????????119603



	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3000','?????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3001','?????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3002','??????????????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3003','??????????????????????????');

	3000,?????????????????
	3001,?????????????????
	3002,??????????????????????????
	3003,??????????????????????????
*/

			ELSIF v_servicetype_no='1127' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122401';
				v_sbjt_no:='421101';
			ELSIF v_servicetype_no='1148' THEN
			--ELSIF v_vou_memo='????????????????' THEN
				v_vou_memo:='????????????????';
				v_drsbjt_no:='122402';
				v_sbjt_no:='421102';
			ELSIF v_servicetype_no='1133' THEN
			--ELSIF v_vou_memo='?????????' THEN
				v_vou_memo:='?????????';
				v_drsbjt_no:='450101';
				v_sbjt_no:='216101';
			ELSIF v_servicetype_no='1135' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='450102';
				v_sbjt_no:='216102';
			ELSIF v_servicetype_no='1152' THEN
			--ELSIF v_vou_memo='?????????' THEN
				v_vou_memo:='?????????';
				v_drsbjt_no:='450103';
				v_sbjt_no:='421103';

			ELSIF v_servicetype_no='1129' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='122301';
				v_sbjt_no:='450201';
			ELSIF v_servicetype_no='1131' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='450201';
				v_sbjt_no:='216201';
			ELSIF v_servicetype_no='1429' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='122302';
				v_sbjt_no:='450202';
			ELSIF v_servicetype_no='1431' THEN
			--ELSIF v_vou_memo='??????????????' THEN
				v_vou_memo:='??????????????';
				v_drsbjt_no:='450202';
				v_sbjt_no:='216202';
	---------------------------------------------------------
			ELSE
				v_makevou:='N';
			END IF;


			IF v_makevou='Y' THEN
				v_salegrp_cde:='000';
				v_bsns_typ:='0';
				v_cha_mrk:='0';
				v_check_flag:='2';
				v_crt_tm:=TRUNC(v_crt_tm);

				BEGIN

					Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);


						INSERT INTO WEB_FIN_MADCR_INTF(
							c_seq_no,
							c_item_no,
							c_cav_flag,
							c_sbjt_no,
							n_amt,
							c_cur_no,
							t_crt_tm,
							c_dptacc_no,
							c_dpt_cde,
							c_prod_no,
							c_vou_memo,
							c_send_flag,
							c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
							c_servicetype_no,c_sbjt_memo,c_ri_com
							)
						VALUES(
							vTmpVouNo,
							'1',
							v_drcav_flag,
							v_drsbjt_no,
							v_dramt,
							v_cur_no,
							TRUNC(v_crt_tm),
							v_dptacc_cde,
							v_dpt_cde,
							v_prod_no,
							v_vou_memo,
							'0',
							v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,
							v_servicetype_no,v_sbjt_memo,v_ri_com
						);



						INSERT INTO WEB_FIN_MADCR_INTF(
							c_seq_no,
							c_item_no,
							c_cav_flag,
							c_sbjt_no,
							n_amt,
							c_cur_no,
							t_crt_tm,
							c_dptacc_no,
							c_dpt_cde,
							c_prod_no,
							c_vou_memo,
							c_send_flag,
							c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
							c_servicetype_no,c_sbjt_memo,c_ri_com
							)
						VALUES(
							vTmpVouNo,
							'2',
							v_crcav_flag,
							v_sbjt_no,
							v_cramt,
							v_cur_no,
							TRUNC(v_crt_tm),
							v_dptacc_cde,
							v_dpt_cde,
							v_prod_no,
							v_vou_memo,
							'0',
							v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,v_servicetype_no,v_sbjt_memo,v_ri_com
						);


						/*??????*/

						UPDATE WEB_FIN_MADCR
							SET c_vou_no=vTmpVouNo
							WHERE 1=1
								AND c_dpt_cde=v_dpt_cde
								AND c_kind_no=v_prod_no
								AND c_cur_no=v_cur_no
								AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
								AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
								AND c_servicetype_no=v_servicetype_no
								AND c_ri_com=v_ri_com
								AND c_vou_no IS NULL
								AND c_rcpt_no IS NOT NULL;




						SELECT SUM(n_amt)/2
						INTO v_total_amt
							FROM WEB_FIN_MADCR_INTF
							WHERE c_seq_no=vTmpVouNo;

						UPDATE WEB_FIN_MADCR
							SET c_company_cde=v_company_cde,
							c_period_name=v_period_name,
							c_department_cde=v_department_cde,
							n_total_amt=v_total_amt
							WHERE c_vou_no=vTmpVouNo;


						UPDATE WEB_FIN_MADCR_INTF
							SET
							c_company_cde=v_company_cde,
							c_period_name=v_period_name,
							t_end_tm=SYSDATE,
							c_department_cde=v_department_cde,
							n_total_amt=v_total_amt,
							c_cur_no=DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no)
							,c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
							c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ)
							WHERE c_seq_no=vTmpVouNo;
					commit;


					END;
				END IF;
		ELSE
			v_err_content:='proc:[gather2],??????['||v_dpt_cde||v_ri_com||v_vou_memo||v_sbjt_no||TO_CHAR(v_cramt)||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||v_dpt_cde||v_prod_no||'],?????['||SQLCODE||SQLERRM;

			INSERT INTO WEB_BAS_FIN_ERRORLOG
			(
				c_err_no,
				c_errtype_no,
				c_tran_type,
				c_err_content,
				t_crt_tm
			)
			VALUES(
				F_Fin_Getcode('e'),
				'001',	--??????
				'0000',	--??????
				v_err_content,
				SYSDATE
			);
		END IF;	--v_ncompany||ri=0
			COMMIT;
		END LOOP;
		CLOSE cur_ifriDetailma;

		--????( ???????)
		OPEN cur_updgather;
		LOOP
		    FETCH cur_updgather
		    INTO v_company_cde,v_servicetype_no,v_crt_tm,v_cur_no;
		    EXIT WHEN cur_updgather%NOTFOUND;

			SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;
			v_voucompany_cde:=v_company_cde;

			IF v_servicetype_no IN ('4000','4001','4002','4003','4004') THEN
				v_voucompany_cde:='1000100';
			END IF;


			IF v_servicetype_no IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004')  THEN
			--'??????''??????????' ?????????? ???????? ???????????
				Dz_Proc.get_fin_rivoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF 	v_servicetype_no IN ('1127','1148','1133', '1135','1152','1129','1131','1101','1429','1431')   THEN
			--??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ????/??????????????/????????????
				Dz_Proc.get_fin_prevoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF v_servicetype_no IS NULL THEN
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSE
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			END IF;

			/*
				3000,????????
				3001,???????????
				4000,????????
				4001,???????????

				3002,??????????
				3003,??????????
				3004,???????????

				4002,??????????
				4003,??????????
				4004,???????????
			*/
			v_voucompany_cde:='1000100';
			v_voudepartment_cde:='2006';
			v_voudpt_cde:='00000019';
			v_voudptacc_cde:='00000019';

			IF v_servicetype_no IN ('3000','3001') THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4000','4001') THEN

				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('3002','3003','3004') THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4002','4003','4004')  THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;



			ELSE
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					and  not  (c_servicetype_no='1007' AND c_prod_no  like '014%')
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					and  not  (c_servicetype_no='1007' AND c_prod_no  like '00%')
					AND c_voucher_no IS NULL;
			END IF;


			--?????????????

			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='0'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='1';

			IF v_servicetype_no<>'1001' THEN -- ?????
				UPDATE WEB_FIN_MADCR
				SET c_item_no='0'
				WHERE  c_voucher_no=v_voucher_no AND c_item_no='1';
			END IF;

			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='1'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;

			IF v_servicetype_no<>'1001' THEN -- ?????
				UPDATE WEB_FIN_MADCR
				SET c_item_no='1'
				WHERE  c_voucher_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;
			END IF;

			--?????????????????
			SELECT SUM(n_total_amt)/2
				INTO v_total_amt
				FROM WEB_FIN_MADCR_INTF
				WHERE c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET n_total_amt=v_total_amt
				WHERE  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR
				SET n_total_amt=v_total_amt
				WHERE  c_voucher_no=v_voucher_no;

			--??????
			UPDATE WEB_FIN_MADCR_INTF
				SET c_department_cde='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR  c_sbjt_no='214614') AND  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET c_prod_no='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%'  OR  c_sbjt_no LIKE '119603%' OR c_sbjt_no LIKE '119113%' OR  c_sbjt_no='214614' ) AND  c_vou_no=v_voucher_no;

			Auto_Confirmed.ValidityCheckMaVou(v_voucher_no,v_succsflag);
			IF v_succsflag <0 THEN
				ROLLBACK;
				v_err_content:='proc:[gather],??????????['||TO_CHAR(v_succsflag)||v_company_cde||v_servicetype_no||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||'],?????['||SQLCODE||SQLERRM;

				INSERT INTO WEB_BAS_FIN_ERRORLOG
				(
					c_err_no,
					c_errtype_no,
					c_tran_type,
					c_err_content,
					t_crt_tm
				)
				VALUES(
					F_Fin_Getcode('e'),
					'001',	--??????
					'0000',	--??????
					v_err_content,
					SYSDATE
				);
				COMMIT;
			ELSE
				COMMIT;
			END IF;

		END LOOP;
		CLOSE cur_updgather;


		--????( ???? ???????)
		OPEN cur_saveupdgather;
		LOOP
		    FETCH cur_saveupdgather
		    INTO v_company_cde,v_servicetype_no,v_crt_tm,v_cur_no;
		    EXIT WHEN cur_saveupdgather%NOTFOUND;

			SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;
			v_voucompany_cde:=v_company_cde;

			IF v_servicetype_no IN ('4000','4001','4002','4003','4004') THEN
				v_voucompany_cde:='1000100';
			END IF;

			IF v_servicetype_no='1007' THEN
				v_voucompany_cde:='1000400';
			END IF;


			IF v_servicetype_no IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004')  THEN
			--'??????''??????????' ?????????? ???????? ???????????
				Dz_Proc.get_fin_rivoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF 	v_servicetype_no IN ('1127','1148','1133', '1135','1152','1129','1131','1101','1429','1431')   THEN
			--??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ????/??????????????/????????????
				Dz_Proc.get_fin_prevoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF v_servicetype_no IS NULL THEN
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSE
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			END IF;

			/*
				3000,????????
				3001,???????????
				4000,????????
				4001,???????????

				3002,??????????
				3003,??????????
				3004,???????????

				4002,??????????
				4003,??????????
				4004,???????????
			*/
			v_voucompany_cde:='1000100';
			v_voudepartment_cde:='2006';
			v_voudpt_cde:='00000019';
			v_voudptacc_cde:='00000019';

			IF v_servicetype_no IN ('3000','3001') THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4000','4001') THEN

				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('3002','3003','3004') THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4002','4003','4004')  THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;



			ELSE
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					and   (c_servicetype_no='1007' AND c_prod_no  like '014%')
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					and    (c_servicetype_no='1007' AND c_prod_no  like '00%')
					AND c_voucher_no IS NULL;
			END IF;


			--?????????????

			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='0'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='1';

			IF v_servicetype_no<>'1001' THEN -- ?????
				UPDATE WEB_FIN_MADCR
				SET c_item_no='0'
				WHERE  c_voucher_no=v_voucher_no AND c_item_no='1';
			END IF;

			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='1'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;

			IF v_servicetype_no<>'1001' THEN -- ?????
				UPDATE WEB_FIN_MADCR
				SET c_item_no='1'
				WHERE  c_voucher_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;
			END IF;



			--?????????????????
			SELECT SUM(n_total_amt)/2
				INTO v_total_amt
				FROM WEB_FIN_MADCR_INTF
				WHERE c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET n_total_amt=v_total_amt,c_company_cde='1000400',c_department_cde='2026'
				WHERE  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR
				SET n_total_amt=v_total_amt
				WHERE  c_voucher_no=v_voucher_no;

			--??????
			UPDATE WEB_FIN_MADCR_INTF
				SET c_department_cde='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR  c_sbjt_no='214614') AND  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET c_prod_no='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%'  OR  c_sbjt_no LIKE '119603%' OR c_sbjt_no LIKE '119113%' OR  c_sbjt_no='214614' ) AND  c_vou_no=v_voucher_no;

			Auto_Confirmed.ValidityCheckMaVou(v_voucher_no,v_succsflag);
			IF v_succsflag <0 THEN
				ROLLBACK;
				v_err_content:='proc:[gather],??????????['||TO_CHAR(v_succsflag)||v_company_cde||v_servicetype_no||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||'],?????['||SQLCODE||SQLERRM;

				INSERT INTO WEB_BAS_FIN_ERRORLOG
				(
					c_err_no,
					c_errtype_no,
					c_tran_type,
					c_err_content,
					t_crt_tm
				)
				VALUES(
					F_Fin_Getcode('e'),
					'001',	--??????
					'0000',	--??????
					v_err_content,
					SYSDATE
				);
				COMMIT;
			ELSE
				COMMIT;
			END IF;

		END LOOP;
		CLOSE cur_saveupdgather;




		--????????
	    INSERT INTO WEB_FIN_MADCR_STATUS(C_SEQ_NO,T_CRT_TM)
	    VALUES(F_Fin_Getcode('g'),SYSDATE);


/*

	select NVL(c_err_content,'-')
	INTO v_err_content
	from WEB_BAS_FIN_ERRORLOG
	where trunc(t_crt_tm) =trunc(sysdate) AND ROWNUM =1;


   	if  v_err_content<>'-' then
    		l_bool:=CUX_SEND_MAIL(v_err_content,to_char(sysdate,'YYYY')||'-'||to_char(sysdate,'MM')||'-'||to_char(sysdate,'DD')||' ????????','zhuminghua@ab-insurance.com');
	END IF;
*/

	   COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||vTmpVouNo||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[exception gather],??????['||vTmpVouNo||v_vou_memo||v_sbjt_no||TO_CHAR(v_cramt)||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||v_dpt_cde||v_prod_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;
	END;

	END;


--5.1 ?? ???? ?????gather,????c_servicetype_no???????????????????
PROCEDURE rigather
IS
	/*???????????,??????????????????*/
	/*?????*/
	v_drsbjt_no            WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_sbjt_no              WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_tmpsbjt_no           VARCHAR(20);

	v_dpt_cde              WEB_FIN_MADCR.c_dpt_cde%TYPE;
	v_dptacc_cde           WEB_FIN_MADCR.c_dptacc_no%TYPE;
	v_prod_no              WEB_FIN_MADCR.c_prod_no%TYPE;
	v_cur_no               WEB_FIN_MADCR_INTF.c_cur_no%TYPE;
	v_drcav_flag           WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_crcav_flag           WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_dramt                WEB_FIN_MADCR.n_amt%TYPE;
	v_cramt                WEB_FIN_MADCR.n_amt%TYPE;
	v_amt                  WEB_FIN_MADCR.n_amt%TYPE;
	v_vou_memo             VARCHAR(200);
	vTmpVouNo              VARCHAR(30);
	v_crt_tm               WEB_FIN_MADCR.t_crt_tm%TYPE;

	v_salegrp_cde           WEB_FIN_MADCR.c_salegrp_cde%TYPE;
	v_bsns_typ              WEB_FIN_MADCR.c_bsns_typ%TYPE;
	v_cha_mrk               WEB_FIN_MADCR.c_cha_mrk%TYPE;
	v_con_dpt_cde		WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
	--????????????  ORACLE?????????
	v_company_cde T_DEPARTMENT.c_company_cde%TYPE;
	v_department_cde T_DEPARTMENT.c_department_cde%TYPE;
	v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;

	v_err_content	 	WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
	v_makevou			VARCHAR2(1);
	v_check_flag		WEB_FIN_DCR.c_check_flag%TYPE;
	v_voucher_no		WEB_FIN_MADCR.c_voucher_no%TYPE;

	v_sbjt_memo	web_fin_dcr_intf.c_sbjt_memo%TYPE;
	v_period_name	web_fin_dcr_intf.c_period_name%TYPE;

	v_succsflag	INT;
	v_ri_com	web_fin_dcr_intf.c_ri_com%TYPE;
	v_total_amt	WEB_FIN_MADCR.n_total_amt%TYPE;
	v_ncompany	INT;
	v_nri		INT;

	v_voucompany_cde WEB_FIN_MADCR.c_company_cde%TYPE;
	v_voudepartment_cde WEB_FIN_MADCR.c_department_cde%TYPE;
	v_voudpt_cde	WEB_FIN_MADCR.c_dpt_cde%TYPE;
	v_voudptacc_cde	WEB_FIN_MADCR.c_dpt_cde%TYPE;

	CURSOR cur_ifgDetailma IS
	SELECT c_dpt_cde,c_kind_no,c_cur_no,SUM(n_amt)/2,TRUNC(t_crt_tm),c_servicetype_no
		FROM WEB_FIN_MADCR
		WHERE 	c_vou_no IS NULL
			AND  t_crt_tm < TRUNC(SYSDATE)
			and t_crt_tm >sysdate -30
			AND c_ri_com IS NULL
			AND c_servicetype_no IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004')
		GROUP BY c_dpt_cde,c_kind_no,c_cur_no,TRUNC(t_crt_tm) ,c_servicetype_no;

	CURSOR cur_ifriDetailma IS
	SELECT c_dpt_cde,c_kind_no,c_cur_no,SUM(n_amt)/2,TRUNC(t_crt_tm) ,c_servicetype_no,c_ri_com
		FROM WEB_FIN_MADCR
		WHERE 	c_vou_no IS NULL
			AND  t_crt_tm < TRUNC(SYSDATE)
			and t_crt_tm >sysdate -30
			AND c_ri_com IS NOT NULL
			AND c_servicetype_no IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004')
		GROUP BY c_dpt_cde,c_kind_no,c_cur_no,TRUNC(t_crt_tm) ,c_servicetype_no,c_ri_com;

        CURSOR cur_updrigather IS
		SELECT  c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no
			FROM WEB_FIN_MADCR_INTF
			WHERE c_vou_no IS NULL
			and t_crt_tm >sysdate -30
			AND c_servicetype_no IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004')
			GROUP BY c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no;

	BEGIN

	OPEN cur_ifgDetailma;
	LOOP
	FETCH cur_ifgDetailma
	INTO
		v_dpt_cde,v_prod_no,v_cur_no,v_amt,v_crt_tm,v_servicetype_no;
	EXIT WHEN cur_ifgDetailma%NOTFOUND;

	--?????
	--Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
	--??????????
	--???????/????/????
	--select  TO_CHAR(123,'0000') from dual;
	--?????7??+?????2??+?/??4??+??????4?)
	--????
	--??????,???????/????/????
	SELECT COUNT(*)
		INTO v_ncompany
		FROM T_DEPARTMENT
		WHERE c_dpt_cde=trim(v_dpt_cde);





		/*
		?????? 1000
			??????	112201
			??????	410101

		?????? 1123
			????????-??????	122203
			???????\??	410205

		?????????? 1001
			????????????	212101
			??????	112201

		?????? 1009
			???????????	440101
			??????	215001

		????? 1011
			??????????	440102
			???????????	215001

		?????????? 1010
			??????	440101
			??????	113101

		??????? 1007
			???????	443101
			???????	211101

		5.1???????
		5.1?????
		?1??????????????????
		?????????????-?????? 122401 	1127 ???????????
			???????????-IBNR 122402  	1148 ????????????????
		???????????-?????? 421101
			?????????- IBNR 421102


		?2??????????????????
		???????????-?????? 450101 	1133 ?????????
			?????????-IBNR 450102 		1135 ????????????
			?????????-???? 450103 	1152 ?????????
		?????????-???????????????  216101
			???????-IBNR	216102
			???????-????  216103


		122401,???????????/???????????
		122402,???????????/IBNR
		122403,???????????/????

		450101,?????????/???
		450102,?????????/IBNR
		450103,?????????/????

		421101,?????????/??????
		421102,?????????/??????
		421103,?????????/????

		216101,???????/???
		216102,???????/IBNR
		216103,???????/???????

			v_drsbjt_no:='119113';
			v_crsbjt_no:='214614';
			v_vou_memo:='?????????';
			v_servicetype_no:='5000';
		*/

		v_drcav_flag:='?';
		v_crcav_flag:='?';
		v_dramt:=v_amt;
		v_cramt:=v_amt;
		v_makevou:='Y';

		IF v_servicetype_no='1000' THEN
		--IF v_vou_memo='??????' THEN
			v_vou_memo:='??????';
			v_drsbjt_no:='112201';
			v_sbjt_no:='410101';
		ELSIF v_servicetype_no='5000' THEN
		--IF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='119113';
			v_sbjt_no:='214614';

		ELSIF v_servicetype_no='1123' THEN
		--ELSIF v_vou_memo='??????' THEN
			v_drsbjt_no:='122203';
			v_sbjt_no:='410205';
			v_vou_memo:='??????';
		ELSIF v_servicetype_no='1001' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='212101';
			v_sbjt_no:='112201';
		ELSIF v_servicetype_no='1009' THEN
		--ELSIF v_vou_memo='??????' THEN
			v_vou_memo:='??????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='215001';
		ELSIF v_servicetype_no='1011' THEN
		--ELSIF v_vou_memo='?????' THEN
			v_vou_memo:='?????';
			v_drsbjt_no:='440102';
			v_sbjt_no:='215002';
		ELSIF v_servicetype_no='1010' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113101';
		ELSIF v_servicetype_no='1150' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113102';
		ELSIF v_servicetype_no='1151' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113103';
		ELSIF v_servicetype_no='1149' THEN
			v_vou_memo:='???????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113104';
		ELSIF v_servicetype_no='1007' THEN
		--ELSIF v_vou_memo='???????' THEN
			v_vou_memo:='???????';
			v_drsbjt_no:='443101';
			v_sbjt_no:='211101';
		ELSIF v_servicetype_no='1101' THEN
		--ELSIF v_vou_memo='????' THEN
			v_vou_memo:='????';
			v_drsbjt_no:='446106';
			v_sbjt_no:='214401';

		ELSIF v_servicetype_no='1127' THEN
		--ELSIF v_vou_memo='???????????' THEN
			v_vou_memo:='???????????';
			v_drsbjt_no:='122401';
			v_sbjt_no:='421101';
		ELSIF v_servicetype_no='1148' THEN
		--ELSIF v_vou_memo='????????????????' THEN
			v_vou_memo:='????????????????';
			v_drsbjt_no:='122402';
			v_sbjt_no:='421102';
		ELSIF v_servicetype_no='1133' THEN
		--ELSIF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='450101';
			v_sbjt_no:='216101';
		ELSIF v_servicetype_no='1135' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='450102';
			v_sbjt_no:='216102';
		ELSIF v_servicetype_no='1152' THEN
		--ELSIF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='450103';
			v_sbjt_no:='216103';

		ELSIF v_servicetype_no='1129' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='122301';
			v_sbjt_no:='450201';
		ELSIF v_servicetype_no='1131' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='450201';
			v_sbjt_no:='216201';

		ELSE
			v_makevou:='N';
		END IF;


		IF  v_ncompany =0 THEN
			v_err_content:='proc:[rigather1],??????['||v_dpt_cde||SQLCODE||SQLERRM;

			INSERT INTO WEB_BAS_FIN_ERRORLOG
			(
				c_err_no,
				c_errtype_no,
				c_tran_type,
				c_err_content,
				t_crt_tm
			)
			VALUES(
				F_Fin_Getcode('e'),
				'001',	--??????
				'0000',	--??????
				v_err_content,
				SYSDATE
			);

		END IF;

		IF v_makevou='Y' AND v_ncompany >0 THEN
			SELECT c_company_cde,c_dptacc_cde,c_department_cde
				INTO v_company_cde,v_dptacc_cde,v_department_cde
				FROM T_DEPARTMENT
				WHERE c_dpt_cde=trim(v_dpt_cde);

			SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;

			v_salegrp_cde:='000';
			v_bsns_typ:='0';
			v_cha_mrk:='0';
			v_check_flag:='2';
			v_crt_tm:=TRUNC(v_crt_tm);
			BEGIN
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);



				INSERT INTO WEB_FIN_MADCR_INTF(
					c_seq_no,
					c_item_no,
					c_cav_flag,
					c_sbjt_no,
					n_amt,
					c_cur_no,
					t_crt_tm,
					c_dptacc_no,
					c_dpt_cde,
					c_prod_no,
					c_vou_memo,
					c_send_flag,
					c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
					c_servicetype_no
					)
				VALUES(
					vTmpVouNo,
					'1',
					v_drcav_flag,
					v_drsbjt_no,
					v_dramt,
					v_cur_no,
					TRUNC(v_crt_tm),
					v_dptacc_cde,
					v_dpt_cde,
					v_prod_no,
					v_vou_memo,
					'0',
					v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,
					v_servicetype_no
				);



				INSERT INTO WEB_FIN_MADCR_INTF(
					c_seq_no,
					c_item_no,
					c_cav_flag,
					c_sbjt_no,
					n_amt,
					c_cur_no,
					t_crt_tm,
					c_dptacc_no,
					c_dpt_cde,
					c_prod_no,
					c_vou_memo,
					c_send_flag,
					c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
					c_servicetype_no
					)
				VALUES(
					vTmpVouNo,
					'2',
					v_crcav_flag,
					v_sbjt_no,
					v_cramt,
					v_cur_no,
					TRUNC(v_crt_tm),
					v_dptacc_cde,
					v_dpt_cde,
					v_prod_no,
					v_vou_memo,
					'0',
					v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,v_servicetype_no
				);


				/*??????*/

				UPDATE WEB_FIN_MADCR
					SET c_vou_no=vTmpVouNo
					WHERE  c_dpt_cde=v_dpt_cde
						AND c_kind_no=v_prod_no
						AND c_cur_no=v_cur_no
						AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
						AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
						AND c_servicetype_no=v_servicetype_no
						AND c_vou_no IS NULL
						AND c_ri_com IS NULL
						AND c_rcpt_no IS NOT NULL;


				--????????????
				SELECT SUM(n_amt)/2
				INTO v_total_amt
					FROM WEB_FIN_MADCR_INTF
					WHERE c_seq_no=vTmpVouNo;

				UPDATE WEB_FIN_MADCR
					SET c_company_cde=v_company_cde,
					c_period_name=v_period_name,
					n_total_amt=v_total_amt
					WHERE c_vou_no=vTmpVouNo;


				UPDATE WEB_FIN_MADCR_INTF
					SET
					c_company_cde=v_company_cde,
					c_department_cde=v_department_cde,
					c_period_name=v_period_name,
					t_end_tm=SYSDATE,
					n_total_amt=v_total_amt,
					c_cur_no=DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no),
					c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),
					c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
					c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ)
					WHERE c_seq_no=vTmpVouNo;

			END;
			END IF;
			commit;

		END LOOP;
		CLOSE cur_ifgDetailma;


	OPEN cur_ifriDetailma;
	LOOP
	FETCH cur_ifriDetailma
	INTO v_dpt_cde,v_prod_no,v_cur_no,v_amt,v_crt_tm,v_servicetype_no,v_ri_com;
	EXIT WHEN cur_ifriDetailma%NOTFOUND;

	--?????
	--Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
	--??????????
	--???????/????/????
	--select  TO_CHAR(123,'0000') from dual;
	--?????7??+?????2??+?/??4??+??????4?)
	--????
	--??????,???????/????/????

	SELECT COUNT(*)
		INTO v_ncompany
		FROM T_DEPARTMENT
		WHERE c_dpt_cde=trim(v_dpt_cde);

	SELECT COUNT(*)
		INTO v_nri
		FROM t_fin_ri
		WHERE c_ri_com=v_ri_com;

	IF v_nri>0 AND v_ncompany >0 THEN
		SELECT c_company_cde,c_dptacc_cde,c_department_cde
			INTO v_company_cde,v_dptacc_cde,v_department_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde=trim(v_dpt_cde);

		SELECT c_finri_com
			INTO v_sbjt_memo
			FROM t_fin_ri
			WHERE c_ri_com=v_ri_com;

		SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;

			v_drcav_flag:='?';
			v_crcav_flag:='?';
			v_dramt:=v_amt;
			v_cramt:=v_amt;
			v_makevou:='Y';



			IF v_servicetype_no='1116' THEN
			--ELSIF v_vou_memo='??????' THEN
				v_vou_memo:='??????';
				v_drsbjt_no:='442101';
				v_sbjt_no:='211301';
			ELSIF v_servicetype_no='1117' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122201';
				v_sbjt_no:='420301';

			ELSIF v_servicetype_no='1118' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122202';
				v_sbjt_no:='420101';

			--ELSIF v_servicetype_no='1119' THEN
			--ELSIF v_vou_memo='????????' THEN

			ELSIF v_servicetype_no='1121' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122204';
				v_sbjt_no:='213101';

			ELSIF v_servicetype_no='1122' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='446104';
				v_sbjt_no:='211304';



			ELSIF v_servicetype_no='3000' THEN
			--ELSIF v_vou_memo='????????' THEN
				v_vou_memo:='????????';
				v_drsbjt_no:='211301';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='3001' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='211304';
				v_sbjt_no:='119603';

			ELSIF v_servicetype_no='4000' THEN
			--ELSIF v_vou_memo='????????' THEN
				v_vou_memo:='????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='211301';
			ELSIF v_servicetype_no='4001' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='211304';

			ELSIF v_servicetype_no='3002' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122201';
			ELSIF v_servicetype_no='3003' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122202';
			ELSIF v_servicetype_no='3004' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122204';


			ELSIF v_servicetype_no='4002' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122201';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='4003' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122202';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='4004' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122204';
				v_sbjt_no:='119603';

/*

	?????????????????
		??????????????????211301
		???????\???????? 119603?

	?????????????????
		???????\????????? 119603
		?????????????????211301

	------------------------------------------------------
	??????????????????????????
	???????\???????????? 119603
	?????????????122201  ?122202

	??????????????????????????
	?????????????122201
			 ???????\?????????119603



	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3000','?????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3001','?????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3002','??????????????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3003','??????????????????????????');

	3000,?????????????????
	3001,?????????????????
	3002,??????????????????????????
	3003,??????????????????????????
*/

			ELSIF v_servicetype_no='1127' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122401';
				v_sbjt_no:='421101';
			ELSIF v_servicetype_no='1148' THEN
			--ELSIF v_vou_memo='????????????????' THEN
				v_vou_memo:='????????????????';
				v_drsbjt_no:='122402';
				v_sbjt_no:='421102';
			ELSIF v_servicetype_no='1133' THEN
			--ELSIF v_vou_memo='?????????' THEN
				v_vou_memo:='?????????';
				v_drsbjt_no:='450101';
				v_sbjt_no:='216101';
			ELSIF v_servicetype_no='1135' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='450102';
				v_sbjt_no:='216102';
			ELSIF v_servicetype_no='1152' THEN
			--ELSIF v_vou_memo='?????????' THEN
				v_vou_memo:='?????????';
				v_drsbjt_no:='450103';
				v_sbjt_no:='421103';

			ELSIF v_servicetype_no='1129' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='122301';
				v_sbjt_no:='450201';
			ELSIF v_servicetype_no='1131' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='450201';
				v_sbjt_no:='216201';

			ELSIF v_servicetype_no='1429' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='122302';
				v_sbjt_no:='450202';
			ELSIF v_servicetype_no='1431' THEN
			--ELSIF v_vou_memo='??????????????' THEN
				v_vou_memo:='??????????????';
				v_drsbjt_no:='450202';
				v_sbjt_no:='216202';

	---------------------------------------------------------
			ELSE
				v_makevou:='N';
			END IF;


			IF v_makevou='Y' THEN
				v_salegrp_cde:='000';
				v_bsns_typ:='0';
				v_cha_mrk:='0';
				v_check_flag:='2';
				v_crt_tm:=TRUNC(v_crt_tm);

				BEGIN

					Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);


						INSERT INTO WEB_FIN_MADCR_INTF(
							c_seq_no,
							c_item_no,
							c_cav_flag,
							c_sbjt_no,
							n_amt,
							c_cur_no,
							t_crt_tm,
							c_dptacc_no,
							c_dpt_cde,
							c_prod_no,
							c_vou_memo,
							c_send_flag,
							c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
							c_servicetype_no,c_sbjt_memo,c_ri_com
							)
						VALUES(
							vTmpVouNo,
							'1',
							v_drcav_flag,
							v_drsbjt_no,
							v_dramt,
							v_cur_no,
							TRUNC(v_crt_tm),
							v_dptacc_cde,
							v_dpt_cde,
							v_prod_no,
							v_vou_memo,
							'0',
							v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,
							v_servicetype_no,v_sbjt_memo,v_ri_com
						);



						INSERT INTO WEB_FIN_MADCR_INTF(
							c_seq_no,
							c_item_no,
							c_cav_flag,
							c_sbjt_no,
							n_amt,
							c_cur_no,
							t_crt_tm,
							c_dptacc_no,
							c_dpt_cde,
							c_prod_no,
							c_vou_memo,
							c_send_flag,
							c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
							c_servicetype_no,c_sbjt_memo,c_ri_com
							)
						VALUES(
							vTmpVouNo,
							'2',
							v_crcav_flag,
							v_sbjt_no,
							v_cramt,
							v_cur_no,
							TRUNC(v_crt_tm),
							v_dptacc_cde,
							v_dpt_cde,
							v_prod_no,
							v_vou_memo,
							'0',
							v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,v_servicetype_no,v_sbjt_memo,v_ri_com
						);


						/*??????*/

						UPDATE WEB_FIN_MADCR
							SET c_vou_no=vTmpVouNo
							WHERE 1=1
								AND c_dpt_cde=v_dpt_cde
								AND c_kind_no=v_prod_no
								AND c_cur_no=v_cur_no
								AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
								AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
								AND c_servicetype_no=v_servicetype_no
								AND c_ri_com=v_ri_com
								AND c_vou_no IS NULL
								AND c_rcpt_no IS NOT NULL;




						SELECT SUM(n_amt)/2
						INTO v_total_amt
							FROM WEB_FIN_MADCR_INTF
							WHERE c_seq_no=vTmpVouNo;

						UPDATE WEB_FIN_MADCR
							SET c_company_cde=v_company_cde,
							c_period_name=v_period_name,
							c_department_cde=v_department_cde,
							n_total_amt=v_total_amt
							WHERE c_vou_no=vTmpVouNo;


						UPDATE WEB_FIN_MADCR_INTF
							SET
							c_company_cde=v_company_cde,
							c_period_name=v_period_name,
							t_end_tm=SYSDATE,
							c_department_cde=v_department_cde,
							n_total_amt=v_total_amt,
							c_cur_no=DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no)
							,c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
							c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ)
							WHERE c_seq_no=vTmpVouNo;
					commit;


					END;
				END IF;
		ELSE
			v_err_content:='proc:[rigather2],??????['||v_dpt_cde||v_ri_com||v_vou_memo||v_sbjt_no||TO_CHAR(v_cramt)||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||v_dpt_cde||v_prod_no||'],?????['||SQLCODE||SQLERRM;

			INSERT INTO WEB_BAS_FIN_ERRORLOG
			(
				c_err_no,
				c_errtype_no,
				c_tran_type,
				c_err_content,
				t_crt_tm
			)
			VALUES(
				F_Fin_Getcode('e'),
				'001',	--??????
				'0000',	--??????
				v_err_content,
				SYSDATE
			);
		END IF;	--v_ncompany||ri=0
			COMMIT;
		END LOOP;
		CLOSE cur_ifriDetailma;

		--????( ???????)
		OPEN cur_updrigather;
		LOOP
		    FETCH cur_updrigather
		    INTO v_company_cde,v_servicetype_no,v_crt_tm,v_cur_no;
		    EXIT WHEN cur_updrigather%NOTFOUND;

			SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;
			v_voucompany_cde:=v_company_cde;

			IF v_servicetype_no IN ('4000','4001','4002','4003','4004') THEN
				v_voucompany_cde:='1000100';
			END IF;


			IF v_servicetype_no IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004')  THEN
			--'??????''??????????' ?????????? ???????? ???????????
				Dz_Proc.get_fin_rivoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF 	v_servicetype_no IN ('1127','1148','1133', '1135','1152','1129','1131','1101','1429','1431')   THEN
			--??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ????/??????????????/????????????
				Dz_Proc.get_fin_prevoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF v_servicetype_no IS NULL THEN
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSE
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			END IF;

			/*
				3000,????????
				3001,???????????
				4000,????????
				4001,???????????

				3002,??????????
				3003,??????????
				3004,???????????

				4002,??????????
				4003,??????????
				4004,???????????
			*/
			v_voucompany_cde:='1000100';
			v_voudepartment_cde:='2006';
			v_voudpt_cde:='00000019';
			v_voudptacc_cde:='00000019';

			IF v_servicetype_no IN ('3000','3001') THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4000','4001') THEN

				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('3002','3003','3004') THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4002','4003','4004')  THEN
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;


			ELSE
				UPDATE  /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			END IF;


			--?????????????
			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='0'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='1';

			UPDATE WEB_FIN_MADCR
			SET c_item_no='0'
			WHERE  c_voucher_no=v_voucher_no AND c_item_no='1';

			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='1'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;

			UPDATE WEB_FIN_MADCR
			SET c_item_no='1'
			WHERE  c_voucher_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;

			--?????????????????
			SELECT SUM(n_total_amt)/2
				INTO v_total_amt
				FROM WEB_FIN_MADCR_INTF
				WHERE c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET n_total_amt=v_total_amt
				WHERE  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR
				SET n_total_amt=v_total_amt
				WHERE  c_voucher_no=v_voucher_no;

			--??????
			UPDATE WEB_FIN_MADCR_INTF
				SET c_department_cde='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR  c_sbjt_no='214614') AND  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET c_prod_no='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%'  OR  c_sbjt_no LIKE '119603%' OR c_sbjt_no LIKE '119113%' OR  c_sbjt_no='214614' ) AND  c_vou_no=v_voucher_no;

			Auto_Confirmed.ValidityCheckMaVou(v_voucher_no,v_succsflag);
			IF v_succsflag <0 THEN
				ROLLBACK;
				v_err_content:='proc:[rigather],??????????['||TO_CHAR(v_succsflag)||v_company_cde||v_servicetype_no||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||'],?????['||SQLCODE||SQLERRM;

				INSERT INTO WEB_BAS_FIN_ERRORLOG
				(
					c_err_no,
					c_errtype_no,
					c_tran_type,
					c_err_content,
					t_crt_tm
				)
				VALUES(
					F_Fin_Getcode('e'),
					'001',	--??????
					'0000',	--??????
					v_err_content,
					SYSDATE
				);
				COMMIT;
			ELSE
				COMMIT;
			END IF;

		END LOOP;
		CLOSE cur_updrigather;



	    COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||vTmpVouNo||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[exception rigather],??????['||vTmpVouNo||v_vou_memo||v_sbjt_no||TO_CHAR(v_cramt)||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||v_dpt_cde||v_prod_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;
	END;

	END;

--5.2 ?? ???????? ?????gather,????c_servicetype_no???????????????????
PROCEDURE pregather
IS
	/*???????????,??????????????????*/
	/*?????*/
	v_drsbjt_no            WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_sbjt_no              WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_tmpsbjt_no           VARCHAR(20);

	v_dpt_cde              WEB_FIN_MADCR.c_dpt_cde%TYPE;
	v_dptacc_cde           WEB_FIN_MADCR.c_dptacc_no%TYPE;
	v_prod_no              WEB_FIN_MADCR.c_prod_no%TYPE;
	v_cur_no               WEB_FIN_MADCR_INTF.c_cur_no%TYPE;
	v_drcav_flag           WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_crcav_flag           WEB_FIN_MADCR.c_cav_flag%TYPE;
	v_dramt                WEB_FIN_MADCR.n_amt%TYPE;
	v_cramt                WEB_FIN_MADCR.n_amt%TYPE;
	v_amt                  WEB_FIN_MADCR.n_amt%TYPE;
	v_vou_memo             VARCHAR(200);
	vTmpVouNo              VARCHAR(30);
	v_crt_tm               WEB_FIN_MADCR.t_crt_tm%TYPE;

	v_salegrp_cde           WEB_FIN_MADCR.c_salegrp_cde%TYPE;
	v_bsns_typ              WEB_FIN_MADCR.c_bsns_typ%TYPE;
	v_cha_mrk               WEB_FIN_MADCR.c_cha_mrk%TYPE;
	v_con_dpt_cde		WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
	--????????????  ORACLE?????????
	v_company_cde T_DEPARTMENT.c_company_cde%TYPE;
	v_department_cde T_DEPARTMENT.c_department_cde%TYPE;
	v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;

	v_err_content	 	WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
	v_makevou			VARCHAR2(1);
	v_check_flag		WEB_FIN_DCR.c_check_flag%TYPE;
	v_voucher_no		WEB_FIN_MADCR.c_voucher_no%TYPE;

	v_sbjt_memo	web_fin_dcr_intf.c_sbjt_memo%TYPE;
	v_period_name	web_fin_dcr_intf.c_period_name%TYPE;

	v_succsflag	INT;
	v_ri_com	web_fin_dcr_intf.c_ri_com%TYPE;
	v_total_amt	WEB_FIN_MADCR.n_total_amt%TYPE;
	v_ncompany	INT;
	v_nri		INT;

	v_voucompany_cde WEB_FIN_MADCR.c_company_cde%TYPE;
	v_voudepartment_cde WEB_FIN_MADCR.c_department_cde%TYPE;
	v_voudpt_cde	WEB_FIN_MADCR.c_dpt_cde%TYPE;
	v_voudptacc_cde	WEB_FIN_MADCR.c_dpt_cde%TYPE;

	CURSOR cur_ifgDetailma IS
	SELECT decode(c_check_flag,'4','4','2'),c_dpt_cde,c_kind_no,c_cur_no,SUM(n_amt)/2,TRUNC(t_crt_tm),c_servicetype_no
		FROM WEB_FIN_MADCR
		WHERE 	c_vou_no IS NULL
			AND  t_crt_tm < TRUNC(SYSDATE)
			and t_crt_tm >sysdate -30
			AND c_ri_com IS NULL
			AND c_servicetype_no IN ('1127','1148','1133', '1135','1152','1129','1131','1429','1431','1101')
		GROUP BY decode(c_check_flag,'4','4','2'),c_dpt_cde,c_kind_no,c_cur_no,TRUNC(t_crt_tm) ,c_servicetype_no;

	CURSOR cur_ifriDetailma IS
	SELECT decode(c_check_flag,'4','4','2'),c_dpt_cde,c_kind_no,c_cur_no,SUM(n_amt)/2,TRUNC(t_crt_tm) ,c_servicetype_no,c_ri_com
		FROM WEB_FIN_MADCR
		WHERE 	c_vou_no IS NULL
			AND  t_crt_tm < TRUNC(SYSDATE)
			and t_crt_tm >sysdate -30
			AND c_ri_com IS NOT NULL
			AND c_servicetype_no IN ('1127','1148','1133', '1135','1152','1129','1131','1429','1431','1101')
		GROUP BY decode(c_check_flag,'4','4','2'),c_dpt_cde,c_kind_no,c_cur_no,TRUNC(t_crt_tm) ,c_servicetype_no,c_ri_com;

        CURSOR cur_updpregather IS
		SELECT  c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no
			FROM WEB_FIN_MADCR_INTF
			WHERE c_vou_no IS NULL
			and t_crt_tm >sysdate -30
			AND c_servicetype_no IN ('1127','1148','1133', '1135','1152','1129','1131','1429','1431','1101')
			GROUP BY c_company_cde,c_servicetype_no,TRUNC(t_crt_tm),c_cur_no;

	BEGIN

	OPEN cur_ifgDetailma;
	LOOP
	FETCH cur_ifgDetailma
	INTO
		v_check_flag,v_dpt_cde,v_prod_no,v_cur_no,v_amt,v_crt_tm,v_servicetype_no;
	EXIT WHEN cur_ifgDetailma%NOTFOUND;

	--?????
	--Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
	--??????????
	--???????/????/????
	--select  TO_CHAR(123,'0000') from dual;
	--?????7??+?????2??+?/??4??+??????4?)
	--????
	--??????,???????/????/????
	SELECT COUNT(*)
		INTO v_ncompany
		FROM T_DEPARTMENT
		WHERE c_dpt_cde=trim(v_dpt_cde);





		/*
		?????? 1000
			??????	112201
			??????	410101

		?????? 1123
			????????-??????	122203
			???????\??	410205

		?????????? 1001
			????????????	212101
			??????	112201

		?????? 1009
			???????????	440101
			??????	215001

		????? 1011
			??????????	440102
			???????????	215001

		?????????? 1010
			??????	440101
			??????	113101

		??????? 1007
			???????	443101
			???????	211101

		5.1???????
		5.1?????
		?1??????????????????
		?????????????-?????? 122401 	1127 ???????????
			???????????-IBNR 122402  	1148 ????????????????
		???????????-?????? 421101
			?????????- IBNR 421102


		?2??????????????????
		???????????-?????? 450101 	1133 ?????????
			?????????-IBNR 450102 		1135 ????????????
			?????????-???? 450103 	1152 ?????????
		?????????-???????????????  216101
			???????-IBNR	216102
			???????-????  216103


		122401,???????????/???????????
		122402,???????????/IBNR
		122403,???????????/????

		450101,?????????/???
		450102,?????????/IBNR
		450103,?????????/????

		421101,?????????/??????
		421102,?????????/??????
		421103,?????????/????

		216101,???????/???
		216102,???????/IBNR
		216103,???????/???????

			v_drsbjt_no:='119113';
			v_crsbjt_no:='214614';
			v_vou_memo:='?????????';
			v_servicetype_no:='5000';
		*/

		v_drcav_flag:='?';
		v_crcav_flag:='?';
		v_dramt:=v_amt;
		v_cramt:=v_amt;
		v_makevou:='Y';

		IF v_servicetype_no='1000' THEN
		--IF v_vou_memo='??????' THEN
			v_vou_memo:='??????';
			v_drsbjt_no:='112201';
			v_sbjt_no:='410101';
		ELSIF v_servicetype_no='5000' THEN
		--IF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='119113';
			v_sbjt_no:='214614';

		ELSIF v_servicetype_no='1123' THEN
		--ELSIF v_vou_memo='??????' THEN
			v_drsbjt_no:='122203';
			v_sbjt_no:='410205';
			v_vou_memo:='??????';
		ELSIF v_servicetype_no='1001' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='212101';
			v_sbjt_no:='112201';
		ELSIF v_servicetype_no='1009' THEN
		--ELSIF v_vou_memo='??????' THEN
			v_vou_memo:='??????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='215001';
		ELSIF v_servicetype_no='1011' THEN
		--ELSIF v_vou_memo='?????' THEN
			v_vou_memo:='?????';
			v_drsbjt_no:='440102';
			v_sbjt_no:='215002';
		ELSIF v_servicetype_no='1010' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113101';
		ELSIF v_servicetype_no='1150' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113102';
		ELSIF v_servicetype_no='1151' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113103';
		ELSIF v_servicetype_no='1149' THEN
			v_vou_memo:='???????????????';
			v_drsbjt_no:='440101';
			v_sbjt_no:='113104';
		ELSIF v_servicetype_no='1007' THEN
		--ELSIF v_vou_memo='???????' THEN
			v_vou_memo:='???????';
			v_drsbjt_no:='443101';
			v_sbjt_no:='211101';
		ELSIF v_servicetype_no='1101' THEN
		--ELSIF v_vou_memo='????' THEN
			v_vou_memo:='????';
			v_drsbjt_no:='446106';
			v_sbjt_no:='214401';

		ELSIF v_servicetype_no='1127' THEN
		--ELSIF v_vou_memo='???????????' THEN
			v_vou_memo:='???????????';
			v_drsbjt_no:='122401';
			v_sbjt_no:='421101';
		ELSIF v_servicetype_no='1148' THEN
		--ELSIF v_vou_memo='????????????????' THEN
			v_vou_memo:='????????????????';
			v_drsbjt_no:='122402';
			v_sbjt_no:='421102';
		ELSIF v_servicetype_no='1133' THEN
		--ELSIF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='450101';
			v_sbjt_no:='216101';
		ELSIF v_servicetype_no='1135' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='450102';
			v_sbjt_no:='216102';
		ELSIF v_servicetype_no='1152' THEN
		--ELSIF v_vou_memo='?????????' THEN
			v_vou_memo:='?????????';
			v_drsbjt_no:='450103';
			v_sbjt_no:='216103';

		ELSIF v_servicetype_no='1129' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='122301';
			v_sbjt_no:='450201';
		ELSIF v_servicetype_no='1131' THEN
		--ELSIF v_vou_memo='??????????' THEN
			v_vou_memo:='??????????';
			v_drsbjt_no:='450201';
			v_sbjt_no:='216201';
		ELSIF v_servicetype_no='1429' THEN
		--ELSIF v_vou_memo='????????????' THEN
			v_vou_memo:='????????????';
			v_drsbjt_no:='122302';
			v_sbjt_no:='450202';
		ELSIF v_servicetype_no='1431' THEN
		--ELSIF v_vou_memo='??????????????' THEN
			v_vou_memo:='??????????????';
			v_drsbjt_no:='450202';
			v_sbjt_no:='216202';
		ELSE
			v_makevou:='N';
		END IF;


		IF  v_ncompany =0 THEN
			v_err_content:='proc:[pregather1],??????['||v_dpt_cde||SQLCODE||SQLERRM;

			INSERT INTO WEB_BAS_FIN_ERRORLOG
			(
				c_err_no,
				c_errtype_no,
				c_tran_type,
				c_err_content,
				t_crt_tm
			)
			VALUES(
				F_Fin_Getcode('e'),
				'001',	--??????
				'0000',	--??????
				v_err_content,
				SYSDATE
			);

		END IF;

		IF v_makevou='Y' AND v_ncompany >0 THEN
			SELECT c_company_cde,c_dptacc_cde,c_department_cde
				INTO v_company_cde,v_dptacc_cde,v_department_cde
				FROM T_DEPARTMENT
				WHERE c_dpt_cde=trim(v_dpt_cde);

			SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;

			v_salegrp_cde:='000';
			v_bsns_typ:='0';
			v_cha_mrk:='0';
			--v_check_flag:='2';
			v_crt_tm:=TRUNC(v_crt_tm);
			BEGIN
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);



				INSERT INTO WEB_FIN_MADCR_INTF(
					c_seq_no,
					c_item_no,
					c_cav_flag,
					c_sbjt_no,
					n_amt,
					c_cur_no,
					t_crt_tm,
					c_dptacc_no,
					c_dpt_cde,
					c_prod_no,
					c_vou_memo,
					c_send_flag,
					c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
					c_servicetype_no
					)
				VALUES(
					vTmpVouNo,
					'1',
					v_drcav_flag,
					v_drsbjt_no,
					v_dramt,
					v_cur_no,
					TRUNC(v_crt_tm),
					v_dptacc_cde,
					v_dpt_cde,
					v_prod_no,
					v_vou_memo,
					'0',
					v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,
					v_servicetype_no
				);



				INSERT INTO WEB_FIN_MADCR_INTF(
					c_seq_no,
					c_item_no,
					c_cav_flag,
					c_sbjt_no,
					n_amt,
					c_cur_no,
					t_crt_tm,
					c_dptacc_no,
					c_dpt_cde,
					c_prod_no,
					c_vou_memo,
					c_send_flag,
					c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
					c_servicetype_no
					)
				VALUES(
					vTmpVouNo,
					'2',
					v_crcav_flag,
					v_sbjt_no,
					v_cramt,
					v_cur_no,
					TRUNC(v_crt_tm),
					v_dptacc_cde,
					v_dpt_cde,
					v_prod_no,
					v_vou_memo,
					'0',
					v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,v_servicetype_no
				);


				/*??????*/

				UPDATE WEB_FIN_MADCR
					SET c_vou_no=vTmpVouNo
					WHERE  c_dpt_cde=v_dpt_cde
						AND c_kind_no=v_prod_no
						AND c_cur_no=v_cur_no
						AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
						AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
						AND c_servicetype_no=v_servicetype_no
						AND c_vou_no IS NULL
						AND c_ri_com IS NULL
						AND c_rcpt_no IS NOT NULL;


				--????????????
				SELECT SUM(n_amt)/2
				INTO v_total_amt
					FROM WEB_FIN_MADCR_INTF
					WHERE c_seq_no=vTmpVouNo;

				UPDATE WEB_FIN_MADCR
					SET c_company_cde=v_company_cde,
					c_period_name=v_period_name,
					n_total_amt=v_total_amt
					WHERE c_vou_no=vTmpVouNo;


				UPDATE WEB_FIN_MADCR_INTF
					SET
					c_company_cde=v_company_cde,
					c_department_cde=v_department_cde,
					c_period_name=v_period_name,
					t_end_tm=SYSDATE,
					n_total_amt=v_total_amt,
					c_cur_no=DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no),
					c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),
					c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
					c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ)
					WHERE c_seq_no=vTmpVouNo;

			END;
			END IF;
			commit;

		END LOOP;
		CLOSE cur_ifgDetailma;


	OPEN cur_ifriDetailma;
	LOOP
	FETCH cur_ifriDetailma
	INTO v_check_flag,v_dpt_cde,v_prod_no,v_cur_no,v_amt,v_crt_tm,v_servicetype_no,v_ri_com;
	EXIT WHEN cur_ifriDetailma%NOTFOUND;

	--?????
	--Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
	--??????????
	--???????/????/????
	--select  TO_CHAR(123,'0000') from dual;
	--?????7??+?????2??+?/??4??+??????4?)
	--????
	--??????,???????/????/????

	SELECT COUNT(*)
		INTO v_ncompany
		FROM T_DEPARTMENT
		WHERE c_dpt_cde=trim(v_dpt_cde);

	SELECT COUNT(*)
		INTO v_nri
		FROM t_fin_ri
		WHERE c_ri_com=v_ri_com;

	IF v_nri>0 AND v_ncompany >0 THEN
		SELECT c_company_cde,c_dptacc_cde,c_department_cde
			INTO v_company_cde,v_dptacc_cde,v_department_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde=trim(v_dpt_cde);

		SELECT c_finri_com
			INTO v_sbjt_memo
			FROM t_fin_ri
			WHERE c_ri_com=v_ri_com;

		SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;

			v_drcav_flag:='?';
			v_crcav_flag:='?';
			v_dramt:=v_amt;
			v_cramt:=v_amt;
			v_makevou:='Y';



			IF v_servicetype_no='1116' THEN
			--ELSIF v_vou_memo='??????' THEN
				v_vou_memo:='??????';
				v_drsbjt_no:='442101';
				v_sbjt_no:='211301';
			ELSIF v_servicetype_no='1117' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122201';
				v_sbjt_no:='420301';

			ELSIF v_servicetype_no='1118' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122202';
				v_sbjt_no:='420101';

			--ELSIF v_servicetype_no='1119' THEN
			--ELSIF v_vou_memo='????????' THEN

			ELSIF v_servicetype_no='1121' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122204';
				v_sbjt_no:='213101';

			ELSIF v_servicetype_no='1122' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='446104';
				v_sbjt_no:='211304';



			ELSIF v_servicetype_no='3000' THEN
			--ELSIF v_vou_memo='????????' THEN
				v_vou_memo:='????????';
				v_drsbjt_no:='211301';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='3001' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='211304';
				v_sbjt_no:='119603';

			ELSIF v_servicetype_no='4000' THEN
			--ELSIF v_vou_memo='????????' THEN
				v_vou_memo:='????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='211301';
			ELSIF v_servicetype_no='4001' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='211304';

			ELSIF v_servicetype_no='3002' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122201';
			ELSIF v_servicetype_no='3003' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122202';
			ELSIF v_servicetype_no='3004' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='119603';
				v_sbjt_no:='122204';


			ELSIF v_servicetype_no='4002' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122201';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='4003' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='122202';
				v_sbjt_no:='119603';
			ELSIF v_servicetype_no='4004' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122204';
				v_sbjt_no:='119603';

/*

	?????????????????
		??????????????????211301
		???????\???????? 119603?

	?????????????????
		???????\????????? 119603
		?????????????????211301

	------------------------------------------------------
	??????????????????????????
	???????\???????????? 119603
	?????????????122201  ?122202

	??????????????????????????
	?????????????122201
			 ???????\?????????119603



	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3000','?????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3001','?????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3002','??????????????????????????');

	INSERT INTO t_fin_servicetype(c_no,c_name)
	VALUES('3003','??????????????????????????');

	3000,?????????????????
	3001,?????????????????
	3002,??????????????????????????
	3003,??????????????????????????
*/

			ELSIF v_servicetype_no='1127' THEN
			--ELSIF v_vou_memo='???????????' THEN
				v_vou_memo:='???????????';
				v_drsbjt_no:='122401';
				v_sbjt_no:='421101';
			ELSIF v_servicetype_no='1148' THEN
			--ELSIF v_vou_memo='????????????????' THEN
				v_vou_memo:='????????????????';
				v_drsbjt_no:='122402';
				v_sbjt_no:='421102';
			ELSIF v_servicetype_no='1133' THEN
			--ELSIF v_vou_memo='?????????' THEN
				v_vou_memo:='?????????';
				v_drsbjt_no:='450101';
				v_sbjt_no:='216101';
			ELSIF v_servicetype_no='1135' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='450102';
				v_sbjt_no:='216102';
			ELSIF v_servicetype_no='1152' THEN
			--ELSIF v_vou_memo='?????????' THEN
				v_vou_memo:='?????????';
				v_drsbjt_no:='450103';
				v_sbjt_no:='421103';

			ELSIF v_servicetype_no='1129' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='122301';
				v_sbjt_no:='450201';
			ELSIF v_servicetype_no='1131' THEN
			--ELSIF v_vou_memo='??????????' THEN
				v_vou_memo:='??????????';
				v_drsbjt_no:='450201';
				v_sbjt_no:='216201';
			ELSIF v_servicetype_no='1429' THEN
			--ELSIF v_vou_memo='????????????' THEN
				v_vou_memo:='????????????';
				v_drsbjt_no:='122302';
				v_sbjt_no:='450202';
			ELSIF v_servicetype_no='1431' THEN
			--ELSIF v_vou_memo='??????????????' THEN
				v_vou_memo:='??????????????';
				v_drsbjt_no:='450202';
				v_sbjt_no:='216202';
	---------------------------------------------------------
			ELSE
				v_makevou:='N';
			END IF;


			IF v_makevou='Y' THEN
				v_salegrp_cde:='000';
				v_bsns_typ:='0';
				v_cha_mrk:='0';
				--v_check_flag:='2';
				v_crt_tm:=TRUNC(v_crt_tm);

				BEGIN

					Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'5',dz_proc.g_pttype);


						INSERT INTO WEB_FIN_MADCR_INTF(
							c_seq_no,
							c_item_no,
							c_cav_flag,
							c_sbjt_no,
							n_amt,
							c_cur_no,
							t_crt_tm,
							c_dptacc_no,
							c_dpt_cde,
							c_prod_no,
							c_vou_memo,
							c_send_flag,
							c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
							c_servicetype_no,c_sbjt_memo,c_ri_com
							)
						VALUES(
							vTmpVouNo,
							'1',
							v_drcav_flag,
							v_drsbjt_no,
							v_dramt,
							v_cur_no,
							TRUNC(v_crt_tm),
							v_dptacc_cde,
							v_dpt_cde,
							v_prod_no,
							v_vou_memo,
							'0',
							v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,
							v_servicetype_no,v_sbjt_memo,v_ri_com
						);



						INSERT INTO WEB_FIN_MADCR_INTF(
							c_seq_no,
							c_item_no,
							c_cav_flag,
							c_sbjt_no,
							n_amt,
							c_cur_no,
							t_crt_tm,
							c_dptacc_no,
							c_dpt_cde,
							c_prod_no,
							c_vou_memo,
							c_send_flag,
							c_salegrp_cde,c_bsns_typ,c_cha_mrk,c_con_dpt_cde,c_check_flag,
							c_servicetype_no,c_sbjt_memo,c_ri_com
							)
						VALUES(
							vTmpVouNo,
							'2',
							v_crcav_flag,
							v_sbjt_no,
							v_cramt,
							v_cur_no,
							TRUNC(v_crt_tm),
							v_dptacc_cde,
							v_dpt_cde,
							v_prod_no,
							v_vou_memo,
							'0',
							v_salegrp_cde,v_bsns_typ,v_cha_mrk,v_con_dpt_cde,v_check_flag,v_servicetype_no,v_sbjt_memo,v_ri_com
						);


						/*??????*/

						UPDATE WEB_FIN_MADCR
							SET c_vou_no=vTmpVouNo
							WHERE 1=1
								AND c_dpt_cde=v_dpt_cde
								AND c_kind_no=v_prod_no
								AND c_cur_no=v_cur_no
								AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
								AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
								AND c_servicetype_no=v_servicetype_no
								AND c_ri_com=v_ri_com
								AND c_vou_no IS NULL
								AND c_rcpt_no IS NOT NULL;




						SELECT SUM(n_amt)/2
						INTO v_total_amt
							FROM WEB_FIN_MADCR_INTF
							WHERE c_seq_no=vTmpVouNo;

						UPDATE WEB_FIN_MADCR
							SET c_company_cde=v_company_cde,
							c_period_name=v_period_name,
							c_department_cde=v_department_cde,
							n_total_amt=v_total_amt
							WHERE c_vou_no=vTmpVouNo;


						UPDATE WEB_FIN_MADCR_INTF
							SET
							c_company_cde=v_company_cde,
							c_period_name=v_period_name,
							t_end_tm=SYSDATE,
							c_department_cde=v_department_cde,
							n_total_amt=v_total_amt,
							c_cur_no=DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no)
							,c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
							c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ)
							WHERE c_seq_no=vTmpVouNo;
					commit;


					END;
				END IF;
		ELSE
			v_err_content:='proc:[pregather2],??????['||v_dpt_cde||v_ri_com||v_vou_memo||v_sbjt_no||TO_CHAR(v_cramt)||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||v_dpt_cde||v_prod_no||'],?????['||SQLCODE||SQLERRM;

			INSERT INTO WEB_BAS_FIN_ERRORLOG
			(
				c_err_no,
				c_errtype_no,
				c_tran_type,
				c_err_content,
				t_crt_tm
			)
			VALUES(
				F_Fin_Getcode('e'),
				'001',	--??????
				'0000',	--??????
				v_err_content,
				SYSDATE
			);
		END IF;	--v_ncompany||ri=0
			COMMIT;
		END LOOP;
		CLOSE cur_ifriDetailma;

		--????( ???????)
		OPEN cur_updpregather;
		LOOP
		    FETCH cur_updpregather
		    INTO v_company_cde,v_servicetype_no,v_crt_tm,v_cur_no;
		    EXIT WHEN cur_updpregather%NOTFOUND;

			SELECT TO_CHAR(v_crt_tm,'YYYY-MM') INTO v_period_name FROM dual;
			v_voucompany_cde:=v_company_cde;

			IF v_servicetype_no IN ('4000','4001','4002','4003','4004') THEN
				v_voucompany_cde:='1000100';
			END IF;


			IF v_servicetype_no IN ('1116','1117','1118','1119','1121','1122','3000','3001','3002','3003','3004','4000','4001','4002','4003','4004')  THEN
			--'??????''??????????' ?????????? ???????? ???????????
				Dz_Proc.get_fin_rivoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF 	v_servicetype_no IN ('1127','1148','1133', '1135','1152','1129','1131','1429','1431','1101')   THEN
			--??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ??????????????????,????????????
				Dz_Proc.get_fin_prevoucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSIF v_servicetype_no IS NULL THEN
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			ELSE
				Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_voucompany_cde,dz_proc.g_pttype);
			END IF;

			/*
				3000,????????
				3001,???????????
				4000,????????
				4001,???????????

				3002,??????????
				3003,??????????
				3004,???????????

				4002,??????????
				4003,??????????
				4004,???????????
			*/
			v_voucompany_cde:='1000100';
			v_voudepartment_cde:='2006';
			v_voudpt_cde:='00000019';
			v_voudptacc_cde:='00000019';

			IF v_servicetype_no IN ('3000','3001') THEN
				UPDATE /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/   WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4000','4001') THEN

				UPDATE /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/   WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('3002','3003','3004') THEN
				UPDATE /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/   WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_voucompany_cde,c_sbjt_memo)
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			ELSIF v_servicetype_no IN ('4002','4003','4004')  THEN
				UPDATE /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE,c_sbjt_memo=DECODE(c_cav_flag,'?','02'||v_company_cde,c_sbjt_memo),
					c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					--c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;


			ELSE
				UPDATE /*+  index(WEB_FIN_MADCR_INTF,WEB_FIN_MADCR_INTF_CRT)*/  WEB_FIN_MADCR_INTF
					SET c_vou_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=v_cur_no
					AND c_vou_no IS NULL;

				UPDATE WEB_FIN_MADCR
					SET c_voucher_no=v_voucher_no,t_end_tm=SYSDATE
					WHERE c_company_cde=v_company_cde
					AND c_servicetype_no=v_servicetype_no
					AND t_crt_tm >=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
					AND t_crt_tm <=TO_DATE(TO_CHAR(v_crt_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS')
					AND c_cur_no=DECODE(v_cur_no,'CNY','01','HKD','02','USD','03','EUR','13','JPY','05',v_cur_no)
					AND c_voucher_no IS NULL;
			END IF;


			--?????????????
			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='0'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='1';

			UPDATE WEB_FIN_MADCR
			SET c_item_no='0'
			WHERE  c_voucher_no=v_voucher_no AND c_item_no='1';

			UPDATE WEB_FIN_MADCR_INTF
			SET c_item_no='1'
			WHERE  c_vou_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;

			UPDATE WEB_FIN_MADCR
			SET c_item_no='1'
			WHERE  c_voucher_no=v_voucher_no AND c_item_no='0' AND ROWNUM <2;

			--?????????????????
			SELECT SUM(n_total_amt)/2
				INTO v_total_amt
				FROM WEB_FIN_MADCR_INTF
				WHERE c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET n_total_amt=v_total_amt
				WHERE  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR
				SET n_total_amt=v_total_amt
				WHERE  c_voucher_no=v_voucher_no;

			--??????
			UPDATE WEB_FIN_MADCR_INTF
				SET c_department_cde='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR  c_sbjt_no='214614') AND  c_vou_no=v_voucher_no;

			UPDATE WEB_FIN_MADCR_INTF
				SET c_prod_no='0',c_bsns_typ='0'
				WHERE (c_sbjt_no LIKE '214401%'  OR  c_sbjt_no LIKE '119603%' OR c_sbjt_no LIKE '119113%' OR  c_sbjt_no='214614' ) AND  c_vou_no=v_voucher_no;

			Auto_Confirmed.ValidityCheckMaVou(v_voucher_no,v_succsflag);
			IF v_succsflag <0 THEN
				ROLLBACK;
				v_err_content:='proc:[pregather],??????????['||TO_CHAR(v_succsflag)||v_company_cde||v_servicetype_no||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||'],?????['||SQLCODE||SQLERRM;

				INSERT INTO WEB_BAS_FIN_ERRORLOG
				(
					c_err_no,
					c_errtype_no,
					c_tran_type,
					c_err_content,
					t_crt_tm
				)
				VALUES(
					F_Fin_Getcode('e'),
					'001',	--??????
					'0000',	--??????
					v_err_content,
					SYSDATE
				);
				COMMIT;
			ELSE
				COMMIT;
			END IF;

		END LOOP;
		CLOSE cur_updpregather;



	    COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||vTmpVouNo||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[exception pregather],??????['||vTmpVouNo||v_vou_memo||v_sbjt_no||TO_CHAR(v_cramt)||v_cur_no||TO_CHAR(v_crt_tm,'YYYY-MM-DD')||v_dpt_cde||v_prod_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;
	END;

	END;

--6.??
PROCEDURE monthlycloing(v_dptacc_cde     IN       T_DEPARTMENT.c_dpt_cde%TYPE,
			v_crt_cde     IN       T_FIN_MONTHLYCLOSING.c_upd_cde%TYPE,
      			v_succsflag   	IN 	 OUT    NUMBER)
IS

        v_tmp_cnt	INT;
	v_period_name   T_FIN_MONTHLYCLOSING.c_period_name%TYPE;
	v_end_time	T_FIN_ACCNTPERIOD.C_BGN_TM%TYPE;
	v_otherdptacc_cde T_DEPARTMENT.c_dptacc_cde%TYPE;

        CURSOR cur_dptacc IS
            SELECT DISTINCT c_dptacc_cde
              FROM T_DEPARTMENT
              WHERE c_dptacc_cde<>'?' AND c_dptacc_cde IS NOT NULL;

    BEGIN
/*
1.??
1.1.????????????????????????????????????????
1.2.???????????????????
1.3 ??????????????????????

2.??????????????????????????

3.?????????????????????
4.???????????????????????????t_fin_errorlog????

v_succsflag:
	0	??
	-1 	?????????????????
	-2	??????????????????????
	-3	????????????????
	-4	????????,???????????
	-5	?????????????????????????

	-9	????
*/

        v_succsflag  := 0;

	--1.??????????????????????
	SELECT COUNT(*)
	INTO	v_tmp_cnt
	FROM T_FIN_MONTHLYCLOSING
	WHERE c_dptacc_cde=v_dptacc_cde AND c_closing_flag='1' ;--??

	IF v_tmp_cnt=0 THEN	--????????? 00000019
		v_succsflag  := -4;
		RETURN;
	ELSE
		SELECT c_period_name
			INTO	v_period_name
			FROM T_FIN_MONTHLYCLOSING
			WHERE c_dptacc_cde=v_dptacc_cde
			AND c_closing_flag='1' ;--??
	END IF;

	SELECT TRUNC(c_end_tm)
		INTO v_end_time
		FROM T_FIN_ACCNTPERIOD
		WHERE c_period_name=v_period_name;

	v_end_time:=TRUNC(v_end_time);
	IF v_end_time>TRUNC(SYSDATE) THEN
		v_succsflag  := -1;
		RETURN;
	END IF;

	--2.?????????????????????????????????????????
	IF v_dptacc_cde='00000019' THEN --?????
		SELECT COUNT(*)
			INTO	v_tmp_cnt
			FROM web_fin_cav_bill
			WHERE c_check_flag IN ('0','1')
			AND t_cav_tm <=TO_DATE(TO_CHAR(v_end_time,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');
	ELSE
		SELECT COUNT(*)
			INTO	v_tmp_cnt
			FROM web_fin_cav_bill
			WHERE c_check_flag IN ('0','1') AND c_dpt_cde =v_dptacc_cde
			AND t_cav_tm <=TO_DATE(TO_CHAR(v_end_time,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');
	END IF;

	IF v_tmp_cnt>0 THEN
		v_succsflag  := -2;
		RETURN;
	END IF;

	IF v_end_time>=TRUNC(SYSDATE) THEN
		v_succsflag  := -1;
		RETURN;
	END IF;

/*
	IF v_dptacc_cde='00000019' THEN --?????
		select COUNT(*)
		INTO	v_tmp_cnt
			from v_fin_cavmoney
			where  c_rp_type <200
			and c_bal_type='002001'
			and c_check_flag ='2'
			and    c_moneycheck_flag<>'2'
			AND t_cav_tm <=to_date(TO_CHAR(v_end_time,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');

	ELSE
		select COUNT(*)
		INTO	v_tmp_cnt
			from v_fin_cavmoney
			where  c_rp_type <200
			and c_bal_type='002001'
			and c_check_flag ='2'
			and    c_moneycheck_flag<>'2'
			AND c_dpt_cde =v_dptacc_cde
			AND t_cav_tm <=to_date(TO_CHAR(v_end_time,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');

	END IF;

	IF v_tmp_cnt>0 THEN
		v_succsflag  := -5;
		RETURN;
	END IF;
*/



	---3	????????????????????
	SELECT COUNT(*)
		INTO v_tmp_cnt
		FROM T_FIN_STATUS
		WHERE t_crt_tm >= TO_DATE(TO_CHAR(SYSDATE,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
			AND t_crt_tm <=TO_DATE(TO_CHAR(SYSDATE,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');

	IF v_tmp_cnt=0 THEN --???????
		v_succsflag  := -3;
		RETURN;
	END IF;


	--4.????
	/*
	IF v_dptacc_cde='00000019' THEN
		UPDATE T_DEPARTMENT
			SET c_switch_flag='0'  --??
			WHERE c_switch_flag<>'0';

		   OPEN cur_dptacc;
		    LOOP
			FETCH cur_dptacc  INTO v_otherdptacc_cde;
			EXIT WHEN cur_dptacc%NOTFOUND;
			BEGIN
				UPDATE T_DEPARTMENT
					SET c_switch_flag='0' --??
					WHERE c_dptacc_cde=v_otherdptacc_cde AND c_switch_flag<>'0';

				UPDATE T_FIN_MONTHLYCLOSING
					SET c_closing_flag='2'  --??
					WHERE  c_dptacc_cde=v_otherdptacc_cde AND c_closing_flag<>'2' ;

				--????
				v_period_name:=TO_CHAR(ADD_MONTHS(v_end_time,1),'YYYY-MM');
				INSERT INTO T_FIN_MONTHLYCLOSING(c_period_name,c_dptacc_cde)
					VALUES(v_period_name,v_otherdptacc_cde);
			END;
		    END LOOP;

		    CLOSE cur_dptacc;

	ELSE
		UPDATE T_DEPARTMENT
			SET c_switch_flag='0' --??
			WHERE c_dptacc_cde=v_dptacc_cde AND c_switch_flag<>'0';

		UPDATE T_FIN_MONTHLYCLOSING
			SET c_closing_flag='2'  --??
			WHERE  c_dptacc_cde=v_dptacc_cde AND c_closing_flag<>'2' ;

		--????
		INSERT INTO T_FIN_MONTHLYCLOSING(c_period_name,c_dptacc_cde)
			VALUES(TO_CHAR(ADD_MONTHS(v_end_time,1),'YYYY-MM'),v_dptacc_cde);
	END IF;
	*/

    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                RAISE;
                v_succsflag  := -9;

                --dbms_output.put_line('exception'||TO_CHAR(i)||'*'||SRcptNo||SQLERRM);
                IF SQLCODE < 0 THEN
                    v_succsflag := SQLCODE;
                ELSE
                    v_succsflag := -SQLCODE;
                END IF;
            END;
    END;

--7.????? Validity check(?????? Inspects accountant the period)
PROCEDURE ValidityCheck
IS

        v_tmp_cnt	INT;
	v_period_name   T_FIN_MONTHLYCLOSING.c_period_name%TYPE;
	v_end_time	WEB_BAS_FIN_ACCT_PERIOD.T_BGN_TM%TYPE;
	v_otherdptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
	v_err_content T_FIN_ERRORLOG.c_err_content%TYPE;
	v_tmpflag_cnt	INT;

        CURSOR cur_dptacc IS
            SELECT DISTINCT c_dptacc_cde
              FROM WEB_ORG_DPT
              WHERE c_dptacc_cde<>'?' AND c_dptacc_cde IS NOT NULL;

/*

??????
-1??????????????????
-2???????????????????
-3??????????
-4??????????

-9?????
 0. ??
*/


BEGIN
	SELECT COUNT(*)
		INTO v_tmp_cnt
		FROM WEB_BAS_FIN_ACCT_PERIOD
		WHERE T_bgn_tm<=TRUNC(sysdate,'MM')+15
			AND T_end_tm>=TRUNC(sysdate,'MM');


--1(?????????????????)
	IF v_tmp_cnt=0 THEN
		v_period_name:=TO_CHAR(TRUNC(SYSDATE,'MM'),'YYYY-MM');
		INSERT INTO WEB_BAS_FIN_ACCT_PERIOD(C_PERIOD_NAME,T_BGN_TM,T_END_TM)
			VALUES(v_period_name,TRUNC(SYSDATE,'MM'),TRUNC(ADD_MONTHS(SYSDATE,1),'MM')-1 );
	END IF;

--2???????????????????
	OPEN cur_dptacc;
	LOOP
	FETCH cur_dptacc  INTO v_otherdptacc_cde;
	EXIT WHEN cur_dptacc%NOTFOUND;
	BEGIN
		SELECT COUNT(*)
		INTO	v_tmp_cnt
		FROM T_FIN_MONTHLYCLOSING
		WHERE c_dptacc_cde=v_otherdptacc_cde
			AND c_closing_flag='1' ;--??

		IF v_tmp_cnt=0 THEN
			IF v_period_name IS NULL THEN
				v_period_name:=TO_CHAR(TRUNC(SYSDATE,'MM'),'YYYY-MM');
				INSERT INTO web_FIN_MONTHLYCLOSING(c_period_name,c_dptacc_cde)
					VALUES(v_period_name,v_otherdptacc_cde);
			ELSE
				INSERT INTO web_FIN_MONTHLYCLOSING(c_period_name,c_dptacc_cde)
					VALUES(v_period_name,v_otherdptacc_cde);
			END IF;
		END IF;


	END;
	COMMIT;
	END LOOP;
	CLOSE cur_dptacc;

--3?????????????

--4?????????????


--5.???????????????????????????
	SELECT COUNT(*)
		INTO v_tmp_cnt
		FROM T_FIN_MONTHLYCLOSING
		WHERE c_period_name<>TO_CHAR(SYSDATE,'YYYY-MM')
			AND c_closing_flag='1';

	IF v_tmp_cnt<>0 THEN
		OPEN cur_dptacc;
		LOOP
		FETCH cur_dptacc  INTO v_otherdptacc_cde;
		EXIT WHEN cur_dptacc%NOTFOUND;
		BEGIN

		SELECT COUNT(*)
			INTO v_tmpflag_cnt
			FROM T_FIN_MONTHLYCLOSING
			WHERE c_period_name<>TO_CHAR(SYSDATE,'YYYY-MM')
				AND c_dptacc_cde=v_otherdptacc_cde
				AND c_closing_flag='1';

			IF v_tmpflag_cnt<>0 THEN
				/*
				--??
				SELECT COUNT(*)
					INTO	v_tmp_cnt
					FROM web_fin_cav_bill
					WHERE c_check_flag IN ('0','1') AND c_dpt_cde =v_otherdptacc_cde;
				*/

				--IF v_tmp_cnt>0 THEN
					UPDATE WEB_ORG_DPT
						SET c_switch_flag='1' --??
						WHERE c_dptacc_cde=v_otherdptacc_cde;
				--END IF;

				--??
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM T_FIN_STATUS
					WHERE t_crt_tm >=TO_DATE(TO_CHAR(SYSDATE,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
						AND t_crt_tm <=TO_DATE(TO_CHAR(SYSDATE,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');


				IF v_tmp_cnt=0 THEN
					UPDATE WEB_ORG_DPT
						SET c_switch_flag='1' --??
						WHERE c_dptacc_cde=v_otherdptacc_cde ;
				END IF;
			END IF;

		END;
		COMMIT;
		END LOOP;
		CLOSE cur_dptacc;
	END IF;




EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||v_otherdptacc_cde||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[ValidityCheck],??????['||v_otherdptacc_cde||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO web_bas_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--8.???? Calculate interest
PROCEDURE Calculateinterest
IS
	v_insrnc_bgn_tm      DATE;                                           --????
	v_insrnc_end_tm        DATE;                                           --????
	v_prod_no       WEB_FIN_SAVEAMT_DUE.c_prod_no%TYPE;                    --????
	v_ply_no        WEB_FIN_SAVEAMT_DUE.c_ply_no%TYPE;
	v_dpt_cde       WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;
	plytime         NUMBER (16, 2);
	edrtime         NUMBER (16, 2);
	newedrtime      NUMBER (16, 2);
	ngetamt         NUMBER (16, 2);--??
  nsum            NUMBER (16, 2);--???
	npayamt         NUMBER (16, 2);
	npaidamt        NUMBER (16, 2);
  v_success_flag  int;--????????
	v_edr_rsn       T_EDR_BASE.c_edr_rsn%TYPE;
	v_cur_cde          WEB_FIN_SAVEAMT_DUE.c_BS_cur%TYPE;
	v_rcpt_no          WEB_FIN_SAVEAMT_DUE.c_rcpt_no%TYPE;
	v_salegrp_cde      WEB_FIN_SAVEAMT_DUE.c_slSgrp_cde%TYPE;
	chacls          WEB_FIN_SAVEAMT_DUE.c_cha_cls%TYPE;
	chacde          WEB_FIN_SAVEAMT_DUE.c_cha_cde%TYPE;
	v_sls_cde          WEB_FIN_SAVEAMT_DUE.c_sls_cde%TYPE;
	payprsncde      WEB_FIN_SAVEAMT_DUE.c_payER_cde%TYPE;
	--v_dpt_cde          WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;
	--v_monseqno      T_FIN_MONTHACCRUAL.c_mon_ret_no%TYPE;
	v_seq_no      WEB_bas_VOUCHERinfo.C_VOUCHER_CDE%TYPE;---c_seq_no???C_VOUCHER_CDE
	--v_monseqno1     T_FIN_MONTHACCRUAL.c_mon_ret_no%TYPE;
	v_seq_no1     WEB_bas_VOUCHERinfo.C_VOUCHER_CDE%TYPE;
	v_feetyp_cde     WEB_FIN_SAVEAMT_DUE.c_feetyp_cde%TYPE;
	v_newedrno      T_EDR_BASE.c_edr_no%TYPE;
	n_realflag      NUMBER (1);
	a               NUMBER (1);
	v_err_content	T_FIN_ERRORLOG.c_err_content%TYPE;
	v_crt_cde	WEB_FIN_SAVEAMT_DUE.c_crt_cde%TYPE;
	dznoflag	INT;
	v_interest_flag	VARCHAR2(2);
	v_cal_tm	T_FIN_PAYDUE.t_bal_tm%TYPE;


	v_vou_memo	WEB_FIN_MADCR.c_vou_memo%TYPE;
	v_department_cde t_fin_dcr.c_department_cde%TYPE;
	v_company_cde	WEB_FIN_MADCR.c_company_cde%TYPE;
	v_period_name	WEB_FIN_MADCR.c_period_name%TYPE;
	v_servicetype_no	WEB_FIN_MADCR.c_servicetype_no%TYPE;
	v_end_time	T_FIN_ACCNTPERIOD.c_end_tm%TYPE;
	v_dptacc_cde T_DEPARTMENT.c_dpt_cde%TYPE;
	v_maseq_no WEB_FIN_MADCR.c_seq_no%TYPE;

	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_tmp_cnt	int;
	v_add_type	t_prd_prod.c_add_type%type;


   CURSOR cur_calint
   IS
      SELECT c_ply_no, c_prod_no, NVL(n_paid_amt,0),
             TRUNC(t_insrnc_bgn_tm),
             TRUNC(t_insrnc_end_tm),
             NVL(c_BS_cur,' '), NVL(c_rcpt_no,' '), NVL(c_slSgrp_cde,' '), NVL(c_cha_cls,' '),
	     NVL(c_cha_cde,' '), NVL(c_sls_cde,' '), NVL(c_payER_cde,' '),
		 NVL(c_dpt_cde,' '),c_crt_cde,c_dptacc_CDE
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_lx_flag='0' AND c_feetyp_cde = 'G' AND n_paid_amt < 0
	   and not exists
	   (SELECT c_ply_no from t_edr_base
	   		   WHERE c_ply_no =WEB_FIN_SAVEAMT_DUE.c_ply_no
	   		   		 and c_edr_rsn in ('A1','A3','77')
	   );


       --????G?????0???????? ?????????????????????????????

BEGIN

--	return;
	--?????
	/*IF TRUNC(SYSDATE-1,'MM')<>TRUNC(ADD_MONTHS(SYSDATE,-1)) THEN
		RETURN;
	ELSE*/

		UPDATE WEB_FIN_SAVEAMT_DUE
			SET c_lx_flag='0'
			WHERE c_feetyp_cde = 'G' AND n_paid_amt < 0
		and not exists
			   (SELECT c_ply_no from t_edr_base
					   WHERE c_ply_no =WEB_FIN_SAVEAMT_DUE.c_ply_no
							 and c_edr_rsn in ('A1','A3','77')
			   );


		commit;
--	END IF;


   --????????
   v_cal_tm:=TRUNC(SYSDATE)-1;
   v_period_name:=TO_CHAR(v_cal_tm,'yyyy-mm');

   OPEN cur_calint;
   LOOP
      FETCH cur_calint
       INTO v_ply_no, v_prod_no, npaidamt, v_insrnc_bgn_tm, v_insrnc_end_tm, v_cur_cde,
            v_rcpt_no, v_salegrp_cde, chacls, chacde, v_sls_cde, payprsncde, v_dpt_cde,v_crt_cde,v_dptacc_cde;

      EXIT WHEN cur_calint%NOTFOUND;
   --??????????


	v_period_name:=TO_CHAR(SYSDATE,'YYYY-MM');
	SELECT TRUNC(t_end_tm)
		INTO v_end_time
		FROM WEB_BAS_FIN_ACCT_PERIOD
		WHERE c_period_name=v_period_name;

	v_cal_tm:=TRUNC(v_end_time);
	v_period_name:=TO_CHAR(v_cal_tm,'YYYY-MM');

	IF TRUNC(SYSDATE)-v_end_time<>1 THEN
		RETURN;
	END IF;

      SELECT SUM (NVL (n_edr_prj_no, 0))
        INTO edrtime
        FROM web_PLY_BASE
       WHERE c_ply_no = TRIM (v_ply_no);

	--?????????????
      IF edrtime = 0 AND ABS (npaidamt) > 0
      THEN
         SELECT NVL (c_resv_txt_20, 0)   --c_resv_txt_20,??
           INTO plytime
           FROM WEB_PLY_CVRG
          WHERE c_ply_no = TRIM (v_ply_no);

	SELECT nvl(c_add_type,'3')
	INTO v_add_type
	FROM t_prd_prod
	WHERE c_prod_no=v_prod_no;


	--?????? wpc
         --SELECT
         SERVICE_INTERFACE.calplytax(v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,'1',plytime,ngetamt,nsum,v_success_flag);
          -- INTO ngetamt
         --  FROM DUAL;
          v_interest_flag:='Y';
     ELSIF ABS (npaidamt) > 0 THEN

		SELECT nvl(max(c_edr_no),'xx')
		INTO v_newedrno
		FROM WEB_FIN_SAVEAMT_DUE
		WHERE c_ply_no =v_ply_no and c_edr_no is not null AND c_ply_no<>' ';

        v_newedrno :=
            Get_Newply_No (v_ply_no,
                           TO_CHAR (SYSDATE-1, 'yyyy-mm-dd hh24:mi:ss')
                          );


		IF  v_newedrno= '------' THEN
			v_interest_flag:='N';
		ELSE
			SELECT count(*)
			INTO v_tmp_cnt
			FROM T_EDR_RDR
			WHERE c_edr_no = TRIM (v_newedrno);

			IF v_tmp_cnt>0 THEN
				SELECT NVL (n_yl1, 0)
				INTO newedrtime
				FROM T_EDR_RDR
				WHERE c_edr_no = TRIM (v_newedrno);

				SELECT nvl(c_add_type,'3')
				INTO v_add_type
				FROM t_prd_prod
				WHERE c_prod_no=v_prod_no;

				--?????? wpc
--				SELECT Invst_Finc.get_profit_sum (v_add_type,
--				 v_insrnc_bgn_tm,
--				 v_insrnc_end_tm,
--				 SYSDATE-1,
--				 newedrtime
--				)
--				INTO ngetamt
--				FROM DUAL;
--????
SERVICE_INTERFACE.calplytax(v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,'1',plytime,ngetamt,nsum,v_success_flag);
--end wpc
				v_interest_flag:='Y';
			ELSE
				v_interest_flag:='N';
			END IF;
		END IF ;

      END IF;

      IF v_interest_flag='Y' THEN
	SELECT SQ_FIN_INTERESTDUE.NEXTVAL
			INTO v_seq_no
		FROM dual;

		--????
		 INSERT INTO WEB_FIN_INTERESTDUE
			     (
          C_INTERESTDUE_PK_ID,
          C_LONGSHORT_FLAG,
          C_LX_FLAG,
				  c_ply_no          ,
				  c_edr_no          ,
				  t_insrnc_bgn_tm   ,
				  t_insrnc_end_tm   ,
				  n_tms             ,
				  c_prod_no         ,
				  c_bsns_typ        ,
				  c_slsgrp_cde     ,
				  c_bs_cur        ,
				  --c_payer_cde    ,
				  c_feetyp_cde      ,
				  --n_bs_amt         ,
				  n_paid_amt        ,
				  t_pay_bgn_tm     ,
				  t_pay_end_tm      ,
				  c_pay_mde_cde     ,
				  t_paid_tm         ,
				  c_cha_mrk         ,
				  c_cha_cls         ,
				  c_cha_cde         ,
				  c_dptacc_cde       ,
				  c_dpt_cde         ,
				  c_rcpt_no         ,
				  c_prn_no          ,
				  c_opt_no          ,
				  c_rollback_mark   ,
				  c_to_fin_flag     ,
				  c_crt_cde         ,
				  t_crt_tm          ,
				  c_upd_cde         ,
				  t_upd_tm          ,
				  --t_rp_tm         ,--t_arp_tm wpc
				  c_arp_flag        ,
				  n_tax_rate        ,
				  c_compare_falg    ,
				  c_clnt_mrk        ,
				  c_bank_account    ,
				  c_sls_cde         ,
				 -- c_old_edr         ,wpc
         --c_ply_mrk,         --c_ply_mrk?????,,?????? wpc
				  C_RP_FLAG         ,
				  C_PAYER_NME       ,
				  t_due_tm          ,

				  c_tran_flag       ,
				  c_con_dpt_cde     ,
				  n_can_sum         ,
				  c_bala_mrk        ,
				  c_payer_cde       ,
				  --c_payer_nme       ,wpc
				 -- c_ply_flag        ,---??????? wpc
				  c_app_nme         ,
				  c_lcn_no          ,
				  c_main_con_cde   ,
				  c_rp_cur          ,
				  n_rp_amt          ,
				 -- n_rp_amt   ,
				  --t_paid_tm        ,
				  n_bs_amt         ,

				  t_rp_tm          ,
				  c_accnt_flag

			     )
				 SELECT
          c_saveamtdue_pk_id,
          C_LONGSHORT_FLAG,
          C_LX_FLAG,
				  c_ply_no          ,
				  c_edr_no          ,
				  t_insrnc_bgn_tm   ,
				  t_insrnc_end_tm   ,
				  n_tms             ,
				  c_prod_no         ,
				  c_bsns_typ        ,
				  c_slSgrp_cde     ,
				  c_BS_cur         ,
				  --c_payER_cde    ,
				  c_feetyp_cde      ,
				 -- ngetamt /*n_pay_amt*/,
				  0 /*n_paid_amt*/  ,
				  t_pay_bgn_tm     ,
				  t_pay_end_tm      ,
				  c_pay_mde_cde     ,
				  t_paid_tm         ,
				  c_cha_mrk         ,
				  c_cha_cls         ,
				  c_cha_cde         ,
				  c_dptacc_CDE       ,
				  c_dpt_cde         ,
				  v_seq_no/*c_rcpt_no*/         ,
				  c_prn_no          ,
				  c_opt_no          ,
				  c_rollback_mark   ,
				  c_to_fin_flag     ,
				  c_crt_cde         ,
				  SYSDATE-1/*t_crt_tm*/          ,
				  c_upd_cde         ,
				  t_upd_tm          ,
				  --t_arp_tm          ,
				  c_arp_flag        ,
				  n_tax_rate            ,
				  c_compare_falg    ,
				  c_clnt_mrk        ,
				  c_bank_account    ,
				  c_sls_cde         ,
				 -- c_old_edr         ,

				  c_rp_flag         ,--WPC c_ply_mrk
				  c_payer_nme        ,
				  v_cal_tm/*t_bal_tm*/          ,

				  c_tran_flag       ,
				  c_con_dpt_cde     ,
				  n_can_sum         ,
				  c_bala_mrk        ,
				  c_payer_cde       ,
				  --c_payer_nme       ,
				  --c_ply_flag        ,
				  c_app_nme         ,
				  c_lcn_no          ,
				  c_main_con_CDE   ,
				  NULL/*c_rp_cur*/          ,
				  0/*n_rp_amt*/          ,
				 -- 0/*n_real_paid_sum*/   ,
				 -- NULL/*t_check_tm*/     ,
				  0/*n_ply_amt*/         ,

				  NULL/*t_cav_tm*/          ,
				  '01'/*c_accnt_flag*/
		FROM WEB_FIN_SAVEAMT_DUE
		WHERE c_rcpt_no=v_rcpt_no;

		--????
		/*
		     1101(2960)
		     Dr????? 446106
		     Cr:?????? 214401
		*/
		v_vou_memo:='????';
		v_servicetype_no:='1101';
		SELECT c_company_cde,c_department_cde
			INTO v_company_cde,v_department_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde=trim(v_dpt_cde);

		--?????
		Dz_Proc.get_fin_no(v_maseq_no,v_dpt_cde,'7',dz_proc.g_pttype);

		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;

		INSERT INTO WEB_FIN_MADCR
		(
			c_seq_no           ,
			c_item_no          ,
			t_end_tm           ,
			c_cav_flag         ,
			c_sbjt_no          ,

			n_amt              ,
			c_cur_no           ,
			t_crt_tm           ,
			c_dptacc_no        ,
			c_dpt_cde          ,

			c_rcpt_no          ,
			c_sls_cde          ,
			c_prod_no          ,
			c_bsns_typ         ,
			c_cha_cls          ,

			c_cha_cde          ,
			c_salegrp_cde      ,
			C_PAY_PRSN_CDE     ,
			c_pay_prsn_name    ,
			c_ri_com           ,
			c_cont_code        ,
			c_ply_no           ,
			c_cha_mrk          ,

			c_vou_memo         ,
			c_company_cde      ,
			c_check_flag       ,
			n_total_amt        ,
			c_servicetype_no,
			c_kind_no,c_department_cde
		)
		SELECT
			  v_maseq_no           ,
			  '1'/*c_item_no*/          ,
			  SYSDATE-1/*t_end_tm*/           ,
			  '?'/*c_cav_flag*/         ,
			  '446106'          ,

			  ngetamt/*n_amt*/              ,
			  c_bs_cur/*c_cur_no*/           ,
			  v_cal_tm/*t_crt_tm*/           ,
			  c_dptacc_cde        ,
			  c_dpt_cde          ,

			  c_rcpt_no          ,
			  c_sls_cde          ,
			  c_prod_no          ,
			  c_bsns_typ         ,
			  c_cha_cls          ,
			  c_cha_cde          ,
			  c_slsgrp_cde      ,
			  NULL/*c_payER_cde*/     ,
			  NULL/*c_pay_prsn_name*/    ,
			  NULL/*c_ri_com*/           ,
			  NULL/*c_cont_code*/        ,
			  c_ply_no           ,
			  c_cha_mrk          ,

			  v_vou_memo/*c_vou_memo*/         ,
			  v_company_cde      ,
			  '0'/*c_check_flag*/       ,
			  ngetamt/*n_total_amt*/        ,
			  v_servicetype_no,
			  v_kind_no,v_department_cde
		FROM WEB_FIN_INTERESTDUE
		WHERE c_rcpt_no=v_seq_no;

		INSERT INTO WEB_FIN_MADCR
		(
			c_seq_no           ,
			c_item_no          ,
			t_end_tm           ,
			c_cav_flag         ,
			c_sbjt_no          ,

			n_amt              ,
			c_cur_no           ,
			t_crt_tm           ,
			c_dptacc_no        ,
			c_dpt_cde          ,

			c_rcpt_no          ,
			c_sls_cde          ,
			c_prod_no          ,
			c_bsns_typ         ,
			c_cha_cls          ,

			c_cha_cde          ,
			c_salegrp_cde      ,
			C_PAY_PRSN_CDE     ,
			c_pay_prsn_name    ,
			c_ri_com           ,
			c_cont_code        ,
			c_ply_no           ,
			c_cha_mrk          ,

			c_vou_memo         ,
			c_company_cde      ,
			c_check_flag       ,
			n_total_amt        ,
			c_servicetype_no,
			c_kind_no,c_department_cde
		)
		SELECT
			  v_maseq_no           ,
			  '2'/*c_item_no*/          ,
			  SYSDATE-1/*t_end_tm*/           ,
			  '?'/*c_cav_flag*/         ,
			  '214401'          ,

			  ngetamt/*n_amt*/              ,
			  c_bs_cur/*c_cur_no*/           ,
			  v_cal_tm/*t_crt_tm*/           ,
			  c_dptacc_cde      ,
			  c_dpt_cde          ,

			  c_rcpt_no          ,
			  c_sls_cde          ,
			  c_prod_no          ,
			  c_bsns_typ         ,
			  c_cha_cls          ,
			  c_cha_cde          ,
			  c_slSgrp_cde      ,
			  NULL/*c_payER_cde*/     ,
			  NULL/*c_pay_prsn_name*/    ,
			  NULL/*c_ri_com*/           ,
			  NULL/*c_cont_code*/        ,
			  c_ply_no           ,
			  c_cha_mrk          ,

			  v_vou_memo/*c_vou_memo*/         ,
			  v_company_cde      ,
			  '0'/*c_check_flag*/       ,
			  ngetamt/*n_total_amt*/        ,
			  v_servicetype_no,
			  v_kind_no,v_department_cde
		FROM WEB_FIN_INTERESTDUE
		WHERE c_rcpt_no=v_seq_no;

		UPDATE WEB_FIN_SAVEAMT_DUE
		SET c_lx_flag='1'
		WHERE c_rcpt_no=v_rcpt_no;

	END IF;

	COMMIT;
   END LOOP;

   CLOSE cur_calint;

   COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[CalculateInterest],??????['||v_rcpt_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--9.????form a fee
PROCEDURE Formafee(v_formafee_no	IN WEB_FIN_CAV_MNY.c_formafee_no%TYPE,
		   v_succsflag		IN 	 OUT    NUMBER) IS

  v_tmp_cnt	INT;
	v_period_name   t_fin_monthlyclosing.c_period_name%TYPE;
	v_end_time	t_fin_accntperiod.c_bgn_tm%TYPE;


	v_voucher_no	web_fin_dcr.c_voucher_no%TYPE;
	v_seq_no	web_fin_dcr.c_seq_no%TYPE;
	v_company_cde	web_fin_dcr.c_company_cde%TYPE;
	v_department_cde web_fin_dcr.c_department_cde%TYPE;
	v_vou_memo	web_fin_dcr.c_vou_memo%TYPE;
	v_crsbjt_no	web_fin_dcr.c_sbjt_no%TYPE;
	v_savecash_bank	WEB_FIN_CAV_MNY.c_savecash_bank%TYPE;
	v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
	v_dpt_cde 	  web_fin_cav_bill.c_dpt_cde%TYPE;
	v_servicetype_no web_fin_dcr.c_servicetype_no%TYPE;
	v_rp_type		 web_fin_cav_bill.c_rp_type%TYPE;
	v_dcrvoucher_no	web_fin_dcr.c_voucher_no%TYPE;
	v_sumcr_amt	web_fin_dcr.n_amt%TYPE;
	v_sumdr_amt	web_fin_dcr.n_amt%TYPE;
	v_bank_cde	WEB_FIN_CAV_MNY.c_bank_cde%TYPE;

	v_cav_no     	web_fin_dcr.c_cav_no%TYPE;
	v_item_no    	web_fin_dcr.c_item_no%TYPE;
	v_flag	 	web_fin_dcr.c_check_flag%TYPE;/*1 ?? 2 ??*/
	v_savecash_no	WEB_FIN_CAV_MNY.c_savecash_no%TYPE;

	i		INT;
	v_today_tm	WEB_fin_madcr.t_crt_tm%TYPE;
	v_bal_type	WEB_FIN_CAV_MNY.c_bal_typ%TYPE;
	v_drsbjt_no	web_fin_dcr.c_sbjt_no%type;
	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_cashsumcr_amt	web_fin_dcr.n_amt%TYPE;
	v_credsumcr_amt	web_fin_dcr.n_amt%TYPE;
        CURSOR cur_ifCavMoney IS
		SELECT  c_cav_pk_id,n_item_no,c_savecash_no,c_bal_typ
			FROM WEB_FIN_CAV_MNY
			WHERE c_formafee_no=trim(v_formafee_no)
			and (c_bank_cde is  null or  c_bank_cde = ' ')
				and c_bal_typ  in ('002001','002006');
BEGIN
    	v_succsflag  := 0;


	i:=0;

	SELECT SUM(n_amt)
		INTO v_sumcr_amt
	FROM WEB_FIN_CAV_MNY
	WHERE c_formafee_no=trim(v_formafee_no)
	and (c_bank_cde is  null or  c_bank_cde = ' ')
	and c_bal_typ  in ('002001','002006');

	SELECT SUM(n_amt)
		INTO v_cashsumcr_amt
	FROM WEB_FIN_CAV_MNY
	WHERE c_formafee_no=trim(v_formafee_no)
	and (c_bank_cde is  null or  c_bank_cde = ' ')
	and c_bal_typ  in ('002001');

	SELECT SUM(n_amt)
		INTO v_credsumcr_amt
	FROM WEB_FIN_CAV_MNY
	WHERE c_formafee_no=trim(v_formafee_no)
	and (c_bank_cde is  null or  c_bank_cde = ' ')
	and c_bal_typ  in ('002006');

	OPEN cur_ifCavMoney;
	LOOP
	    FETCH cur_ifCavMoney
	    INTO v_cav_no,v_item_no,v_savecash_no,v_bal_type;
	    EXIT WHEN cur_ifCavMoney%NOTFOUND;

		i:=i+1;

		SELECT  c_dpt_cde,c_rp_type
		INTO v_dpt_cde,v_rp_type
			FROM web_fin_cav_bill
			WHERE c_cav_pk_id=trim(v_cav_no);

		SELECT c_savecash_bank
			INTO v_savecash_bank
			FROM WEB_FIN_CAV_MNY
			WHERE c_cav_pk_id=trim(v_cav_no) AND n_item_no=trim(v_item_no);

		--1.??????????????????????

		SELECT COUNT(*)
		INTO	v_tmp_cnt
		FROM T_FIN_MONTHLYCLOSING
		WHERE c_dptacc_cde=trim(v_dpt_cde) AND c_closing_flag='1' ;--??

		IF v_tmp_cnt=0 THEN	--????????? 00000019
			v_succsflag  := -6;
			RETURN;
		ELSE
			SELECT c_period_name
				INTO	v_period_name
				FROM T_FIN_MONTHLYCLOSING
				WHERE c_dptacc_cde=trim(v_dpt_cde) AND c_closing_flag='1' ;--??
		END IF;


		--v_period_name:=TO_CHAR(SYSDATE,'YYYY-MM');
		SELECT TRUNC(c_end_tm)
			INTO v_end_time
			FROM T_FIN_ACCNTPERIOD
			WHERE c_period_name=v_period_name;

		--???????????
		IF TO_CHAR(SYSDATE,'YYYY-MM')<>v_period_name THEN
			v_today_tm:=v_end_time;
		ELSE
			v_today_tm:=SYSDATE;
		END IF;

		SELECT c_company_cde
			INTO v_company_cde
			FROM t_department
			WHERE c_dpt_cde=trim(v_dpt_cde);

		IF i=1 THEN
			Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_company_cde,dz_proc.g_pttype);--????????
			Dz_Proc.get_fin_no(v_seq_no,v_dpt_cde,'5',dz_proc.g_pttype);
			v_vou_memo:='??';
			v_servicetype_no:='1115';
		END IF;

		IF v_savecash_no  IS NULL THEN
			v_flag:='2';
		ELSE
			v_flag:='1';
		END IF;

		IF v_flag=1 THEN


			SELECT c_sbjt_no
				INTO v_crsbjt_no
				FROM t_fin_bank
				WHERE c_dpt_cde=trim(v_dpt_cde) AND c_bank_cde=trim(v_savecash_bank);

			IF v_bal_type='002001' THEN
				v_drsbjt_no:='100101';
			ELSE
				v_drsbjt_no:='101506';
			END IF;

			INSERT INTO web_fin_dcr
							(
								c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
								n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
								t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
								c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
								c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
								c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
								c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_voucher_no,
								c_cav_no
							)
			SELECT
								v_seq_no,i,'?',v_crsbjt_no,v_savecash_bank,
								n_amt,NULL,c_cur_cde,NULL,NULL,
								v_today_tm,v_dpt_cde,c_flow_cde,v_rp_type,NULL,
								c_bal_typ,c_savecash_no,c_check_no,t_rp_tm,NULL,
								'0',NULL,v_dpt_cde,v_vou_memo,NULL,
								NULL,v_company_cde,' ','0',' ',/*c_salegrp_cde,c_bsns_typ,c_cha_mrk*/
								v_voucher_no,v_period_name,v_sumcr_amt,v_servicetype_no,v_voucher_no,
								v_cav_no
			FROM WEB_FIN_CAV_MNY
			WHERE c_cav_pk_id=trim(v_cav_no) AND n_item_no=trim(v_item_no);


			i:=i+1;
			INSERT INTO web_fin_dcr
							(
								c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
								n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
								t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
								c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
								c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
								c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
								c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_voucher_no,
								c_cav_no
							)
			SELECT
								v_seq_no,i,'?',/*'100101'*/v_drsbjt_no,'0',
								n_amt,NULL,c_cur_cde,NULL,NULL,
								v_today_tm,v_dpt_cde,c_flow_cde,v_rp_type,NULL,
								c_bal_typ,c_bank_cde,c_check_no,t_rp_tm,NULL,
								'0',NULL,v_dpt_cde,v_vou_memo,NULL,
								NULL,v_company_cde,' ','0',' ',/*c_salegrp_cde,c_bsns_typ,c_cha_mrk*/
								v_voucher_no,v_period_name,v_sumcr_amt,v_servicetype_no,v_voucher_no,
								v_cav_no
			FROM WEB_FIN_CAV_MNY
			WHERE c_cav_pk_id=trim(v_cav_no) AND n_item_no=trim(v_item_no);




		ELSIF v_flag='2'  AND i=1 THEN --??

			--??????
			SELECT MAX(c_voucher_no)
				INTO v_dcrvoucher_no
				FROM web_fin_dcr
				WHERE c_cav_no=v_cav_no AND c_vou_memo='??';


			INSERT INTO web_fin_dcr
							(
								c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
								n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
								t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
								c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
								c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
								c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
								c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_voucher_no,
								c_cav_no
							)
			SELECT 	v_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
								-n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
								v_today_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
								c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
								'0',c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
								c_cost_cde,c_company_cde,c_salegrp_cde,/*c_bsns_typ*/'0',c_cha_mrk,
								v_voucher_no,TO_CHAR(v_today_tm,'YYYY-MM'),-n_total_amt,c_servicetype_no,v_voucher_no,
								c_cav_no
			FROM web_fin_dcr
			WHERE c_voucher_no=v_dcrvoucher_no;

			INSERT INTO web_fin_dcr_intf
			(
				c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
				n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
				t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
				c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
				c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
				c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
				c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_cav_no
			)
			SELECT
				v_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
				-n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
				v_today_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
				c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
				'0',c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
				c_cost_cde,c_company_cde,c_salegrp_cde,/*c_bsns_typ*/'0',c_cha_mrk,
				v_voucher_no,TO_CHAR(v_today_tm,'YYYY-MM'),-n_total_amt,c_servicetype_no,c_cav_no
			FROM web_fin_dcr_intf
			WHERE c_vou_no=v_dcrvoucher_no;



			UPDATE web_fin_dcr_intf
			SET c_sbjt_memo=DECODE(c_sbjt_memo,NULL,'0',' ','0',c_sbjt_memo),c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
			c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ),c_department_cde=DECODE(c_department_cde,NULL,'0',' ','0',c_department_cde)
			WHERE c_seq_no=trim(v_seq_no) ;

			/*
			UPDATE web_fin_dcr_intf
			set c_sbjt_memo=v_savecash_bank
			WHERE c_seq_no=trim(v_seq_no) AND c_sbjt_no like '1002%' ;
			*/

			UPDATE web_fin_dcr_intf
			SET c_sbjt_memo='0'
			WHERE c_seq_no=trim(v_seq_no) AND c_sbjt_no LIKE '1001%' ;


			Auto_Confirmed3.ValidityCheckCavVou(v_seq_no,v_succsflag); --wpc
			v_succsflag  := v_succsflag;
			IF v_succsflag<0 THEN
				RETURN;
			END IF;

			UPDATE WEB_FIN_CAV_MNY
				SET c_savecash_bank=NULL
				WHERE c_cav_pk_id=trim(v_cav_no) AND n_item_no=trim(v_item_no);

		END IF;

	END LOOP;
	CLOSE cur_ifCavMoney;


	IF v_flag=1 THEN	--??



			SELECT c_bank_cde
				INTO v_bank_cde
				FROM web_fin_dcr
				WHERE c_seq_no=trim(v_seq_no) AND c_bank_cde IS NOT NULL AND ROWNUM=1;

			INSERT INTO web_fin_dcr_intf
							(
								c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
								n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
								t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
								c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
								c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
								c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
								c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_cav_no
							)
			SELECT					c_seq_no,c_item_no,c_cav_flag,(SELECT c_finsbjt_no FROM t_fin_subject WHERE c_sbjt_no=web_fin_dcr.c_sbjt_no),c_sbjt_memo,
								v_sumcr_amt,n_exch_amt,DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no),n_rate,c_chr_cur_no,
								v_today_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
								c_bal_type,NULL,c_check_no,t_rp_tm,c_prod_no,
								c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
								c_cost_cde,c_company_cde,c_salegrp_cde,/*c_bsns_typ*/'0',c_cha_mrk,
								c_voucher_no,c_period_name,v_sumcr_amt,c_servicetype_no,v_formafee_no
						FROM web_fin_dcr
						WHERE c_seq_no=trim(v_seq_no) AND c_cav_flag='?' AND ROWNUM=1;

			IF  	v_cashsumcr_amt<>0 THEN
				INSERT INTO web_fin_dcr_intf
								(
									c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
									n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
									t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
									c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
									c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
									c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
									c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_cav_no
								)
				SELECT					c_seq_no,c_item_no,c_cav_flag,(SELECT c_finsbjt_no FROM t_fin_subject WHERE c_sbjt_no=web_fin_dcr.c_sbjt_no),c_sbjt_memo,
									v_cashsumcr_amt,n_exch_amt,DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no),n_rate,c_chr_cur_no,
									v_today_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
									c_bal_type,v_bank_cde,c_check_no,t_rp_tm,c_prod_no,
									c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
									c_cost_cde,c_company_cde,c_salegrp_cde,/*c_bsns_typ*/'0',c_cha_mrk,
									c_voucher_no,c_period_name,v_sumcr_amt,c_servicetype_no,v_formafee_no
							FROM web_fin_dcr
							WHERE c_seq_no=trim(v_seq_no) AND c_cav_flag='?' AND ROWNUM=1 AND c_sbjt_no='100101';
			END IF;

			IF v_credsumcr_amt<>0 THEN
				INSERT INTO web_fin_dcr_intf
								(
									c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
									n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
									t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
									c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
									c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
									c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
									c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_cav_no
								)
				SELECT					c_seq_no,c_item_no,c_cav_flag,(SELECT c_finsbjt_no FROM t_fin_subject WHERE c_sbjt_no=web_fin_dcr.c_sbjt_no),c_sbjt_memo,
									v_credsumcr_amt,n_exch_amt,DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no),n_rate,c_chr_cur_no,
									v_today_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
									c_bal_type,v_bank_cde,c_check_no,t_rp_tm,c_prod_no,
									c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
									c_cost_cde,c_company_cde,c_salegrp_cde,/*c_bsns_typ*/'0',c_cha_mrk,
									c_voucher_no,c_period_name,v_sumcr_amt,c_servicetype_no,v_formafee_no
							FROM web_fin_dcr
							WHERE c_seq_no=trim(v_seq_no) AND c_cav_flag='?' AND ROWNUM=1 and c_sbjt_no='101506';
			END IF;





			UPDATE web_fin_dcr_intf
			SET c_sbjt_memo=v_savecash_bank
			WHERE c_seq_no=trim(v_seq_no) AND c_sbjt_no LIKE '1002%' ;

			UPDATE web_fin_dcr_intf
			SET c_sbjt_memo='0'
			WHERE c_seq_no=trim(v_seq_no) AND c_sbjt_no LIKE '1001%' ;

			UPDATE web_fin_dcr_intf
			SET
			c_sbjt_memo=DECODE(c_sbjt_memo,NULL,'0',' ','0',c_sbjt_memo),c_dpt_cde=DECODE(c_dpt_cde,NULL,'0',' ','0',c_dpt_cde),c_prod_no=DECODE(c_prod_no,NULL,'0',' ','0',c_prod_no),
			c_bsns_typ=DECODE(c_bsns_typ,NULL,'0',' ','0',c_bsns_typ),c_department_cde=DECODE(c_department_cde,NULL,'0',' ','0',c_department_cde)
					WHERE c_seq_no=trim(v_seq_no) ;

			Auto_Confirmed3.ValidityCheckCavVou(v_seq_no,v_succsflag); --wpc
			v_succsflag  := v_succsflag;

			IF v_succsflag<0 THEN
				RETURN ;
			END IF;
	END IF;
/*
1.??

v_succsflag:
	0	??
	-1
	-2
	-3
	-4	????????,???????????

	-9	????
*/


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;

		dbms_output.put_line('exception'||'*'||v_cav_no||SQLERRM);


		v_err_content:='proc:[formafee],??????['||v_cav_no||'],?????['||SQLCODE||SQLERRM;



	END;
END;


--10.?????????
--PROCEDURE ValidityCheckCavVou(v_seq_no	IN       WEB_FIN_DCR.c_seq_no%type,
--      		   	      v_succsflag   	IN 	 OUT    NUMBER);

PROCEDURE ValidityCheckCavVou(v_seq_no	IN       WEB_FIN_DCR.c_seq_no%type,
      		   	      v_succsflag   	IN 	 OUT    NUMBER) IS
/*
	1.??????
	2.??????
	3.????????
	4.??????????
	5.??????

	6.?????
	7.?????
	8.??????
	-9 ????????
*/

	v_company_cde 	web_fin_dcr_intf.c_company_cde%TYPE;
	v_department_cde web_fin_dcr_intf.c_department_cde%TYPE;
	v_sbjt_no 	web_fin_dcr_intf.c_sbjt_no%TYPE;
	v_sbjt_memo	web_fin_dcr_intf.c_sbjt_memo%TYPE;
	v_prod_no 	web_fin_dcr_intf.c_prod_no%TYPE;
	v_period_name 	web_fin_dcr_intf.c_period_name%TYPE;
	v_cur_no 	web_fin_dcr_intf.c_cur_no%TYPE;
	v_dpt_cde	web_fin_dcr_intf.c_dpt_cde%TYPE;
	v_crt_tm	web_fin_dcr_intf.t_crt_tm%TYPE;
	v_wei_1		VARCHAR2(1);
	v_wei_2		VARCHAR2(1);
	v_wei_3		VARCHAR2(1);
	v_wei_4		VARCHAR2(1);
	v_wei_5		VARCHAR2(1);

	v_wei_6		VARCHAR2(1);
	v_wei_7		VARCHAR2(1);
	v_wei_8		VARCHAR2(1);
	v_wei_9		VARCHAR2(1);

	v_dr_amt 	web_fin_dcr_intf.n_amt%TYPE;
	v_cr_amt 	web_fin_dcr_intf.n_amt%TYPE;
	v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;

	v_verifyvou_memo web_fin_dcr_intf.c_verifyvou_memo%TYPE;
        v_tmp_cnt	INT;
	v_bank_cde	web_fin_dcr_intf.c_bank_cde%TYPE;
	v_rp_type	web_fin_dcr_intf.c_rp_type%TYPE;

        CURSOR cur_ifcavvou IS
		SELECT c_company_cde,c_department_cde,c_sbjt_no,c_sbjt_memo,c_prod_no,
		            	c_period_name,c_cur_no,c_dpt_cde,c_bank_cde,t_crt_tm,
		            	c_rp_type
				FROM web_fin_dcr_intf
            	WHERE c_seq_no=v_seq_no;
BEGIN
	v_succsflag  := 0;

 	--??
	OPEN cur_ifcavvou;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifcavvou
	    INTO v_company_cde,v_department_cde,v_sbjt_no,v_sbjt_memo,v_prod_no,
				    v_period_name,v_cur_no,v_dpt_cde,v_bank_cde,v_crt_tm,v_rp_type;
	    EXIT WHEN cur_ifcavvou%NOTFOUND;

		BEGIN
			IF v_rp_type='102' THEN --20090214?????????
				v_succsflag:=0;
				RETURN;
			END IF;
			--1.????????
			IF v_company_cde IS NULL OR v_company_cde = ' ' OR  v_company_cde = '?' THEN
				v_wei_1:='1';
				v_succsflag:=-1;
				RETURN;
			ELSE
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_company
					WHERE c_dpt_cde=trim(v_company_cde);

				IF v_tmp_cnt=0 THEN
					v_wei_1:='1';
					v_succsflag:=-1;
					RETURN;
				ELSE
					v_wei_1:='0';
				END IF;
			END IF;

			--2.????? ??
			IF v_department_cde IS NULL OR v_department_cde = ' ' THEN
				v_wei_2:='1';--?????? ?:???????
				v_succsflag:=-2;
				RETURN;
			ELSIF v_department_cde='0' OR v_dpt_cde='0' THEN
				IF v_sbjt_no ='214908' THEN
					v_wei_2:='1';
					v_succsflag:=-2;
					RETURN;
				ELSE
					v_wei_2:='0';
				END IF;
			ELSE
				SELECT COUNT(c_dpt_cde)
				INTO v_tmp_cnt
					FROM t_department
					WHERE c_dpt_cde =v_dpt_cde
					AND c_department_cde <>'?'
					AND  c_department_cde IS NOT NULL
					AND c_company_cde <>'?'
					AND  c_company_cde IS NOT NULL
					--AND c_ctct_cde not in ('014001','014008')
					AND LENGTH(c_dpt_cde) =8;

				IF v_tmp_cnt =0  THEN
					v_wei_2:='1';
					v_succsflag:=-2;
					RETURN;
				END IF;

				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_department
					WHERE c_dpt_cde=trim(v_department_cde);

				IF v_tmp_cnt=0 THEN
					v_wei_2:='1';
					v_succsflag:=-2;
					RETURN;
				ELSE
					v_wei_2:='0';
				END IF;
			END IF;


			--3.????? ????
			IF v_sbjt_no IS NULL  OR v_sbjt_no = ' ' THEN
				v_wei_3:='1';
				v_succsflag:=-3;
				RETURN;
			ELSE
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_subject
					WHERE c_sbjt_no=trim(v_sbjt_no);

				IF v_tmp_cnt=0 THEN
					v_wei_3:='1';
					v_succsflag:=-3;
					RETURN;
				ELSE
					v_wei_3:='0';
				END IF;
			END IF;

			--4.????? ??????
			IF v_sbjt_memo IS NULL  OR v_sbjt_memo = ' ' THEN
				v_wei_4:='4';
				v_succsflag:=-4;
				RETURN;
			ELSIF v_sbjt_memo='0' THEN
				v_wei_4:='0';
			ELSE
			/*
				SELECT count(*)
				INTO v_tmp_cnt
				FROM t_fin_bank
				WHERE c_bank_cde=v_sbjt_memo;

				IF v_tmp_cnt>0 THEN
					SELECT count(*)
					INTO v_tmp_cnt
					FROM t_fin_bank
					WHERE c_bank_cde=v_sbjt_memo
						AND c_company_cde=v_company_cde;

					IF v_tmp_cnt=0 THEN
						v_wei_4:='1';
						v_succsflag:=-4;
						return;
					END IF;
				END IF;

				v_wei_4:='0';
			*/

				v_wei_4:='0';
			END IF;


			--5.????? ??
			IF v_prod_no IS NULL OR v_prod_no=' ' THEN
				v_wei_5:='0';--???? ????????
			ELSIF v_prod_no='0' THEN
				v_wei_5:='0';
			ELSE
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_prod
					WHERE c_prod_no=trim(v_prod_no);

				IF v_tmp_cnt=0 THEN
					v_wei_5:='1';
					v_succsflag:=-5;
					RETURN;
				ELSE
					v_wei_5:='0';
				END IF;
			END IF;

			--6.??????
			IF v_period_name IS NULL  OR v_period_name = ' '  THEN
				v_wei_6:='1';
			ELSE
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_fin_accntperiod
					WHERE c_period_name=trim(v_period_name);


				IF v_tmp_cnt=0 THEN
					v_wei_6:='1';
					v_succsflag:=-6;
					RETURN;
				ELSE
					IF TO_CHAR(v_crt_tm,'YYYY-MM')<>v_period_name THEN
						v_wei_6:='1';
						v_succsflag:=-6;
						RETURN;
					ELSE
						v_wei_6:='0';

					END IF;

				END IF;
			END IF;

			--7.??????
			IF v_cur_no IS NULL   OR v_cur_no = ' ' THEN
				v_wei_7:='1';
			ELSE
				IF v_cur_no NOT IN ('CNY','HKD','USD','EUR','JPY') THEN
					v_wei_7:='1';
					v_succsflag:=-7;
					RETURN;
				ELSE
					v_wei_7:='0';
				END IF;
			END IF;

			--8.??????
			SELECT SUM(DECODE(c_cav_flag,'?',n_amt,0)),SUM(DECODE(c_cav_flag,'?',n_amt,0))
			INTO v_dr_amt,v_cr_amt
			FROM web_fin_dcr_intf
			WHERE c_seq_no=v_seq_no;



			IF v_dr_amt= v_cr_amt AND v_dr_amt<>0 AND v_cr_amt<>0 THEN
				v_wei_8:='0';
			ELSE
				--IF v_rp_type IN ('204','205') AND v_dr_amt=0 AND v_cr_amt=0 THEN
				--	v_wei_8:='0';
				--ELSE
					v_wei_8:='1';
					v_succsflag:=-8;
					RETURN;
				--END IF;
			END IF;


		END;

	END LOOP;
	CLOSE cur_ifcavvou;

		--v_verifyvou_memo:=v_wei_1||v_wei_2||v_wei_3||v_wei_4||v_wei_5||v_wei_6||v_wei_7||v_wei_8;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		 v_succsflag  := -9;
		dbms_output.put_line('exception'||'*'||v_seq_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[ValidityCheckCavVou],??????['||v_seq_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'1115',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--11.?????????
PROCEDURE ValidityCheckmaVou(v_seq_no	IN       web_fin_madcr.c_seq_no%type,
      		   	      v_succsflag   	IN 	 OUT    NUMBER) IS
/*
	1.??????
	2.??????
	3.????????
	4.??????????
	5.??????

	6.?????
	7.?????
	8.??????
	-9 ????????
*/


	v_company_cde 	t_fin_gmadcr.c_company_cde%TYPE;
	v_department_cde t_fin_gmadcr.c_department_cde%TYPE;
	v_sbjt_no 	t_fin_gmadcr.c_sbjt_no%TYPE;
	v_prod_no 	t_fin_gmadcr.c_prod_no%TYPE;
	v_period_name 	t_fin_gmadcr.c_period_name%TYPE;
	v_sbjt_memo		t_fin_gmadcr.c_sbjt_memo%TYPE;
	v_cur_no 	t_fin_gmadcr.c_cur_no%TYPE;
	v_dpt_cde	t_fin_gmadcr.c_dpt_cde%TYPE;
	v_wei_1		VARCHAR2(1);
	v_wei_2		VARCHAR2(1);
	v_wei_3		VARCHAR2(1);
	v_wei_4		VARCHAR2(1);
	v_wei_5		VARCHAR2(1);

	v_wei_6		VARCHAR2(1);
	v_wei_7		VARCHAR2(1);
	v_wei_8		VARCHAR2(1);
	v_wei_9		VARCHAR2(1);

	v_dr_amt 	t_fin_gmadcr.n_amt%TYPE;
	v_cr_amt 	t_fin_gmadcr.n_amt%TYPE;
	v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;

	v_verifyvou_memo t_fin_gmadcr.c_verifyvou_memo%TYPE;
        v_tmp_cnt	INT;
        v_crt_tm	t_fin_gmadcr.t_crt_tm%TYPE;
        CURSOR cur_ifcavvou IS
	SELECT c_company_cde,c_department_cde,c_sbjt_no,c_prod_no,
            	c_period_name,c_cur_no,c_dpt_cde,c_sbjt_memo,t_crt_tm
		FROM t_fin_gmadcr
            	WHERE c_seq_no=v_seq_no;

BEGIN
	v_succsflag  := 0;


	OPEN cur_ifcavvou;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifcavvou
	    INTO v_company_cde,v_department_cde,v_sbjt_no,v_prod_no,
		    v_period_name,v_cur_no,v_dpt_cde,v_sbjt_memo,v_crt_tm;
	    EXIT WHEN cur_ifcavvou%NOTFOUND;
		BEGIN

			--1.????????
			IF v_company_cde IS NULL OR v_company_cde = ' ' OR  v_company_cde = '?' THEN
				v_wei_1:='1';
				v_succsflag:=-1;
				RETURN;
			ELSE
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_company
					WHERE c_dpt_cde=trim(v_company_cde);

				IF v_tmp_cnt=0 THEN
					v_wei_1:='1';
					v_succsflag:=-1;
					RETURN;
				ELSE
					v_wei_1:='0';
				END IF;
			END IF;

			--2.????? ??
			IF v_department_cde IS NULL OR v_department_cde = ' ' THEN
				v_wei_2:='1';--?????? ?:???????
				RETURN;
			ELSIF v_department_cde='0' THEN
				v_wei_2:='0';
			ELSE
				SELECT COUNT(c_dpt_cde)
				INTO v_tmp_cnt
					FROM t_department
					WHERE c_dpt_cde =v_dpt_cde
					AND c_department_cde <>'?'
					AND  c_department_cde IS NOT NULL
					AND c_company_cde <>'?'
					AND  c_company_cde IS NOT NULL
					--AND c_ctct_cde not in ('014001','014008')
					AND LENGTH(c_dpt_cde) =8;

				IF v_tmp_cnt =0  THEN
					v_wei_2:='1';
					v_succsflag:=-2;
					RETURN;
				END IF;

				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_department
					WHERE c_dpt_cde=trim(v_department_cde);

				IF v_tmp_cnt=0 THEN
					v_wei_2:='1';
					v_succsflag:=-2;
					RETURN;
				ELSE
					v_wei_2:='0';
				END IF;
			END IF;


			--3.????? ????
			IF v_sbjt_no IS NULL  OR v_sbjt_no = ' ' THEN
				v_wei_3:='1';
				v_succsflag:=-3;
				RETURN;
			ELSE
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_subject
					WHERE c_sbjt_no=trim(v_sbjt_no);

				IF v_tmp_cnt=0 THEN
					v_wei_3:='1';
					v_succsflag:=-3;
					RETURN;
				ELSE
					v_wei_3:='0';
				END IF;
			END IF;

			--4.????? ??????
			IF v_sbjt_memo IS NULL  OR v_sbjt_memo = ' ' THEN
				v_wei_4:=-4;
				RETURN;
			ELSIF v_sbjt_memo='0' THEN
				v_wei_4:='0';
			ELSE
				v_wei_4:='0';
			END IF;


			--5.????? ??
			IF v_prod_no IS NULL OR v_prod_no=' ' THEN
				v_wei_5:='0';--???? ????????
			ELSIF v_prod_no='0' THEN
				v_wei_5:='0';
			ELSE
				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_oracle_prod
					WHERE c_prod_no=trim(v_prod_no);

				IF v_tmp_cnt=0 THEN
					v_wei_5:='1';
					v_succsflag:=-5;
					RETURN;
				ELSE
					v_wei_5:='0';
				END IF;
			END IF;

			--6.??????
			IF v_period_name IS NULL  OR v_period_name = ' '  THEN
				v_wei_6:='1';
			ELSE

				SELECT COUNT(*)
					INTO v_tmp_cnt
					FROM t_fin_accntperiod
					WHERE c_period_name=trim(v_period_name);

				IF v_tmp_cnt=0 THEN
					v_wei_6:='1';
					v_succsflag:=-6;
					RETURN;
				ELSE
					IF TO_CHAR(v_crt_tm,'YYYY-MM')<>v_period_name THEN
						v_wei_6:='1';
						v_succsflag:=-6;
						RETURN;
					ELSE
						v_wei_6:='0';

					END IF;
				END IF;

			END IF;

			--7.??????
			IF v_cur_no IS NULL   OR v_cur_no = ' ' THEN
				v_wei_7:='1';
			ELSE
				IF v_cur_no NOT IN ('CNY','HKD','USD','EUR','JPY') THEN
					v_wei_7:='1';
					v_succsflag:=-7;
					RETURN;
				ELSE
					v_wei_7:='0';
				END IF;
			END IF;

			--8.??????
			SELECT SUM(DECODE(c_cav_flag,'?',n_amt,0)),SUM(DECODE(c_cav_flag,'?',n_amt,0))
			INTO v_dr_amt,v_cr_amt
			FROM t_fin_gmadcr
			WHERE c_seq_no=v_seq_no;

			IF v_dr_amt= v_cr_amt THEN
				v_wei_8:='0';
			ELSE
				v_wei_8:='1';
				v_succsflag:=-8;
				RETURN;
			END IF;


		END;

	END LOOP;
	CLOSE cur_ifcavvou;
		--v_verifyvou_memo:=v_wei_1||v_wei_2||v_wei_3||v_wei_4||v_wei_5||v_wei_6||v_wei_7||v_wei_8;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		 v_succsflag  := -9;
		dbms_output.put_line('exception'||'*'||v_seq_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[ValidityCheckMaVou],??????['||v_seq_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'1115',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--12.???? Guarantee confirmation again
--PROCEDURE RiConfirm;

--12.???????? gather ribill
--PROCEDURE gatherribill;

--13.?????
PROCEDURE calpreply IS

	--???????????????????????
	--????
	v_dptacc_cde		T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;

	v_prod_no		WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_cal_amt  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_rical_amt  		WEB_FIN_PRM_DUE.n_paid_amt%TYPE;
	v_dr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_cr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;

	v_na_prm  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;	--?????
	v_edr_type 		WEB_FIN_PRM_DUE.c_edr_typ%TYPE; 	--????
	v_edr_no		WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no		WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_pre_sum		WEB_FIN_PRM_DUE.n_pre_amt%TYPE;
	v_rcpt_no		WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_bal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_cnt			INT;
	v_tmpcnt		INT;

	v_sbjt_memo		web_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo		web_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo		web_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1		web_FIN_MADCR.c_seq_no%TYPE;

	v_drsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	v_crsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag		WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_err_content	 	T_FIN_ERRORLOG.c_err_content%TYPE;
	v_servicetype_no	T_FIN_SERVICETYPE.c_no%TYPE;

	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_cal_tag	WEB_FIN_PREPLY.c_cal_tag%TYPE;
	v_cur_no		WEB_FIN_PREPLY.c_cur_cde%TYPE;
	v_cal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_company_cde	t_department.c_company_cde%TYPE;
	v_period_name    web_fin_dcr_intf.c_period_name%TYPE;
	v_department_cde web_fin_dcr_intf.c_department_cde%TYPE;
	v_cal_typ	 WEB_FIN_PREPLY.c_cal_typ%type;

	v_succsflag 	 INT;

        --c_company_cde,c_department_cde,c_period_name,
	--,c_cal_tag--,c_cur_no
	--c_ply_no,c_edr_no,t_cal_tm--,t_crt_tm
	--c_sbjt_no,c_sbjt_memo

	--???????
        CURSOR cur_ifcalpre IS
	SELECT c_dpt_cde,c_cur_cde,c_prod_no,c_cal_typ,SUM(n_cal_amt),SUM(n_rical_amt),TRUNC(t_cal_tm)
		FROM WEB_FIN_PREPLY
		WHERE  t_cal_tm <= TRUNC(SYSDATE) 		--????
			AND c_vou_no IS NULL
			AND t_cal_tm>=SYSDATE -10
		GROUP BY c_dpt_cde,c_cur_cde,c_prod_no,c_cal_typ,TRUNC(t_cal_tm);

BEGIN

	--???
	OPEN cur_ifcalpre;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifcalpre
	    INTO v_dpt_cde,v_cur_no,v_prod_no,v_cal_typ,v_cal_amt,v_rical_amt,v_cal_tm;
	    EXIT WHEN cur_ifcalpre%NOTFOUND;
	    --v_cal_tag,v_ply_no,v_edr_no,

		--????????????????????????????????t_department??
		SELECT  c_dptacc_cde,c_company_cde,c_department_cde
			INTO v_dptacc_cde,v_company_cde,v_department_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde =trim(v_dpt_cde);

		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;

		SELECT TO_CHAR(v_cal_tm,'YYYY-MM')
		INTO v_period_name
		FROM DUAL;

		v_cal_tm:=TRUNC(v_cal_tm);
/*

		5.2????????
			?????
			?1???????????????????
			?2??????
			1129 ????????????
			???????????????????122301	1129 ????????????
				????????????????450201

			1429 ????????????
			??????????????-????????????122302
				????????????-???????????450202



			?1???????????????????
			?2??????
			1131 ??????????
			?????????????????450201	??????????-????????
				??????????????216201	????????-????????


			1431 ??????????????
			????????????????????450202
				?????????? ???????216202




		-- ??????????

*/
		--???????
		IF v_rical_amt<>0 THEN
			--?????
			--Dz_Proc.get_fin_voucode(vTmpVouNo,v_period_name,v_company_cde);
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'9',dz_proc.g_pttype);
			v_dr_amt:=-v_rical_amt;
			v_cr_amt:=-v_rical_amt;

			IF v_cal_typ<>'3' THEN
				v_drsbjt_no:='122301';
				v_crsbjt_no:='450201';
				v_vou_memo:='????????????';
				v_servicetype_no:='1129';
			ELSE
				v_drsbjt_no:='122302';
				v_crsbjt_no:='450202';
				v_vou_memo:='????????????';
				v_servicetype_no:='1429';
			END IF;



			INSERT INTO web_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'1' ,'?' ,v_drsbjt_no ,v_dr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_dr_amt
			);

			INSERT INTO web_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'2' ,'?' ,v_crsbjt_no ,v_cr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_dr_amt
			);

			/*
				INSERT INTO T_FIN_GMADCR
				(
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
						c_vou_memo,c_send_flag,c_bsns_typ,
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				)
				SELECT
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no) ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_kind_no,
						c_vou_memo,c_send_flag,'0',
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				FROM web_FIN_MADCR
				WHERE c_seq_no=vTmpVouNo;

				Auto_confirmed.ValidityCheckMaVou(vTmpVouNo,v_succsflag);

					IF v_succsflag <0 THEN
						ROLLBACK;
						v_err_content:='proc:[calpreply ri],??????['||to_char(v_succsflag)||v_dpt_cde||v_prod_no||v_cur_no||TO_CHAR(v_cal_tm,'YYYY-MM-DD')||v_dptacc_cde||v_vou_memo||'],?????['||SQLCODE||SQLERRM;

						INSERT INTO T_FIN_ERRORLOG
						(
							c_err_no,
							c_errtype_no,
							c_tran_type,
							c_err_content,
							t_crt_tm
						)
						VALUES(
							F_Fin_Getcode('e'),
							'001',	--??????
							'0000',	--??????
							v_err_content,
							SYSDATE
						);
						commit;

					END IF;
			*/
		END IF;


		--???????
		IF v_cal_amt<>0 THEN
			--?????
			--Dz_Proc.get_fin_voucode(vTmpVouNo,v_period_name,v_company_cde);
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'9',dz_proc.g_pttype);
			v_dr_amt:=v_cal_amt;
			v_cr_amt:=v_cal_amt;

			IF v_cal_typ<>'3' THEN
				v_drsbjt_no:='450201';
				v_crsbjt_no:='216201';
				v_vou_memo:='??????????';
				v_servicetype_no:='1131';
			ELSE
				v_drsbjt_no:='450202';
				v_crsbjt_no:='216202';
				v_vou_memo:='??????????????';
				v_servicetype_no:='1431';
			END IF;


			INSERT INTO web_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'1' ,'?' ,v_drsbjt_no ,v_dr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			INSERT INTO web_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'2' ,'?' ,v_crsbjt_no ,v_cr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			/*
				INSERT INTO T_FIN_GMADCR
				(
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
						c_vou_memo,c_send_flag,c_bsns_typ,
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				)
				SELECT
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no) ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_kind_no,
						c_vou_memo,'0','0',
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				FROM web_FIN_MADCR
				WHERE c_seq_no=vTmpVouNo;
				Auto_confirmed.ValidityCheckMaVou(vTmpVouNo,v_succsflag);

					IF v_succsflag <0 THEN
						ROLLBACK;
						v_err_content:='proc:[calpreply],??????['||to_char(v_succsflag)||v_dpt_cde||v_prod_no||v_cur_no||TO_CHAR(v_cal_tm,'YYYY-MM-DD')||v_dptacc_cde||v_vou_memo||'],?????['||SQLCODE||SQLERRM;

						INSERT INTO T_FIN_ERRORLOG
						(
							c_err_no,
							c_errtype_no,
							c_tran_type,
							c_err_content,
							t_crt_tm
						)
						VALUES(
							F_Fin_Getcode('e'),
							'001',	--??????
							'0000',	--??????
							v_err_content,
							SYSDATE
						);
						commit;
					ELSE
						commit;
					END IF;
			*/
		END IF;

		--??????
		UPDATE WEB_FIN_PREPLY
		SET c_vou_no=vTmpVouNo
		WHERE 	c_dpt_cde=v_dpt_cde
			AND c_cur_cde=v_cur_no
			AND c_prod_no=v_prod_no
			AND c_cal_typ=v_cal_typ
			AND c_vou_no IS NULL
			AND t_cal_tm >= TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
			AND t_cal_tm <=TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');
		commit;

	END LOOP;
	CLOSE cur_ifcalpre;


--?????????????
COMMIT;


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[calpreply],??????['||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;


--14.?????????-???
PROCEDURE calpreclmreport IS

	--???????????????????????
	--????
	v_dptacc_cde		WEB_ORG_DPT.c_dptacc_cde%TYPE;
	v_dpt_cde		WEB_ORG_DPT.c_dpt_cde%TYPE;

	v_prod_no		WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_cal_amt  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_rical_amt  		WEB_FIN_PRM_DUE.n_paid_amt%TYPE;
	v_dr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_cr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;

	v_na_prm  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;	--?????
	v_edr_type 		WEB_FIN_PRM_DUE.c_edr_typ%TYPE; 	--????
	v_edr_no		WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no		WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_pre_sum		WEB_FIN_PRM_DUE.n_pre_amt%TYPE;
	v_rcpt_no		WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_bal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_cnt			INT;
	v_tmpcnt		INT;

	v_sbjt_memo		WEB_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo		WEB_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo		WEB_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1		WEB_FIN_MADCR.c_seq_no%TYPE;

	v_drsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	v_crsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag		WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_err_content	 	WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
	v_servicetype_no	T_FIN_SERVICETYPE.c_no%TYPE;

	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_cal_tag	web_fin_preclm.c_cal_tag%TYPE;
	v_cur_no		web_fin_preclm.c_cur_cde%TYPE;
	v_cal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_company_cde	WEB_ORG_DPT.c_company_cde%TYPE;
	v_period_name    web_fin_dcr_intf.c_period_name%TYPE;
	v_department_cde web_fin_dcr_intf.c_department_cde%TYPE;
	v_succsflag 	 INT;
        --c_company_cde,c_department_cde,c_period_name,
	--,c_cal_tag--,c_cur_no
	--c_ply_no,c_edr_no,t_cal_tm--,t_crt_tm
	--c_sbjt_no,c_sbjt_memo

	--???????
        CURSOR cur_ifcalpre IS
	SELECT /*+ index (web_fin_preclm IDX_FIN_PRECLM_CAL_DPT)*/ c_dpt_cde,c_cur_cde,c_prod_no,SUM(n_cal_amt),SUM(n_rical_amt),TRUNC(t_cal_tm)
		FROM web_fin_preclm
		WHERE  t_cal_tm <= TRUNC(SYSDATE) 		--????
		AND t_cal_tm>=SYSDATE -10
			AND c_vou_no IS NULL
			AND c_clm_type='3'
		GROUP BY c_dpt_cde,c_cur_cde,c_prod_no,TRUNC(t_cal_tm);

BEGIN

	--???
	OPEN cur_ifcalpre;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifcalpre
	    INTO v_dpt_cde,v_cur_no,v_prod_no,v_cal_amt,v_rical_amt,v_cal_tm;
	    EXIT WHEN cur_ifcalpre%NOTFOUND;
	    --v_cal_tag,v_ply_no,v_edr_no,

		--????????????????????????????????WEB_ORG_DPT??
		SELECT  c_dptacc_cde,c_company_cde,c_department_cde
			INTO v_dptacc_cde,v_company_cde,v_department_cde
			FROM WEB_ORG_DPT
			WHERE c_dpt_cde =trim(v_dpt_cde);

		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;

		SELECT TO_CHAR(v_cal_tm,'YYYY-MM')
		INTO v_period_name
		FROM DUAL;
		v_cal_tm:=TRUNC(v_cal_tm);

/*
		5.1???????
		5.1?????
		?1??????????????????
		?????????????-?????? 122401 	1127 ???????????
			???????????-IBNR 122402  	1148 ????????????????
		???????????-?????? 421101
			?????????- IBNR 421102


		?2??????????????????
		???????????-?????? 450101 	1133 ?????????
			?????????-IBNR 450102 		1135 ????????????
			?????????-???? 450103 	1152 ?????????
		?????????-???????????????  216101
			???????-IBNR	216102
			???????-????  421103



		122401,???????????/???????????
		122402,???????????/IBNR
		122403,???????????/????

		450101,?????????/???
		450102,?????????/IBNR
		450103,?????????/????

		421101,?????????/??????
		421102,?????????/??????
		421103,?????????/????

		216101,???????/???
		216102,???????/IBNR
		216103,???????/???????
*/
		--???????
		IF v_rical_amt<>0 THEN
			--?????
			--Dz_Proc.get_fin_voucode(vTmpVouNo,v_period_name,v_company_cde);
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'9',dz_proc.g_pttype);
			v_dr_amt:=-v_rical_amt;
			v_cr_amt:=-v_rical_amt;


			v_drsbjt_no:='122401';
			v_crsbjt_no:='421101';
			v_vou_memo:='???????????';
			v_servicetype_no:='1127';



			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'1' ,'?' ,v_drsbjt_no ,v_dr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_dr_amt
			);

			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'2' ,'?' ,v_crsbjt_no ,v_cr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_dr_amt
			);
			/*
				INSERT INTO T_FIN_GMADCR
				(
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
						c_vou_memo,c_send_flag,c_bsns_typ,
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				)
				SELECT
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no) ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_kind_no,
						c_vou_memo,c_send_flag,'0',
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				FROM WEB_FIN_MADCR
				WHERE c_seq_no=vTmpVouNo;

				Auto_confirmed.ValidityCheckMaVou(vTmpVouNo,v_succsflag);
					IF v_succsflag <0 THEN
						ROLLBACK;
						v_err_content:='proc:[ri calpreclmreport],??????['||to_char(v_succsflag)||v_dpt_cde||v_prod_no||v_cur_no||TO_CHAR(v_cal_tm,'YYYY-MM-DD')||v_dptacc_cde||v_vou_memo||'],?????['||SQLCODE||SQLERRM;

						INSERT INTO WEB_BAS_FIN_ERRORLOG
						(
							c_err_no,
							c_errtype_no,
							c_tran_type,
							c_err_content,
							t_crt_tm
						)
						VALUES(
							F_Fin_Getcode('e'),
							'001',	--??????
							'0000',	--??????
							v_err_content,
							SYSDATE
						);
						commit;
					END IF;
			*/
		END IF;


		--???????
		IF v_cal_amt<>0 THEN
			--?????
			--Dz_Proc.get_fin_voucode(vTmpVouNo,v_period_name,v_company_cde);
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'9',dz_proc.g_pttype);

			v_dr_amt:=v_cal_amt;
			v_cr_amt:=v_cal_amt;

			v_drsbjt_no:='450101';
			v_crsbjt_no:='216101';
			v_vou_memo:='?????????';
			v_servicetype_no:='1133';




			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'1' ,'?' ,v_drsbjt_no ,v_dr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'2' ,'?' ,v_crsbjt_no ,v_cr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			/*
				INSERT INTO T_FIN_GMADCR
				(
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
						c_vou_memo,c_send_flag,c_bsns_typ,
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				)
				SELECT
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no) ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_kind_no,
						c_vou_memo,'0','0',
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				FROM WEB_FIN_MADCR
				WHERE c_seq_no=vTmpVouNo;
				Auto_confirmed.ValidityCheckMaVou(vTmpVouNo,v_succsflag);

				IF v_succsflag <0 THEN
					ROLLBACK;
					v_err_content:='proc:[calpreclmreport],??????['||to_char(v_succsflag)||v_dpt_cde||v_prod_no||v_cur_no||TO_CHAR(v_cal_tm,'YYYY-MM-DD')||v_dptacc_cde||v_vou_memo||'],?????['||SQLCODE||SQLERRM;

					INSERT INTO WEB_BAS_FIN_ERRORLOG
					(
						c_err_no,
						c_errtype_no,
						c_tran_type,
						c_err_content,
						t_crt_tm
					)
					VALUES(
						F_Fin_Getcode('e'),
						'001',	--??????
						'0000',	--??????
						v_err_content,
						SYSDATE
					);
					commit;
				ELSE
					commit;
				END IF;
			*/

		END IF;

		--??????
		UPDATE web_fin_preclm
		SET c_vou_no=vTmpVouNo
		WHERE 	c_dpt_cde=v_dpt_cde
			AND c_cur_cde=v_cur_no
			AND c_prod_no=v_prod_no
			AND c_clm_type='3'
			AND c_vou_no IS NULL
			AND t_cal_tm >= TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
			AND t_cal_tm <=TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');
		commit;
	END LOOP;
	CLOSE cur_ifcalpre;


--?????????????
COMMIT;


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[calpreclmreport],??????['||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--14.?????????-???
PROCEDURE calpreclmnoreport IS

	--???????????????????????
	--????
	v_dptacc_cde		T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;

	v_prod_no		WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_cal_amt  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_rical_amt  		WEB_FIN_PRM_DUE.n_paid_amt%TYPE;
	v_dr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_cr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;

	v_na_prm  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;	--?????
	v_edr_type 		WEB_FIN_PRM_DUE.c_Edr_Typ%TYPE; 	--????
	v_edr_no		WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no		WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_pre_sum		WEB_FIN_PRM_DUE.n_pre_amt%TYPE;
	v_rcpt_no		WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_bal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_cnt			INT;
	v_tmpcnt		INT;

	v_sbjt_memo		WEB_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo		WEB_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo		WEB_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1		WEB_FIN_MADCR.c_seq_no%TYPE;

	v_drsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	v_crsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag		WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_err_content	 	web_bas_FIN_ERRORLOG.c_err_content%TYPE;
	v_servicetype_no	T_FIN_SERVICETYPE.c_no%TYPE;

	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_cal_tag	WEB_fin_preclm.c_cal_tag%TYPE;
	v_cur_no		WEB_fin_preclm.c_cur_cde%TYPE;
	v_cal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_company_cde	t_department.c_company_cde%TYPE;
	v_period_name    web_fin_dcr_intf.c_period_name%TYPE;
	v_department_cde web_fin_dcr_intf.c_department_cde%TYPE;
	v_succsflag 	 INT;
        --c_company_cde,c_department_cde,c_period_name,
	--,c_cal_tag--,c_cur_no
	--c_ply_no,c_edr_no,t_cal_tm--,t_crt_tm
	--c_sbjt_no,c_sbjt_memo

	--???????
        CURSOR cur_ifcalpre IS
	SELECT /*+ index (WEB_fin_preclm IDX_FIN_PRECLM_CAL_DPT)*/c_dpt_cde,c_cur_cde,c_prod_no,SUM(n_cal_amt),SUM(n_rical_amt),TRUNC(t_cal_tm)
		FROM WEB_fin_preclm
		WHERE  t_cal_tm <= TRUNC(SYSDATE) 		--????
		AND t_cal_tm>=SYSDATE -10
			AND c_vou_no IS NULL
			AND c_clm_type='4'
		GROUP BY c_dpt_cde,c_cur_cde,c_prod_no,TRUNC(t_cal_tm);

BEGIN

	--???
	OPEN cur_ifcalpre;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifcalpre
	    INTO v_dpt_cde,v_cur_no,v_prod_no,v_cal_amt,v_rical_amt,v_cal_tm;
	    EXIT WHEN cur_ifcalpre%NOTFOUND;
	    --v_cal_tag,v_ply_no,v_edr_no,

		--????????????????????????????????t_department??
		SELECT  c_dptacc_cde,c_company_cde,c_department_cde
			INTO v_dptacc_cde,v_company_cde,v_department_cde
			FROM T_DEPARTMENT
			WHERE c_dpt_cde =trim(v_dpt_cde);

		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;
		v_cal_tm:=TRUNC(v_cal_tm);
		SELECT TO_CHAR(v_cal_tm,'YYYY-MM')
		INTO v_period_name
		FROM DUAL;
/*

/*
		5.1???????
		5.1?????
		?1??????????????????
		?????????????-?????? 122401 	1127 ???????????
			???????????-IBNR 122402  	1148 ????????????????
		???????????-?????? 421101
			?????????- IBNR 421102


		?2??????????????????
		???????????-?????? 450101 	1133 ?????????
			?????????-IBNR 450102 		1135 ????????????
			?????????-???? 450103 	1152 ?????????
		?????????-???????????????  216101
			???????-IBNR	216102
			???????-????  421103



		122401,???????????/???????????
		122402,???????????/IBNR
		122403,???????????/????

		450101,?????????/???
		450102,?????????/IBNR
		450103,?????????/????

		421101,?????????/??????
		421102,?????????/??????
		421103,?????????/????

		216101,???????/???
		216102,???????/IBNR
		216103,???????/???????
*/



		--???????
		IF v_rical_amt<>0 THEN
			--?????
			--Dz_Proc.get_fin_voucode(vTmpVouNo,v_period_name,v_company_cde);
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'9',dz_proc.g_pttype);
			v_dr_amt:=-v_rical_amt;
			v_cr_amt:=-v_rical_amt;

			v_drsbjt_no:='122402';
			v_crsbjt_no:='421102';
			v_vou_memo:='????????????????';
			v_servicetype_no:='1148';



			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'1' ,'?' ,v_drsbjt_no ,v_dr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_dr_amt
			);

			INSERT INTO web_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'2' ,'?' ,v_crsbjt_no ,v_cr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_dr_amt
			);

			/*
				INSERT INTO T_FIN_GMADCR
				(
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
						c_vou_memo,c_send_flag,c_bsns_typ,
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				)
				SELECT
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no) ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_kind_no,
						c_vou_memo,c_send_flag,'0',
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				FROM WEB_FIN_MADCR
				WHERE c_seq_no=vTmpVouNo;

				Auto_confirmed.ValidityCheckMaVou(vTmpVouNo,v_succsflag);
				IF v_succsflag <0 THEN
					ROLLBACK;
					v_err_content:='proc:[calpreclmnoreport],??????['||to_char(v_succsflag)||v_dpt_cde||v_prod_no||v_cur_no||TO_CHAR(v_cal_tm,'YYYY-MM-DD')||v_dptacc_cde||v_vou_memo||'],?????['||SQLCODE||SQLERRM;

					INSERT INTO web_bas_FIN_ERRORLOG
					(
						c_err_no,
						c_errtype_no,
						c_tran_type,
						c_err_content,
						t_crt_tm
					)
					VALUES(
						F_Fin_Getcode('e'),
						'001',	--??????
						'0000',	--??????
						v_err_content,
						SYSDATE
					);
					commit;
				END IF;
			*/
		END IF;


		--???????
		IF v_cal_amt<>0 THEN
			--?????
			--Dz_Proc.get_fin_voucode(vTmpVouNo,v_period_name,v_company_cde);
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'9',dz_proc.g_pttype);
			v_dr_amt:=v_cal_amt;
			v_cr_amt:=v_cal_amt;

			v_drsbjt_no:='450102';
			v_crsbjt_no:='216102';
			v_vou_memo:='????????????';
			v_servicetype_no:='1135';



			INSERT INTO web_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'1' ,'?' ,v_drsbjt_no ,v_dr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'2' ,'?' ,v_crsbjt_no ,v_cr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			/*
			INSERT INTO T_FIN_GMADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
			)
			SELECT
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no) ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_kind_no,
					c_vou_memo,'0','0',
					c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
			FROM WEB_FIN_MADCR
			WHERE c_seq_no=vTmpVouNo;
			Auto_confirmed.ValidityCheckMaVou(vTmpVouNo,v_succsflag);
			IF v_succsflag <0 THEN
				ROLLBACK;
				v_err_content:='proc:[ri calpreclmnoreport],??????['||to_char(v_succsflag)||v_dpt_cde||v_prod_no||v_cur_no||TO_CHAR(v_cal_tm,'YYYY-MM-DD')||v_dptacc_cde||v_vou_memo||'],?????['||SQLCODE||SQLERRM;

				INSERT INTO web_bas_FIN_ERRORLOG
				(
					c_err_no,
					c_errtype_no,
					c_tran_type,
					c_err_content,
					t_crt_tm
				)
				VALUES(
					F_Fin_Getcode('e'),
					'001',	--??????
					'0000',	--??????
					v_err_content,
					SYSDATE
				);
				commit;
			ELSE
				commit;
			END IF;
			*/

		END IF;

		--??????
		UPDATE WEB_fin_preclm
		SET c_vou_no=vTmpVouNo
		WHERE 	c_dpt_cde=v_dpt_cde
			AND c_cur_cde=v_cur_no
			AND c_prod_no=v_prod_no
			AND c_clm_type='4'
			AND c_vou_no IS NULL
			AND t_cal_tm >= TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
			AND t_cal_tm <=TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');
		commit;

	END LOOP;
	CLOSE cur_ifcalpre;


--?????????????
COMMIT;


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[calpreclmnoreport],??????['||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM;

		INSERT INTO web_bas_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--15.??????
--PROCEDURE gatherrihistorybill;

--16.??????????????????????????????????
--PROCEDURE Supplementclmcharge;

--17.--??????????
PROCEDURE buactualprem
IS
	v_dptacc_cde		T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;

	v_prod_no		WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_pre_sum 		WEB_FIN_PRM_DUE.n_BS_AMT%TYPE;
	v_edr_type 		WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
	v_edr_no		WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no		WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_rcpt_no		WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_bal_tm		WEB_FIN_PRM_DUE.t_DUE_tm%TYPE;


	v_cav_flag		WEB_FIN_DCR.c_cav_flag%TYPE;
	v_cnt			INT;
	v_tmpcnt		INT;
	v_sbjt_no		WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_sbjt_memo		WEB_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo		WEB_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo		WEB_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1		WEB_FIN_MADCR.c_seq_no%TYPE;

	vSbjtNo			WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag		WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_feetyp_cde		T_FIN_PAYDUE.c_feetyp_cde%TYPE;
	v_tran_flag		T_FIN_PAYDUE.c_tran_flag%TYPE;
	v_err_content	 	T_FIN_ERRORLOG.c_err_content%TYPE;
    	v_seq_no    		WEB_FIN_DCR.c_seq_no%TYPE;
    	v_item_no    		WEB_FIN_DCR.c_item_no%TYPE;

	vToday  		VARCHAR(10);
	vBillToday  		VARCHAR(10);
	v_servicetype_no	WEB_FIN_DCR.c_servicetype_no%TYPE;
	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_department_cde	WEB_FIN_DCR.c_department_cde%TYPE;
	v_company_cde		WEB_FIN_DCR.c_company_cde%TYPE;

	--??????
        CURSOR cur_ifPrmInfo IS
	SELECT c_dpt_cde,
		c_prod_no,
		c_ply_no,
		n_BS_AMT,
		c_rcpt_no,
		t_DUE_tm
	FROM WEB_FIN_PRM_DUE
	WHERE c_arp_flag = '2'
	AND n_BS_AMT=n_PAID_AMT
	AND t_DUE_tm >= TO_DATE('2007-07-01'||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
	AND t_DUE_tm <= SYSDATE;

BEGIN

--?????????
	--??
	OPEN cur_ifPrmInfo;
	LOOP
	    FETCH cur_ifPrmInfo
	    INTO v_dpt_cde,
                                             v_prod_no,
                                             v_ply_no,
                                             v_pre_sum,
                                             v_rcpt_no,
                                             v_bal_tm;
	    EXIT WHEN cur_ifPrmInfo%NOTFOUND;

		SELECT c_department_cde,c_company_cde,c_dptacc_cde
		INTO v_department_cde,v_company_cde,v_dptacc_cde
		FROM t_department
		WHERE c_dpt_cde=v_dpt_cde;


		v_bal_tm:=TRUNC(v_bal_tm);
		IF v_bal_tm=TO_DATE('2007-03-31','yyyy-mm-dd') THEN
			 v_bal_tm:=SYSDATE;
		END IF;

		--?????
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;

		v_vou_memo:='??????????';
		v_servicetype_no:='1001';
		v_bal_tm:=TRUNC(v_bal_tm);
		--?????
		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE  ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,C_PAY_PRSN_CDE ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_ply_no,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_servicetype_no,c_kind_no,
			c_department_cde,c_company_cde,c_period_name)
		SELECT vTmpVouNo,
		   '1',
		   '?',
		   '212101',
		   v_pre_sum,
		   c_BS_cur,
		   v_bal_tm,
		   v_dptacc_cde,
		   c_dpt_cde,
		   c_rcpt_no,
		   C_SLS_CDE,
		   C_PROD_NO,
		   C_CHA_CLS,
		   C_CHA_CDE,
		   C_SLSGRP_CDE,
		   C_PAYER_CDE,
		  NULL,
		  NULL,
		  NULL,
		  '0',
		   C_bsns_typ,
		   C_PAYER_NME,
		   '0',--v_sbjt_memo,
		   c_ply_no,c_cha_mrk,
		   v_vou_memo,c_con_dpt_cde,v_servicetype_no,v_kind_no,
		   v_department_cde,v_company_cde,TO_CHAR(v_bal_tm,'YYYY-MM')
		FROM WEB_FIN_PRM_DUE
		WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no))
		--AND c_prod_no NOT IN  ('0001','0002','0003');
		and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);


		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,C_PAY_PRSN_CDE ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_ply_no,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_servicetype_no,c_kind_no,
			c_department_cde,c_company_cde,c_sbjt_memo,c_period_name)
		SELECT vTmpVouNo,
		    '2',
		    '?',
		    '112201',
		    v_pre_sum,
		    c_BS_cur,
		    v_bal_tm,
		    v_dptacc_cde,
		    c_dpt_cde,
		    c_rcpt_no,
		    C_SLS_CDE,
		    C_PROD_NO,
		    C_CHA_CLS,
		    C_CHA_CDE,
		    C_SLSGRP_CDE,
		    C_PAYER_CDE,
		   NULL,
		   NULL,
		   NULL,
		   '0',
		    C_bsns_typ,
		    C_PAYER_NME,
		    c_ply_no,
		    c_cha_mrk,
		    v_vou_memo,c_con_dpt_cde,v_servicetype_no,v_kind_no,
		    v_department_cde,v_company_cde,'0',TO_CHAR(v_bal_tm,'YYYY-MM')
		FROM WEB_FIN_PRM_DUE
		WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no)) --AND c_prod_no NOT IN  ('0001','0002','0003');
		and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);

		/*
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
		v_vou_memo:='??????';
		v_servicetype_no:='1000';

		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE  ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SLSGRP_CDE ,C_PAYER_CDE ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_sbjt_memo,c_ply_no,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_servicetype_no,c_kind_no,
			c_department_cde,c_company_cde,c_period_name)
		SELECT vTmpVouNo,
		   '1',
		   '?',
		   '112201',
		   v_pre_sum,
		   c_BS_cur,
		   v_bal_tm,
		   v_dptacc_cde,
		   c_dpt_cde,
		   c_rcpt_no,
		   C_SLS_CDE,
		   C_PROD_NO,
		   C_CHA_CLS,
		   C_CHA_CDE,
		   C_SLSGRP_CDE,
		   C_PAYER_CDE,
		  NULL,
		  NULL,
		  NULL,
		  '0',
		   C_bsns_typ,
		   C_PAYER_NME,
		   '0',--v_sbjt_memo,
		   c_ply_no,c_cha_mrk,
		   v_vou_memo,c_con_dpt_cde,v_servicetype_no,v_kind_no,
		   v_department_cde,v_company_cde,to_char(v_bal_tm,'YYYY-MM')
		FROM WEB_FIN_PRM_DUE
		WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no))  --AND c_prod_no NOT IN  ('0001','0002','0003');
		and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);



		INSERT INTO WEB_FIN_MADCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SLSGRP_CDE ,C_PAYER_CDE ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_ply_no,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_servicetype_no,c_kind_no,
			c_department_cde,c_company_cde,c_sbjt_memo,c_period_name)
		SELECT vTmpVouNo,
		    '2',
		    '?',
		    '410101',
		    v_pre_sum,
		    c_BS_cur,
		    v_bal_tm,
		    v_dptacc_cde,
		    c_dpt_cde,
		    c_rcpt_no,
		    C_SLS_CDE,
		    C_PROD_NO,
		    C_CHA_CLS,
		    C_CHA_CDE,
		    C_SLSGRP_CDE,
		    C_PAYER_CDE,
		   NULL,
		   NULL,
		   NULL,
		   '0',
		    C_bsns_typ,
		    C_PAYER_NME,
		    c_ply_no,
		    c_cha_mrk,
		    v_vou_memo,c_con_dpt_cde,v_servicetype_no,v_kind_no,
		    v_department_cde,v_company_cde,'0',to_char(v_bal_tm,'YYYY-MM')
		FROM WEB_FIN_PRM_DUE
		WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no)) --AND c_prod_no NOT IN  ('0001','0002','0003');
		and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);
		*/

		/*????*/
		UPDATE WEB_FIN_PRM_DUE
			SET c_arp_flag='5',t_upd_tm=SYSDATE
			WHERE  c_rcpt_no = RTRIM(LTRIM(v_rcpt_no)) ;
			commit;

	END LOOP;
	CLOSE cur_ifPrmInfo;

COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		ROLLBACK;
		dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);
		v_err_content:='proc:[buactualprem],??????['||v_rcpt_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO web_bas_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;


	END;
END;


--18.???????
/*
	1.?????
	2.??????
	3.????
	4.??????=????

	????:?????(???)?ORACLE????
		??????????/????ORACLE????
*/

--19.??????
PROCEDURE Cancelhistory(v_rcpt_no	IN       WEB_FIN_PRM_DUE.c_rcpt_no%TYPE,v_bank_no IN web_bas_fin_bank.c_bank_cde%TYPE)
IS
	v_dptacc_cde		T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;

	v_prod_no		WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_pre_sum 		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_edr_type 		WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
	v_edr_no		WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no		WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_bal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;

	v_cav_flag		WEB_FIN_DCR.c_cav_flag%TYPE;
	v_cnt			INT;
	v_tmpcnt		INT;
	v_sbjt_no		T_FIN_MADCR.c_sbjt_no%TYPE;
	v_sbjt_memo		T_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo		T_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo		T_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1		T_FIN_MADCR.c_seq_no%TYPE;

	vSbjtNo			WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag		WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_feetyp_cde		T_FIN_PAYDUE.c_feetyp_cde%TYPE;
	v_tran_flag		T_FIN_PAYDUE.c_tran_flag%TYPE;
	v_err_content	 	T_FIN_ERRORLOG.c_err_content%TYPE;
    	v_seq_no    		WEB_FIN_DCR.c_seq_no%TYPE;
    	v_item_no    		WEB_FIN_DCR.c_item_no%TYPE;


	vToday  		VARCHAR(10);
	vBillToday  		VARCHAR(10);

	v_servicetype_no	WEB_FIN_DCR.c_servicetype_no%TYPE;
	v_kind_no		t_fin_prod.c_prod_no%TYPE;
	v_department_cde	WEB_FIN_DCR.c_department_cde%TYPE;
	v_company_cde		WEB_FIN_DCR.c_company_cde%TYPE;

	v_drcav_flag	t_fin_madcr.c_cav_flag%TYPE;
	v_crcav_flag	t_fin_madcr.c_cav_flag%TYPE;
	v_drsbjt_no	t_fin_madcr.c_sbjt_no%TYPE;
	v_crsbjt_no	t_fin_madcr.c_sbjt_no%TYPE;
  v_voucher_no WEB_FIN_DCR.c_voucher_no%TYPE;
  v_period_name WEB_FIN_DCR.c_period_name%TYPE;
	--??????
        CURSOR cur_ifPrmInfo IS
	SELECT c_dpt_cde,
		c_prod_no,
		c_ply_no,
		n_bs_amt,
		t_insrnc_bgn_tm
	FROM WEB_FIN_PRM_DUE
	WHERE  c_rcpt_no=v_rcpt_no AND n_bs_amt=n_paid_amt;

BEGIN

--?????????
	--??
	OPEN cur_ifPrmInfo;
	LOOP
	    FETCH cur_ifPrmInfo
	    INTO v_dpt_cde,
                                             v_prod_no,
                                             v_ply_no,
                                             v_pre_sum,
                                             v_bal_tm;
	    EXIT WHEN cur_ifPrmInfo%NOTFOUND;

		SELECT c_department_cde,c_company_cde,c_dptacc_cde
		INTO v_department_cde,v_company_cde,v_dptacc_cde
		FROM t_department
		WHERE c_dpt_cde=v_dpt_cde;


		v_bal_tm:=TRUNC(SYSDATE);


		--?????
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;

		v_vou_memo:='????';
		v_servicetype_no:='1102';

		v_drcav_flag:='?';
		v_crcav_flag:='?';

		IF v_bank_no IS NOT NULL THEN
			SELECT c_sbjt_no
				INTO v_drsbjt_no
				FROM t_fin_bank
				WHERE c_bank_cde=v_bank_no AND c_dpt_cde=v_dptacc_cde;
			v_sbjt_memo:=v_bank_no;
			v_crsbjt_no:='112201';
		ELSE
			v_drsbjt_no:='100101';
			v_crsbjt_no:='112201';
			v_sbjt_memo:='0';
		END IF;

		v_period_name:=TO_CHAR(SYSDATE,'yyyy-mm');

		Dz_Proc.get_fin_voucode(v_voucher_no,v_period_name,v_company_cde,dz_proc.g_pttype);


		INSERT INTO WEB_FIN_DCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,C_DPTACC_NO ,
			C_SEND_FLAG,
			c_sbjt_memo,c_kind_no,
			c_department_cde,c_company_cde,c_period_name,c_vou_memo,c_voucher_no,c_vou_no,n_total_amt,c_rcpt_no,c_servicetype_no)
		SELECT vTmpVouNo, '1', v_drcav_flag, v_drsbjt_no,  -v_pre_sum,
		   c_bs_cur,SYSDATE, v_dptacc_cde,

		  '0',
		   v_sbjt_memo,'0',
		   '0',v_company_cde,TO_CHAR(v_bal_tm,'YYYY-MM'),v_vou_memo,v_voucher_no,v_voucher_no,-v_pre_sum,c_rcpt_no,v_servicetype_no
		FROM WEB_FIN_PRM_DUE
		WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no))  --AND c_prod_no NOT IN  ('0001','0002','0003');
		and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);


		INSERT INTO WEB_FIN_DCR(C_SEQ_NO ,C_ITEM_NO ,C_CAV_FLAG ,C_SBJT_NO ,N_AMT ,
			C_CUR_NO ,T_CRT_TM ,
			C_DPTACC_NO ,C_DPT_CDE ,C_RCPT_NO,
			C_SLS_CDE ,C_PROD_NO ,
			C_CHA_CLS ,C_CHA_CDE ,C_SALEGRP_CDE ,c_pay_prsn_cde ,C_RI_COM ,
			C_CONT_CODE ,C_VOU_NO ,C_SEND_FLAG,C_bsns_typ,C_pay_prsn_name,
			c_ply_no,c_cha_mrk,c_vou_memo,c_con_dpt_cde,c_servicetype_no,c_kind_no,
			c_department_cde,c_company_cde,c_sbjt_memo,c_period_name,c_voucher_no,n_total_amt)
		SELECT vTmpVouNo,
		    '2',
		    v_crcav_flag,
		    v_crsbjt_no,
		    -v_pre_sum,
		    c_bs_cur,
		    SYSDATE,
		    v_dptacc_cde,
		    c_dpt_cde,
		    c_rcpt_no,
		    C_SLS_CDE,
		    C_PROD_NO,
		    C_CHA_CLS,
		    C_CHA_CDE,
		    C_SLSGRP_CDE,
		    C_PAYER_CDE,
		   NULL,
		   NULL,
		   v_voucher_no,
		   '0',
		    C_bsns_typ,
		    C_PAYER_NME,
		    c_ply_no,
		    c_cha_mrk,
		    v_vou_memo,c_con_dpt_cde,v_servicetype_no,v_kind_no,
		    v_department_cde,v_company_cde,'0',TO_CHAR(v_bal_tm,'YYYY-MM'),v_voucher_no,-v_pre_sum
		FROM WEB_FIN_PRM_DUE
		WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no)) --AND c_prod_no NOT IN  ('0001','0002','0003');
		and not exists (select 1 from t_prd_prod where c_kind_no='00' and c_prod_no=WEB_FIN_PRM_DUE.c_prod_no);


		/*????*/
		UPDATE WEB_FIN_PRM_DUE
			SET c_arp_flag='1',t_upd_tm=SYSDATE,n_paid_amt=0,n_rp_amt=0
			WHERE  c_rcpt_no = RTRIM(LTRIM(v_rcpt_no)) ;

		UPDATE WEB_FIN_PRM_DUE
			SET c_accnt_flag='00'
			WHERE  c_rcpt_no = RTRIM(LTRIM(v_rcpt_no)) AND t_due_tm >SYSDATE;

		UPDATE WEB_FIN_PRM_DUE
			SET c_accnt_flag='01'
			WHERE  c_rcpt_no = RTRIM(LTRIM(v_rcpt_no)) AND t_due_tm <SYSDATE;


		INSERT INTO web_fin_dcr_intf
						(
							c_seq_no,c_item_no,c_cav_flag,c_sbjt_no,c_sbjt_memo,
							n_amt,n_exch_amt,c_cur_no,n_rate,c_chr_cur_no,
							t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
							c_bal_type,c_bank_cde,c_check_no,t_rp_tm,c_prod_no,
							c_send_flag,c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
							c_cost_cde,c_company_cde,c_salegrp_cde,c_bsns_typ,c_cha_mrk,
							c_vou_no,c_period_name,n_total_amt,c_servicetype_no,c_department_cde,c_rcpt_no
						)
		SELECT					c_seq_no,c_item_no,c_cav_flag,(SELECT c_finsbjt_no FROM t_fin_subject WHERE c_sbjt_no=WEB_FIN_DCR.c_sbjt_no),c_sbjt_memo,
							n_amt,n_exch_amt,DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no),n_rate,c_chr_cur_no,
							t_crt_tm,c_dptacc_no,c_flow_no,c_rp_type,c_ri_com,
							c_bal_type,NULL,c_check_no,t_rp_tm,c_kind_no,
							'0',c_cont_code,c_dpt_cde,c_vou_memo,c_con_dpt_cde,
							c_cost_cde,c_company_cde,c_salegrp_cde,/*c_bsns_typ*/'0',c_cha_mrk,
							c_voucher_no,c_period_name,n_amt,c_servicetype_no,c_department_cde,c_rcpt_no
					FROM WEB_FIN_DCR
					WHERE c_seq_no=vTmpVouNo;
	commit;

	END LOOP;
	CLOSE cur_ifPrmInfo;

COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		ROLLBACK;
		dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);
		v_err_content:='proc:[cancelhistory],??????['||v_rcpt_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;


	END;
END;

--20. ????	??????????????????	1??????????????? 2??? 5 ??? ?
/*
	113101????/????
	113102????/????
	113103????/????
	113104????/????
*/
PROCEDURE ClmCategories IS
	--????
	v_dpt_cde		WEB_ORG_DPT.c_dpt_cde%TYPE;
	v_eac_dcm_mrk		WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
	v_cur_typ		WEB_FIN_CLM_DUE.c_bs_cur%TYPE;
	v_batch_no		WEB_FIN_CLM_DUE.c_batch_no%TYPE;
	v_bala_mrk		WEB_FIN_CLM_DUE.c_bala_mrk%TYPE;
	v_err_content WEB_BAS_fin_errorlog.c_err_content%TYPE;

	--??(?????????????) ???????????????????????
        CURSOR cur_ifclmInfo IS
	SELECT a.c_dpt_cde,a.c_eac_dcm_mrk,a.c_bs_cur,a.c_bala_mrk
	     FROM WEB_FIN_CLM_DUE a,WEB_ORG_DPT b
	     WHERE a.c_dpt_cde=b.c_dpt_cde
	     AND a.c_batch_no IS NULL
	     AND a.c_feetyp_cde IS NULL
	     AND a.c_bala_mrk IN ('0','2','3') -- ?????????
	     AND a.n_paid_amt=0
	     AND LENGTH(b.c_dpt_cde)=8
	     AND b.c_company_cde<>'?'
	     AND b.c_department_cde<>'?'
	     AND a.n_bs_amt <>0
	     AND b.c_company_cde IS NOT NULL
	     AND b.c_department_cde IS NOT NULL
	     AND a.c_eac_dcm_mrk IN ('1','2','5','6')
	     AND a.n_bs_amt >0
	     AND a.t_crt_tm  >= TO_DATE('2007-05-08 00:00:00','YYYY-MM-DD HH24:MI:SS')
	     AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS')
	     GROUP BY a.c_dpt_cde,a.c_eac_dcm_mrk,a.c_bs_cur,a.c_bala_mrk;


BEGIN

	update WEB_FIN_CLM_DUE a
	set c_batch_no=null
	     WHERE a.c_batch_no IS NOT NULL
	     AND a.c_feetyp_cde IS NULL
	     AND a.c_bala_mrk IN ('0','2','3') -- ?????????
	     AND a.n_paid_amt=0
	     AND a.n_bs_amt <>0
	     AND a.c_eac_dcm_mrk IN ('1','2','5','6')
	     AND a.n_bs_amt >0
	     AND a.t_crt_tm  >= TO_DATE('2007-05-08 00:00:00','YYYY-MM-DD HH24:MI:SS')
	     AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS');

	--???????
--	Auto_confirmed.newClmCategories;


	OPEN cur_ifclmInfo;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifclmInfo
	    INTO v_dpt_cde,v_eac_dcm_mrk,v_cur_typ,v_bala_mrk;
	    EXIT WHEN cur_ifclmInfo%NOTFOUND;

		--?????
		Dz_Proc.get_fin_no(v_batch_no,v_dpt_cde,'7',dz_proc.g_pttype);


		UPDATE WEB_FIN_CLM_DUE a
		SET c_batch_no=v_batch_no
		WHERE c_dpt_cde=v_dpt_cde
			 AND c_eac_dcm_mrk=v_eac_dcm_mrk
			 AND c_bs_cur=v_cur_typ
			 AND c_bala_mrk=v_bala_mrk
		     AND c_batch_no IS NULL
		     AND c_feetyp_cde IS NULL
		     AND c_bala_mrk IN ('0','2','3') -- ?????????
		     AND n_paid_amt=0
		     AND n_bs_amt <>0
		     AND c_eac_dcm_mrk IN ('1','2','5','6')
			 AND a.n_bs_amt >0
	     		AND t_crt_tm  >= TO_DATE('2007-05-08 00:00:00','YYYY-MM-DD HH24:MI:SS')
	     		AND t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS');
		commit;
	END LOOP;
	CLOSE cur_ifclmInfo;

COMMIT;


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||v_dpt_cde||v_eac_dcm_mrk||v_cur_typ||SQLERRM);
		ROLLBACK;


		v_err_content:='proc:[ClmCategories],??????['||v_dpt_cde||v_eac_dcm_mrk||v_cur_typ||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;
PROCEDURE newClmCategories IS
	--????
	v_dpt_cde		T_DEPARTMENT.c_dpt_cde%TYPE;
	v_eac_dcm_mrk		WEB_fin_clm_due.c_eac_dcm_mrk%TYPE;
	v_cur_typ		WEB_fin_clm_due.c_bs_cur%TYPE;
	v_batch_no		WEB_fin_clm_due.c_batch_no%TYPE;
	v_bala_mrk		WEB_fin_clm_due.c_bala_mrk%TYPE;
	v_err_content t_fin_errorlog.c_err_content%TYPE;

	--??(?????????????) ???????????????????????
        CURSOR cur_ifclmInfo IS
	SELECT a.c_dpt_cde,a.c_eac_dcm_mrk,a.c_bs_cur,a.c_bala_mrk
	     FROM WEB_fin_clm_due a,t_department b
	     WHERE a.c_dpt_cde=b.c_dpt_cde
	     AND a.c_batch_no IS NULL
	     AND a.c_feetyp_cde IS NULL
	     AND a.c_bala_mrk IN ('0','2','3') -- ?????????
	     AND a.n_paid_amt=0
	     AND LENGTH(b.c_dpt_cde)=8
	     AND b.c_company_cde<>'?'
	     AND b.c_department_cde<>'?'
	     AND a.n_bs_amt <>0
	     AND b.c_company_cde IS NOT NULL
	     AND b.c_department_cde IS NOT NULL
	     AND a.c_eac_dcm_mrk IN ('1','2','5','6')
	     AND a.n_bs_amt >0
	     AND a.t_crt_tm  >= TO_DATE('2008-12-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
--	     AND not exists (SELECT 1 FROM t_fin_tmpbigsavedue where c_ply_no=a.c_ply_no)
	     --AND a.t_crt_tm  <= TO_DATE('2008-06-05 23:59:50','YYYY-MM-DD HH24:MI:SS')
	     and exists (select 1 from t_fin_rpclmcustomer where c_bala_mrk='6'  and c_capital_flows not in ('6','7')  and c_rcpt_no=a.c_rcpt_no)
	     GROUP BY a.c_dpt_cde,a.c_eac_dcm_mrk,a.c_bs_cur,a.c_bala_mrk;


BEGIN

	update WEB_fin_clm_due a
	SET c_batch_no=null
	     WHERE a.c_batch_no IS NOT NULL
	     AND a.c_feetyp_cde IS NULL
	     AND a.c_bala_mrk IN ('0','2','3') -- ?????????
	     AND a.n_paid_amt=0
	     AND a.n_bs_amt <>0
	     AND a.c_eac_dcm_mrk IN ('1','2','5','6')
	     AND a.n_bs_amt >0
	     AND a.t_crt_tm  >= TO_DATE('2008-12-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
--	     AND not exists (SELECT 1 FROM t_fin_tmpbigsavedue where c_ply_no=a.c_ply_no)
	     and exists (select 1 from t_fin_rpclmcustomer where c_bala_mrk='6'
	     and c_capital_flows not in ('6','7')
	     and c_rcpt_no=a.c_rcpt_no);

	OPEN cur_ifclmInfo;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifclmInfo
	    INTO v_dpt_cde,v_eac_dcm_mrk,v_cur_typ,v_bala_mrk;
	    EXIT WHEN cur_ifclmInfo%NOTFOUND;

		--?????
		Dz_Proc.get_fin_no(v_batch_no,v_dpt_cde,'7',dz_proc.g_pttype);


		UPDATE WEB_fin_clm_due a
		SET c_batch_no=v_batch_no,C_tpupd_no=v_batch_no,T_tp_tm=sysdate
		WHERE c_dpt_cde=v_dpt_cde
			 AND c_eac_dcm_mrk=v_eac_dcm_mrk
			 AND c_bs_cur=v_cur_typ
			 AND c_bala_mrk=v_bala_mrk
		     AND c_batch_no IS NULL
		     AND c_feetyp_cde IS NULL
		     AND c_bala_mrk IN ('0','2','3') -- ?????????
		     AND n_paid_amt=0
		     AND n_bs_amt <>0
			 AND c_eac_dcm_mrk IN ('1','2','5','6')
--			 AND not exists (SELECT 1 FROM t_fin_tmpbigsavedue where c_ply_no=a.c_ply_no)
			 AND a.n_bs_amt >0
			 and exists (select 1 from t_fin_rpclmcustomer where c_bala_mrk='6'  and c_capital_flows not in ('6','7')  and c_rcpt_no=a.c_rcpt_no)
	     		 AND t_crt_tm  >= TO_DATE('2008-12-01 00:00:00','YYYY-MM-DD HH24:MI:SS');

		commit;
	END LOOP;
	CLOSE cur_ifclmInfo;

COMMIT;


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||v_dpt_cde||v_eac_dcm_mrk||v_cur_typ||SQLERRM);
		ROLLBACK;


		v_err_content:='proc:[newClmCategories],??????['||v_dpt_cde||v_eac_dcm_mrk||v_cur_typ||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--21.??????? 216103   ???????/???????
PROCEDURE calpreclmpay IS

	--???????????????????????
	--????
	v_dptacc_cde		WEB_ORG_DPT.c_dptacc_cde%TYPE;
	v_dpt_cde		WEB_ORG_DPT.c_dpt_cde%TYPE;

	v_prod_no		WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_cal_amt  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_rical_amt  		WEB_FIN_PRM_DUE.n_paid_amt%TYPE;
	v_dr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_cr_amt	  	WEB_FIN_PRM_DUE.n_bs_amt%TYPE;

	v_na_prm  		WEB_FIN_PRM_DUE.n_bs_amt%TYPE;	--?????
	v_edr_type 		WEB_FIN_PRM_DUE.c_edr_typ%TYPE; 	--????
	v_edr_no		WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no		WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_pre_sum		WEB_FIN_PRM_DUE.n_pre_amt%TYPE;
	v_rcpt_no		WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_bal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_cnt			INT;
	v_tmpcnt		INT;

	v_sbjt_memo		WEB_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo		WEB_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo		WEB_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1		WEB_FIN_MADCR.c_seq_no%TYPE;

	v_drsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	v_crsbjt_no		WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag		WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_err_content	 	T_FIN_ERRORLOG.c_err_content%TYPE;
	v_servicetype_no	T_FIN_SERVICETYPE.c_no%TYPE;

	v_kind_no	t_fin_prod.c_prod_no%TYPE;
	v_cal_tag	web_fin_preclm.c_cal_tag%TYPE;
	v_cur_no		web_fin_preclm.c_cur_cde%TYPE;
	v_cal_tm		WEB_FIN_PRM_DUE.t_due_tm%TYPE;
	v_company_cde	WEB_ORG_DPT.c_company_cde%TYPE;
	v_period_name    web_fin_dcr_intf.c_period_name%TYPE;
	v_department_cde web_fin_dcr_intf.c_department_cde%TYPE;
	v_succsflag 	 INT;
        --c_company_cde,c_department_cde,c_period_name,
	--,c_cal_tag--,c_cur_no
	--c_ply_no,c_edr_no,t_cal_tm--,t_crt_tm
	--c_sbjt_no,c_sbjt_memo

	--???????
        CURSOR cur_ifcalpre IS
	SELECT /*+ index (web_fin_preclm IDX_FIN_PRECLM_CAL_DPT)*/c_dpt_cde,c_cur_cde,c_prod_no,SUM(n_cal_amt),SUM(n_rical_amt),TRUNC(t_cal_tm)
		FROM web_fin_preclm
		WHERE  t_cal_tm <= TRUNC(SYSDATE) 		--????
		AND t_cal_tm>=SYSDATE -10
			AND c_vou_no IS NULL
			AND c_clm_type='5'
		GROUP BY c_dpt_cde,c_cur_cde,c_prod_no,TRUNC(t_cal_tm);

BEGIN

	--???
	OPEN cur_ifcalpre;
	LOOP
	    <<GOTO_LAB>>
	    FETCH cur_ifcalpre
	    INTO v_dpt_cde,v_cur_no,v_prod_no,v_cal_amt,v_rical_amt,v_cal_tm;
	    EXIT WHEN cur_ifcalpre%NOTFOUND;
	    --v_cal_tag,v_ply_no,v_edr_no,

		--????????????????????????????????WEB_ORG_DPT??
		SELECT  c_dptacc_cde,c_company_cde,c_department_cde
			INTO v_dptacc_cde,v_company_cde,v_department_cde
			FROM WEB_ORG_DPT
			WHERE c_dpt_cde =trim(v_dpt_cde);

		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;

		SELECT TO_CHAR(v_cal_tm,'YYYY-MM')
		INTO v_period_name
		FROM DUAL;
/*
		5.1???????
		5.1?????
		?1??????????????????
		?????????????-?????? 122401 	1127 ???????????
			???????????-IBNR 122402  	1148 ????????????????
		???????????-?????? 421101
			?????????- IBNR 421102


		?2??????????????????
		???????????-?????? 450101 	1133 ?????????
			?????????-IBNR 450102 		1135 ????????????
			?????????-???? 450103 	1152 ?????????
		?????????-???????????????  216101
			???????-IBNR	216102
			???????-????  216103



		122401,???????????/???????????
		122402,???????????/IBNR
		122403,???????????/????

		450101,?????????/???
		450102,?????????/IBNR
		450103,?????????/????

		421101,?????????/??????
		421102,?????????/??????
		421103,?????????/????

		216101,???????/???
		216102,???????/IBNR
		216103,???????/???????


*/



		--???????
		IF v_cal_amt<>0 THEN
			--?????
			--Dz_Proc.get_fin_voucode(vTmpVouNo,v_period_name,v_company_cde);
			Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'9',dz_proc.g_pttype);

			v_dr_amt:=v_cal_amt;
			v_cr_amt:=v_cal_amt;

			v_drsbjt_no:='450103';
			v_crsbjt_no:='216103';
			v_vou_memo:='?????????';
			v_servicetype_no:='1152';

			v_cal_tm:=TRUNC(v_cal_tm);

			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'1' ,'?' ,v_drsbjt_no ,v_dr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			INSERT INTO WEB_FIN_MADCR
			(
					c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
					c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
					c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
					c_kind_no,c_vou_memo,c_send_flag,c_bsns_typ,
					c_rcpt_no,c_vou_no,c_voucher_no,c_servicetype_no,n_total_amt
			)
			VALUES
			(
				vTmpVouNo,'2' ,'?' ,v_crsbjt_no ,v_cr_amt ,
				v_cur_no ,v_cal_tm ,v_period_name,'0',
				v_dpt_cde,v_dptacc_cde,v_company_cde,v_department_cde,v_prod_no,
				v_kind_no,v_vou_memo,'0','0',
				vTmpVouNo,NULL,NULL,v_servicetype_no,v_cr_amt
			);

			/*
				INSERT INTO T_FIN_GMADCR
				(
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						c_cur_no ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_prod_no,
						c_vou_memo,c_send_flag,c_bsns_typ,
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				)
				SELECT
						c_seq_no ,c_item_no ,c_cav_flag ,c_sbjt_no,n_amt ,
						DECODE(c_cur_no,'01','CNY','02','HKD','03','USD','12','EUR','13','EUR','05','JPY',c_cur_no) ,t_crt_tm ,c_period_name,c_sbjt_memo,
						c_dpt_cde,c_dptacc_no,c_company_cde,c_department_cde,c_kind_no,
						c_vou_memo,'0','0',
						c_rcpt_no,c_vou_no,c_servicetype_no,n_total_amt
				FROM WEB_FIN_MADCR
				WHERE c_seq_no=vTmpVouNo;

				Auto_confirmed.ValidityCheckMaVou(vTmpVouNo,v_succsflag);
				IF v_succsflag <0 THEN
					ROLLBACK;
					v_err_content:='proc:[ri calpreclmpay],??????['||to_char(v_succsflag)||v_dpt_cde||v_prod_no||v_cur_no||TO_CHAR(v_cal_tm,'YYYY-MM-DD')||v_dptacc_cde||v_vou_memo||'],?????['||SQLCODE||SQLERRM;

					INSERT INTO T_FIN_ERRORLOG
					(
						c_err_no,
						c_errtype_no,
						c_tran_type,
						c_err_content,
						t_crt_tm
					)
					VALUES(
						F_Fin_Getcode('e'),
						'001',	--??????
						'0000',	--??????
						v_err_content,
						SYSDATE
					);
					commit;
				ELSE
					commit;
				END IF;
			*/

		END IF;

		--??????
		UPDATE web_fin_preclm
		SET c_vou_no=vTmpVouNo
		WHERE 	c_dpt_cde=v_dpt_cde
			AND c_cur_cde=v_cur_no
			AND c_prod_no=v_prod_no
			AND c_clm_type='5'
			AND c_vou_no IS NULL
			AND t_cal_tm >= TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
			AND t_cal_tm <=TO_DATE(TO_CHAR(v_cal_tm,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');
			commit;

	END LOOP;
	CLOSE cur_ifcalpre;


--?????????????
COMMIT;


EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		dbms_output.put_line('exception'||'*'||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM);
		ROLLBACK;

		v_err_content:='proc:[calpreclmpay],??????['||vTmpVouNo||v_dpt_cde||v_cur_no||v_prod_no||SQLERRM;

		INSERT INTO WEB_BAS_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;

	END;
END;

--22.????
PROCEDURE forceclosemonth
IS
	v_tmp_cnt 	 INT;

BEGIN



	IF TRUNC(SYSDATE-1,'MM')=TRUNC(ADD_MONTHS(SYSDATE,-1)) THEN
		--????????
		UPDATE WEB_FIN_SAVEAMT_DUE
			SET c_lx_flag='0'
			WHERE c_feetyp_cde = 'G' AND n_paid_amt < 0
		and not exists
			   (SELECT c_ply_no from t_edr_base
					   WHERE c_ply_no =WEB_FIN_SAVEAMT_DUE.c_ply_no
							 and c_edr_rsn in ('A1','A3','77')
			   );



		--????????
		SELECT COUNT(*)
		INTO v_tmp_cnt
			FROM T_FIN_MONTHLYCLOSING
			WHERE  c_period_name=TO_CHAR(ADD_MONTHS(SYSDATE,-1),'yyyy-mm') AND c_closing_flag='1';

		IF v_tmp_cnt>0 THEN
			UPDATE WEB_FIN_MONTHLYCLOSING
			SET c_period_name=TO_CHAR(SYSDATE,'YYYY-MM'),c_closing_flag='1'
			WHERE  c_period_name=TO_CHAR(ADD_MONTHS(SYSDATE,-1),'yyyy-mm') AND c_closing_flag='1';

		END IF;

		--??????
		SELECT COUNT(*)
		INTO v_tmp_cnt
			FROM t_fin_accntperiod
			WHERE  c_period_name=TO_CHAR(SYSDATE,'YYYY-MM');

		IF v_tmp_cnt=0 THEN
			insert into WEB_BAS_FIN_ACCT_PERIOD(c_period_name,T_bgn_tm,T_end_tm,c_crt_cde,t_crt_tm,c_upd_cde,t_upd_tm)
			values(TO_CHAR(SYSDATE,'YYYY-MM'),trunc(sysdate),trunc(ADD_MONTHS(SYSDATE,1)-1),'admin',sysdate,'admin',sysdate);
		END IF;

	END IF;


END;


--23.???????????
PROCEDURE cancelmonths IS
 	--????????????

         v_seq_no                web_fin_madcr_intf.c_seq_no%TYPE;
         v_vou_no                web_fin_madcr_intf.c_vou_no%TYPE;
         v_company_cde		web_fin_madcr_intf.c_company_cde%TYPE;
         v_period_name		web_fin_madcr_intf.c_period_name%TYPE;
 		v_voucher_no		WEB_fin_madcr.c_voucher_no%TYPE;
 		v_succsflag		INT;
 		v_err_content	t_fin_errorlog.c_err_content%TYPE;


         CURSOR cur_ifchrg IS
 	SELECT DISTINCT c_vou_no,c_company_cde
 		FROM web_fin_madcr_intf
 		WHERE   c_con_dpt_cde IS NULL
 		AND t_crt_tm =trunc(sysdate,'MM')-1  --to_date('2007-04-30','YYYY-MM-DD')
 		AND c_check_flag='2'
 		AND c_servicetype_no='1101';
 BEGIN
 	return;
 	/*
 	?????????
 	--?????
 	IF TRUNC(SYSDATE-1,'MM')<>TRUNC(ADD_MONTHS(SYSDATE,-1)) THEN
 		RETURN;
 	END IF;
 	*/

 	IF trunc(sysdate,'MM')+14<>TRUNC(SYSDATE) THEN
 		return;
 	END IF;

 	/*3???????*/
         OPEN cur_ifchrg;
         LOOP
             FETCH cur_ifchrg INTO v_vou_no,v_company_cde;
             EXIT WHEN cur_ifchrg%NOTFOUND;

 		   SELECT 	TO_CHAR(ADD_MONTHS(t_crt_tm,1),'YYYY-MM')
 		   INTO v_period_name
 		   FROM web_fin_madcr_intf
 		   WHERE c_vou_no=v_vou_no AND ROWNUM =1;


 		   Dz_Proc.get_fin_prevoucode(v_voucher_no,v_period_name,v_company_cde,dz_proc.g_pttype);

 			INSERT INTO WEB_fin_madcr
 			(
 			  c_seq_no           ,
 			  c_item_no          ,
 			  c_cav_flag         ,
 			  c_sbjt_no          ,
 			  n_amt              ,
 			  c_cur_no           ,
 			  t_crt_tm           ,
 			  c_dptacc_no        ,
 			  c_dpt_cde          ,
 			  c_rcpt_no          ,
 			  c_sls_cde          ,
 			  c_prod_no          ,
 			  c_cha_cls          ,
 			  c_cha_cde          ,
 			  c_salegrp_cde      ,
 			  c_pay_prsn_cde     ,
 			  c_ri_com           ,
 			  c_cont_code        ,
 			  c_vou_no           ,
 			  c_send_flag        ,
 			  t_end_tm           ,
 			  c_bsns_typ         ,
 			  c_pay_prsn_name    ,
 			  c_sbjt_memo        ,
 			  c_ply_no           ,
 			  c_cha_mrk          ,
 			  c_finbank_cde      ,
 			  c_vou_memo         ,
 			  c_company_cde      ,
 			  c_cost_cde         ,
 			  c_current_dpt_cde  ,
 			  c_con_dpt_cde      ,
 			  c_check_flag       ,
 			  c_period_name      ,
 			  c_voucher_no       ,
 			  n_total_amt        ,
 			  c_servicetype_no   ,
 			  c_department_cde   ,
 			  c_kind_no
 			  )
 			  SELECT
 				  'C'||c_seq_no           ,
 				  c_item_no          ,
 				  			  c_cav_flag         ,
 				  			  c_sbjt_no          ,
 				  			  n_amt              ,
 				  			  c_cur_no           ,
 				  			  t_crt_tm           ,
 				  			  c_dptacc_no        ,
 				  			  c_dpt_cde          ,
 				  			  c_rcpt_no          ,
 				  			  c_sls_cde          ,
 				  			  c_prod_no          ,
 				  			  c_cha_cls          ,
 				  			  c_cha_cde          ,
 				  			  c_salegrp_cde      ,
 				  			  c_pay_prsn_cde     ,
 				  			  c_ri_com           ,
 				  			  c_cont_code        ,
 				  			  'C'||c_vou_no           ,
 				  			  c_send_flag        ,
 				  			  t_end_tm           ,
 				  			  c_bsns_typ         ,
 				  			  c_pay_prsn_name    ,
 				  			  c_sbjt_memo        ,
 				  			  c_ply_no           ,
 				  			  c_cha_mrk          ,
 				  			  c_finbank_cde      ,
 				  			  c_vou_memo         ,
 				  			  c_company_cde      ,
 				  			  c_cost_cde         ,
 				  			  c_current_dpt_cde  ,
 				  			  c_con_dpt_cde      ,
 				  			  '3'       ,
 				  			  c_period_name      ,
 				  			  v_voucher_no       ,
 				  			  n_total_amt        ,
 				  			  c_servicetype_no   ,
 				  			  c_department_cde   ,
 			  c_kind_no
 			  FROM WEB_fin_madcr
 			  WHERE c_voucher_no=v_vou_no;


 			INSERT INTO  web_fin_madcr_intf
 			(
 			  c_seq_no               ,
 			  c_item_no              ,
 			  c_cav_flag             ,
 			  c_sbjt_no              ,
 			  c_sbjt_memo            ,
 			  n_amt                  ,

 			  c_cur_no               ,
 			  t_crt_tm               ,
 			  c_dptacc_no            ,
 			  c_dpt_cde              ,
 			  c_ri_com               ,
 			  c_prod_no              ,
 			  ts                     ,
 			  c_send_flag            ,
 			  c_vou_no               ,
 			  c_cont_code            ,
 			  c_cha_mrk              ,
 			  c_bsns_typ             ,
 			  c_salegrp_cde          ,
 			  c_vou_memo             ,
 			  c_company_cde          ,
 			  c_cost_cde             ,
 			  c_current_dpt_cde      ,
 			  t_vou_date             ,
 			  c_con_dpt_cde          ,
 			  c_check_flag           ,
 			  c_send_memo            ,
 			  c_period_name          ,
 			  c_cav_no               ,
 			  set_of_books_id        ,
 			  actual_flag            ,
 			  user_je_category_name  ,
 			  user_je_source_name    ,
 			  chart_of_accounts_id   ,
 			  n_total_amt            ,
 			  c_servicetype_no       ,
 			  c_department_cde       ,
 			  c_rcpt_no
 			  )
 			  SELECT
 			  'C'||c_seq_no               ,
 			  c_item_no              ,
 			  c_cav_flag             ,
 			  c_sbjt_no              ,
 			  c_sbjt_memo            ,
 			  n_amt                  ,

 			  c_cur_no               ,
 			  t_crt_tm               ,
 			  c_dptacc_no            ,
 			  c_dpt_cde              ,
 			  c_ri_com               ,
 			  c_prod_no              ,
 			  ts                     ,
 			  c_send_flag            ,
 			  v_voucher_no               ,
 			  c_cont_code            ,
 			  c_cha_mrk              ,
 			  c_bsns_typ             ,
 			  c_salegrp_cde          ,
 			  c_vou_memo             ,
 			  c_company_cde          ,
 			  c_cost_cde             ,
 			  c_current_dpt_cde      ,
 			  t_vou_date             ,
 			  c_con_dpt_cde          ,
 			  '3'           ,
 			  c_send_memo            ,
 			  c_period_name          ,
 			  c_cav_no              ,
 			  set_of_books_id        ,
 			  actual_flag            ,
 			  user_je_category_name  ,
 			  user_je_source_name    ,
 			  chart_of_accounts_id   ,
 			  n_total_amt            ,
 			  c_servicetype_no       ,
 			  c_department_cde       ,
 			  c_rcpt_no
 			  FROM web_fin_madcr_intf
 			  WHERE c_vou_no=v_vou_no;

 		   UPDATE WEB_fin_madcr
 		   SET n_amt=-n_amt,n_total_amt=-n_total_amt,c_voucher_no=v_voucher_no,
 		   c_send_flag='0',t_end_tm=SYSDATE,c_con_dpt_cde='3'
 		   ,t_crt_tm=TRUNC(ADD_MONTHS(t_crt_tm,1)),c_period_name=TO_CHAR(ADD_MONTHS(t_crt_tm,1),'YYYY-MM')
 		   WHERE c_voucher_no=v_voucher_no;

 		   UPDATE web_fin_madcr_intf
 		   SET n_amt=-n_amt,n_total_amt=-n_total_amt,
 		   	c_vou_no=v_voucher_no,c_send_flag='0'
 		   	,t_end_tm=SYSDATE,c_con_dpt_cde='3'
 		   	,t_crt_tm=TRUNC(ADD_MONTHS(t_crt_tm,1))
 		   	,c_period_name=TO_CHAR(ADD_MONTHS(t_crt_tm,1),'YYYY-MM')
 		   WHERE c_vou_no=v_voucher_no;

 		   UPDATE WEB_fin_madcr
 		   SET  c_con_dpt_cde='3'
 		   WHERE c_voucher_no=v_vou_no;

 		   UPDATE web_fin_madcr_intf
 		   SET  c_con_dpt_cde='3'
 		   WHERE c_vou_no=v_vou_no;

 		   --???????????????
 	--	Auto_rollupmonth.ValidityCheckmaVou(v_voucher_no,v_succsflag);

 		IF v_succsflag <0 THEN
 			ROLLBACK;
 			v_err_content:='proc:[cancelmonths],??????['||TO_CHAR(v_succsflag)||v_vou_no||v_voucher_no||'],?????['||SQLCODE||SQLERRM;

 			INSERT INTO WEB_BAS_FIN_ERRORLOG
 			(
 				c_err_no,
 				c_errtype_no,
 				c_tran_type,
 				c_err_content,
 				t_crt_tm
 			)
 			VALUES(
 				F_Fin_Getcode('e'),
 				'001',	--??????
 				'0000',	--??????
 				v_err_content,
 				SYSDATE
 			);
 			COMMIT;

 		END IF;
 		commit;

         END LOOP;
         CLOSE cur_ifchrg;

 	COMMIT;


 EXCEPTION
   WHEN OTHERS THEN
 	BEGIN
 		--RAISE;


 		v_err_content:='proc:[EXCEPTION cancelmonths],??????['||TO_CHAR(v_succsflag)||v_vou_no||v_voucher_no||'],?????['||SQLCODE||SQLERRM;
 		ROLLBACK;

 		INSERT INTO WEB_BAS_FIN_ERRORLOG
 		(
 			c_err_no,
 			c_errtype_no,
 			c_tran_type,
 			c_err_content,
 			t_crt_tm
 		)
 		VALUES(
 			F_Fin_Getcode('e'),
 			'001',	--??????
 			'0000',	--??????
 			v_err_content,
 			SYSDATE
 		);
 		COMMIT;

 	END;

 END;


--24.??
PROCEDURE taxclose(	v_end_tm	IN VARCHAR2,
			v_dptacc_cde     IN       T_DEPARTMENT.c_dpt_cde%TYPE,
			v_crt_cde     IN       T_FIN_MONTHLYCLOSING.c_upd_cde%TYPE,
      			v_succsflag   	IN 	 OUT    NUMBER)
IS

        v_tmp_cnt	INT;
	v_period_name   T_FIN_MONTHLYCLOSING.c_period_name%TYPE;
	v_end_time	T_FIN_ACCNTPERIOD.C_BGN_TM%TYPE;
	v_otherdptacc_cde T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_tend_tm DATE;--????
	v_up_tm   DATE;--??????

	v_rcpt_no 	WEB_FIN_PRM_DUE.c_rcpt_no%type;
	v_ply_no	WEB_FIN_PRM_DUE.c_ply_no%type;
	v_edr_no	WEB_FIN_PRM_DUE.c_edr_no%type;

	--??????
        CURSOR cur_ccsInfo IS
		select b.c_rcpt_no,b.c_ply_no,b.c_edr_no
		from web_fin_cav_bill a,web_fin_cav_doc b
		WHERE a.c_cav_pk_id=b.c_cav_pk_id
			and a.c_rp_type in ('101','111','112','201')
			AND a.t_check_tm <= v_tend_tm
			AND a.c_dpt_cde=v_dptacc_cde
			and a.c_check_flag='2'
			--AND b.c_prod_no in ('0316','0320')
			and exists (select c_rcpt_no from WEB_FIN_PRM_DUE where c_rcpt_no=b.c_rcpt_no
			and n_other_amt<>0
			and c_prod_no in ('0316','0320'))
			AND a.t_check_tm >=v_up_tm;


    BEGIN
/*
			//1.??
			//1.1.??????????????
			//1.2.????????????????????????????????????


		v_succsflag:
			0	??
			-1 	????????????
			-2	????????????????

			-9	????
*/
	v_succsflag  := 0;
	v_tend_tm:=TO_DATE(v_end_tm||' 23:59:59','YYYY-MM-DD hh24:mi:ss');

	IF v_tend_tm>=TRUNC(SYSDATE) THEN
			v_succsflag  := -1;
		RETURN;
	END IF;

	SELECT  COUNT(*)
	INTO 	v_tmp_cnt
	FROM 	web_FIN_CLOSETAX
	WHERE	 c_dpt_cde=v_dptacc_cde;

	IF v_tmp_cnt=0 THEN
		v_up_tm:=TO_DATE('2007-06-01 23:59:59','yyyy-mm-dd hh24:mi:ss');
	ELSE
		SELECT  MAX(t_end_tm)
		INTO 	v_up_tm
		FROM 	web_FIN_CLOSETAX
		WHERE	 c_dpt_cde=v_dptacc_cde;
	END IF;


	IF v_tend_tm<=v_up_tm THEN
		v_succsflag  := -2;
		RETURN;
	END IF;

	--??????
	INSERT INTO web_FIN_CLOSETAX
	(
		c_rcpt_no,
		c_dpt_cde,
		T_bgn_tm,
		T_end_tm,
		T_crt_tm,
		C_emp_cde
	)
	VALUES
	(
		v_dptacc_cde||TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),
		v_dptacc_cde,
		v_up_tm,
		v_tend_tm,
		SYSDATE,
		v_crt_cde
	);


	--??
	OPEN cur_ccsInfo;
	LOOP
	    FETCH cur_ccsInfo
	    INTO v_rcpt_no,v_ply_no,v_edr_no;
	    EXIT WHEN cur_ccsInfo%NOTFOUND;

		SELECT c_ply_no,c_edr_no
			INTO v_ply_no,v_edr_no
			FROM WEB_FIN_PRM_DUE
			WHERE c_rcpt_no=v_rcpt_no;

--wpc 2009.05.20 ???c_up_flag????V6????
--		UPDATE web_ply_vs_tax
--			SET c_up_flag='1',t_up_tm=TRUNC(v_tend_tm)
--			WHERE c_ply_no=v_ply_no
--			and (c_up_flag is null or c_up_flag<>'1' );

--wpc ???web_edr_vs_tax????
--		IF v_edr_no IS NOT NULL THEN
--			UPDATE web_edr_vs_tax
--				SET c_up_flag='1',t_up_tm=TRUNC(v_tend_tm)
--				WHERE c_edr_no=v_edr_no
--				and (c_up_flag is null or c_up_flag<>'1' );
--		END IF;



		UPDATE 	web_fin_prm_due
			SET c_to_fin_flag='2', t_bln_tm=TRUNC(v_tend_tm)
			WHERE c_rcpt_no=v_rcpt_no
			and n_other_amt<>0
			and (c_to_fin_flag is null or c_to_fin_flag<>'2' );

	END LOOP;
	CLOSE cur_ccsInfo;




    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                RAISE;
                v_succsflag  := -9;

                --dbms_output.put_line('exception'||TO_CHAR(i)||'*'||SRcptNo||SQLERRM);
                IF SQLCODE < 0 THEN
                    v_succsflag := SQLCODE;
                ELSE
                    v_succsflag := -SQLCODE;
                END IF;
            END;
    END;


--25 ??????????
 PROCEDURE modiglfee(v_mt_type IN VARCHAR2,
			v_company_cde IN VARCHAR2,
			v_cur_dpt_cde IN VARCHAR2,
			v_period_name IN VARCHAR2,
			v_mix_amt IN VARCHAR2,
			v_dptacc_cde IN VARCHAR2,
			v_succsflag IN OUT NUMBER)
	/*
	-1 ??????????oracle????????????????????
	-9 ??????,????!
	*/
IS

	v_tmp_cnt	int;
	-- -1 ??????????oracle????????????????????
	-- -2 ??????????oracle???????????
	v_company_cde1	WEB_FIN_DCR.c_company_cde%type;

BEGIN
	v_succsflag:=0;

	SELECT c_company_cde
	INTO v_company_cde1
	FROM t_department
	WHERE c_dptacc_cde=v_dptacc_cde and rownum=1;

	IF v_dptacc_cde<>'00000019' THEN

		IF v_company_cde1<>v_company_cde THEN
			v_succsflag:=-2;
			return;
		END IF;
	END IF;

	SELECT COUNT(1)
	INTO v_tmp_cnt
		FROM web_fin_glinfo
		WHERE 	c_company_cde=v_company_cde
			AND 	c_cur_dpt_cde=v_cur_dpt_cde
		AND 	c_period_name=v_period_name;

	IF v_tmp_cnt=0  THEN
		v_succsflag:=-1;
		RETURN ;
	END IF;
	IF v_mt_type='1' THEN
		UPDATE web_fin_glinfo
		SET	n_yy_ce=NVL(to_number(v_mix_amt),0)-n_yy
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	ELSIF v_mt_type='2' THEN
		UPDATE web_fin_glinfo
		SET	n_sx_ce=NVL(to_number(v_mix_amt),0)-n_sx
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	ELSIF v_mt_type='3' THEN
		UPDATE web_fin_glinfo
		SET	n_jjpf_ce=NVL(to_number(v_mix_amt),0)-n_jjpf
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	ELSIF v_mt_type='4' THEN
		UPDATE web_fin_glinfo
		SET	n_byj_ce=NVL(to_number(v_mix_amt),0)-n_byj
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	ELSIF v_mt_type='5' THEN
		UPDATE web_fin_glinfo
		SET	n_lcx_ce=NVL(to_number(v_mix_amt),0)-n_lcx
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	ELSIF v_mt_type='6' THEN
		UPDATE web_fin_glinfo
		SET	n_knd_ce=NVL(to_number(v_mix_amt),0)-n_knd
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	ELSIF v_mt_type='7' THEN
		UPDATE web_fin_glinfo
		SET	n_sj_ce=NVL(to_number(v_mix_amt),0)-n_sj
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	ELSIF v_mt_type='8' THEN
		UPDATE web_fin_glinfo
		SET	n_ss_ce=NVL(to_number(v_mix_amt),0)-n_ss
			WHERE 	c_company_cde=v_company_cde
				AND 	c_cur_dpt_cde=v_cur_dpt_cde
				AND 	c_period_name=v_period_name;
	END IF;

/*
	1 ????
	2 ???
	3 ??????
	4 ???
	5 ?????
	6 ?????
	7 ??
	8 ????
*/






COMMIT;

EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		ROLLBACK;
		v_succsflag  := -9;
		RETURN;


	END;
END;

	/*
	-1 ??????????oracle????????????????????
	-9 ??????,????!
	*/

--26 ????????
PROCEDURE bankinterest
IS
	v_dptacc_cde			T_DEPARTMENT.c_dptacc_cde%TYPE;
	v_dpt_cde					T_DEPARTMENT.c_dpt_cde%TYPE;

	v_prod_no					WEB_FIN_PRM_DUE.c_prod_no%TYPE;
	v_pre_sum 				WEB_FIN_PRM_DUE.n_bs_amt%TYPE;
	v_edr_type 				WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
	v_edr_no					WEB_FIN_PRM_DUE.c_edr_no%TYPE;
	v_ply_no					WEB_FIN_PRM_DUE.c_ply_no%TYPE;
	v_rcpt_no					WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
	v_bal_tm					WEB_FIN_PRM_DUE.t_due_tm%TYPE;


	v_cav_flag				WEB_FIN_DCR.c_cav_flag%TYPE;
	v_cnt							INT;
	v_tmpcnt					INT;
	v_sbjt_no					WEB_FIN_MADCR.c_sbjt_no%TYPE;
	v_sbjt_memo				WEB_FIN_MADCR.c_sbjt_memo%TYPE;
	v_vou_memo				WEB_FIN_MADCR.c_vou_memo%TYPE;
	vTmpVouNo					WEB_FIN_MADCR.c_seq_no%TYPE;
	vTmpVouNo1				WEB_FIN_MADCR.c_seq_no%TYPE;

	vSbjtNo						WEB_FIN_DCR.c_sbjt_no%TYPE;
	vCavFlag					WEB_FIN_DCR.C_CAV_FLAG%TYPE;
	v_feetyp_cde			T_FIN_PAYDUE.c_feetyp_cde%TYPE;
	v_tran_flag				T_FIN_PAYDUE.c_tran_flag%TYPE;
	v_err_content			T_FIN_ERRORLOG.c_err_content%TYPE;
	v_seq_no    			WEB_FIN_DCR.c_seq_no%TYPE;
	v_item_no    			WEB_FIN_DCR.c_item_no%TYPE;
	v_total_amt   		WEB_FIN_DCR.n_total_amt%TYPE;

	vToday  					VARCHAR(10);
	vBillToday  			VARCHAR(10);
	v_servicetype_no	WEB_FIN_DCR.c_servicetype_no%TYPE;
	v_kind_no					t_fin_prod.c_prod_no%TYPE;
	v_department_cde	WEB_FIN_DCR.c_department_cde%TYPE;
	v_company_cde			WEB_FIN_DCR.c_company_cde%TYPE;



  CURSOR cur_ifPrmInfo IS
SELECT
      a.c_dpt_cde,
      a.c_prod_no,
      a.c_ply_no,
      b.n_other_amt,
      a.c_rcpt_no,
      a.t_crt_tm,
      a.c_cav_flag,
      a.c_seq_no,
      a.c_item_no,
      a.c_dptacc_no,
      a.n_total_amt
  FROM WEB_FIN_DCR a,t_fin_saveamtdue b
    where a.c_rcpt_no = b.c_rcpt_no
    and b.N_OTHER_AMT>0
    and a.T_CRT_TM>=TRUNC(SYSDATE-1,'MM')
    and a.T_CRT_TM<TRUNC(SYSDATE,'MM')
    AND a.c_prereal_flag<>'1';
    --and a.c_cav_pk_id = '20080214050000010005'


BEGIN
	RETURN;
	--??????
	IF TRUNC(SYSDATE-1,'MM')<>TRUNC(ADD_MONTHS(SYSDATE,-1)) THEN
		RETURN;
	ELSE

		commit;
	END IF;


	--??
	OPEN cur_ifPrmInfo;
	LOOP
	    FETCH cur_ifPrmInfo
	    INTO v_dpt_cde,
           v_prod_no,
           v_ply_no,
           v_pre_sum,
           v_rcpt_no,
           v_bal_tm,
           v_cav_flag,
           v_seq_no,
           v_item_no,
           v_dptacc_cde,
           v_total_amt;

	    EXIT WHEN cur_ifPrmInfo%NOTFOUND;

		SELECT c_department_cde,c_company_cde
		INTO v_department_cde,v_company_cde
		FROM t_department
		WHERE c_dpt_cde=v_dpt_cde;

		IF v_total_amt>0 THEN
			v_pre_sum:=v_pre_sum;
		ELSE
			v_pre_sum:=-v_pre_sum;
		END IF;

		v_vou_memo:='????';
		v_servicetype_no:='1101';
		/*
		     1101(2960)
		     Dr????? 446106
		     Cr:?????? 214401
		*/

		--?????
		Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
		SELECT c_kind_no
		INTO	v_kind_no
			FROM t_fin_prod
		WHERE c_prod_no=v_prod_no;


		v_bal_tm:=trunc(SYSDATE-1);


		INSERT INTO WEB_FIN_MADCR
		(
			c_seq_no           ,c_item_no          ,t_end_tm           ,c_cav_flag         ,c_sbjt_no          ,
			n_amt              ,c_cur_no           ,t_crt_tm           ,c_dptacc_no        ,c_dpt_cde          ,
			c_rcpt_no          ,c_sls_cde          ,c_prod_no          ,c_bsns_typ         ,c_cha_cls          ,
			c_cha_cde          ,c_salegrp_cde      ,c_ply_no           ,c_cha_mrk          ,c_vou_memo         ,
			c_company_cde      ,c_check_flag       ,n_total_amt        ,c_servicetype_no	 ,c_kind_no					 ,
			c_department_cde
		)
		SELECT
		  vTmpVouNo					,'1'								 ,SYSDATE-1					 ,'?'					 		,'446106',
		  v_pre_sum         ,c_cur_cde					 ,v_bal_tm           ,c_dptacc_no       ,c_dpt_cde,
		  C_RCPT_NO         ,c_sls_cde					 ,c_prod_no					 ,c_bsns_typ        ,c_cha_cls					 ,
		  c_cha_cde					,C_SALEGRP_CDE			 ,c_ply_no					 ,c_cha_mrk					,v_vou_memo,
		  v_company_cde     ,'4'                 ,v_total_amt				 ,v_servicetype_no  ,v_kind_no,
		  v_department_cde
			FROM T_FIN_SAVEAMTDUE
			WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no));



		INSERT INTO WEB_FIN_MADCR
		(
			c_seq_no           ,c_item_no          ,t_end_tm           ,c_cav_flag         ,c_sbjt_no          ,
			n_amt              ,c_cur_no           ,t_crt_tm           ,c_dptacc_no        ,c_dpt_cde          ,
			c_rcpt_no          ,c_sls_cde          ,c_prod_no          ,c_bsns_typ         ,c_cha_cls          ,
			c_cha_cde          ,c_salegrp_cde      ,c_ply_no           ,c_cha_mrk          ,c_vou_memo         ,
			c_company_cde      ,c_check_flag       ,n_total_amt        ,c_servicetype_no	 ,c_kind_no					 ,
			c_department_cde
		)
		SELECT
		  vTmpVouNo					,'2'								 ,SYSDATE-1					 ,'?'					 		,'214401',
		  v_pre_sum         ,c_cur_cde					 ,v_bal_tm           ,c_dptacc_no       ,c_dpt_cde,
		  C_RCPT_NO         ,c_sls_cde					 ,c_prod_no					 ,c_bsns_typ        ,c_cha_cls					 ,
		  c_cha_cde					,C_SALEGRP_CDE			 ,c_ply_no					 ,c_cha_mrk					,v_vou_memo,
		  v_company_cde     ,'4'                 ,v_total_amt				 ,v_servicetype_no  ,v_kind_no,
		  v_department_cde
			FROM T_FIN_SAVEAMTDUE
			WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no));



		/*????*/
		UPDATE WEB_FIN_DCR SET c_prereal_flag='1' WHERE  c_seq_no = v_seq_no AND c_item_no=v_item_no;

		COMMIT;

	END LOOP;
	CLOSE cur_ifPrmInfo;



EXCEPTION
	WHEN OTHERS THEN
	BEGIN
		--RAISE;
		ROLLBACK;
		dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);
		v_err_content:='proc:[bankinterest],??????['||v_rcpt_no||'],?????['||SQLCODE||SQLERRM;

		INSERT INTO web_bas_FIN_ERRORLOG
		(
			c_err_no,
			c_errtype_no,
			c_tran_type,
			c_err_content,
			t_crt_tm
		)
		VALUES(
			F_Fin_Getcode('e'),
			'001',	--??????
			'0000',	--??????
			v_err_content,
			SYSDATE
		);
		COMMIT;


	END;
END;

--27 ????????
PROCEDURE BankCardGather
IS
  --????
  v_dptacc_no   T_DEPARTMENT.c_dpt_cde%TYPE;
  v_gather_flag web_fin_cav_bill.c_gather_flag%TYPE;
  v_cur_cde     web_fin_cav_bill.c_cur_cde%TYPE;
  v_batch_no    WEB_FIN_PRM_DUE.c_batch_no%TYPE;
  --v_check_tm        web_fin_cav_bill.t_check_tm%TYPE;
  v_err_content t_fin_errorlog.c_err_content%TYPE;
  v_check_tm    VARCHAR2(10);
  v_money_amt   WEB_FIN_CAV_MNY.n_amt%type;
  v_doc_amt     WEB_FIN_CAV_MNY.n_amt%type;
  v_other_amt   WEB_FIN_CAV_MNY.n_amt%type;
  v_item_no     WEB_FIN_DCR.c_item_no%type;

  v_money_sbjt_no  t_fin_bank.c_sbjt_no%type;
  v_bank_cde       t_fin_bank.c_bank_cde%type;
  v_vou_memo       WEB_FIN_DCR.c_vou_memo%type;
  v_servicetype_no WEB_FIN_DCR.c_servicetype_no%type;

  v_period_name VARCHAR2(10);
  v_company_cde WEB_FIN_DCR.c_company_cde%type;
  v_object_amt  web_fin_cav_obj.n_amt%type;
  v_total_amt   web_fin_cav_obj.n_amt%type;

  i int;

  v_dptdoc_cde WEB_FIN_DCR.c_dpt_cde%type;
  v_department_cde t_department.c_department_cde%type;
  v_prod_no    WEB_FIN_DCR.c_prod_no%type;
  v_getdoc_prm WEB_FIN_DCR.n_amt%type;
  v_sbjt_no    WEB_FIN_DCR.c_sbjt_no%type;
  v_kind_no    t_fin_prod.c_kind_no%type;

  n_count int;

  --??????????
  CURSOR cur_ifcompanyInfo IS
    SELECT a.c_dpt_cde, to_char(a.t_check_tm, 'YYYY-MM-DD')
      FROM web_fin_cav_bill a
     WHERE a.c_rp_type = '111'
       AND a.c_cur_cde = '01'
       AND 1=2     --????
     --  and a.c_dpt_cde not like '03%'    --????
       AND (a.c_gather_flag is null or a.c_gather_flag = '' or a.c_gather_flag = '0') --???????? null ???? 1????
      and t_check_tm >= to_date('2009-04-09', 'yyyy-mm-dd')
      -- and t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
    -- AND a.t_check_tm  >= trunc(sysdate-1)
    --AND a.t_check_tm  <= to_date(to_char(trunc(sysdate-1),'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
     GROUP BY a.c_dpt_cde, to_char(a.t_check_tm, 'YYYY-MM-DD')
     order BY to_char(a.t_check_tm, 'YYYY-MM-DD'),a.c_dpt_cde;

  --???????????
  CURSOR cur_ifcarddocInfo IS
    SELECT b.c_dpt_cde, b.c_prod_no, sum(b.n_amt), c_sbjt_no,a.c_department_cde
      FROM WEB_FIN_DCR b, t_department a
     WHERE b.c_dpt_cde=a.c_dpt_cde
       and b.c_rp_type = '111'
       AND b.c_cur_no = '01'
       and b.c_sbjt_no in ('112201', '212101')
          --   AND a.c_gather_flag is null --???????? null ???? 1????
      --- and b.t_crt_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
      -- and b.t_crt_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
       AND b.t_crt_tm  >= to_date(v_check_tm||' 00:00:00','yyyy-mm-dd hh24:mi:ss')
       AND b.t_crt_tm  <= to_date(v_check_tm||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
       AND b.c_dptacc_no = v_dptacc_no
     GROUP BY b.c_dpt_cde, b.c_prod_no, c_sbjt_no,a.c_department_cde;

  --???????????
  CURSOR cur_ifcardobjectInfo IS
    SELECT b.c_dpt_cde, b.c_prod_no, sum(b.n_amt), c_sbjt_no,a.c_department_cde
      FROM WEB_FIN_DCR b, t_department a
     WHERE b.c_dpt_cde=a.c_dpt_cde
       and b.c_rp_type = '111'
       AND b.c_cur_no = '01'
       and b.c_sbjt_no = '119113'
          --   AND a.c_gather_flag is null --???????? null ???? 1????
     -- and b.t_crt_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
      -- and b.t_crt_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
       AND b.t_crt_tm  >= to_date(v_check_tm||' 00:00:00','yyyy-mm-dd hh24:mi:ss')
      AND b.t_crt_tm  <= to_date(v_check_tm||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
       AND b.c_dptacc_no = v_dptacc_no
     GROUP BY b.c_dpt_cde, b.c_prod_no, c_sbjt_no,a.c_department_cde;

BEGIN

  OPEN cur_ifcompanyInfo;
  LOOP
    <<GOTO_LAB>>
    FETCH cur_ifcompanyInfo
      INTO v_dptacc_no, v_check_tm;
    EXIT WHEN cur_ifcompanyInfo%NOTFOUND;

    --1.?????
    -- select to_date(v_check_tm,'YYYY-MM') into v_period_name from dual;

    v_period_name := substr(v_check_tm, 1, 7);
    n_count       := 0;

    --v_period_name := to_date(v_check_tm,'YYYY-MM');
    SELECT c_company_cde
      INTO v_company_cde
      FROM t_department
     WHERE c_dpt_cde = v_dptacc_no;

    Dz_Proc.get_fin_voucode(v_batch_no, v_period_name, v_company_cde,dz_proc.g_pttype);

    --????

--wpc ??????
/*
    --????WEB_FIN_DCR_back????WEB_FIN_DCR,?????
    INSERT INTO WEB_fin_gdcr_back
      (C_SEQ_NO,
       C_ITEM_NO,
       C_CAV_FLAG,
       C_SBJT_NO,
       C_SBJT_MEMO,
       N_AMT,
       N_EXCH_AMT,
       C_CUR_NO,
       N_RATE,
       C_CHR_CUR_NO,
       T_CRT_TM,
       C_DPTACC_NO,
       C_DPT_CDE,
       C_FLOW_NO,
       C_RP_TYPE,
       C_RI_COM,
       C_BAL_TYPE,
       C_BANK_CDE,
       C_CHECK_NO,
       T_RP_TM,
       C_PROD_NO,
       TS,
       C_SEND_FLAG,
       C_VOU_NO,
       C_CONT_CODE,
       C_CHA_MRK,
       C_FINBANK_CDE,
       C_BSNS_TYP,
       C_SALEGRP_CDE,
       C_VOU_MEMO,
       C_COMPANY_CDE,
       C_COST_CDE,
       C_CURRENT_DPT_CDE,
       T_VOU_DATE,
       C_CON_DPT_CDE,
       C_CHECK_FLAG,
       C_SEND_MEMO,
       C_PERIOD_NAME,
       c_cav_pk_id,
       SET_OF_BOOKS_ID,
       ACTUAL_FLAG,
       USER_JE_CATEGORY_NAME,
       USER_JE_SOURCE_NAME,
       CHART_OF_ACCOUNTS_ID,
       N_TOTAL_AMT,
       C_SERVICETYPE_NO,
       REQUEST_ID,
       C_DEPARTMENT_CDE,
       C_VERIFYVOU_MEMO,
       C_RCPT_NO,
       C_CHECK_CDE,
       T_UPDATE_TM,
       C_BATCH_NO)
      SELECT C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             C_SBJT_MEMO,
             N_AMT,
             N_EXCH_AMT,
             C_CUR_NO,
             N_RATE,
             C_CHR_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_FLOW_NO,
             C_RP_TYPE,
             C_RI_COM,
             C_BAL_TYPE,
             C_BANK_CDE,
             C_CHECK_NO,
             T_RP_TM,
             C_PROD_NO,
             TS,
             C_SEND_FLAG,
             C_VOU_NO,
             C_CONT_CODE,
             C_CHA_MRK,
             C_FINBANK_CDE,
             C_BSNS_TYP,
             C_SALEGRP_CDE,
             C_VOU_MEMO,
             C_COMPANY_CDE,
             C_COST_CDE,
             C_CURRENT_DPT_CDE,
             T_VOU_DATE,
             C_CON_DPT_CDE,
             C_CHECK_FLAG,
             C_SEND_MEMO,
             C_PERIOD_NAME,
             c_cav_pk_id,
             SET_OF_BOOKS_ID,
             ACTUAL_FLAG,
             USER_JE_CATEGORY_NAME,
             USER_JE_SOURCE_NAME,
             CHART_OF_ACCOUNTS_ID,
             N_TOTAL_AMT,
             C_SERVICETYPE_NO,
             REQUEST_ID,
             C_DEPARTMENT_CDE,
             C_VERIFYVOU_MEMO,
             C_RCPT_NO,
             C_CHECK_CDE,
             sysdate,
             v_batch_no
        FROM web_fin_dcr_intf a
       WHERE a.c_rp_type = '111'
         AND a.c_cur_no = 'CNY'
         AND a.c_dptacc_no = v_dptacc_no
       -- and a.t_crt_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
        --and a.t_crt_tm <= to_date('2009-03-12', 'yyyy-mm-dd');
          AND a.t_crt_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
          AND a.t_crt_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS');
    -- AND a.c_gather_flag is null
*/
    --???????
    delete from web_fin_dcr_intf
     WHERE c_rp_type = '111'
       AND c_cur_no = 'CNY'
          -- AND a.c_gather_flag is null --???????? null ???? 1????
    --   and t_crt_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
    --  and t_crt_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
       AND t_crt_tm  >= to_date(v_check_tm||' 00:00:00','yyyy-mm-dd hh24:mi:ss')
       AND t_crt_tm  <= to_date(v_check_tm||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
       AND c_dptacc_no = v_dptacc_no;

    --2.????
    SELECT count(1)
      INTO n_count
      FROM WEB_FIN_CAV_MNY b, web_fin_cav_bill a
     WHERE a.c_cav_pk_id = b.c_cav_pk_id
       AND a.c_rp_type = '111'
       AND a.c_cur_cde = '01'
       AND a.c_dpt_cde = v_dptacc_no
       --and a.t_check_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
       --and a.t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
       AND a.t_check_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
       AND a.t_check_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS')
       AND (a.c_gather_flag is null  or a.c_gather_flag = '' or a.c_gather_flag = '0');
    if (n_count > 0) then
      SELECT SUM(n_amt)
        INTO v_money_amt
        FROM WEB_FIN_CAV_MNY b, web_fin_cav_bill a
       WHERE a.c_cav_pk_id = b.c_cav_pk_id
         AND a.c_rp_type = '111'
         AND a.c_cur_cde = '01'
         AND a.c_dpt_cde = v_dptacc_no
         --and a.t_check_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
         --and a.t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
         AND a.t_check_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
         AND a.t_check_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS')
         AND (a.c_gather_flag is null or a.c_gather_flag = ''or a.c_gather_flag = '0');
    else
      v_money_amt := 0;
    end if;

    --3.????

    SELECT count(1)
      INTO n_count
      FROM web_fin_cav_doc b, web_fin_cav_bill a
     WHERE a.c_cav_pk_id = b.c_cav_pk_id
       AND a.c_rp_type = '111'
       AND a.c_cur_cde = '01'
       AND a.c_dpt_cde = v_dptacc_no
    -- and a.t_check_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
      --and a.t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
         AND a.t_check_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
        AND a.t_check_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS')
       AND (a.c_gather_flag is null or a.c_gather_flag = ''or a.c_gather_flag = '0');

    if (n_count > 0) then
      SELECT SUM(b.n_bs_amt)
        INTO v_doc_amt
        FROM web_fin_cav_doc b, web_fin_cav_bill a
       WHERE a.c_cav_pk_id = b.c_cav_pk_id
         AND a.c_rp_type = '111'
         AND a.c_cur_cde = '01'
         AND a.c_dpt_cde = v_dptacc_no
       --     and a.t_check_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
        --  and a.t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
         AND a.t_check_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
         AND a.t_check_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS')
         AND (a.c_gather_flag is null or a.c_gather_flag = '' or a.c_gather_flag = '0');
    else
      v_doc_amt := 0;
    end if;

    --4.??????????????
    SELECT count(1)
      INTO n_count
      FROM web_fin_cav_obj b, web_fin_cav_bill a
     WHERE a.c_cav_pk_id = b.c_cav_pk_id
       AND a.c_rp_type = '111'
       AND a.c_cur_cde = '01'
       AND a.c_dpt_cde = v_dptacc_no
      --  and a.t_check_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
       --   and a.t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
         AND a.t_check_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
       AND a.t_check_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS')
       AND (a.c_gather_flag is null or a.c_gather_flag = '' or a.c_gather_flag = '0') ;

    if (n_count > 0) then
      SELECT SUM(b.n_amt)
        INTO v_object_amt
        FROM web_fin_cav_obj b, web_fin_cav_bill a
       WHERE a.c_cav_pk_id = b.c_cav_pk_id
         AND a.c_rp_type = '111'
         AND a.c_cur_cde = '01'
         AND a.c_dpt_cde = v_dptacc_no
       --    and a.t_check_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
       -- and a.t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
             AND a.t_check_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
          AND a.t_check_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS')
         AND (a.c_gather_flag is null or a.c_gather_flag = '' or a.c_gather_flag = '0');
     --  GROUP BY c_sbjt_no;
    else
      v_object_amt := 0;
    end if;

    --5.??web_fin_dcr_intf
    if (substr(v_dptacc_no,0,2) ='03') then
       v_bank_cde:= '01100118';
       v_money_sbjt_no := '10020199';
    ELSIF (substr(v_dptacc_no,0,4) ='2601') then
       v_bank_cde:= '01300201';
       v_money_sbjt_no := '10020101';
    ELSIF (substr(v_dptacc_no,0,4) ='1014') then
       v_bank_cde:= '01260702';
       v_money_sbjt_no := '10020101';
    else
      SELECT C_BANK_CDE, c_sbjt_no
        INTO v_bank_cde, v_money_sbjt_no
        FROM t_fin_bank
       WHERE c_dpt_cde = v_dptacc_no
         and enabled_flag='Y'
         and c_rp_flag = '05';
    end if;



    SELECT SUM(N_AMT)
      INTO v_total_amt
      FROM WEB_FIN_DCR a
     WHERE a.c_rp_type = '111'
       AND a.c_cur_no = '01'
       AND a.c_dptacc_no = v_dptacc_no
       AND a.c_cav_flag = '?'
     -- and a.t_crt_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
      -- and a.t_crt_tm <= to_date('2009-03-12', 'yyyy-mm-dd');
         AND a.t_crt_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
           AND a.t_crt_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS');
    --AND a.c_gather_flag is null;

    v_vou_memo       := '????';
    v_servicetype_no := '1102';
    --5.1 ??
    INSERT INTO web_fin_dcr_intf
      (c_seq_no,
       c_item_no,
       c_cav_flag,
       c_sbjt_no,
       c_sbjt_memo,
       n_amt,
       n_exch_amt,
       c_cur_no,
       n_rate,
       c_chr_cur_no,
       t_crt_tm,
       c_dptacc_no,
       c_flow_no,
       c_rp_type,
       c_ri_com,
       c_bal_type,
       c_bank_cde,
       c_check_no,
       t_rp_tm,
       c_prod_no,
       c_send_flag,
       c_cont_code,
       c_dpt_cde,
       c_vou_memo,
       c_con_dpt_cde,
       c_cost_cde,
       c_company_cde,
       c_salegrp_cde,
       c_bsns_typ,
       c_cha_mrk,
       c_vou_no,
       c_period_name,
       n_total_amt,
       c_servicetype_no,
       c_department_cde,
       c_rcpt_no,
       c_cav_no)
    values
      (v_batch_no, --c_seq_no
       '1', --c_item_no
       '?', --c_cav_flag
       v_money_sbjt_no, --c_sbjt_no
       v_bank_cde, --c_sbjt_memo
       v_money_amt, --n_amt
       v_money_amt, --n_exch_amt
       'CNY', --c_cur_no
       1, --n_rate
       '01', --c_chr_cur_no
       TO_DATE(v_check_tm || ' 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), --t_crt_tm
       v_dptacc_no, --c_dptacc_no
       '', --c_flow_no,
       '111', --c_rp_type
       NULL, --c_ri_com
       '002003', --c_bal_type,
       v_bank_cde, --c_bank_cde
       '????', --c_check_no
       TO_DATE(v_check_tm || ' 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), --t_rp_tm
       NULL, --c_prod_no,
       '0', --c_send_flag
       NULL, --c_cont_code,
       NULL, --c_dpt_cde,
       '????', --c_vou_memo
       null, --c_con_dpt_cde,
       null, --c_cost_cde,
       v_company_cde, --c_company_cde
       null, --c_salegrp_cde, /*c_bsns_typ*/
       '0', --c_bsns_typ
       null, --c_cha_mrk,
       v_batch_no, --c_vou_no,
       v_period_name, --c_period_name
       v_total_amt, --n_total_amt
       v_servicetype_no, --c_servicetype_no
       '0', --c_department_cde,
       null, --c_rcpt_no,
       v_batch_no --c_cav_pk_id
       );

    --5.2 ??
    i := 1;
    OPEN cur_ifcarddocInfo;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifcarddocInfo
        INTO v_dptdoc_cde, v_prod_no, v_getdoc_prm, v_sbjt_no,v_department_cde;
      EXIT WHEN cur_ifcarddocInfo%NOTFOUND;

      i := i + 1;

      SELECT count(1)
        INTO n_count
        FROM t_fin_prod
       WHERE c_prod_no = v_prod_no;

      if n_count > 0 then
        SELECT c_kind_no
          INTO v_kind_no
          FROM t_fin_prod
         WHERE c_prod_no = v_prod_no;
      else
        v_kind_no := '0';
      end if;

      INSERT INTO web_fin_dcr_intf
        (c_seq_no,
         c_item_no,
         c_cav_flag,
         c_sbjt_no,
         c_sbjt_memo,
         n_amt,
         n_exch_amt,
         c_cur_no,
         n_rate,
         c_chr_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_flow_no,
         c_rp_type,
         c_ri_com,
         c_bal_type,
         c_bank_cde,
         c_check_no,
         t_rp_tm,
         c_prod_no,
         c_send_flag,
         c_cont_code,
         c_dpt_cde,
         c_vou_memo,
         c_con_dpt_cde,
         c_cost_cde,
         c_company_cde,
         c_salegrp_cde,
         c_bsns_typ,
         c_cha_mrk,
         c_vou_no,
         c_period_name,
         n_total_amt,
         c_servicetype_no,
         c_department_cde,
         c_rcpt_no,
         c_cav_no)
      values
        (v_batch_no, --c_seq_no
         i, --c_item_no
         '?', --c_cav_flag
         v_sbjt_no, --c_sbjt_no
         '0', --c_sbjt_memo
         v_getdoc_prm, --n_amt
         v_getdoc_prm, --n_exch_amt
         'CNY', --c_cur_no
         1, --n_rate
         '01', --c_chr_cur_no
         TO_DATE(v_check_tm || ' 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), --t_crt_tm
         v_dptacc_no, --c_dptacc_no
         '', --c_flow_no,
         '111', --c_rp_type
         NULL, --c_ri_com
         null, --c_bal_type,
         NULL, --c_bank_cde
         NULL, --c_check_no
         TO_DATE(v_check_tm || ' 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), --t_rp_tm
         v_kind_no, --c_prod_no,
         '0', --c_send_flag
         NULL, --c_cont_code,
         v_dptdoc_cde, --c_dpt_cde,
         '????', --c_vou_memo
         null, --c_con_dpt_cde,
         null, --c_cost_cde
         v_company_cde, --c_company_cde
         null, --c_salegrp_cde
         '0', --c_bsns_typ
         null, --c_cha_mrk,
         v_batch_no, --c_vou_no,
         v_period_name, --c_period_name
         v_total_amt, --n_total_amt
         v_servicetype_no, --c_servicetype_no
         v_department_cde, --c_department_cde,
         null, --c_rcpt_no,
         v_batch_no --c_cav_pk_id
         );

    END LOOP;
    CLOSE cur_ifcarddocInfo;

    OPEN cur_ifcardobjectInfo;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifcardobjectInfo
        INTO v_dptdoc_cde, v_prod_no, v_other_amt, v_sbjt_no,v_department_cde;
      EXIT WHEN cur_ifcardobjectInfo%NOTFOUND;

      i := i + 1;

      SELECT count(1)
        INTO n_count
        FROM t_fin_prod
       WHERE c_prod_no = v_prod_no;

      if n_count > 0 then
        SELECT c_kind_no
          INTO v_kind_no
          FROM t_fin_prod
         WHERE c_prod_no = v_prod_no;
      else
        v_kind_no := '0';
      end if;

      INSERT INTO web_fin_dcr_intf
        (c_seq_no,
         c_item_no,
         c_cav_flag,
         c_sbjt_no,
         c_sbjt_memo,
         n_amt,
         n_exch_amt,
         c_cur_no,
         n_rate,
         c_chr_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_flow_no,
         c_rp_type,
         c_ri_com,
         c_bal_type,
         c_bank_cde,
         c_check_no,
         t_rp_tm,
         c_prod_no,
         c_send_flag,
         c_cont_code,
         c_dpt_cde,
         c_vou_memo,
         c_con_dpt_cde,
         c_cost_cde,
         c_company_cde,
         c_salegrp_cde,
         c_bsns_typ,
         c_cha_mrk,
         c_vou_no,
         c_period_name,
         n_total_amt,
         c_servicetype_no,
         c_department_cde,
         c_rcpt_no,
         c_cav_no)
      values
        (v_batch_no, --c_seq_no
         i, --c_item_no
         '?', --c_cav_flag
         v_sbjt_no, --c_sbjt_no
         '0', --c_sbjt_memo
         v_other_amt, --n_amt
         v_other_amt, --n_exch_amt
         'CNY', --c_cur_no
         1, --n_rate
         '01', --c_chr_cur_no
         TO_DATE(v_check_tm || ' 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), --t_crt_tm
         v_dptacc_no, --c_dptacc_no
         '', --c_flow_no,
         '111', --c_rp_type
         NULL, --c_ri_com
         null, --c_bal_type,
         NULL, --c_bank_cde
         NULL, --c_check_no
         TO_DATE(v_check_tm || ' 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), --t_rp_tm
         v_kind_no, --c_prod_no,
         '0', --c_send_flag
         NULL, --c_cont_code,
         v_dptdoc_cde, --c_dpt_cde,
         '????', --c_vou_memo
         null, --c_con_dpt_cde,
         null, --c_cost_cde
         v_company_cde, --c_company_cde
         null, --c_salegrp_cde
         '0', --c_bsns_typ
         null, --c_cha_mrk,
         v_batch_no, --c_vou_no,
         v_period_name, --c_period_name
         v_total_amt, --n_total_amt
         v_servicetype_no, --c_servicetype_no
         v_department_cde, --c_department_cde,
         null, --c_rcpt_no,
         v_batch_no --c_cav_pk_id
         );

    END LOOP;
    CLOSE cur_ifcardobjectInfo;

     UPDATE WEB_FIN_DCR
       SET c_voucher_no = v_batch_no,c_vou_no=v_batch_no
     WHERE c_rp_type = '111'
       AND c_cur_no = '01'
       AND c_dptacc_no = v_dptacc_no
       --  and t_crt_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
       --  and t_crt_tm <= to_date('2009-03-12', 'yyyy-mm-dd');
          AND t_crt_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
          AND t_crt_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS');

    --6.????????
    UPDATE web_fin_cav_bill
       SET c_gather_flag = v_batch_no
     WHERE c_rp_type = '111'
       AND c_cur_cde = '01'
       AND c_dpt_cde = v_dptacc_no
       --  and t_check_tm >= to_date('2009-03-11', 'yyyy-mm-dd')
       --  and t_check_tm <= to_date('2009-03-12', 'yyyy-mm-dd')
          AND t_check_tm  >= TO_DATE(v_check_tm||' 00:00:00','YYYY-MM-DD HH24:MI:SS')
          AND t_check_tm  <= TO_DATE(v_check_tm||' 23:59:50','YYYY-MM-DD HH24:MI:SS')
       AND (c_gather_flag is null or c_gather_flag = '' or c_gather_flag = '0');


    commit;
  END LOOP;
  CLOSE cur_ifcompanyInfo;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      --RAISE;
      dbms_output.put_line('exception' || '*' || v_dptacc_no || v_batch_no ||
                           v_cur_cde || SQLERRM);
      ROLLBACK;

      v_err_content := 'proc:[BankCardGather],??????[' || v_dptacc_no ||
                       v_batch_no || v_cur_cde || '],?????[' ||
                       SQLCODE || SQLERRM;

      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'),
         '001',  --??????
         '0000', --??????
         v_err_content,
         SYSDATE);
      COMMIT;

    END;
END;

END Auto_Confirmed3;
/
