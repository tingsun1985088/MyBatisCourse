CREATE PACKAGE BODY "P_TEST_COLLECTFU" is
   Procedure Generateavoucher(vCavNo IN VARCHAR2, v_succsflag IN OUT NUMBER) IS
    --????????
    vItemNo  WEB_FIN_CAV_OBJ.N_ITEM_NO%TYPE;

    V_OPREMNY_PK_ID  WEB_FIN_CAV_OBJ.C_OPREMNY_PK_ID%TYPE;
    vAmt     WEB_FIN_CAV_OBJ.n_amt%TYPE;
    v_cur_cde   WEB_FIN_CAV_OBJ.c_cur_cde%TYPE;
    vCurNo   WEB_FIN_CAV_OBJ.c_cur_cde%TYPE;
    vCavDire WEB_FIN_CAV_OBJ.C_CAV_DIR%TYPE;
    vDptCde  WEB_FIN_CAV_OBJ.c_dpt_cde%TYPE;

    vSlsCde    WEB_FIN_CAV_OBJ.c_sls_cde%TYPE;
    vProdNo    WEB_FIN_CAV_OBJ.c_prod_no%TYPE;
    v_bsns_typ WEB_FIN_CAV_OBJ.c_bsns_typ%TYPE;
    vChaCls    WEB_FIN_CAV_OBJ.c_cha_cls%TYPE;
    vChaCde    WEB_FIN_CAV_OBJ.c_cha_cde%TYPE;
    vPayName   WEB_FIN_CAV_OBJ.C_PAYER_NME%TYPE;
    v_cha_mrk  WEB_FIN_PRM_DUE.c_cha_mrk%TYPE;

    vPreFlag         WEB_FIN_CAV_OBJ.c_pre_flag%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_salegrp_cde    WEB_FIN_DCR.c_salegrp_cde%TYPE;
	--v_OPREMNY_PK_ID WEB_FIN_CAV_OBJ.C_OPREMNY_PK_ID%TYPE;


    --????
    vBalType  WEB_FIN_CAV_MNY.C_BAL_TYP%TYPE;
	v_item_no		  WEB_FIN_CAV_MNY.N_ITEM_NO%TYPE;
    vBankCde  WEB_FIN_CAV_MNY.C_BANK_CDE%TYPE;
    vCheckNo  WEB_FIN_CAV_MNY.C_CHECK_NO%TYPE;
    vRpTm     WEB_FIN_CAV_MNY.T_RP_TM%TYPE;
    v_flow_cde WEB_FIN_CAV_MNY.c_flow_cde%TYPE;
    v_CAVMNY_PK_ID WEB_FIN_CAV_MNY.C_CAVMNY_PK_ID%TYPE;


    --?????
    i                INT;
    v_applen         INT;
    v_gdcnt          INT;
    vCavFlag         WEB_FIN_DCR.C_CAV_FLAG%TYPE;
    vSbjtNo          WEB_FIN_DCR.c_sbjt_no%TYPE;
    vDocDptCde       WEB_FIN_DCR.c_dpt_cde%TYPE;
    v_rcpt_no        WEB_FIN_DCR.c_rcpt_no%TYPE;
    v_vou_memo       WEB_FIN_DCR.c_vou_memo%TYPE;
    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;


    --????????
    vRpType        WEB_FIN_CAV_BILL.c_rp_type%TYPE;
    vSumAmt        WEB_FIN_CAV_BILL.N_SUM_AMT%TYPE;
    v_replace_flag WEB_FIN_CAV_BILL.c_replace_flag%TYPE; --??/??/??
    vRcptNo        WEB_FIN_CAV_DOC.c_rcpt_no%TYPE;
    v_BS_AMT        WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    vExchRate      WEB_FIN_CAV_DOC.n_exch_rate%TYPE;
    vChrCurNo      WEB_FIN_CAV_DOC.C_BS_CUR%TYPE;
    vExchgotPrm    WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    v_202get_prm   WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    vEdrNo         WEB_FIN_CAV_DOC.c_edr_no%TYPE;

    vPreAmt     WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    vPreClmAmt  WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    vTmpAmt     WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    vMixAmt     WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    vFinTypCde  WEB_FIN_CAV_DOC.c_feetyp_cde%TYPE;
    v_pay_name  WEB_FIN_CAV_DOC.C_PAYER_NME%TYPE;
    v_bill_flag WEB_FIN_CAV_DOC.c_bill_flag%TYPE;
    v_ply_no    WEB_FIN_CAV_DOC.c_ply_no%TYPE;
    v_prod_no   WEB_FIN_PRM_DUE.c_prod_no%TYPE;

    n_sumprm      WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    n_sumclm      WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    v_exchgot_prm WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    v_batch_no    WEB_FIN_PRM_DUE.c_batch_no%type;

    --?????
    vTmpVouNo   WEB_FIN_TMP_DCR.c_seq_no%TYPE;
    vTmpVouNo1  WEB_FIN_TMP_DCR.c_seq_no%TYPE;
    v_sbjt_memo WEB_FIN_TMP_DCR.c_sbjt_memo%TYPE;

    v_ply_app_no  WEB_FIN_PRM_DUE.C_APP_NO%TYPE;
    v_DUE_TM      WEB_FIN_PRM_DUE.T_DUE_TM%TYPE; --????

    v_nSumFeeCnt  INT;
    v_tran_flag   WEB_FIN_PRM_DUE.c_tran_flag%TYPE;
--zmh    v_type        WEB_FIN_RICED_DUE.c_type%TYPE;
--zmh    v_plyclm_flag WEB_FIN_RICED_DUE.c_plyclm_flag%TYPE;

    v_con_dpt_cde   WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
    v_eac_dcm_mrk WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
    v_kind_no     WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_compare_amt WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;
    v_other_amt   WEB_FIN_CAV_DOC.N_BS_AMT%TYPE;

    --????????
    v_nplyset     INT;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_period_name WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE;
    v_end_time    WEB_FIN_DCR.t_crt_tm%TYPE;
    v_prn_no      WEB_FIN_PRM_DUE.c_prn_no%TYPE;
    v_edr_no      WEB_FIN_PRM_DUE.c_edr_no%TYPE;
    v_shplycnt    int;
    v_shedrcnt    int;
    v_temp_cnt1   int;

/*
	--zmh
    v_abby_flag   t_fin_seemoney_printply.c_abby_flag%type;
    v_Interval    t_fin_seemoney_printply.n_Interval%type;
    v_times       t_fin_seemoney_printply.n_times%type;

*/
    CURSOR cur_ifCavMoney IS
      SELECT C_BAL_TYP,
             N_AMT,
             C_CUR_cde,
             C_PAYER_NME,
             C_BANK_CDE,
             C_CHECK_NO,
             T_RP_TM,
             c_sbjt_no,
             c_flow_cde,
             n_item_no,
             C_BANK_NME
        FROM WEB_FIN_CAV_MNY
       WHERE C_CAV_PK_ID = vCavNo;

    --??????
    CURSOR cur_ifCavObject IS
      SELECT c_sbjt_no,
             n_amt,
             c_cur_cde,
             c_cav_dir,
             c_dpt_cde,
             c_sls_cde,
             c_prod_no,
             c_bsns_typ,
             c_cha_cls,
             c_cha_cde,
             C_PAYER_NME,
             n_pre_amt,
             c_pre_flag,
             n_item_no,
             C_OPREMNY_PK_ID
        FROM WEB_FIN_CAV_OBJ
       WHERE C_CAV_PK_ID = vCavNo;

    --????????
    CURSOR cur_ifCavDoc IS
      SELECT c_rcpt_no,
             n_exch_rate,
             C_BS_CUR,
             N_BS_AMT,
             c_prod_no,
             c_sls_cde,
             c_bsns_typ,
             c_cha_cls,
             c_cha_cde,
             c_dpt_cde,
             c_edr_no,
             c_feetyp_cde,
             C_PAYER_NME,
             c_bill_flag,
             c_ply_no
        FROM WEB_FIN_CAV_DOC
       WHERE C_CAV_PK_ID = vCavNo;
/*
    v_doc_flag    WEB_FIN_CAV_RIDOC.c_doc_flag%TYPE;
    v_ri_com      WEB_FIN_CAV_RIDOC.c_ri_com%TYPE;
    v_cont_code   WEB_FIN_CAV_RIDOC.c_cont_code%TYPE;
*/
    j             INT;
    v_finbank_cde web_fin_dcr_intf.c_finbank_cde%TYPE;
    v_second_sbjt CHAR(2);

    v_temp_fzpcnt INT;
    v_temp_zpcnt  INT;
/*
    --????????
    CURSOR cur_ifriDoc IS
      SELECT c_doc_flag,
             c_ri_com,
             c_cont_code,
             c_rcpt_no,
             c_cur_no,
             n_exch_rate,
             n_paid_amt,
             n_exchgot_prm,
             c_dptacc_cde,
             c_dpt_cde
        FROM WEB_FIN_CAV_RIDOC
       WHERE C_CAV_PK_ID = vCavNo;
  */
    v_MakeVou      CHAR; --????? Y????? N???
    v_tmpcnt       INT;
    v_temp_cnt     INT;


    v_bank_cde     WEB_FIN_CAV_MNY.c_bank_cde%type;
--    v_control_days t_fin_seemoney_printply.n_control_days%type;

  BEGIN

    /*
        ??????
    */
    v_succsflag := 0;
    v_MakeVou   := 'Y';


    --??????
    SELECT c_rp_type, c_dpt_cde, c_cur_cde, n_sum_amt, C_replace_flag
      INTO vRpType, vDptCde, vChrCurNo, vSumAmt, v_replace_flag
      FROM WEB_FIN_CAV_BILL
     WHERE C_CAV_PK_ID = vCavNo;
      -- return;
/*
    SELECT n_control_days - 1
      INTO v_control_days
      FROM t_fin_seemoney_printply
     WHERE c_dptacc_cde = vDptCde;

    SELECT c_abby_flag
      INTO v_abby_flag
      FROM t_fin_seemoney_printply
     WHERE c_dptacc_cde = vDptCde;
*/
    IF vRpType in ('111', '112') AND SUBSTR(vDptCde, 1, 2) = '03' THEN

      select decode(b.c_bank_cde, '002', '01100118', '01100119')
        into v_bank_cde
        from WEB_FIN_CAV_DOC a, WEB_FIN_PRM_DUE b
       where a.c_rcpt_no = b.c_rcpt_no
         and a.C_CAV_PK_ID = vCavNo
         and rownum = 1;


      UPDATE WEB_FIN_CAV_MNY
         SET c_bank_cde = v_bank_cde
       WHERE C_CAV_PK_ID = vCavNo;
    END IF;

    SELECT COUNT(c_period_name)
      INTO v_temp_cnt
      FROM WEB_FIN_MONTHLYCLOSING
     WHERE c_dptacc_cde = vDptCde
       AND c_closing_flag = '1'; --??

    IF v_temp_cnt = 0 THEN
      v_succsflag := -2;
      RETURN;
    END IF;

    SELECT c_period_name
      INTO v_period_name
      FROM WEB_FIN_MONTHLYCLOSING
     WHERE c_dptacc_cde = vDptCde
       AND c_closing_flag = '1'; --??

    --    v_period_name:=TO_CHAR(SYSDATE,'YYYY-MM');
    SELECT count(1)
      INTO v_temp_cnt
      FROM WEB_BAS_FIN_ACCT_PERIOD
     WHERE c_period_name = v_period_name;

    IF v_temp_cnt = 0 THEN
      v_succsflag := -30;
      RETURN;
    END IF;


    SELECT TRUNC(t_end_tm)
      INTO v_end_time
      FROM WEB_BAS_FIN_ACCT_PERIOD
     WHERE c_period_name = v_period_name;

    --    IF(v_replace_flag<>'0')THEN
    --?????/?????,??????
    --        return;
    --    END IF;

    vRpType := TRIM(vRpType);

    --???????????????

    IF vRpType = '202' THEN
      SELECT ABS(NVL(SUM((a.n_other_amt)), 0))
        INTO v_other_amt
        FROM WEB_FIN_SAVEAMT_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo;

      IF v_other_amt <> 0 THEN
        SELECT NVL(SUM(DECODE(c_sbjt_no, '214401', n_amt, -n_amt)), 0)
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('410905', '214401');

        IF v_other_amt <> ABS(v_compare_amt) THEN
          --??????????????????????????????
          v_succsflag := -7;
          RETURN;
        END IF;

        --23 ????????????????!
        SELECT SUM(-b.N_BS_AMT)
          INTO v_202get_prm
          FROM WEB_FIN_CAV_DOC a, WEB_FIN_SAVEAMT_DUE b
         WHERE a.c_rcpt_no = b.c_rcpt_no
           and a.C_CAV_PK_ID = vCavNo;

        IF v_202get_prm > 0 then
          v_succsflag := -23;
          RETURN;
        END IF;
      END IF;
    ELSIF vRpType = '212' THEN
      SELECT ABS(NVL(SUM((a.n_other_amt)), 0))
        INTO v_other_amt
        FROM web_fin_tmpbigsave_due a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo;

      IF v_other_amt <> 0 THEN
        SELECT NVL(SUM(DECODE(c_sbjt_no, '214401', n_amt, -n_amt)), 0)
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('410905', '214401');

        IF v_other_amt <> ABS(v_compare_amt) THEN
          --??????????????????????????????
          v_succsflag := -7;
          RETURN;
        END IF;
      END IF;
    ELSIF vRpType = '101' THEN
      SELECT ABS(NVL(SUM(a.n_other_amt), 0))
        INTO v_other_amt
        FROM WEB_FIN_PRM_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo;

      IF v_other_amt <> 0 THEN
        SELECT NVL(SUM(n_amt), 0)
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('119113');

        IF v_other_amt <> v_compare_amt THEN
          ---8 ????????????????????????,???!
          v_succsflag := -8;
          RETURN;
        END IF;
      END IF;

      --??????????
      IF v_other_amt = 0 THEN
        SELECT NVL(SUM(n_amt), 0)
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('119113');

        IF v_compare_amt <> 0 THEN
          ---8 ????????????????????????,???!
          v_succsflag := -8;
          RETURN;
        END IF;
      END IF;

    ELSIF vRpType = '111' OR vRpType = '112' THEN
      SELECT ABS(NVL(SUM(a.n_other_amt), 0))
        INTO v_other_amt
        FROM WEB_FIN_PRM_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo;

      IF v_other_amt <> 0 THEN
        SELECT NVL(SUM(n_amt), 0)
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('119113');

        IF v_other_amt <> v_compare_amt THEN
          ---8 ????????????????????????,???!
          v_succsflag := -8;
          RETURN;
        END IF;
      END IF;
      --??????????
      IF v_other_amt = 0 THEN
        SELECT NVL(SUM(n_amt), 0)
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('119113');

        IF v_compare_amt <> 0 THEN
          ---8 ????????????????????????,???!
          v_succsflag := -8;
          RETURN;
        END IF;
      END IF;

    ELSIF vRpType = '201' THEN
      SELECT ABS(NVL(SUM(a.n_other_amt), 0))
        INTO v_other_amt
        FROM WEB_FIN_PRM_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo;

      IF v_other_amt <> 0 THEN
        SELECT ABS(NVL(SUM(n_amt), 0))
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('119113');

        IF v_other_amt <> v_compare_amt THEN
          ---8 ????????????????????????,???!
          v_succsflag := -8;
          RETURN;
        END IF;
      END IF;

      --??????????
      IF v_other_amt = 0 THEN
        SELECT NVL(SUM(n_amt), 0)
          INTO v_compare_amt
          FROM WEB_FIN_CAV_OBJ
         WHERE C_CAV_PK_ID = vCavNo
           AND c_sbjt_no IN ('119113');

        IF v_compare_amt <> 0 THEN
          ---8 ????????????????????????,???!
          v_succsflag := -8;
          RETURN;
        END IF;
      END IF;

    END IF;

     /*?????*/
    IF vRptype = '101' OR vRpType = '111' OR vRpType = '112' THEN

      v_vou_memo       := '????';
      v_servicetype_no := '1102';

      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_FIN_PRM_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo
         AND a.c_accnt_flag NOT IN ('11', '10');

      IF v_temp_cnt <> 0 THEN
        v_succsflag := -11;
        RETURN;
      END IF;

    ELSIF vRptype = '103' THEN
      /*103 ???*/
      v_vou_memo       := '?????';
      v_servicetype_no := '1109';
    ELSIF vRptype = '104' THEN
      /*104 ????*/
      v_vou_memo       := '??????';
      v_servicetype_no := '1103';
    ELSIF vRptype = '105' THEN
      /*105 ?????*/
      v_vou_memo       := '?????';
      v_servicetype_no := '1105';
    ELSIF vRptype = '106' THEN
      /*106 ??????*/
      v_vou_memo       := '??????';
      v_servicetype_no := '1110';
    ELSIF vRptype = '107' OR vRptype = '209' THEN
      /*107  ????? 209 */
      v_vou_memo       := '?????????';
      v_servicetype_no := '1114';

    ELSIF vRptype = '201' THEN
      /*201 ??/??-?????/?? 202 ??/??????*/
      v_vou_memo       := '????';
      v_servicetype_no := '1102';
      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_FIN_PRM_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo
         AND a.c_accnt_flag NOT IN ('11', '10');

      IF v_temp_cnt <> 0 THEN
        v_succsflag := -11;
        RETURN;
      END IF;
    ELSIF vRptype = '203' THEN
      /*203 ????? */
      v_vou_memo       := '?????';
      v_servicetype_no := '1104';
    ELSIF vRptype = '204' THEN
      /*204 ???? */
      v_vou_memo       := '??????';
      v_servicetype_no := '1107';
    ELSIF vRptype = '205' THEN
      /*205 ??*/
      v_vou_memo       := '????';
      v_servicetype_no := '1108';
    ELSIF vRptype = '102' THEN
      v_vou_memo       := '???????';
      v_servicetype_no := '1111';
      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_FIN_SAVEAMT_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo
         AND a.c_accnt_flag NOT IN ('11', '10');

      IF v_temp_cnt <> 0 THEN
        v_succsflag := -11;
        RETURN;
      END IF;
    ELSIF vRptype = '202' THEN
      v_vou_memo       := '???????';
      v_servicetype_no := '1112';
      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_FIN_SAVEAMT_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo
         AND a.c_accnt_flag NOT IN ('11', '10');

      IF v_temp_cnt <> 0 THEN
        v_succsflag := -11;
        RETURN;
      END IF;
    ELSIF vRptype = '212' THEN
      v_vou_memo       := '???????';
      v_servicetype_no := '1112';
      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM web_fin_tmpbigsave_due a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo
         AND a.c_accnt_flag NOT IN ('11', '10');

      IF v_temp_cnt <> 0 THEN
        v_succsflag := -11;
        RETURN;
      END IF;
    ELSIF vRptype = '206' THEN
      /*206 ?????*/
      v_vou_memo       := '?????';
      v_servicetype_no := '1106';
      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_FIN_PAY_DUE a, WEB_FIN_CAV_DOC b
       WHERE a.c_rcpt_no = b.c_rcpt_no
         AND b.C_CAV_PK_ID = vCavNo
         AND a.c_accnt_flag NOT IN ('11', '10');

      IF v_temp_cnt <> 0 THEN
        v_succsflag := -11;
        RETURN;
      END IF;
    ELSIF vRptype = '207' THEN
      /*207*/
      v_vou_memo       := '??????';
      v_servicetype_no := '1110';
    ELSIF vRptype = '208' THEN
      --???????????
      v_vou_memo := '??????????';
    END IF;

    i := 0;

    --?????
    Dz_Proc.get_fin_cav_no(vTmpVouNo, vDptCde, '4',dz_proc.g_pttype);

    --????
    OPEN cur_ifCavMoney;
    LOOP
      FETCH cur_ifCavMoney
        INTO vBalType, vAmt, vCurNo, vPayName, vBankCde, vCheckNo, vRpTm, vSbjtNo, v_flow_cde, v_item_no, v_finbank_cde;
      EXIT WHEN cur_ifCavMoney%NOTFOUND;

      IF vRpType = '111' THEN
        SELECT COUNT(1)
          INTO v_temp_cnt
          FROM WEB_FIN_CAV_MNY
         WHERE C_CAV_PK_ID = vCavNo
           AND C_BAL_TYP <> '002003';

        IF v_temp_cnt > 0 THEN
          v_succsflag := -12;
          RETURN;
        END IF;
      ELSIF vRpType = '112' THEN
        SELECT COUNT(1)
          INTO v_temp_cnt
          FROM WEB_FIN_CAV_MNY
         WHERE C_CAV_PK_ID = vCavNo
           AND C_BAL_TYP <> '002002';

        IF v_temp_cnt > 0 THEN
          v_succsflag := -17;
          RETURN;
        END IF;
      END IF;

      i := i + 1;

      IF vRpType > '200' THEN
        ---?
        vCavFlag := '?';
      ELSE
        vCavFlag := '?';
      END IF;


      IF vRpType = '107' THEN
        vCavFlag := '?';
      ELSIF vRpType = '209' THEN
        vCavFlag := '?';
      ELSIF vRpType = '212' THEN
        vCavFlag := '?';
      END IF;

      --??????????
      IF vBalType = '002001' THEN
        IF TO_NUMBER(vRpType) - 199 > 0 THEN
          --??
          vSbjtNo := '100102';
        ELSE
          --??
          vSbjtNo := '100101';
        END IF;
        vBankCde := '0';
      ELSIF vBalType = '002006' THEN
        --???
        IF TO_NUMBER(vRpType) - 199 > 0 THEN
          --??
          vSbjtNo := '101506';
        ELSE
          --??
          vSbjtNo := '101506';
        END IF;
        vBankCde := '0';

      ELSE
        IF vBankCde IS NULL OR vBankCde = ' ' THEN
          v_succsflag := -1; --???????
          RETURN;
        ELSE
          SELECT c_sbjt_no
            INTO vSbjtNo
            FROM WEB_BAS_FIN_BANK
           WHERE C_BANK_CDE = vBankCde
             AND C_DPT_CDE = vDptCde;
        END IF;
      END IF;

      UPDATE WEB_FIN_CAV_MNY
         SET c_sbjt_no = vSbjtNo
       WHERE C_CAV_PK_ID = vCavNo
         AND n_item_no = v_item_no;

      SELECT C_company_cde
        INTO v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = vDptCde;
     /*
       SELECT C_company_cde
        INTO v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_disp_cde = vDptCde;*/

      IF v_company_cde = '?' OR v_company_cde IS NULL THEN
        v_succsflag := -3;
        RETURN;
      END IF;

      vPayName := substr(vPayName, 1, 10);

      INSERT INTO WEB_FIN_TMP_DCR
        (C_SEQ_NO,
         C_ITEM_NO,
         C_CAV_FLAG,
         C_SBJT_NO,
         N_AMT,
         N_EXCH_AMT,
         C_CUR_NO,
         N_RATE,
         C_CHR_CUR_NO,
         T_CRT_TM,
         C_DPTACC_NO,
         C_DPT_CDE,
         C_CAV_NO,
         C_BAL_TYPE,
         C_PAY_NAME,
         C_BANK_CDE,
         C_CHECK_NO,
         T_RP_TM,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SALEGRP_CDE,
         c_pay_prsn_cde,
         C_RI_COM,
         C_CONT_CODE,
         C_VOU_NO,
         c_rp_type,
         C_company_cde,
         c_flow_no,
         c_finbank_cde,
         -- LZC add 2009-04-24 begin
         c_send_flag,
         C_VOU_MEMO

         -- LZC add 2009-04-24 end
         )
      VALUES
        (vTmpVouNo,
         TO_CHAR(i),
         vCavFlag,
         vSbjtNo,
         vAmt,
         NULL,
         vCurNo,
         NULL,
         NULL,
         SYSDATE,
         vDptCde,
         '0',
         vCavNo,
         vBalType,
         vPayName,
         vBankCde,
         vCheckNo,
         vRpTm,
         NULL,
         NULL,
         NULL,
         NULL,
         NULL,
         NULL,
         NULL,
         vRpType,
         v_company_cde,
         v_flow_cde,
         v_finbank_cde,
         -- LZC add 2009-04-24 begin
         '0',
         v_vou_memo
         -- LZC add 2009-04-24 end
         );



    END LOOP;
    CLOSE cur_ifCavMoney;

    --????
    j := i;
    OPEN cur_ifCavObject;
    LOOP
      FETCH cur_ifCavObject
        INTO vSbjtNo, vAmt, vCurNo, vCavDire, vDocDptCde, vSlsCde, vProdNo, v_bsns_typ, vChaCls, vChaCde, vPayName, vPreAmt, vPreFlag, vItemNo,v_OPREMNY_PK_ID ;
      EXIT WHEN cur_ifCavObject%NOTFOUND;

      i := i + 1;

      IF vRpType > '200' AND vCavDire = '2' THEN
        --?
        vCavFlag := '?';
      ELSIF vRpType > '200' AND vCavDire = '1' THEN
        --?
        vCavFlag := '?';
      ELSIF vRpType < '200' AND vCavDire = '2' THEN
        --?
        vCavFlag := '?';
      ELSIF vRpType < '200' AND vCavDire = '1' THEN
        --?
        vCavFlag := '?';
      END IF;

      /*
          ORACLE??????????????,?????0

          119301    ????????
          119707    ???????
      */

      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = vDocDptCde;

      IF v_temp_cnt = 0 THEN
        v_succsflag := -4;
        RETURN;
      END IF;

      SELECT c_department_cde, c_company_cde
        INTO v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = vDocDptCde;

      IF v_company_cde = '?' OR v_company_cde IS NULL OR
         v_department_cde = '?' OR v_department_cde IS NULL THEN
        v_succsflag := -4;
        RETURN;
      END IF;

      IF vSbjtNo = '119301' OR vSbjtNo = '119707' OR vSbjtNo = '119607' OR
         vSbjtNo = '119302' OR vSbjtNo = '119707' OR vSbjtNo = '119201' OR
         vSbjtNo = '214609' OR vSbjtNo = '214614' OR vSbjtNo = '214401' THEN
        vDocDptCde       := '0';
        v_department_cde := '0';
      END IF;

      IF vSbjtNo = '217101' THEN
        SELECT c_prod_no
          INTO vProdNo
          FROM WEB_FIN_CAV_DOC
         WHERE C_CAV_PK_ID = vCavNo
           AND ROWNUM = 1;
      ELSE
        vProdNo := '0';
      END IF;

      INSERT INTO WEB_FIN_TMP_DCR
              (C_SEQ_NO,
               C_ITEM_NO,
               C_CAV_FLAG,
               C_SBJT_NO,
               N_AMT,
               N_EXCH_AMT,
               C_CUR_NO,
               N_RATE,
               C_CHR_CUR_NO,
               T_CRT_TM,
               C_DPTACC_NO,
               C_DPT_CDE,
               C_CAV_NO,
               C_BAL_TYPE,
               C_PAY_NAME,
               C_BANK_CDE,
               C_CHECK_NO,
               T_RP_TM,
               C_SLS_CDE,
               C_PROD_NO,
               c_bsns_typ,
               C_CHA_CLS,
               C_CHA_CDE,
               C_SALEGRP_CDE,
               c_pay_prsn_cde,
               C_RI_COM,
               C_CONT_CODE,
               C_VOU_NO,
               c_rp_type,
               C_company_cde,
               c_department_cde,
               -- LZC add 2009-04-24 begin
               c_send_flag,
               C_VOU_MEMO
               -- LZC add 2009-04-24 end
               )
            VALUES
              (vTmpVouNo,
               TO_CHAR(i),
               vCavFlag,
               vSbjtNo,
               vAmt,
               NULL,
               vCurNo,
               NULL,
               NULL,
               SYSDATE,
               vDptCde,
               vDocDptCde,
               vCavNo,
               NULL,
               vPayName,
               NULL,
               NULL,
               NULL,
               vSlsCde,
               vProdNo,
               v_bsns_typ,
               vChaCls,
               vChaCde,
               v_salegrp_cde,
               NULL,
               null,--v_ri_com,
               NULL,
               NULL,
               vRpType,
               v_company_cde,
               v_department_cde,
               -- LZC add 2009-04-24 begin
               '0',
               v_vou_memo
                -- LZC add 2009-04-24 end
               );

      ---15 ?????????????????????????????
      IF vPreFlag = '2' AND (vRpType = '111' OR vRpType = '112') THEN
        SELECT COUNT(1)
          INTO v_temp_cnt
          FROM WEB_FIN_CAV_MNY
         WHERE C_CAV_PK_ID = v_OPREMNY_PK_ID
           AND C_BAL_TYP = '002001';

        IF v_temp_cnt > 0 THEN
          v_succsflag := -15;
          RETURN;
        END IF;

      END IF;

    END LOOP;
    CLOSE cur_ifCavObject;

    --IF v_replace_flag='0' THEN /*?????/?????,??????*/
    OPEN cur_ifCavDoc;
    LOOP
      FETCH cur_ifCavDoc
        INTO vRcptNo, vExchRate, vCurNo, vAmt, vProdNo, vSlsCde, v_bsns_typ, vChaCls, vChaCde, vDocDptCde, vEdrNo, vFinTypCde, v_pay_name, v_bill_flag, v_ply_no;
      EXIT WHEN cur_ifCavDoc%NOTFOUND;

      i           := i + 1;
      v_tran_flag := '1';
      vMixAmt     := vAmt;
      /*
        IF    vProdNo  in ('0316','0325') and vRpType = '111' and SUBSTR(vDptCde,1,2) ='05' THEN --??
            SELECT COUNT(1)
          INTO    v_temp_cnt
          FROM WEB_FIN_CAV_DOC
          WHERE C_CAV_PK_ID=vCavNo
              AND t_insrnc_bgn_tm <= TRUNC(SYSDATE);

            IF v_temp_cnt> 0  THEN
          v_succsflag  := -14;
          RETURN;
            END IF;
        ELSIF   vProdNo  in ('0316','0325') and vRpType = '112' and SUBSTR(vDptCde,1,2) ='05' THEN --??
              SELECT COUNT(1)
              INTO    v_temp_cnt
            FROM WEB_FIN_CAV_DOC a,WEB_FIN_PRM_DUE b
            WHERE a.C_CAV_PK_ID=vCavNo
            AND b.t_insrnc_bgn_tm>b.t_arp_tm+v_control_days
             AND b.c_prod_no  in ('0316','0325')
            AND a.c_rcpt_no=b.c_rcpt_no;

            IF v_temp_cnt= 0  THEN
          v_succsflag  := -16;
          RETURN;
            END IF;
        END IF;
      */

      IF vRpType = '101' OR vRpType = '201' OR vRpType = '111' OR
         vRpType = '112' THEN
        SELECT c_dpt_cde,
               c_cha_mrk,
               c_prod_no,
               c_tran_flag,
               c_con_dpt_cde,
               C_SLSGRP_CDE,
               c_bsns_typ,
               c_cha_mrk,
               c_ply_no,
               c_edr_no
          INTO vDocDptCde,
               v_cha_mrk,
               vProdNo,
               v_tran_flag,
               v_con_dpt_cde,
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_ply_no,
               vEdrNo
          FROM WEB_FIN_PRM_DUE
         WHERE c_rcpt_no = vRcptNo;
      ELSIF vRpType = '103' OR vRpType = '204' OR vRpType = '205' OR
            vRpType = '207' OR vRpType = '106' THEN
        SELECT c_dpt_cde,
               c_cha_mrk,
               c_prod_no,
               c_tran_flag,
               c_con_dpt_cde,

               C_SLSGRP_CDE,
               c_bsns_typ,
               c_cha_mrk,
               c_eac_dcm_mrk,
               c_ply_no
          INTO vDocDptCde,
               v_cha_mrk,
               vProdNo,
               v_tran_flag,
               v_con_dpt_cde,
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_eac_dcm_mrk,
               v_ply_no
          FROM WEB_FIN_CLM_DUE
         WHERE c_rcpt_no = vRcptNo;
      ELSIF vRpType = '105' OR vRpType = '206' THEN
        SELECT c_dpt_cde,
               c_cha_mrk,
               c_prod_no,
               c_tran_flag,
               c_con_dpt_cde,
               C_SLSGRP_CDE,
               c_bsns_typ,
               c_cha_mrk,
               c_ply_no
          INTO vDocDptCde,
               v_cha_mrk,
               vProdNo,
               v_tran_flag,
               v_con_dpt_cde,
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_ply_no
          FROM WEB_FIN_PAY_DUE
         WHERE c_rcpt_no = vRcptNo;
      ELSIF vRpType = '102' OR vRpType = '202' THEN
        SELECT c_dpt_cde,
               c_cha_mrk,
               c_prod_no,
               c_tran_flag,
               c_con_dpt_cde,
               C_SLSGRP_CDE,
               c_bsns_typ,
               c_cha_mrk,
               c_ply_no,
               c_edr_no
          INTO vDocDptCde,
               v_cha_mrk,
               vProdNo,
               v_tran_flag,
               v_con_dpt_cde,
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_ply_no,
               v_edr_no
          FROM WEB_FIN_SAVEAMT_DUE
         WHERE c_rcpt_no = vRcptNo;
        ELSE
          SELECT c_dpt_cde,
                 c_cha_mrk,
                 c_prod_no,
                 c_tran_flag,
                 c_con_dpt_cde,
                 C_SLSGRP_CDE,
                 c_bsns_typ,
                 c_cha_mrk,
                 c_ply_no
            INTO vDocDptCde,
                 v_cha_mrk,
                 vProdNo,
                 v_tran_flag,
                 v_con_dpt_cde,
                 v_salegrp_cde,
                 v_bsns_typ,
                 v_cha_mrk,
                 v_ply_no
            FROM WEB_FIN_PRM_DUE
           WHERE c_rcpt_no = vRcptNo;

      END IF;

      IF vRpType in ('101', '102') THEN
        SELECT count(1)
          INTO v_temp_cnt
          FROM WEB_EDR_BASE
         WHERE c_ply_no = RTRIM(v_ply_no)
           and C_EDR_TYPE = '2';

        --22 ??????????????????????
        IF v_temp_cnt > 0 THEN
          v_succsflag := -22;
          RETURN;
        END IF;
      END IF;

     --LZC 2009-04-24 ADD BEGIN

   /*     SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_ORG_DPT
       WHERE c_dpt_disp_cde = vDocDptCde;
       */
     --LZC 2009-04-24 ADD END
    SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = vDocDptCde;

      IF v_temp_cnt = 0 THEN
        v_succsflag := -5;
        RETURN;
      END IF;

      SELECT c_department_cde, c_company_cde
        INTO v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = vDocDptCde;

     --LZC 2009-04-24 ADD BEGIN

    /*    SELECT c_department_cde, c_company_cde
        INTO v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_disp_cde = vDocDptCde;*/

     --LZC 2009-04-24 ADD END

      IF v_company_cde = '?' OR v_company_cde IS NULL OR
         v_department_cde = '?' OR v_department_cde IS NULL THEN
        v_succsflag := -5;
        RETURN;
      END IF;

      IF vRpType > '200' THEN
        --??
        vCavFlag := '?';
      ELSE
        vCavFlag := '?';
      END IF;

      IF vRpType = '201' AND vAmt < 0 THEN
        --201 ??/??-?????/?? ??????????    ????/????
        vCavFlag := '?';
      END IF;

      IF vRpType = '201' AND vAmt > 0 THEN
        --201 ??/??-?????/?? ??????????
        vCavFlag := '?';
      END IF;

      BEGIN
        IF vRpType = '101' OR vRpType = '111' OR vRpType = '112' THEN
          /*101 ?????????/?? */

          IF v_tran_flag = '2' THEN
            BEGIN
              vSbjtNo     := '122204';
              vAmt        := vAmt;
              vExchgotPrm := vExchgotPrm;
              vCavFlag    := '?';
            END;
          ELSE
            BEGIN
              v_tmpcnt := 0;
              SELECT TRUNC(v_end_time) - TRUNC(T_DUE_TM) --?????????
                INTO v_tmpcnt
                FROM WEB_FIN_PRM_DUE
               WHERE c_rcpt_no = trim(vRcptNo);

              IF vAmt > 0 AND v_tmpcnt < 0 THEN
                --??????,??????????
                vSbjtNo := '212101'; --????
              ELSIF vAmt > 0 AND v_tmpcnt >= 0 THEN
                --??????,??????????
                vSbjtNo := '112201'; --????
              ELSE
                --=0
                vSbjtNo := '112201'; --????
              END IF;

              IF vAmt < 0 THEN
                IF v_tmpcnt < 0 THEN
                  --??
                  vSbjtNo     := '212101';
                  vAmt        := -ABS(vAmt);
                  vExchgotPrm := -ABS(vExchgotPrm);
                ELSE
                  --??
                  vSbjtNo     := '112201';
                  vAmt        := -ABS(vAmt);
                  vExchgotPrm := -ABS(vExchgotPrm);
                END IF;
              END IF;
              vCavFlag := '?';
            END;
          END IF;

        ELSIF vRpType = '103' THEN
          /*103 ??? */
          BEGIN
            vSbjtNo     := '440106'; --????/????? ?????? ???? 440106
            vCavFlag    := '?';
            vAmt        := vAmt;
            vExchgotPrm := vExchgotPrm;

            SELECT c_feetyp_cde
              INTO vFinTypCde
              FROM WEB_FIN_CLM_DUE
             WHERE c_rcpt_no = vRcptNo;

            --????????????
            IF v_eac_dcm_mrk = '1' THEN
              BEGIN
                vSbjtNo := '212201';
              END;
            ELSIF v_eac_dcm_mrk = '5' THEN
              --???
              BEGIN
                /*
                    ??????
                    ??????????
                */
                vSbjtNo := '440104';
              END;
            ELSIF v_eac_dcm_mrk = '2' THEN
              --
              BEGIN
                /*
                    ??????
                    ??????
                */
                vSbjtNo := '215001';
              END;
            ELSIF v_eac_dcm_mrk = '6' THEN
              --??????
              BEGIN
                vSbjtNo := '440104';
              END;
            END IF;
          /*
            IF v_abby_flag = '2' THEN
              --??????
              vSbjtNo := '2149XX'; --?????
            END IF;
          */
          END;
        ELSIF vRpType = '201' THEN
          /*201 ??/??-?????/?? ????????????????????   ?????????????????????????? ??????*/
          IF v_tran_flag = '2' THEN
            BEGIN
              vSbjtNo     := '122204';
              vAmt        := vAmt;
              vExchgotPrm := vExchgotPrm;
              vCavFlag    := '?';
            END;
          ELSE
            BEGIN
              SELECT TRUNC(v_end_time) - TRUNC(T_DUE_TM)
                INTO v_tmpcnt
                FROM WEB_FIN_PRM_DUE
               WHERE c_rcpt_no = trim(vRcptNo);

              IF vAmt > 0 THEN
                /*?????????????????????????? ???????????????????????????????*/
                IF v_tmpcnt < 0 THEN
                  --??
                  vSbjtNo  := '212101';
                  vCavFlag := '?';
                ELSE
                  --??
                  vSbjtNo  := '112201';
                  vCavFlag := '?';
                END IF;

                vAmt        := -ABS(vAmt);
                vExchgotPrm := -ABS(vExchgotPrm);
              ELSE

                IF vFinTypCde <> 'GR' THEN
                  --?????????????????????????
                  IF v_tmpcnt < 0 THEN
                    vSbjtNo := '212101'; --????

                    vCavFlag    := '?';
                    vAmt        := ABS(vAmt);
                    vExchgotPrm := ABS(vExchgotPrm);
                  ELSE
                    vSbjtNo     := '112201'; --????
                    vCavFlag    := '?';
                    vAmt        := ABS(vAmt);
                    vExchgotPrm := ABS(vExchgotPrm);
                  END IF;
                END IF;
              END IF;
            END;
          END IF;

        ELSIF vRpType = '202' THEN
          /*202 ??/??????*/
          vSbjtNo := '217101'; --????
          vCavFlag    := '?';
          vAmt        := -vAmt;
          vExchgotPrm := -vExchgotPrm;
        /*
        ELSIF vRpType = '202' THEN
          /*202 ??/??????
          vSbjtNo := '217101'; --????

          vCavFlag := '?';
          IF v_edr_no = ' ' or v_edr_no is null THEN
            vSbjtNo     := '217101'; --????
            vAmt        := vAmt;
            vExchgotPrm := vExchgotPrm;
            vCavFlag    := '?';
          ELSE
            vAmt        := -vAmt;
            vExchgotPrm := -vExchgotPrm;
          END IF;*/
        ELSIF vRpType = '212' THEN
          /*212 ??/??????*/
          vSbjtNo := '217101'; --????

          vCavFlag := '?';
          IF v_edr_no = ' ' or v_edr_no is null THEN
            vSbjtNo     := '217101'; --????
            vAmt        := vAmt;
            vExchgotPrm := vExchgotPrm;
            vCavFlag    := '?';
          ELSE
            vAmt        := -vAmt;
            vExchgotPrm := -vExchgotPrm;
          END IF;
        ELSIF vRpType = '102' THEN
          /*102 ???*/
          vSbjtNo  := '217101'; --????
          vCavFlag := '?';

          IF v_edr_no <> ' ' and v_edr_no is not null THEN
            vSbjtNo     := '217101'; --????
            vAmt        := -vAmt;
            vExchgotPrm := -vExchgotPrm;
            vCavFlag    := '?';
          ELSE
            vAmt        := vAmt;
            vExchgotPrm := vExchgotPrm;
          END IF;
        ELSIF vRpType = '204' THEN
          /*204 ????*/
          BEGIN
            vAmt        := -vAmt;
            vExchgotPrm := -vExchgotPrm;
            IF v_eac_dcm_mrk = '1' THEN
              vSbjtNo := '113101'; --??????????  ?????????
            ELSIF v_eac_dcm_mrk = '5' THEN
              --5 ???
              vSbjtNo := '440104';
            ELSIF v_eac_dcm_mrk = '6' THEN
              --6??????
              vSbjtNo := '440104';
            END IF;
			/*
            IF v_abby_flag = '2' THEN
              --??????
              vSbjtNo := '2149XX'; --?????
            END IF;
			*/

          END;
        ELSIF vRpType = '205' THEN
          /*205 ??*/
          vAmt        := -vAmt;
          vExchgotPrm := -vExchgotPrm;

          IF v_eac_dcm_mrk = '2' THEN
            vCavFlag := '?';
            vSbjtNo  := '215001'; --????
          ELSIF v_eac_dcm_mrk = '1' THEN
            vCavFlag := '?';
            vSbjtNo  := '113101'; --??????????  ?????????
          ELSIF v_eac_dcm_mrk = '5' THEN
            --5 ???
            vCavFlag := '?';
            vSbjtNo  := '440104';
          ELSE
            -- ?:  ????  ?: ?????????
            vCavFlag := '?';
            vSbjtNo  := '410301';
          END IF;
		  /*
          IF v_abby_flag = '2' THEN
            --??????
            vSbjtNo := '2149XX'; --?????
          END IF;
		  */
        ELSIF vRpType = '105' THEN
          /*105 ????? ????????? ???????*/
          vSbjtNo     := '211101';
          vCavFlag    := '?';
          vAmt        := vAmt;
          vExchgotPrm := vExchgotPrm;
        ELSIF vRpType = '206' THEN
          /*206 ?????*/
          vSbjtNo := '211101'; --?????

          vCavFlag    := '?';
          vAmt        := -vAmt;
          vExchgotPrm := -vExchgotPrm;
        ELSIF vRpType = '106' THEN
          vAmt        := ABS(vAmt);
          vExchgotPrm := ABS(vExchgotPrm);
          vCavFlag    := '?';
          vSbjtNo     := '215001'; /*?????-??????*/
		  /*
          IF v_abby_flag = '2' THEN
            --??????
            vSbjtNo := '2149XX'; --?????
          END IF;
          */
        ELSIF vRpType = '207' THEN
          vAmt        := -vAmt;
          vExchgotPrm := -vExchgotPrm;
          vCavFlag    := '?';
          IF v_tran_flag = '2' THEN
            vSbjtNo := '122204';
          ELSE
            vSbjtNo := '215001'; /*?????????*/
          END IF;
		  /*
          IF v_abby_flag = '2' THEN
            --??????
            vSbjtNo := '2149XX'; --?????
          END IF;
		  */
        END IF;
      END;

      IF v_MakeVou = 'Y' THEN
        IF vRpType = '101' OR vRpType = '111' OR vRpType = '112' THEN
          SELECT c_tran_flag
            INTO v_tran_flag
            FROM WEB_FIN_PRM_DUE
           WHERE c_rcpt_no = vRcptNo;

        ELSIF vRpType = '205' THEN
          SELECT c_tran_flag
            INTO v_tran_flag
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = vRcptNo;
          IF v_tran_flag = '2' THEN
            vSbjtNo  := '112201'; --????
            vCavFlag := '?';
          END IF;

        END IF;

        SELECT COUNT(*)
          INTO v_temp_cnt
          FROM WEB_BAS_FIN_PROD
         WHERE c_prod_no = vProdNo;

        IF v_temp_cnt = 0 THEN
          v_succsflag := -6;
          RETURN;
        END IF;

        SELECT c_kind_no
          INTO v_kind_no
          FROM WEB_BAS_FIN_PROD
         WHERE c_prod_no = vProdNo;

        vPayName := substr(vPayName, 1, 10);

		    INSERT INTO WEB_FIN_TMP_DCR
          (C_SEQ_NO,
           C_ITEM_NO,
           C_CAV_FLAG,
           C_SBJT_NO,
           N_AMT,
           N_EXCH_AMT,
           C_CUR_NO,
           N_RATE,
           C_CHR_CUR_NO,
           T_CRT_TM,
           C_DPTACC_NO,
           C_DPT_CDE,
           C_CAV_NO,
           C_RCPT_NO,
           C_BAL_TYPE,
           C_PAY_NAME,
           C_BANK_CDE,
           C_CHECK_NO,
           T_RP_TM,
           C_SLS_CDE,
           C_PROD_NO,
           c_bsns_typ,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_rp_type,
           c_cha_mrk,
           c_con_dpt_cde,
           c_company_cde,
           c_ply_no,
           c_kind_no,
           c_department_cde,
           -- LZC add 2009-04-24 begin
           c_send_flag,
           C_VOU_MEMO
           -- LZC add 2009-04-24 end
           )
        VALUES
          (vTmpVouNo,
           TO_CHAR(i),
           vCavFlag,
           vSbjtNo,
           vAmt,
           vExchgotPrm,
           vCurNo,
           vExchRate,
           vChrCurNo,
           SYSDATE,
           vDptCde,
           vDocDptCde,
           vCavNo,
           vRcptNo,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           vSlsCde,
           vProdNo,
           v_bsns_typ,
           vChaCls,
           vChaCde,
           v_salegrp_cde,
           NULL,
           NULL,
           NULL,
           NULL,
           v_pay_name,
           v_sbjt_memo,
           vRpType,
           v_cha_mrk,
           v_con_dpt_cde,
           v_company_cde,
           v_ply_no,
           v_kind_no,
           v_department_cde,
           -- LZC add 2009-04-24 begin
           '0',
           v_vou_memo
           -- LZC add 2009-04-24 end
           );
      END IF;
    END LOOP;
    CLOSE cur_ifCavDoc;

    IF vRpType in ('111', '112') AND SUBSTR(vDptCde, 1, 2) = '03' THEN
      --24 ??????????????????????????
      select count(1)
        INTO v_shplycnt
        from WEB_FIN_CAV_DOC
       WHERE C_CAV_PK_ID = vCavNo
         and length(nvl(c_edr_no, '1')) > 8;

      select count(1)
        INTO v_shedrcnt
        from WEB_FIN_CAV_DOC
       WHERE C_CAV_PK_ID = vCavNo
         and length(nvl(c_edr_no, '1')) < 8;

      IF v_shplycnt > 0 AND v_shedrcnt > 0 THEN
        v_succsflag := -24;
        RETURN;
      END IF;
      --25 ?????????????????????????????????
      select c_batch_no
        INTO v_batch_no
        from WEB_FIN_CAV_DOC a, WEB_FIN_PRM_DUE b
       WHERE a.C_CAV_PK_ID = vCavNo
         and a.c_rcpt_no = b.c_rcpt_no
         and rownum = 1;

      select count(1)
        INTO v_shplycnt
        from WEB_FIN_CAV_DOC a, WEB_FIN_PRM_DUE b
       WHERE a.C_CAV_PK_ID = vCavNo
         and a.c_rcpt_no = b.c_rcpt_no
         and c_batch_no <> v_batch_no;
      IF v_shplycnt > 0 THEN
        v_succsflag := -25;
        RETURN;
      END IF;

    END IF;

    --28 ??????,????????????
    IF vRpType in ('111', '112') AND SUBSTR(vDptCde, 1, 2) = '09' THEN
      select count(distinct a.C_PAYER_NME)
        INTO v_shplycnt
        from WEB_FIN_PRM_DUE a, WEB_FIN_CAV_DOC b
       where a.c_rcpt_no = b.c_rcpt_no
         AND a.c_prod_no NOT in ('0316', '0325')
         and b.C_CAV_PK_ID = vCavNo;
      IF v_shplycnt > 1 THEN
        v_succsflag := -28;
        RETURN;
      END IF;
    END IF;

    --29 ??????????????
    IF vRpType = '111' AND SUBSTR(vDptCde, 1, 2) = '09' THEN
      select count(1)
        INTO v_shplycnt
        from WEB_FIN_CAV_DOC b
       where C_CAV_PK_ID = vCavNo
         AND c_prod_no not in ('0316', '0325');

      IF v_shplycnt > 1 THEN
        v_succsflag := -29;
        RETURN;
      END IF;
    END IF;

    /*
            IF     vRpType ='112' THEN
        SELECT c_rcpt_no
          INTO v_rcpt_no
          FROM WEB_FIN_CAV_DOC
          WHERE C_CAV_PK_ID=vCavNo AND ROWNUM =1;

        SELECT c_prn_no
          INTO v_prn_no
          FROM WEB_FIN_PRM_DUE
          WHERE c_rcpt_no=v_rcpt_no;

        SELECT COUNT(1)
        INTO v_shplycnt
          FROM WEB_FIN_CAV_DOC a,WEB_FIN_PRM_DUE b
          WHERE a.C_CAV_PK_ID<> vCavNo
          and a.c_rcpt_no=b.c_rcpt_no
          and b.c_rcpt_no<>v_rcpt_no
          and b.c_prn_no=v_prn_no
          and  exists (SELECT C_DPT_CDE FROM WEB_ORG_DPT
          WHERE c_dpt_cde=b.c_dpt_cde and c_dptacc_cde =vDptCde)
          and b.T_DUE_TM >sysdate -30;
          IF v_shplycnt>0 THEN
        v_succsflag  := -27;
        RETURN;
          END IF;

      END IF;
    */
  /*
    OPEN cur_ifriDoc;
    LOOP
      FETCH cur_ifriDoc
        INTO v_doc_flag, v_ri_com, v_cont_code, vRcptNo, vCurNo, vExchRate, vAmt, vExchgotPrm, vDocDptCde, vDptCde;
      EXIT WHEN cur_ifriDoc%NOTFOUND;

      SELECT c_dpt_cde,
             c_doc_flag,
             c_ri_com,
             c_cont_code,
             T_DUE_TM,
             c_prod_no
        INTO vDptCde, v_doc_flag, v_ri_com, v_cont_code, v_DUE_TM, vProdNo
        FROM WEB_FIN_RICED_DUE
       WHERE c_rcpt_no = vRcptNo;
      vDocDptCde := '00000019';

      --????????????????
      i := i + 1;


      v_vou_memo       := '?????????';
      v_servicetype_no := '1114';
      vAmt             := vAmt;
      vExchgotPrm      := vExchgotPrm;

      IF v_DUE_TM <= TO_DATE('2007-06-28', 'YYYY-MM-DD') THEN
        IF vRpType = '107' THEN
          --??????      ???????????????
          vCavFlag := '?';

          vSbjtNo := '211301';
        ELSE
          --209
          vCavFlag := '?';

          vSbjtNo := '211301';

          vAmt        := -vAmt;
          vExchgotPrm := -vExchgotPrm;
        END IF;
      ELSE
        IF vRpType = '107' THEN
          --??????      ???????????????
          vCavFlag := '?';

          IF v_doc_flag = '1' THEN
            --1 ????
            vSbjtNo := '211301';
          ELSIF v_doc_flag = '2' THEN
            --2 ????????
            vSbjtNo := '122201';
          ELSIF v_doc_flag = '3' THEN
            --3 ????????
            vSbjtNo := '122202';
          ELSE
            vSbjtNo := '122201';
          END IF;
        ELSE
          --209
          vCavFlag := '?';

          IF v_doc_flag = '1' THEN
            --1 ????
            vSbjtNo := '211301';
          ELSIF v_doc_flag = '2' THEN
            --2 ????????
            vSbjtNo := '122201';
          ELSIF v_doc_flag = '3' THEN
            --3 ????????
            vSbjtNo := '122202';
          ELSE
            vSbjtNo := '211301';
          END IF;

          vAmt        := -vAmt;
          vExchgotPrm := -vExchgotPrm;
        END IF;
      END IF;

      SELECT c_company_cde, c_department_cde
        INTO v_company_cde, v_department_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = vDptCde;

      IF v_company_cde = '?' OR v_company_cde IS NULL OR
         v_department_cde = '?' OR v_department_cde IS NULL THEN
        v_succsflag := -5;
        RETURN;
      END IF;

      SELECT COUNT(*)
        INTO v_temp_cnt
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = vProdNo;

      IF v_temp_cnt = 0 THEN
        v_succsflag := -6;
        RETURN;
      END IF;

      SELECT c_kind_no
        INTO v_kind_no
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = vProdNo;

      INSERT INTO WEB_FIN_TMP_DCR
        (C_SEQ_NO,
         n_item_no,
         C_CAV_FLAG,
         c_sbjt_no,
         N_AMT,
         N_EXCH_AMT,
         C_CUR_NO,
         N_RATE,
         C_CHR_CUR_NO,
         T_CRT_TM,
         c_dptacc_cde,
         C_DPT_CDE,
         C_CAV_PK_ID,
         C_RCPT_NO,
         C_BAL_TYP,
         C_PAYER_NME,
         C_BANK_CDE,
         C_CHECK_NO,
         T_RP_TM,
         C_SLS_CDE,
         C_PROD_NO,
         c_bsns_typ,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SLSGRP_CDE,
         c_pay_prsn_cde,
         C_RI_COM,
         C_CONT_CODE,
         C_VOU_NO,
         C_pay_prsn_name,
         c_sbjt_memo,
         c_rp_type,
         c_company_cde,
         c_kind_no,
         c_department_cde)
      VALUES
        (vTmpVouNo,
         TO_CHAR(i),
         vCavFlag,
         vSbjtNo,
         vAmt,
         vExchgotPrm,
         vCurNo,
         vExchRate,
         vChrCurNo,
         SYSDATE,
         vDocDptCde,
         vDptCde,
         vCavNo,
         vRcptNo,
         NULL,
         NULL,
         NULL,
         NULL,
         NULL,
         vSlsCde,
         vProdNo,
         v_bsns_typ,
         vChaCls,
         vChaCde,
         v_salegrp_cde,
         NULL,
         v_ri_com,
         v_cont_code,
         NULL,
         v_pay_name,
         v_sbjt_memo,
         vRptype,
         v_company_cde,
         v_kind_no,
         v_department_cde);

    END LOOP;
    CLOSE cur_ifriDoc;
  */
    --END IF;/*?????????*/


    UPDATE WEB_FIN_TMP_DCR
       SET c_vou_memo       = v_vou_memo,
           c_servicetype_no = v_servicetype_no,
           c_sbjt_memo      = DECODE(c_sbjt_memo,
                                     NULL,
                                     '0',
                                     ' ',
                                     '0',
                                     c_sbjt_memo),
           c_dpt_cde        = DECODE(c_dpt_cde,
                                     NULL,
                                     '0',
                                     ' ',
                                     '0',
                                     c_dpt_cde),
           c_prod_no        = DECODE(c_prod_no,
                                     NULL,
                                     '0',
                                     ' ',
                                     '0',
                                     c_prod_no),
           c_bsns_typ       = DECODE(c_bsns_typ,
                                     NULL,
                                     '0',
                                     ' ',
                                     '0',
                                     c_bsns_typ),
           c_kind_no        = NVL(c_kind_no, '0')
     WHERE C_SEQ_NO = vTmpVouNo;

    /*
    EXCEPTION

        WHEN OTHERS THEN
        BEGIN
    --        RAISE;
    --        dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);

            v_succsflag  := -9;


            v_err_content:='proc:[Generateavoucher],??????['|| vRpType||vDptCde||vChrCurNo||to_char(vSumAmt)||v_replace_flag||'],?????['||sqlcode||SQLERRM;

            INSERT INTO WEB_BAS_FIN_ERRORLOG
            (
                c_err_no,
                c_errtype_no,
                c_tran_type,
                c_err_content,
                t_crt_tm
            )
            VALUES(
                f_fin_getcode('e','00'),
                '008',    --????
                '0000',    --??????
                v_err_content,
                sysdate
            );

        END;
    */
  END;
end P_test_COLLECTFU;
/
