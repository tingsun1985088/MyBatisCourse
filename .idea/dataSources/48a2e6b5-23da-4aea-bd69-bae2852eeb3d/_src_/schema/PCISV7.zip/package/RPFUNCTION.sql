CREATE PACKAGE "RPFUNCTION" is

  --此包包含收付应用的一些基本函数
  function getRate(v_cur1 varchar2, v_cur2 varchar2, v_time date)
    return number; --汇率
  function getServicetype(v_servicetype varchar2) return varchar2; --业务类型
  function getFinCur(v_cur varchar2) return varchar2; --财务币种
  function getFinCurName(v_cur varchar2) return varchar2; --财务币种
  function getFinDepart(v_dpt_cde varchar2,v_rcpt_no varchar2) return varchar2; --获取成本中心信息
  function getFinCompany(v_dpt_cde varchar2,v_rcpt_no varchar2) return varchar2; --获取公司段信息
  function getFinProd(v_prod_no varchar2,v_clm_no varchar2,v_app_no varchar2,v_edr_no varchar2,v_mrk varchar2) return varchar2; --获取财务产品
  function getFinCha(v_cha varchar2,v_rcpt_no varchar2) return varchar2; --获取财务渠道编码
  function getVhl(v_app_no varchar2) return varchar2;--获取车型
  function getKindName(v_kind_no varchar2,v_prod_no varchar2,v_cvrg_no varchar2) return varchar2; --获取险类名称
  function getKindNo(v_kind_no varchar2,v_prod_no varchar2,v_cvrg_no varchar2) return varchar2; --对特殊产品或险别进行处理
  
 /* function getDptCde(v_to_newOrOld varchar2,v_dptCde varchar2) return varchar2; --机构转码 wkf 2013-5-27
  function getEmpCde(v_to_newOrOld varchar2,v_empCde varchar2) return varchar2; --员工转码 wkf 2013-5-30*/
 
  end rpfunction;

/
