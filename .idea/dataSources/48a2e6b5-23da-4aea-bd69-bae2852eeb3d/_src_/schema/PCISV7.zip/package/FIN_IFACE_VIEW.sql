CREATE package fin_iface_view is
      --编译视图
      procedure fin_compile_view(succflag out varchar2);
      --刷新视图
      procedure fin_refresh_view(succflag out varchar2);
end fin_iface_view;
/
