CREATE Package Body FIN_iface_optimize is

procedure p_get_report(
            t_bgn_tm  IN  date,
            t_end_tm  IN  date ,
            dptlen   IN  int,
            v_C_TYPE in varchar2,
            v_ret_sta OUT number)
is
  v_sql   varchar2(5000);
  v_sql2   varchar2(5000);
  v_curId  integer;
  v_rownum number;
  v_year  varchar2(4);
  v_month  varchar2(2);
  v_ts   varchar2(20);

  v_t_bgn_tm   varchar2(20);
  v_t_end_tm   varchar2(20);
  v_t_bgn_tm2  varchar2(20);
  v_t_end_tm2  varchar2(20);
  v_return     varchar2(20);
  e_continue EXCEPTION;
  cursor curItem is
      select C_MEASURE_CODE, C_MEASURE_NAME, C_KIND_NO_CON, C_KIND_NO_VAL, C_CAR_KIND_CON,
      C_CAR_KIND_VAL, C_NEW_FLAG_CON, C_NEW_FLAG_VAL, AMOUNT, C_INSRNC_CDE_CON, C_INSRNC_CDE_VAL,
      TABLE_VIEW_NAME, C_BSNS_TYPE_CON, C_BSNS_TYPE_VAL, C_EDR_TYPE_CON, C_EDR_TYPE_VAL, C_EDR_NO_CON,
      C_EDR_NO_VAL, N_PRM_YUAN_CON, N_PRM_YUAN_VAL, C_LOSS_STAT_CON, C_LOSS_STAT_VAL,
      C_CAR_TYPE_CON, C_CAR_TYPE_VAL, C_PROD_CON, C_PROD_VAL,C_DUTY_FLAG_CON,C_DUTY_FLAG_VAL,
      C_T_PK_TM,C_WHERE_OTHERS,C_CUR_CDE_CON,C_CUR_CDE_VAL,C_APPT_NATION_CON,C_APPT_NATION_VAL,
      C_DOC_FLAG_CON,C_DOC_FLAG_VAL,c_cont_typ_cde_CON,c_cont_typ_cde_VAL,
      C_USE_ATR_CON,C_USE_ATR_VAL,C_Agri_Mrk_CON,C_Agri_Mrk_VAL,
      C_Nat_Typ_CON,C_Nat_Typ_VAL,C_Fin_Typ_con,C_Fin_Typ_val,c_salegrp_cde_con,c_salegrp_cde_val,
      c_cont_cde_con,c_cont_cde_val,C_MEASURE_TYPE,C_VALIDATE,C_REPORT_FLASH,C_REPORT_MONTH,C_REPORT_QUARTER,
      C_REPORT_YEAR,C_REPORT_YEAR_HALF,C_USAGE_CDE_CON,C_USAGE_CDE_VAL,C_FLAG,C_RATE
      from FIN_MEASURE_ITEM a
      where T_ADB_TM is Null --and c_measure_code='61080335'
        --1，快报 2 月报 3 季报 4半年报 5 年报
        and (
               (v_C_TYPE = '1' and C_REPORT_FLASH='是') or--快报指标
               (v_C_TYPE = '2' and C_REPORT_MONTH='是') or--月指标
               (v_C_TYPE = '3' and C_REPORT_QUARTER='是') or--季指标
               (v_C_TYPE = '4' and C_REPORT_YEAR_HALF='是') or--半年指标
               (v_C_TYPE = '5' and C_REPORT_YEAR='是') or--年指标
               (v_C_TYPE = '6' and C_REPORT_FINTYEAR='是')--年度指标
             );
begin
  --刷新视图(已经将普通视图全部改为物化视图,以提高效率)(全量刷新) begin add by shexiwan 2012-01-10
  --编译视图
  ---fin_iface_view.fin_compile_view(v_return);
  --刷新视图
  --fin_iface_view.fin_refresh_view(v_return);
  --刷新视图(全量刷新) end
  v_ret_sta := 0;
  v_year := to_char(t_end_tm,'YYYY');
  v_month := to_char(t_end_tm,'MM');
  v_ts := TO_CHAR(t_end_tm,'yyyy-mm-dd hh24:mi:ss');
  v_curId := dbms_sql.open_cursor;
  --v_t_bgn_tm := to_char(t_bgn_tm,'yyyy-mm-dd')|| ' 00:00:00';
  v_t_bgn_tm:=v_year||'-01-01 00:00:00';
  v_t_end_tm := to_char(t_end_tm ,'yyyy-mm-dd')||' 23:59:59';

  DELETE FROM FIN_measure WHERE year = to_char(t_end_tm,'YYYY') and month= to_char(t_end_tm,'MM') AND C_TYPE=v_C_TYPE;/*删除已有数据以避免数据重复*/
commit;
  for v_re in curItem loop
  begin
    if RTRIM(LTRIM(v_re.TABLE_VIEW_NAME)) <> '---' then
        v_sql:='';
        v_sql := 'insert into circi.FIN_measure(unitcode, year, month, measurecode, measurename, amount, remark, ts,DPTACCCDE,C_TYPE)';

        v_sql := v_sql || ' select c_department_cde,'  || ' ''' || v_year || ''',''' || v_month || ''',''';

        --v_sql := v_sql || v_re.C_MEASURE_CODE ||''',''' || v_re.C_MEASURE_NAME || ''',' || v_re.amount || ',''' || v_re.C_MEASURE_NAME || ''',''' || v_ts || ''',C_COMPANY_CDE' || ',''' || v_C_TYPE || '''';
        v_sql := v_sql || v_re.C_MEASURE_CODE ||''',''' || v_re.C_MEASURE_NAME || ''',' ;
        v_sql := v_sql || v_re.amount ||'*decode(nvl(' || v_re.C_RATE||',0),0,1,GET_FINRATE(a.c_cur_no,''01'', trunc(to_date('''||v_t_end_tm ||''',''yyyy-mm-dd hh24:mi:ss''))))' ||',''' ;
        v_sql := v_sql ||  v_re.C_MEASURE_NAME || ''',''' || v_ts || ''',C_COMPANY_CDE' || ',''' || v_C_TYPE || '''';

        v_sql := v_sql || ' from ' || v_re.TABLE_VIEW_NAME || ' a where 1=1 ';

        if v_re.C_KIND_NO_CON <> '---' then
         v_sql := v_sql || ' and c_kind_no ' || v_re.C_KIND_NO_CON || v_re.C_KIND_NO_VAL;
        end if;
        if v_re.C_CAR_KIND_CON <> '---' then
         v_sql := v_sql || ' and c_car_kind ' || v_re.C_CAR_KIND_CON || v_re.C_CAR_KIND_VAL;
        end if;
        if v_re.C_NEW_FLAG_CON <> '---' then
         v_sql := v_sql || ' and C_NEW_FLAG ' || v_re.C_NEW_FLAG_CON || v_re.C_NEW_FLAG_VAL;
        end if;
        if v_re.C_INSRNC_CDE_CON <> '---' then
         v_sql := v_sql || ' and C_INSRNC_CDE ' || v_re.C_INSRNC_CDE_CON || v_re.C_INSRNC_CDE_VAL;
        end if;
        if v_re.c_bsns_type_con <> '---' then
         v_sql := v_sql || ' and c_bsns_type ' || v_re.c_bsns_type_con || v_re.c_bsns_type_val;
        end if;
        if v_re.c_edr_type_con <> '---' then
         v_sql := v_sql || ' and c_edr_type ' || v_re.c_edr_type_con || v_re.c_edr_type_val;
        end if;
        if v_re.c_edr_no_con <> '---' then
         v_sql := v_sql || ' and c_edr_no ' || v_re.c_edr_no_con || v_re.c_edr_no_val;
        end if;
        if v_re.n_prm_yuan_con <> '---' then
         v_sql := v_sql || ' and n_prm_yuan ' || v_re.n_prm_yuan_con || v_re.n_prm_yuan_val;
        end if;
        if v_re.c_loss_stat_con <> '---' then
         v_sql := v_sql || ' and C_CLM_MAINSTATUS ' || v_re.c_loss_stat_con || v_re.c_loss_stat_val;
        end if;
        if v_re.c_car_type_con <> '---' then
         v_sql := v_sql || ' and c_car_type ' || v_re.c_car_type_con || v_re.c_car_type_val;
        end if;
        if trim(v_re.c_prod_con) <> '---' then
         v_sql := v_sql || ' and c_prod_no ' || v_re.c_prod_con || v_re.c_prod_val;
        end if;
        if v_re.C_DUTY_FLAG_CON <> '---' then
         v_sql := v_sql || ' and C_DUTY_FLAG ' || v_re.C_DUTY_FLAG_CON || v_re.C_DUTY_FLAG_val;
        end if;

        if v_re.c_t_pk_tm <> '---' Then
          v_sql:= v_sql || ' and '||v_re.c_t_pk_tm ;
        Else

          /* If SUBSTR(v_re.C_MEASURE_CODE,1,4)  In ( '6122','6123','6124')  Then
                v_sql := v_sql || 'and t_pk_tm <= TO_CHAR ( t_end_tm ,''YYYY-MM'') ';
             Else */
             v_sql := v_sql || ' AND T_DUE_TM >= :t_bgn_tm AND T_DUE_TM <= :t_end_tm ';
           /*End If; */
        end if;

       if v_re.C_where_others <> '---' then
         v_sql := v_sql || ' and ' || v_re.C_where_others;
        end if;
        if v_re.c_cur_cde_con <> '---' then
          v_sql := v_sql || ' and c_cur_cde '|| v_re.c_cur_cde_con || v_re.c_cur_cde_val;
        end if;
        if v_re.C_APPT_NATION_CON <> '---' then --境内外
          v_sql := v_sql || ' and C_APPT_NATION '|| v_re.C_APPT_NATION_CON || v_re.C_APPT_NATION_VAL;
        end if;
        if v_re.C_DOC_FLAG_CON <> '---' then
         v_sql := v_sql || ' and C_DOC_FLAG  ' || v_re.C_DOC_FLAG_CON || v_re.C_DOC_FLAG_VAL;
        end if;
        if v_re.c_cont_typ_cde_CON <> '---' then
         v_sql := v_sql || ' and c_cont_typ_cde ' || v_re.c_cont_typ_cde_CON || v_re.c_cont_typ_cde_VAL;
        end if;
        if v_re.C_Agri_Mrk_con <> '---' then  --涉农标志
          v_sql := v_sql || ' and C_Agri_Mrk ' || v_re.C_Agri_Mrk_con || v_re.C_Agri_Mrk_val;
        end if;
        if v_re.C_Nat_Typ_con <> '---' then
          v_sql := v_sql || ' and C_Nat_Typ ' || v_re.C_Nat_Typ_con || v_re.C_Nat_Typ_val;
        end if;
        if v_re.C_USE_ATR_con <> '---' then  --使用性质
          v_sql := v_sql || ' and C_USE_ATR ' || v_re.C_USE_ATR_con || v_re.C_USE_ATR_val;
        end if;
        if v_re.C_Fin_Typ_con <> '---' then
          v_sql := v_sql || ' and C_Fin_Typ ' || v_re.C_Fin_Typ_con || v_re.C_Fin_Typ_val;
        end if;
        if v_re.c_salegrp_cde_con <> '---' then
          v_sql := v_sql || ' and c_salegrp_cde ' || v_re.c_salegrp_cde_con || v_re.c_salegrp_cde_val;
        end if;
        if v_re.c_cont_cde_con <> '---' then  --再保中合约类型
          v_sql := v_sql || ' and c_cont_cde ' || v_re.c_cont_cde_con || v_re.c_cont_cde_val;
        end if;
        if v_re.C_USAGE_CDE_CON <> '---' then  --车辆使用性质
          v_sql := v_sql || ' and C_USAGE_CDE ' || v_re.C_USAGE_CDE_CON || v_re.C_USAGE_CDE_VAL;
        end if;

        --v_sql := replace( v_sql, ':t_bgn_tm', ' to_date(''' || v_t_bgn_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
        if v_re.c_flag is null or v_re.c_flag = '0' then
           v_sql := replace( v_sql, ':t_bgn_tm', ' to_date(''' || v_t_bgn_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
        elsif v_re.c_flag in( '1' ,'3')then
           v_t_bgn_tm2 := '2010-01-01 00:00:00';
           v_sql := replace( v_sql, ':t_bgn_tm', ' to_date(''' || v_t_bgn_tm2 || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
        elsif v_re.c_flag = '4' then
           v_t_bgn_tm2 := '2010-01-01 00:00:00';
           v_sql := replace( v_sql, ':t_bgn_tm', ' to_date(''' || v_t_bgn_tm2 || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
           /*v_sql:=v_sql || ' and ( t_paid_tm is null or ';
           v_sql:=v_sql || ' t_paid_tm>to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss''))';
           v_sql:=v_sql || ' and not exists ( select 1 from web_fin_prm_due d where d.c_ply_no=a.c_ply_no and d.c_edr_typ=''2'' and t_due_tm<= to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss'')) ';
           */
        else
           v_sql := replace( v_sql, ':t_bgn_tm', ' to_date(''' || v_t_bgn_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
        end if;
        v_sql := replace( v_sql, ':t_end_tm', ' to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
        --账龄(计算应收时用)
        v_sql := replace( v_sql, ':t_vou_date', ' to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );

        -- v_sql := replace( v_sql, ' t_end_tm', ' to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
        if(SUBSTR(v_re.c_measure_code,1,1)<>'a') then
          if  SUBSTR(v_re.C_MEASURE_CODE,1,2)  = '82'  then
             v_sql := replace( v_sql, ':t_bgn_tm', 'trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -12 ), ''yyyy'')' );
             v_sql := replace( v_sql, ':t_bend_tm', 'trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -12 ), ''yyyy'')-1' );
          else
            if SUBSTR(v_re.C_MEASURE_CODE,1,2) = '83'  then
               v_sql := replace( v_sql, ':t_bgn_tm', 'trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -24 ), ''yyyy'')' );
               v_sql := replace( v_sql, ':t_bend_tm','trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -24 ), ''yyyy'')-1' );
            else
                v_sql := replace( v_sql, ':t_bgn_tm', ' to_date(''' || v_t_bgn_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
               v_sql := replace( v_sql, ':t_bend_tm',  ' to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
             end if;
          end if;
        end if;
        v_sql2 := v_sql;
     /*  if --v_re.TABLE_VIEW_NAME='v_factorage_novhl' or  v_re.TABLE_VIEW_NAME= 'v_factorage_vhl2'
          v_re.c_measure_code = 'a64210036'
          then
             dbms_output.put_line(v_sql);
            end if;*/
        --P_ERR_DEAL( 'FIN_iface_optimize.p_get_report', v_sql, v_re.C_MEASURE_CODE, SQLERRM );
        --P_DEBUG_DEAL( 'FIN_iface_optimize.p_get_report before parse', v_sql, '0', v_re.C_MEASURE_CODE );
        dbms_sql.parse( v_curId, v_sql, dbms_sql.v7);
        v_rownum := dbms_sql.execute( v_curId );
       /* if v_re.c_flag = '2' then --减去期初数
          insert into fin_measure(unitcode,year,month,measurecode,measurename,amount,remark,dptacccde,c_type)
           select a.unitcode,v_year,v_month,a.measurecode,a.measurename,-sum(a.amount),a.remark,a.dptacccde,a.c_type
           from fin_measure a where a.month = '12' and a.year = to_number(v_year)-1 and a.c_type = v_C_TYPE
           group by a.unitcode,a.measurecode,a.measurename,a.remark,a.dptacccde,a.c_type;

        end if;*/
        P_DEBUG_DEAL( 'FIN_iface_optimize.p_get_report', v_sql, SQLCODE, v_re.C_MEASURE_CODE );
    END IF;
  exception
    when e_continue then
     null;
  end;
  end loop;


  dbms_sql.close_cursor(v_curId);
  --向FIN_MEASURE表中插入未统计到的指标，默认金额为0
  --Process_FIN_MEASURE_ZERO(v_year ,v_month ,v_C_TYPE);
  --调用oracle提供的存过，对指标进行求和
  Process_Bessness(v_year ,v_month ,v_C_TYPE);
  commit;
  --add by shexiwan 2013-07-04 begin
  --删除3.1数据库相应数据
  delete from fin_measure_sum_31 a 
    where a.year = v_year and a.month = v_month and a.c_type = v_C_TYPE;
  --写入3.1数据库
  insert into fin_measure_sum_31
    (year,month,measurecode,measurename,amount,dptacccde,c_type,department)
  select 
    year,month,measurecode,measurename,amount,dptacccde,c_type,department
    from fin_measure_sum a
   where a.year = v_year and a.month = v_month and a.c_type = v_C_TYPE;
   commit;
  --add by shexiwan 2013-07-04 end
--------  p_circi_FORMULA_add( v_C_TYPE, 1 );--add by zhoufj
exception
  when others then
   dbms_output.put_line(v_sql);
   dbms_output.put_line(SQLCODE);
   dbms_output.put_line(SQLERRM);
   dbms_sql.close_cursor(v_curId);
   rollback;
   v_ret_sta := SQLCODE;
   P_ERR_DEAL( 'FIN_iface_optimize.p_get_report', v_sql, SQLCODE, SQLERRM );
   commit;
end;

end FIN_iface_optimize;
/
