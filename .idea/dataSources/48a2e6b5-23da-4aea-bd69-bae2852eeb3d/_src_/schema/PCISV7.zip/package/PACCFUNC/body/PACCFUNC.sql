CREATE PACKAGE BODY "PACCFUNC" is
/*
v_succsflag:
	0	??
	-1 	????????????
*/

  procedure crtedrpayrcd(edrtyp in varchar,
                         /* d(??) n(??) s(???) y(??) k(???) c(???)g(???) t(????) p(?????)*/
                         v_edr_no      in web_edr_base.c_edr_no%type, /* ????    */
                         v_ply_no      in web_ply_base.c_ply_no%type, /* ???       */
                         v_crt_cde     in web_fin_pay_due.c_crt_cde%type, /* ???   */
                         v_pay_mde_cde in web_fin_pay_due.c_pay_mde_cde%type, /* ???? */
                         --v_paid_amt   in out web_fin_pay_due.n_paid_amt%type, /* ???? */ --ok
                         v_rcpt_no in out web_fin_pay_due.c_rcpt_no%type, /* ???   */ --ok
                         v_succsflag in out number) is

    v_insrnc_bgn_tm web_fin_pay_due.t_insrnc_bgn_tm%type; --????    ok
    v_insrnc_end_tm web_fin_pay_due.t_insrnc_bgn_tm%type; --????? ok
    v_edr_bgn_tm web_fin_pay_due.t_insrnc_bgn_tm%type; --???? ok
    v_tms           web_fin_pay_due.n_tms%type; --??           ok
    v_prod_no       web_fin_pay_due.c_prod_no%type; --????        ok
    v_bsns_typ      web_fin_pay_due.c_bsns_typ%type; --????      ok
    v_slsgrp_cde    web_fin_pay_due.c_slsgrp_cde%type; --????    ok
    v_bs_cur        web_fin_pay_due.c_bs_cur%type; --????         ok
    v_clnt_mrk      web_fin_pay_due.c_clnt_mrk%type; --????
    v_cha_cde       web_fin_pay_due.c_cha_cde%type; --????       ok
    v_dptacc_cde    web_fin_pay_due.c_dptacc_cde%type; --????      ok
    v_dpt_cde       web_fin_pay_due.c_dpt_cde%type; --????        ok
    v_due_tm        web_fin_pay_due.t_due_tm%type; --????          ok
    v_comm_rate     web_ply_base.n_comm_rate%type; --?????       ok
    v_saving_amt    web_ply_base.n_saving_amt%type; --??           ok
    v_prm           web_ply_base.n_prm%type; --??    ok
    v_long_term_mrk web_ply_base.c_long_term_mrk%type; --?????       ok
    v_cha_mrk       web_fin_saveamt_due.c_cha_mrk%type; --????     ok
    v_bank_account  web_fin_saveamt_due.c_bank_account%type; --????     ok
    v_sls_cde       web_ply_base.c_sls_cde%type; --???         ok
    v_payer_cde     web_fin_saveamt_due.c_payer_cde%type; --??????   ok
    v_paid_amt      web_fin_pay_due.n_paid_amt%type;
    v_payer_nme     web_fin_saveamt_due.c_payer_nme%type; --????   ok
    v_tmp_cnt	    int;--????
    v_due_amt       web_fin_saveamt_due.n_due_amt%type; --????
	  v_ig			int;--???


  begin
    v_succsflag :=0;

    if v_edr_no is null then
      select c_dpt_cde,
             c_prod_no,
             c_prm_cur,
             c_bsns_typ,
             c_salegrp_cde,
             --c_cust_type,
             t_insrnc_bgn_tm,
             t_insrnc_end_tm,
             n_comm_rate,
             n_saving_amt,
             n_prm,
             c_long_term_mrk,
             c_sls_cde
        into v_dpt_cde,
             v_prod_no,
             v_bs_cur,
             v_bsns_typ,
             v_slsgrp_cde,
             --v_clnt_mrk,
             v_insrnc_bgn_tm,
             v_insrnc_end_tm,
             v_comm_rate,
             v_saving_amt,
             v_prm,
             v_long_term_mrk,
             v_sls_cde
        from web_ply_base
       where c_ply_no = ltrim(rtrim(v_ply_no))
         and c_edr_no is null;

      if substr(v_prod_no, 1, 2) = '00' then
        select c_clnt_mrk,
               c_bs_cur,
               c_cha_cde,
               c_dptacc_cde,
               c_dpt_cde,
               c_cha_mrk,
               c_bank_account,
               c_payer_cde,
               c_payer_nme,
               n_due_amt
          into v_clnt_mrk,
               v_bs_cur,
               v_cha_cde,
               v_dptacc_cde,
               v_dpt_cde,
               v_cha_mrk,
               v_bank_account,
               v_payer_cde,
               v_payer_nme,
               v_due_amt
          from web_fin_saveamt_due
         where c_ply_no = ltrim(rtrim(v_ply_no));
        v_paid_amt := v_due_amt * v_comm_rate;
      else
        select c_clnt_mrk,
               c_bs_cur,
               c_cha_cde,
               c_dptacc_cde,
               c_dpt_cde,
               c_cha_mrk,
               c_bank_account,
               c_payer_cde,
               c_payer_nme
          into v_clnt_mrk,
               v_bs_cur,
               v_cha_cde,
               v_dptacc_cde,
               v_dpt_cde,
               v_cha_mrk,
               v_bank_account,
               v_payer_cde,
               v_payer_nme
          from web_fin_prm_due
         where c_ply_no = ltrim(rtrim(v_ply_no))
           and c_edr_no is null;
        v_paid_amt := v_prm * v_comm_rate;

      end if;

	  v_ig :=15;

    else
      select c_dpt_cde,
             c_prod_no,
             c_prm_cur,
             c_bsns_typ,
             c_salegrp_cde,
             --c_cust_type,
             t_insrnc_bgn_tm,
             t_insrnc_end_tm,
             n_comm_rate,
             n_saving_amt,
             n_prm,
             c_long_term_mrk,
             c_sls_cde,
		 	       nvl(t_edr_bgn_tm - t_insrnc_bgn_tm,0)

        into v_dpt_cde,
             v_prod_no,
             v_bs_cur,
             v_bsns_typ,
             v_slsgrp_cde,
             --v_clnt_mrk,
             v_insrnc_bgn_tm,
             v_insrnc_end_tm,
             v_comm_rate,
             v_saving_amt,
             v_prm,
             v_long_term_mrk,
             v_sls_cde,
			       v_ig
        from web_ply_base
       where c_ply_no = ltrim(rtrim(v_ply_no))
         and c_edr_no = ltrim(rtrim(v_edr_no));
      if substr(v_prod_no, 1, 2) = '00' then
        select c_clnt_mrk,
               c_bs_cur,
               c_cha_cde,
               c_dptacc_cde,
               c_dpt_cde,
               c_cha_mrk,
               c_bank_account,
               c_payer_cde,
               c_payer_nme,
               n_due_amt
          into v_clnt_mrk,
               v_bs_cur,
               v_cha_cde,
               v_dptacc_cde,
               v_dpt_cde,
               v_cha_mrk,
               v_bank_account,
               v_payer_cde,
               v_payer_nme,
               v_due_amt
          from web_fin_saveamt_due
         where c_ply_no = ltrim(rtrim(v_ply_no));
        v_paid_amt := v_due_amt * v_comm_rate;
      else
        select c_clnt_mrk,
               c_bs_cur,
               c_cha_cde,
               c_dptacc_cde,
               c_dpt_cde,
               c_cha_mrk,
               c_bank_account,
               c_payer_cde,
               c_payer_nme
          into v_clnt_mrk,
               v_bs_cur,
               v_cha_cde,
               v_dptacc_cde,
               v_dpt_cde,
               v_cha_mrk,
               v_bank_account,
               v_payer_cde,
               v_payer_nme
          from web_fin_prm_due
         where c_ply_no = ltrim(rtrim(v_ply_no))
           and c_edr_no = ltrim(rtrim(v_edr_no));
        v_paid_amt := v_prm * v_comm_rate;
      end if;

    end if;

    v_due_tm := trunc(sysdate);
	--???????????15?,??????
    if edrtyp = 'S' /*  ??? */
	and v_ig <=15
     then
      select count(*)
        into v_tms
        from web_fin_pay_due
       where c_ply_no = v_ply_no
         and c_feetyp_cde = 'S'
         and n_paid_amt <> 0;

      select count(1)
        into v_tmp_cnt
        from web_org_dpt
       where c_dpt_cde = v_dpt_cde and c_dptacc_cde is not null;

	---1 	????????????
	IF v_tmp_cnt=0 THEN
		v_succsflag:=-1;
		RETURN;
	END IF;

      select c_dptacc_cde
        into v_dptacc_cde
        from web_org_dpt
       where c_dpt_cde = v_dpt_cde;

      dz_proc.get_fin_no(v_rcpt_no, v_dpt_cde, 'S', dz_proc.g_pttype);

      insert into web_fin_pay_due
        (c_ply_no,
         c_edr_no,
         t_insrnc_bgn_tm,
         t_insrnc_end_tm,
         n_tms,
         c_prod_no,
         c_bsns_typ,
         c_slsgrp_cde,
         c_bs_cur,
         c_feetyp_cde,
         n_bs_amt,
         n_paid_amt,
         t_pay_bgn_tm,
         t_pay_end_tm,
         c_pay_mde_cde,
         c_clnt_mrk,
         c_cha_cls,
         c_cha_cde,
         c_dptacc_cde,
         c_dpt_cde,
         c_rcpt_no,
         c_prn_no,
         c_opt_no,
         c_rollback_mark,
         c_to_fin_flag,
         c_crt_cde,
         t_crt_tm,
         c_upd_cde,
         t_upd_tm,
         -- c_bank_account,
         c_sls_cde,
         t_due_tm,
         c_longshort_flag,
         c_cha_mrk,
         c_accnt_flag,
         c_payer_cde,
         c_payer_nme,
         n_rp_amt,
         c_bala_mrk)
      values
        (nvl(v_ply_no, chr(0)), --???
         nvl(v_edr_no, chr(0)), --???
         v_insrnc_bgn_tm, --????
         v_insrnc_end_tm, --????
         nvl(v_tms, 0), --??
         nvl(v_prod_no, chr(0)), --????
         nvl(v_bsns_typ, chr(0)), --????
         nvl(v_slsgrp_cde, chr(0)), --????
         nvl(v_bs_cur, chr(0)), --????
         'S', --??????
         nvl(v_paid_amt, 0), --?????
         0, --????
         sysdate, --????
         sysdate, --????
         nvl(v_pay_mde_cde, chr(0)), --????
         v_clnt_mrk, --????
         nvl(v_bsns_typ, chr(0)), --????
         nvl(v_cha_cde, chr(0)), --????
         nvl(v_dptacc_cde, chr(0)), --????
         nvl(v_dpt_cde, chr(0)), --????
         nvl(v_rcpt_no, chr(0)), --???
         chr(0), --?????
         chr(0), --???
         chr(0), --????
         chr(0), --??????
         nvl(v_crt_cde, chr(0)), --????
         sysdate, --????
         nvl(v_crt_cde, chr(0)), --????
         sysdate, --????
         --      '1',--nvl(sbnkacct, chr(0)),           --????
         nvl(v_sls_cde, chr(0)), --???
         v_due_tm, --????
         v_long_term_mrk, --????????
         v_cha_mrk, --????
         '00', --????
         v_payer_cde,
         v_payer_nme,
         0,
         '0'
         );
    end if;
  end crtedrpayrcd;

end paccfunc;
/
