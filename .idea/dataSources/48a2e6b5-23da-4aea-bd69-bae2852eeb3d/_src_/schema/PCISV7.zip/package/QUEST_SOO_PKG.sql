CREATE PACKAGE "QUEST_SOO_PKG" 
IS
--
-- This package contains routines to support Spotlight On Oracle
--
-- Person      Date    Comments
-- ---------   ------  -----------------------------------------------
-- Guy         7oct98  Initial
-- Megh        20Jun99 Added procedures obj_keep, obj_unkeep and
--                     flush_shared_pool. Also added function obj_type
-- Han B Xie   Jun2000 - now.

    -- Global indicating that the object cache is initialized
    g_object_cache_initialized     NUMBER:=0;
    g_debug                        NUMBER:=0;

    -- And make them global accessible
    /* -------------------------------------------------------------
    || The following statements define the "segment cache".  This
    || comprises a number of PL/SQL tables which contain details
    || of file/block ranges for all existing segments.
    ||
    || get_segname uses a binary chop to find the appropriate entry
    */ -------------------------------------------------------------
    TYPE object_cache_numtype       IS TABLE OF NUMBER      INDEX BY BINARY_INTEGER;
    TYPE object_cache_tabtype       IS TABLE OF VARCHAR(61) INDEX BY BINARY_INTEGER;

    object_cache_fileno             object_cache_numtype;
    object_cache_extno              object_cache_numtype;
    object_cache_blockno            object_cache_numtype;
    object_cache_length             object_cache_numtype;
    object_cache_segname            object_cache_tabtype;
    object_cache_count              NUMBER := 0;

    object_cache                    object_cache_tabtype;

    --
    -- Function to format SQL
    --
    Function format_sql ( p_sql_text IN varchar2,
                          p_max_len  IN number:=256)
             RETURN  varchar2;
    PRAGMA restrict_references(format_sql, WNDS, RNDS, WNPS, RNPS);

    --
    -- Event_category returns the event "category" so we can group
    -- like categories.  It's overloaded to accept either a event anme
    -- or the INDX from X$KSLEI
    --
    FUNCTION event_category(p_event varchar2, tag VARCHAR2 := 'pre 4.0') RETURN varchar2;
    PRAGMA   RESTRICT_REFERENCES (event_category, WNDS, RNDS, WNPS);

    FUNCTION event_category(p_indx number, tag VARCHAR2 := 'pre 4.0') RETURN varchar2;
    PRAGMA   RESTRICT_REFERENCES (event_category, WNDS, RNDS, WNPS);

    FUNCTION latch_category(p_latch_name varchar2) RETURN varchar2;
    PRAGMA   RESTRICT_REFERENCES (latch_category, WNDS, RNDS, WNPS);

    FUNCTION obj_type(object_t varchar2) RETURN char;
    PRAGMA   RESTRICT_REFERENCES (obj_type, WNDS, RNDS, WNPS);

    FUNCTION IsSpOk RETURN number;
    PRAGMA   RESTRICT_REFERENCES (IsSpOk, WNDS, WNPS);

    FUNCTION SgaOther RETURN number;
    PRAGMA   RESTRICT_REFERENCES (SgaOther, WNDS, WNPS);

    --
    -- Procedure initialize to initialize PL/SQL tables , etc
    --
    PROCEDURE initialize;

    -- Quick but essential initialize
    PROCEDURE initialize_fast;
    -- Slower initialize which can be defered until main screen collected
    PROCEDURE initialize_objects;

    -- Print the current lock-tree
    PROCEDURE locktree(p_agent_id VARCHAR2 DEFAULT 'N/A');

    -- Set a normal trace on for the session
    PROCEDURE set_trace(p_sid NUMBER, p_serial NUMBER, p_level NUMBER);

    -- overload for backward compatibility
    PROCEDURE set_trace(p_sid NUMBER, p_serial NUMBER, p_mode boolean);

    -- Kill the nominated session
    PROCEDURE kill_session(p_sid NUMBER, p_serial NUMBER);

    -- Turn timed statistics on
    PROCEDURE set_timed_statistics;

    -- Keep object in shared pool
    -- PROCEDURE obj_keep(name in varchar2, type in varchar2);

    -- Unkeep object from shared pool
    -- PROCEDURE obj_unkeep(name in varchar2, type in varchar2);

    -- Flush shared pool
    PROCEDURE flush_shared_pool;

    --
    -- Translate values in the form 999{K|M} to byte values so
    -- instance monitor can deal with them
    --

    FUNCTION TRANSLATE_PARAMETER( p_value VARCHAR2) RETURN  varchar2;

    PRAGMA  RESTRICT_REFERENCES (translate_parameter, WNDS, RNDS, WNPS);

    --
    -- These routines support the "show locked row" facility
    --
    --Published procedures
    --Show the row locks being waited for by the specified sid
    FUNCTION show_locked_row(lsid in number) return varchar2;
    FUNCTION toRadixString(num in number, radix in number) return varchar2;
    PRAGMA   restrict_references(toRadixString, WNDS, WNPS, RNDS, RNPS);
    FUNCTION digitToString(num in number) return varchar2;
    PRAGMA   restrict_references(digitToString, WNDS, WNPS, RNDS, RNPS);
    FUNCTION stringToDigit(str in varchar2) return number;
    PRAGMA   restrict_references(stringToDigit, WNDS, WNPS, RNDS, RNPS);

    FUNCTION sga_cat(p_pool VARCHAR2, p_name VARCHAR2) RETURN VARCHAR2;
    PRAGMA   restrict_references(sga_cat, WNDS, RNDS, WNPS, RNPS);

    FUNCTION sga_cat2(p_pool VARCHAR2, p_name VARCHAR2) RETURN VARCHAR2;
    PRAGMA   restrict_references(sga_cat2, WNDS, RNDS, WNPS, RNPS);

    FUNCTION sga_pool7(p_name VARCHAR2) RETURN VARCHAR2;
    PRAGMA   restrict_references(sga_pool7, WNDS, RNDS, WNPS, RNPS);

    FUNCTION sga_area7(p_name VARCHAR2) RETURN VARCHAR2;
    PRAGMA   restrict_references(sga_area7, WNDS, RNDS, WNPS, RNPS);

    -- Stuff for getting full SQL text
    -- FUNCTION exact_db_version(p_major OUT NUMBER,
    --                          p_minor1 OUT NUMBER,
    --                          p_minor2 OUT NUMBER)
    --         RETURN VARCHAR2;
    --

    FUNCTION get_long_sqltext(p_hash_value NUMBER,
                              p_address RAW)
             RETURN VARCHAR2;

    FUNCTION get_session_long_sqltext(p_sid NUMBER)
             RETURN VARCHAR2;

    -- Decode lock details: TYPE, MODE, REQUEST
    FUNCTION lock_type_decode(type_p VARCHAR2, id2_p NUMBER default -1)
             RETURN VARCHAR2;
    PRAGMA restrict_references(lock_type_decode, WNDS, WNPS);

    FUNCTION lock_mode_decode(mode_p NUMBER) RETURN VARCHAR2;
    PRAGMA   restrict_references(lock_mode_decode, WNDS, WNPS, RNPS);

    FUNCTION event_detail ( event_p  IN VARCHAR2,
                            p1text_p IN VARCHAR2, p1_p IN NUMBER,
                            p2text_p IN VARCHAR2 DEFAULT '', p2_p IN NUMBER DEFAULT 0,
                            p3text_p IN VARCHAR2 DEFAULT '', p3_p IN NUMBER DEFAULT 0) RETURN VARCHAR2;

    -- wait_detail is a quicker version of event_detail to be used in SELECT cluase.
    FUNCTION wait_detail ( event_p  IN VARCHAR2,
                           p1text_p IN VARCHAR2, p1_p IN NUMBER,
                           p2text_p IN VARCHAR2 DEFAULT '', p2_p IN NUMBER DEFAULT 0,
                           p3text_p IN VARCHAR2 DEFAULT '', p3_p IN NUMBER DEFAULT 0) RETURN VARCHAR2;
    PRAGMA   RESTRICT_REFERENCES (wait_detail, WNDS, WNPS);

    FUNCTION dataobj_object(dataobj_p NUMBER) RETURN VARCHAR2;

    FUNCTION job_interval(next_date_p DATE, interval_p VARCHAR2) RETURN DATE;

    --
    -- I18N versions
    --
    PROCEDURE locktree_41(p_agent_id VARCHAR2 DEFAULT 'N/A');
    FUNCTION show_locked_row_41(lsid in number) return varchar2;

    FUNCTION lock_type_decode_41(type_p VARCHAR2, id2_p NUMBER default -1)
             RETURN VARCHAR2;
    PRAGMA restrict_references(lock_type_decode_41, WNDS, WNPS, RNPS);

    FUNCTION lock_mode_decode_41(mode_p NUMBER) RETURN VARCHAR2;
    PRAGMA   restrict_references(lock_mode_decode_41, WNDS, WNPS, RNPS);

    FUNCTION event_detail_41 ( event_p  IN VARCHAR2,
                            p1text_p IN VARCHAR2, p1_p IN NUMBER,
                            p2text_p IN VARCHAR2 DEFAULT '', p2_p IN NUMBER DEFAULT 0,
                            p3text_p IN VARCHAR2 DEFAULT '', p3_p IN NUMBER DEFAULT 0) RETURN VARCHAR2;

    FUNCTION wait_detail_41 ( event_p  IN VARCHAR2,
                           p1text_p IN VARCHAR2, p1_p IN NUMBER,
                           p2text_p IN VARCHAR2 DEFAULT '', p2_p IN NUMBER DEFAULT 0,
                           p3text_p IN VARCHAR2 DEFAULT '', p3_p IN NUMBER DEFAULT 0) RETURN VARCHAR2;
    PRAGMA   RESTRICT_REFERENCES (wait_detail_41, WNDS, WNPS);

  PROCEDURE populate_event_table;

  FUNCTION get_seg_name_41 (p_fileno NUMBER, p_blockno NUMBER)
      RETURN VARCHAR2;
END;









/
