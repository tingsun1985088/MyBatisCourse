CREATE package p_fin_pre_clm is
       --未决
       procedure p_fin_novhl_pend(v_today in varchar2,v_return out varchar2);
       procedure p_fin_vhl_pend(v_today in varchar2,v_return out varchar2);
       --已决
       /*procedure p_fin_novhl_clm(v_today in varchar2,v_return out varchar2);
       */
       procedure p_fin_vhl_clm_jq(v_today in varchar2,v_return out varchar2);
       procedure p_fin_vhl_clm_sy(v_today in varchar2,v_return out varchar2);
       procedure p_fin_novhl_clm(v_today in varchar2,v_return out varchar2);
end p_fin_pre_clm;
/
