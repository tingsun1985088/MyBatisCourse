CREATE package c_autowritebackwjfin is
  /***************************************************
  ************* 车理赔回写呼叫中心支付数据***********
  **************add by zhangxin  20160613************/

  /**
  * 收付回写信息
  **/
  type fin_write_back_info is Record(
    v_custseq        web_fin_write_back.custseq%type, --一次赔付的多个客户的序号（也就是从表的结算信息流水号）
    v_baserealamount web_fin_write_back.baserealamount%type, --实收付金额（保单币种）现金/银行类科目的金额
    v_tfintime       web_fin_write_back.t_crt_tm%type, --创建日期
    v_opflag         web_fin_write_back.opflag%type, --支付状态：1实收,2实付,3实收取消,4实付取消,5未付款退票,6资金退票
    v_tm             web_fin_write_back.t_crt_tm%type --创建时间
    );

  /**
  * 收款人信息
  **/
  type vhlclm_income_info is Record(
    v_cincnme     web_vhlclm_income.c_inc_nme%type, --收款人姓名
    v_ctel        web_vhlclm_income.c_tel%type, --联系电话
    v_cictyp      web_vhlclm_income.c_ic_typ%type, --收款人类型（被保险人、受益人、三者、其他）
    v_camttyp     web_vhlclm_income.c_amt_typ%type, --款项类型（正常赔款、预付、垫付）
    v_cincbanknme web_vhlclm_income.c_inc_bank_nme%type, --开户行名称
    v_cbanknum    web_vhlclm_income.c_bank_num%type, --银行账号
    v_crptno      web_vhlclm_income.c_rpt_no%type --报案号
    );

  /**
  * 车理赔回写呼叫中心支付数据(开始逻辑)
  **/
  procedure auto_writebackwjfininfo;

  /******************************************
  *  车理赔回写呼叫中心支付数据(主逻辑)
  *  v_c_rpt_no  入参  报案号
  *  v_success   出参  成功条数
  *  v_failure   出参  失败条数
  *  注：设计成功、失败条数，目的为赔案级
  *      报案级通用
  *******************************************/
  procedure main_writebackwjfininfo(v_c_rpt_no in varchar2,
                                    v_success  out number,
                                    v_failure  out number);
  
  /***************************************************
  *  车理赔回写呼叫中心支付数据(主逻辑-多次赔付分支)
  *  v_c_rpt_no  入参  报案号
  *  v_c_case_no 入参  赔案号
  *  v_custseq   入参  支付唯一编号
  *  v_number    入参  报案下赔案的循环次数
  *  v_counttype 入参  报案号下赔案的个数
  *  v_success   出参  成功条数
  *  v_failure   出参  失败条数
  *  注：设计成功、失败条数，目的为赔案级
  *      报案级通用
  ***************************************************/
  procedure main_sub_writebackwjfininfo(v_c_rpt_no            in  varchar2,
                                        v_c_case_no           in  varchar2,
                                        v_fin_write_back_info in  fin_write_back_info,
                                        v_number              in  number,
                                        v_counttype           in  number,
                                        v_success             out number,
                                        v_failure             out number);
  
  /******************************************
  **  查询收付回写信息
  **  v_c_rpt_no 入参  报案号
  **  v_fin_write_back_info  出参  实付信息
  *******************************************/
  procedure queryfinwriteback(v_c_rpt_no            in varchar2,
                              v_fin_write_back_info out fin_write_back_info);
                                                         
  /*************************************************
  * *************** 查询实付信息********************
  *  v_custseq              入参  客户序号
  *  v_c_case_no            入参  赔案号
  *  v_fin_write_back_info  出参  实付信息
  *************************************************/
  procedure queryfinwritebackinfo(v_custseq             in  varchar2,
                                  v_c_case_no           in  varchar2,
                                  v_fin_write_back_info out fin_write_back_info);

  /**************************************
  *  判断是否赔付多笔，若有多笔，则循环取值
  *  v_claimno     入参  赔案号
  *  v_custseqnums 出参  支付流水号个数
  ***************************************/
  procedure querycustseqcount(v_claimno in varchar2, v_custseqnums out number);

  /**************************************
  *  查询支付唯一编号
  *  v_claimno 入参  赔案号
  *  v_custseq 出参  支付流水号
  ***************************************/
  procedure querycustseq(v_claimno in varchar2, v_custseq out varchar2);
  
  /*****************************************
  *  判断案件号是交强还是商业
  *  v_c_rpt_no   入参    报案号
  *  v_c_case_no  入参    赔案号
  *  v_type       出参    赔案号所属险种  0-交强  1-商业  2-交商联合  3-不存在
  *  v_counttyp   出参    报案号下赔案的个数
  ******************************************/
  procedure verdictcasenotype(v_c_rpt_no          in varchar2,
                              v_c_case_no         in varchar2,
                              v_type              out varchar2,
                              v_counttyp          out number);

  /*****************************************
  *  判断应付与实付是否相等
  *  v_c_rpt_no    入参   报案号
  *  v_fin_write_back_info 入参  实付信息
  *  v_flag        出参   是否相等标识
  ******************************************/
  procedure verdictamount(v_c_rpt_no            in varchar2,
                          v_fin_write_back_info in fin_write_back_info,
                          v_flag                out varchar2);

  /*************************************
  *  判断数据是否已经存在赔案信息中
  *  v_c_rpt_no  入参   报案号
  *  v_exist     出参   是否存在标识
  **************************************/
  procedure verdictdateexist(v_c_rpt_no in varchar2, v_exist out varchar2);

  /*****************************************
  *  根据支付唯一编号查询收款人信息
  *  v_custseq   入参   支付流水号
  *  v_vhlclm_income_info  出参  收款人信息
  ******************************************/
  procedure queryInComemassage(v_custseq            in varchar2,
                               v_vhlclm_income_info out vhlclm_income_info);

  /*****************************************
  *  回写呼叫中心收付中间表
  *  v_fin_write_back_info 入参  实付信息
  *  v_vhlclm_income_info  入参  收款人信息
  *  v_flag  出参  是否成功标识
  *  v_info  出参  失败详细原因
  ******************************************/
  procedure into_hh_pending_hftask_log(v_c_rpt_no    in varchar2,
                                       v_c_flag      in varchar2,
                                       v_c_error_msg in varchar2);

  /****************************************
  *  保存回写呼叫中心支付数据处理异常信息
  *  v_c_rpt_no  入参   报案号
  *  v_c_flag    入参   失败原因分类
  *  v_c_error_msg 入参  失败详细原因
  *****************************************/
  procedure into_hh_hftask(v_fin_write_back_info in fin_write_back_info,
                           v_vhlclm_income_info  in vhlclm_income_info,
                           v_commitflag          in varchar2,
                           v_flag                out varchar2,
                           v_info                out varchar2);
  /***************************************
  *  保存日志信息
  *  v_c_back_tm 入参  定时任务完成时间
  *  v_c_states 入参  定时任务成功失败标识 
  *  v_c_error_msg 入参   失败详细原因
  ****************************************/
  procedure into_fin_logInfo(v_c_back_tm   in varchar2,
                             v_c_states    in varchar2,
                             v_c_error_msg in varchar2);
end;
/
