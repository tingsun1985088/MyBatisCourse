CREATE PACKAGE BODY "RPFUNCTION" is
  --汇率
  function getRate(v_cur1 varchar2, v_cur2 varchar2, v_time date)
    return number is
    v_fin_cur1 varchar2(10); --(财务币种)需要转换的币种(v_cur1,业务系统币种)
    v_fin_cur2 varchar2(10); --(财务币种)转换后的币种(v_cur2,业务系统币种)
    v_rate     number(30, 6); --汇率
  begin
    v_rate:=1;
    begin
    if v_cur1 = v_cur2 then
       return 1;
    end if;
    return 1;
    if v_cur2 = '01' then
      v_fin_cur2 := 'CNY';
   /* else
      select upper(a.c_cur_unt) into v_fin_cur2 from circi.WEB_BAS_FIN_CUR a  where upper(a.c_cur_cde) = v_cur2;*/
    end if;
    --select upper(a.c_cur_unt) into v_fin_cur1 from web_bas_fin_cur a  where upper(a.c_cur_cde) = v_cur1;
    v_fin_cur1:=v_cur1;
   /* begin
      select a.show_conversion_rate into v_rate
      from cux_gl_daily_rates_v@CWDB.REGRESS.RDBMS.DEV.US.ORACLE.COM a
      --cux_gl_daily_rates_v a
       where upper(a.from_currency) = v_fin_cur1 and upper(a.to_currency) = v_fin_cur2
             and trunc(a.conversion_date)=trunc(v_time);
    exception when no_data_found then
      \*insert into t_error_msg(c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      values(F_Fin_Getcode('e'),'003','000',
      '币种'||v_fin_cur1||'与'||v_fin_cur2||'之间的汇率转换查询出错,日期:'||v_time,sysdate);*\
      P_ERR_DEAL( '汇率', '000', SQLCODE, SQLERRM );
    end;*/
    return round(v_rate,6);
  end;
  end;
   function getServicetype(v_servicetype varchar2) return varchar2  is v_vou_memo varchar2(100);
  begin
     select c_name into v_vou_memo from web_bas_fin_servicetype where c_no = v_servicetype;
     return v_vou_memo;
  end;
  --财务币种
  function getFinCur(v_cur varchar2) return varchar2   is v_fin_cur varchar2(10);
  begin
     select upper(a.c_cur_unt) into v_fin_cur from web_bas_fin_cur a where a.c_cur_cde = v_cur;
     return v_fin_cur;
  end;
  --币种名称
  function getFinCurName(v_cur varchar2) return varchar2   is v_fin_cur varchar2(10);
  begin
     if v_cur = '01' then
        v_fin_cur:='人民币';
     else
        select a.c_cur_cnm into v_fin_cur from web_bas_fin_cur a where a.c_cur_cde = v_cur;
     end if;

     return v_fin_cur;
  end;
  --获取成本中心信息
  function getFinDepart(v_dpt_cde varchar2,v_rcpt_no varchar2) return varchar2   is v_fin_dpt varchar2(50);
  begin
     v_fin_dpt:='-1';
     begin
         select c_department_cde into v_fin_dpt
          from WEB_ORG_DPT WHERE c_dpt_cde =trim(v_dpt_cde);
     exception when no_data_found then
         v_fin_dpt:='-1';
          insert into web_bas_fin_errorlog
         (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
         values
         (F_Fin_Getcode('e'), '001','0000',v_rcpt_no || ':获取成本中心信息失败',SYSDATE);
     end;
     return v_fin_dpt;
  end;

  --获取公司段信息
  function getFinCompany(v_dpt_cde varchar2,v_rcpt_no varchar2) return varchar2   is v_fin_dpt varchar2(50);
  begin
     v_fin_dpt:='-1';
     begin
         select nvl(c_company_cde,substr(v_dpt_cde,1,4)) into v_fin_dpt from WEB_ORG_DPT WHERE c_dpt_cde =trim(v_dpt_cde);
     exception when no_data_found then
         v_fin_dpt:='-1';
          insert into web_bas_fin_errorlog
         (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
         values
         (F_Fin_Getcode('e'), '001','0000',v_rcpt_no || ':获取公司段信息失败',SYSDATE);
     end;
      return v_fin_dpt;
  end;
  --获取财务产品
  function getFinProd(v_prod_no varchar2,v_clm_no varchar2,v_app_no varchar2,v_edr_no varchar2,v_mrk varchar2) return varchar2   is v_fin_prod varchar2(50);
           v_usage_cde varchar2(10);
           v_count3    number(10);
           v_err       varchar2(50);
           v_vhl_type  varchar2(50);
           v_error  varchar2(50);
  begin
     v_fin_prod:='-1';
     begin
     if v_prod_no <> '0320' then
          select p.c_kind_no into v_fin_prod  from WEB_BAS_FIN_PROD p  where p.c_prod_no = v_prod_no;
      elsif v_prod_no = '0320' then
          if v_mrk = '1' then--保单
              v_error:='保单'||v_app_no;
              select c_usage_cde,c_vhl_typ into v_usage_cde,v_vhl_type
               from web_ply_vhl where c_app_no = v_app_no and c_edr_no is null and rownum=1;

          elsif v_mrk = '2' then--赔案
             v_error:='赔案'||v_clm_no;
         --  wuqy 根据理赔的类型添加
          select C_VHL_TYP,C_USE_CDE into v_vhl_type,v_usage_cde from web_vhlclm_ply where c_case_no = v_clm_no;
         --   wuqy 暂时屏蔽 2013-4-16 select rel.c_use_attr,rel.c_vhl_type into v_usage_cde,v_vhl_type from
          --    WEB_CLM_PLY_REL rel where rel.c_clm_no = v_clm_no and rownum = 1;
          elsif v_mrk = '3' then --批单
              v_error:='批单'||v_edr_no;
              select c_usage_cde,c_vhl_typ into v_usage_cde,v_vhl_type
               from web_ply_vhl where c_edr_no = v_edr_no and rownum=1;
          end if;
          if v_vhl_type in('365014','365015','365016','365017','365019','365020','365021') then
             v_fin_prod := '030109'; --挂车
          elsif v_usage_cde = '364001001' then
             v_fin_prod := '030101'; --家庭自用车
          elsif v_usage_cde = '364002002' or v_usage_cde = '364002001' then
             v_fin_prod := '030102'; --非营业客车
          elsif v_usage_cde = '364004001' then
             v_fin_prod := '030104'; --非营业货车
          elsif v_usage_cde = '364003002' or v_usage_cde = '364003001' or
                v_usage_cde = '364003003' then
             v_fin_prod := '030103'; --营业客车
          elsif v_usage_cde = '364004002' then
             v_fin_prod := '030105'; --营业货车
          elsif v_usage_cde = '364005001' then
             v_fin_prod := '030106'; --特种车
          elsif v_usage_cde = '364005002' then
              v_fin_prod := '030107'; --摩托车
          elsif v_usage_cde = '364005003' then
              v_fin_prod := '030108'; --拖拉机
          end if;
        end if;
        exception when no_data_found then
          v_fin_prod:='-1';
          insert into web_bas_fin_errorlog
         (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
         values
         (F_Fin_Getcode('e'), '001','0000',v_error || ':获取财物产品失败',SYSDATE);

        end;
        return v_fin_prod;
  end;

  --获取财务渠道
  function getFinCha(v_cha varchar2,v_rcpt_no varchar2) return varchar2   is v_fin_cha varchar2(50);
  begin
     v_fin_cha:='-1';
     begin
         select a.c_fincha_cde into v_fin_cha from WEB_BAS_FIN_CHA a where c_fincha_cde = v_cha; -- wuqy 2012-12-17 原来是c_cha_cde
     exception when no_data_found then
         v_fin_cha:='-1';
         insert into web_bas_fin_errorlog
         (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
         values
         (F_Fin_Getcode('e'), '001','0000',v_rcpt_no || ':获取财物渠道失败',SYSDATE);
     end;
      return v_fin_cha;
  end;
 --产品判断
  function getKindName(v_kind_no varchar2,v_prod_no varchar2,v_cvrg_no varchar2)
    return varchar2 is v_kind_name varchar2(50);
   v_jy_flg      char(1);
  begin
     if v_kind_no = '01' then
        v_kind_name := '企业财产险';
     elsif v_kind_no = '02' then
        v_kind_name := '货物运输保险';
     elsif v_kind_no = '03' and v_prod_no = '0320' then
        v_kind_name := '交强险';
     elsif v_kind_no = '03' and v_prod_no <> '0320' then
        v_kind_name := '商业车险';
     elsif v_kind_no = '04' then
        v_kind_name := '责任保险';
     elsif v_kind_no = '05' then
        v_kind_name := '特殊风险保险';
     --险类代码为12是精算自定义的一个代码,若以后承保添加新的险类的代码为12,则需注意
     elsif (v_kind_no = '06' and v_prod_no in('0609', '0610', '0614','0611')) or v_kind_no = '12' then
        v_kind_name := '短期健康保险';
     elsif v_kind_no = '06' and v_prod_no not in('0609', '0610', '0614','0611') then
        if trim(v_cvrg_no) <> '' and trim(v_cvrg_no) is null then
           select a.c_jy_flg into v_jy_flg from  web_prd_cvrg a where a.c_cvrg_no = v_cvrg_no;
           --0:主险,1:附加险,2:扩展责任
           if v_jy_flg = '1' then
              v_kind_name := '短期健康保险';
           else
              v_kind_name := '意外伤害保险';
           end if;
        else
           v_kind_name := '意外伤害保险';
        end if;
     elsif v_kind_no = '07' then
        v_kind_name := '信用保证险';
     elsif v_kind_no = '08' then
        v_kind_name := '家庭财产险';
     elsif v_kind_no = '09' then
        v_kind_name := '工程险';
     elsif v_kind_no = '10' then
        v_kind_name := '船舶保险';
     elsif v_kind_no = '11' then
        v_kind_name := '农业保险';
     end if;
     return v_kind_name;
  end;
  
 --产品判断
  function getKindNo(v_kind_no varchar2,v_prod_no varchar2,v_cvrg_no varchar2) return varchar2 is v_kind varchar2(50);
    v_jy_flg      char(1);
  begin
     v_kind:=v_kind_no;
     if v_prod_no in('0609', '0610', '0614','0611') then
        v_kind := '12';
     elsif v_kind_no='06' and v_cvrg_no <> '---' then
        --健康险意外险区分标记：0意外 1 健康 null 非意健险
        select a.c_jy_flg into v_jy_flg from  web_prd_cvrg a where a.c_cvrg_no = v_cvrg_no;
        if v_jy_flg = '1' then
           v_kind := '12';
        else
           v_kind:=v_kind_no;
        end if;
     end if;
     return v_kind;
  end;

   -- 获取车险
  function  getVhl(v_app_no varchar2) return varchar2 is VHLTYP varchar2(50);
   CUSEATR      VARCHAR2(30);           --车辆试使用性质
   CFEEATR      VARCHAR2(30);           --车辆种类
   V_VHLTYP     VARCHAR2(30);
   begin
    -- SELECT C_Biz_Mrk,c_usage_cde,c_vhl_typ INTO CFEEATR,CUSEATR,V_VHLTYP --modify by wkf 2013-8-7
      SELECT C_Biz_Mrk,c_usage_cde,c_vhl_typ INTO CUSEATR,CFEEATR,V_VHLTYP
         FROM web_PLY_VHL
      WHERE C_APP_NO =v_app_no;

        IF CFEEATR = '345010001' THEN
           IF CUSEATR = '345009001' THEN
           VHLTYP := '01';       --家庭用车
        ELSIF (CUSEATR = '345009002' OR CUSEATR = '345009003')  THEN
           VHLTYP := '02';          --非营业客车
        END IF;
   END IF;
   IF (CFEEATR = '345010007' OR CFEEATR = '345010008' OR CFEEATR = '345010009') THEN
       IF (CUSEATR = '345009004' OR CUSEATR = '345009005')  THEN
       VHLTYP := '03';          --营业客车
    END IF;
   END IF;
   IF CFEEATR = '345010004' THEN
         IF (CUSEATR = '345009001' OR CUSEATR = '345009002' OR CUSEATR = '345009003') THEN
         VHLTYP := '04';       --非营业货车
      ELSIF (CUSEATR = '345009004' OR CUSEATR = '345009005')  THEN
         VHLTYP := '05';          --营业货车
    END IF;
    IF(V_VHLTYP='345002025') THEN                --ADD BY HHJ 2008/04/22
     VHLTYP := '08';
     END IF;                                     --END
   END IF;
   IF CFEEATR = '345010006' THEN
        VHLTYP := '06';    --特种车
   END IF;
   IF CFEEATR = '345010012' THEN
        VHLTYP := '07';    --摩托车
   END IF;
   IF CFEEATR = '345010011' THEN
        VHLTYP := '08';    --拖拉机
   END IF;
   IF CFEEATR = '345010010' THEN
        VHLTYP := '09';    --挂车
   END IF;

   RETURN VHLTYP;

EXCEPTION
     WHEN OTHERS THEN
       RETURN '00';
END;

--机构转码 wkf 2013-5-27
 /*function getDptCde(v_to_newOrOld varchar2,v_dptCde varchar2) return varchar2 is v_to_dptCde varchar2(50);
 v_count number;
 begin

   if('TO_NEW'=upper(v_to_newOrOld)) then
      select count(newid) into v_count from dptempmap where type='P' and oldid =v_dptCde;
       if v_count <>0 then
      select newid into v_to_dptCde from dptempmap where type='P' and oldid =v_dptCde;
      end if;
  elsif('TO_OLD'=upper(v_to_newOrOld)) then
     select count(oldid) into v_count from dptempmap where type='P' and newid =v_dptCde;
     if v_count <>0 then
         select oldid into v_to_dptCde from dptempmap where type='P' and newid =v_dptCde;
      end if;
  else
     select count(oldid) into v_count from dptempmap where type='P' and newid =v_dptCde;
     if v_count <>0 then
         select oldid into v_to_dptCde from dptempmap where type='P' and newid =v_dptCde;
      end if;
   end if;
   if v_to_dptCde is  null or v_to_dptCde =''then
                    v_to_dptCde:=v_dptCde;
  end if;
     return v_to_dptCde;
    EXCEPTION
      WHEN OTHERS
      THEN
         BEGIN
            DBMS_OUTPUT.put_line ('exception' || '*' || '转码失败' || SQLERRM);
         END;

 end;
 --员工转码 wkf 2013-5-30
 function getEmpCde(v_to_newOrOld varchar2,v_empCde varchar2) return varchar2 is v_to_empCde varchar2(50);

 v_count number;
 begin
   if('TO_NEW'=upper(v_to_newOrOld)) then
      select count(newid) into v_count from dptempmap where type='IN' and oldid =v_empCde;
       if v_count <>0 then
      select newid into v_to_empCde from dptempmap where type='IN' and oldid =v_empCde;
      end if;
  elsif('TO_OLD'=upper(v_to_newOrOld)) then
     select count(oldid) into v_count from dptempmap where type='IN' and newid =v_empCde;
     if v_count <>0 then
         select oldid into v_to_empCde from dptempmap where type='IN' and newid =v_empCde;
      end if;
  else
     select count(oldid) into v_count from dptempmap where type='IN' and newid =v_empCde;
     if v_count <>0 then
         select oldid into v_to_empCde from dptempmap where type='IN' and newid =v_empCde;
      end if;
   end if;
   if v_to_empCde is null or v_to_empCde='' then
      v_to_empCde:=v_empCde;
  end if;
     return v_to_empCde;
    EXCEPTION
      WHEN OTHERS
      THEN
         BEGIN
            DBMS_OUTPUT.put_line ('exception' || '*' || '转码失败' || SQLERRM);
         END;

 end; */
end;
/
