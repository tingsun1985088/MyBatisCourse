CREATE PACKAGE BODY RPT_IFACE_OPTIMIZE IS

  PROCEDURE P_GET_REPORT(T_BGN_TM  IN DATE,
                         T_END_TM  IN DATE,
                         DPTLEN    IN INT,
                         V_C_TYPE  IN VARCHAR2,
                         V_RET_STA OUT NUMBER) IS
    V_SQL    VARCHAR2(3000);
    V_CURID  INTEGER;
    V_ROWNUM NUMBER;
    V_YEAR   VARCHAR2(4);
    V_MONTH  VARCHAR2(2);
    V_TS     VARCHAR2(20);
  
    V_T_BGN_TM VARCHAR2(20);
    V_T_END_TM VARCHAR2(20);
  
    E_CONTINUE EXCEPTION;
    CURSOR CURITEM IS
      SELECT C_MEASURE_CODE,
             C_MEASURE_NAME,
             C_KIND_NO_CON,
             C_KIND_NO_VAL,
             C_CAR_KIND_CON,
             C_CAR_KIND_VAL,
             C_NEW_FLAG_CON,
             C_NEW_FLAG_VAL,
             AMOUNT,
             C_INSRNC_CDE_CON,
             C_INSRNC_CDE_VAL,
             TABLE_VIEW_NAME,
             C_BSNS_TYPE_CON,
             C_BSNS_TYPE_VAL,
             C_EDR_TYPE_CON,
             C_EDR_TYPE_VAL,
             C_EDR_NO_CON,
             C_EDR_NO_VAL,
             N_PRM_YUAN_CON,
             N_PRM_YUAN_VAL,
             C_LOSS_STAT_CON,
             C_LOSS_STAT_VAL,
             C_CAR_TYPE_CON,
             C_CAR_TYPE_VAL,
             C_PROD_CON,
             C_PROD_VAL,
             C_DUTY_FLAG_CON,
             C_DUTY_FLAG_VAL,
             C_T_PK_TM,
             C_WHERE_OTHERS,
             C_CUR_CDE_CON,
             C_CUR_CDE_VAL,
             C_APPT_NATION_CON,
             C_APPT_NATION_VAL,
             C_DOC_FLAG_CON,
             C_DOC_FLAG_VAL,
             C_CONT_TYP_CDE_CON,
             C_CONT_TYP_CDE_VAL,
             C_USE_ATR_CON,
             C_USE_ATR_VAL,
             C_AGRI_MRK_CON,
             C_AGRI_MRK_VAL,
             C_NAT_TYP_CON,
             C_NAT_TYP_VAL,
             C_FIN_TYP_CON,
             C_FIN_TYP_VAL,
             C_SALEGRP_CDE_CON,
             C_SALEGRP_CDE_VAL,
             C_CONT_CDE_CON,
             C_CONT_CDE_VAL
        FROM IFACE_MEASURE_ITEM
       WHERE T_ADB_TM IS NULL --and c_measure_code='61080335'
         AND C_TYPE = V_C_TYPE
         AND SUBSTR(C_MEASURE_CODE, 1, 1) <> 'a' --2007-4-18 dengby add for a1120***
         AND SUBSTR(C_MEASURE_CODE, 1, 4) NOT IN
             ( /*'6122','6124','6123','6125','6126','6127',*/'6118',
              '6119')
         AND C_MEASURE_CODE IN
             (SELECT B.C_MEASURE_CODE
                FROM T_SUBFORMULA B
               WHERE B.C_DEEP = '1'
                 AND B.C_FREQUENCY = V_C_TYPE) /*And C_MEASURE_NAME Like '已决赔款－机动车辆保险－汽车%'*/
      /*and SUBSTR(c_measure_code,1,4) in ('6122','6124','6123')*/
      --and c_measure_code ='m81042017'
      ;
    CURSOR CURITEM_DPT IS
      SELECT C_MEASURE_CODE,
             C_MEASURE_NAME,
             C_KIND_NO_CON,
             C_KIND_NO_VAL,
             TABLE_VIEW_NAME
        FROM IFACE_MEASURE_ITEM
       WHERE T_ADB_TM IS NULL
         AND C_TYPE = V_C_TYPE
         AND SUBSTR(C_MEASURE_CODE, 1, 4) = '6118xxxx'
         AND C_MEASURE_CODE IN
             (SELECT C_MEASURE_CODE
                FROM T_SUBFORMULA
               WHERE C_DEEP = '1'
                 AND C_FREQUENCY = V_C_TYPE);
    CURSOR CURITEM_EMP IS
      SELECT C_MEASURE_CODE,
             C_MEASURE_NAME,
             C_KIND_NO_CON,
             C_KIND_NO_VAL,
             C_NEW_FLAG_CON,
             C_NEW_FLAG_VAL,
             C_INSRNC_CDE_CON,
             C_INSRNC_CDE_VAL,
             TABLE_VIEW_NAME
        FROM IFACE_MEASURE_ITEM
       WHERE T_ADB_TM IS NULL
         AND C_TYPE = V_C_TYPE
         AND SUBSTR(C_MEASURE_CODE, 1, 4) = '6119xxxx'
         AND C_MEASURE_CODE IN
             (SELECT C_MEASURE_CODE
                FROM T_SUBFORMULA
               WHERE C_DEEP = '1'
                 AND C_FREQUENCY = V_C_TYPE);
  
  BEGIN
      ---added by ctt 20120928
    update t_run_time set t_bgn_tm=sysdate where c_proc_nme='P_GET_REPORT';
    commit;
      ---added by ctt 20120928
    V_RET_STA  := 0;
    V_YEAR     := TO_CHAR(T_END_TM, 'YYYY');
    V_MONTH    := TO_CHAR(T_END_TM, 'MM');
    V_TS       := TO_CHAR(T_END_TM, 'yyyy-mm-dd hh24:mi:ss');
    V_CURID    := DBMS_SQL.OPEN_CURSOR;
    V_T_BGN_TM := TO_CHAR(T_BGN_TM, 'yyyy-mm-dd hh24:mi:ss');
    V_T_END_TM := TO_CHAR(T_END_TM, 'yyyy-mm-dd hh24:mi:ss');
  
    FOR V_RE IN CURITEM LOOP
      BEGIN    
        IF RTRIM(LTRIM(V_RE.TABLE_VIEW_NAME)) <> '---' and V_RE.AMOUNT<>'0' THEN
          V_SQL := 'insert into iface_measure(unitcode, year, month, measurecode, measurename, amount, remark, ts)';
        ----updated by ctt 2012-12-10  四级机构------
            /* V_SQL := V_SQL || ' select substr(c_dpt_cde,1,' || DPTLEN ||
                   '), ''' || V_YEAR || ''',''' || V_MONTH || ''',''';*/
          V_SQL:=V_SQL||'SELECT c_belong_dpt_cde,''' || V_YEAR || ''',''' || V_MONTH || ''',''';
        -----------------------------------------------------------
          V_SQL := V_SQL || V_RE.C_MEASURE_CODE || ''',''' ||
                   V_RE.C_MEASURE_NAME || ''',' || V_RE.AMOUNT || ',''' ||
                   V_RE.C_MEASURE_NAME || ''',''' || V_TS || '''';
        -------------updated by ctt 2012-12-10-----------
           /* V_SQL := V_SQL || ' from ' || V_RE.TABLE_VIEW_NAME ||
                   ' where length(c_dpt_cde) >= ' || DPTLEN;*/
        V_SQL := V_SQL || ' from ' || V_RE.TABLE_VIEW_NAME ||
                   ' where 1=1 ' ;
        -------------updated by ctt 2012-12-10-----------
          IF V_RE.C_KIND_NO_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_kind_no ' || V_RE.C_KIND_NO_CON ||
                     V_RE.C_KIND_NO_VAL;
          END IF;
          IF V_RE.C_CAR_KIND_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_car_kind ' || V_RE.C_CAR_KIND_CON ||
                     V_RE.C_CAR_KIND_VAL;
          END IF;
          IF V_RE.C_NEW_FLAG_CON <> '---' THEN
            V_SQL := V_SQL || ' and C_NEW_FLAG ' || V_RE.C_NEW_FLAG_CON ||
                     V_RE.C_NEW_FLAG_VAL;
          END IF;
          IF V_RE.C_INSRNC_CDE_CON <> '---' THEN
            V_SQL := V_SQL || ' and C_INSRNC_CDE ' || V_RE.C_INSRNC_CDE_CON ||
                     V_RE.C_INSRNC_CDE_VAL;
          END IF;
          IF V_RE.C_BSNS_TYPE_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_bsns_type ' || V_RE.C_BSNS_TYPE_CON ||
                     V_RE.C_BSNS_TYPE_VAL;
          END IF;
          IF V_RE.C_EDR_TYPE_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_edr_type ' || V_RE.C_EDR_TYPE_CON ||
                     V_RE.C_EDR_TYPE_VAL;
          END IF;
          IF V_RE.C_EDR_NO_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_edr_no ' || V_RE.C_EDR_NO_CON ||
                     V_RE.C_EDR_NO_VAL;
          END IF;
          IF V_RE.N_PRM_YUAN_CON <> '---' THEN
            V_SQL := V_SQL || ' and n_prm_yuan ' || V_RE.N_PRM_YUAN_CON ||
                     V_RE.N_PRM_YUAN_VAL;
          END IF;
          IF V_RE.C_LOSS_STAT_CON <> '---' THEN
            V_SQL := V_SQL || ' and C_CLM_MAINSTATUS ' ||
                     V_RE.C_LOSS_STAT_CON || V_RE.C_LOSS_STAT_VAL;
          END IF;
          IF V_RE.C_CAR_TYPE_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_car_type ' || V_RE.C_CAR_TYPE_CON ||
                     V_RE.C_CAR_TYPE_VAL;
          END IF;
          IF V_RE.C_PROD_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_prod_no ' || V_RE.C_PROD_CON ||
                     V_RE.C_PROD_VAL;
          END IF;
          IF V_RE.C_DUTY_FLAG_CON <> '---' THEN
            V_SQL := V_SQL || ' and C_DUTY_FLAG ' || V_RE.C_DUTY_FLAG_CON ||
                     V_RE.C_DUTY_FLAG_VAL;
          END IF;
        
          IF V_RE.C_T_PK_TM <> '---' THEN
            V_SQL := V_SQL || ' and ' || V_RE.C_T_PK_TM;
          ELSE
            /* If SUBSTR(v_re.C_MEASURE_CODE,1,4)  In ( '6122','6123','6124')  Then
               v_sql := v_sql || 'and t_pk_tm <= TO_CHAR ( t_end_tm ,''YYYY-MM'') ';
            Else */
            IF V_RE.TABLE_VIEW_NAME <> 'rpt_car_count a' THEN
              ---updated by ctt 2012-01-04 存在保险起期为2012/12/31 23:59:59
              /*V_SQL := V_SQL ||
                       'and t_pk_tm >= :t_bgn_tm and t_pk_tm < :t_end_tm ';*/
                V_SQL := V_SQL ||
                       'and t_pk_tm between :t_bgn_tm and  :t_end_tm ';       
               ---updated by ctt 2012-01-04 存在保险起期为2012/12/31 23:59:59
            END IF;
            /*End If; */
          END IF;
        
          IF V_RE.C_WHERE_OTHERS <> '---' THEN
            V_SQL := V_SQL || ' and ' || V_RE.C_WHERE_OTHERS;
          END IF;
          IF V_RE.C_CUR_CDE_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_cur_cde ' || V_RE.C_CUR_CDE_CON ||
                     V_RE.C_CUR_CDE_VAL;
          END IF;
          IF V_RE.C_APPT_NATION_CON <> '---' THEN
            --境内外
            V_SQL := V_SQL || ' and C_APPT_NATION ' ||
                     V_RE.C_APPT_NATION_CON || V_RE.C_APPT_NATION_VAL;
          END IF;
          IF V_RE.C_DOC_FLAG_CON <> '---' THEN
            V_SQL := V_SQL || ' and C_DOC_FLAG  ' || V_RE.C_DOC_FLAG_CON ||
                     V_RE.C_DOC_FLAG_VAL;
          END IF;
          IF V_RE.C_CONT_TYP_CDE_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_cont_typ_cde ' ||
                     V_RE.C_CONT_TYP_CDE_CON || V_RE.C_CONT_TYP_CDE_VAL;
          END IF;
          IF V_RE.C_AGRI_MRK_CON <> '---' THEN
            --涉农标志
            V_SQL := V_SQL || ' and C_Agri_Mrk ' || V_RE.C_AGRI_MRK_CON ||
                     V_RE.C_AGRI_MRK_VAL;
          END IF;
          IF V_RE.C_NAT_TYP_CON <> '---' THEN
            --涉农性质
            V_SQL := V_SQL || ' and C_Nat_Typ ' || V_RE.C_NAT_TYP_CON ||
                     V_RE.C_NAT_TYP_VAL;
          END IF;
          IF V_RE.C_USE_ATR_CON <> '---' THEN
            --使用性质
            V_SQL := V_SQL || ' and C_USE_ATR ' || V_RE.C_USE_ATR_CON ||
                     V_RE.C_USE_ATR_VAL;
          END IF;
          IF V_RE.C_FIN_TYP_CON <> '---' THEN
            --使用性质
            V_SQL := V_SQL || ' and C_Fin_Typ ' || V_RE.C_FIN_TYP_CON ||
                     V_RE.C_FIN_TYP_VAL;
          END IF;
          IF V_RE.C_SALEGRP_CDE_CON <> '---' THEN
            --使用性质
            V_SQL := V_SQL || ' and c_salegrp_cde ' ||
                     V_RE.C_SALEGRP_CDE_CON || V_RE.C_SALEGRP_CDE_VAL;
          END IF;
          IF V_RE.C_CONT_CDE_CON <> '---' THEN
            --再保中合约类型
            V_SQL := V_SQL || ' and c_cont_cde ' || V_RE.C_CONT_CDE_CON ||
                     V_RE.C_CONT_CDE_VAL;
          END IF;
          ----updated by ctt 2012-12-10---------
         /* V_SQL := V_SQL || ' group by substr(c_dpt_cde,1,' || DPTLEN || ')';*/
         V_SQL := V_SQL || ' group by c_belong_dpt_cde';
         ----updated by ctt 2012-12-10---------
          V_SQL := REPLACE(V_SQL,
                           ':t_end_tm',
                           ' to_date(''' || V_T_END_TM ||
                           ''',''yyyy-mm-dd hh24:mi:ss'') ');
           
          -- v_sql := replace( v_sql, ' t_end_tm', ' to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
          /*if(SUBSTR(v_re.c_measure_code,1,1)<>'a') then
            if  SUBSTR(v_re.C_MEASURE_CODE,1,2)  = '82'  then
               v_sql := replace( v_sql, ':t_bgn_tm', 'trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -12 ), ''yyyy'')' );
               v_sql := replace( v_sql, ':t_bend_tm', 'trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -12 ), ''yyyy'')-1' );
            else
              if SUBSTR(v_re.C_MEASURE_CODE,1,2) = '83'  then
                 v_sql := replace( v_sql, ':t_bgn_tm', 'trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -24 ), ''yyyy'')' );
                 v_sql := replace( v_sql, ':t_bend_tm','trunc( ADD_MONTHS(to_date('''||v_t_end_tm||''',''yyyy-mm-dd hh24:mi:ss''), -24 ), ''yyyy'')-1' );
              else
                  v_sql := replace( v_sql, ':t_bgn_tm', ' to_date(''' || v_t_bgn_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
                 v_sql := replace( v_sql, ':t_bend_tm',  ' to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
               end if;
            end if;
          end if;*/
        
          IF SUBSTR(V_RE.C_MEASURE_CODE, 1, 2) = '82' THEN
            --修改 上年截止日期 统计到当月为止
            --v_sql := REPLACE( v_sql, 'to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ', 'to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
            V_SQL := REPLACE(V_SQL,
                             ':t_bgn_tm',
                             'trunc( ADD_MONTHS(to_date(''' || V_T_END_TM ||
                             ''',''yyyy-mm-dd hh24:mi:ss''), -12 ), ''yyyy'')');
            V_SQL := REPLACE(V_SQL,
                             ':t_bend_tm',
                             'to_date(substr(''' || V_T_END_TM ||
                             ''',1,4)-1||''1231 235959'',''YYYYMMDD HH24MISS'')');
          
          ELSE
            --前年
            IF SUBSTR(V_RE.C_MEASURE_CODE, 1, 2) = '83' THEN
              --v_sql := REPLACE( v_sql, 'to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ', 'to_date(''' || v_t_end_tm || ''',''yyyy-mm-dd hh24:mi:ss'') ' );
              V_SQL := REPLACE(V_SQL,
                               ':t_bgn_tm',
                               'trunc( ADD_MONTHS(to_date(''' || V_T_END_TM ||
                               ''',''yyyy-mm-dd hh24:mi:ss''), -24 ), ''yyyy'')');
              V_SQL := REPLACE(V_SQL,
                               ':t_bend_tm',
                               'to_date(substr(''' || V_T_END_TM ||
                               ''',1,4)-2||''1231 235959'',''YYYYMMDD HH24MISS'')');
            ELSE
              V_SQL := REPLACE(V_SQL,
                               ':t_bgn_tm',
                               ' to_date(''' || V_T_BGN_TM ||
                               ''',''yyyy-mm-dd hh24:mi:ss'') ');
              V_SQL := REPLACE(V_SQL,
                               ':t_bend_tm',
                               ' to_date(''' || V_T_END_TM ||
                               ''',''yyyy-mm-dd hh24:mi:ss'') ');
            END IF;
          END IF;
        
          --delete from t_error_msg;
          --P_ERR_DEAL( 'rpt_iface_optimize.p_get_report', v_sql, v_re.C_MEASURE_CODE, SQLERRM );
          P_DEBUG_DEAL('rpt_iface_optimize.p_get_report before parse',
                       V_SQL,
                       '0',
                       V_RE.C_MEASURE_CODE);
          DBMS_SQL.PARSE(V_CURID, V_SQL, DBMS_SQL.V7);
        
          V_ROWNUM := DBMS_SQL.EXECUTE(V_CURID);
       --loujunxian edit 20120925 begin
          /*P_DEBUG_DEAL('rpt_iface_optimize.p_get_report',
                       V_SQL,
                       SQLCODE,
                       V_RE.C_MEASURE_CODE);*/  --delete
          --loujunxian edit 20120925 end
        END IF;
      EXCEPTION
        WHEN E_CONTINUE THEN
          NULL;
      END;
    END LOOP;
  
    IF DPTLEN = 2 THEN
      /*机构*/
      FOR V_RE IN CURITEM_DPT LOOP
        BEGIN
          IF V_RE.TABLE_VIEW_NAME = '---' THEN
            RAISE E_CONTINUE;
          END IF;
          V_SQL := 'insert into iface_measure(unitcode, year, month, measurecode, measurename, amount, remark, ts)';
          V_SQL := V_SQL || 'select ''00'', ''' || V_YEAR || ''',''' ||
                   V_MONTH || ''',''';
          V_SQL := V_SQL || V_RE.C_MEASURE_CODE || ''',''' ||
                   V_RE.C_MEASURE_NAME || ''', nvl(sum(1),0),''' ||
                   V_RE.C_MEASURE_NAME || ''',''' || V_TS || '''';
          V_SQL := V_SQL ||
                   ' from WEB_ORG_DPT where (t_adb_tm > :t_end_tm or t_adb_tm is null) and t_fnd_tm < :t_end_tm ';
        
          IF V_RE.C_KIND_NO_CON <> '---' THEN
            V_SQL := V_SQL || ' and length(C_INTER_CDE) ' ||
                     V_RE.C_KIND_NO_CON || V_RE.C_KIND_NO_VAL;
          END IF;
        
          DBMS_SQL.PARSE(V_CURID, V_SQL, DBMS_SQL.V7);
          DBMS_SQL.BIND_VARIABLE(V_CURID, ':t_end_tm', T_END_TM);
          V_ROWNUM := DBMS_SQL.EXECUTE(V_CURID);
          P_DEBUG_DEAL('rpt_iface_optimize.p_get_report',
                       V_SQL,
                       SQLCODE,
                       V_RE.C_MEASURE_CODE);
        EXCEPTION
          WHEN E_CONTINUE THEN
            NULL;
        END;
      END LOOP;
      /*员工*/
      FOR V_RE IN CURITEM_EMP LOOP
        BEGIN
          IF V_RE.TABLE_VIEW_NAME = '---' THEN
            RAISE E_CONTINUE;
          END IF;
          V_SQL := 'insert into iface_measure(unitcode, year, month, measurecode, measurename, amount, remark, ts)';
          V_SQL := V_SQL || 'select ''00'', ''' || V_YEAR || ''',''' ||
                   V_MONTH || ''',''';
          V_SQL := V_SQL || V_RE.C_MEASURE_CODE || ''',''' ||
                   V_RE.C_MEASURE_NAME || ''', nvl(sum(1),0),''' ||
                   V_RE.C_MEASURE_NAME || ''',''' || V_TS || '''';
          V_SQL := V_SQL ||
                   ' from WEB_ORG_EMP where (t_lev_tm is null or t_lev_tm > :t_end_tm) and t_ent_tm < :t_end_tm';
        
          IF V_RE.C_KIND_NO_CON <> '---' THEN
            V_SQL := V_SQL || ' and length(c_dpt_cde) ' ||
                     V_RE.C_KIND_NO_CON || V_RE.C_KIND_NO_VAL;
          END IF;
          IF V_RE.C_NEW_FLAG_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_dpt_cde ' || V_RE.C_NEW_FLAG_CON ||
                     V_RE.C_NEW_FLAG_VAL;
          END IF;
          IF V_RE.C_INSRNC_CDE_CON <> '---' THEN
            V_SQL := V_SQL || ' and c_sex ' || V_RE.C_INSRNC_CDE_CON ||
                     V_RE.C_INSRNC_CDE_VAL;
          END IF;
        
          DBMS_SQL.PARSE(V_CURID, V_SQL, DBMS_SQL.V7);
          DBMS_SQL.BIND_VARIABLE(V_CURID, ':t_end_tm', T_END_TM);
          V_ROWNUM := DBMS_SQL.EXECUTE(V_CURID);
          P_DEBUG_DEAL('rpt_iface_optimize.p_get_report',
                       V_SQL,
                       SQLCODE,
                       V_RE.C_MEASURE_CODE);
        EXCEPTION
          WHEN E_CONTINUE THEN
            NULL;
        END;
      END LOOP;
    
    END IF;
    DBMS_SQL.CLOSE_CURSOR(V_CURID);
    COMMIT;
    ---added by ctt 20120928
    update t_run_time set t_end_tm=sysdate where c_proc_nme='P_GET_REPORT';
    commit;
      ---added by ctt 20120928
    --------  p_circi_FORMULA_add( v_C_TYPE, 1 );--add by zhoufj
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_SQL.CLOSE_CURSOR(V_CURID);
      ROLLBACK;
      V_RET_STA := SQLCODE;
      P_ERR_DEAL('rpt_iface_optimize.p_get_report',
                 V_SQL,
                 SQLCODE,
                 SQLERRM);
      COMMIT;
  END;

  /*PROCEDURE Ri_Iface_Measure(
        v_beg_tm  IN       VARCHAR2,
        v_end_tm  IN    VARCHAR2,
        n_dptlen  IN       INT,
        v_err_str OUT      VARCHAR2
  )
  IS
     nCount  INT:=0;
     str_sql VARCHAR2(500);
     cYear   CHAR(4);
     cMonth  CHAR(2);
     cParComCde VARCHAR(4);
  
     CURSOR CUS_CONF(nClass INT) IS
     SELECT C_MEASURECODE,C_MEASURENAME FROM RI_IFACE_MEASURE_CONF WHERE N_MEASURECLASS=nClass;
  
     CusConf CUS_CONF%ROWTYPE;
  BEGIN
     cYear:=SUBSTR(v_end_tm,1,4);
     cMonth:=SUBSTR(v_end_tm,5,2);
  
   \*  DELETE FROM IFACE_MEASURE;*\
   \*****************************开始处理分出保费*************************************\
      DELETE FROM TMP_RI_MEASURE_PREM_1;  \*删除分出保费临时表数据*\
  
   BEGIN
    \*开始写分出保费临时表*\
    INSERT INTO TMP_RI_MEASURE_PREM_1
    SELECT
     C_DPT_NO,
              SUM(n_61220001*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220001,  \* 分出保费                                      *\
              SUM(n_61220002*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220002,  \* 分出保费－法定                                *\
              SUM(n_61220004*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220004,  \* 分出保费－法定－财产险                        *\
              SUM(n_61220005*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220005,  \* 分出保费－法定－财产险－非水险                *\
              SUM(n_61220006*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220006,  \* 分出保费－法定－财产险－责任险                *\
              SUM(n_61220011*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220011,  \* 分出保费－法定－财产险－保证保险              *\
              SUM(n_61220007*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220007,  \* 分出保费－法定－财产险－其他                  *\
              SUM(n_61220008*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220008,  \* 分出保费－法定－水险                          *\
              SUM(n_61220009*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220009,  \* 分出保费－法定－水险－货运险                  *\
              SUM(n_61220010*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220010,  \* 分出保费－法定－水险－船舶险                  *\
              SUM(n_61220023*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220023,  \* 分出保费－法定－水险－其他                    *\
              SUM(n_61220014*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220014,  \* 分出保费－法定－汽车险                        *\
              SUM(n_61220018*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220018,  \* 分出保费－法定－高风险                        *\
              SUM(n_61220022*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220022,  \* 分出保费－法定－高风险－航空险                *\
              SUM(n_61220024*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220024,  \* 分出保费－法定－高风险－航天险                *\
              SUM(n_61220034*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220034,  \* 分出保费－法定－高风险－石油险                *\
              SUM(n_61220031*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220031,  \* 分出保费－法定－高风险－核保险业务            *\
              SUM(n_61220035*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220035,  \* 分出保费－法定－意外伤害险                    *\
              SUM(n_61220036*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220036,  \* 分出保费－法定－健康险                        *\
              SUM(n_61220037*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220037,  \* 分出保费－法定－其他                          *\
              SUM(n_61220041*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220041,  \* 分出保费－非法定                              *\
              SUM(n_61220042*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220042,  \* 分出保费－非法定－合同分保                    *\
              SUM(n_61220043*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220043,  \* 分出保费－非法定－合同分保－财产险            *\
              SUM(n_61220069*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220069,  \* 分出保费－非法定－合同分保－财产险－非水险    *\
              SUM(n_61220070*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220070,  \* 分出保费－非法定－合同分保－财产险－责任险    *\
              SUM(n_61220071*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220071,  \* 分出保费－非法定－合同分保－财产险－保证保险  *\
              SUM(n_61220072*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220072,  \* 分出保费－非法定－合同分保－财产险－其他      *\
              SUM(n_61220003*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220003,  \* 分出保费－非法定－合同分保－水险              *\
              SUM(n_61220074*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220074,  \* 分出保费－非法定－合同分保－水险－货运险      *\
              SUM(n_61220075*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220075,  \* 分出保费－非法定－合同分保－水险－船舶险      *\
              SUM(n_61220076*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220076,  \* 分出保费－非法定－合同分保－水险－其他        *\
              SUM(n_61220012*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220012,  \* 分出保费－非法定－合同分保－汽车险            *\
              SUM(n_61220078*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220078,  \* 分出保费－非法定－合同分保－高风险            *\
              SUM(n_61220079*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220079,  \* 分出保费－非法定－合同分保－高风险－航空险    *\
              SUM(n_61220080*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220080,  \* 分出保费－非法定－合同分保－高风险－航天险    *\
              SUM(n_61220081*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220081,  \* 分出保费－非法定－合同分保－高风险－石油险    *\
              SUM(n_61220013*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220013,  \* 分出保费－非法定－合同分保－高风险－核保险业务*\
              SUM(n_61220015*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220015,  \* 分出保费－非法定－合同分保－意外伤害险        *\
              SUM(n_61220016*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220016,  \* 分出保费－非法定－合同分保－健康险            *\
              SUM(n_61220017*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220017,  \* 分出保费－非法定－合同分保－其他              *\
              SUM(n_61220019*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220019,  \* 分出保费－非法定－临时分保                    *\
              SUM(n_61220020*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220020,  \* 分出保费－非法定－临时分保－财产险            *\
              SUM(n_61220091*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220091,  \* 分出保费－非法定－临时分保－财产险－非水险    *\
              SUM(n_61220092*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220092,  \* 分出保费－非法定－临时分保－财产险－责任险    *\
              SUM(n_61220093*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220093,  \* 分出保费－非法定－临时分保－财产险－保证保险  *\
              SUM(n_61220094*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220094,  \* 分出保费－非法定－临时分保－财产险－其他      *\
              SUM(n_61220021*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220021,  \* 分出保费－非法定－临时分保－水险              *\
              SUM(n_61220096*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220096,  \* 分出保费－非法定－临时分保－水险－货运险      *\
              SUM(n_61220097*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220097,  \* 分出保费－非法定－临时分保－水险－船舶险      *\
              SUM(n_61220098*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220098,  \* 分出保费－非法定－临时分保－水险－其他        *\
              SUM(n_61220099*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220099,  \* 分出保费－非法定－临时分保－汽车险            *\
              SUM(n_61220100*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220100,  \* 分出保费－非法定－临时分保－高风险            *\
              SUM(n_61220101*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220101,  \* 分出保费－非法定－临时分保－高风险－航空险    *\
              SUM(n_61220102*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220102,  \* 分出保费－非法定－临时分保－高风险－航天险    *\
              SUM(n_61220103*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220103,  \* 分出保费－非法定－临时分保－高风险－石油险    *\
              SUM(n_61220104*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220104,  \* 分出保费－非法定－临时分保－高风险－核保险业务*\
              SUM(n_61220025*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220025,  \* 分出保费－非法定－临时分保－意外伤害险        *\
              SUM(n_61220026*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220026,  \* 分出保费－非法定－临时分保－健康险            *\
              SUM(n_61220027*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220027,  \* 分出保费－非法定－临时分保－其他              *\
              SUM(n_61220028*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220028,  \* 分出保费－境内                                *\
              SUM(n_61220044*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220044,  \* 分出保费－境内－财产险                        *\
              SUM(n_61220045*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220045,  \* 分出保费－境内－财产险－非水险                *\
              SUM(n_61220046*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220046,  \* 分出保费－境内－财产险－责任险                *\
              SUM(n_61220047*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220047,  \* 分出保费－境内－财产险－保证保险              *\
              SUM(n_61220048*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220048,  \* 分出保费－境内－财产险－其他                  *\
              SUM(n_61220049*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220049,  \* 分出保费－境内－水险                          *\
              SUM(n_61220050*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220050,  \* 分出保费－境内－水险－货运险                  *\
              SUM(n_61220051*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220051,  \* 分出保费－境内－水险－船舶险                  *\
              SUM(n_61220052*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220052,  \* 分出保费－境内－水险－其他                    *\
              SUM(n_61220053*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220053,  \* 分出保费－境内－汽车险                        *\
              SUM(n_61220054*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220054,  \* 分出保费－境内－高风险                        *\
              SUM(n_61220055*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220055,  \* 分出保费－境内－高风险－航空险                *\
              SUM(n_61220056*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220056,  \* 分出保费－境内－高风险－航天险                *\
              SUM(n_61220057*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220057,  \* 分出保费－境内－高风险－石油险                *\
              SUM(n_61220058*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220058,  \* 分出保费－境内－高风险－核保险业务            *\
              SUM(n_61220029*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220029,  \* 分出保费－境内－意外伤害险                    *\
              SUM(n_61220030*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220030,  \* 分出保费－境内－健康险                        *\
              SUM(n_61220065*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220065,  \* 分出保费－境内－其他                          *\
              SUM(n_61220066*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220066,  \* 分出保费－境外                                *\
              SUM(n_61220067*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220067,  \* 分出保费－境外－财产险                        *\
              SUM(n_61220068*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220068,  \* 分出保费－境外－财产险－非水险                *\
              SUM(n_61220073*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220073,  \* 分出保费－境外－财产险－责任险                *\
              SUM(n_61220077*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220077,  \* 分出保费－境外－财产险－保证保险              *\
              SUM(n_61220088*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220088,  \* 分出保费－境外－财产险－其他                  *\
              SUM(n_61220089*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220089,  \* 分出保费－境外－水险                          *\
              SUM(n_61220090*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220090,  \* 分出保费－境外－水险－货运险                  *\
              SUM(n_61220095*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220095,  \* 分出保费－境外－水险－船舶险                  *\
              SUM(n_61220111*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220111,  \* 分出保费－境外－水险－其他                    *\
              SUM(n_61220112*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220112,  \* 分出保费－境外－汽车险                        *\
              SUM(n_61220113*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220113,  \* 分出保费－境外－高风险                        *\
              SUM(n_61220114*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220114,  \* 分出保费－境外－高风险－航空险                *\
              SUM(n_61220115*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220115,  \* 分出保费－境外－高风险－航天险                *\
              SUM(n_61220116*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220116,  \* 分出保费－境外－高风险－石油险                *\
              SUM(n_61220117*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220117,  \* 分出保费－境外－高风险－核保险业务            *\
              SUM(n_61220032*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220032,  \* 分出保费－境外－意外伤害险                    *\
              SUM(n_61220033*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220033,  \* 分出保费－境外－健康险                        *\
              SUM(n_61220124*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61220124   \* 分出保费－境外－其他                          *\
    FROM (
          SELECT a.C_RI_CUR,
              SUBSTR (A.C_INSRNC_COM, 1, n_dptlen) C_DPT_NO, \*DECODE(SUBSTR (A.C_INSRNC_COM, 1, n_dptlen),'900','912',SUBSTR (A.C_INSRNC_COM, 1, n_dptlen)) C_DPT_NO,*\
        SUM(NVL(b.N_SHARE_PREM,0)) n_61220001, \*分出保费                                      *\
              \*法定*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )) n_61220002, \*分出保费－法定                                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220004, \*分出保费－法定－财产险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220005, \*分出保费－法定－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220006, \*分出保费－法定－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220011, \*分出保费－法定－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220007, \*分出保费－法定－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220008, \*分出保费－法定－水险                          *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220009, \*分出保费－法定－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220010, \*分出保费－法定－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220023, \*分出保费－法定－水险－其他                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220014, \*分出保费－法定－汽车险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220018, \*分出保费－法定－高风险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220022, \*分出保费－法定－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220024, \*分出保费－法定－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220034, \*分出保费－法定－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220031, \*分出保费－法定－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220035, \*分出保费－法定－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220036, \*分出保费－法定－健康险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220037, \*分出保费－法定－其他                          *\
              \*非法定*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,1 )) n_61220041, \*分出保费－非法定                              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )) n_61220042, \*分出保费－非法定－合同分保                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220043, \*分出保费－非法定－合同分保－财产险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220069, \*分出保费－非法定－合同分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220070, \*分出保费－非法定－合同分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220071, \*分出保费－非法定－合同分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220072, \*分出保费－非法定－合同分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220003, \*分出保费－非法定－合同分保－水险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220074, \*分出保费－非法定－合同分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220075, \*分出保费－非法定－合同分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220076, \*分出保费－非法定－合同分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220012, \*分出保费－非法定－合同分保－汽车险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220078, \*分出保费－非法定－合同分保－高风险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220079, \*分出保费－非法定－合同分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220080, \*分出保费－非法定－合同分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220081, \*分出保费－非法定－合同分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220013, \*分出保费－非法定－合同分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220015, \*分出保费－非法定－合同分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220016, \*分出保费－非法定－合同分保－健康险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220017, \*分出保费－非法定－合同分保－其他              *\
              \*临分*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )) n_61220019, \*分出保费－非法定－临时分保                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220020, \*分出保费－非法定－临时分保－财产险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220091, \*分出保费－非法定－临时分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220092, \*分出保费－非法定－临时分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220093, \*分出保费－非法定－临时分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220094, \*分出保费－非法定－临时分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220021, \*分出保费－非法定－临时分保－水险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220096, \*分出保费－非法定－临时分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220097, \*分出保费－非法定－临时分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220098, \*分出保费－非法定－临时分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220099, \*分出保费－非法定－临时分保－汽车险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220100, \*分出保费－非法定－临时分保－高风险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220101, \*分出保费－非法定－临时分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220102, \*分出保费－非法定－临时分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220103, \*分出保费－非法定－临时分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220104, \*分出保费－非法定－临时分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220025, \*分出保费－非法定－临时分保?input type="checkbox" name="" value="">馔馍撕ο?       *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220026, \*分出保费－非法定－临时分保－健康险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220027, \*分出保费－非法定－临时分保－其他              *\
              \*境内*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )) n_61220028, \*分出保费－境内                                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220044, \*分出保费－境内－财产险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220045, \*分出保费－境内－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220046, \*分出保费－境内－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220047, \*分出保费－境内－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220048, \*分出保费－境内－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220049, \*分出保费－境内－水险                          *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220050, \*分出保费－境内－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220051, \*分出保费－境内－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220052, \*分出保费－境内－水险－其他                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220053, \*分出保费－境内－汽车险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220054, \*分出保费－境内－高风险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220055, \*分出保费－境内－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220056, \*分出保费－境内－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220057, \*分出保费－境内－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220058, \*分出保费－境内－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220029, \*分出保费－境内－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220030, \*分出保费－境内－健康险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220065, \*分出保费－境内－其他                          *\
              \*境外*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )) n_61220066, \*分出保费－境外                                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220067, \*分出保费－境外－财产险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220068, \*分出保费－境外－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220073, \*分出保费－境外－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220077, \*分出保费－境外－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220088, \*分出保费－境外－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220089, \*分出保费－境外－水险                          *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220090, \*分出保费－境外－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220095, \*分出保费－境外－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220111, \*分出保费－境外－水险－其他                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220112, \*分出保费－境外－汽车险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220113, \*分出保费－境外－高风险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220114, \*分出保费－境外－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220115, \*分出保费－境外－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220116, \*分出保费－境外－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220117, \*分出保费－境外－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220032, \*分出保费－境外－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220033, \*分出保费－境外－健康险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220124  \*分出保费－境外－其他                          *\
        FROM  R_PLY_MAIN A,R_SHARE_PLY B,R_CONT_MAIN C,R_RI_COM d
        WHERE A.C_PLY_NO = B.C_PLY_NO
     AND A.N_TARGET=B.N_TARGET
     AND A.C_STATUS='C'
       AND A.N_INST = B.N_INST
       AND B.N_CONT_ID = C.N_ID
          AND d.c_code = b.C_RI_COM
    AND A.T_BAL_TM2 BETWEEN v_beg_tm AND v_end_tm
    AND LENGTH (A.C_INSRNC_COM) >= n_dptlen
       AND c.c_code NOT IN('04','BB')
    GROUP BY SUBSTR (A.C_INSRNC_COM, 1, n_dptlen),a.C_RI_CUR
   UNION
        SELECT   a.C_RI_CUR,
         SUBSTR (A.C_INSRNC_COM, 1, n_dptlen) C_DPT_NO,
              SUM(NVL(b.N_SHARE_PREM,0)) n_61220001, \*分出保费                                      *\
              \*法定*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )) n_61220002, \*分出保费－法定                                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220004, \*分出保费－法定－财产险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220005, \*分出保费－法定－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220006, \*分出保费－法定－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220011, \*分出保费－法定－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220007, \*分出保费－法定－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220008, \*分出保费－法定－水险                          *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220009, \*分出保费－法定－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220010, \*分出保费－法定－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220023, \*分出保费－法定－水险－其他                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220014, \*分出保费－法定－汽车险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220018, \*分出保费－法定－高风险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220022, \*分出保费－法定－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220024, \*分出保费－法定－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220034, \*分出保费－法定－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220031, \*分出保费－法定－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220035, \*分出保费－法定－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220036, \*分出保费－法定－健康险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220037, \*分出保费－法定－其他                          *\
              \*非法定*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,1 )) n_61220041, \*分出保费－非法定                              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )) n_61220042, \*分出保费－非法定－合同分保                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220043, \*分出保费－非法定－合同分保－财产险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220069, \*分出保费－非法定－合同分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220070, \*分出保费－非法定－合同分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220071, \*分出保费－非法定－合同分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220072, \*分出保费－非法定－合同分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220003, \*分出保费－非法定－合同分保－水险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220074, \*分出保费－非法定－合同分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220075, \*分出保费－非法定－合同分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220076, \*分出保费－非法定－合同分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220012, \*分出保费－非法定－合同分保－汽车险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220078, \*分出保费－非法定－合同分保－高风险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220079, \*分出保费－非法定－合同分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220080, \*分出保费－非法定－合同分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220081, \*分出保费－非法定－合同分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220013, \*分出保费－非法定－合同分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220015, \*分出保费－非法定－合同分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220016, \*分出保费－非法定－合同分保－健康险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220017, \*分出保费－非法定－合同分保－其他              *\
              \*临分*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )) n_61220019, \*分出保费－非法定－临时分保                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220020, \*分出保费－非法定－临时分保－财产险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220091, \*分出保费－非法定－临时分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220092, \*分出保费－非法定－临时分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220093, \*分出保费－非法定－临时分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220094, \*分出保费－非法定－临时分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220021, \*分出保费－非法定－临时分保－水险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220096, \*分出保费－非法定－临时分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220097, \*分出保费－非法定－临时分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220098, \*分出保费－非法定－临时分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220099, \*分出保费－非法定－临时分保－汽车险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220100, \*分出保费－非法定－临时分保－高风险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220101, \*分出保费－非法定－临时分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220102, \*分出保费－非法定－临时分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220103, \*分出保费－非法定－临时分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220104, \*分出保费－非法定－临时分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220025, \*分出保费－非法定－临时分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220026, \*分出保费－非法定－临时分保－健康险            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(c.C_CODE,'FA',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220027, \*分出保费－非法定－临时分保－其他              *\
  
              \*境内*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )) n_61220028, \*分出保费－境内                                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220044, \*分出保费－境内－财产险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220045, \*分出保费－境内－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220046, \*分出保费－境内－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220047, \*分出保费－境内－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220048, \*分出保费－境内－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220049, \*分出保费－境内－水险                          *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220050, \*分出保费－境内－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220051, \*分出保费－境内－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220052, \*分出保费－境内－水险－其他                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220053, \*分出保费－境内－汽车险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220054, \*分出保费－境内－高风险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220055, \*分出保费－境内－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220056, \*分出保费－境内－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220057, \*分出保费－境内－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220058, \*分出保费－境内－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220029, \*分出保费－境内－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220030, \*分出保费－境内－健康险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',1,0 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220065, \*分出保费－境内－其他                          *\
              \*境外*\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )) n_61220066, \*分出保费－境外                                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220067, \*分出保费－境外－财产险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61220068, \*分出保费－境外－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0 )) n_61220073, \*分出保费－境外－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0 )) n_61220077, \*分出保费－境外－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220088, \*分出保费－境外－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0 )) n_61220089, \*分出保费－境外－水险                          *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0 )) n_61220090, \*分出保费－境外－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0 )) n_61220095, \*分出保费－境外－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220111, \*分出保费－境外－水险－其他                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0 )) n_61220112, \*分出保费－境外－汽车险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220113, \*分出保费－境外－高风险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220114, \*分出保费－境外－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220115, \*分出保费－境外－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0 )) n_61220116, \*分出保费－境外－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220117, \*分出保费－境外－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0 )) n_61220032, \*分出保费－境外－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0 )) n_61220033, \*分出保费－境外－健康险                        *\
              SUM(NVL(b.N_SHARE_PREM,0)*DECODE(d.C_ATTRIB,'A',0,1 )*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0 )) n_61220124  \*分出保费－境外－其他                          *\
        FROM  R_EDR_MAIN A,R_SHARE_EDR B,R_CONT_MAIN C,R_RI_COM d
        WHERE A.C_EDR_NO = B.C_EDR_NO
      AND A.N_TARGET=B.N_TARGET
     AND A.C_STATUS='C'
       AND A.N_INST = B.N_INST
       AND B.N_CONT_ID = C.N_ID
          AND d.c_code = b.C_RI_COM
    AND A.T_BAL_TM2  BETWEEN v_beg_tm AND v_end_tm
    AND LENGTH (A.C_INSRNC_COM) >= n_dptlen
       AND c.c_code NOT IN('04','BB')
    GROUP BY SUBSTR (A.C_INSRNC_COM, 1, n_dptlen),a.C_RI_CUR
       )GROUP BY C_DPT_NO ;
    \*写分出保费临时表结束*\
  
   \*开始取配置表中的数据*\
  
   SELECT COUNT(*) INTO nCount FROM TMP_RI_MEASURE_PREM_1;
  
   IF nCount>0 THEN
      \*内码转换为外码*\
      UPDATE TMP_RI_MEASURE_PREM_1 a SET C_DPT_NO=(SELECT C_DPT_CDE FROM T_DEPARTMENT WHERE C_INTER_CDE=decode(a.C_DPT_NO,'900','9',a.C_DPT_NO));
  
      OPEN CUS_CONF(1);
      LOOP
  
          FETCH CUS_CONF INTO CusConf;
          EXIT WHEN CUS_CONF%NOTFOUND;
        BEGIN
      str_sql:='INSERT INTO IFACE_MEASURE(UNITCODE,YEAR,MONTH,MEASURECODE,MEASURENAME,AMOUNT) SELECT C_DPT_NO,'''||cYear||''','''||cMonth||''','''||CusConf.C_MEASURECODE||''','''||CusConf.C_MEASURENAME||''',n_'||CusConf.C_MEASURECODE||' FROM TMP_RI_MEASURE_PREM_1';
      EXECUTE IMMEDIATE str_sql;
        END;
  
      END LOOP;
      CLOSE CUS_CONF;
  
   END IF;
  
   EXCEPTION
        WHEN OTHERS THEN
        v_err_str := '取分出保费出错'||'['||SQLERRM||']';
     RETURN;
   END;  \*结束事物*\
    \*****************************结束分出保费处理*************************************\
  
    \*****************************开始处理摊回分保费用***************************************\
      DELETE FROM TMP_RI_MEASURE_COMM_1;  \*删除分出保费临时表数据*\
   BEGIN
    \*开始写分出保费临时表*\
    INSERT INTO TMP_RI_MEASURE_COMM_1
    SELECT
           C_DPT_NO,
                 SUM(n_61230041*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230041,  \*摊回分保费用                                      *\
                 SUM(n_61230001*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230001,  \*摊回分保费用－法定                                *\
                 SUM(n_61230004*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230004,  \*摊回分保费用－法定－财产险                        *\
                 SUM(n_61230003*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230003,  \*摊回分保费用－法定－财产险－非水险                *\
                 SUM(n_61230002*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230002,  \*摊回分保费用－法定－财产险－责任险                *\
                 SUM(n_61230010*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230010,  \*摊回分保费用－法定－财产险－保证保险              *\
                 SUM(n_61230005*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230005,  \*摊回分保费用－法定－财产险－其他                  *\
                 SUM(n_61230006*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230006,  \*摊回分保费用－法定－水险                          *\
                 SUM(n_61230007*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230007,  \*摊回分保费用－法定－水险－货运险                  *\
                 SUM(n_61230008*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230008,  \*摊回分保费用－法定－水险－船舶险                  *\
                 SUM(n_61230009*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230009,  \*摊回分保费用－法定－水险－其他                    *\
                 SUM(n_61230011*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230011,  \*摊回分保费用－法定－汽车险                        *\
                 SUM(n_61230012*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230012,  \*摊回分保费用－法定－高风险                        *\
                 SUM(n_61230013*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230013,  \*摊回分保费用－法定－高风险－航空险                *\
                 SUM(n_61230014*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230014,  \*摊回分保费用－法定－高风险－航天险                *\
                 SUM(n_61230015*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230015,  \*摊回分保费用－法定－高风险－石油险                *\
                 SUM(n_61230019*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230019,  \*摊回分保费用－法定－高风险－核保险业务            *\
                 SUM(n_61230016*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230016,  \*摊回分保费用－法定－意外伤害险                    *\
                 SUM(n_61230017*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230017,  \*摊回分保费用－法定－健康险                        *\
                 SUM(n_61230018*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230018,  \*摊回分保费用－法定－其他                          *\
                 SUM(n_61230023*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230023,  \*摊回分保费用－非法定                              *\
                 SUM(n_61230024*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230024,  \*摊回分保费用－非法定－合同分保                    *\
                 SUM(n_61230025*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230025,  \*摊回分保费用－非法定－合同分保－财产险            *\
                 SUM(n_61230068*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230068,  \*摊回分保费用－非法定－合同分保－财产险－非水险    *\
                 SUM(n_61230069*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230069,  \*摊回分保费用－非法定－合同分保－财产险－责任险    *\
                 SUM(n_61230070*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230070,  \*摊回分保费用－非法定－合同分保－财产险－保证保险  *\
                 SUM(n_61230071*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230071,  \*摊回分保费用－非法定－合同分保－财产险－其他      *\
                 SUM(n_61230026*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230026,  \*摊回分保费用－非法定－合同分保－水险              *\
                 SUM(n_61230073*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230073,  \*摊回分保费用－非法定－合同分保－水险－货运险      *\
                 SUM(n_61230074*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230074,  \*摊回分保费用－非法定－合同分保－水险－船舶险      *\
                 SUM(n_61230075*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230075,  \*摊回分保费用－非法定－合同分保－水险－其他        *\
                 SUM(n_61230027*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230027,  \*摊回分保费用－非法定－合同分保－汽车险            *\
                 SUM(n_61230077*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230077,  \*摊回分保费用－非法定－合同分保－高风险            *\
                 SUM(n_61230078*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230078,  \*摊回分保费用－非法定－合同分保－高风险－航空险    *\
                 SUM(n_61230079*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230079,  \*摊回分保费用－非法定－合同分保－高风险－航天险    *\
                 SUM(n_61230080*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230080,  \*摊回分保费用－非法定－合同分保－高风险－石油险    *\
                 SUM(n_61230081*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230081,  \*摊回分保费用－非法定－合同分保－高风险－核保险业务*\
                 SUM(n_61230028*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230028,  \*摊回分保费用－非法定－合同分保－意外伤害险        *\
                 SUM(n_61230029*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230029,  \*摊回分保费用－非法定－合同分保－健康险            *\
                 SUM(n_61230030*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230030,  \*摊回分保费用－非法定－合同分保－其他              *\
                 SUM(n_61230031*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230031,  \*摊回分保费用－非法定－临时分保                    *\
                 SUM(n_61230032*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230032,  \*摊回分保费用－非法定－临时分保－财产险            *\
                 SUM(n_61230091*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230091,  \*摊回分保费用－非法定－临时分保－财产险－非水险    *\
                 SUM(n_61230092*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230092,  \*摊回分保费用－非法定－临时分保－财产险－责任险    *\
                 SUM(n_61230093*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230093,  \*摊回分保费用－非法定－临时分保－财产险－保证保险  *\
                 SUM(n_61230094*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230094,  \*摊回分保费用－非法定－临时分保－财产险－其他      *\
                 SUM(n_61230033*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230033,  \*摊回分保费用－非法定－临时分保－水险              *\
                 SUM(n_61230096*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230096,  \*摊回分保费用－非法定－临时分保－水险－货运险      *\
                 SUM(n_61230097*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230097,  \*摊回分保费用－非法定－临时分保－水险－船舶险      *\
                 SUM(n_61230098*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230098,  \*摊回分保费用－非法定－临时分保－水险－其他        *\
                 SUM(n_61230099*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230099,  \*摊回分保费用－非法定－临时分保－汽车险            *\
                 SUM(n_61230100*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230100,  \*摊回分保费用－非法定－临时分保－高风险            *\
                 SUM(n_61230101*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230101,  \*摊回分保费用－非法定－临时分保－高风险－航空险    *\
                 SUM(n_61230102*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230102,  \*摊回分保费用－非法定－临时分保－高风险－航天险    *\
                 SUM(n_61230103*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230103,  \*摊回分保费用－非法定－临时分保－高风险－石油险    *\
                 SUM(n_61230104*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230104,  \*摊回分保费用－非法定－临时分保－高风险－核保险业务*\
                 SUM(n_61230034*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230034,  \*摊回分保费用－非法定－临时分保－意外伤害险        *\
                 SUM(n_61230035*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230035,  \*摊回分保费用－非法定－临时分保－健康险            *\
                 SUM(n_61230036*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230036,  \*摊回分保费用－非法定－临时分保－其他              *\
                 SUM(n_61230042*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230042,  \*摊回分保费用－境内                                *\
                 SUM(n_61230043*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230043,  \*摊回分保费用－境内－财产险                        *\
                 SUM(n_61230044*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230044,  \*摊回分保费用－境内－财产险－非水险                *\
                 SUM(n_61230045*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230045,  \*摊回分保费用－境内－财产险－责任险                *\
                 SUM(n_61230046*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230046,  \*摊回分保费用－境内－财产险－保证保险              *\
                 SUM(n_61230047*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230047,  \*摊回分保费用－境内－财产险－其他                  *\
                 SUM(n_61230048*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230048,  \*摊回分保费用－境内－水险                          *\
                 SUM(n_61230049*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230049,  \*摊回分保费用－境内－水险－货运险                  *\
                 SUM(n_61230050*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230050,  \*摊回分保费用－境内－水险－船舶险                  *\
                 SUM(n_61230051*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230051,  \*摊回分保费用－境内－水险－其他                    *\
                 SUM(n_61230052*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230052,  \*摊回分保费用－境内－汽车险                        *\
                 SUM(n_61230053*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230053,  \*摊回分保费用－境内－高风险                        *\
                 SUM(n_61230054*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230054,  \*摊回分保费用－境内－高风险－航空险                *\
                 SUM(n_61230055*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230055,  \*摊回分保费用－境内－高风险－航天险                *\
                 SUM(n_61230056*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230056,  \*摊回分保费用－境内－高风险－石油险                *\
                 SUM(n_61230057*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230057,  \*摊回分保费用－境内－高风险－核保险业务            *\
                 SUM(n_61230037*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230037,  \*摊回分保费用－境内－意外伤害险                    *\
                 SUM(n_61230038*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230038,  \*摊回分保费用－境内－健康险                        *\
                 SUM(n_61230064*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230064,  \*摊回分保费用－境内－其他                          *\
                 SUM(n_61230065*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230065,  \*摊回分保费用－境外                                *\
                 SUM(n_61230066*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230066,  \*摊回分保费用－境外－财产险                        *\
                 SUM(n_61230067*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230067,  \*摊回分保费用－境外－财产险－非水险                *\
                 SUM(n_61230072*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230072,  \*摊回分保费用－境外－财产险－责任险                *\
                 SUM(n_61230076*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230076,  \*摊回分保费用－境外－财产险－保证保险              *\
                 SUM(n_61230088*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230088,  \*摊回分保费用－境外－财产险－其他                  *\
                 SUM(n_61230089*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230089,  \*摊回分保费用－境外－水险                          *\
                 SUM(n_61230090*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230090,  \*摊回分保费用－境外－水险－货运险                  *\
                 SUM(n_61230095*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230095,  \*摊回分保费用－境外－水险－船舶险                  *\
                 SUM(n_61230111*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230111,  \*摊回分保费用－境外－水险－其他                    *\
                 SUM(n_61230112*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230112,  \*摊回分保费用－境外－汽车险                        *\
                 SUM(n_61230113*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230113,  \*摊回分保费用－境外－高风险                        *\
                 SUM(n_61230114*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230114,  \*摊回分保费用－境外－高风险－航空险                *\
                 SUM(n_61230115*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230115,  \*摊回分保费用－境外－高风险－航天险                *\
                 SUM(n_61230116*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230116,  \*摊回分保费用－境外－高风险－石油险                *\
                 SUM(n_61230117*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230117,  \*摊回分保费用－境外－高风险－核保险业务            *\
                 SUM(n_61230039*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230039,  \*摊回分保费用－境外－意外伤害险                    *\
                 SUM(n_61230040*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230040,  \*摊回分保费用－境外－健康险                        *\
                 SUM(n_61230124*DECODE(C_RI_CUR,'01',1,GET_RATE(C_RI_CUR,'01'))) n_61230124   \*摊回分保费用－境外－其他                          *\
  FROM (
        SELECT a.C_RI_CUR,
         SUBSTR (A.C_INSRNC_COM, 1, n_dptlen) C_DPT_NO,
              SUM(NVL(b.N_SHARE_COMM,0)) n_61230041, \*分出保费                                      *\
              \*法定*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)) n_61230001, \*分出保费－法定                                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230004, \*分出保费－法定－财产险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230003, \*分出保费－法定－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230002, \*分出保费－法定－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230010, \*分出保费－法定－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230005, \*分出保费－法定－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230006, \*分出保费－法定－水险                          *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230007, \*分出保费－法定－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230008, \*分出保费－法定－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230009, \*分出保费－法定－水险－其他                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230011, \*分出保费－法定－汽车险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230012, \*分出保费－法定－高风险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230013, \*分出保费－法定－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230014, \*分出保费－法定－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230015, \*分出保费－法定－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230019, \*分出保费－法定－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230016, \*分出保费－法定－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230017, \*分出保费－法定－健康险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230018, \*分出保费－法定－其他                          *\
              \*非法定*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,1)) n_61230023, \*分出保费－非法定                              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)) n_61230024, \*分出保费－非法定－合同分保                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230025, \*分出保费－非法定－合同分保－财产险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230068, \*分出保费－非法定－合同分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230069, \*分出保费－非法定－合同分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230070, \*分出保费－非法定－合同分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230071, \*分出保费－非法定－合同分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230026, \*分出保费－非法定－合同分保－水险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230073, \*分出保费－非法定－合同分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230074, \*分出保费－非法定－合同分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230075, \*分出保费－非法定－合同分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230027, \*分出保费－非法定－合同分保－汽车险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230077, \*分出保费－非法定－合同分保－高风险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230078, \*分出保费－非法定－合同分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230079, \*分出保费－非法定－合同分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230080, \*分出保费－非法定－合同分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230081, \*分出保费－非法定－合同分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230028, \*分出保费－非法定－合同分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230029, \*分出保费－非法定－合同分保－健康险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230030, \*分出保费－非法定－合同分保－其他              *\
              \*临分*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)) n_61230031, \*分出保费－非法定－临时分保                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230032, \*分出保费－非法定－临时分保－财产险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230091, \*分出保费－非法定－临时分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230092, \*分出保费－非法定－临时分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230093, \*分出保费－非法定－临时分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230094, \*分出保费－非法定－临时分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230033, \*分出保费－非法定－临时分保－水险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230096, \*分出保费－非法定－临时分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230097, \*分出保费－非法定－临时分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230098, \*分出保费－非法定－临时分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230099, \*分出保费－非法定－临时分保－汽车险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230100, \*分出保费－非法定－临时分保－高风险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230101, \*分出保费－非法定－临时分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230102, \*分出保费－非法定－临时分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230103, \*分出保费－非法定－临时分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230104, \*分出保费－非法定－临时分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230034, \*分出保费－非法定－临时分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230035, \*分出保费－非法定－临时分保－健康险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230036, \*分出保费－非法定－临时分保－其他              *\
              \*境内*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)) n_61230042, \*分出保费－境内                                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230043, \*分出保费－境内－财产险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230044, \*分出保费－境内－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230045, \*分出保费－境内－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230046, \*分出保费－境内－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230047, \*分出保费－境内－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230048, \*分出保费－境内－水险                          *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230049, \*分出保费－境内－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230050, \*分出保费－境内－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230051, \*分出保费－境内－水险－其他                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230052, \*分出保费－境内－汽车险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230053, \*分出保费－境内－高风险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230054, \*分出保费－境内－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230055, \*分出保费－境内－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230056, \*分出保费－境内－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230057, \*分出保费－境内－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230037, \*分出保费－境内－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230038, \*分出保费－境内－健康险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230064, \*分出保费－境内－其他                          *\
              \*境外*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)) n_61230065, \*分出保费－境外                                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230066, \*分出保费－境外－财产险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230067, \*分出保费－境外－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230072, \*分出保费－境外－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230076, \*分出保费－境外－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230088, \*分出保费－境外－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230089, \*分出保费－境外－水险                          *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230090, \*分出保费－境外－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230095, \*分出保费－境外－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230111, \*分出保费－境外－水险－其他                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230112, \*分出保费－境外－汽车险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230113, \*分出保费－境外－高风险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230114, \*分出保费－境外－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230115, \*分出保费－境外－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230116, \*分出保费－境外－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230117, \*分出保费－境外－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230039, \*分出保费－境外－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230040, \*分出保费－境外－健康险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230124  \*分出保费－境外－其他                          *\
        FROM  R_PLY_MAIN A,R_SHARE_PLY B,R_CONT_MAIN C,R_RI_COM d
        WHERE A.C_PLY_NO = B.C_PLY_NO
      AND A.N_TARGET=B.N_TARGET
     AND A.C_STATUS='C'
       AND A.N_INST = B.N_INST
       AND B.N_CONT_ID = C.N_ID
          AND d.c_code = b.C_RI_COM
    AND A.T_BAL_TM2  BETWEEN v_beg_tm AND v_end_tm
    AND LENGTH (A.C_INSRNC_COM) >= n_dptlen
      AND c.c_code NOT IN('04','BB')
    GROUP BY SUBSTR (A.C_INSRNC_COM, 1, n_dptlen),a.C_RI_CUR
    UNION
        SELECT   a.C_RI_CUR,
          SUBSTR (A.C_INSRNC_COM, 1, n_dptlen) C_DPT_NO,
              SUM(NVL(b.N_SHARE_COMM,0)) n_61230041, \*分出保费                                      *\
              \*法定*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)) n_61230001, \*分出保费－法定                                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230004, \*分出保费－法定－财产险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230003, \*分出保费－法定－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230002, \*分出保费－法定－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230010, \*分出保费－法定－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230005, \*分出保费－法定－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230006, \*分出保费－法定－水险                          *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230007, \*分出保费－法定－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230008, \*分出保费－法定－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230009, \*分出保费－法定－水险－其他                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230011, \*分出保费－法定－汽车险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230012, \*分出保费－法定－高风险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230013, \*分出保费－法定－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230014, \*分出保费－法定－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230015, \*分出保费－法定－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230019, \*分出保费－法定－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230016, \*分出保费－法定－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230017, \*分出保费－法定－健康险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230018, \*分出保费－法定－其他                          *\
              \*非法定*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,1)) n_61230023, \*分出保费－非法定                              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)) n_61230024, \*分出保费－非法定－合同分保                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230025, \*分出保费－非法定－合同分保－财产险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230068, \*分出保费－非法定－合同分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230069, \*分出保费－非法定－合同分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230070, \*分出保费－非法定－合同分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230071, \*分出保费－非法定－合同分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230026, \*分出保费－非法定－合同分保－水险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230073, \*分出保费－非法定－合同分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230074, \*分出保费－非法定－合同分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230075, \*分出保费－非法定－合同分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230027, \*分出保费－非法定－合同分保－汽车险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230077, \*分出保费－非法定－合同分保－高风险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230078, \*分出保费－非法定－合同分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230079, \*分出保费－非法定－合同分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230080, \*分出保费－非法定－合同分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230081, \*分出保费－非法定－合同分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230028, \*分出保费－非法定－合同分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230029, \*分出保费－非法定－合同分保－健康险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230030, \*分出保费－非法定－合同分保－其他              *\
              \*临分*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)) n_61230031, \*分出保费－非法定－临时分保                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230032, \*分出保费－非法定－临时分保－财产险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230091, \*分出保费－非法定－临时分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230092, \*分出保费－非法定－临时分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230093, \*分出保费－非法定－临时分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230094, \*分出保费－非法定－临时分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230033, \*分出保费－非法定－临时分保－水险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230096, \*分出保费－非法定－临时分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230097, \*分出保费－非法定－临时分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230098, \*分出保费－非法定－临时分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230099, \*分出保费－非法定－临时分保－汽车险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230100, \*分出保费－非法定－临时分保－高风险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230101, \*分出保费－非法定－临时分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230102, \*分出保费－非法定－临时分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230103, \*分出保费－非法定－临时分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230104, \*分出保费－非法定－临时分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230034, \*分出保费－非法定－临时分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230035, \*分出保费－非法定－临时分保－健康险            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230036, \*分出保费－非法定－临时分保－其他              *\
              \*境内*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)) n_61230042, \*分出保费－境内                                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230043, \*分出保费－境内－财产险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230044, \*分出保费－境内－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230045, \*分出保费－境内－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230046, \*分出保费－境内－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230047, \*分出保费－境内－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230048, \*分出保费－境内－水险                          *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230049, \*分出保费－境内－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230050, \*分出保费－境内－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230051, \*分出保费－境内－水险－其他                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230052, \*分出保费－境内－汽车险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230053, \*分出保费－境内－高风险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230054, \*分出保费－境内－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230055, \*分出保费－境内－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230056, \*分出保费－境内－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230057, \*分出保费－境内－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230037, \*分出保费－境内－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230038, \*分出保费－境内－健康险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230064, \*分出保费－境内－其他                          *\
              \*境外*\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)) n_61230065, \*分出保费－境外                                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230066, \*分出保费－境外－财产险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61230067, \*分出保费－境外－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61230072, \*分出保费－境外－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61230076, \*分出保费－境外－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230088, \*分出保费－境外－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61230089, \*分出保费－境外－水险                          *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61230090, \*分出保费－境外－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61230095, \*分出保费－境外－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230111, \*分出保费－境外－水险－其他                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61230112, \*分出保费－境外－汽车险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230113, \*分出保费－境外－高风险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230114, \*分出保费－境外－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230115, \*分出保费－境外－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61230116, \*分出保费－境外－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230117, \*分出保费－境外－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61230039, \*分出保费－境外－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61230040, \*分出保费－境外－健康险                        *\
              SUM(NVL(b.N_SHARE_COMM,0)*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61230124  \*分出保费－境外－其他                          *\
        FROM  R_EDR_MAIN A,R_SHARE_EDR B,R_CONT_MAIN C,R_RI_COM d
        WHERE A.C_EDR_NO = B.C_EDR_NO
      AND A.N_TARGET=B.N_TARGET
     AND A.C_STATUS='C'
       AND A.N_INST = B.N_INST
       AND B.N_CONT_ID = C.N_ID
          AND d.c_code = b.C_RI_COM
    AND A.T_BAL_TM2  BETWEEN v_beg_tm AND v_end_tm
    AND LENGTH (A.C_INSRNC_COM) >= n_dptlen
     AND c.c_code NOT IN('04','BB')
    GROUP BY SUBSTR (A.C_INSRNC_COM, 1, n_dptlen),a.C_RI_CUR
       )GROUP BY C_DPT_NO  ;
  
    \*写分出保费临时表结束*\
  
   \*开始取配置表中的数据*\
  
   SELECT COUNT(*) INTO nCount FROM TMP_RI_MEASURE_COMM_1;
  
   IF nCount>0 THEN
    \*内码转换为外码*\
      UPDATE TMP_RI_MEASURE_COMM_1 a SET C_DPT_NO=(SELECT C_DPT_CDE FROM T_DEPARTMENT WHERE C_INTER_CDE=decode(a.C_DPT_NO,'900','9',a.C_DPT_NO));
  
      OPEN CUS_CONF(2);
      LOOP
  
          FETCH CUS_CONF INTO CusConf;
          EXIT WHEN CUS_CONF%NOTFOUND;
        BEGIN
      str_sql:='INSERT INTO IFACE_MEASURE(UNITCODE,YEAR,MONTH,MEASURECODE,MEASURENAME,AMOUNT) SELECT C_DPT_NO,'''||cYear||''','''||cMonth||''','''||CusConf.C_MEASURECODE||''','''||CusConf.C_MEASURENAME||''',n_'||CusConf.C_MEASURECODE||' FROM TMP_RI_MEASURE_COMM_1';
      EXECUTE IMMEDIATE str_sql;
        END;
  
      END LOOP;
      CLOSE CUS_CONF;
  
   END IF;
   EXCEPTION
        WHEN OTHERS THEN
        v_err_str := '取摊回分保费用出错'||'['||SQLERRM||']';
     RETURN;
   END;  \*结束事物*\
    \*****************************结束摊回分保费用处理*************************************\
  
  
  
    \*****************************开始处理摊回分保赔款***************************************\
   DELETE FROM TMP_RI_MEASURE_CLM_1;  \*删除分出保费临时表数据*\
   BEGIN
    \*开始写分出保费临时表*\
    INSERT INTO TMP_RI_MEASURE_CLM_1
    SELECT
            SUBSTR (A.C_INSRNC_COM, 1, n_dptlen) C_DPT_NO,
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))) n_61240044, \*分出保费                                      *\
              \*法定*\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)) n_61240020, \*分出保费－法定                                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240023, \*分出保费－法定－财产险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240022, \*分出保费－法定－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61240021, \*分出保费－法定－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61240024, \*分出保费－法定－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240025, \*分出保费－法定－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61240026, \*分出保费－法定－水险                          *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61240031, \*分出保费－法定－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61240027, \*分出保费－法定－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240028, \*分出保费－法定－水险－其他                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61240029, \*分出保费－法定－汽车险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240030, \*分出保费－法定－高风险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240032, \*分出保费－法定－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240037, \*分出保费－法定－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240033, \*分出保费－法定－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240034, \*分出保费－法定－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61240035, \*分出保费－法定－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61240036, \*分出保费－法定－健康险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240041, \*分出保费－法定－其他                          *\
              \*非法定*\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,1)) n_61240042, \*分出保费－非法定                              *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)) n_61240043, \*分出保费－非法定－合同分保                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240001, \*分出保费－非法定－合同分保－财产险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240071, \*分出保费－非法定－合同分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61240072, \*分出保费－非法定－合同分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61240073, \*分出保费－非法定－合同分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240074, \*分出保费－非法定－合同分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61240002, \*分出保费－非法定－合同分保－水险              *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61240076, \*分出保费－非法定－合同分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61240077, \*分出保费－非法定－合同分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240078, \*分出保费－非法定－合同分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61240003, \*分出保费－非法定－合同分保－汽车险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240080, \*分出保费－非法定－合同分保－高风险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240081, \*分出保费－非法定－合同分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240082, \*分出保费－非法定－合同分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240083, \*分出保费－非法定－合同分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240084, \*分出保费－非法定－合同分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61240004, \*分出保费－非法定－合同分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61240009, \*分出保费－非法定－合同分保－健康险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'01',0,'FA',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240005, \*分出保费－非法定－合同分保－其他              *\
              \*临分*\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)) n_61240010, \*分出保费－非法定－临时分保                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240011, \*分出保费－非法定－临时分保－财产险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240088, \*分出保费－非法定－临时分保－财产险－非水险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61240089, \*分出保费－非法定－临时分保－财产险－责任险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61240090, \*分出保费－非法定－临时分保－财产险－保证保险  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240091, \*分出保费－非法定－临时分保－财产险－其他      *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61240012, \*分出保费－非法定－临时分保－水险              *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61240093, \*分出保费－非法定－临时分保－水险－货运险      *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61240094, \*分出保费－非法定－临时分保－水险－船舶险      *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240095, \*分出保费－非法定－临时分保－水险－其他        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61240096, \*分出保费－非法定－临时分保－汽车险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240097, \*分出保费－非法定－临时分保－高风险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240098, \*分出保费－非法定－临时分保－高风险－航空险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240099, \*分出保费－非法定－临时分保－高风险－航天险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240100, \*分出保费－非法定－临时分保－高风险－石油险    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240101, \*分出保费－非法定－临时分保－高风险－核保险业务*\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61240013, \*分出保费－非法定－临时分保－意外伤害险        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61240014, \*分出保费－非法定－临时分保－健康险            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(c.C_CODE,'FA',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240015, \*分出保费－非法定－临时分保－其他              *\
  
              \*境内*\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)) n_61240045, \*分出保费－境内                                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240046, \*分出保费－境内－财产险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240047, \*分出保费－境内－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61240048, \*分出保费－境内－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61240049, \*分出保费－境内－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240050, \*分出保费－境内－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61240051, \*分出保费－境内－水险                          *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61240052, \*分出保费－境内－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61240053, \*分出保费－境内－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240054, \*分出保费－境内－水险－其他                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61240055, \*分出保费－境内－汽车险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240056, \*分出保费－境内－高风险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240057, \*分出保费－境内－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240058, \*分出保费－境内－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240059, \*分出保费－境内－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240060, \*分出保费－境内－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61240016, \*分出保费－境内－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61240017, \*分出保费－境内－健康险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',1,0)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240067, \*分出保费－境内－其他                          *\
              \*境外*\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)) n_61240068, \*分出保费－境外                                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'04',1,'05',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240069, \*分出保费－境外－财产险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'01',1,'07',1, '08',1,'09',1,'10',1,'16',1,'17',1,0 )) n_61240070, \*分出保费－境外－财产险－非水险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'04',1,0)) n_61240075, \*分出保费－境外－财产险－责任险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'05',1,0)) n_61240079, \*分出保费－境外－财产险－保证保险              *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240085, \*分出保费－境外－财产险－其他                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,'11',1,0)) n_61240086, \*分出保费－境外－水险                          *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'02',1,0)) n_61240087, \*分出保费－境外－水险－货运险                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'11',1,0)) n_61240092, \*分出保费－境外－水险－船舶险                  *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240105, \*分出保费－境外－水险－其他                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'03',1,0)) n_61240106, \*分出保费－境外－汽车险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240107, \*分出保费－境外－高风险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240108, \*分出保费－境外－高风险－航空险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240109, \*分出保费－境外－高风险－航天险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'18',1,0)) n_61240110, \*分出保费－境外－高风险－石油险                *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240111, \*分出保费－境外－高风险－核保险业务            *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'06',1,0)) n_61240018, \*分出保费－境外－意外伤害险                    *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'12',1,0)) n_61240019, \*分出保费－境外－健康险                        *\
              SUM(NVL(b.N_SHARE_SUM,0)*DECODE(a.C_RI_CUR,'01',1,GET_RATE(a.C_RI_CUR,'01'))*DECODE(d.C_ATTRIB,'A',0,1)*DECODE(SUBSTR(a.C_INSRNC_TYPE,1,2),'99',1,0)) n_61240118  \*分出保费－境外－其他                          *\
       FROM  R_CLM_MAIN A,R_SHARE_CLM B,R_CONT_MAIN C,R_RI_COM d
        WHERE A.C_CLM_NO = B.C_CLM_NO
       AND A.N_CLM_TMS=B.N_CLM_TMS
    AND A.N_TARGET=B.N_TARGET
     AND A.C_STATUS='C'
       AND B.N_CONT_ID = C.N_ID
          AND d.c_code = b.C_RI_COM
    AND A.T_BAL_TM2  BETWEEN v_beg_tm AND v_end_tm
    AND LENGTH (A.C_INSRNC_COM) >= n_dptlen
    AND c.c_code NOT IN('04','BB')
    GROUP BY SUBSTR (A.C_INSRNC_COM, 1, n_dptlen);
  
    \*写分出保费临时表结束*\
  
   \*开始取配置表中的数据*\
  
   SELECT COUNT(*) INTO nCount FROM TMP_RI_MEASURE_CLM_1;
  
   IF nCount>0 THEN
    \*内码转换为外码*\
  
  
  
      UPDATE TMP_RI_MEASURE_CLM_1 a SET C_DPT_NO=(SELECT C_DPT_CDE FROM T_DEPARTMENT WHERE C_INTER_CDE=decode(a.C_DPT_NO,'900','9',a.C_DPT_NO));
  
      OPEN CUS_CONF(3);
      LOOP
  
          FETCH CUS_CONF INTO CusConf;
          EXIT WHEN CUS_CONF%NOTFOUND;
        BEGIN
      str_sql:='INSERT INTO IFACE_MEASURE(UNITCODE,YEAR,MONTH,MEASURECODE,MEASURENAME,AMOUNT) SELECT C_DPT_NO,'''||cYear||''','''||cMonth||''','''||CusConf.C_MEASURECODE||''','''||CusConf.C_MEASURENAME||''',n_'||CusConf.C_MEASURECODE||' FROM TMP_RI_MEASURE_CLM_1';
      EXECUTE IMMEDIATE str_sql;
        END;
  
      END LOOP;
      CLOSE CUS_CONF;
  
   END IF;
  
   EXCEPTION
        WHEN OTHERS THEN
        v_err_str := '取摊回分保赔款出错'||'['||SQLERRM||']';
     RETURN;
   END;  \*结束事物*\
    \*****************************结束摊回分保赔款处理*************************************\
  END;*/
  PROCEDURE P_CIRCI_FORMULA_ADD(C_REPORT_TYPE   VARCHAR2,
                                C_INSERT_UPDATE INTEGER) IS
    N_TOTAL       NUMBER(22, 2);
    N_SUM         NUMBER(22, 2);
    V_TOTAL       VARCHAR2(20);
    V_SUM         VARCHAR2(3000);
    N_POSI        INTEGER;
    V_MEASURECODE VARCHAR2(100);
    V_C_DPT_CDE   VARCHAR2(100);
  
    CURSOR CUR_MEASURECODE IS
      SELECT DISTINCT UNITCODE, MEASURECODE FROM IFACE_MEASURE;
    CURSOR CUR_FORMULA IS
      SELECT C_FORMULA
        FROM T_ITEMCHECK_FORMULA
       WHERE INSTR(C_FORMULA, '+') <> 0
         AND C_FORMULA LIKE V_MEASURECODE || '=%';
    CURSOR CUR_ADD IS
      SELECT MEASURECODE, TO_NUMBER(NVL(AMOUNT, '0')) AS AMOUNT
        FROM IFACE_MEASURE
       WHERE UNITCODE = V_C_DPT_CDE
         AND INSTR(V_SUM, MEASURECODE) <> 0;
  BEGIN
    FOR V_MEASURE IN CUR_MEASURECODE LOOP
      BEGIN
        V_MEASURECODE := V_MEASURE.MEASURECODE;
        V_C_DPT_CDE   := V_MEASURE.UNITCODE;
        FOR V_FORMULA IN CUR_FORMULA LOOP
          BEGIN
            N_POSI  := INSTR(V_FORMULA.C_FORMULA, '=');
            V_TOTAL := SUBSTR(V_FORMULA.C_FORMULA, 1, N_POSI - 1);
            V_SUM   := SUBSTR(V_FORMULA.C_FORMULA,
                              N_POSI + 1,
                              LENGTH(V_FORMULA.C_FORMULA) - N_POSI);
            N_SUM   := 0;
          
            SELECT NVL(SUM(TO_NUMBER(AMOUNT)), 0)
              INTO N_TOTAL
              FROM IFACE_MEASURE
             WHERE MEASURECODE = V_TOTAL
               AND UNITCODE = V_C_DPT_CDE;
          
            FOR V_ADD IN CUR_ADD LOOP
              BEGIN
                N_POSI := INSTR(V_SUM, V_ADD.MEASURECODE);
                IF N_POSI = 1 THEN
                  N_SUM := N_SUM + V_ADD.AMOUNT;
                ELSE
                  IF SUBSTR(V_SUM, N_POSI - 1, 1) = '+' THEN
                    N_SUM := N_SUM + V_ADD.AMOUNT;
                  ELSE
                    N_SUM := N_SUM - V_ADD.AMOUNT;
                  END IF;
                END IF;
              EXCEPTION
                WHEN OTHERS THEN
                  INSERT INTO T_ERROR_MSG
                    (OCCTIME, PROCNAME, INPARM)
                  VALUES
                    (SYSDATE, 'p_circi_FORMULA_add:cur_add', V_ADD.AMOUNT);
              END;
            END LOOP;
            IF C_INSERT_UPDATE = 1 THEN
              --update
              IF (N_TOTAL <> N_SUM) AND (N_TOTAL - N_SUM <= 1) AND
                 (N_TOTAL - N_SUM >= -1) THEN
                INSERT INTO T_ERROR_MSG
                  (OCCTIME, PROCNAME, INPARM, N_SQLCODE, S_SQLERRM)
                VALUES
                  (SYSDATE,
                   'p_circi_FORMULA_add@@' || V_C_DPT_CDE,
                   V_TOTAL || '=' || V_SUM,
                   N_TOTAL - N_SUM,
                   TO_CHAR(N_TOTAL) || '<>' || TO_CHAR(N_SUM));
                UPDATE IFACE_MEASURE
                   SET AMOUNT = N_SUM
                 WHERE UNITCODE = V_C_DPT_CDE
                   AND MEASURECODE = V_TOTAL;
              END IF;
            ELSE
              IF N_TOTAL <> N_SUM THEN
                INSERT INTO T_ERROR_MSG
                  (OCCTIME, PROCNAME, INPARM, N_SQLCODE, S_SQLERRM)
                VALUES
                  (SYSDATE,
                   'p_circi_FORMULA_add--' || V_C_DPT_CDE,
                   V_TOTAL || '=' || V_SUM,
                   N_TOTAL - N_SUM,
                   TO_CHAR(N_TOTAL) || '<>' || TO_CHAR(N_SUM));
              END IF;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              INSERT INTO T_ERROR_MSG
                (OCCTIME, PROCNAME, INPARM)
              VALUES
                (SYSDATE,
                 'p_circi_FORMULA_add:cur_formula',
                 V_FORMULA.C_FORMULA);
          END;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          INSERT INTO T_ERROR_MSG
            (OCCTIME, PROCNAME, INPARM)
          VALUES
            (SYSDATE,
             'p_circi_FORMULA_add:cur_MEASURECODE',
             V_MEASURE.MEASURECODE || ':' || V_MEASURE.UNITCODE);
      END;
    END LOOP;
    COMMIT;
  END;

END RPT_IFACE_OPTIMIZE;
/
