CREATE package p_fin_pay is

  procedure P_fin_pay_amt(v_today varchar2, v_cal_type in char, v_return out varchar2);
  procedure P_fin_pay_report(v_today varchar2, v_cal_type in char, v_return out varchar2);
  --再保后已决赔付率
  procedure P_fin_bac_pay_amt(v_today varchar2, v_cal_type in char, v_return out varchar2);
  procedure P_fin_bac_pay_report(v_today varchar2, v_cal_type in char, v_return out varchar2);
end p_fin_pay;
/
