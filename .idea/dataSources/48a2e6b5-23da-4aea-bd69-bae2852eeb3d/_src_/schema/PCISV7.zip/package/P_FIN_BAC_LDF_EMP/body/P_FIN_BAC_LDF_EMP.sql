CREATE package body P_FIN_BAC_LDF_EMP is

  v_err_content  web_bas_fin_errorlog.c_err_content%TYPE; --日志错误信息
  v_Sqlcode      Number;
  v_Sqlerrm      Varchar2(600);
  v_inwd_mrk     varchar2(10);
  v_srs_case_mrk varchar2(10);
  v_got_prm      number(20, 2);
  v_accnt_tm     date;
  v_insrc_cde    Varchar2(10);
  v_dpt_cde      Varchar2(10);
  v_kind_no      Varchar2(10);
  v_prod_no      Varchar2(10);
  v_year         Varchar2(4);
  v_quart        Varchar2(2);
  v_bgn_tm       date;
  v_end_tm       date;
  v_start_tm     date;
  v_over_tm      date;
  v_upd_col      varchar2(1000);
  v_upd_col2     varchar2(10);
  v_col_tmp      number;
  v_sql          varchar2(1000);
  v_sql2         varchar2(1000);
  v_flg          char(1);
  j              number(10);
  i              number(10);
  v_begin_year   varchar2(4);
  v_begin_quart  varchar2(4);
  v_000          number(20, 2);
  v_001          number(20, 2);
  v_002          number(20, 2);
  v_003          number(20, 2);
  v_004          number(20, 2);
  v_005          number(20, 2);
  v_006          number(20, 2);
  v_007          number(20, 2);
  v_008          number(20, 2);
  v_009          number(20, 2);
  v_010          number(20, 2);
  v_011          number(20, 2);
  v_012          number(20, 2);
  v_013          number(20, 2);
  v_014          number(20, 2);
  v_015          number(20, 2);
  v_016          number(20, 2);
  v_017          number(20, 2);
  v_018          number(20, 2);
  v_019          number(20, 2);
  v_020          number(20, 2);
  v_021          number(20, 2);
  v_022          number(20, 2);
  v_023          number(20, 2);
  v_024          number(20, 2);
  v_025          number(20, 2);
  v_026          number(20, 2);
  v_027          number(20, 2);
  v_028          number(20, 2);
  v_029          number(20, 2);
  v_030          number(20, 2);
  v_031          number(20, 2);
  v_032          number(20, 2);
  v_033          number(20, 2);
  v_034          number(20, 2);
  v_035          number(20, 2);
  v_036          number(20, 2);
  v_037          number(20, 2);
  v_038          number(20, 2);
  v_039          number(20, 2);
  v_040          number(20, 2);
  v_041          number(20, 2);
  v_042          number(20, 2);
  v_043          number(20, 2);
  v_044          number(20, 2);
  v_045          number(20, 2);
  v_046          number(20, 2);
  v_047          number(20, 2);
  v_048          number(20, 2);
  v_049          number(20, 2);
  v_050          number(20, 2);
  v_051          number(20, 2);
  v_052          number(20, 2);
  v_053          number(20, 2);
  v_054          number(20, 2);
  v_055          number(20, 2);
  v_056          number(20, 2);
  v_057          number(20, 2);
  v_058          number(20, 2);
  v_059          number(20, 2);
  v_060          number(20, 2);
  v_061          number(20, 2);
  v_062          number(20, 2);
  v_063          number(20, 2);
  v_064          number(20, 2);
  v_065          number(20, 2);
  v_066          number(20, 2);
  v_067          number(20, 2);
  v_068          number(20, 2);
  v_069          number(20, 2);
  v_070          number(20, 2);
  v_071          number(20, 2);
  v_072          number(20, 2);
  v_ldf_000      number(20, 2);
  v_ldf_001      number(20, 2);
  v_ldf_002      number(20, 2);
  v_ldf_003      number(20, 2);
  v_ldf_004      number(20, 2);
  v_ldf_005      number(20, 2);
  v_ldf_006      number(20, 2);
  v_ldf_007      number(20, 2);
  v_ldf_008      number(20, 2);
  v_ldf_009      number(20, 2);
  v_ldf_010      number(20, 2);
  v_ldf_011      number(20, 2);
  v_ldf_012      number(20, 2);
  v_ldf_013      number(20, 2);
  v_ldf_014      number(20, 2);
  v_ldf_015      number(20, 2);
  v_ldf_016      number(20, 2);
  v_ldf_017      number(20, 2);
  v_ldf_018      number(20, 2);
  v_ldf_019      number(20, 2);
  v_ldf_020      number(20, 2);
  v_ldf_021      number(20, 2);
  v_ldf_022      number(20, 2);
  v_ldf_023      number(20, 2);
  v_ldf_024      number(20, 2);
  v_ldf_025      number(20, 2);
  v_ldf_026      number(20, 2);
  v_ldf_027      number(20, 2);
  v_ldf_028      number(20, 2);
  v_ldf_029      number(20, 2);
  v_ldf_030      number(20, 2);
  v_ldf_031      number(20, 2);
  v_ldf_032      number(20, 2);
  v_ldf_033      number(20, 2);
  v_ldf_034      number(20, 2);
  v_ldf_035      number(20, 2);
  v_ldf_036      number(20, 2);
  v_ldf_037      number(20, 2);
  v_ldf_038      number(20, 2);
  v_ldf_039      number(20, 2);
  v_ldf_040      number(20, 2);
  v_ldf_041      number(20, 2);
  v_ldf_042      number(20, 2);
  v_ldf_043      number(20, 2);
  v_ldf_044      number(20, 2);
  v_ldf_045      number(20, 2);
  v_ldf_046      number(20, 2);
  v_ldf_047      number(20, 2);
  v_ldf_048      number(20, 2);
  v_ldf_049      number(20, 2);
  v_ldf_050      number(20, 2);
  v_ldf_051      number(20, 2);
  v_ldf_052      number(20, 2);
  v_ldf_053      number(20, 2);
  v_ldf_054      number(20, 2);
  v_ldf_055      number(20, 2);
  v_ldf_056      number(20, 2);
  v_ldf_057      number(20, 2);
  v_ldf_058      number(20, 2);
  v_ldf_059      number(20, 2);
  v_ldf_060      number(20, 2);
  v_ldf_061      number(20, 2);
  v_ldf_062      number(20, 2);
  v_ldf_063      number(20, 2);
  v_ldf_064      number(20, 2);
  v_ldf_065      number(20, 2);
  v_ldf_066      number(20, 2);
  v_ldf_067      number(20, 2);
  v_ldf_068      number(20, 2);
  v_ldf_069      number(20, 2);
  v_ldf_070      number(20, 2);
  v_ldf_071      number(20, 2);
  v_ldf_072      number(20, 2);

  v_clm_amt1 number(20, 6);
  v_clm_amt2 number(20, 6);
  emp_elv1   number(30, 6);
  emp_elv2   number(30, 6);

  today   date;
  v_today date;

  v_pk_id      varchar2(50);
  v_count      number;
  v_default_tm date := to_date('2011-04-01', 'yyyy-mm-dd'); --默认值

  --季度已决进展因子(基于已决原始加权平均法)
  procedure P_Fin_bac_Amt_Ldf_OWS(v_today1   varchar2,
                                  v_cal_type in char,
                                  v_return   out varchar2) is
  
    cursor cur_clm is
      select distinct a.c_kind_no as c_kind_no, a.c_prod_no as c_prod_no
        from web_fin_bac_amt a
       where trunc(a.t_cal_tm) = trunc(v_today);
  
  begin
    v_return := 1;
    v_today  := to_date(v_today1, 'yyyy-mm-dd');
    delete from WEB_FIN_BAC_LDF_EMP a
     where C_MRK = '1'
       and c_flg = '1'
       and C_TYPE = '1'
       and a.t_cal_tm = v_today;
    commit;
  
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
    
      --dz_proc.get_fin_no(v_pk_id,'800010','88','01');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_pk_id)
      VALUES
        (v_today, V_KIND_NO, v_prod_no, SYSDATE, '1', '1', '1', v_pk_id);
    
      for v_col in 1 .. 24 loop
        --v_bgn_tm:=TRUNC(ADD_MONTHS(v_start_tm,v_col-j), 'Q' );
      
        v_bgn_tm := add_months(trunc(v_today, 'MM'), -v_col);
        v_year   := to_char(v_bgn_tm, 'yyyy');
        v_quart  := to_char(v_bgn_tm, 'MM');
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
        v_col_tmp := v_col - 1;
        if v_col_tmp <= 9 then
          v_upd_col2 := '0' || v_col_tmp;
        else
          v_upd_col2 := v_col_tmp;
        end if;
        --v_upd_col和v_upd_col2的行数应相同,即v_upd_col2行数-1=v_upd_col行数
        v_sql := 'SELECT  SUM(N_0' || v_upd_col2 || '),SUM(N_0' ||
                 v_upd_col || ') FROM web_fin_bac_amt ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(v_today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        V_SQL := V_SQL || ' AND C_YEAR<=''' || V_YEAR || '''';
        V_SQL := V_SQL || ' AND C_QUART<= ( CASE WHEN C_YEAR=''' || V_YEAR ||
                 ''' THEN ''' || V_QUART || '''';
        V_SQL := V_SQL || ' ELSE ''12'' END)';
      
        EXECUTE IMMEDIATE v_sql
          INTO v_clm_amt1, v_clm_amt2;
      
        emp_elv1 := case
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) <> 0 then
                       9999
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) = 0 then
                       1
                      else
                       v_clm_amt2 / v_clm_amt1
                    end;
        --更新进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET N_0' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        
        v_sql2:=v_sql2||' AND C_MRK = ''1'' AND c_flg = ''1'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''1''';*/
        /*v_sql2:='INSERT INTO web_fin_bac_amt_LAST_LDF(C_YEAR,C_QUART,C_KIND_NO,C_PROD_NO,N_0'||v_upd_col||'';
        V_SQL2:=V_SQL2||') VALUES('''||V_YEAR||''','''||V_QUART||''','''||V_KIND_NO||''','''||V_PROD_NO||''','||emp_elv1||')';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
  
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_bac_Amt_Ldf_OWS],出错流水号:[' || v_today ||
                       '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_bac_Amt_Ldf_OWS;

  --季度已报进展因子(基于已报原始加权平均法)
  procedure P_Fin_Bac_Report_Ldf_OWS(v_today1   varchar2,
                                     v_cal_type in char,
                                     v_return   out varchar2) is
    cursor cur_clm is
      select distinct a.c_kind_no as c_kind_no, a.c_prod_no as c_prod_no
        from WEB_FIN_BAC_REPORT a
       where trunc(a.t_cal_tm) = trunc(v_today);
  
  begin
    v_return := 1;
    v_today  := to_date(v_today1, 'yyyy-mm-dd');
    delete from WEB_FIN_BAC_LDF_EMP a
     where C_MRK = '1'
       and c_flg = '1'
       and C_TYPE = '2'
       and a.t_cal_tm = v_today;
    commit;
   
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
      --dz_proc.get_fin_no(v_pk_id,'800020','88','02');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_pk_id)
      VALUES
        (v_today, V_KIND_NO, v_prod_no, SYSDATE, '1', '1', '2', v_pk_id);
    
      for v_col in 1 .. 24 loop
        --v_bgn_tm:=TRUNC(ADD_MONTHS(v_start_tm,v_col-j), 'Q' );
        v_bgn_tm := add_months(trunc(v_today, 'MM'), -v_col);
        v_year   := to_char(v_bgn_tm, 'yyyy');
        v_quart  := to_char(v_bgn_tm, 'MM');
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
        v_col_tmp := v_col - 1;
        if v_col_tmp <= 9 then
          v_upd_col2 := '0' || v_col_tmp;
        else
          v_upd_col2 := v_col_tmp;
        end if;
      
        v_sql := 'SELECT  SUM(N_0' || v_upd_col2 || '),SUM(N_0' ||
                 v_upd_col || ') FROM WEB_FIN_BAC_REPORT ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(v_today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        V_SQL := V_SQL || ' AND C_YEAR<=''' || V_YEAR || '''';
        V_SQL := V_SQL || ' AND C_QUART<= ( CASE WHEN C_YEAR=''' || V_YEAR ||
                 ''' THEN ''' || V_QUART || '''';
        V_SQL := V_SQL || ' ELSE ''12'' END)';
      
        EXECUTE IMMEDIATE v_sql
          INTO v_clm_amt1, v_clm_amt2;
      
        emp_elv1 := case
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) <> 0 then
                       9999
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) = 0 then
                       1
                      else
                       v_clm_amt2 / v_clm_amt1
                    end;
        --更新进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET N_0' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        v_sql2:=v_sql2||' AND C_MRK = ''1'' AND c_flg = ''1'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''2''';*/
        /*v_sql2:='INSERT INTO web_fin_bac_amt_LAST_LDF(C_YEAR,C_QUART,C_KIND_NO,C_PROD_NO,N_0'||v_upd_col||'';
        V_SQL2:=V_SQL2||') VALUES('''||V_YEAR||''','''||V_QUART||''','''||V_KIND_NO||''','''||V_PROD_NO||''','||emp_elv1||')';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
  
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_Bac_Report_Ldf_OWS],出错流水号:[' || v_today ||
                       '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_Bac_Report_Ldf_OWS;

  --季度已决进展因子(基于已决简单算术平均法)
  procedure P_Fin_bac_Amt_Ldf_SA(v_today1   varchar2,
                                 v_cal_type in char,
                                 v_return   out varchar2) is
  
    cursor cur_clm is
      select distinct a.c_kind_no as c_kind_no, a.c_prod_no as c_prod_no
        from WEB_FIN_bac_LDF a
       where a.c_type = '1'
         and a.c_mrk = '2'
         and trunc(a.t_cal_tm) = trunc(v_today);
  
  begin
    v_return := 1;
    v_today  := to_date(v_today1, 'yyyy-mm-dd');
    delete from WEB_FIN_BAC_LDF_EMP a
     where C_MRK = '1'
       and c_flg = '2'
       and C_TYPE = '1'
       and a.t_cal_tm = v_today;
    commit;
  
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
    
      --dz_proc.get_fin_no(v_pk_id,'800030','88','03');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_pk_id)
      VALUES
        (v_today, V_KIND_NO, v_prod_no, SYSDATE, '1', '2', '1', v_pk_id);
    
      for v_col in 1 .. 24 loop
        --向前推-v_col*3和月
        v_bgn_tm := add_months(trunc(v_today, 'MM'), -v_col);
        v_year   := to_char(v_bgn_tm, 'yyyy');
        v_quart  := to_char(v_bgn_tm, 'MM');
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
      
        v_upd_col := 'N_0' || v_upd_col;
      
        v_sql := 'SELECT  SUM( case when nvl(' || v_upd_col ||
                 ',1)=0 then 0 when ' || v_upd_col ||
                 ' = 9999 then 0  else ' || v_upd_col || ' end) ,count(1) ';
        v_sql := v_sql || ' FROM WEB_FIN_bac_LDF ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(v_today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        V_SQL := V_SQL || ' AND C_YEAR<=''' || V_YEAR || '''';
        V_SQL := V_SQL || ' AND C_QUART<= ( CASE WHEN C_YEAR=''' || V_YEAR ||
                 ''' THEN ''' || V_QUART || '''';
        V_SQL := V_SQL || ' ELSE ''12'' END)';
        V_SQL := V_SQl || ' AND C_TYPE = ''1'' ';
        --v_sql := v_sql || ' and ' || v_upd_col || ' <> 9999 '; --add 2012-11-15
        --v_sql := v_sql || ' and ' || v_upd_col || ' <> 0 ';
      
        EXECUTE IMMEDIATE v_sql
          INTO v_clm_amt1, v_count;
      
        --emp_elv1:=case when v_clm_amt1 is null or v_clm_amt1 =0 then 0 else v_clm_amt1/(J-v_col+1) end;
        emp_elv1 := case
                      when v_clm_amt1 is null or v_clm_amt1 = 0 then
                       1
                      else
                       v_clm_amt1 / v_count
                    end;
        --更新进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET ' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        v_sql2:=v_sql2||' AND C_MRK = ''1'' AND c_flg = ''2'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''1''';*/
        /*v_sql2:='INSERT INTO web_fin_bac_amt_LAST_LDF(C_YEAR,C_QUART,C_KIND_NO,C_PROD_NO,N_0'||v_upd_col||'';
        V_SQL2:=V_SQL2||') VALUES('''||V_YEAR||''','''||V_QUART||''','''||V_KIND_NO||''','''||V_PROD_NO||''','||emp_elv1||')';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
  
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_bac_Amt_Ldf_SA],出错流水号:[' || v_today ||
                       '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_bac_Amt_Ldf_SA;

  --季度已报进展因子(基于已报简单算术平均法)
  procedure P_Fin_bac_Report_Ldf_SA(v_today1   varchar2,
                                    v_cal_type in char,
                                    v_return   out varchar2) is
    cursor cur_clm is
      select distinct a.c_kind_no as c_kind_no, a.c_prod_no as c_prod_no
        from WEB_FIN_bac_LDF a
       where a.c_type = '2'
         and a.c_mrk = '2'
         and trunc(a.t_cal_tm) = trunc(v_today);
  
  begin
    v_return := 1;
    v_today  := to_date(v_today1, 'yyyy-mm-dd');
    delete from WEB_FIN_BAC_LDF_EMP a
     where C_MRK = '1'
       and c_flg = '2'
       and C_TYPE = '2'
       and a.t_cal_tm = v_today;
    commit;
    
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
    
      --dz_proc.get_fin_no(v_pk_id,'800040','88','04');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_pk_id)
      VALUES
        (v_today, V_KIND_NO, v_prod_no, SYSDATE, '1', '2', '2', v_pk_id);
    
      for v_col in 1 .. 24 loop
        --v_bgn_tm:=TRUNC(ADD_MONTHS(v_start_tm,v_col-j), 'Q' );
        v_bgn_tm := add_months(trunc(v_today, 'MM'), -v_col);
        v_year   := to_char(v_bgn_tm, 'yyyy');
        v_quart  := to_char(v_bgn_tm, 'MM');
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
      
        v_upd_col := 'N_0' || v_upd_col;
      
        v_sql := 'SELECT  SUM( case when nvl(' || v_upd_col ||
                 ',1)=0 then 0 when ' || v_upd_col ||
                 ' = 9999 then 0  else ' || v_upd_col || ' end) ,count(1) ';
        v_sql := v_sql || ' FROM WEB_FIN_bac_LDF ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(v_today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        V_SQL := V_SQL || ' AND C_YEAR<=''' || V_YEAR || '''';
        V_SQL := V_SQL || ' AND C_QUART<= ( CASE WHEN C_YEAR=''' || V_YEAR ||
                 ''' THEN ''' || V_QUART || '''';
        V_SQL := V_SQL || ' ELSE ''12'' END)';
        V_SQL := V_SQl || ' AND C_type = ''2'' ';
        -- v_sql := v_sql || ' and ' || v_upd_col || ' <> 9999 '; --add 2012-11-15
        -- v_sql := v_sql || ' and ' || v_upd_col || ' <> 0 ';
      
        EXECUTE IMMEDIATE v_sql
          INTO v_clm_amt1, v_count;
      
        --emp_elv1:=case when v_clm_amt1 is null or v_clm_amt1 =0 then 0 else v_clm_amt1/(J-v_col+1) end;
        emp_elv1 := case
                      when v_clm_amt1 is null or v_clm_amt1 = 0 then
                       1
                      else
                       v_clm_amt1 / v_count
                    end;
      
        --更新进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET ' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        v_sql2:=v_sql2||' AND C_MRK = ''1'' AND c_flg = ''2'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''2''';*/
        /*v_sql2:='INSERT INTO web_fin_bac_amt_LAST_LDF(C_YEAR,C_QUART,C_KIND_NO,C_PROD_NO,N_0'||v_upd_col||'';
        V_SQL2:=V_SQL2||') VALUES('''||V_YEAR||''','''||V_QUART||''','''||V_KIND_NO||''','''||V_PROD_NO||''','||emp_elv1||')';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
  
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_bac_Report_Ldf_SA],出错流水号:[' || v_today ||
                       '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_bac_Report_Ldf_SA;

  -- 基于已决最近两个事故年的原始加权平均法
  procedure P_Fin_bac_Amt_Ldf_TOWYEAR(v_today1   varchar2,
                                      v_cal_type in char,
                                      v_return   out varchar2) is
  
    cursor cur_clm is
      select distinct a.c_kind_no as c_kind_no, a.c_prod_no as c_prod_no
        from web_fin_bac_amt a
       where trunc(a.t_cal_tm) = trunc(v_today)
      /*and a.c_kind_no = '01'*/
      ;
  
  begin
    v_return := 1;
    v_today  := to_date(v_today1, 'yyyy-mm-dd');
    delete from WEB_FIN_BAC_LDF_EMP a
     where C_MRK = '1'
       and c_flg = '3'
       and C_TYPE = '1'
       and a.t_cal_tm = v_today;
    commit;
  
  
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
    
      --dz_proc.get_fin_no(v_pk_id,'800050','88','05');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_pk_id)
      VALUES
        (v_today, V_KIND_NO, v_prod_no, SYSDATE, '1', '3', '1', v_pk_id);
      --若评估日与默认起期超过2年,则前面进展因子补1
      /*if i >= 1 then
        for v_col in 1 .. i loop
          if v_col <= 9 then
            v_upd_col := '0' || v_col;
          else
            v_upd_col := v_col;
          end if;
          v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
          v_sql2 := v_sql2 || ' SET N_0' || v_upd_col || '';
          v_sql2 := v_sql2 || ' = 1 ';
          v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
          \*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
          v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
          v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
          v_sql2:=v_sql2||' AND C_MRK = ''1'' AND c_flg = ''3''  AND C_TYPE = ''1''';*\
          EXECUTE IMMEDIATE V_SQL2;
        end loop;
      end if;*/
    
      for v_col in 1..24 loop
        --v_bgn_tm:=TRUNC(ADD_MONTHS(v_start_tm,v_col-j), 'Q' );
        v_bgn_tm := add_months(trunc(v_today, 'MM'), -v_col);
        
        v_year   := to_char(v_bgn_tm, 'yyyy');
        v_quart := to_char(v_bgn_tm, 'MM');
      
      
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
        v_col_tmp := v_col - 1;
        if v_col_tmp <= 9 then
          v_upd_col2 := '0' || v_col_tmp;
        else
          v_upd_col2 := v_col_tmp;
        end if;
      
        --v_upd_col和v_upd_col2的行数应相同,即v_upd_col2行数-1=v_upd_col行数
        v_sql := 'SELECT  SUM(N_0' || v_upd_col2 || '),SUM(N_0' ||
                 v_upd_col || ') FROM web_fin_bac_amt ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(v_today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        V_SQL := V_SQL || ' AND C_YEAR<=''' || V_YEAR || '''';
        V_SQL := V_SQL || ' AND C_QUART<= ( CASE WHEN C_YEAR=''' || V_YEAR ||
                 ''' THEN ''' || V_QUART || '''';
        V_SQL := V_SQL || ' ELSE ''12'' END)';
        V_SQL := V_SQL || ' AND C_YEAR||c_quart>''' || v_begin_year ||
                 v_begin_quart || '''';
      
        EXECUTE IMMEDIATE v_sql
          INTO v_clm_amt1, v_clm_amt2;
      
        emp_elv1 := case
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) <> 0 then
                       9999
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) = 0 then
                       1
                      else
                       v_clm_amt2 / v_clm_amt1
                    end;
        if emp_elv1 is null then
          emp_elv1 := 1;
        end if;
        --更新进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET N_0' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        
        v_sql2:=v_sql2||' AND C_MRK = ''1'' AND c_flg = ''3'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''1''';*/
        /*v_sql2:='INSERT INTO web_fin_bac_amt_LAST_LDF(C_YEAR,C_QUART,C_KIND_NO,C_PROD_NO,N_0'||v_upd_col||'';
        V_SQL2:=V_SQL2||') VALUES('''||V_YEAR||''','''||V_QUART||''','''||V_KIND_NO||''','''||V_PROD_NO||''','||emp_elv1||')';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
  
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_bac_Amt_Ldf_TOWYEAR],出错流水号:[' ||
                       v_today || '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_bac_Amt_Ldf_TOWYEAR;

  -- 基于已报最近两个事故年的原始加权平均法
  procedure P_Fin_bac_Report_Ldf_TOWYEAR(v_today1   varchar2,
                                         v_cal_type in char,
                                         v_return   out varchar2) is
  
    cursor cur_clm is
      select distinct a.c_kind_no as c_kind_no, a.c_prod_no as c_prod_no
        from WEB_FIN_BAC_REPORT a
       where trunc(a.t_cal_tm) = trunc(v_today);
  
  begin
    v_return := 1;
    v_today  := to_date(v_today1, 'yyyy-mm-dd');
    v_start_tm := add_months(v_today,-24);
    v_begin_year := to_char(v_start_tm,'YYYY');
    v_begin_quart := to_char(v_start_tm,'MM');
    delete from WEB_FIN_BAC_LDF_EMP a
     where C_MRK = '1'
       and c_flg = '3'
       and C_TYPE = '2'
       and a.t_cal_tm = v_today;
    commit;
   
  
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
    
      --dz_proc.get_fin_no(v_pk_id,'800060','88','07');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_pk_id)
      VALUES
        (v_today, V_KIND_NO, v_prod_no, SYSDATE, '1', '3', '2', v_pk_id);
    
      for v_col in 1..24 loop
        --v_bgn_tm:=TRUNC(ADD_MONTHS(v_start_tm,v_col-j), 'Q' );
        v_bgn_tm := add_months(trunc(v_today, 'MM'), -v_col);
       
        v_year   := to_char(v_bgn_tm, 'yyyy');
        v_quart  := to_char(v_bgn_tm, 'MM');
      
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
        v_col_tmp := v_col - 1;
        if v_col_tmp <= 9 then
          v_upd_col2 := '0' || v_col_tmp;
        else
          v_upd_col2 := v_col_tmp;
        end if;
      
        v_sql := 'SELECT  SUM(N_0' || v_upd_col2 || '),SUM(N_0' ||
                 v_upd_col || ') FROM WEB_FIN_BAC_REPORT ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(v_today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        V_SQL := V_SQL || ' AND C_YEAR<=''' || V_YEAR || '''';
        V_SQL := V_SQL || ' AND C_QUART<= ( CASE WHEN C_YEAR=''' || V_YEAR ||
                 ''' THEN ''' || V_QUART || '''';
        V_SQL := V_SQL || ' ELSE ''12'' END)';
        V_SQL := V_SQL || ' AND C_YEAR||c_quart>''' || v_begin_year ||
                 v_begin_quart || '''';
      
        EXECUTE IMMEDIATE v_sql
          INTO v_clm_amt1, v_clm_amt2;
      
        emp_elv1 := case
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) <> 0 then
                       9999
                      when nvl(v_clm_amt1, 0) = 0 and nvl(v_clm_amt2, 0) = 0 then
                       1
                      else
                       v_clm_amt2 / v_clm_amt1
                    end;
        if emp_elv1 is null then
          emp_elv1 := 1;
        end if;
        --更新进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET N_0' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(v_today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        
        v_sql2:=v_sql2||' AND C_MRK = ''1'' AND c_flg = ''3'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''2''';*/
        /*v_sql2:='INSERT INTO web_fin_bac_amt_LAST_LDF(C_YEAR,C_QUART,C_KIND_NO,C_PROD_NO,N_0'||v_upd_col||'';
        V_SQL2:=V_SQL2||') VALUES('''||V_YEAR||''','''||V_QUART||''','''||V_KIND_NO||''','''||V_PROD_NO||''','||emp_elv1||')';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
  
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_bac_Report_Ldf_TOWYEAR],出错流水号:[' ||
                       v_today || '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_bac_Report_Ldf_TOWYEAR;

  --基于已决累计进展因子
  procedure P_Fin_bac_Amt_Ldf_EMP(v_today    varchar2,
                                  v_cal_type in char,
                                  v_lt_bf    in varchar2,
                                  v_return   out varchar2)
  --v_cal_type 1:原始加权平均法,2:简单算术平均法,3:最近两个事故原始加权平均法,4:手动录入进展因子
   is
    cursor cur_clm is
      select distinct a.c_kind_no, a.c_prod_no
        from WEB_FIN_BAC_LDF_EMP a
       where a.c_flg = v_cal_type
            --and a.C_TOTAL_MRK = '2'  --按季度
         and C_TYPE = '1' --基于已决
         and C_MRK = '1' --进展因子
         AND NVL(A.C_LT_BF, '3') = v_lt_bf
         and trunc(a.t_cal_tm) = to_date(v_today, 'yyyy-mm-dd');
  begin
    v_return := 1;
    if v_today = '' or v_today is null then
      today := trunc(last_day(add_months(last_day(sysdate) + 1, -2)));
    else
      today := to_date(v_today, 'yyyy-mm-dd');
    end if;
    DELETE FROM WEB_FIN_BAC_LDF_EMP A
     WHERE C_MRK = '2'
       AND C_TYPE = '1'
       AND c_flg = v_cal_type
       AND trunc(t_cal_tm) = today
       and nvl(c_lt_bf, '3') = v_lt_bf;
    /* v_sql:='delete from WEB_FIN_BAC_LDF_EMP a where C_MRK = ''2'' and C_TOTAL_MRK = ''2'' and C_TYPE = ''1'' ';
    v_sql:=v_sql||' and c_flg = ''' || v_cal_type ||''' and  to_char(t_cal_tm,''yyyymmdd'') = '''||to_char(today,'yyyymmdd')||'''';
    v_sql:=v_sql||' AND c_lt_bf='''||v_lt_bf||'''';
    EXECUTE IMMEDIATE v_sql;*/
    commit;
    V_FLG := v_cal_type;
    --取评估日季度的最后一个月
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
      --v_flg:=  v_cur.c_flg;
    
      --dz_proc.get_fin_no(v_pk_id,'800070','88','07');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_pk_id,c_lt_bf)
      VALUES
        (today, V_KIND_NO, v_prod_no, SYSDATE, '2', v_flg, '1', v_pk_id,v_lt_bf);
    
      for v_col in 1 .. 24 loop
        v_upd_col := '1';
        --拼装需查询的字段,并计算进展因子
        for v_col_tmp in v_col .. 24 loop
          if v_col_tmp <= 9 then
            v_upd_col := v_upd_col || '*N_00' || v_col_tmp;
          else
            v_upd_col := v_upd_col || '*N_0' || v_col_tmp;
          end if;
        end loop;
      
        v_sql := 'SELECT  ' || v_upd_col || ' FROM WEB_FIN_BAC_LDF_EMP ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        v_sql := v_sql || ' AND C_FLG=''' || V_FLG || '''';
        v_sql := v_sql || ' AND C_TYPE = ''1'' AND C_MRK = ''1'' ';
        v_sql := v_sql || ' AND  NVL(c_lt_bf,''3'')=''' || v_lt_bf || '''';
      
        EXECUTE IMMEDIATE v_sql
          INTO emp_elv1;
      
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
        --更新累计进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET N_0' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        v_sql2:=v_sql2||' AND C_FLG='''||V_FLG||''' AND C_TOTAL_MRK = ''2'' ';
        v_sql2:=v_sql2||' AND C_MRK = ''2'' AND C_TYPE = ''1''';
        v_sql2:=v_sql2||' AND  NVL(c_lt_bf,''3'')='''||v_lt_bf||'''';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_bac_Amt_Ldf_EMP],出错流水号:[' || today ||
                       '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_bac_Amt_Ldf_EMP;

  --基于已决累计进展因子
  procedure P_Fin_bac_Report_Ldf_EMP(v_today    varchar2,
                                     v_cal_type in char,
                                     v_lt_bf    in varchar2,
                                     v_return   out varchar2)
  ----v_cal_type 1:原始加权平均法,2:简单算术平均法,3:最近两个事故原始加权平均法,4:手动录入进展因子
   is
    cursor cur_clm is
      select distinct a.c_kind_no, a.c_prod_no
        from WEB_FIN_BAC_LDF_EMP a
       where a.c_flg = v_cal_type --手动录入
            --and a.C_TOTAL_MRK = '2'  --按季度
         and C_TYPE = '2' --基于已报
         and C_MRK = '1' --进展因子
         AND NVL(A.C_LT_BF, '3') = v_lt_bf
         and trunc(a.t_cal_tm) = to_date(v_today, 'yyyy-mm-dd');
  begin
  
    if v_today = '' or v_today is null then
      today := trunc(last_day(add_months(last_day(sysdate) + 1, -2)));
    else
      today := to_date(v_today, 'yyyy-mm-dd');
    end if;
  
    v_return := 1;
    DELETE FROM WEB_FIN_BAC_LDF_EMP A
     WHERE C_MRK = '2'
       AND C_TYPE = '2'
       AND c_flg = v_cal_type
       AND trunc(t_cal_tm) = today
       and nvl(c_lt_bf, '3') = v_lt_bf;
    /*v_sql:='delete from WEB_FIN_BAC_LDF_EMP a where C_MRK = ''2'' and C_TOTAL_MRK = ''2'' and C_TYPE = ''2'' ';
    v_sql:=v_sql||' and c_flg = ''' || v_cal_type ||''' and  to_char(t_cal_tm,''yyyymmdd'') = '''||to_char(today,'yyyymmdd')||'''';
    v_sql:=v_sql||' AND c_lt_bf='''||v_lt_bf||'''';
    
    EXECUTE IMMEDIATE v_sql;*/
    commit;
    V_FLG := v_cal_type;
    
    for v_cur in cur_clm loop
      V_KIND_NO := v_cur.c_kind_no;
      v_prod_no := v_cur.c_prod_no;
      --v_flg:=  v_cur.c_flg;
      --dz_proc.get_fin_no(v_pk_id,'800080','88','08');
      V_PK_ID := sys_guid();
    
      INSERT INTO WEB_FIN_BAC_LDF_EMP
        (T_CAL_TM,
         C_KIND_NO,
         C_PROD_NO,
         T_CRT_TM,
         C_MRK,
         c_flg,
         C_TYPE,
         c_Pk_Id,c_lt_bf)
      VALUES
        (today, V_KIND_NO, v_prod_no, SYSDATE, '2', v_flg, '2', v_pk_id,v_lt_bf);
    
      for v_col in 1 .. 24 loop
        v_upd_col := '1';
      
        --拼装需查询的字段,并计算进展因子
        for v_col_tmp in v_col .. 24 loop
          if v_col_tmp <= 9 then
            v_upd_col := v_upd_col || '*N_00' || v_col_tmp;
          else
            v_upd_col := v_upd_col || '*N_0' || v_col_tmp;
          end if;
        end loop;
      
        v_sql := 'SELECT  ' || v_upd_col || ' FROM WEB_FIN_BAC_LDF_EMP ';
        v_sql := v_sql || ' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')=''' ||
                 to_char(today, 'yyyy-mm-dd') || '''';
        v_sql := v_sql || ' AND C_KIND_NO=''' || V_KIND_NO ||
                 ''' AND C_PROD_NO=''' || V_PROD_NO || '''';
        v_sql := v_sql || ' AND C_FLG=''' || V_FLG || ''' ';
        v_sql := v_sql || ' AND C_TYPE = ''2'' AND C_MRK = ''1'' ';
        v_sql := v_sql || ' AND  NVL(c_lt_bf,''3'')=''' || v_lt_bf || '''';
      
        EXECUTE IMMEDIATE v_sql
          INTO emp_elv1;
      
        if v_col <= 9 then
          v_upd_col := '0' || v_col;
        else
          v_upd_col := v_col;
        end if;
        --更新累计进展因子
        v_sql2 := ' UPDATE WEB_FIN_BAC_LDF_EMP ';
        v_sql2 := v_sql2 || ' SET N_0' || v_upd_col || '';
        v_sql2 := v_sql2 || ' = ' || emp_elv1;
        v_sql2 := v_sql2 || ' WHERE C_PK_ID=''' || V_PK_ID || '''';
        /*v_sql2:=v_sql2||' WHERE to_char(T_CAL_TM,''yyyy-mm-dd'')='''||to_char(today,'yyyy-mm-dd')||'''';
        v_sql2:=v_sql2||' AND C_KIND_NO = '''||V_KIND_NO||'''';
        v_sql2:=v_sql2||' AND C_PROD_NO = '''||V_PROD_NO||'''';
        
        v_sql2:=v_sql2||' AND C_FLG='''||V_FLG||''' AND C_TOTAL_MRK = ''2'' ';
        v_sql2:=v_sql2||' AND C_MRK = ''2'' AND C_TYPE = ''2''';
        v_sql2:=v_sql2||' AND  NVL(c_lt_bf,''3'')='''||v_lt_bf||'''';*/
      
        EXECUTE IMMEDIATE V_SQL2;
      
      end loop;
    end loop;
    commit;
  exception
    When Others Then
      Rollback;
      v_Sqlcode := Sqlcode;
      v_Sqlerrm := Substr(Sqlerrm, 1, 600);
      ROLLBACK;
    
      v_err_content := 'proc:[P_Fin_bac_Report_Ldf_EMP],出错流水号:[' || today ||
                       '],错误描述：[' || SQLCODE || SQLERRM;
      insert into web_bas_fin_errorlog
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        ('007', '001', '0000', v_err_content, SYSDATE);
      COMMIT;
      v_return := -1;
  end P_Fin_bac_Report_Ldf_EMP;

end P_FIN_BAC_LDF_EMP;
/
