CREATE PACKAGE "TEST" is

  -- Author  : HUSSEIN
  -- Created : 2009-7-15 8:34:53
  -- Purpose : test

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  PROCEDURE hello(C_SYSTEM_CDE IN WEB_FIN_SYSUSER.C_SYSTEM_CDE%type);

  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

end Test;










/
