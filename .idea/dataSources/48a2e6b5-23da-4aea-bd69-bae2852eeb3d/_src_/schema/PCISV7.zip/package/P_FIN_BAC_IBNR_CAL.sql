CREATE package P_FIN_BAC_IBNR_CAL is
  --赔付率法
  procedure P_Fin_BAC_CAL_PAY(v_today    varchar2,
                              v_cal_type in char,
                              v_return   out varchar2);
  --链锑法
  procedure P_Fin_BAC_CAL_LT(v_today    varchar2,
                             v_cal_type in char,
                             v_return   out varchar2);
  --BF法
  procedure P_Fin_BAC_CAL_BF(v_today    varchar2,
                             v_cal_type in char,
                             v_return   out varchar2);

end P_FIN_BAC_IBNR_CAL;
/
