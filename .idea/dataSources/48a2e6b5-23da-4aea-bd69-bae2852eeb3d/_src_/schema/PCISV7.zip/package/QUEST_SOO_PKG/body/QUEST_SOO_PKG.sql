CREATE PACKAGE BODY "QUEST_SOO_PKG" 
IS
   --
   -- This package contains routines used by Spotlight On Oracle
   --

   --
   -- These tables contain event names and categories
   --
   TYPE varchar_tab_typ IS TABLE OF VARCHAR2 (120)
      INDEX BY BINARY_INTEGER;

   TYPE number_tab_typ IS TABLE OF NUMBER
      INDEX BY BINARY_INTEGER;

   TYPE lock_type_typ IS TABLE OF VARCHAR2(64)
      INDEX BY VARCHAR2(64);

   event_indx_tab        varchar_tab_typ;
   event_name_tab        varchar_tab_typ;
   event_category_tab    varchar_tab_typ;
   lock_type_tab         lock_type_typ;
   g_event_count         NUMBER                        := 0;
   l_event_initialized   BOOLEAN                       := FALSE;

   --g_debug                  varchar2(1):='N';

   /* -------------------------------------------------------------------
|| All the declarations below relate to the locktree functionality
*/
   --------------------------------------------------------------------
-- This cursor gets the data from v$lock
   CURSOR c_lock
   IS
      SELECT   ROWNUM, SID, TYPE ltype, request, lmode,
               quest_soo_pkg.lock_type_decode (TYPE, id2) lock_type,
               quest_soo_pkg.lock_mode_decode (lmode) mode_held,
               quest_soo_pkg.lock_mode_decode (request) mode_requested, id1,
               id2, BLOCK blocking, DECODE (request, 0, 0, 1) blocked
          FROM v$lock
         WHERE request <> 0 OR BLOCK <> 2 /* Only want blocked or blocking */
      ORDER BY SID, blocking DESC, blocked DESC;

   --
   -- This cursor gets the data from v$lock
   -- I18N version
   --
   CURSOR c_lock_41
   IS
      SELECT   ROWNUM, SID, TYPE ltype, request, lmode,
               quest_soo_pkg.lock_type_decode_41 (TYPE, id2) lock_type,
               quest_soo_pkg.lock_mode_decode_41 (lmode) mode_held,
               quest_soo_pkg.lock_mode_decode_41 (request) mode_requested,
               id1, id2, BLOCK blocking, DECODE (request, 0, 0, 1) blocked
          FROM v$lock
         WHERE request <> 0 OR BLOCK <> 2 /* Only want blocked or blocking */
      ORDER BY SID, blocking DESC, blocked DESC;

   -- PL/SQL table stypes (array-types) to hold v$lock data
   TYPE vtabtype IS TABLE OF VARCHAR2 (200)
      INDEX BY BINARY_INTEGER;

   TYPE ntabtype IS TABLE OF NUMBER
      INDEX BY BINARY_INTEGER;

   SID                   ntabtype;           -- array of session identifiers.
   ltype                 vtabtype;                -- array of lock type codes
   request               ntabtype;                  -- array of request codes
   lock_type             vtabtype;                 -- array of lock type text
   mode_held             vtabtype;                 -- array of mode held text
   mode_requested        vtabtype;            -- array of mode requested text
   id1                   ntabtype;                            -- array of id1
   id2                   ntabtype;                            -- array of id2
   blocking              ntabtype;     -- array of 1= blocking 2=not blocking
   blocked               ntabtype;       -- array of 1=blocked 0= not blocked
   printed               ntabtype;      -- array of 1=entry has been printed.
   blocked_list          ntabtype;          -- List of sids which are blocked
   blocked_list_cnt      NUMBER                        := 0;
   blocking_list         ntabtype;         -- List of sids which are blocking
   blocking_list_cnt     NUMBER                        := 0;
   lock_count            NUMBER                        := 0;
   -- Limit on the above arrays.
   tree_depth            NUMBER                        := 0;
   -- Keep track of tree depth.
   tree_sequence         NUMBER                        := 0;
                                                       -- Sequence to display
/* -----------------------------------------------------------
** lock_hash_table implements a hash table on lock_type, id1
** These three values will be identical for users holding and wanting
** the same lock.  We hash lock_type, id1  to locate the first
** matching row.  The value of the row found is the index to
** sid, ltype, etc.    Subsequent rows will hold additional matching
** rows.
** A collision is pretty unlikely given the hashing scheme but is
** possible so each row returned needs to be validated - eg check
** lock_type, id1  to ensure they're what you think they should be.
**
** f_lock_hash generates a hash value
*/ -----------------------------------------------------------
   lock_hash_table       ntabtype;
/** -----------------------------------------------------------
**  This table contains pointers to entries with a given sid
**  The key is sid*10000
*/  -----------------------------------------------------------
   sid_hash_table        ntabtype;
   /*
   ** SOO_LOCKTREE receives the lock tree information
   */
   soo_locktree_row      quest_soo_lock_tree%ROWTYPE;
/* -----------------------------------------------------------------
** Full version of Oracle RDBMS.
** We just need to run the function dbversion once and
** save the result in this variable for other procedures/functions
*/ -----------------------------------------------------------------
   full_version          VARCHAR2 (20);

   /* ===========================================================
   || Some forward declarations
      =========================================================*/
   FUNCTION get_seg_name (p_fileno NUMBER, p_blockno NUMBER)
      RETURN VARCHAR2;

   PROCEDURE initialize_object_cache;

   FUNCTION dbversion
      RETURN VARCHAR2;

   PROCEDURE populate_lock_type;

/* -----------------------------------------------------------
|| Functions and procedure bodies start here
*/ -----------------------------------------------------------

   /* -------------------------------------
   || Format an SQL statement for the top sessions display
      -----------------------------------------------*/

   -- Function to format SQL text
   FUNCTION format_sql (p_sql_text IN VARCHAR2, p_max_len IN NUMBER := 256)
      RETURN VARCHAR2
   IS
      i               NUMBER          := 0;
      l_text_len      NUMBER          := 0;
      l_this_char     CHAR;
      l_last_char     CHAR;
      l_from_pos      NUMBER          := 0;
      l_dup_sp_pos    NUMBER          := 0;
      l_return_text   VARCHAR2 (2000);
   BEGIN
      -- Strip out blanks
      l_return_text := TRANSLATE (p_sql_text, CHR (10) || CHR (13), '  ');
      l_dup_sp_pos := INSTR (l_return_text, '  ');
      i := 1;

      WHILE (l_dup_sp_pos <> 0)
      LOOP
         l_return_text :=
               SUBSTR (l_return_text, 1, l_dup_sp_pos)
            || SUBSTR (l_return_text, l_dup_sp_pos + 2);
         l_dup_sp_pos := INSTR (l_return_text, '  ');
         i := i + 1;
         EXIT WHEN l_dup_sp_pos > 40;
      END LOOP;

      -- For selects, make sure the 'FROM' is visible
      IF UPPER (SUBSTR (p_sql_text, 1, 6)) = 'SELECT'
      THEN
         l_from_pos := INSTR (UPPER (l_return_text), 'FROM');

         IF l_from_pos > 40
         THEN
            l_return_text :=
                  SUBSTR (l_return_text, 1, 40)
               || ' ... '
               || SUBSTR (l_return_text, l_from_pos);
         END IF;
      END IF;

      RETURN SUBSTR (l_return_text, 1, p_max_len);
   END;

   /* ===================================
   || Print a debug message
   =====================================*/
   PROCEDURE DEBUG (in_string VARCHAR2)
   IS
   BEGIN
      IF g_debug = 1
      THEN
         DBMS_OUTPUT.put_line (in_string);
      END IF;
   END;

   /* ===============================================================
   || Function to set up the object cache which allows fast retrieval
   || of segment name from file/block segment header
      ==============================================================*/
   PROCEDURE initialize_object_cache
   IS
   /* CURSOR ioc_csr IS

    l_object_key  number;
    l_object_hash number;

    l_temp_key    number;*/
   BEGIN
      SELECT   file_id, extent_id,
               block_id, blocks,
               owner || '.' || segment_name segment_name
      BULK COLLECT INTO object_cache_fileno, object_cache_extno,
               object_cache_blockno, object_cache_length,
               object_cache_segname
          FROM SYS.dba_extents
      ORDER BY file_id, block_id;

      object_cache_count := object_cache_segname.COUNT;
      g_object_cache_initialized := 1;
   END;                                              -- intialize object_cache

/* -------------------------------------------------------------
|| A function to return a segment name given a file/block header address
|| This is faster than using DBA_SEGMENTS
*/ -------------------------------------------------------------
   FUNCTION get_seg_name (p_fileno NUMBER, p_blockno NUMBER)
      RETURN VARCHAR2
   AS
      i      NUMBER := 0;
      hi     NUMBER := 0;
      lo     NUMBER := 0;
      NEXT   NUMBER := 0;
      prev   NUMBER := 0;
   BEGIN
/* -------------------------------------------------------------
|| If the object cache is not initialized, then
|| initialize it
*/ -------------------------------------------------------------
      IF g_object_cache_initialized = 0
      THEN
         RETURN ('Extent at file ' || p_fileno || ', block ' || p_blockno);
      END IF;

      -- Binary chop through the table
      hi := object_cache_count;
      lo := 1;
      i := TRUNC ((hi - lo) / 2);

      <<main_loop>>
      LOOP
         -- Found a match
         DEBUG (   'checking entry '
                || i
                || ': '
                || object_cache_fileno (i)
                || ', '
                || object_cache_blockno (i)
                || '-'
                || TO_CHAR (  object_cache_blockno (i)
                            + object_cache_length (i)
                            - 1
                           )
               );

         IF     object_cache_fileno (i) = p_fileno
            AND                                               -- Found a match
                p_blockno BETWEEN object_cache_blockno (i)
                              AND   object_cache_blockno (i)
                                  + object_cache_length (i)
                                  - 1
         THEN
            DEBUG ('found match at ' || i || ' : ' || object_cache_segname (i)
                  );
            RETURN (object_cache_segname (i));
         ELSIF (   object_cache_fileno (i) < p_fileno
                OR                                     -- matching row is high
                   (    object_cache_fileno (i) = p_fileno
                    AND object_cache_blockno (i) + object_cache_length (i) - 1 <
                                                                     p_blockno
                   )
               )
         THEN
            -- We are low
            DEBUG ('too low');
            lo := i;
            NEXT := i + CEIL ((hi - lo) / 2);
         ELSIF (   object_cache_fileno (i) > p_fileno
                OR (    object_cache_fileno (i) = p_fileno
                    AND object_cache_blockno (i) > p_blockno
                   )
               )
         THEN
            -- We are high
            DEBUG ('too high');
            hi := i;
            NEXT := i - CEIL ((hi - lo) / 2);
         END IF;

         IF NEXT = i OR NEXT = prev
         THEN
            DEBUG ('chopped down to nothing (next entry' || NEXT || ')');
            -- We've chopped down to nothing (perhaps the cache should be refreshed)
            RETURN ('Unknown, temporary or new segment');
         END IF;

         prev := i;
         i := NEXT;
      END LOOP;
   END;                                                        -- get_seg_name

/* -------------------------------------------------------------
|| A function to return a segment name given a file/block header address
|| This is faster than using DBA_SEGMENTS
|| This is the I18N version of get_seg_name
*/ -------------------------------------------------------------
   FUNCTION get_seg_name_41 (p_fileno NUMBER, p_blockno NUMBER)
      RETURN VARCHAR2
   AS
      i      NUMBER := 0;
      hi     NUMBER := 0;
      lo     NUMBER := 0;
      NEXT   NUMBER := 0;
      prev   NUMBER := 0;
   BEGIN
/* -------------------------------------------------------------
|| If the object cache is not initialized, then
|| initialize it
*/ -------------------------------------------------------------
      IF g_object_cache_initialized = 0
      THEN
         RETURN ('Extent at file ' || p_fileno || ', block ' || p_blockno);
      END IF;

      -- Binary chop through the table
      hi := object_cache_count;
      lo := 1;
      i := TRUNC ((hi - lo) / 2);

      <<main_loop>>
      LOOP
         -- Found a match
         DEBUG (   'checking entry '
                || i
                || ': '
                || object_cache_fileno (i)
                || ', '
                || object_cache_blockno (i)
                || '-'
                || TO_CHAR (  object_cache_blockno (i)
                            + object_cache_length (i)
                            - 1
                           )
               );

         IF     object_cache_fileno (i) = p_fileno
            AND                                               -- Found a match
                p_blockno BETWEEN object_cache_blockno (i)
                              AND   object_cache_blockno (i)
                                  + object_cache_length (i)
                                  - 1
         THEN
            DEBUG ('found match at ' || i || ' : ' || object_cache_segname (i)
                  );
            RETURN (object_cache_segname (i));
         ELSIF (   object_cache_fileno (i) < p_fileno
                OR                                     -- matching row is high
                   (    object_cache_fileno (i) = p_fileno
                    AND object_cache_blockno (i) + object_cache_length (i) - 1 <
                                                                     p_blockno
                   )
               )
         THEN
            -- We are low
            DEBUG ('too low');
            lo := i;
            NEXT := i + CEIL ((hi - lo) / 2);
         ELSIF (   object_cache_fileno (i) > p_fileno
                OR (    object_cache_fileno (i) = p_fileno
                    AND object_cache_blockno (i) > p_blockno
                   )
               )
         THEN
            -- We are high
            DEBUG ('too high');
            hi := i;
            NEXT := i - CEIL ((hi - lo) / 2);
         END IF;

         IF NEXT = i OR NEXT = prev
         THEN
            DEBUG ('chopped down to nothing (next entry' || NEXT || ')');
            -- We've chopped down to nothing (perhaps the cache should be refreshed)
            RETURN ('UNK');            -- 'Unknown, temporary or new segment'
         END IF;

         prev := i;
         i := NEXT;
      END LOOP;
   END;                                                     -- get_seg_name_41

   --A copy of get_seg_name, to get extent number
   FUNCTION get_ext_no (p_fileno NUMBER, p_blockno NUMBER)
      RETURN NUMBER
   AS
      i      NUMBER := 0;
      hi     NUMBER := 0;
      lo     NUMBER := 0;
      NEXT   NUMBER := 0;
      prev   NUMBER := 0;
   BEGIN
      hi := object_cache_count;
      lo := 1;
      i := TRUNC ((hi - lo) / 2);

      <<main_loop>>
      LOOP
         -- Found a match
         DEBUG (   'checking entry '
                || i
                || ': '
                || object_cache_fileno (i)
                || ', '
                || object_cache_blockno (i)
                || '-'
                || TO_CHAR (  object_cache_blockno (i)
                            + object_cache_length (i)
                            - 1
                           )
               );

         IF     object_cache_fileno (i) = p_fileno
            AND                                               -- Found a match
                p_blockno BETWEEN object_cache_blockno (i)
                              AND   object_cache_blockno (i)
                                  + object_cache_length (i)
                                  - 1
         THEN
            DEBUG ('found match at ' || i || ' : ' || object_cache_segname (i)
                  );
            RETURN (object_cache_extno (i));
         ELSIF (   object_cache_fileno (i) < p_fileno
                OR                                     -- matching row is high
                   (    object_cache_fileno (i) = p_fileno
                    AND object_cache_blockno (i) + object_cache_length (i) - 1 <
                                                                     p_blockno
                   )
               )
         THEN
            -- We are low
            DEBUG ('too low');
            lo := i;
            NEXT := i + CEIL ((hi - lo) / 2);
         ELSIF (   object_cache_fileno (i) > p_fileno
                OR (    object_cache_fileno (i) = p_fileno
                    AND object_cache_blockno (i) > p_blockno
                   )
               )
         THEN
            -- We are high
            DEBUG ('too high');
            hi := i;
            NEXT := i - CEIL ((hi - lo) / 2);
         END IF;

         IF NEXT = i OR NEXT = prev
         THEN
            DEBUG ('chopped down to nothing (next entry' || NEXT || ')');
            -- We've chopped down to nothing (perhaps the cache should be refreshed)
            RETURN (0);
         END IF;

         prev := i;
         i := NEXT;
      END LOOP;
   END;                                                          -- get_ext_no

   --
   -- This function returns the event category for a given event.
   --
   FUNCTION event_category (p_event VARCHAR2, tag VARCHAR2 := 'pre 4.0')
      RETURN VARCHAR2
   IS
      i     NUMBER;
      cat   VARCHAR2 (100) := 'Unknown';
   BEGIN
      -- Check that the table is initialized
      IF g_event_count = 0
      THEN
         RETURN ('SoO ERROR: Event category table not initialized');
      END IF;

      -- Loop through the event tables and look for a matching event.
      FOR i IN 1 .. g_event_count
      LOOP
         -- debug('checking event '||i||':'||event_name_tab(i));
         IF p_event = event_name_tab (i)
         THEN
            IF tag = 'pre 4.0'
            THEN
               cat :=
                  SUBSTR (event_category_tab (i),
                          INSTR (event_category_tab (i), ' ^ ') + 3
                         );
            ELSE
               cat :=
                  SUBSTR (event_category_tab (i),
                          1,
                          INSTR (event_category_tab (i), ' ^ ') - 1
                         );
            END IF;
         END IF;
      END LOOP;

      RETURN (cat);
   END;                                                      -- event_category

   --
   -- This function returns an event category for an indx value
   -- from x$kslei
   --
   FUNCTION event_category (p_indx NUMBER, tag VARCHAR2 := 'pre 4.0')
      RETURN VARCHAR2
   IS
      i   NUMBER;
   BEGIN
      -- Check that the table is initialized
      IF g_event_count = 0
      THEN
         RETURN ('Spotlight On Oracle internal error');
      END IF;

      -- Return the event from the event_indx_tab
      IF tag = 'pre 4.0'
      THEN
         RETURN (SUBSTR (event_indx_tab (p_indx),
                         INSTR (event_indx_tab (p_indx), ' ^ ') + 3
                        )
                );
      ELSE
         RETURN (SUBSTR (event_indx_tab (p_indx),
                         1,
                         INSTR (event_indx_tab (p_indx), ' ^ ') - 1
                        )
                );
      END IF;
   EXCEPTION
      -- No entry found
      WHEN NO_DATA_FOUND
      THEN
         RETURN ('Unknown');
   END;                                                      -- event_category

   --
   -- Determine if the shared_pool_size is Ok
   --
   FUNCTION isspok
      RETURN NUMBER
   IS
      CURSOR sp_ok1
      IS
         SELECT request_failures, last_failure_size, max_free_size,
                free_space, request_misses
           FROM v$shared_pool_reserved;

      CURSOR sp_ok2
      IS
         SELECT quest_soo_pkg.translate_parameter (VALUE)
           FROM v$parameter
          WHERE NAME = 'shared_pool_reserved_min_alloc';

      res_spok    NUMBER;
      request_f   v$shared_pool_reserved.request_failures%TYPE;
      last_fs     v$shared_pool_reserved.last_failure_size%TYPE;
      max_fs      v$shared_pool_reserved.max_free_size%TYPE;
      fs          v$shared_pool_reserved.free_space%TYPE;
      request_m   v$shared_pool_reserved.request_misses%TYPE;
      sps_val     v$parameter.VALUE%TYPE;
   BEGIN
      OPEN sp_ok1;

      FETCH sp_ok1
       INTO request_f, last_fs, max_fs, fs, request_m;

      CLOSE sp_ok1;

      OPEN sp_ok2;

      FETCH sp_ok2
       INTO sps_val;

      CLOSE sp_ok2;

      IF (request_f > 0) AND (last_fs < sps_val)
      THEN
         res_spok := 1;
      ELSE
         res_spok := 0;
      END IF;

      RETURN (res_spok);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         CLOSE sp_ok1;

         CLOSE sp_ok2;

         RETURN (-1);
   END;

   --
   -- Determine the size of "other" in SGA
   --
   FUNCTION sgaother
      RETURN NUMBER
   IS
      CURSOR sga_other1
      IS
         SELECT quest_soo_pkg.translate_parameter (VALUE)
           FROM v$parameter
          WHERE NAME = 'java_pool_size';

      CURSOR sga_other2
      IS
         SELECT SUM (VALUE)
           FROM v$sga
          WHERE NAME <> 'Variable Size';

      CURSOR sga_other3
      IS
         SELECT SUM (VALUE)
           FROM v$sga;

      CURSOR sga_other4
      IS
         SELECT SUM (dc.sharable_mem)
           FROM v$db_object_cache dc;

      CURSOR sga_other5
      IS
         SELECT SUM (sa.sharable_mem)
           FROM v$sqlarea sa;

      CURSOR sga_other6
      IS
         SELECT SUM (250 * users_opening)
           FROM v$sqlarea sa;

      CURSOR sga_other7
      IS
         SELECT SUM (VALUE)
           FROM v$sesstat s, v$statname n
          WHERE s.statistic# = n.statistic#
            AND n.NAME = 'session uga memory max';

      sga_other_sz   NUMBER;
      jpsz           v$parameter.VALUE%TYPE;
      sga_nv_sz      NUMBER;
      sga_tot        NUMBER;
      object_mem     NUMBER;
      shared_sql     NUMBER;
      cursor_mem     NUMBER;
      mts_mem        NUMBER;
   BEGIN
      OPEN sga_other1;

      FETCH sga_other1
       INTO jpsz;

      CLOSE sga_other1;

      OPEN sga_other2;

      FETCH sga_other2
       INTO sga_nv_sz;

      CLOSE sga_other2;

      OPEN sga_other3;

      FETCH sga_other3
       INTO sga_tot;

      CLOSE sga_other3;

      OPEN sga_other4;

      FETCH sga_other4
       INTO object_mem;

      CLOSE sga_other4;

      OPEN sga_other5;

      FETCH sga_other5
       INTO shared_sql;

      CLOSE sga_other5;

      OPEN sga_other6;

      FETCH sga_other6
       INTO cursor_mem;

      CLOSE sga_other6;

      OPEN sga_other7;

      FETCH sga_other7
       INTO mts_mem;

      CLOSE sga_other7;

      sga_other_sz :=
           NVL (sga_tot, 0)
         - NVL (sga_nv_sz, 0)
         - NVL (jpsz, 0)
         - NVL (object_mem, 0)
         - NVL (shared_sql, 0)
         - NVL (cursor_mem, 0)
         - NVL (mts_mem, 0);
      RETURN (sga_other_sz);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         CLOSE sga_other1;

         CLOSE sga_other2;

         CLOSE sga_other3;

         CLOSE sga_other4;

         CLOSE sga_other5;

         CLOSE sga_other6;

         CLOSE sga_other7;

         RETURN (0);
   END;

--
-- This function returns the wait class of an event in 10g
--
   FUNCTION oracleeventclass (p_event_name VARCHAR2)
      RETURN VARCHAR2
   IS
      cs          VARCHAR2 (200)
            := 'SELECT wait_class FROM v$event_name WHERE name = :event_name';
      ch          INTEGER;
      waitclass   VARCHAR2 (200) := 'Unknown';
      rv          NUMBER;
      VERSION     NUMBER;
   BEGIN
      -- Mostly we double checked the version, but better this way......
      VERSION :=
           TO_NUMBER (SUBSTR (full_version, 1, INSTR (full_version, '.') - 1));

      IF VERSION = 10
      THEN
         ch := DBMS_SQL.open_cursor;
         DBMS_SQL.parse (ch, cs, DBMS_SQL.native);
         DBMS_SQL.bind_variable (ch, 'event_name', p_event_name);
         DBMS_SQL.define_column (ch, 1, waitclass, 200);
         rv := DBMS_SQL.EXECUTE (ch);
         rv := DBMS_SQL.fetch_rows (ch);

         IF rv > 0
         THEN
            --only getting the first one...
            DBMS_SQL.COLUMN_VALUE (ch, 1, waitclass);
            DBMS_SQL.close_cursor (ch);
         END IF;
      END IF;

      RETURN (waitclass);
   END;

   --
   -- This procedure populates the PL/SQL tables containing events and categories
   --
   PROCEDURE populate_event_table
   IS
      /* -----------------------------------------------------------------
      -- This cursor pulls out events and categories.  It pulls them
      -- out in descending frequency, so we can scan the table a bit
      -- more efficiently.  It gets INDX from X$KSLEI so that we can
      -- use that instead of the event name to avoid the join on X$KSLED
      ------------------------------------------------------------------*/
      stmt                VARCHAR2 (3200);
      stmt7               VARCHAR2 (3200)
         := 'SELECT /*+ORDERED USE_HASH(E) */

                    s.event event,

                    e.topcategory || '' - '' || e.subcategory || '' ^ '' || e.category category,

                    NVL(total_waits, -1)       total_waits,

                    NVL(S.INDX, -1)            indx

               FROM (SELECT /*+  ORDERED */

                            0 inst_id,

                            D.KSLEDNAM event,

                            S.KSLESWTS total_waits,

                            S.KSLESTMO total_timeouts,

                            S.KSLESTIM time_waited,

                            S.KSLESTIM / DECODE(S.KSLESWTS,0,1,S.KSLESWTS) average_wait,

                            S.INDX indx

                       FROM X$KSLED D, X$KSLEI S

                      WHERE S.INDX = D.INDX

                    ) s,

                    quest_soo_event_categories e

              WHERE s.event=e.name(+)

              ORDER BY total_waits desc';
      stmt8               VARCHAR2 (3200)
         := 'SELECT /*+ ORDERED USE_HASH(E) */

                    s.event event,

                    e.topcategory || '' - '' || e.subcategory || '' ^ '' || e.category category,

                    NVL(total_waits, -1)       total_waits,

                    NVL(S.INDX, -1)            indx

               FROM (SELECT /*+  ORDERED */

                            D.INST_ID,

                            D.KSLEDNAM event,

                            S.KSLESWTS total_waits,

                            S.KSLESTMO total_timeouts,

                            S.KSLESTIM time_waited,

                            S.KSLESTIM / DECODE(S.KSLESWTS,0,1,S.KSLESWTS) average_wait,

                            S.INDX indx

                       FROM X$KSLED D, X$KSLEI S

                      WHERE s.indx = d.indx

                        AND d.inst_id = USERENV(''INSTANCE'')

                        AND s.inst_id = USERENV(''INSTANCE'')

                    ) s,

                    quest_soo_event_categories e

              WHERE s.event=e.name(+)

              ORDER BY total_waits desc';
      stmt9               VARCHAR2 (3200)
         := 'SELECT /*+ ORDERED USE_HASH(E) */

                    s.event event,

                    e.topcategory || '' - '' || e.subcategory || '' ^ '' || e.category category,

                    NVL(total_waits, -1)       total_waits,

                    NVL(S.INDX,-1)            indx

               FROM (SELECT /*+  ORDERED */

                            D.INST_ID,

                            D.KSLEDNAM event,

                            S.KSLESWTS total_waits,

                            S.KSLESTMO total_timeouts,

                            S.KSLESTIM/10000 time_waited,  -- microsecond in 9i,convert to centisecond

                            S.KSLESTIM/10000/DECODE(S.KSLESWTS,0,1,S.KSLESWTS) average_wait,

                            S.INDX indx

                       FROM X$KSLED D, X$KSLEI S

                      WHERE S.INDX = D.INDX

                        AND d.INST_ID = USERENV(''INSTANCE'')

                        AND s.inst_id = USERENV(''INSTANCE'')

                    ) s,

                    quest_soo_event_categories e

              WHERE s.event=e.name(+)

              ORDER BY total_waits desc';
      stmt11              VARCHAR2 (3200)
         := 'WITH kslei AS

     (

        SELECT s.inst_id, s.indx,

               (s.ksleswts_un + s.ksleswts_fg + s.ksleswts_bg) ksleswts,

               (s.kslestmo_un + s.kslestmo_fg + s.kslestmo_bg) kslestmo,

               s.kslestim_un + s.kslestim_fg + s.kslestim_bg kslestim

          FROM x$kslei s)

    SELECT   /*+ ORDERED USE_HASH(E) */

         s.event event,

         e.topcategory || '' - '' || e.subcategory || '' ^ ''

         || e.CATEGORY CATEGORY,

         NVL (total_waits, -1) total_waits, NVL (s.indx, -1) indx

    FROM (SELECT /*+  ORDERED */

                 d.inst_id, d.kslednam event, s.ksleswts total_waits,

                 s.kslestmo total_timeouts, s.kslestim / 10000 time_waited,

                                   -- microsecond in 9i,convert to centisecond

                   s.kslestim

                 / 10000

                 / DECODE (s.ksleswts, 0, 1, s.ksleswts) average_wait,

                 s.indx indx

            FROM x$ksled d, kslei s

           WHERE s.indx = d.indx

             AND d.inst_id = USERENV (''INSTANCE'')

             AND s.inst_id = USERENV (''INSTANCE'')) s,

         quest_soo_event_categories e

   WHERE s.event = e.NAME(+)

   ORDER BY total_waits DESC';
      VERSION             NUMBER;
      csr                 INTEGER;
      event_name          VARCHAR2 (3200);
      event_cat           VARCHAR2 (3200);
      event_waits         NUMBER;
      event_indx          INTEGER;
      ignore              INTEGER;

      TYPE varchar_typ IS TABLE OF VARCHAR2 (3200)
         INDEX BY BINARY_INTEGER;

      TYPE num_typ IS TABLE OF NUMBER
         INDEX BY BINARY_INTEGER;

      l_event_name_tab    DBMS_SQL.varchar2_table;
      l_event_cat_tab     DBMS_SQL.varchar2_table;
      l_event_waits_tab   DBMS_SQL.number_table;
      l_event_indx_tab    DBMS_SQL.number_table;
      l_no_events         NUMBER;
      l_rows              NUMBER;
   BEGIN
      g_event_count := 0;
      VERSION :=
           TO_NUMBER (SUBSTR (full_version, 1, INSTR (full_version, '.') - 1));
      DEBUG ('start');
      stmt := stmt9;

      -- default to Oracle 9 first, which covers 10G and future release.
      IF (VERSION = 7)
      THEN
         stmt := stmt7;
      ELSIF (VERSION = 8)
      THEN
         stmt := stmt8;
      ELSIF (VERSION = 11)
      THEN
         stmt := stmt11;
      END IF;

      IF VERSION >= 10
      THEN
         EXECUTE IMMEDIATE    'INSERT INTO quest_soo_event_categories (NAME, topcategory, subcategory, CATEGORY) '
                           || 'SELECT NAME, decode(wait_class, ''Idle'', ''Idle'', ''Other''), '
                           || 'DECODE(wait_class, ''Idle'', ''Idle'', ''Other''), decode(wait_class, ''Idle'', ''Idle'', ''Other'') '
                           || ' FROM v$event_name e WHERE NOT EXISTS (SELECT 1 FROM quest_soo_event_categories c WHERE c.NAME = e.NAME)';
      END IF;

      -- Fetch the number of rows neccessary for array fetch:
      SELECT COUNT (*)
        INTO l_no_events
        FROM x$ksled;

      --
      -- Execute the appropriate SQL and put the rows into PLSQL
      -- Collections (DBMS_SQL is neccessary since the SQL is dynamic and
      -- we might be running in an earlier version that doesn't have bulk
      -- collect in NDS
      --
      csr := DBMS_SQL.open_cursor;
      DBMS_SQL.parse (csr, stmt, DBMS_SQL.native);
      DBMS_SQL.define_array (csr, 1, l_event_name_tab, l_no_events + 1, 0);
      DBMS_SQL.define_array (csr, 2, l_event_cat_tab, l_no_events + 1, 0);
      DBMS_SQL.define_array (csr, 3, l_event_waits_tab, l_no_events + 1, 0);
      DBMS_SQL.define_array (csr, 4, l_event_indx_tab, l_no_events + 1, 0);
      ignore := DBMS_SQL.EXECUTE (csr);
      l_rows := DBMS_SQL.fetch_rows (csr);
      DBMS_SQL.COLUMN_VALUE (csr, 1, l_event_name_tab);
      DBMS_SQL.COLUMN_VALUE (csr, 2, l_event_cat_tab);
      DBMS_SQL.COLUMN_VALUE (csr, 3, l_event_waits_tab);
      DBMS_SQL.COLUMN_VALUE (csr, 4, l_event_indx_tab);
      DBMS_SQL.close_cursor (csr);

      --
      -- Loop through the resulting rows, traslating them to the
      -- "traditional" event category tab format
      --
      -- TODO: The delimited format of this structure seems ridiculous and
      --       would almost certainly be better as a record structured array
      --
      FOR i IN 0 .. l_rows - 1
      LOOP
         event_name := l_event_name_tab (i);
         event_cat := l_event_cat_tab (i);
         event_waits := l_event_waits_tab (i);
         event_indx := l_event_indx_tab (i);
         g_event_count := g_event_count + 1;

         --dbms_output.put_line(substr('Value of event_name='||event_name,1,255));

         -- An new event is not categorised, set to Unknown.  If it is 10g, see if it is Idle.
         IF event_cat = ' -  ^ '
         THEN
            IF VERSION >= 10 AND oracleeventclass (event_name) = 'Idle'
            THEN
               event_category_tab (g_event_count) := 'Idle - Idle ^ Idle';
            ELSE
               event_category_tab (g_event_count) :=
                                                'Unknown - Unknown ^ Unknown';
            END IF;
         ELSE
            event_category_tab (g_event_count) := event_cat;
         END IF;

         event_name_tab (g_event_count) := event_name;

         IF event_indx > -1
         THEN
            --dbms_output.put_line(event_indx);
            event_indx_tab (event_indx) := event_category_tab (g_event_count);
         END IF;
      END LOOP;

      -- Populate the lock type table
      populate_lock_type;

   /*  EXCEPTION
        WHEN OTHERS
        THEN
           IF DBMS_SQL.is_open (csr)
           THEN
              DBMS_SQL.close_cursor (csr);
           END IF;

           RAISE; */
   END;                                                -- populate_event_table

   PROCEDURE initialize
   IS
   --
   -- Initialization section. This initializes PL/SQL tables.
   --
   BEGIN
      full_version := dbversion;          --Don't get version more than once.
      populate_event_table;
      initialize_object_cache;
   END;

   PROCEDURE initialize_fast
   IS
   --
   -- Initialization section A. This includes those initializations which
   -- Must be performed before any functions can be used.
   --
   BEGIN
      full_version := dbversion;          --Don't get version more than once.
      populate_event_table;
   END;

   PROCEDURE initialize_objects
   IS
   --
   -- Initialization section B. This includes all the slower loads which can
   -- Be deferred until after the first refresh.
   --
   BEGIN
      initialize_object_cache;
   END;

/* ---------------------------------------------------------
|| Functions below here are for the locktree functionality
*/ ---------------------------------------------------------

   -- Add a sid to the blocking list
   PROCEDURE add_blocking (p_sid NUMBER)
   IS
      i   NUMBER := 0;
   BEGIN
      FOR i IN 1 .. blocking_list_cnt
      LOOP
         IF blocking_list (i) = p_sid
         THEN
            RETURN;
         END IF;
      END LOOP;

      blocking_list_cnt := blocking_list_cnt + 1;
      blocking_list (blocking_list_cnt) := p_sid;
   END;

   --Add a sid to the blocked list
   PROCEDURE add_blocked (p_sid NUMBER)
   IS
      i   NUMBER := 0;
   BEGIN
      FOR i IN 1 .. blocked_list_cnt
      LOOP
         IF blocked_list (i) = p_sid
         THEN
            RETURN;
         END IF;
      END LOOP;

      blocked_list_cnt := blocked_list_cnt + 1;
      blocked_list (blocked_list_cnt) := p_sid;
   END;

   --Is a sid blocking?
   FUNCTION is_blocking (p_sid NUMBER)
      RETURN BOOLEAN
   IS
      i   NUMBER := 0;
   BEGIN
      FOR i IN 1 .. blocking_list_cnt
      LOOP
         IF blocking_list (i) = p_sid
         THEN
            RETURN (TRUE);
         END IF;
      END LOOP;

      RETURN (FALSE);
   END;

   --Is a sid blocked?
   FUNCTION is_blocked (p_sid NUMBER)
      RETURN BOOLEAN
   IS
      i   NUMBER := 0;
   BEGIN
      FOR i IN 1 .. blocked_list_cnt
      LOOP
         IF blocked_list (i) = p_sid
         THEN
            RETURN (TRUE);
         END IF;
      END LOOP;

      RETURN (FALSE);
   END;

   -- Generate a hash value for lock_hash_table
   FUNCTION f_lock_hash (p_id1 NUMBER, p_id2 NUMBER)
      RETURN BINARY_INTEGER
   IS
      i               NUMBER;
      l_work_string   VARCHAR2 (80) := '000';
   BEGIN
      DEBUG ('building hash_value for ' || p_id1 || ' ' || p_id2);
      -- Build up a character string containing all the numbers
      l_work_string := TO_CHAR (ABS (p_id1)) || l_work_string;
      l_work_string := TO_CHAR (ABS (p_id2)) || l_work_string;
      -- Use mod to get a number which fits in BINARY_INTEGER
      -- Actually make the number <<2^31 to allow for overflow rows
      DEBUG ('building hash_value for ' || l_work_string);
      RETURN (MOD (TO_NUMBER (l_work_string), 2000000000));
   END;

   -- Add an entry to the hash tables
   PROCEDURE add_hash_table (
      p_lock_count   NUMBER,
      p_ltype        VARCHAR2,
      p_id1          NUMBER,
      p_id2          NUMBER,
      p_sid          NUMBER
   )
   IS
      l_hash_value   BINARY_INTEGER;
      l_test_value   NUMBER;
      i              BINARY_INTEGER;
   BEGIN
      -- Get a hash value
      DEBUG ('getting hash_value');
      l_hash_value := f_lock_hash (p_id1, p_id2);
      DEBUG ('hash value is ' || l_hash_value);
      -- Starting with the hash value, look for an empty slot
      -- and when found, insert this value.
      i := l_hash_value;

      <<lock_hash_loop>>
      LOOP
         BEGIN
            l_test_value := lock_hash_table (i);
            --If here, a value was found, so try the next entry
            i := i + 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               -- If here, we've found a blank slot.  So put the entry in it
               -- and exit.
               lock_hash_table (i) := p_lock_count;
               DEBUG ('Added ' || p_lock_count || ' to lock_hash_table ' || i);
               EXIT lock_hash_loop;
         END;
      END LOOP;

      -- Now put an entry in the sid hash table
      i := p_sid * 10000;

      <<sid_hash_loop>>
      LOOP
         BEGIN
            l_test_value := sid_hash_table (i);
            --If here, a value was found, so try the next entry
            i := i + 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               sid_hash_table (i) := p_lock_count;
               DEBUG ('Adding sid_hash_table entry ' || i || ' for ' || p_sid);
               EXIT sid_hash_loop;
         END;
      END LOOP;
   END;

   PROCEDURE load_vlock
   IS
   -- Load the v$lock table into arrays
   BEGIN
      lock_count := 0;
      DEBUG ('load_vlock');

      FOR r1 IN c_lock
      LOOP
         DEBUG (lock_count || ' ' || r1.SID);
         lock_count := lock_count + 1;
         SID (lock_count) := r1.SID;
         ltype (lock_count) := r1.ltype;
         request (lock_count) := r1.request;
         lock_type (lock_count) := r1.lock_type;
         mode_held (lock_count) := r1.mode_held;
         mode_requested (lock_count) := r1.mode_requested;
         id1 (lock_count) := r1.id1;
         id2 (lock_count) := r1.id2;
         blocking (lock_count) := r1.blocking;
         blocked (lock_count) := r1.blocked;
         printed (lock_count) := 0;

         -- add sid to the blocked/blocking lists
         IF r1.blocking = 1
         THEN
            add_blocking (r1.SID);
         END IF;

         IF r1.blocked = 1
         THEN
            add_blocked (r1.SID);
         END IF;

         -- Add blocked entries to the lock_hash_table
         DEBUG (   'add hash_table '
                || lock_count
                || ' '
                || r1.ltype
                || ' '
                || r1.id1
                || ' '
                || r1.id2
               );
         add_hash_table (lock_count, r1.ltype, r1.id1, r1.id2, r1.SID);
      END LOOP;
   END;

   --
   -- I18N version
   --
   PROCEDURE load_vlock_41
   IS
   -- Load the v$lock table into arrays
   BEGIN
      lock_count := 0;
      DEBUG ('load_vlock_41');

      FOR r1 IN c_lock_41
      LOOP
         DEBUG (lock_count || ' ' || r1.SID);
         lock_count := lock_count + 1;
         SID (lock_count) := r1.SID;
         ltype (lock_count) := r1.ltype;
         request (lock_count) := r1.request;
         lock_type (lock_count) := r1.lock_type;
         mode_held (lock_count) := r1.mode_held;
         mode_requested (lock_count) := r1.mode_requested;
         id1 (lock_count) := r1.id1;
         id2 (lock_count) := r1.id2;
         blocking (lock_count) := r1.blocking;
         blocked (lock_count) := r1.blocked;
         printed (lock_count) := 0;

         -- add sid to the blocked/blocking lists
         IF r1.blocking = 1
         THEN
            add_blocking (r1.SID);
         END IF;

         IF r1.blocked = 1
         THEN
            add_blocked (r1.SID);
         END IF;

         -- Add blocked entries to the lock_hash_table
         DEBUG (   'add hash_table '
                || lock_count
                || ' '
                || r1.ltype
                || ' '
                || r1.id1
                || ' '
                || r1.id2
               );
         add_hash_table (lock_count, r1.ltype, r1.id1, r1.id2, r1.SID);
      END LOOP;
   END;

   -- Return the object name given an object id
   FUNCTION object_name (p_object_id NUMBER)
      RETURN VARCHAR2
   IS
      CURSOR c_get_objname (cp_object_id NUMBER)
      IS
         SELECT u.NAME || '.' || o.NAME NAME
           FROM SYS.obj$ o, SYS.user$ u
          WHERE obj# = cp_object_id AND u.user# = o.owner#;

      r_objname   c_get_objname%ROWTYPE;
   BEGIN
      OPEN c_get_objname (p_object_id);

      FETCH c_get_objname
       INTO r_objname;

      CLOSE c_get_objname;

      RETURN (r_objname.NAME);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         CLOSE c_get_objname;

         RETURN ('Unknown');
   END;

   -- Report basic details of the session
   PROCEDURE sid_details (p_sid NUMBER)
   IS
      CURSOR c_sid_details (cp_sid NUMBER)
      IS
         SELECT username, serial# serial, process pid,
                row_wait_obj# row_wait_obj
           FROM v$session
          WHERE SID = cp_sid;

      r_sid_details       c_sid_details%ROWTYPE;
      l_session_details   VARCHAR2 (90);
   BEGIN
      OPEN c_sid_details (p_sid);

      FETCH c_sid_details
       INTO r_sid_details;

      CLOSE c_sid_details;

      -- Decode the row wait object
      IF r_sid_details.row_wait_obj > 0
      THEN
         soo_locktree_row.object_name :=
                                     object_name (r_sid_details.row_wait_obj);
      END IF;

      soo_locktree_row.serial := r_sid_details.serial;
      soo_locktree_row.username := r_sid_details.username;
      soo_locktree_row.pid := r_sid_details.pid;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         CLOSE c_sid_details;

         soo_locktree_row.username := 'Unknown';
         soo_locktree_row.serial := 0;
         soo_locktree_row.pid := 'Unknown';
   END;

   -- Display details for a blocking user
   PROCEDURE print_blocker (p_element NUMBER, p_agent_id VARCHAR2)
   IS
      out_text   VARCHAR2 (200);
   BEGIN
      tree_sequence := tree_sequence + 1;
      sid_details (SID (p_element));

      INSERT INTO quest_soo_lock_tree
                  (user_audsid, sequence_id, agent_id,
                   tree_depth, SID, serial,
                   username, pid, lock_type,
                   request_mode, object_name
                  )
           VALUES (USERENV ('SESSIONID'), tree_sequence, p_agent_id,
                   tree_depth, SID (p_element), soo_locktree_row.serial,
                   soo_locktree_row.username, soo_locktree_row.pid, NULL,
                   NULL, NULL
                  );

      COMMIT;
   END;

   -- Display details for a blocked user
   PROCEDURE print_blocked (p_element NUMBER, p_agent_id VARCHAR2)
   IS
      out_text   VARCHAR2 (200);
   BEGIN
      -- Set the object name via id1 intially  - might be overridden by sid_details
      soo_locktree_row.object_name := object_name (id1 (p_element));
      tree_sequence := tree_sequence + 1;
      sid_details (SID (p_element));

      INSERT INTO quest_soo_lock_tree
                  (user_audsid, sequence_id, agent_id,
                   tree_depth, SID, serial,
                   username, pid,
                   lock_type, request_mode,
                   object_name
                  )
           VALUES (USERENV ('SESSIONID'), tree_sequence, p_agent_id,
                   tree_depth, SID (p_element), soo_locktree_row.serial,
                   soo_locktree_row.username, soo_locktree_row.pid,
                   lock_type (p_element), mode_requested (p_element),
                   soo_locktree_row.object_name
                  );

      COMMIT;
      printed (p_element) := 1;
   END;

   -- Show users waiting on the specified entry
   -- REVISIT:  This function should really take a sid as it's
   -- argument
   PROCEDURE show_waiters_on (p_blocker NUMBER, p_agent_id VARCHAR2)
   IS
      i              NUMBER;
      j              NUMBER;
      next_sid       NUMBER;
      l_hash_value   BINARY_INTEGER;
   BEGIN
      tree_depth := tree_depth + 1;
      -- Calculate the hash value for this sessions lock
      l_hash_value := f_lock_hash (id1 (p_blocker), id2 (p_blocker));
      DEBUG (   'Looking for sessions waiting on '
             || p_blocker
             || ' '
             || id1 (p_blocker)
             || ' '
             || id2 (p_blocker)
            );
      DEBUG ('Hash value is ' || l_hash_value);

      <<blocked_loop>>
      LOOP
         BEGIN
            i := lock_hash_table (l_hash_value);
            DEBUG ('Found ' || i || ' ' || SID (i) || ' ' || blocked (i));

            IF     SID (i) <> SID (p_blocker)
               AND id1 (i) = id1 (p_blocker)
               AND id2 (i) = id2 (p_blocker)
               AND printed (i) = 0
               AND                               -- never print a waiter twice
                   i <> p_blocker
               AND blocked (i) = 1
            THEN
               print_blocked (i, p_agent_id);

               --Now see if this sid is blocking anybody else
               IF is_blocking (SID (i))
               THEN
                  -- Look for a sid the same as this one, which blocks someone
                  -- else
                  j := SID (i) * 10000;  -- Start point in the sid hash table
                  --
                  -- Loop through our sid lookup table
                  --
                  DEBUG ('looking for sids matching ' || SID (i) || ' key '
                         || j
                        );

                  <<sid_loop>>
                  LOOP
                     BEGIN
                        next_sid := sid_hash_table (j);
                        DEBUG ('found ' || j || ' ' || sid_hash_table (j));

                        IF     SID (next_sid) = SID (i)
                           AND i <> next_sid
                           AND blocking (next_sid) = 1
                           AND printed (next_sid) <> 1
                        THEN
                           --
                           -- We've found a sid the same as ours who is blocking someone
                           --
                           show_waiters_on (next_sid, p_agent_id);
                           printed (next_sid) := 1;
                        -- Remember that we've done this sid
                        END IF;

                        j := j + 1;             -- Go to the next matchine sid
                     EXCEPTION
                        WHEN NO_DATA_FOUND
                        THEN
                           -- When we stop finding sids, then we exit
                           EXIT sid_loop;
                     END;
                  END LOOP;
               END IF;
            END IF;

            -- GO the the next hash value may should contain
            -- More blockers
            l_hash_value := l_hash_value + 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               -- No more entries match the lock id1
               EXIT blocked_loop;
         END;
      END LOOP;

      tree_depth := tree_depth - 1;
   END;

   -- Clear all locktree global variables
   PROCEDURE reset_globals
   IS
   BEGIN
      SID.DELETE;
      ltype.DELETE;
      request.DELETE;
      lock_type.DELETE;
      mode_held.DELETE;
      mode_requested.DELETE;
      id1.DELETE;
      id2.DELETE;
      blocking.DELETE;
      blocked.DELETE;
      printed.DELETE;
      blocked_list.DELETE;
      blocked_list_cnt := 0;
      blocking_list.DELETE;
      blocking_list_cnt := 0;
      lock_count := 0;
      tree_depth := 0;
      tree_sequence := 0;
      lock_hash_table.DELETE;
      sid_hash_table.DELETE;
   END;

   -- Mainline print a lock tree.
   PROCEDURE locktree (p_agent_id VARCHAR2)
   IS
      i   NUMBER;
   BEGIN
      DEBUG ('about to load_vlock');
      -- clears the contents of the lock tables
      reset_globals;
      load_vlock;                                     -- Load the lock arrays

      FOR i IN 1 .. lock_count
      LOOP
         IF     blocking (i) = 1
            AND (NOT is_blocked (SID (i)))
            /* the next line ensures that we don't print multiple lines
            ** for a single session, even if that session holds multiple
            ** Blocking locks
            */
            AND (i = 1 OR SID (i - 1) != SID (i))           /*not a repeated*/
         THEN
            print_blocker (i, p_agent_id);
            show_waiters_on (i, p_agent_id);
         END IF;
      END LOOP;
   END;

   --
   -- Mainline print a lock tree.
   -- I18N version
   --
   PROCEDURE locktree_41 (p_agent_id VARCHAR2)
   IS
      i   NUMBER;
   BEGIN
      DEBUG ('about to load_vlock');
      -- clears the contents of the lock tables
      reset_globals;
      load_vlock_41;                                  -- Load the lock arrays

      FOR i IN 1 .. lock_count
      LOOP
         IF     blocking (i) = 1
            AND (NOT is_blocked (SID (i)))
            /* the next line ensures that we don't print multiple lines
            ** for a single session, even if that session holds multiple
            ** Blocking locks
            */
            AND (i = 1 OR SID (i - 1) != SID (i))           /*not a repeated*/
         THEN
            print_blocker (i, p_agent_id);
            show_waiters_on (i, p_agent_id);
         END IF;
      END LOOP;
   END;

   FUNCTION latch_category (p_latch_name VARCHAR2)
      RETURN VARCHAR2
   IS
   BEGIN
      IF    (p_latch_name LIKE 'library cache%')
         OR (p_latch_name = 'shared pool')
      THEN
         RETURN ('Shared Pool');
      ELSIF (p_latch_name LIKE 'redo%')
      THEN
         RETURN ('Redo buffer');
      ELSIF (p_latch_name LIKE 'cache buffer%')
      THEN
         RETURN ('Buffer cache');
      ELSIF (p_latch_name LIKE '%enqueue%')
      THEN
         RETURN ('Enqueue');
      ELSIF (p_latch_name LIKE '%virtual circuit%')
      THEN
         RETURN ('MTS');
      ELSIF (p_latch_name LIKE '%transaction%')
      THEN
         RETURN ('Transaction');
      ELSE
         RETURN ('Other');
      END IF;
   END;                                                      -- latch_category

   FUNCTION obj_type (object_t VARCHAR2)
      RETURN CHAR
   IS
   BEGIN
      IF (object_t = 'package')
      THEN
         RETURN ('P');
      ELSIF (object_t = 'cursor')
      THEN
         RETURN ('C');
      ELSIF (object_t = 'trigger')
      THEN
         RETURN ('R');
      ELSIF (object_t = 'sequence')
      THEN
         RETURN ('Q');
      ELSE
         RETURN ('T');
      END IF;
   END;                                                            -- obj_type

   -- Start tracing the session
   PROCEDURE set_trace (p_sid NUMBER, p_serial NUMBER, p_level NUMBER)
   IS
   BEGIN
      SYS.DBMS_SYSTEM.set_ev (p_sid, p_serial, 10046, p_level, '');
   END;

   -- Overload for backward compatibiity
   PROCEDURE set_trace (p_sid NUMBER, p_serial NUMBER, p_mode BOOLEAN)
   IS
   BEGIN
      -- Just wrapping dbms_system for now, but might do something different later
      SYS.DBMS_SYSTEM.set_sql_trace_in_session (p_sid, p_serial, p_mode);
   END;

   -- Keep object in Shared Pool
   -- PROCEDURE obj_keep(name in varchar2, type in varchar2) IS
   -- BEGIN
   --    sys.dbms_shared_pool.keep(name, obj_type(type));

   --    EXCEPTION
   --      WHEN OTHERS THEN NULL;
   -- END;

   -- Unkeep object from Shared Pool
   -- PROCEDURE obj_unkeep(name in varchar2, type in varchar2) IS
   -- BEGIN
   --    sys.dbms_shared_pool.unkeep(name, obj_type(type));

   --    EXCEPTION
   --      WHEN OTHERS THEN NULL;
   -- END;

   -- Kill the nominated session
   PROCEDURE kill_session (p_sid NUMBER, p_serial NUMBER)
   IS
      l_cursor   INTEGER         DEFAULT 0;
      rc         INTEGER         DEFAULT 0;
      stmt       VARCHAR2 (1000);
   BEGIN
      stmt :=
          'alter system kill session ''' || p_sid || ', ' || p_serial || '''';
      l_cursor := DBMS_SQL.open_cursor;
      DBMS_SQL.parse (l_cursor, stmt, DBMS_SQL.native);
      rc := DBMS_SQL.EXECUTE (l_cursor);
      DBMS_SQL.close_cursor (l_cursor);
   EXCEPTION
      WHEN OTHERS
      THEN
         BEGIN
            DBMS_SQL.close_cursor (l_cursor);
         EXCEPTION
            WHEN OTHERS
            THEN
               NULL;
         END;

         raise_application_error (-20102, 'Cannot kill session: ' || SQLERRM);
   END;

   -- Turn timed statistics on
   PROCEDURE set_timed_statistics
   IS
      l_cursor   INTEGER         DEFAULT 0;
      rc         INTEGER         DEFAULT 0;
      stmt       VARCHAR2 (1000);
   BEGIN
      stmt := 'alter system set timed_statistics=TRUE';
      l_cursor := DBMS_SQL.open_cursor;
      DBMS_SQL.parse (l_cursor, stmt, DBMS_SQL.native);
      rc := DBMS_SQL.EXECUTE (l_cursor);
      DBMS_SQL.close_cursor (l_cursor);
   EXCEPTION
      WHEN OTHERS
      THEN
         BEGIN
            DBMS_SQL.close_cursor (l_cursor);
         EXCEPTION
            WHEN OTHERS
            THEN
               NULL;
         END;

         raise_application_error (-20103,
                                  'Cannot set timed_statistics ' || SQLERRM
                                 );
   END;

   --  Flush shared pool
   PROCEDURE flush_shared_pool
   IS
      l_cursor   INTEGER         DEFAULT 0;
      rc         INTEGER         DEFAULT 0;
      stmt       VARCHAR2 (1000);
   BEGIN
      stmt := 'alter system flush shared_pool';
      l_cursor := DBMS_SQL.open_cursor;
      DBMS_SQL.parse (l_cursor, stmt, DBMS_SQL.native);
      rc := DBMS_SQL.EXECUTE (l_cursor);
      DBMS_SQL.close_cursor (l_cursor);
   EXCEPTION
      WHEN OTHERS
      THEN
         BEGIN
            DBMS_SQL.close_cursor (l_cursor);
         EXCEPTION
            WHEN OTHERS
            THEN
               NULL;
         END;

         raise_application_error (-21101,
                                  'Cannot flush shared pool ' || SQLERRM
                                 );
   END;

   --
   -- Translate values in the form 999{K|M} to byte values so
   -- instance monitor can deal with them
   --
   FUNCTION translate_parameter (p_value VARCHAR2)
      RETURN VARCHAR2
   IS
      last_char      CHAR;
      numeric_part   NUMBER;
      -- Below two variables are used for buffer_pool_keep/recycle
      para_value     VARCHAR2 (200);
      end_position   INTEGER;
   BEGIN
      -- buffer_pool_keep/recycle has format {integer | (BUFFERS: integer [,LRU_LATCHES: integer] ) }
      -- the first integer is the size.
      IF (INSTR (p_value, ',') > 1)
      THEN
         end_position := INSTR (p_value, ',');
      ELSE
         end_position := LENGTH (p_value);
      END IF;

      para_value := LOWER (REPLACE (SUBSTR (p_value, 1, end_position), ' '));

      IF (INSTR (para_value, 'buffers:', 1) > 0)
      THEN
         RETURN (TO_NUMBER (TRANSLATE (para_value,
                                       '0123456789befrsu,:)(',
                                       '0123456789'
                                      )
                           )
                );
      ELSE
         -- Above is the end for puffer_pool_keep/recycle.  Below is not changed.
         last_char := NVL (UPPER (SUBSTR (p_value, -1)), ' ');

         IF last_char <> 'K' AND last_char <> 'M' AND last_char <> 'G'
         THEN
            -- Does not have a trailing 'K' or 'M' or 'G'
            RETURN (p_value);
         ELSE
            BEGIN
               numeric_part :=
                         TO_NUMBER (SUBSTR (p_value, 1, LENGTH (p_value) - 1));

               IF last_char = 'K'
               THEN
                  RETURN (TO_CHAR (numeric_part * 1024));
               ELSIF last_char = 'M'
               THEN
                  RETURN (TO_CHAR (numeric_part * 1024 * 1024));
               ELSIF last_char = 'G'
               THEN
                  RETURN (TO_CHAR (numeric_part * 1024 * 1024 * 1024));
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  -- Can't convert the leading chars to a number, so return the
                  -- original value
                  RETURN (p_value);
            END;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN (p_value);
   END;

   /* -----------------------------------------------------------
      FUnctions below implement the "show blocked row facility
      ----------------------------------------------------------*/

   --global variables

   --private declarations
   FUNCTION build_select_list (lowner IN VARCHAR2, lname IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION run_stmt (lowner IN VARCHAR2, lname IN VARCHAR2, lrowid IN VARCHAR2)
      RETURN VARCHAR2;

   PROCEDURE DEBUG (lstr IN VARCHAR2);

   /*---------------------------------------------------------
     Show all the rows being waited on
    -----------------------------------------------------------*/
   FUNCTION show_locked_row (lsid IN NUMBER)
      RETURN VARCHAR2
   IS
      --rowid changed between Oracle7 and Oracle8, so we
      --dynamically create the statement to suit.
      cs8         VARCHAR2 (2000)
         := 'SELECT u.name oowner, o.name oname,

                                      sys.dbms_rowid.rowid_create(1, s.row_wait_obj#,

                                                                     s.row_wait_file#,

                                                                     s.row_wait_block#,

                                                                     s.row_wait_row#) orowid

                                 FROM v$session s, sys.obj$ o, sys.user$ u

                                WHERE s.row_wait_obj# != -1

                                  AND o.obj# = s.row_wait_obj#

                                  AND u.user# = o.owner#

                                  AND s.sid = :lsid';
      cs7         VARCHAR2 (2000)
         := 'SELECT u.name oowner, o.name oname,

                                      lpad(quest_soo_pkg.toradixstring(s.row_wait_block#, 16), 8, ''0'') ||''.''||

                                      lpad(quest_soo_pkg.toradixstring(s.row_wait_row#, 16), 4, ''0'')   ||''.''||

                                      lpad(quest_soo_pkg.toradixstring(s.row_wait_file#, 16), 4, ''0'') orowid

                                 FROM v$session s, sys.obj$ o, sys.user$ u

                                WHERE s.row_wait_obj# != -1

                                  AND o.obj# = s.row_wait_obj#

                                  AND u.user# = o.owner#

                                  AND s.sid = :lsid';
      ch          INTEGER;
      ldataline   VARCHAR2 (2000);
      oowner      VARCHAR2 (500);
      oname       VARCHAR2 (500);
      orowid      VARCHAR2 (50);
      rv          NUMBER;
      lsql        VARCHAR2 (2000);
      VERSION     NUMBER;
   BEGIN
      IF full_version IS NULL
      THEN                        -- We don't initialize all sessions in ADK.
         full_version := dbversion;
      END IF;

      --debug('Entering show_waiters');
      VERSION :=
            TO_NUMBER (SUBSTR (full_version, 1, INSTR (full_version, '.') - 1));

      IF (VERSION = 7)
      THEN
         lsql := cs7;
      ELSE
         IF (VERSION = 8 OR VERSION = 9 OR VERSION = 10)
         THEN
            lsql := cs8;
         ELSE
            --debug('Unsupported Version!');
            NULL;
         END IF;
      END IF;

      --debug('version='||version||' '||lsql);
      ch := DBMS_SQL.open_cursor;
      DBMS_SQL.parse (ch, lsql, DBMS_SQL.native);
      DBMS_SQL.bind_variable (ch, 'lsid', lsid);
      DBMS_SQL.define_column (ch, 1, oowner, 500);
      DBMS_SQL.define_column (ch, 2, oname, 500);
      DBMS_SQL.define_column (ch, 3, orowid, 50);
      rv := DBMS_SQL.EXECUTE (ch);
      rv := DBMS_SQL.fetch_rows (ch);

      --debug('found '||rv||' rows');
      IF rv > 0
      THEN
         --only getting the first one...
         DBMS_SQL.COLUMN_VALUE (ch, 1, oowner);
         DBMS_SQL.COLUMN_VALUE (ch, 2, oname);
         DBMS_SQL.COLUMN_VALUE (ch, 3, orowid);
         --debug(oowner||' '||oname||' '||orowid);
         ldataline := run_stmt (oowner, oname, orowid);
         DBMS_SQL.close_cursor (ch);
         --debug(ldataline);
         RETURN (ldataline);
      ELSE
         RETURN ('Cannot determine row level lock details for this session.'
                );
      END IF;
   END;                                            --procedure show_locked_row

   /*---------------------------------------------------------
     Show all the rows being waited on
     I18N version
    -----------------------------------------------------------*/
   FUNCTION show_locked_row_41 (lsid IN NUMBER)
      RETURN VARCHAR2
   IS
      --rowid changed between Oracle7 and Oracle8, so we
      --dynamically create the statement to suit.
      cs8         VARCHAR2 (2000)
         := 'SELECT u.name oowner, o.name oname,

                                      sys.dbms_rowid.rowid_create(1, s.row_wait_obj#,

                                                                     s.row_wait_file#,

                                                                     s.row_wait_block#,

                                                                     s.row_wait_row#) orowid

                                 FROM v$session s, sys.obj$ o, sys.user$ u

                                WHERE s.row_wait_obj# != -1

                                  AND o.obj# = s.row_wait_obj#

                                  AND u.user# = o.owner#

                                  AND s.sid = :lsid';
      ch          INTEGER;
      ldataline   VARCHAR2 (2000);
      oowner      VARCHAR2 (500);
      oname       VARCHAR2 (500);
      orowid      VARCHAR2 (50);
      rv          NUMBER;
      lsql        VARCHAR2 (2000);
      VERSION     NUMBER;
   BEGIN
      IF full_version IS NULL
      THEN                        -- We don't initialize all sessions in ADK.
         full_version := dbversion;
      END IF;

      lsql := cs8;

      --debug('version='||version||' '||lsql);
      ch := DBMS_SQL.open_cursor;
      DBMS_SQL.parse (ch, lsql, DBMS_SQL.native);
      DBMS_SQL.bind_variable (ch, 'lsid', lsid);
      DBMS_SQL.define_column (ch, 1, oowner, 500);
      DBMS_SQL.define_column (ch, 2, oname, 500);
      DBMS_SQL.define_column (ch, 3, orowid, 50);
      rv := DBMS_SQL.EXECUTE (ch);
      rv := DBMS_SQL.fetch_rows (ch);

      IF rv > 0
      THEN
         --only getting the first one...
         DBMS_SQL.COLUMN_VALUE (ch, 1, oowner);
         DBMS_SQL.COLUMN_VALUE (ch, 2, oname);
         DBMS_SQL.COLUMN_VALUE (ch, 3, orowid);
         --debug(oowner||' '||oname||' '||orowid);
         ldataline := run_stmt (oowner, oname, orowid);
         DBMS_SQL.close_cursor (ch);
         --debug(ldataline);
         RETURN (ldataline);
      ELSE
         RETURN ('ERROR');
      END IF;
   END;                                         --procedure show_locked_row_41

/* ---------------------------------------------------------------
|| Procedure to run the statement built to retrieve the locked row
*/ --------------------------------------------------------------
   FUNCTION run_stmt (lowner IN VARCHAR2, lname IN VARCHAR2, lrowid IN VARCHAR2)
      RETURN VARCHAR2
   IS
      c1          INTEGER         DEFAULT 0;
      rc          INTEGER         DEFAULT 0;
      lsql        VARCHAR2 (2000);
      ldataline   VARCHAR2 (2000);
      nrows       INTEGER;
   BEGIN
      --debug('Entering run_stmt');
      --Only one column to be bound...a long string
      c1 := DBMS_SQL.open_cursor;
      lsql :=
            'SELECT '
         || '''Table="'
         || lowner
         || '.'
         || lname
         || '" ''||'
         || '''rowid="'
         || lrowid
         || '"''||'
         || build_select_list (lowner, lname)
         || ' FROM '
         || lowner
         || '.'
         || lname
         || ' WHERE rowid=chartorowid(:lr) ';
      --debug('stmt='||lsql);
      DBMS_SQL.parse (c1, lsql, DBMS_SQL.native);
      DBMS_SQL.bind_variable (c1, 'lr', lrowid);
      DBMS_SQL.define_column (c1, 1, ldataline, 2000);
      --check return codes from function calls
      rc := DBMS_SQL.EXECUTE (c1);
      --debug('rows = '||rc);
      nrows := DBMS_SQL.fetch_rows (c1);
      DBMS_SQL.COLUMN_VALUE (c1, 1, ldataline);
      DBMS_SQL.close_cursor (c1);
      --debug('return string is '||ldataline);
      RETURN (ldataline);
   END;                                                   --procedure run_stmt

/* ---------------------------------------------------------------
|| Build the select list for the sql stmt based on the columns of
|| the table and their types
*/ --------------------------------------------------------------
   FUNCTION build_select_list (lowner IN VARCHAR2, lname IN VARCHAR2)
      RETURN VARCHAR2
   IS
      CURSOR cols (lname IN VARCHAR2, lowner IN VARCHAR2)
      IS
         SELECT   DECODE (data_type,
                          'NUMBER', 'to_char(' || column_name || ')',
                          'DATE', 'to_char(' || column_name || ')',
                          column_name
                         ) newcol,
                  column_name
             FROM dba_tab_columns
            WHERE owner = lowner
              AND table_name = lname
              AND data_type IN
                     ('CHAR',
                      'VARCHAR2',
                      'DATE',
                      'NUMBER',
                      'NCHAR',
                      'NVARCHAR2'
                     )
         ORDER BY column_id ASC;

      lselstmt   VARCHAR2 (2000) := NULL;
   BEGIN
      --debug('Entering build_select_list');
      --build a concat select list to return for inclusion in stmt
      FOR c1 IN cols (lname, lowner)
      LOOP
         --dont forget to check the length of the string to see if the new will fit
         EXIT WHEN   LENGTH (lselstmt)
                   + LENGTH (c1.column_name)
                   + 11
                   + LENGTH (c1.newcol) > 1500;

         IF (LENGTH (lselstmt) != 0)
         THEN
            lselstmt := lselstmt || '||';
         --debug('prefixing'||lselstmt);
         END IF;

         lselstmt :=
               lselstmt
            || ''' '
            || c1.column_name
            || '="''||'
            || c1.newcol
            || '||''"''';
      END LOOP;

      --and tack a handle on the end of it...
      lselstmt := lselstmt || ' ' || ' OUTSTR ';
      --debug(lselstmt);
      RETURN (lselstmt);
   END;

/* ---------------------------------------------------------------
|| Write debug messages to dbms_output
|| dbms_output has a limit of 255 char per line, so we break the
|| chunks up into smaller bits than that.
|| changing the message line length is ok.
*/ --------------------------------------------------------------
   PROCEDURE DEBUG (lstr IN VARCHAR2)
   IS
      msg         VARCHAR2 (200)
                    := 'DEBUG: ' || TO_CHAR (SYSDATE, 'hh24:mi:ss ddmmyyyy ');
      chunk_len   NUMBER         := 255 - LENGTH (msg);
   BEGIN
      IF (g_debug = 'Y')
      THEN
         FOR i IN 0 .. CEIL (LENGTH (lstr) / 255)
         LOOP
            DBMS_OUTPUT.put_line (   msg
                                  || SUBSTR (lstr,
                                             (i * chunk_len) + 1,
                                             chunk_len
                                            )
                                 );
         END LOOP;
      END IF;
   END;

/* ---------------------------------------------------------------
|| Convert number to string (hex conversion)
*/ --------------------------------------------------------------
   FUNCTION toradixstring (num IN NUMBER, radix IN NUMBER)
      RETURN VARCHAR2
   AS
      dividend    NUMBER;
      divisor     NUMBER;
      REMAINDER   NUMBER (2);
      numstr      VARCHAR2 (2000);
   BEGIN
      /* NULL NUMBER -> NULL hex string */
      IF (num IS NULL)
      THEN
         RETURN NULL;
      ELSIF (num = 0)
      THEN                                                  /* special case */
         RETURN '0';
      END IF;

      /* invalid number or radix; force ORA-6502:
         PL/SQL: numeric or value err */
      IF    (num < 0)
         OR (num != TRUNC (num))
         OR (radix < 2)
         OR (radix > 16)
         OR (radix != TRUNC (radix))
      THEN
         numstr := TO_CHAR (TO_NUMBER ('invalid number'));
         /* Forces ORA-6502. */
         RETURN numstr;
      END IF;

      dividend := num;
      numstr := '';                             /* start with a null string */

      /* the actual conversion loop */
      WHILE (dividend != 0)
      LOOP
         REMAINDER := MOD (dividend, radix);
         numstr := digittostring (REMAINDER) || numstr;
         dividend := TRUNC (dividend / radix);
      END LOOP;

      RETURN numstr;
   END toradixstring;

   /* Takes a number between 0 and 15, and converts it to a string (character)
      The toRadixString() function calls this function.

      The caller of this function is responsible for making sure no invalid
      number is passed as the argument.  Valid numbers include non-negative
      integer in the radix used by the calling function.  For example,
      toOctalString() must pass nothing but 0, 1, 2, 3, 4, 5, 6, and 7 as the
      argument 'num' of digitToString().
   */
   FUNCTION digittostring (num IN NUMBER)
      RETURN VARCHAR2
   AS
      digitstr   VARCHAR2 (1);
   BEGIN
      IF (num < 10)
      THEN
         digitstr := TO_CHAR (num);
      ELSE
         digitstr := CHR (ASCII ('A') + num - 10);
      END IF;

      RETURN digitstr;
   END digittostring;

   -- Take a string and convert it to a number
   -- If string isn't in number format return -1
   FUNCTION stringToDigit(str IN VARCHAR2)
      RETURN NUMBER
   AS
     numstr    	NUMBER;
   BEGIN
   	   BEGIN
   	      numstr := TO_NUMBER(str);

   	   EXCEPTION
   	      WHEN OTHERS THEN
   	         numstr := -1;
   	   END;

       RETURN numstr;

   END stringToDigit;

--------------------------------------------------
--Acquire and return the full dbms version number
--------------------------------------------------
   FUNCTION dbversion
      RETURN VARCHAR2
   IS
      db_version   VARCHAR2 (20);

      CURSOR c1
      IS
         SELECT SUBSTR (SUBSTR (banner, INSTR (banner, 'Release ') + 8),
                        1,
                        INSTR (SUBSTR (banner, INSTR (banner, 'Release ') + 8),
                               ' '
                              )
                       )
           FROM v$version
          WHERE banner LIKE 'Oracle%' OR banner LIKE 'Personal Oracle%';
   BEGIN
      --The first row contains the dbms version...I am assured.
      OPEN c1;

      FETCH c1
       INTO db_version;

      CLOSE c1;

      --debug('Major Version: '||db_version);
      RETURN (db_version);
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20100,
                                     'Exception in version check'
                                  || SQLCODE
                                  || ':'
                                  || SQLERRM
                                 );
   -- debug('Exception in version check'||sqlcode||':'||sqlerrm);
   END; --function dbversion

   -- Function get to version number in a number
   FUNCTION get_db_version RETURN NUMBER
   IS
   	  db_version 	NUMBER;
   BEGIN

	 SELECT TO_NUMBER (SUBSTR (VERSION, 1, INSTR (VERSION, '.', 1, 2) - 1), '99.99')
	 INTO   db_version
	 FROM 	v$instance;

	 RETURN db_version;
   EXCEPTION
   	 WHEN OTHERS THEN
   	 	 SELECT TO_NUMBER (SUBSTR (VERSION, 1, INSTR (VERSION, '.') - 1), '99.99')
   	 	 INTO 	db_version
   	 	 FROM 	v$instance;

   	 	 RETURN db_version;
   END get_db_version;

   --
   -- Functions to help decipher shared pool structure
   --
   FUNCTION sga_cat2 (p_pool VARCHAR2, p_name VARCHAR2)
      RETURN VARCHAR2
   IS
      l_sga_cat   VARCHAR2 (30);
   BEGIN
      IF     p_pool IN ('shared pool', 'large pool', 'java pool')
         AND p_name IN ('sql area', 'library cache', 'free memory')
      THEN
         l_sga_cat := p_name;
      ELSE
         l_sga_cat := 'Other Used';
      END IF;

      RETURN l_sga_cat;
   END;

   FUNCTION sga_cat (p_pool VARCHAR2, p_name VARCHAR2)
      RETURN VARCHAR2
   IS
      l_sga_cat   VARCHAR2 (30);
   BEGIN
      IF p_pool IS NULL
      THEN
         l_sga_cat := p_name;
      ELSE
         l_sga_cat := p_pool;
      END IF;

      RETURN l_sga_cat;
   END;

   FUNCTION sga_area7 (p_name VARCHAR2)
      RETURN VARCHAR2
   IS
      l_area   VARCHAR2 (30);
   BEGIN
      IF p_name IN
                  ('sql area', 'library cache', 'log_buffer', 'free memory')
      THEN
         l_area := p_name;
      ELSE
         l_area := 'Other';
      END IF;

      RETURN (l_area);
   END;

   FUNCTION sga_pool7 (p_name VARCHAR2)
      RETURN VARCHAR2
   IS
      l_pool   VARCHAR2 (30);
   BEGIN
      IF p_name IN ('db_block_buffers')
      THEN
         l_pool := p_name;
      ELSIF p_name IN ('fixed_sga', 'log_buffer')
      THEN
         l_pool := 'General';
      ELSE
         l_pool := 'Shared Pool';
      END IF;

      RETURN (l_pool);
   END;

   /* --------------------------------------------------------------------
      Function to return the full SQL text.  This is overloaded
      to use either SID for current or previous SQL or to take an
      address and/or hash value.

      Unless the database version is greater than 8.1.5, the hash value
      is ignored because of numerous bugs relating to the use of hash values
      in these versions
    --------------------------------------------------------------------*/
   /* exact_db_version is not required.  No need to call it again and again.
   FUNCTION exact_db_version(p_major  OUT NUMBER,
                             p_minor1 OUT NUMBER,
                             p_minor2 OUT NUMBER)
         RETURN VARCHAR2 IS
       CURSOR c_version IS
              SELECT banner
                FROM V$VERSION
               WHERE ROWNUM=1;

       l_start      NUMBER;
       l_end        NUMBER;
       l_banner     VARCHAR2(2000);
       l_db_version VARCHAR2(20);
       l_major      NUMBER;
       l_minor1     NUMBER;
       l_minor2     NUMBER;
   BEGIN
       OPEN c_version;
       FETCH c_version INTO l_banner;
       l_start:=INSTR(l_banner, '.')-1;
       l_end:=INSTR(l_banner, ' ', l_start)-1;

       IF  l_end>0 THEN
           l_db_version:=SUBSTR(l_banner, l_start, l_end-l_start+1);
       ELSE
           l_db_version:=SUBSTR(l_banner, l_start);
       END IF;

       CLOSE c_version;

       p_major:=SUBSTR(l_db_version, 1, INSTR(l_db_version, '.')-1);
       l_start:=INSTR(l_db_version, '.')+1;
       l_end:=INSTR(l_db_version, '.', l_start);
       --dbms_output.put_line(l_start||' '||l_end);
       p_minor1:=SUBSTR(l_db_version, l_start, l_end-l_start);
       --dbms_output.put_line(p_minor1);

       l_start:=INSTR(l_db_version, '.', l_end)+1;
       l_end:=INSTR(l_db_version, '.', l_start);
       --dbms_output.put_line(l_start||' '||l_end);
       p_minor2:=SUBSTR(l_db_version, l_start, l_end-l_start);

       RETURN(l_db_version);
   EXCEPTION WHEN value_error THEN
       raise_application_error(-20101, 'Unable to parse Oracle version: '||l_banner);
   END;
   */

   --
   -- This function returns the long SQL text string.  It attempts this in a
   -- number of ways to work around problems with hash values in various
   -- releases of Oracle
   --
   FUNCTION get_long_sqltext (p_hash_value NUMBER, p_address RAW)
      RETURN VARCHAR2
   IS
      CURSOR c_get_sqltext_newlines_hash
      IS
         SELECT   sql_text
             FROM v$sqltext_with_newlines
            WHERE hash_value = p_hash_value AND address = p_address
         ORDER BY piece;

      CURSOR c_get_sqltext_newlines_nohash
      IS
         SELECT   sql_text
             FROM v$sqltext_with_newlines
            WHERE address = p_address
         ORDER BY piece;

      CURSOR c_get_sql_hash
      IS
         SELECT sql_text
           FROM v$sql
          WHERE hash_value = p_hash_value AND address = p_address;

      l_sql     VARCHAR (32512) := '';            -- The Max supported by DOA
      n         NUMBER          := 0;
      --v1    NUMBER;
      --v2    NUMBER;
      --v3    NUMBER;
      VERSION   VARCHAR2 (10);
   BEGIN
      IF full_version IS NULL
      THEN                        -- We don't initialize all sessions in ADK.
         full_version := dbversion;
      END IF;

      VERSION := SUBSTR (full_version, 1, INSTR (full_version, '.', 1, 3) - 1);

      --
      -- First try v$sqltext via hash; UNLESS the version
      -- is 8.1.5, in which case this will cause an infinite
      -- loop
      --
      --IF  exact_db_version(v1, v2, v3) NOT LIKE '8.1.5.%' THEN
      IF VERSION <> '8.1.5'
      THEN
         FOR r1 IN c_get_sqltext_newlines_hash
         LOOP
            l_sql := l_sql || r1.sql_text;
         END LOOP;
      END IF;

      --dbms_output.put_line('Found '||length(l_sql)||' from sqltext_newlines_hash');
      -- Get anything?  If not, try looking at v$sql
      IF LENGTH (l_sql) = 0 OR l_sql IS NULL
      THEN
         FOR r1 IN c_get_sql_hash
         LOOP
            l_sql := l_sql || r1.sql_text;
         END LOOP;

         --dbms_output.put_line('Found '||length(l_sql)||' from sql');

         --
         -- If we got nothing try v$sqltext_with_newlines but drop the hash
         -- Also do this if the text is greater than 1000 bytes
         --
         -- l_sql:='';
         IF LENGTH (l_sql) = 0 OR LENGTH (l_sql) >= 999 OR l_sql IS NULL
         THEN
            FOR r1 IN c_get_sqltext_newlines_nohash
            LOOP
               l_sql := l_sql || r1.sql_text;
            END LOOP;
         --dbms_output.put_line('Found '||length(l_sql)||' from sqltext_newlines_nohash');
         END IF;
      END IF;

      --
      -- That's all folks.....
      --
      RETURN (REPLACE (l_sql, CHR (0)));
   -- ADK can't handle a NULL character in a string.
   EXCEPTION
      WHEN VALUE_ERROR
      THEN
         -- Pretty unlikely that we'll see statmenets > 32K, but if we do....
         RETURN (REPLACE (l_sql, CHR (0)));
   -- ADK can't handle a NULL character in a string.
   END;

   --
   -- This function returns the long SQL text string.  It attempts this in a
   -- number of ways to work around problems with hash values in various
   -- releases of Oracle
   --
   FUNCTION get_session_long_sqltext (p_sid NUMBER)
      RETURN VARCHAR2
   IS
      CURSOR c_sess
      IS
         SELECT sql_hash_value, sql_address, prev_hash_value, prev_sql_addr
           FROM v$session
          WHERE SID = p_sid;

      r   c_sess%ROWTYPE;
   BEGIN
      OPEN c_sess;

      FETCH c_sess
       INTO r;

      CLOSE c_sess;

      IF NVL (r.sql_hash_value, 0) <> 0
      THEN
         RETURN (get_long_sqltext (r.sql_hash_value, r.sql_address));
      ELSE
         RETURN (get_long_sqltext (r.prev_hash_value, r.prev_sql_addr));
      END IF;
   END;

   FUNCTION lock_type_decode (type_p VARCHAR2, id2_p NUMBER DEFAULT -1)
      RETURN VARCHAR2
   IS
      return_string   VARCHAR2 (100);
   BEGIN

      IF lock_type_tab.EXISTS(type_p) THEN
      	return_string := lock_type_tab(type_p);
      END IF;

      IF return_string IS NULL THEN

		  -- TODO:  better to go against v$lock_type but this view only came in
		  -- in 10g
		  IF type_p = 'PE'
		  THEN
			 return_string := 'Parameter';
		  ELSIF type_p = 'PG'
		  THEN
			 return_string := 'Global Parameter';
		  ELSIF type_p = 'PV'
		  THEN
			 return_string := 'KSV slave startup';
		  ELSIF type_p = 'AS'
		  THEN
			 return_string := 'Service Operations';
		  ELSIF type_p = 'PD'
		  THEN
			 return_string := 'Property Lock';
		  ELSIF type_p = 'CF'
		  THEN
			 return_string := 'Controlfile Transaction';
		  ELSIF type_p = 'PW'
		  THEN
			 return_string := 'Buffer Cache PreWarm';
		  ELSIF type_p = 'RO'
		  THEN
			 return_string := 'Multiple Object Reuse';
		  ELSIF type_p = 'WS'
		  THEN
			 return_string := 'LogWriter Standby';
		  ELSIF type_p = 'WL'
		  THEN
			 return_string := 'Being Written Redo Log';
		  ELSIF type_p = 'DF'
		  THEN
			 return_string := 'Datafile Online in RAC';
		  ELSIF type_p = 'PL'
		  THEN
			 return_string := 'Transportable Tablespace';
		  ELSIF type_p = 'XR'
		  THEN
			 return_string := 'Quiesce / Force Logging';
		  ELSIF type_p = 'TA'
		  THEN
			 return_string := 'Instance Undo';
		  ELSIF type_p = 'TE'
		  THEN
			 return_string := 'KTF broadcast';
		  ELSIF type_p = 'RW'
		  THEN
			 return_string := 'Materialized View Flags';
		  ELSIF type_p = 'PI'
		  THEN
			 return_string := 'Remote PX Process Spawn Status';
		  ELSIF type_p = 'PS'
		  THEN
			 return_string := 'PX Process Reservation';
		  ELSIF type_p = 'PT'
		  THEN
			 return_string := 'ASM Partnership and Status Table';
		  ELSIF type_p = 'PM'
		  THEN
			 return_string := 'ASM PST Signalling';
		  ELSIF type_p = 'SH'
		  THEN
			 return_string := 'Active Session History Flushing';
		  ELSIF type_p = 'BL'
		  THEN
			 return_string := 'Buffer hash table instance lock';
		  ELSIF type_p = 'CF'
		  THEN
			 return_string := 'Control file schema global enqueue lock';
		  ELSIF type_p = 'CI'
		  THEN
			 return_string := 'Cross-instance function invocation instance lock';
		  ELSIF type_p = 'CS'
		  THEN
			 return_string := 'Control file schema global enqueue lock';
		  ELSIF type_p = 'CU'
		  THEN
			 return_string := 'Cursor bind lock';
		  ELSIF type_p = 'DF'
		  THEN
			 return_string := 'Data file instance lock';
		  ELSIF type_p = 'DL'
		  THEN
			 return_string := 'Direct loader parallel index create';
		  ELSIF type_p = 'DM'
		  THEN
			 return_string := 'Mount/startup db primary/secondary instance lock';
		  ELSIF type_p = 'DR'
		  THEN
			 return_string := 'Distributed recovery process lock';
		  ELSIF type_p = 'DX'
		  THEN
			 return_string := 'Distributed transaction entry lock';
		  ELSIF type_p = 'FI'
		  THEN
			 return_string := 'SGA open-file information lock';
		  ELSIF type_p = 'FS'
		  THEN
			 return_string := 'File set lock';
		  ELSIF type_p = 'HW'
		  THEN
			 return_string :=
						 'Space management operations on a specific segment lock';
		  ELSIF type_p = 'IN'
		  THEN
			 return_string := 'Instance number lock';
		  ELSIF type_p = 'IR'
		  THEN
			 return_string :=
							'Instance recovery serialization global enqueue lock';
		  ELSIF type_p = 'IS'
		  THEN
			 return_string := 'Instance state lock';
		  ELSIF type_p = 'IV'
		  THEN
			 return_string := 'Library cache invalidation instance lock';
		  ELSIF type_p = 'JQ'
		  THEN
			 return_string := 'Job queue lock';
		  ELSIF type_p = 'KK'
		  THEN
			 return_string := 'Thread kick lock';
		  ELSIF type_p = 'MB'
		  THEN
			 return_string := 'Master buffer hash table instance lock';
		  ELSIF type_p = 'MM'
		  THEN
			 return_string := 'Mount definition gloabal enqueue lock';
		  ELSIF type_p = 'MR'
		  THEN
			 return_string := 'Media recovery lock';
		  ELSIF type_p = 'PF'
		  THEN
			 return_string := 'Password file lock';
		  ELSIF type_p = 'PI'
		  THEN
			 return_string := 'Parallel operation lock PI';
		  ELSIF type_p = 'PR'
		  THEN
			 return_string := 'Process startup lock';
		  ELSIF type_p = 'PS'
		  THEN
			 return_string := 'Parallel operation lock PS';
		  ELSIF type_p = 'RE'
		  THEN
			 return_string := 'USE_ROW_ENQUEUE enforcement lock';
		  ELSIF type_p = 'RT'
		  THEN
			 return_string := 'Redo thread global enqueue lock';
		  ELSIF type_p = 'RW'
		  THEN
			 return_string := 'Row wait enqueue lock';
		  ELSIF type_p = 'SC'
		  THEN
			 return_string := 'System commit number instance lock';
		  ELSIF type_p = 'SH'
		  THEN
			 return_string := 'System commit number high water mark enqueue lock';
		  ELSIF type_p = 'SM'
		  THEN
			 return_string := 'SMON lock';
		  ELSIF type_p = 'SN'
		  THEN
			 return_string := 'Sequence number instance lock';
		  ELSIF type_p = 'SQ'
		  THEN
			 return_string := 'Sequence number enqueue lock';
		  ELSIF type_p = 'SS'
		  THEN
			 return_string := 'Sort segment lock';
		  ELSIF type_p = 'ST'
		  THEN
			 return_string := 'Space transaction enqueue lock';
		  ELSIF type_p = 'SV'
		  THEN
			 return_string := 'Sequence number value lock';
		  ELSIF type_p = 'TA'
		  THEN
			 return_string := 'Generic enqueue lock';
		  ELSIF type_p = 'TD'
		  THEN
			 return_string := 'DDL enqueue lock';
		  ELSIF type_p = 'TE'
		  THEN
			 return_string := 'Extend-segment enqueue lock';
		  ELSIF type_p = 'TM'
		  THEN
			 return_string := 'DML enqueue lock';
		  ELSIF type_p = 'TO'
		  THEN
			 return_string := 'Temporary object operations lock';
		  ELSIF type_p = 'TT'
		  THEN
			 return_string := 'Temporary table enqueue lock';
		  ELSIF type_p = 'TX'
		  THEN
			 return_string := 'Transaction enqueue lock';
		  ELSIF type_p = 'UL'
		  THEN
			 return_string := 'User supplied lock';
		  ELSIF type_p = 'UN'
		  THEN
			 return_string := 'User name lock';
		  ELSIF type_p = 'US'
		  THEN
			 return_string := 'Undo segment DDL lock';
		  ELSIF type_p = 'WL'
		  THEN
			 return_string := 'Being-written redo log instance lock';
		  ELSIF type_p = 'WS'
		  THEN
			 return_string := 'Write-atomic-log-switch global enqueue lock';
		  ELSIF type_p = 'TS'
		  THEN
			 return_string :=
						 'Temporary segment or new block allocation enqueue lock';
		  ELSIF type_p = 'LS'
		  THEN
			 return_string := 'Log start/log switch enqueue lock';
		  ELSIF type_p = 'DT'
		  THEN
			 return_string := 'Default Temporary Tablespace Enqueue';
		  ELSIF type_p = 'DV'
		  THEN
			 return_string := 'Diana Version Enqueue';
		  ELSIF type_p = 'IA'
		  THEN
			 return_string := 'Internet Application Server Enqueue';
		  ELSIF type_p = 'KM'
		  THEN
			 return_string := 'Scheduler Modification and Loading Enqueue';
		  ELSIF type_p = 'KT'
		  THEN
			 return_string := 'Scheduler Top Plan Enqueue';
		  ELSIF type_p = 'SR'
		  THEN
			 return_string := 'Synchronized Replication Enqueue';
		  ELSIF type_p = 'MD'
		  THEN
			 return_string := 'Change Data Capture Materialized View Log';
		  ELSIF type_p = 'JD'
		  THEN
			 return_string := 'DBMS Jobs enqueue/lock';
		  ELSIF type_p = 'FB'
		  THEN
			 return_string :=
							'Formatting a range of Bitmap Blocks (BMBs) for ASSM';
		  ELSIF type_p = 'SW'
		  THEN
			 return_string := 'Suspend Writes (ALTER SYSTEM SUSPEND|RESUME)';
		  ELSIF type_p = 'XR'
		  THEN
			 return_string :=
				'ALTER SYSTEM QUIESCE RESTRICTED enqueue or ALTER DATABASE OPEN in RAC mode enqueue';
		  ELSIF type_p = 'AF'
		  THEN
			 return_string := 'Advisor task lock';
		  ELSIF type_p = 'AG'
		  THEN
			 return_string := 'Workspace lock';
		  ELSIF type_p = 'AS'
		  THEN
			 return_string := 'New service activation';
		  ELSIF type_p = 'AW'
		  THEN
			 return_string := 'Workspace AW$ table access lock';
		  ELSIF type_p = 'CT'
		  THEN
			 return_string := 'Change tracking lock';
		  ELSIF type_p = 'DP'
		  THEN
			 return_string := 'LDAP parameters access lock';
		  ELSIF type_p = 'FU'
		  THEN
			 return_string := 'Capture of the DB Feature Usage and HWM Stat lock';
		  ELSIF type_p = 'IT'
		  THEN
			 return_string := 'Temp table meta-data pinning/recreation lock';
		  ELSIF type_p = 'JS'
		  THEN
			 return_string := 'Job cache lock';
		  ELSIF type_p = 'MN'
		  THEN
			 return_string := 'LogMiner dictionary and synchronize lock';
		  ELSIF type_p = 'MW'
		  THEN
			 return_string :=
				'Calibration of the manageability schedules with the Maintenance Window';
		  ELSIF type_p = 'RO'
		  THEN
			 return_string := 'Coordinates flushing of multiple objects lock';
		  ELSIF type_p = 'RS'
		  THEN
			 return_string := 'Space reclaimable operations lock';
		  ELSIF type_p = 'TB'
		  THEN
			 return_string :=
							 'Writes to the SQL Tuning Base Existence Cache lock';
		  ELSIF type_p = 'TC'
		  THEN
			 return_string := 'Tablespace checkpoint lock';
		  ELSIF type_p = 'TL'
		  THEN
			 return_string := 'Threshold log table lock';
		  ELSIF type_p = 'TQ'
		  THEN
			 return_string := 'Queue table lock';
		  ELSIF type_p = 'WF'
		  THEN
			 return_string := 'Flushing of snapshots lock';
		  ELSIF type_p = 'WP'
		  THEN
			 return_string := 'Purging and baselines lock';
		  ELSIF type_p = 'LA'
		  THEN
			 return_string := 'Library cache lock instance lock (A=namespace)';
		  ELSIF type_p = 'LB'
		  THEN
			 return_string := 'Library cache lock instance lock (B=namespace)';
		  ELSIF type_p = 'LC'
		  THEN
			 return_string := 'Library cache lock instance lock (C=namespace)';
		  ELSIF type_p = 'LD'
		  THEN
			 return_string := 'Library cache lock instance lock (D=namespace)';
		  ELSIF type_p = 'LE'
		  THEN
			 return_string := 'Library cache lock instance lock (E=namespace)';
		  ELSIF type_p = 'LF'
		  THEN
			 return_string := 'Library cache lock instance lock (F=namespace)';
		  ELSIF type_p = 'LG'
		  THEN
			 return_string := 'Library cache lock instance lock (G=namespace)';
		  ELSIF type_p = 'LH'
		  THEN
			 return_string := 'Library cache lock instance lock (H=namespace)';
		  ELSIF type_p = 'LI'
		  THEN
			 return_string := 'Library cache lock instance lock (I=namespace)';
		  ELSIF type_p = 'LJ'
		  THEN
			 return_string := 'Library cache lock instance lock (J=namespace)';
		  ELSIF type_p = 'LK'
		  THEN
			 return_string := 'Library cache lock instance lock (K=namespace)';
		  ELSIF type_p = 'LL'
		  THEN
			 return_string := 'Library cache lock instance lock (L=namespace)';
		  ELSIF type_p = 'LM'
		  THEN
			 return_string := 'Library cache lock instance lock (M=namespace)';
		  ELSIF type_p = 'LN'
		  THEN
			 return_string := 'Library cache lock instance lock (N=namespace)';
		  ELSIF type_p = 'LO'
		  THEN
			 return_string := 'Library cache lock instance lock (O=namespace)';
		  ELSIF type_p = 'LP'
		  THEN
			 return_string := 'Library cache lock instance lock (P=namespace)';
		  ELSIF type_p = 'PA'
		  THEN
			 return_string := 'Library cache pin instance lock (A=namespace)';
		  ELSIF type_p = 'PB'
		  THEN
			 return_string := 'Library cache pin instance lock (B=namespace)';
		  ELSIF type_p = 'PC'
		  THEN
			 return_string := 'Library cache pin instance lock (C=namespace)';
		  ELSIF type_p = 'PD'
		  THEN
			 return_string := 'Library cache pin instance lock (D=namespace)';
		  ELSIF type_p = 'PE'
		  THEN
			 return_string := 'Library cache pin instance lock (E=namespace)';
		  ELSIF type_p = 'PF'
		  THEN
			 return_string := 'Library cache pin instance lock (F=namespace)';
		  ELSIF type_p = 'PG'
		  THEN
			 return_string := 'Library cache pin instance lock (G=namespace)';
		  ELSIF type_p = 'PH'
		  THEN
			 return_string := 'Library cache pin instance lock (H=namespace)';
		  ELSIF type_p = 'PI'
		  THEN
			 return_string := 'Library cache pin instance lock (I=namespace)';
		  ELSIF type_p = 'PJ'
		  THEN
			 return_string := 'Library cache pin instance lock (J=namespace)';
		  ELSIF type_p = 'PL'
		  THEN
			 return_string := 'Library cache pin instance lock (K=namespace)';
		  ELSIF type_p = 'PK'
		  THEN
			 return_string := 'Library cache pin instance lock (L=namespace)';
		  ELSIF type_p = 'PM'
		  THEN
			 return_string := 'Library cache pin instance lock (M=namespace)';
		  ELSIF type_p = 'PN'
		  THEN
			 return_string := 'Library cache pin instance lock (N=namespace)';
		  ELSIF type_p = 'PO'
		  THEN
			 return_string := 'Library cache pin instance lock (O=namespace)';
		  ELSIF type_p = 'PP'
		  THEN
			 return_string := 'Library cache pin instance lock (P=namespace)';
		  ELSIF type_p = 'PQ'
		  THEN
			 return_string := 'Library cache pin instance lock (Q=namespace)';
		  ELSIF type_p = 'PR'
		  THEN
			 return_string := 'Library cache pin instance lock (R=namespace)';
		  ELSIF type_p = 'PS'
		  THEN
			 return_string := 'Library cache pin instance lock (S=namespace)';
		  ELSIF type_p = 'PT'
		  THEN
			 return_string := 'Library cache pin instance lock (T=namespace)';
		  ELSIF type_p = 'PU'
		  THEN
			 return_string := 'Library cache pin instance lock (U=namespace)';
		  ELSIF type_p = 'PV'
		  THEN
			 return_string := 'Library cache pin instance lock (V=namespace)';
		  ELSIF type_p = 'PW'
		  THEN
			 return_string := 'Library cache pin instance lock (W=namespace)';
		  ELSIF type_p = 'PX'
		  THEN
			 return_string := 'Library cache pin instance lock (X=namespace)';
		  ELSIF type_p = 'PY'
		  THEN
			 return_string := 'Library cache pin instance lock (Y=namespace)';
		  ELSIF type_p = 'PZ'
		  THEN
			 return_string := 'Library cache pin instance lock (Z=namespace)';
		  ELSIF type_p = 'QA'
		  THEN
			 return_string := 'Row cache instance lock (A=cache)';
		  ELSIF type_p = 'QB'
		  THEN
			 return_string := 'Row cache instance lock (B=cache)';
		  ELSIF type_p = 'QC'
		  THEN
			 return_string := 'Row cache instance lock (C=cache)';
		  ELSIF type_p = 'QD'
		  THEN
			 return_string := 'Row cache instance lock (D=cache)';
		  ELSIF type_p = 'QE'
		  THEN
			 return_string := 'Row cache instance lock (E=cache)';
		  ELSIF type_p = 'QF'
		  THEN
			 return_string := 'Row cache instance lock (F=cache)';
		  ELSIF type_p = 'QG'
		  THEN
			 return_string := 'Row cache instance lock (G=cache)';
		  ELSIF type_p = 'QH'
		  THEN
			 return_string := 'Row cache instance lock (H=cache)';
		  ELSIF type_p = 'QI'
		  THEN
			 return_string := 'Row cache instance lock (I=cache)';
		  ELSIF type_p = 'QJ'
		  THEN
			 return_string := 'Row cache instance lock (J=cache)';
		  ELSIF type_p = 'QL'
		  THEN
			 return_string := 'Row cache instance lock (K=cache)';
		  ELSIF type_p = 'QK'
		  THEN
			 return_string := 'Row cache instance lock (L=cache)';
		  ELSIF type_p = 'QM'
		  THEN
			 return_string := 'Row cache instance lock (M=cache)';
		  ELSIF type_p = 'QN'
		  THEN
			 return_string := 'Row cache instance lock (N=cache)';
		  ELSIF type_p = 'QO'
		  THEN
			 return_string := 'Row cache instance lock (O=cache)';
		  ELSIF type_p = 'QP'
		  THEN
			 return_string := 'Row cache instance lock (P=cache)';
		  ELSIF type_p = 'QQ'
		  THEN
			 return_string := 'Row cache instance lock (Q=cache)';
		  ELSIF type_p = 'QR'
		  THEN
			 return_string := 'Row cache instance lock (R=cache)';
		  ELSIF type_p = 'QS'
		  THEN
			 return_string := 'Row cache instance lock (S=cache)';
		  ELSIF type_p = 'QT'
		  THEN
			 return_string := 'Row cache instance lock (T=cache)';
		  ELSIF type_p = 'QU'
		  THEN
			 return_string := 'Row cache instance lock (U=cache)';
		  ELSIF type_p = 'QV'
		  THEN
			 return_string := 'Row cache instance lock (V=cache)';
		  ELSIF type_p = 'QW'
		  THEN
			 return_string := 'Row cache instance lock (W=cache)';
		  ELSIF type_p = 'QX'
		  THEN
			 return_string := 'Row cache instance lock (X=cache)';
		  ELSIF type_p = 'QY'
		  THEN
			 return_string := 'Row cache instance lock (Y=cache)';
		  ELSIF type_p = 'QZ'
		  THEN
			 return_string := 'Row cache instance lock (Z=cache)';
		  ELSIF type_p = 'SJ'
		  THEN
			 return_string := 'KTSJ Slave Task Cancel';
		  ELSIF type_p = 'RR'
		  THEN
			 return_string := 'Workload Capture and Replay';
		  ELSIF type_p = 'CN'
		  THEN
			 return_string := 'KTCN REG enq';
		  ELSIF type_p = 'SE'
		  THEN
			 return_string := 'Session Migration';
		  ELSIF type_p = 'TH'
		  THEN
			 return_string := 'Threshold Chain';
		  ELSIF type_p = 'RC'
		  THEN
			 return_string := 'Result Set Cache';
		  ELSIF type_p = 'AE'
		  THEN
			 return_string := 'Edition Lock';
		  ELSIF type_p = 'AK'
		  THEN
			 return_string := 'GES Deadlock Test';
		  ELSIF type_p = 'DI'
		  THEN
			 return_string := 'GES Internal';
		  ELSIF type_p = 'RM'
		  THEN
			 return_string := 'GES Resource Remastering';
		  ELSIF type_p = 'FP'
		  THEN
			 return_string := 'File Object';
		  ELSIF type_p = 'FM'
		  THEN
			 return_string := 'File Mapping';
		  ELSIF type_p = 'XY'
		  THEN
			 return_string := 'Internal Test';
		  ELSIF type_p = 'RU'
		  THEN
			 return_string := 'Rolling Upgrade';
		  ELSIF type_p = 'DS'
		  THEN
			 return_string := 'Database Suspend';
		  ELSIF type_p = 'KO'
		  THEN
			 return_string := 'Multiple Object Checkpoint';
		  ELSIF type_p = 'WR'
		  THEN
			 return_string := 'LNS archiving log';
		  ELSIF type_p = 'RN'
		  THEN
			 return_string := 'Redo Log Nab Computation';
		  ELSIF type_p = 'RP'
		  THEN
			 return_string := 'Resilver / Repair';
		  ELSIF type_p = 'BR'
		  THEN
			 return_string := 'Backup/Restore';
		  ELSIF type_p = 'ID'
		  THEN
			 return_string := 'NID';
		  ELSIF type_p = 'SB'
		  THEN
			 return_string := 'LogicalStandby';
		  ELSIF type_p = 'FL'
		  THEN
			 return_string := 'Flashback database log';
		  ELSIF type_p = 'FD'
		  THEN
			 return_string := 'Flashback Database';
		  ELSIF type_p = 'FW'
		  THEN
			 return_string := 'Flashback Writer';
		  ELSIF type_p = 'TF'
		  THEN
			 return_string := 'Temporary File';
		  ELSIF type_p = 'SK'
		  THEN
			 return_string := 'Shrink Segment';
		  ELSIF type_p = 'TW'
		  THEN
			 return_string := 'Cross-Instance Transaction';
		  ELSIF type_p = 'SU'
		  THEN
			 return_string := 'SaveUndo Segment';
		  ELSIF type_p = 'IM'
		  THEN
			 return_string := 'Kti blr lock';
		  ELSIF type_p = 'HV'
		  THEN
			 return_string := 'Direct Loader High Water Mark';
		  ELSIF type_p = 'HQ'
		  THEN
			 return_string := 'Hash Queue';
		  ELSIF type_p = 'HP'
		  THEN
			 return_string := 'Queue Page';
		  ELSIF type_p = 'Q '
		  THEN
			 return_string := 'Row Cache';
		  ELSIF type_p = 'V '
		  THEN
			 return_string := 'Library Cache Lock 3';
		  ELSIF type_p = 'E '
		  THEN
			 return_string := 'Library Cache Lock 2';
		  ELSIF type_p = 'L '
		  THEN
			 return_string := 'Library Cache Lock 1';
		  ELSIF type_p = 'Y '
		  THEN
			 return_string := 'Library Cache Pin 3';
		  ELSIF type_p = 'G '
		  THEN
			 return_string := 'Library Cache Pin 2';
		  ELSIF type_p = 'N '
		  THEN
			 return_string := 'Library Cache Pin 1';
		  ELSIF type_p = 'OC'
		  THEN
			 return_string := 'Outline Cache';
		  ELSIF type_p = 'OL'
		  THEN
			 return_string := 'Outline Name';
		  ELSIF type_p = 'IL'
		  THEN
			 return_string := 'Label Security';
		  ELSIF type_p = 'CL'
		  THEN
			 return_string := 'Label Security cache';
		  ELSIF type_p = 'MK'
		  THEN
			 return_string := 'Master Key';
		  ELSIF type_p = 'OW'
		  THEN
			 return_string := 'Encryption Wallet';
		  ELSIF type_p = 'AU'
		  THEN
			 return_string := 'Audit index file';
		  ELSIF type_p = 'DB'
		  THEN
			 return_string := 'DbsDriver';
		  ELSIF type_p = 'MS'
		  THEN
			 return_string := 'Materialized View Refresh Log';
		  ELSIF type_p = 'BF'
		  THEN
			 return_string := 'BLOOM FILTER';
		  ELSIF type_p = 'KP'
		  THEN
			 return_string := 'Kupp Process Startup';
		  ELSIF type_p = 'SI'
		  THEN
			 return_string := 'Streams Table Instantiation';
		  ELSIF type_p = 'ZG'
		  THEN
			 return_string := 'File Group';
		  ELSIF type_p = 'JI'
		  THEN
			 return_string := 'Materialized View';
		  ELSIF type_p = 'AT'
		  THEN
			 return_string := 'Alter Tablespace';
		  ELSIF type_p = 'MH'
		  THEN
			 return_string := 'AQ Notification Mail Host';
		  ELSIF type_p = 'ML'
		  THEN
			 return_string := 'AQ Notification Mail Port';
		  ELSIF type_p = 'SF'
		  THEN
			 return_string := 'AQ Notification Sender';
		  ELSIF type_p = 'XH'
		  THEN
			 return_string := 'AQ Notification No-Proxy';
		  ELSIF type_p = 'WA'
		  THEN
			 return_string := 'AQ Notification Watermark';
		  ELSIF type_p = 'RF'
		  THEN
			 return_string := 'Data Guard Broker';
		  ELSIF type_p = 'AO'
		  THEN
			 return_string := 'MultiWriter Object Access';
		  ELSIF type_p = 'OQ'
		  THEN
			 return_string := 'OLAPI Histories';
		  ELSIF type_p = 'IZ'
		  THEN
			 return_string := 'INSTANCE LOCK';
		  ELSIF type_p = 'AM'
		  THEN
			 return_string := 'ASM Enqueue';
		  ELSIF type_p = 'CM'
		  THEN
			 return_string := 'ASM Instance Enqueue';
		  ELSIF type_p = 'XQ'
		  THEN
			 return_string := 'ASM Extent Relocation Enqueue';
		  ELSIF type_p = 'AD'
		  THEN
			 return_string := 'ASM Disk AU Lock';
		  ELSIF type_p = 'DG'
		  THEN
			 return_string := 'ASM Disk Group Modification';
		  ELSIF type_p = 'DD'
		  THEN
			 return_string := 'ASM Local Disk Group';
		  ELSIF type_p = 'HD'
		  THEN
			 return_string := 'ASM Disk Header';
		  ELSIF type_p = 'DQ'
		  THEN
			 return_string := 'ASM RBAL doorbell';
		  ELSIF type_p = 'DN'
		  THEN
			 return_string := 'Diskgroup number generator';
		  ELSIF type_p = 'FA'
		  THEN
			 return_string := 'ASM File Access Lock';
		  ELSIF type_p = 'FR'
		  THEN
			 return_string := 'Disk Group Recovery';
		  ELSIF type_p = 'FG'
		  THEN
			 return_string := 'ACD Relocation Gate Enqueue';
		  ELSIF type_p = 'FT'
		  THEN
			 return_string := 'Disk Group Redo Generation';
		  ELSIF type_p = 'FC'
		  THEN
			 return_string := 'Disk Group Chunk Mount';
		  ELSIF type_p = 'RB'
		  THEN
			 return_string := 'ASM Rollback Recovery';
		  ELSE
			 return_string := type_p;
		  END IF;
		END IF;

      /*  SELECT DECODE
                  (type_p,
                   'BL', 'Buffer hash table instance lock',
                   'CF', 'Control file schema global enqueue lock',
                   'CI', 'Cross-instance function invocation instance lock',
                   'CS', 'Control file schema global enqueue lock',
                   'CU', 'Cursor bind lock',
                   'DF', 'Data file instance lock',
                   'DL', 'Direct loader parallel index create',
                   'DM', 'Mount/startup db primary/secondary instance lock',
                   'DR', 'Distributed recovery process lock',
                   'DX', 'Distributed transaction entry lock',
                   'FI', 'SGA open-file information lock',
                   'FS', 'File set lock',
                   'HW', 'Space management operations on a specific segment lock',
                   'IN', 'Instance number lock',
                   'IR', 'Instance recovery serialization global enqueue lock',
                   'IS', 'Instance state lock',
                   'IV', 'Library cache invalidation instance lock',
                   'JQ', 'Job queue lock',
                   'KK', 'Thread kick lock',
                   'MB', 'Master buffer hash table instance lock',
                   'MM', 'Mount definition gloabal enqueue lock',
                   'MR', 'Media recovery lock',
                   'PF', 'Password file lock',
                   'PI', 'Parallel operation lock PI',
                   'PR', 'Process startup lock',
                   'PS', 'Parallel operation lock PS',
                   'RE', 'USE_ROW_ENQUEUE enforcement lock',
                   'RT', 'Redo thread global enqueue lock',
                   'RW', 'Row wait enqueue lock',
                   'SC', 'System commit number instance lock',
                   'SH', 'System commit number high water mark enqueue lock',
                   'SM', 'SMON lock',
                   'SN', 'Sequence number instance lock',
                   'SQ', 'Sequence number enqueue lock',
                   'SS', 'Sort segment lock',
                   'ST', 'Space transaction enqueue lock',
                   'SV', 'Sequence number value lock',
                   'TA', 'Generic enqueue lock',
                   'TD', 'DDL enqueue lock',
                   'TE', 'Extend-segment enqueue lock',
                   'TM', 'DML enqueue lock',
                   'TO', 'Temporary object operations lock',
                   'TT', 'Temporary table enqueue lock',
                   'TX', 'Transaction enqueue lock',
                   'UL', 'User supplied lock',
                   'UN', 'User name lock',
                   'US', 'Undo segment DDL lock',
                   'WL', 'Being-written redo log instance lock',
                   'WS', 'Write-atomic-log-switch global enqueue lock',
                   'TS', 'Temporary segment or new block allocation enqueue lock',
                   'LS', 'Log start/log switch enqueue lock',
                   'DT', 'Default Temporary Tablespace Enqueue',
                   'DV', 'Diana Version Enqueue',
                   'IA', 'Internet Application Server Enqueue',
                   'KM', 'Scheduler Modification and Loading Enqueue',
                   'KT', 'Scheduler Top Plan Enqueue',
                   'SR', 'Synchronized Replication Enqueue',
                   'MD', 'Change Data Capture Materialized View Log',
                   'JD', 'DBMS Jobs enqueue/lock',
                   'FB', 'Formatting a range of Bitmap Blocks (BMBs) for ASSM',
                   'SW', 'Suspend Writes (ALTER SYSTEM SUSPEND|RESUME)',
                   'XR', 'ALTER SYSTEM QUIESCE RESTRICTED enqueue or ALTER DATABASE OPEN in RAC mode enqueue',
                   'AF', 'Advisor task lock',
                   'AG', 'Workspace lock',
                   'AS', 'New service activation',
                   'AW', 'Workspace AW$ table access lock',
                   'CT', 'Change tracking lock',
                   'DP', 'LDAP parameters access lock',
                   'FU', 'Capture of the DB Feature Usage and HWM Stat lock',
                   'IT', 'Temp table meta-data pinning/recreation lock',
                   'JS', 'Job cache lock',
                   'MN', 'LogMiner dictionary and synchronize lock',
                   'MW', 'Calibration of the manageability schedules with the Maintenance Window',
                   'RO', 'Coordinates flushing of multiple objects lock',
                   'RS', 'Space reclaimable operations lock',
                   'TB', 'Writes to the SQL Tuning Base Existence Cache lock',
                   'TC', 'Tablespace checkpoint lock',
                   'TL', 'Threshold log table lock',
                   'TQ', 'Queue table lock',
                   'WF', 'Flushing of snapshots lock',
                   'WP', 'Purging and baselines lock',
                   DECODE (type_p,
                           'LA', 'Library cache lock instance lock (A=namespace)',
                           'LB', 'Library cache lock instance lock (B=namespace)',
                           'LC', 'Library cache lock instance lock (C=namespace)',
                           'LD', 'Library cache lock instance lock (D=namespace)',
                           'LE', 'Library cache lock instance lock (E=namespace)',
                           'LF', 'Library cache lock instance lock (F=namespace)',
                           'LG', 'Library cache lock instance lock (G=namespace)',
                           'LH', 'Library cache lock instance lock (H=namespace)',
                           'LI', 'Library cache lock instance lock (I=namespace)',
                           'LJ', 'Library cache lock instance lock (J=namespace)',
                           'LK', 'Library cache lock instance lock (K=namespace)',
                           'LL', 'Library cache lock instance lock (L=namespace)',
                           'LM', 'Library cache lock instance lock (M=namespace)',
                           'LN', 'Library cache lock instance lock (N=namespace)',
                           'LO', 'Library cache lock instance lock (O=namespace)',
                           'LP', 'Library cache lock instance lock (P=namespace)',
                           'PA', 'Library cache pin instance lock (A=namespace)',
                           'PB', 'Library cache pin instance lock (B=namespace)',
                           'PC', 'Library cache pin instance lock (C=namespace)',
                           'PD', 'Library cache pin instance lock (D=namespace)',
                           'PE', 'Library cache pin instance lock (E=namespace)',
                           'PF', 'Library cache pin instance lock (F=namespace)',
                           'PG', 'Library cache pin instance lock (G=namespace)',
                           'PH', 'Library cache pin instance lock (H=namespace)',
                           'PI', 'Library cache pin instance lock (I=namespace)',
                           'PJ', 'Library cache pin instance lock (J=namespace)',
                           'PL', 'Library cache pin instance lock (K=namespace)',
                           'PK', 'Library cache pin instance lock (L=namespace)',
                           'PM', 'Library cache pin instance lock (M=namespace)',
                           'PN', 'Library cache pin instance lock (N=namespace)',
                           'PO', 'Library cache pin instance lock (O=namespace)',
                           'PP', 'Library cache pin instance lock (P=namespace)',
                           'PQ', 'Library cache pin instance lock (Q=namespace)',
                           'PR', 'Library cache pin instance lock (R=namespace)',
                           'PS', 'Library cache pin instance lock (S=namespace)',
                           'PT', 'Library cache pin instance lock (T=namespace)',
                           'PU', 'Library cache pin instance lock (U=namespace)',
                           'PV', 'Library cache pin instance lock (V=namespace)',
                           'PW', 'Library cache pin instance lock (W=namespace)',
                           'PX', 'Library cache pin instance lock (X=namespace)',
                           'PY', 'Library cache pin instance lock (Y=namespace)',
                           'PZ', 'Library cache pin instance lock (Z=namespace)',
                           'QA', 'Row cache instance lock (A=cache)',
                           'QB', 'Row cache instance lock (B=cache)',
                           'QC', 'Row cache instance lock (C=cache)',
                           'QD', 'Row cache instance lock (D=cache)',
                           'QE', 'Row cache instance lock (E=cache)',
                           'QF', 'Row cache instance lock (F=cache)',
                           'QG', 'Row cache instance lock (G=cache)',
                           'QH', 'Row cache instance lock (H=cache)',
                           'QI', 'Row cache instance lock (I=cache)',
                           'QJ', 'Row cache instance lock (J=cache)',
                           'QL', 'Row cache instance lock (K=cache)',
                           'QK', 'Row cache instance lock (L=cache)',
                           'QM', 'Row cache instance lock (M=cache)',
                           'QN', 'Row cache instance lock (N=cache)',
                           'QO', 'Row cache instance lock (O=cache)',
                           'QP', 'Row cache instance lock (P=cache)',
                           'QQ', 'Row cache instance lock (Q=cache)',
                           'QR', 'Row cache instance lock (R=cache)',
                           'QS', 'Row cache instance lock (S=cache)',
                           'QT', 'Row cache instance lock (T=cache)',
                           'QU', 'Row cache instance lock (U=cache)',
                           'QV', 'Row cache instance lock (V=cache)',
                           'QW', 'Row cache instance lock (W=cache)',
                           'QX', 'Row cache instance lock (X=cache)',
                           'QY', 'Row cache instance lock (Y=cache)',
                           'QZ', 'Row cache instance lock (Z=cache)',
                           'SJ', 'KTSJ Slave Task Cancel',
                           'RR', 'Workload Capture and Replay',
                           'CN', 'KTCN REG enq',
                           'SE', 'Session Migration',
                           'TH', 'Threshold Chain',
                           'RC', 'Result Set Cache',
                           'AE', 'Edition Lock',
                           type_p
                          )
                  )
          INTO return_string
          FROM DUAL; */

      -- id2 is needed to distinct 'TS' lock.  -1 is used when id2 is not available
      IF type_p = 'TS' AND id2_p = 0
      THEN
         return_string := 'Temporary segment enqueue lock (id2=0)';
      END IF;

      IF type_p = 'TS' AND id2_p = 1
      THEN
         return_string := 'New block allocation enqueue lock (id2=1)';
      END IF;

      RETURN return_string;
   END;

   --
   -- I18N version
   --
   FUNCTION lock_type_decode_41 (type_p VARCHAR2, id2_p NUMBER DEFAULT -1)
      RETURN VARCHAR2
   IS
      return_string   VARCHAR2 (100);
   BEGIN
      return_string := type_p;

      -- id2 is needed to distinct 'TS' lock.  -1 is used when id2 is not available
      IF type_p = 'TS' AND id2_p = 0
      THEN
         return_string := 'T0';
      END IF;

      IF type_p = 'TS' AND id2_p = 1
      THEN
         return_string := 'T1';
      END IF;

      RETURN return_string;
   END;

   -- lock_mode is used for both the request mode and hold mode
   FUNCTION lock_mode_decode (mode_p NUMBER)
      RETURN VARCHAR2
   IS
      return_string   VARCHAR2 (20);
   BEGIN
      SELECT DECODE (mode_p,
                     0, 'None',                      /* Mon Lock equivalent */
                     1, 'Null',                                        /* N */
                     2, 'Row-S (SS)',                                  /* L */
                     3, 'Row-X (SX)',                                  /* R */
                     4, 'Share',                                       /* S */
                     5, 'S/Row-X (SSX)',                               /* C */
                     6, 'Exclusive',                                   /* X */
                     TO_CHAR (mode_p)
                    )
        INTO return_string
        FROM DUAL;

      RETURN return_string;
   END;

   --
   -- lock_mode is used for both the request mode and hold mode
   -- I18N version
   --
   FUNCTION lock_mode_decode_41 (mode_p NUMBER)
      RETURN VARCHAR2
   IS
      return_string   VARCHAR2 (20);
   BEGIN
      SELECT DECODE (mode_p,
                     0, 'Q',                         /* Non Lock equivalent */
                     1, 'N',                                        /* Null */
                     2, 'L',                                  /* Row-S (SS) */
                     3, 'R',                                  /* Row-X (SX) */
                     4, 'S',                                       /* Share */
                     5, 'C',                               /* S/Row-X (SSX) */
                     6, 'X',                                   /* Exclusive */
                     TO_CHAR (mode_p)
                    )
        INTO return_string
        FROM DUAL;

      RETURN return_string;
   END;

   --
   -- Full table scan progress.  Called by event_detail() only, not externally published.
   --
   FUNCTION fts_progress (fileno_p NUMBER, blockno_p NUMBER)
      RETURN NUMBER
   IS
      seg_name      VARCHAR2 (120);
      current_ext   NUMBER         := 0;
      scanned_ext   NUMBER         := 0;
      total_ext     NUMBER         := 0;
      pct           NUMBER         := 0;
   BEGIN
      current_ext := get_ext_no (fileno_p, blockno_p);
      seg_name := get_seg_name (fileno_p, blockno_p);

      FOR i IN 1 .. object_cache_count
      LOOP
         IF (object_cache_segname (i) = seg_name)
         THEN
            IF (object_cache_extno (i) <= current_ext)
            THEN
               scanned_ext := scanned_ext + 1;
               total_ext := total_ext + 1;
            ELSE
               total_ext := total_ext + 1;
            END IF;
         END IF;
      END LOOP;

      pct := ROUND (100 * scanned_ext / total_ext, 2);
      RETURN pct;
   EXCEPTION
      WHEN ZERO_DIVIDE
      THEN
         RETURN 0;
   END;

   --
   -- Full table scan progress for I18N
   -- Called by event_detail_41() only, not externally published.
   --
   FUNCTION fts_progress_41 (fileno_p NUMBER, blockno_p NUMBER)
      RETURN NUMBER
   IS
      seg_name      VARCHAR2 (120);
      current_ext   NUMBER         := 0;
      scanned_ext   NUMBER         := 0;
      total_ext     NUMBER         := 0;
      pct           NUMBER         := 0;
   BEGIN
      current_ext := get_ext_no (fileno_p, blockno_p);
      seg_name := get_seg_name_41 (fileno_p, blockno_p);

      FOR i IN 1 .. object_cache_count
      LOOP
         IF (object_cache_segname (i) = seg_name)
         THEN
            IF (object_cache_extno (i) <= current_ext)
            THEN
               scanned_ext := scanned_ext + 1;
               total_ext := total_ext + 1;
            ELSE
               total_ext := total_ext + 1;
            END IF;
         END IF;
      END LOOP;

      pct := ROUND (100 * scanned_ext / total_ext, 2);
      RETURN pct;
   EXCEPTION
      WHEN ZERO_DIVIDE
      THEN
         RETURN 0;
   END;

   --
   -- event_details is used to decode wait event p1, p2, and p3
   --
   FUNCTION event_detail (
      event_p    IN   VARCHAR2,
      p1text_p   IN   VARCHAR2,
      p1_p       IN   NUMBER,
      p2text_p   IN   VARCHAR2 DEFAULT '',
      p2_p       IN   NUMBER DEFAULT 0,
      p3text_p   IN   VARCHAR2 DEFAULT '',
      p3_p       IN   NUMBER DEFAULT 0
   )
      RETURN VARCHAR2
   IS
      p1detail               VARCHAR2 (512);
      lock_type              VARCHAR2 (10);
      lock_mode              INTEGER;
      default_return_value   VARCHAR2 (2048) := '';
      return_value           VARCHAR2 (2048) := '';
      obj_name               VARCHAR2 (255);
      -- 'direct path read/write' events most likely will use temp file for sorting.
      -- v$tempfile does not exist before 8i.  Have to use a dynamic cursor to find out temp file name.
      tmp_file_stmt          VARCHAR2 (2048)
         := 'SELECT t.name FROM v$tempfile t, v$parameter p

                                                WHERE p.name = ''db_files'' AND t.file#=:file_no-p.value';
      ch                     INTEGER;
      rv                     INTEGER;
   BEGIN
      -- Set default return value first
      default_return_value := event_p;

      IF (LENGTH (RTRIM (p1text_p)) >= 2)
      THEN
         default_return_value :=
                      default_return_value || ', ' || p1text_p || '=' || p1_p;

         IF (LENGTH (RTRIM (p2text_p)) >= 2)
         THEN
            default_return_value :=
                      default_return_value || ', ' || p2text_p || '=' || p2_p;

            IF (LENGTH (RTRIM (p3text_p)) >= 2)
            THEN
               default_return_value :=
                      default_return_value || ', ' || p3text_p || '=' || p3_p;
            END IF;
         END IF;
      END IF;

      /*  Some events exist in all sorts of documents, but I can not find them in 7.3 - 9i.
          For example, dupl. cluster key.
          These events are excluded.
      */

      /**
       ** Regardless of what else we have, if the object# is given, use that
       */
      IF (   (p1text_p = 'file#' AND p2text_p = 'block#')
          OR (p1text_p = 'file number' AND p2text_p = 'first dba')
          OR event_p = 'DFS db file lock'
         )
      THEN
         BEGIN
            SELECT NAME
              INTO p1detail
              FROM v$dbfile
             WHERE file# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN         -- If file name is not found, it must be a temp file.
               BEGIN
                  ch := DBMS_SQL.open_cursor;
                  DBMS_SQL.parse (ch, tmp_file_stmt, DBMS_SQL.native);
                  DBMS_SQL.bind_variable (ch, 'file_no', p1_p);
                  DBMS_SQL.define_column (ch, 1, p1detail, 512);
                  rv := DBMS_SQL.EXECUTE (ch);
                  rv := DBMS_SQL.fetch_rows (ch);

                  IF rv > 0
                  THEN
                     DBMS_SQL.COLUMN_VALUE (ch, 1, p1detail);
                     DBMS_SQL.close_cursor (ch);
                  ELSE
                     DBMS_SQL.close_cursor (ch);
                  END IF;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     p1detail := 'file#=' || TO_CHAR (p1_p);
               END;
         END;

         IF (event_p = 'DFS db file lock')
         THEN
            return_value := p1detail;
         ELSE
            IF (    event_p = 'db file scattered read'
                AND g_object_cache_initialized = 1
               )
            THEN
               return_value :=
                     'file='
                  || p1detail
                  || ', '
                  || 'Full table scan on '
                  || get_seg_name (p1_p, p2_p)
                  || ', ('
                  || fts_progress (p1_p, p2_p)
                  || '% complete)';
            ELSE
               return_value :=
                            get_seg_name (p1_p, p2_p) || ', file='
                            || p1detail;
            END IF;
         END IF;
      -- lock events.  p1=name|mode
      ELSIF (event_p = 'enqueue' OR event_p LIKE 'enq:%')
      THEN
         lock_type :=
               CHR (BITAND (p1_p, -16777216) / 16777215)
            || CHR (BITAND (p1_p, 16711680) / 65535);
         lock_mode := BITAND (p1_p, 65535);

         BEGIN
            SELECT NAME
              INTO obj_name
              FROM SYS.obj$
             WHERE obj# = p2_p;

            return_value :=
                  lock_type_decode (lock_type)
               || ', mode:'
               || lock_mode_decode (lock_mode)
               || ', Object='
               || obj_name;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value :=
                     lock_type_decode (lock_type)
                  || ', mode:'
                  || lock_mode_decode (lock_mode);
         END;
      -- latch event.  p2=latch#
      ELSIF (event_p = 'latch activity' OR event_p = 'latch free')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$latchname
             WHERE latch# = p2_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := 'latch#=' || 'p2_p';
         END;
      -- buffer event.  p1=dba or p2=dba
      ELSIF (p1text_p = 'dba' OR p2text_p = 'dba')
      THEN
         IF (p1text_p = 'dba')
         THEN
            return_value :=
               get_seg_name (DBMS_UTILITY.data_block_address_file (p1_p),
                             DBMS_UTILITY.data_block_address_block (p1_p)
                            );
         ELSE
            return_value :=
               get_seg_name (DBMS_UTILITY.data_block_address_file (p2_p),
                             DBMS_UTILITY.data_block_address_block (p2_p)
                            );
         END IF;
      -- undo event.  p1=segment#
      ELSIF (event_p = 'undo segment recovery')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$rollname
             WHERE usn = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := 'RBS#=' || TO_CHAR (p1_p);
         END;
      -- This event is valid at lease in 7.2
      ELSIF (event_p = 'row cache lock')
      THEN
         BEGIN
            SELECT parameter
              INTO return_value
              FROM v$rowcache
             WHERE cache# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := 'cache#=' || TO_CHAR (p1_p);
         END;
      END IF;

      -- if the event is covered by above, we add p3 when available
      IF (LENGTH (RTRIM (return_value)) > 1)
      THEN
         IF (LENGTH (RTRIM (p3text_p)) > 1)
         THEN
            return_value :=
               event_p || ', ' || return_value || ', ' || p3text_p || '='
               || p3_p;
         ELSE
            return_value := event_p || ', ' || return_value;
         END IF;
      ELSE
         return_value := default_return_value;
      END IF;

      RETURN return_value;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN default_return_value;
   END;

   --
   -- event_details is used to decode wait event p1, p2, and p3
   -- I18N version
   --
   FUNCTION event_detail_41 (
      event_p    IN   VARCHAR2,
      p1text_p   IN   VARCHAR2,
      p1_p       IN   NUMBER,
      p2text_p   IN   VARCHAR2 DEFAULT '',
      p2_p       IN   NUMBER DEFAULT 0,
      p3text_p   IN   VARCHAR2 DEFAULT '',
      p3_p       IN   NUMBER DEFAULT 0
   )
      RETURN VARCHAR2
   IS
      p1detail               VARCHAR2 (512);
      lock_type              VARCHAR2 (10);
      lock_mode              INTEGER;
      default_return_value   VARCHAR2 (2048) := '';
      return_value           VARCHAR2 (2048) := '';
      obj_name               VARCHAR2 (255);
      -- 'direct path read/write' events most likely will use temp file for sorting.
      -- v$tempfile does not exist before 8i.  Have to use a dynamic cursor to find out temp file name.
      tmp_file_stmt          VARCHAR2 (2048)
         := 'SELECT t.name FROM v$tempfile t, v$parameter p

                                                WHERE p.name = ''db_files'' AND t.file#=:file_no-p.value';
      ch                     INTEGER;
      rv                     INTEGER;
      msgno                  INTEGER;
   BEGIN
      -- Set default return value first
      default_return_value := '0|' || event_p;

      IF (LENGTH (RTRIM (p1text_p)) >= 2)
      THEN
         default_return_value :=
                      default_return_value || ', ' || p1text_p || '=' || p1_p;

         IF (LENGTH (RTRIM (p2text_p)) >= 2)
         THEN
            default_return_value :=
                      default_return_value || ', ' || p2text_p || '=' || p2_p;

            IF (LENGTH (RTRIM (p3text_p)) >= 2)
            THEN
               default_return_value :=
                      default_return_value || ', ' || p3text_p || '=' || p3_p;
            END IF;
         END IF;
      END IF;

      /*  Some events exist in all sorts of documents, but I can not find them in 7.3 - 9i.
          For example, dupl. cluster key.
          These events are excluded.
      */

      -- IO events.  p1=file#, p2=block# (except DFS db file lock)
      -- Add direct path io as well
      IF (   (p1text_p = 'file#' AND p2text_p = 'block#')
          OR (p1text_p = 'file number' AND p2text_p = 'first dba')
          OR event_p = 'DFS db file lock'
         )
      THEN
         msgno := 0;

         BEGIN
            SELECT NAME
              INTO p1detail
              FROM v$dbfile
             WHERE file# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN         -- If file name is not found, it must be a temp file.
               BEGIN
                  ch := DBMS_SQL.open_cursor;
                  DBMS_SQL.parse (ch, tmp_file_stmt, DBMS_SQL.native);
                  DBMS_SQL.bind_variable (ch, 'file_no', p1_p);
                  DBMS_SQL.define_column (ch, 1, p1detail, 512);
                  rv := DBMS_SQL.EXECUTE (ch);
                  rv := DBMS_SQL.fetch_rows (ch);

                  IF rv > 0
                  THEN
                     DBMS_SQL.COLUMN_VALUE (ch, 1, p1detail);
                     DBMS_SQL.close_cursor (ch);
                  ELSE
                     DBMS_SQL.close_cursor (ch);
                  END IF;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     p1detail := ' (file#=' || TO_CHAR (p1_p) || ')';
               END;
         END;

         IF (event_p = 'DFS db file lock')
         THEN
            return_value := p1detail;
         ELSE
            IF (    event_p = 'db file scattered read'
                AND g_object_cache_initialized = 1
               )
            THEN
               return_value :=
                     p1detail
                  || '|'
                  || get_seg_name_41 (p1_p, p2_p)
                  || '|'
                  || fts_progress_41 (p1_p, p2_p);
               msgno := 6;
            ELSE
               return_value := get_seg_name_41 (p1_p, p2_p) || '|'
                               || p1detail;
               msgno := 7;
            END IF;
         END IF;
      -- lock events.  p1=name|mode
      ELSIF (event_p = 'enqueue' OR event_p LIKE 'enq:%')
      THEN
         lock_type :=
               CHR (BITAND (p1_p, -16777216) / 16777215)
            || CHR (BITAND (p1_p, 16711680) / 65535);
         lock_mode := BITAND (p1_p, 65535);

         IF (event_p = 'enqueue')
         THEN
            return_value :=
                  lock_type_decode_41 (lock_type)
               || '-'
               || lock_mode_decode_41 (lock_mode);
         ELSE                                                  /* 10g logic */
            IF (p2text_p LIKE '%object #')
            THEN
               SELECT NAME
                 INTO obj_name
                 FROM SYS.obj$
                WHERE obj# = p2_p;
            END IF;

            return_value :=
                  ''||lock_type_decode_41 (lock_type)
               || '-'
               || lock_mode_decode_41 (lock_mode)
               || ' lock on '
               || obj_name;
         END IF;

         msgno := 2;
      -- latch event.  p2=latch#
      ELSIF (event_p = 'latch activity' OR event_p = 'latch free')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$latchname
             WHERE latch# = p2_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := TO_CHAR (p2_p);
         END;

         msgno := 3;
      -- buffer event.  p1=dba or p2=dba
      ELSIF (p1text_p = 'dba' OR p2text_p = 'dba')
      THEN
         IF (p1text_p = 'dba')
         THEN
            return_value :=
               get_seg_name_41 (DBMS_UTILITY.data_block_address_file (p1_p),
                                DBMS_UTILITY.data_block_address_block (p1_p)
                               );
         ELSE
            return_value :=
               get_seg_name_41 (DBMS_UTILITY.data_block_address_file (p2_p),
                                DBMS_UTILITY.data_block_address_block (p2_p)
                               );
         END IF;

         msgno := 9;
      -- undo event.  p1=segment#
      ELSIF (event_p = 'undo segment recovery')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$rollname
             WHERE usn = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := TO_CHAR (p1_p);
         END;

         msgno := 4;
      -- This event is valid at lease in 7.2
      ELSIF (event_p = 'row cache lock')
      THEN
         BEGIN
            SELECT parameter
              INTO return_value
              FROM v$rowcache
             WHERE cache# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := TO_CHAR (p1_p);
         END;

         msgno := 5;
      END IF;

      -- if the event is covered by above, we add p3 when available
      IF (LENGTH (RTRIM (return_value)) > 1)
      THEN
         IF (LENGTH (RTRIM (p3text_p)) > 1)
         THEN
            return_value :=
                  TO_CHAR (msgno)
               || '|'
               || event_p
               || ', %1, '
               || p3text_p
               || '='
               || p3_p
               || '|'
               || return_value;
         ELSE
            return_value :=
                  TO_CHAR (msgno) || '|' || event_p || ', %1|'
                  || return_value;
         END IF;
      ELSE
         return_value := default_return_value;
      END IF;

      RETURN return_value;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN default_return_value;
   END;                                                     -- event_detail_41

   --
   -- wait_detail is a quicker vesion of event_details to be used in SELECT clause.
   -- Have to remove dynamic SQL, and not try to get object name
   --
   FUNCTION wait_detail (
      event_p    IN   VARCHAR2,
      p1text_p   IN   VARCHAR2,
      p1_p       IN   NUMBER,
      p2text_p   IN   VARCHAR2 DEFAULT '',
      p2_p       IN   NUMBER DEFAULT 0,
      p3text_p   IN   VARCHAR2 DEFAULT '',
      p3_p       IN   NUMBER DEFAULT 0
   )
      RETURN VARCHAR2
   IS
      p1detail               VARCHAR2 (512);
      lock_type              VARCHAR2 (10);
      lock_mode              INTEGER;
      default_return_value   VARCHAR2 (2048) := '';
      return_value           VARCHAR2 (2048) := '';
      obj_name               VARCHAR2 (255);
      ch                     INTEGER;
      rv                     INTEGER;
   BEGIN
      -- Set default return value first
      default_return_value := event_p;

      IF (LENGTH (RTRIM (p1text_p)) >= 2)
      THEN
         default_return_value :=
                      default_return_value || ', ' || p1text_p || '=' || p1_p;

         IF (LENGTH (RTRIM (p2text_p)) >= 2)
         THEN
            default_return_value :=
                      default_return_value || ', ' || p2text_p || '=' || p2_p;

            IF (LENGTH (RTRIM (p3text_p)) >= 2)
            THEN
               default_return_value :=
                      default_return_value || ', ' || p3text_p || '=' || p3_p;
            END IF;
         END IF;
      END IF;

      -- IO events.  p1=file#, p2=block# (except DFS db file lock)
      -- Add direct path io as well
      IF (   (p1text_p = 'file#' AND p2text_p = 'block#')
          OR (p1text_p = 'file number' AND p2text_p = 'first dba')
          OR event_p = 'DFS db file lock'
         )
      THEN
         BEGIN
            SELECT NAME
              INTO p1detail
              FROM v$dbfile
             WHERE file# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN         -- If file name is not found, it must be a temp file.
               p1detail := 'TEMP datafile:' || TO_CHAR (p1_p);
         END;

         return_value := p1detail;
      -- lock events.  p1=name|mode
      ELSIF (event_p = 'enqueue')
      THEN
         lock_type :=
               CHR (BITAND (p1_p, -16777216) / 16777215)
            || CHR (BITAND (p1_p, 16711680) / 65535);
         lock_mode := BITAND (p1_p, 65535);

         BEGIN
            SELECT NAME
              INTO obj_name
              FROM SYS.obj$
             WHERE obj# = p2_p;

            return_value :=
                  lock_type_decode (lock_type)
               || ', mode:'
               || lock_mode_decode (lock_mode)
               || ', Object='
               || obj_name;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value :=
                     lock_type_decode (lock_type)
                  || ', mode:'
                  || lock_mode_decode (lock_mode);
         END;
      -- latch event.  p2=latch#
      ELSIF (event_p = 'latch activity' OR event_p = 'latch free')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$latchname
             WHERE latch# = p2_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := 'latch#=' || 'p2_p';
         END;
      -- undo event.  p1=segment#
      ELSIF (event_p = 'undo segment recovery')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$rollname
             WHERE usn = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := 'RBS#=' || TO_CHAR (p1_p);
         END;
      -- This event is valid at lease in 7.2
      ELSIF (event_p = 'row cache lock')
      THEN
         BEGIN
            SELECT parameter
              INTO return_value
              FROM v$rowcache
             WHERE cache# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := 'cache#=' || TO_CHAR (p1_p);
         END;
      END IF;

      -- if the event is covered by above, we add p3 when available
      IF (LENGTH (RTRIM (return_value)) > 1)
      THEN
         IF (LENGTH (RTRIM (p3text_p)) > 1)
         THEN
            return_value :=
               event_p || ', ' || return_value || ', ' || p3text_p || '='
               || p3_p;
         ELSE
            return_value := event_p || ', ' || return_value;
         END IF;
      ELSE
         return_value := default_return_value;
      END IF;

      RETURN return_value;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN default_return_value;
   END;

   --
   -- wait_detail is a quicker vesion of event_details to be used in SELECT clause.
   -- Have to remove dynamic SQL, and not try to get object name
   -- I18N version
   --
   FUNCTION wait_detail_41 (
      event_p    IN   VARCHAR2,
      p1text_p   IN   VARCHAR2,
      p1_p       IN   NUMBER,
      p2text_p   IN   VARCHAR2 DEFAULT '',
      p2_p       IN   NUMBER DEFAULT 0,
      p3text_p   IN   VARCHAR2 DEFAULT '',
      p3_p       IN   NUMBER DEFAULT 0
   )
      RETURN VARCHAR2
   IS
      p1detail               VARCHAR2 (512);
      lock_type              VARCHAR2 (10);
      lock_mode              INTEGER;
      default_return_value   VARCHAR2 (2048) := '';
      return_value           VARCHAR2 (2048) := '';
      obj_name               VARCHAR2 (255);
      ch                     INTEGER;
      rv                     INTEGER;
      msgno                  INTEGER;
   BEGIN
      -- Set default return value first
      default_return_value := '0|' || event_p;

      IF (LENGTH (RTRIM (p1text_p)) >= 2)
      THEN
         default_return_value :=
                      default_return_value || ', ' || p1text_p || '=' || p1_p;

         IF (LENGTH (RTRIM (p2text_p)) >= 2)
         THEN
            default_return_value :=
                      default_return_value || ', ' || p2text_p || '=' || p2_p;

            IF (LENGTH (RTRIM (p3text_p)) >= 2)
            THEN
               default_return_value :=
                      default_return_value || ', ' || p3text_p || '=' || p3_p;
            END IF;
         END IF;
      END IF;

      -- IO events.  p1=file#, p2=block# (except DFS db file lock)
      -- Add direct path io as well
      IF (   (p1text_p = 'file#' AND p2text_p = 'block#')
          OR (p1text_p = 'file number' AND p2text_p = 'first dba')
          OR event_p = 'DFS db file lock'
         )
      THEN
         msgno := 1;

         BEGIN
            SELECT NAME
              INTO p1detail
              FROM v$dbfile
             WHERE file# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN         -- If file name is not found, it must be a temp file.
               p1detail := TO_CHAR (p1_p);
               msgno := 8;
         END;

         return_value := p1detail;
      -- lock events.  p1=name|mode
      ELSIF (event_p = 'enqueue')
      THEN
         lock_type :=
               CHR (BITAND (p1_p, -16777216) / 16777215)
            || CHR (BITAND (p1_p, 16711680) / 65535);
         lock_mode := BITAND (p1_p, 65535);
         return_value :=
               lock_type_decode_41 (lock_type)
            || '|'
            || lock_mode_decode_41 (lock_mode);
         msgno := 2;
      -- latch event.  p2=latch#
      ELSIF (event_p = 'latch activity' OR event_p = 'latch free')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$latchname
             WHERE latch# = p2_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := TO_CHAR (p2_p);
         END;

         msgno := 3;
      -- undo event.  p1=segment#
      ELSIF (event_p = 'undo segment recovery')
      THEN
         BEGIN
            SELECT NAME
              INTO return_value
              FROM v$rollname
             WHERE usn = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := TO_CHAR (p1_p);
         END;

         msgno := 4;
      -- This event is valid at lease in 7.2
      ELSIF (event_p = 'row cache lock')
      THEN
         BEGIN
            SELECT parameter
              INTO return_value
              FROM v$rowcache
             WHERE cache# = p1_p AND ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               return_value := TO_CHAR (p1_p);
         END;

         msgno := 5;
      END IF;

      -- if the event is covered by above, we add p3 when available
      IF (LENGTH (RTRIM (return_value)) > 1)
      THEN
         IF (LENGTH (RTRIM (p3text_p)) > 1)
         THEN
            return_value :=
                  TO_CHAR (msgno)
               || '|'
               || event_p
               || ', %1, '
               || p3text_p
               || '='
               || p3_p
               || '|'
               || return_value;
         ELSE
            return_value :=
                  TO_CHAR (msgno) || '|' || event_p || ', %1|'
                  || return_value;
         END IF;
      ELSE
         return_value := default_return_value;
      END IF;

      RETURN return_value;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN default_return_value;
   END;

   FUNCTION dataobj_object (dataobj_p NUMBER)
      RETURN VARCHAR2
   IS
      return_value   VARCHAR2 (200);
      obj_name       VARCHAR2 (200);
      ch             INTEGER;
      rv             INTEGER;
      stmt           VARCHAR2 (2000)
         := 'SELECT /*+ rule ordered */ u.name || ''.'' || o.name name FROM sys.obj$ o, sys.user$ u

            WHERE obj# < :dataobj_num AND dataobj# = :dataobj_num AND o.OWNER# = u.USER#';
   BEGIN
      -- Set default return value
      return_value := 'Object (x$bh.obj=' || dataobj_p || ')';
      ch := DBMS_SQL.open_cursor;
      DBMS_SQL.parse (ch, stmt, DBMS_SQL.native);
      DBMS_SQL.bind_variable (ch, 'dataobj_num', dataobj_p);
      DBMS_SQL.define_column (ch, 1, obj_name, 200);
      rv := DBMS_SQL.EXECUTE (ch);
      rv := DBMS_SQL.fetch_rows (ch);

      IF rv > 0
      THEN
         DBMS_SQL.COLUMN_VALUE (ch, 1, obj_name);
         return_value := obj_name;
         DBMS_SQL.close_cursor (ch);
      ELSE
         DBMS_SQL.close_cursor (ch);
      END IF;

      RETURN return_value;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         BEGIN
            DBMS_SQL.close_cursor (ch);
            RETURN 'unknown';
         EXCEPTION
            WHEN OTHERS
            THEN
               RETURN 'unknown';
         END;
   END;

-- Function job_interval is used to deal with complicate interval setting in dbms_jobs.
-- Simple setting like 'sysdate+15/24' is handled by clinet.
-- Complicate setting, like NEXT_DAY(ADD_MONTHS(TRUNC(SYSDATE,'Q'),3),'THURSDAY'), (i.e. The first Thursday in the next quarter), is handled here.
-- When the interval is set by user's PL/SQL function, as we don't know how to call all user's functions, we have to ignore them.  NULL is returned.
   FUNCTION job_interval (next_date_p DATE, interval_p VARCHAR2)
      RETURN DATE
   IS
      INTERVAL   DATE           := NULL;
      stmt       VARCHAR2 (320)
         := 'SELECT REPLACE(LOWER(:interval),''sysdate'',''TO_DATE(TO_CHAR(:next_date,''dd/mm/rr hh24:mi:ss''),''dd/mm/rr hh24:mi:ss'') FROM DUAL';
      c          INTEGER;
      rv         NUMBER;
   BEGIN
      BEGIN
         c := DBMS_SQL.open_cursor;
         DBMS_SQL.parse (c, stmt, DBMS_SQL.native);
         DBMS_SQL.bind_variable (c, 'interval', interval_p);
         DBMS_SQL.bind_variable (c, 'next_date', next_date_p);
         DBMS_SQL.define_column (c, 1, INTERVAL);
         rv := DBMS_SQL.EXECUTE (c);
         rv := DBMS_SQL.fetch_rows (c);

         IF rv > 0
         THEN
            DBMS_SQL.COLUMN_VALUE (c, 1, INTERVAL);
         END IF;

         DBMS_SQL.close_cursor (c);
      --If the expression can't be parsed, return defualt NULL.
      EXCEPTION
         WHEN OTHERS
         THEN
            DBMS_SQL.close_cursor (c);
      END;

      RETURN INTERVAL;
   END;

-- Populate lock event array with entries from v$lock_type table
-- Used for future proofing of lock types to handle new versions of Oracle rather than having a static list
-- Will be called when package is initialised
   PROCEDURE populate_lock_type IS

      lv_version   NUMBER;

      arr_type 		varchar_tab_typ;
      arr_name 		varchar_tab_typ;
   BEGIN

      lv_version := get_db_version;

      IF lv_version >= 10 THEN

      	 EXECUTE IMMEDIATE 'select type, name from v$lock_type'
      	 BULK COLLECT INTO arr_type, arr_name;

      	 FOR idx IN 1..arr_type.COUNT LOOP

      	 	lock_type_tab(arr_type(idx)) := arr_name(idx);

      	 END LOOP;


      END IF;

   END populate_lock_type;

END;
/
