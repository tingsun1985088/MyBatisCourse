CREATE package body PKG_ZL_DATA is

  -- 大额抽数
  procedure R_NORMAL(i_start_date in date, i_end_date in date) is

    m_begin_time timestamp := sysdate;
    m_R_CUST_ID  number; --r_cust_id
    m_cnt        number;
    --核心系统大额(单笔或者当日累计保险业务交易达到人民币20万元以上)
    CURSOR C_R_NORMAL(ci_start_date date, ci_end_date date) IS(

      /*select a.c_app_cde,wm_concat(b.c_app_no) c_app_nos
        from web_ply_applicant a
        join (select a.c_app_no,abs(b.n_paid_amt) amt--取绝对值
                from web_ply_base  a
                join web_fin_prm_due b on a.c_app_no = b.c_app_no
                                      and b.c_feetyp_cde ='R'
                                      and b.n_bs_amt = b.n_paid_amt
                                      and b.T_RP_TM >= ci_start_date --抽数时间(保批单) => 收付日期
                                      and b.T_RP_TM < ci_end_date
               union
              select b.c_app_no,abs(a.n_paid_amt)
                from web_fin_clm_due a
                join web_ply_base b on a.c_app_no = b.c_app_no
                                   and b.C_LATEST_MRK = '1'
               where a.n_bs_amt=a.n_paid_amt
                 and a.T_RP_TM >= ci_start_date --抽数时间(理赔) => 收付日期
                 and a.T_RP_TM < ci_end_date 
              ) b on a.c_app_no = b.c_app_no -- 投保单号
         group by a.c_app_cde --客户编号
         having sum(b.amt) > 200000*/
         
        --下面更换查询实现方式，和上面注释的结果相同，目的是不使用wm_concat()
        SELECT  c_app_cde,listagg(c_app_no,',') WITHIN GROUP (ORDER BY c_app_no) AS c_app_nos
        FROM (
            select a.c_app_cde AS c_app_cde,b.c_app_no AS c_app_no,b.amt AS amt
            from web_ply_applicant a
            join (select a.c_app_no AS c_app_no,abs(b.n_paid_amt) amt--取绝对值
                    from web_ply_base a
                    join web_fin_prm_due b on a.c_app_no = b.c_app_no
                                          and b.c_feetyp_cde ='R'
                                          and b.n_bs_amt = b.n_paid_amt
                                          and b.T_RP_TM >= ci_start_date --抽数时间(保批单) => 收付日期
                                          and b.T_RP_TM < ci_end_date
                   union
                  select b.c_app_no AS c_app_no,abs(a.n_paid_amt) amt
                    from web_fin_clm_due a
                    join web_ply_base b on a.c_app_no = b.c_app_no
                                       and b.C_LATEST_MRK = '1'
                   where a.n_bs_amt=a.n_paid_amt
                     and a.T_RP_TM >= ci_start_date --抽数时间(理赔) => 收付日期
                     and a.T_RP_TM < ci_end_date 
                  ) b on a.c_app_no = b.c_app_no -- 投保单号
             
        ) temp
        GROUP  BY c_app_cde --客户编号
        HAVING  sum(amt) > 200000
         
    );

  begin

    --记录日志
    PKG_CUSTOMER_SCO.p_insert_t_prod_log('PKG_ZL_DATA.R_NORMAL',
                                         m_begin_time,
                                         'running',
                                         'PKG_ZL_DATA.R_NORMAL已经开始执行');
    commit;

    --数据获取并插入大额记录表
    FOR F_TMP IN C_R_NORMAL(i_start_date, i_end_date) LOOP
      --客户编号
      --select s_r_hq_customer__r_cust_id.nextval into m_R_CUST_ID from dual;
      --dbms_output.put_line(F_TMP.c_app_cde || '----------' || m_R_CUST_ID);
      --判断客户是否已经录入过
      select nvl(max(a.r_cust_id), -1)
        into m_R_CUST_ID
        from t_lat_CUSTOMER a
       where a.CUSTOMER_ID = F_TMP.c_app_cde;
      if m_R_CUST_ID < 0 then
      select s_r_hq_customer__r_cust_id.nextval into m_R_CUST_ID from dual;
      --插入客户表
     insert into t_lat_customer
        (R_CUST_ID,
         CUSTOMER_ID,
         REAL_NAME,
         GENDER,
         BIRTHDAY,
         CERTI_TYPE,
         CERTI_CODE,
         NATIONALITY,
         ORGAN_ID,
         TRANS_DATE,
         STATUS,
         INSERT_TYPE)
        (select m_R_CUST_ID,
                b.c_app_cde,
                b.c_app_nme, --客户名称
                decode(b.c_sex, '1', 'M', '2', 'F', '') sex, --性别
                b.t_birthday, --生日
                decode(b.c_certf_cls,
                       '120001',
                       1,
                       '120002',
                       3,
                       '120003',
                       2,
                       '110001',
                       12,
                       '110002',
                       13,
                       9) c_certf_cls, --证件类型
                b.c_certf_cde, --证件号
                (select t.c_area_cnm
                   from web_bas_area t
                  where t.c_area_cde = b.c_country
                    and t.c_type = '0') c_country, --查询国家
                a.c_dpt_cde, --客户机构ID
                sysdate - 1, --交易发生日
                '30',
                '0'
           from web_ply_base a
           join (select * from(
                     select t.*,
                            row_number() over(partition by t.c_app_cde order by t.T_CRT_TM desc) as rn
                       from  WEB_PLY_APPLICANT t
                      )where rn=1) b -- 最新客户信息
           on a.c_app_no = b.c_app_no
          where b.c_app_cde = F_TMP.c_app_cde
            /* and b.t_crt_tm >= i_start_date
            and b.t_crt_tm <= i_end_date --抽数时间范围*/
         );
         commit;
         end if;


      --循环每个客户的保单号，相关信息插入插入t_lat_data和T_IH_TSDT
      for row1 in (select column_value as c_app_no
                      from table(splitx(F_TMP.c_app_nos))) loop
      --  dbms_output.put_line(F_TMP.c_app_cde || '----保单号----' ||
      --                       a_row.c_ply_no);

        --插入交易表(报批单信息)
        insert into t_lat_Data
          (HQ_DATA_ID,
           POLICY_ID,
           PERIOD_PREM,
           FINISH_TIME,
           FEE_TYPE,
           PAY_WAY,
           ORGAN_ID,
           R_CUST_ID,
           STATUS,
           CRCD,
           APP_NO,
           INSERT_TYPE,
           FEE_ID,
           FE_TYPE,
           INSERT_TIME)
          (select s_r_hq_data__hq_data_id.nextval,
                  nvl(a.C_EDR_NO,a.c_ply_no), --保(批)单号
                  b.N_PAID_AMT, --实际发生费用
                  a.t_crt_tm,
                  case when a.N_PRM_VAR>0 then '2'
                       when a.N_PRM_VAR<0 then '1'
                       else '0' end fee_type, --费用业务类型
                  b.C_PAY_MDE_CDE, --支付方式 C_PAY_MDE_CDE
                  a.c_dpt_cde,
                  m_R_CUST_ID,
                  '30',
                  '0901',
                  a.c_app_no,
                  '0',
                  b.C_RCPT_NO, --费用ID
                  decode(a.n_edr_prj_no, 0, '1', '2'),
                  sysdate
             from web_ply_base a
             join web_fin_prm_due b on a.c_app_no = b.c_app_no
            where a.c_app_no = row1.c_app_no --投保单号
              and a.c_app_no not in (select APP_NO from t_lat_Data) --不录入重复记录
            );

        commit;

      --插入T_IH_TSDT
  insert into T_IH_TSDT
            select s_T_IH_TSDT__tsid.nextval tsid,
                   null tsdt,
                   t2.c_dpt_cnm,
                   t2.c_dpt_xzqh,
                   null rltp,
                   '00' fict,
                   t2.c_dpt_cde,
                   '@N',
                   '@N',
                   '@I',
                   '@I',
                   '@I',
                   '@I',
                   t3.T_RP_TM, --交易时间
                   t3.C_RCPT_NO,  --业务标识号(费用ID)
                   '00' ||
                   decode(t3.C_PAY_MDE_CDE,
                          '4',
                          '00',
                          '11',
                          '00',
                          '12',
                          '00',
                          '01') || decode(t3.C_PAY_MDE_CDE,
                                          '1',
                                          '10',
                                          '2',
                                          '04',
                                          '4',
                                          '30',
                                          '10',
                                          '34',
                                          '11',
                                          '30',
                                          '12',
                                          '30',
                                          '13',
                                          '20',
                                          '51'),  --交易方式
                   '@N',
                   case when t3.n_paid_amt>0 then '01'--收付标示
                        when t3.n_paid_amt<0 then '02'
                        end,
                   '@N',
                   'CHN' || t2.c_dpt_xzqh,
                   '@I',
                   (select nvl(wbf.c_cur_sbl, 'CNY')
                      from WEB_BAS_FIN_CUR wbf
                     where wbf.c_cur_cde = t3.C_RP_CUR),--币种
                   t3.n_paid_amt, --交易金额
                   '@N',
                   '@N',
                   '@N',
                   '@N',
                   '@N',
                   '@N',
                   '@N',
                   '@N',
                   null rtid,
                   '0901',
                   null issupple,
                   null updt,
                   t1.c_ply_no,
                   t1.c_app_no
              from WEB_PLY_BASE t1
              join WEB_ORG_DPT  t2 on t1.c_dpt_cde = t2.c_dpt_cde
              join web_fin_prm_due t3 on t1.c_app_no = t3.c_app_no
             where t3.c_app_no = row1.c_app_no
               and row1.c_app_no not in (select APP_NO from T_IH_TSDT); --不录入重复记录

          commit;

      end loop;

    END LOOP;

    --追加执行完成日志
    PKG_CUSTOMER_SCO.p_insert_t_prod_log('PKG_ZL_DATA.R_NORMAL',
                                         m_begin_time,
                                         '0',
                                         'PKG_ZL_DATA.R_NORMAL执行成功');
    commit;

  exception
    when others then
      rollback;

  end R_NORMAL;


  -- 可疑交易数据记录(按投保单号码,按保单号码)
  procedure R_SU_NORMAL_SEND(i_su_data_id  in  t_sus_data.su_data_id%type,
                             i_policy_no in varchar2,
                             i_customer_id in varchar2,
                             i_policy_id   in varchar2,
                             i_t_crt_tm in date--签单日期
                             ) is
    m_fee_id number;
  begin
    --插入t_sus_customer
    insert into t_sus_customer
            (R_CUST_ID,
             SU_DATA_ID,
             CUSTOMER_ID,
             REAL_NAME,
             CERTI_TYPE,
             CERTI_CODE,
             TEL,
             ADDRESS,
             CONTACT_INFO,
             CUST_TYPE,
             VOCATION)
            (select s_r_su_customer__r_cust_id.nextval,
                    i_su_data_id,
                    wpa.c_app_cde,
                   wpa.c_app_nme,
                   decode(wpa.c_certf_cls,
                           '120001',
                           1,
                           '120002',
                           3,
                           '120003',
                           2,
                           '110001',
                           12,
                           '110002',
                           13,
                           9) c_certf_cls,
                   wpa.c_certf_cde,
                    wpa.c_mobile,
                    wpa.c_clnt_addr,
                    wpa.c_work_area,
                    wpa.c_clnt_mrk,
                   ( case
              when wpa.c_occup_cde in
                   ('108033', '108010', '108051', '108061', '108063', '108074') then
               '1B'
              when wpa.c_occup_cde in ('108098', '108092', '') then
               '1C'
              when wpa.c_occup_cde in ('108097', '108099', '108078', '108079') then
               '1D'
              when wpa.c_occup_cde in ('108053', '108003', '108054', '108059', '108073') then
               '1E'
              when wpa.c_occup_cde in ('108065', '108066') then
               '1F'
              when wpa.c_occup_cde in ('108052',
                             '108070',
                             '108077',
                             '108080',
                             '108081',
                             '108082',
                             '108083',
                             '108084',
                             '108090',
                             '108094') then
               '1G'
              when wpa.c_occup_cde in ('108031', '108055', '108091', '108093', '108095') or wpa.c_occup_cde is null  then
               '1H'
              else
               '1A'
            end)
               from web_ply_applicant wpa
              where wpa.c_app_cde = i_customer_id
              and wpa.n_edr_prj_no=(select max(t.n_edr_prj_no) from web_ply_applicant t where t.c_ply_no=i_policy_id)
              and wpa.c_ply_no=i_policy_id
              and not exists (select 1 from t_sus_customer tsc where tsc.customer_id=i_customer_id
              and tsc.su_data_id=i_su_data_id));

    -- 3、插入t_sus_contract
     insert into t_sus_contract
       (su_contract_id,
        su_data_id,
        policy_no,
        policy_id,
        item_id,
        product_id,
        internal_id,
        istp,
        organ_id,
        customer_name,
        customer_certi_type,
        customer_certi_code,
        insurant_num,
        isog,
        isat,
        isfe,
        ispt,
        ctes)
       (select s_r_su_contract__contract_id.nextval,
               i_su_data_id,
               wpb.c_ply_no,
               wpb.c_app_no,
               wpc.n_seq_no,
               wpb.c_prod_no,
               wpc.c_cvrg_no,
               '02', --02:财产险
               wpb.c_dpt_cde,
               wpa.c_app_nme,
               decode(wpa.c_certf_cls,
                      '120001',
                      1,
                      '120002',
                      3,
                      '120003',
                      2,
                      '110001',
                      12,
                      '110002',
                      13,
                      9) c_certf_cls,
               wpa.c_certf_cde,
               1,
               wpc.c_tgt_nme,
               wpb.n_amt,
               wpb.n_prm,
               decode(wpb.c_inst_mrk, '0', '02', '01'),
               null
          from web_ply_base wpb
          join web_ply_cvrg wpc
            on wpb.c_app_no = wpc.c_app_no
          join web_ply_applicant wpa
            on wpb.c_app_no = wpa.c_app_no
         where wpa.c_app_no =i_policy_no
          and rownum =1);
  --插入t_sus_trans
  insert into t_sus_trans
    (se_su_trans_id,
     fee_id,
     trans_type,
     trans_time,
     real_name,
     certi_type,
     certi_code,
     policy_code,
     crtp,
     amount,
     crdr,
     cstp,
     caoi,
     tcan,
     su_data_id)
    (select s_r_su_trans__se_su_trans_id.nextval,
            wpc.c_unique_no,
            decode(wpb.c_edr_type, '3', '03', '01'),
            wpc.t_check_tm,
            wpa.c_app_nme,
            decode(wpa.c_certf_cls,
                   '120001',
                   1,
                   '120002',
                   3,
                   '120003',
                   2,
                   '110001',
                   12,
                   '110002',
                   13,
                   9) c_certf_cls,
            wpa.c_certf_cde,
            wpb.c_ply_no,
            (select wbf.c_cur_sbl
               from WEB_BAS_FIN_CUR wbf
              where wbf.c_cur_cde = wpb.c_prm_cur),
            wpb.n_prm,
            (case
              when wpb.n_prm_var < 0 then
               '02'
              else
               '01'
            end),
            case
              when wpb.c_fin_typ in ('4', '11', '12') then
               '01'
              when wpb.c_fin_typ in ('5') then
               '02'
              else
               '03'
            end,
            waa.c_acct_no,
            waa.c_bank_rel_cde,
            i_su_data_id
       from web_ply_applicant wpa
       join web_ply_base wpb
         on wpa.c_app_no = wpb.c_app_no
       join web_pay_confirm_info wpc
         on wpa.c_app_no = wpc.c_app_no
       join web_app_acctinfo waa
         on wpa.c_app_no = waa.c_app_no
      where wpa.c_app_no =i_policy_no
      /*in ( select t.c_app_no
                                  from web_ply_base t
                                 where t.c_ply_no= i_policy_id
                                   --and t.N_EDR_PRJ_NO ='0'
                                  and trunc(t.t_issue_tm)=i_t_crt_tm)*/
                     );





  end R_SU_NORMAL_SEND;

  --报批单信息录入 t_lat_Data
  procedure BP_DATA(c_app_no in varchar2,
                    n_R_CUST_ID in number) is

  tb_no varchar2(50) := c_app_no;
  m_R_CUST_ID number := n_R_CUST_ID;
  begin

  dbms_output.put_line('########'||m_R_CUST_ID||' : '|| tb_no);
        --插入交易表(报批单信息)
        insert into t_lat_Data
          (HQ_DATA_ID,
           POLICY_ID,
           PERIOD_PREM,
           FINISH_TIME,
           FEE_TYPE,
           PAY_WAY,
           ORGAN_ID,
           R_CUST_ID,
           STATUS,
           CRCD,
           APP_NO,
           INSERT_TYPE,
           FEE_ID,
           FE_TYPE)
          (select s_r_hq_data__hq_data_id.nextval,
                  nvl(a.C_EDR_NO,a.c_ply_no), --保(批)单号
                  b.N_PAID_AMT, --实际发生费用
                  a.t_crt_tm,
                  case when a.N_PRM_VAR>0 then '2'
                       when a.N_PRM_VAR<0 then '1'
                       else '0' end fee_type, --费用业务类型
                  b.C_PAY_MDE_CDE, --支付方式 C_PAY_MDE_CDE
                  a.c_dpt_cde,
                  m_R_CUST_ID,
                  '30',
                  '0901',
                  a.c_app_no,
                  '0',
                  b.C_RCPT_NO, --费用ID
                  decode(a.n_edr_prj_no, 0, '1', '2')
             from web_ply_base a
             join web_fin_prm_due b on a.c_app_no = b.c_app_no
            where a.c_app_no = tb_no --传入投保单号
              and a.c_app_no not in (select APP_NO from t_lat_Data) --不录入重复记录
            );

        commit;

        --插入交易表
       --   车理赔
        insert into t_lat_Data
          (HQ_DATA_ID,
           POLICY_ID,
           PERIOD_PREM,
           FINISH_TIME,
           FEE_TYPE,
           PAY_WAY,
           ORGAN_ID,
           R_CUST_ID,
           STATUS,
           CRCD,
           APP_NO,
           INSERT_TYPE,
           FEE_ID,
           FE_TYPE)
          ( select  s_r_hq_data__hq_data_id.nextval,
                    a.c_rpt_no, --赔案号
                    c.n_paid_amt, --实际发生费用
                    c.T_RP_TM,--缴费时间
                    decode(d.n_pay_amt, null, 3, 4), --费用业务类型 3-赔款支出 4-预付赔款
                    c.C_PAY_MDE_CDE,--支付方式
                    b.c_dpt_cde,
                    m_R_CUST_ID,
                    '30',
                    '0901',
                    tb_no,
                    '0',
                    c.C_RCPT_NO, --费用ID
                    '3'
             from web_vhlclm_ply a
             join web_ply_base b on a.c_app_no = b.c_app_no
             join web_fin_clm_due c on a.c_rpt_no = c.c_clm_no
                                   and c.n_bs_amt = c.n_paid_amt
                                   and c.n_paid_amt is not null
             join web_vhlclm_main d on a.c_rpt_no = d.c_rpt_no
            where a.c_app_no = tb_no
              and a.c_app_no not in (select APP_NO from t_lat_Data) --不录入重复记录
            );
        commit;

        --插入交易表
       --   非车理赔
        insert into t_lat_Data
          (HQ_DATA_ID,
           POLICY_ID,
           PERIOD_PREM,
           FINISH_TIME,
           FEE_TYPE,
           PAY_WAY,
           ORGAN_ID,
           R_CUST_ID,
           STATUS,
           CRCD,
           APP_NO,
           INSERT_TYPE,
           FEE_ID,
           FE_TYPE)
           (select s_r_hq_data__hq_data_id.nextval,
                   a.c_clm_no,--赔案号
                   d.n_paid_amt,--实际发生费用
                   d.T_RP_TM,
                   decode(c.n_pay_amt, null, 3, 4), --费用业务类型 3-赔款支出 4-预付赔款
                   d.C_PAY_MDE_CDE,--支付方式
                   b.c_dpt_cde,
                   m_R_CUST_ID,
                   '30',
                   '0901',
                   tb_no,
                   '0',
                   d.C_RCPT_NO, --费用ID
                   '4'
              from web_clm_ply_base a
              join web_ply_base b on a.c_app_no = b.c_app_no
              join web_clm_main c on a.c_clm_no = c.c_rpt_no
              join web_fin_clm_due d on a.c_clm_no = d.c_clm_no
                                    and d.n_bs_amt = d.n_paid_amt
                                    and d.n_paid_amt is not null
              where a.c_app_no = tb_no
                and a.c_app_no not in (select APP_NO from t_lat_Data) --不录入重复记录
              );

        commit;






  end BP_DATA;

end PKG_ZL_DATA;
/
