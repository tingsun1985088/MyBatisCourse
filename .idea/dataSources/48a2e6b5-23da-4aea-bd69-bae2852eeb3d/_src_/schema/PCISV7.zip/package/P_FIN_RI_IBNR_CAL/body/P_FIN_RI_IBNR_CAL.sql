CREATE package body P_FIN_RI_IBNR_CAL is
   t_today_tm                date;
  v_kind_no                 varchar2(10);
  v_prod_no                 varchar2(10);
  v_year                    varchar2(4);
  v_quart                   varchar2(2);
  v_flg                      varchar2(2);
  v_clm_amt                 number(20,2);
  v_pend_amt                number(20,2);
  v_fina_amt                number(20,2);
  v_report_amt              number(20,2);
  v_cal_ym                  varchar2(6);
  v_month                   varchar2(2);
  v_count                   number(10);
  v_countcol                number(10);
  v_countsum                number(10);
  V_COLNME                  varchar2(10);
  V_SQL                     varchar2(500);
  V_emp                     number(20,6);
  v_ibnr_risk               Number(20,6);--风险边际 014005
  v_ibnr_prem               Number(20,6);--风险溢价 014016
  v_ibnr_discount           Number(20,6);
  v_ibnr_Duration           Number(20,6);
  v_ibnr_sum                number(20,2);
  v_err_content             web_bas_fin_errorlog.c_err_content%TYPE;--日志错误信息
  v_Sqlcode                 Number;
  v_Sqlerrm                 Varchar2(600);
  V_got_prm                 number(20,2);
  V_dir_fee                 number(20,2);
  V_indir_fee               number(20,2);
  v_evo_rate                number(20,6);
  v_emp_pay                 number(20,6);
  v_fee_rate_dir            number(20,6);
  v_fee_rate_indir          number(20,6);
  v_yearmonth               varchar2(6);
  v_last_month              varchar2(2);
  v_clm_fee                 number(20,2);
  v_pend_INDIRFEE           number(20,2);
  i                         number(20);
  v_ldf_tail                number(20,6);
  ---------------------------------------------------------------------------------
  procedure P_Fin_RI_CAL_PAY(v_today varchar2, v_cal_type in char, v_return out varchar2)
    is
    --已报
    cursor cur_ibnr_pay is
    select
        distinct a.c_kind_no,a.c_prod_no,a.c_year,A.C_QUART
     from WEB_FIN_RI_REPORT a
     where trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd')
     /*and c_kind_no = '01'*/;

    begin
       t_today_tm:=to_date(v_today,'yyyy-mm-dd');
       v_return:=1;
       delete from web_fin_ri_mid_ibnr_pay WHERE TRUNC(T_CAL_TM) = TRUNC(t_today_tm);
       v_cal_ym:=to_char(TRUNC(ADD_MONTHS(t_today_tm + 2/24, 3 ), 'Q' )-1,'yyyymm');
       i:=to_number(to_char(t_today_tm,'yyyymmdd')||'0001');
       --赔付率发不区分基于已报和已决
           open cur_ibnr_pay;
            loop
               fetch cur_ibnr_pay
                into v_kind_no,v_prod_no,v_year,v_quart;
               exit when cur_ibnr_pay%notfound;

               if v_quart = '1' then
                  v_month:='03';
               elsif v_quart = '2' then
                  v_month:='06';
               elsif v_quart = '3' then
                  v_month:='09';
               elsif v_quart = '4' then
                  v_month:='12';
               end if;
               v_count:=(months_between(to_date(v_cal_ym,'yyyymm'),to_date(v_year||v_month,'yyyymm'))-3)/3+1;
               if v_count>=10 then
                  V_COLNME:='n_0'||round(V_COUNT)||'';
               else
                  V_COLNME:='n_00'||round(V_COUNT)||'';
               end if;

               --赔付率
               SELECT n_rate INTO v_evo_rate FROM web_fin_ibnr_rate
               WHERE C_CDE='014009' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
               and c_year = v_year and c_quart = v_quart;

               --风险溢价
               v_ibnr_prem:=0;

               --风险边际
               select n_rate into v_ibnr_risk from WEB_FIN_IBNR_RATE
               where c_cde = '021004' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;

               --贴现
               select n_rate into v_ibnr_discount from WEB_FIN_IBNR_RATE
               where c_cde = '021002' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --久期
               select n_rate into v_ibnr_Duration from WEB_FIN_IBNR_RATE
               where c_cde = '021001' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --直接理赔费用比例
               SELECT n_rate INTO v_fee_rate_dir FROM web_fin_ibnr_rate
               WHERE C_CDE='021005' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 /*and c_year = v_year and c_quart = v_quart*/;
                v_fee_rate_indir:=0;
               --间接理赔费用率
               /*SELECT n_rate INTO v_fee_rate_indir FROM web_fin_ibnr_rate
               WHERE C_CDE='021006' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no*/
                 /*and c_year = v_year and c_quart = v_quart;*/

                --查询已赚保费
               V_SQL:='SELECT SUM(n_got_prm) FROM web_fin_ri_gotprm_quart';
               V_SQL:=V_SQL||' where C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||V_KIND_NO||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||V_PROD_NO||'''';

               EXECUTE IMMEDIATE V_SQL INTO V_got_prm;

               --查询已决赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM web_fin_ri_amt ';
               V_SQL:=V_SQL||' where TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';

               begin
                    EXECUTE IMMEDIATE V_SQL INTO v_clm_amt;
               exception when no_data_found then
                    v_clm_amt:=0;
               end;

               --查询已报赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM WEB_FIN_RI_REPORT ';
               V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';

               EXECUTE IMMEDIATE V_SQL INTO v_report_amt;

            --已报未决直接理赔费用
               SELECT NVL(sum(n_cal_amt*get_rate(C_CUR_CDE,'01',t_cal_tm)),0) into v_clm_fee
                from  web_fin_ri_mid_resclm a --,web_org_dpt b
                WHERE  decode(c_prod_no,'0320',c_prod_no,'---')=v_prod_no
                   and C_KIND_NO=V_KIND_NO
                   and to_char(t_pend_tm,'yyyy')=v_year
                   and to_char(t_pend_tm,'mm')<=v_month
                   and to_char(t_pend_tm,'mm')>=v_last_month
                   and c_cal_typ = '3';

             --最终赔款=满期*赔付率(预估总赔款)
             v_fina_amt:=V_got_prm*v_evo_rate;
             --预估未决赔款准备金:赔付率法IBNR=满期*赔付率-已决赔款
             v_ibnr_sum:=v_fina_amt-v_clm_amt;--赔付率法
             --未决赔款(会计未决赔款准备金)
             v_pend_amt:=v_ibnr_sum*(1+v_ibnr_risk)/POWER((1+v_ibnr_discount+v_ibnr_prem),v_ibnr_Duration);
             --IBNR(含直接理赔费用)=会计未决准备金-已报未决含ALAE
             v_ibnr_sum:=v_pend_amt-v_report_amt+v_clm_amt;
             --IBNR直接理赔费用
             V_dir_fee:=v_ibnr_sum*v_fee_rate_dir;
             --间接理赔费用=已报未决(含直接费用)/2*间接理赔费用率 + IBNR(含直接费用)*间接费用率
             --V_indir_fee:=((v_report_amt-v_clm_amt)/2+v_ibnr_sum)*v_fee_rate_indir;
             --IBNR(含直接理赔费用)=最终赔款*(IBNR(含直接理赔费用)/最终赔款)=最终赔款*(1-1/累计进展因子)
             --v_ibnr_sum:=v_fina_amt*v_evo_rate;
             --IBNR间接理赔费用=IBNR(含直接费用)*间接费用率
             V_indir_fee:=0;--v_ibnr_sum*v_fee_rate_indir;
             --已报间接理赔费用=已报未决(含直接费用)/2*间接理赔费用率 +
             v_pend_INDIRFEE:=0;--(v_report_amt-v_clm_amt)/2*v_fee_rate_indir;

               INSERT INTO web_fin_ri_mid_ibnr_pay
              ( C_PROD_NO,N_GOT_PRM,N_CLM_PRM,N_CLM_RESPRM,N_CAL_CLM_AMT,t_cal_tm,N_CLM_RATE,
                C_kind_no,c_quart,c_year,T_CRT_TM,N_CLM_RESFEE,N_IBNR_AMT,N_IBNR_DIRFEE,
                N_IBNR_INDIRFEE,N_PEND_INDIRFEE,C_PRE_NO,N_UTM_LOS)
               values(
                v_prod_no,v_got_prm,0,v_report_amt,v_ibnr_sum,t_today_tm,v_evo_rate,
                v_kind_no,v_quart,v_year,SYSDATE,v_clm_fee,v_pend_amt,V_dir_fee,
                V_indir_fee,v_pend_INDIRFEE,i,v_fina_amt
               );
               i:=i+1;

            end loop;
           close cur_ibnr_pay;
      commit;
      exception
      When Others Then
        Rollback;
        v_Sqlcode := Sqlcode;
        v_Sqlerrm := Substr(Sqlerrm, 1, 600);
        ROLLBACK;

      v_err_content:='proc:[P_Fin_RI_CAL_PAY],出错流水号:['||v_today||'  '||v_cal_type||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end P_Fin_RI_CAL_PAY;
  ---------------------------------------------------------------------------------
  ----链锑法
  procedure P_Fin_RI_CAL_LT(v_today varchar2, v_cal_type in char, v_return out varchar2)
    is
    --已决
    cursor cur_ibnr_amt_lt is
    select
        distinct a.c_kind_no,a.c_prod_no,a.c_year,A.C_QUART
     from web_fin_ri_amt a
     where trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd')/*
     and a.c_kind_no = '01' and a.c_year = '2011' and a.c_quart = '4'*/;
    --已报
    cursor cur_ibnr_report_lt is
    select
        distinct a.c_kind_no,a.c_prod_no,a.c_year,A.C_QUART
     from WEB_FIN_RI_REPORT a
     where trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd')/* and c_kind_no = '09'*//*
     and a.c_kind_no = '01' and a.c_year = '2011' and a.c_quart = '4'*/;
    --查询累计进展因子
    cursor cur_ibnr_amt_emp(v_kind varchar2,v_prod varchar2,v_typ varchar2) is
     select --1:原始加权平均法,2:简单算术平均法,3:最近两个事故原始加权平均法,4:手动录入进展因子
        distinct a.c_flg
     from WEB_FIN_RI_LDF_EMP a
     where C_MRK = '2'
     and C_TOTAL_MRK = '2'
     and C_TYPE = v_typ
     and c_kind_no = v_kind
     and c_prod_no = v_prod
     and trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd');

    begin
       t_today_tm:=to_date(v_today,'yyyy-mm-dd');
       v_return:=1;
       delete from web_fin_ri_mid_ibnr_lt WHERE TRUNC(T_CAL_TM) = TRUNC(t_today_tm) and c_type = v_cal_type;
       v_cal_ym:=to_char(TRUNC(ADD_MONTHS(t_today_tm + 2/24, 3 ), 'Q' )-1,'yyyymm');

       if v_cal_type = '1' then
           --基于已决的链锑法
           open cur_ibnr_amt_lt;
            loop
               fetch cur_ibnr_amt_lt
                into v_kind_no,v_prod_no,v_year,v_quart;
               exit when cur_ibnr_amt_lt%notfound;

               if v_quart = '1' then
                  v_month:='03';
               elsif v_quart = '2' then
                  v_month:='06';
               elsif v_quart = '3' then
                  v_month:='09';
               elsif v_quart = '4' then
                  v_month:='12';
               end if;
               v_count:=(months_between(to_date(v_cal_ym,'yyyymm'),to_date(v_year||v_month,'yyyymm'))-3)/3+1;
               if v_count>=10 then
                  V_COLNME:='n_0'||round(V_COUNT)||'';
               else
                  V_COLNME:='n_00'||round(V_COUNT)||'';
               end if;

               --风险边际
               select n_rate into v_ibnr_risk from WEB_FIN_IBNR_RATE
               where c_cde = '022004' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;
               --风险溢价
               v_ibnr_prem:=0;
               /*select n_rate into v_ibnr_prem from WEB_FIN_IBNR_RATE
               where c_cde = '014016' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;*/
               --贴现
               select n_rate into v_ibnr_discount from WEB_FIN_IBNR_RATE
               where c_cde = '022002' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --久期
               select n_rate into v_ibnr_Duration from WEB_FIN_IBNR_RATE
               where c_cde = '022001' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --直接理赔费用比例
               SELECT n_rate INTO v_fee_rate_dir FROM web_fin_ibnr_rate
               WHERE C_CDE='022005' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 /*and c_year = v_year and c_quart = v_quart*/;
               --间接理赔费用率
               /*SELECT n_rate INTO v_fee_rate_indir FROM web_fin_ibnr_rate
               WHERE C_CDE='014008' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 and c_year = v_year and c_quart = v_quart;*/

               --查询已决赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM web_fin_ri_amt ';
               V_SQL:=V_SQL||' where TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';

               EXECUTE IMMEDIATE V_SQL INTO v_clm_amt;

               --查询已报赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM WEB_FIN_RI_REPORT ';
               V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';

                begin
                    EXECUTE IMMEDIATE V_SQL INTO v_report_amt;
               exception when no_data_found then
                    v_report_amt:=0;
               end;

               SELECT NVL(sum(n_cal_amt*get_rate(C_CUR_CDE,'01',t_cal_tm)),0) into v_clm_fee
                from  web_fin_ri_mid_resclm a --,web_org_dpt b
                WHERE  decode(c_prod_no,'0320',c_prod_no,'---')=v_prod_no
                   and C_KIND_NO=V_KIND_NO
                   and to_char(t_pend_tm,'yyyy')=v_year
                   and to_char(t_pend_tm,'mm')<=v_month
                   and to_char(t_pend_tm,'mm')>=v_last_month
                   and c_cal_typ = '3';

               --查询尾部进展因子
                select a.n_ldf_tail into v_ldf_tail from web_fin_ibnr_pbl a
                where a.t_cal_tm = t_today_tm and a.c_ri_flag = '1'
                and a.c_type = '1' and a.c_lt_bf = '1'
                and a.c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no)
                and a.c_prod_no = decode(v_prod_no,'0320','0320','---');

               open cur_ibnr_amt_emp(v_kind_no,v_prod_no,v_cal_type);
                   loop
                     fetch cur_ibnr_amt_emp  into v_flg;
                      exit when cur_ibnr_amt_emp%notfound;

                      if v_count>=9 then
                        V_COLNME:='n_0'||round(V_COUNT+1)||'';
                     else
                        V_COLNME:='n_00'||round(V_COUNT+1)||'';
                     end if;
                      --查询已决累计进展因子
                      V_SQL:='SELECT nvl('||V_COLNME||',1)';
                      V_SQL:=V_SQL||' FROM WEB_FIN_RI_LDF_EMP ';
                      V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
                      V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
                      V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
                      V_SQL:=V_SQL||' AND C_FLG = '''||V_FLG||'''';
                      V_SQL:=V_SQL||' AND C_MRK = ''2'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''1'' ';

                      EXECUTE IMMEDIATE V_SQL INTO V_emp;



                      --最终赔款=已决赔款*最终累计进展因子(预估总赔款)
                      v_fina_amt:=v_clm_amt*(V_emp*v_ldf_tail);
                      --未决赔款(会计未决赔款准备金)
                      v_pend_amt:=(v_fina_amt-v_clm_amt)*(1+v_ibnr_risk)/POWER((1+v_ibnr_discount+v_ibnr_prem),v_ibnr_Duration);
                      --IBNR(含直接理赔费用)=会计未决准备金-已报未决含ALAE
                      v_ibnr_sum:=v_pend_amt-v_report_amt+v_clm_amt;
                      --IBNR直接理赔费用
                      V_dir_fee:=v_ibnr_sum*v_fee_rate_dir;
                      --间接理赔费用=已报未决(含直接费用)/2*间接理赔费用率 + IBNR(含直接费用)*间接费用率
                      V_indir_fee:=0;--((v_report_amt-v_clm_amt)/2+v_ibnr_sum)*v_fee_rate_indir;

                      insert into web_fin_ri_mid_ibnr_lt
                      (t_crt_tm,t_cal_tm,c_prod_no,n_utm_los,n_pend_amt,n_amt,n_report_amt,
                       n_evo_rate,n_ibnr,c_kind_no,c_year,c_quart,c_flg,c_type,N_ibnr_risk,
                       N_ibnr_prem,N_ibnr_discount,N_ibnr_Duration,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,
                       N_DIRFEE_RATE,N_INDIRFEE_RATE,N_CLM_RESFEE)
                       values(
                       sysdate,t_today_tm,v_prod_no,v_fina_amt,v_pend_amt,v_clm_amt,v_report_amt,
                       V_emp,v_ibnr_sum,v_kind_no,v_year,v_quart,v_flg,v_cal_type,V_ibnr_risk,
                       V_ibnr_prem,V_ibnr_discount,V_ibnr_Duration,V_dir_fee,V_indir_fee,
                       v_fee_rate_dir,v_fee_rate_indir,v_clm_fee
                       );
                   end loop;
               close cur_ibnr_amt_emp;
            end loop;
           close cur_ibnr_amt_lt;
       --基于已报链锑法
       elsif v_cal_type = '2' then
          --基于已报的链锑法
           open cur_ibnr_report_lt;
            loop
               fetch cur_ibnr_report_lt
                into v_kind_no,v_prod_no,v_year,v_quart;
               exit when cur_ibnr_report_lt%notfound;

               if v_quart = '1' then
                  v_month:='03';
               elsif v_quart = '2' then
                  v_month:='06';
               elsif v_quart = '3' then
                  v_month:='09';
               elsif v_quart = '4' then
                  v_month:='12';
               end if;
               v_count:=(months_between(to_date(v_cal_ym,'yyyymm'),to_date(v_year||v_month,'yyyymm'))-3)/3+1;
               if v_count>=10 then
                  V_COLNME:='n_0'||round(V_COUNT)||'';
               else
                  V_COLNME:='n_00'||round(V_COUNT)||'';
               end if;

               --风险边际
               select n_rate into v_ibnr_risk from WEB_FIN_IBNR_RATE
               where c_cde = '022004' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;
               --风险溢价
               v_ibnr_prem:=0;
               /*select n_rate into v_ibnr_prem from WEB_FIN_IBNR_RATE
               where c_cde = '014016' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;*/
               --贴现
               select n_rate into v_ibnr_discount from WEB_FIN_IBNR_RATE
               where c_cde = '022002' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --久期
               select n_rate into v_ibnr_Duration from WEB_FIN_IBNR_RATE
               where c_cde = '022001' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --直接理赔费用比例
               SELECT n_rate INTO v_fee_rate_dir FROM web_fin_ibnr_rate
               WHERE C_CDE='022005' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 /*and c_year = v_year and c_quart = v_quart*/;
               --间接理赔费用率
               /*SELECT n_rate INTO v_fee_rate_indir FROM web_fin_ibnr_rate
               WHERE C_CDE='014008' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 and c_year = v_year and c_quart = v_quart;*/

               --查询已决赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM web_fin_ri_amt ';
               V_SQL:=V_SQL||' where TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
               begin
                    EXECUTE IMMEDIATE V_SQL INTO v_clm_amt;
               exception when no_data_found then
                    v_clm_amt:=0;
               end;
               --查询已报赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM WEB_FIN_RI_REPORT ';
               V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';

               EXECUTE IMMEDIATE V_SQL INTO v_report_amt;

               SELECT NVL(sum(n_cal_amt*get_rate(C_CUR_CDE,'01',t_cal_tm)),0) into v_clm_fee
                from  web_fin_mid_resclm a --,web_org_dpt b
                WHERE  decode(c_prod_no,'0320',c_prod_no,'---')=v_prod_no
                   and C_KIND_NO=V_KIND_NO
                   and to_char(t_pend_tm,'yyyy')=v_year
                   and to_char(t_pend_tm,'mm')<=v_month
                   and to_char(t_pend_tm,'mm')>=v_last_month
                   and c_cal_typ = '3';
               --查询尾部进展因子
               select a.n_ldf_tail into v_ldf_tail from web_fin_ibnr_pbl a
               where a.t_cal_tm = t_today_tm and a.c_ri_flag = '1'
               and a.c_type = '2' and a.c_lt_bf = '1'
               and a.c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no)
               and a.c_prod_no = decode(v_prod_no,'0320','0320','---');

               open cur_ibnr_amt_emp(v_kind_no,v_prod_no,v_cal_type);
                   loop
                     fetch cur_ibnr_amt_emp  into v_flg;
                      exit when cur_ibnr_amt_emp%notfound;

                      if v_count>=9 then
                         V_COLNME:='n_0'||round(V_COUNT+1)||'';
                      else
                         V_COLNME:='n_00'||round(V_COUNT+1)||'';
                      end if;
                      --查询已报累计进展因子
                      V_SQL:='SELECT nvl('||V_COLNME||',1)';
                      V_SQL:=V_SQL||' FROM WEB_FIN_RI_LDF_EMP ';
                      V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
                      V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
                      V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
                      V_SQL:=V_SQL||' AND C_FLG = '''||V_FLG||'''';
                      V_SQL:=V_SQL||' AND C_MRK = ''2'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''2'' ';

                      EXECUTE IMMEDIATE V_SQL INTO V_emp;



                      --最终赔款=已报赔款*最终累计进展因子
                      v_fina_amt:=v_report_amt*V_emp*v_ldf_tail;
                      --未决赔款
                      v_pend_amt:=(v_fina_amt-v_clm_amt)*(1+v_ibnr_risk)/POWER((1+v_ibnr_discount+v_ibnr_prem),v_ibnr_Duration);
                      --IBNR(含直接理赔费用)
                      v_ibnr_sum:=v_pend_amt-v_report_amt+v_clm_amt;
                      --IBNR直接理赔费用
                      V_dir_fee:=v_ibnr_sum*v_fee_rate_dir;
                      --间接理赔费用=已报未决(含直接费用)/2*间接理赔费用率 + IBNR(含直接费用)*间接费用率
                      V_indir_fee:=0;--((v_report_amt-v_clm_amt)/2+v_ibnr_sum)*v_fee_rate_indir;

                      insert into web_fin_ri_mid_ibnr_lt
                      (t_crt_tm,t_cal_tm,c_prod_no,n_utm_los,n_pend_amt,n_amt,n_report_amt,
                       n_evo_rate,n_ibnr,c_kind_no,c_year,c_quart,c_flg,c_type,N_ibnr_risk,
                       N_ibnr_prem,N_ibnr_discount,N_ibnr_Duration,N_IBNR_DIRFEE,N_IBNR_INDIRFEE,
                       N_DIRFEE_RATE,N_INDIRFEE_RATE,N_CLM_RESFEE)
                       values(
                       sysdate,t_today_tm,v_prod_no,v_fina_amt,v_pend_amt,v_clm_amt,v_report_amt,
                       V_emp,v_ibnr_sum,v_kind_no,v_year,v_quart,v_flg,v_cal_type,V_ibnr_risk,
                       V_ibnr_prem,V_ibnr_discount,V_ibnr_Duration,V_dir_fee,V_indir_fee,
                       v_fee_rate_dir,v_fee_rate_indir,v_clm_fee
                       );
                       i:=i+1;
                   end loop;
               close cur_ibnr_amt_emp;
            end loop;
           close cur_ibnr_report_lt;

       end if;
      commit;
      exception
      When Others Then
        Rollback;
        v_Sqlcode := Sqlcode;
        v_Sqlerrm := Substr(Sqlerrm, 1, 600);
        ROLLBACK;

      v_err_content:='proc:[P_Fin_RI_CAL_LT],出错流水号:['||v_today||'  '||v_cal_type||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end P_Fin_RI_CAL_LT;
    ---链锑法结束
    -----------------------------------------------------------------------------------
    ----BF开始
    procedure P_Fin_RI_CAL_BF(v_today varchar2, v_cal_type in char, v_return out varchar2)
      is
       --已决
        cursor cur_ibnr_amt_bf is
        select
            distinct a.c_kind_no,a.c_prod_no,a.c_year,A.C_QUART
         from web_fin_ri_amt a
         where trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd')/*
         and a.c_year = '2012' and a.c_quart = '3' and a.c_kind_no = '01'*/;
        --已报
        cursor cur_ibnr_report_bf is
        select
            distinct a.c_kind_no,a.c_prod_no,a.c_year,A.C_QUART
         from WEB_FIN_RI_REPORT a
         where trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd')/*
         and c_kind_no = '01' and a.c_year = '2012' and a.c_quart = '3'*/;
        --查询累计进展因子
        cursor cur_ibnr_amt_emp(v_kind varchar2,v_prod varchar2,v_typ varchar2) is
         select --1:原始加权平均法,2:简单算术平均法,3:最近两个事故原始加权平均法,4:手动录入进展因子
            distinct a.c_flg
         from WEB_FIN_RI_LDF_EMP a
         where C_MRK = '2'
         and C_TOTAL_MRK = '2'
         and C_TYPE = v_typ
         and c_kind_no = v_kind
         and c_prod_no = v_prod
         and trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd');
      begin
        t_today_tm:=to_date(v_today,'yyyy-mm-dd');
        v_return:=1;
        delete from web_fin_ri_mid_ibnr_bf WHERE TRUNC(T_CAL_TM) = TRUNC(t_today_tm) and c_type = v_cal_type;
        v_cal_ym:=to_char(TRUNC(ADD_MONTHS(t_today_tm + 2/24, 3 ), 'Q' )-1,'yyyymm');
        if v_cal_type = '1' then

           /*select min(a.c_year||a.c_quart) into v_yearmonth from web_fin_ri_amt a
           where trunc(a.t_cal_tm) = to_date(v_today,'yyyy-mm-dd');
           if substr(v_yearmonth,5,1) = '1' then
              v_yearmonth:=substr(v_yearmonth,1,4)||'03';
           elsif v_yearmonth = '2' then
              v_yearmonth:=substr(v_yearmonth,1,4)||'06';
           elsif v_yearmonth = '3' then
              v_yearmonth:=substr(v_yearmonth,1,4)||'09';
           elsif v_quart = '4' then
              v_yearmonth:=substr(v_yearmonth,1,4)||'12';
           end if;
           v_countsum:=(months_between(to_date(v_cal_ym,'yyyymm'),to_date(v_yearmonth,'yyyymm'))-3)/3+1;*/
           --基于已决的BF法
           open cur_ibnr_amt_bf;
            loop
               fetch cur_ibnr_amt_bf
                into v_kind_no,v_prod_no,v_year,v_quart;
               exit when cur_ibnr_amt_bf%notfound;

               if v_quart = '1' then
                  v_month:='03';
               elsif v_quart = '2' then
                  v_month:='06';
               elsif v_quart = '3' then
                  v_month:='09';
               elsif v_quart = '4' then
                  v_month:='12';
               end if;
               v_count:=(months_between(to_date(v_cal_ym,'yyyymm'),to_date(v_year||v_month,'yyyymm'))-3)/3+1;
               if v_count>=10 then
                  V_COLNME:='n_0'||round(V_COUNT)||'';
               else
                  V_COLNME:='n_00'||round(V_COUNT)||'';
               end if;

               --风险边际
               select n_rate into v_ibnr_risk from WEB_FIN_IBNR_RATE
               where c_cde = '026004' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;
               --风险溢价
               v_ibnr_prem:=0;
               /*select n_rate into v_ibnr_prem from WEB_FIN_IBNR_RATE
               where c_cde = '014016' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;*/
               --贴现
               select n_rate into v_ibnr_discount from WEB_FIN_IBNR_RATE
               where c_cde = '026002' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --久期
               select n_rate into v_ibnr_Duration from WEB_FIN_IBNR_RATE
               where c_cde = '026001' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --直接理赔费用比例
               SELECT n_rate INTO v_fee_rate_dir FROM web_fin_ibnr_rate
               WHERE C_CDE='026005' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 /*and c_year = v_year and c_quart = v_quart*/;
               --间接理赔费用率
               /*SELECT n_rate INTO v_fee_rate_indir FROM web_fin_ibnr_rate
               WHERE C_CDE='014008' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 and c_year = v_year and c_quart = v_quart;*/

               --查询已赚保费
               V_SQL:='SELECT SUM(n_got_prm) FROM web_fin_ri_gotprm_quart';
               V_SQL:=V_SQL||' where C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||V_KIND_NO||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||V_PROD_NO||'''';

               EXECUTE IMMEDIATE V_SQL INTO V_got_prm;

               --查询已决赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM web_fin_ri_amt ';
               V_SQL:=V_SQL||' where TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';

               EXECUTE IMMEDIATE V_SQL INTO v_clm_amt;

               --查询已报赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM WEB_FIN_RI_REPORT ';
               V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';

               begin
                    EXECUTE IMMEDIATE V_SQL INTO v_report_amt;
               exception when no_data_found then
                    v_report_amt:=0;
               end;

               --查询尾部进展因子
               select a.n_ldf_tail into v_ldf_tail from web_fin_ibnr_pbl a
               where a.t_cal_tm = t_today_tm and a.c_ri_flag = '1'
               and a.c_type = '1' and a.c_lt_bf = '2'
               and a.c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no)
               and a.c_prod_no = decode(v_prod_no,'0320','0320','---');

               open cur_ibnr_amt_emp(v_kind_no,v_prod_no,v_cal_type);
                   loop
                     fetch cur_ibnr_amt_emp  into v_flg;
                      exit when cur_ibnr_amt_emp%notfound;
                      /*v_countcol:=v_countsum-v_count;
                      if v_countcol>=10 then
                         V_COLNME:='n_0'||round(v_countcol)||'';
                      else
                         V_COLNME:='n_00'||round(v_countcol)||'';
                      end if;*/
                      if v_count>=9 then
                         V_COLNME:='n_0'||round(v_count+1)||'';
                      else
                         V_COLNME:='n_00'||round(v_count+1)||'';
                      end if;
                      --查询已决累计进展因子
                      V_SQL:='SELECT nvl('||V_COLNME||',1)';
                      V_SQL:=V_SQL||' FROM WEB_FIN_RI_LDF_EMP ';
                      V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
                      V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
                      V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
                      V_SQL:=V_SQL||' AND C_FLG = '''||V_FLG||'''';
                      V_SQL:=V_SQL||' AND C_MRK = ''2'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''1'' ';

                      EXECUTE IMMEDIATE V_SQL INTO V_emp;


                      --IBNR(含直接理赔费用)/最终赔款 = 1-1/累计进展因子
                      if V_emp = 0 then
                         V_emp:=1;
                      end if;
                      v_evo_rate:=1-1/(V_emp*v_ldf_tail);

                      --赔付率
                     select n_rate into v_emp_pay from WEB_FIN_IBNR_RATE
                     where c_cde = '026007' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                     and c_year = v_year and c_quart = v_quart;

                      --最终赔款=满期*赔付率
                      v_fina_amt:=V_got_prm*v_emp_pay;
                     --未决赔款(会计未决赔款准备金)
                      v_pend_amt:=v_fina_amt*v_evo_rate*(1+v_ibnr_risk)/POWER((1+v_ibnr_discount+v_ibnr_prem),v_ibnr_Duration);
                      --IBNR(含直接理赔费用)=会计未决准备金-已报未决含ALAE
                      v_ibnr_sum:=v_pend_amt-v_report_amt+v_clm_amt;
                      --IBNR直接理赔费用
                      V_dir_fee:=v_ibnr_sum*v_fee_rate_dir;
                      --间接理赔费用=已报未决(含直接费用)/2*间接理赔费用率 + IBNR(含直接费用)*间接费用率
                      V_indir_fee:=0;--((v_report_amt-v_clm_amt)/2+v_ibnr_sum)*v_fee_rate_indir;
                      --IBNR(含直接理赔费用)=最终赔款*(IBNR(含直接理赔费用)/最终赔款)=最终赔款*(1-1/累计进展因子)
                      --v_ibnr_sum:=v_fina_amt*v_evo_rate;

                      insert into web_fin_ri_mid_ibnr_bf
                      (t_crt_tm,t_cal_tm,c_prod_no,n_got_prm,N_PAY_RATE,N_UTM_LOS,N_EVO_RATE,
                       N_PEND_AMT,N_IBNR_BF,c_kind_no,c_year,c_quart,c_flg,c_type,N_LDF,
                       N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_DIRFEE_RATE,N_INDIRFEE_RATE,N_IBNR_AMT,n_amt)
                       values(
                       sysdate,t_today_tm,v_prod_no,V_got_prm,v_emp_pay,v_fina_amt,v_evo_rate,
                       (v_report_amt-v_clm_amt),v_ibnr_sum,v_kind_no,v_year,v_quart,v_flg,v_cal_type,V_emp,
                       V_dir_fee,V_indir_fee,v_fee_rate_dir,v_fee_rate_indir,v_pend_amt,v_clm_amt
                       );
                   end loop;
               close cur_ibnr_amt_emp;
            end loop;
           close cur_ibnr_amt_bf;
       --基于已报BF法
       elsif v_cal_type = '2' then
          --基于已决的BF法
           --基于已决的BF法
           open cur_ibnr_report_bf;
            loop
               fetch cur_ibnr_report_bf
                into v_kind_no,v_prod_no,v_year,v_quart;
               exit when cur_ibnr_report_bf%notfound;

               if v_quart = '1' then
                  v_month:='03';
               elsif v_quart = '2' then
                  v_month:='06';
               elsif v_quart = '3' then
                  v_month:='09';
               elsif v_quart = '4' then
                  v_month:='12';
               end if;
               v_count:=(months_between(to_date(v_cal_ym,'yyyymm'),to_date(v_year||v_month,'yyyymm'))-3)/3+1;
               if v_count>=10 then
                  V_COLNME:='n_0'||round(V_COUNT)||'';
               else
                  V_COLNME:='n_00'||round(V_COUNT)||'';
               end if;

               --风险边际
               select n_rate into v_ibnr_risk from WEB_FIN_IBNR_RATE
               where c_cde = '026004' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;
               --风险溢价
               v_ibnr_prem:=0;
               /*select n_rate into v_ibnr_prem from WEB_FIN_IBNR_RATE
               where c_cde = '014016' and c_kind_no = v_kind_no and c_prod_no = v_prod_no;*/
               --贴现
               select n_rate into v_ibnr_discount from WEB_FIN_IBNR_RATE
               where c_cde = '026002' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --久期
               select n_rate into v_ibnr_Duration from WEB_FIN_IBNR_RATE
               where c_cde = '026001' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                /*and c_year = v_year and c_quart = v_quart*/;
               --直接理赔费用比例
               SELECT n_rate INTO v_fee_rate_dir FROM web_fin_ibnr_rate
               WHERE C_CDE='026005' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 /*and c_year = v_year and c_quart = v_quart*/;
               --间接理赔费用率 再保分出无
               /*SELECT n_rate INTO v_fee_rate_indir FROM web_fin_ibnr_rate
               WHERE C_CDE='014008' AND c_kind_no=v_kind_no and  C_PROD_NO = v_prod_no
                 and c_year = v_year and c_quart = v_quart;*/

               --查询已赚保费
               V_SQL:='SELECT SUM(n_got_prm) FROM web_fin_ri_gotprm_quart';
               V_SQL:=V_SQL||' where C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||V_KIND_NO||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||V_PROD_NO||'''';

               EXECUTE IMMEDIATE V_SQL INTO V_got_prm;

               --查询已决赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM web_fin_ri_amt ';
               V_SQL:=V_SQL||' where TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';

               begin
                    EXECUTE IMMEDIATE V_SQL INTO v_clm_amt;
               exception when no_data_found then
                    v_clm_amt:=0;
               end;

               --查询已报赔款
               V_SQL:='SELECT '||V_COLNME;
               V_SQL:=V_SQL||' FROM WEB_FIN_RI_REPORT ';
               V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
               V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
               V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
               V_SQL:=V_SQL||' AND C_YEAR = '''||v_year||'''';
               V_SQL:=V_SQL||' AND C_QUART = '''||v_quart||'''';

               EXECUTE IMMEDIATE V_SQL INTO v_report_amt;

               --查询尾部进展因子
              select a.n_ldf_tail into v_ldf_tail from web_fin_ibnr_pbl a
              where a.t_cal_tm = t_today_tm and a.c_ri_flag = '1'
              and a.c_type = '2' and a.c_lt_bf = '2'
              and a.c_kind_no = decode(v_prod_no,'0320','0320',v_kind_no)
              and a.c_prod_no = decode(v_prod_no,'0320','0320','---');

               open cur_ibnr_amt_emp(v_kind_no,v_prod_no,v_cal_type);
                   loop
                     fetch cur_ibnr_amt_emp  into v_flg;
                      exit when cur_ibnr_amt_emp%notfound;

                      if v_count>=9 then
                         V_COLNME:='n_0'||round(V_COUNT+1)||'';
                      else
                         V_COLNME:='n_00'||round(V_COUNT+1)||'';
                      end if;
                      --查询已报累计进展因子
                      V_SQL:='SELECT nvl('||V_COLNME||',1)';
                      V_SQL:=V_SQL||' FROM WEB_FIN_RI_LDF_EMP ';
                      V_SQL:=V_SQL||' WHERE TO_CHAR(T_CAL_TM,''YYYY-MM-DD'') = '''||v_today||'''';
                      V_SQL:=V_SQL||' AND C_KIND_NO = '''||v_kind_no||'''';
                      V_SQL:=V_SQL||' AND C_PROD_NO = '''||v_prod_no||'''';
                      V_SQL:=V_SQL||' AND C_FLG = '''||V_FLG||'''';
                      V_SQL:=V_SQL||' AND C_MRK = ''2'' AND C_TOTAL_MRK = ''2'' AND C_TYPE = ''2'' ';

                      EXECUTE IMMEDIATE V_SQL INTO V_emp;


                      --IBNR(含直接理赔费用)/最终赔款 = 1-1/累计进展因子
                      if V_emp = 0 then
                         V_emp:=1;
                      end if;
                      v_evo_rate:=1-1/(V_emp*v_ldf_tail);

                      --赔付率
                     select n_rate into v_emp_pay from WEB_FIN_IBNR_RATE
                     where c_cde = '026007' and c_kind_no = v_kind_no and c_prod_no = v_prod_no
                     and c_year = v_year and c_quart = v_quart;

                      --最终赔款=满期*赔付率
                      v_fina_amt:=V_got_prm*v_emp_pay;
                      --IBNR含ALAE = 最终赔款*(1-1/进展因子)
                      v_ibnr_sum:=v_fina_amt*v_evo_rate;
                     --未决赔款(会计未决赔款准备金)
                      v_pend_amt:=(v_ibnr_sum+v_report_amt-v_clm_amt)*(1+v_ibnr_risk)/POWER((1+v_ibnr_discount+v_ibnr_prem),v_ibnr_Duration);
                      --IBNR(含直接理赔费用)=会计未决准备金-已报未决含ALAE
                      v_ibnr_sum:=v_pend_amt-v_report_amt+v_clm_amt;
                      --IBNR直接理赔费用
                      V_dir_fee:=v_ibnr_sum*v_fee_rate_dir;
                      --间接理赔费用=已报未决(含直接费用)/2*间接理赔费用率 + IBNR(含直接费用)*间接费用率
                      V_indir_fee:=0;--((v_report_amt-v_clm_amt)/2+v_ibnr_sum)*v_fee_rate_indir;

                      --IBNR(含直接理赔费用)=最终赔款*(IBNR(含直接理赔费用)/最终赔款)=最终赔款*(1-1/累计进展因子)
                      --v_ibnr_sum:=v_fina_amt*v_evo_rate;

                      insert into web_fin_ri_mid_ibnr_bf
                      (t_crt_tm,t_cal_tm,c_prod_no,n_got_prm,N_PAY_RATE,N_UTM_LOS,N_EVO_RATE,
                       N_PEND_AMT,N_IBNR_BF,c_kind_no,c_year,c_quart,c_flg,c_type,N_LDF,
                       N_IBNR_DIRFEE,N_IBNR_INDIRFEE,N_DIRFEE_RATE,N_INDIRFEE_RATE,N_IBNR_AMT,n_amt)
                       values(
                       sysdate,t_today_tm,v_prod_no,V_got_prm,v_emp_pay,v_fina_amt,v_evo_rate,
                       (v_report_amt-v_clm_amt),v_ibnr_sum,v_kind_no,v_year,v_quart,v_flg,v_cal_type,V_emp,
                       V_dir_fee,V_indir_fee,v_fee_rate_dir,v_fee_rate_indir,v_pend_amt,v_clm_amt
                       );
                   end loop;
               close cur_ibnr_amt_emp;
            end loop;
           close cur_ibnr_report_bf;

       end if;
      commit;
      exception
      When Others Then
        Rollback;
        v_Sqlcode := Sqlcode;
        v_Sqlerrm := Substr(Sqlerrm, 1, 600);
        ROLLBACK;

      v_err_content:='proc:[P_Fin_RI_CAL_BF],出错流水号:['||v_today||'  '||v_cal_type||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end P_Fin_RI_CAL_BF;
    ----BF结束

end P_FIN_RI_IBNR_CAL;
/
