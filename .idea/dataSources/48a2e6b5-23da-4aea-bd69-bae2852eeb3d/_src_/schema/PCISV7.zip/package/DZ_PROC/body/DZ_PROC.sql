CREATE PACKAGE BODY "DZ_PROC" 
IS
/* 补0函数,  */
   FUNCTION fill_zero (
      i_str         VARCHAR2,                                 /* 转换字符串 */
      i_length      NUMBER,                                   /* 字符串长度 */
      i_direction   NUMBER
   )                                                 /* 补0方向，0=左，1=右 */
      RETURN VARCHAR2
   IS
      str_len   NUMBER;
      n         NUMBER;
      o_str     VARCHAR2 (100);
   BEGIN
      str_len := LENGTH (i_str);

      IF str_len >= i_length
      THEN
         RETURN (i_str);
      END IF;

      IF i_direction = 0
      THEN
         o_str := '';
         n := 0;

         LOOP
            IF n >= i_length - str_len
            THEN
               EXIT;
            END IF;

            o_str := o_str || '0';
            n := n + 1;
         END LOOP;

         o_str := o_str || i_str;
      ELSE
         o_str := i_str;
         n := 0;

         LOOP
            IF n >= i_length - str_len
            THEN
               EXIT;
            END IF;

            o_str := o_str || '0';
            n := n + 1;
         END LOOP;
      END IF;

      RETURN (o_str);
   END;

/*************************产生理算流水号 SEQUENCE finseq******************/
--------配对单流水号：年月日YYYYMMDD（8位）+机构码（7）+事业部门类型(2)+类型（MA）＋流水号（4位）--
--------结算单流水号：年月日YYYYMMDD（8位）+机构码（7）+事业部门类型(2)+类型（RI）＋流水号（4位）--
   PROCEDURE get_fin_no (
      ofincde    OUT   WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
      icdptcde            WEB_ORG_DPT.c_dpt_cde%TYPE,
      icfintyp            VARCHAR2,
      idep_type                         VARCHAR2
   )
   IS
      v_date      VARCHAR2 (8);
      v_dptcde    VARCHAR2 (50);  -- modify by wuqy 2012-12-18
      v_serieno   VARCHAR2 (10);
      v_fintyp    VARCHAR2 (2);
      v_count     NUMBER;
   BEGIN
      v_date := TO_CHAR (SYSDATE, 'YYYYMMDD');
      v_dptcde := LTRIM (RTRIM (icdptcde));
      v_fintyp := LTRIM (RTRIM (icfintyp));

      IF (LENGTH (v_dptcde) >= 7)
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 7);
      ELSE
         v_dptcde := fill_zero (v_dptcde, 7, 1);
      END IF;

      SELECT COUNT (*)
        INTO v_count
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_count > 0
      THEN
         UPDATE WEB_BAS_FIN_SERIENO
            SET c_serie_no = c_serie_no + 1
          WHERE c_dpt_cde = v_dptcde
            AND c_vch_typ = v_fintyp
            AND c_time = v_date;
      ELSE
              INSERT INTO WEB_BAS_FIN_SERIENO
                     (t_crt_tm, t_upd_tm, c_dpt_cde, c_vch_typ, c_time,
                      c_serie_no
                     )
              VALUES (SYSDATE, SYSDATE, v_dptcde, v_fintyp, v_date,
                      1
                     );

      END IF;

      SELECT c_serie_no
        INTO v_serieno
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_fintyp = 'MA'
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 6);
         ofincde :=
                v_date || v_dptcde ||idep_type|| v_fintyp || fill_zero (v_serieno, 6, 0);
      ELSE
         ofincde :=
                v_date || v_dptcde ||idep_type|| v_fintyp || fill_zero (v_serieno, 6, 0);
      END IF;
   END;

/*************************产生订单流水号 SEQUENCE finseq******************/
--------订单号：年月日YYYYMMDD（8位）+类型（A1财产、A2寿险、A3健康）+公司码（7）+事业部门类型(2)+流水号（6位）

   PROCEDURE get_order_no (
      ofincde    OUT   WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
      icdptcde            WEB_ORG_DPT.c_dpt_cde%TYPE,
      icfintyp            VARCHAR2,
      idep_type                         VARCHAR2
   )
   IS
      v_date      VARCHAR2 (8);
      v_dptcde    VARCHAR2 (11);
      v_serieno   VARCHAR2 (10);
      v_fintyp    VARCHAR2 (2);
      v_count     NUMBER;
   BEGIN
      v_date := TO_CHAR (SYSDATE, 'YYYYMMDD');
      v_dptcde := LTRIM (RTRIM (icdptcde));
      v_fintyp := LTRIM (RTRIM (icfintyp));

      IF (LENGTH (v_dptcde) >= 7)
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 7);
      ELSE
         v_dptcde := fill_zero (v_dptcde, 7, 1);
      END IF;

      SELECT COUNT (*)
        INTO v_count
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_count > 0
      THEN
         UPDATE WEB_BAS_FIN_SERIENO
            SET c_serie_no = c_serie_no + 1
          WHERE c_dpt_cde = v_dptcde
            AND c_vch_typ = v_fintyp
            AND c_time = v_date;
      ELSE
              INSERT INTO WEB_BAS_FIN_SERIENO
                     (t_crt_tm, t_upd_tm, c_dpt_cde, c_vch_typ, c_time,
                      c_serie_no
                     )
              VALUES (SYSDATE, SYSDATE, v_dptcde, v_fintyp, v_date,
                      1
                     );

      END IF;

      SELECT c_serie_no
        INTO v_serieno
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_fintyp = 'A1' --财产险
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 6);
         ofincde :=
                TO_CHAR (SYSDATE, 'YYMMDD') ||'1'||v_dptcde ||idep_type||  fill_zero (v_serieno, 6, 0);
      ELSIF v_fintyp = 'A2' --寿险
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 6);
         ofincde :=
                TO_CHAR (SYSDATE, 'YYMMDD')||'2'||v_dptcde ||idep_type||  fill_zero (v_serieno, 6, 0);
      ELSE
         ofincde :=
                TO_CHAR (SYSDATE, 'YYMMDD')||'3'|| v_dptcde ||idep_type|| v_fintyp || fill_zero (v_serieno, 6, 0);
      END IF;
   END;



/*************************产生收付款流水号 SEQUENCE finseq******************/
--------付款流水号：年月日YYYYMMDD（8位）+机构码（7）+事业部门类型(2)+类型（AP）＋流水号（4位）----
--------收款流水号：年月日YYYYMMDD（8位）+机构码（7）+事业部门类型(2)+类型（AR）＋流水号（4位）----
   PROCEDURE get_fin_cav_no (
      ofincde    IN OUT   WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
      icdptcde            WEB_ORG_DPT.c_dpt_cde%TYPE,
      icfintyp            VARCHAR2,
      idep_type                     VARCHAR2
   )
   IS
      v_date      VARCHAR2 (8);
      v_dptcde    VARCHAR2 (11);
      v_serieno   VARCHAR2 (10);
      v_fintyp    VARCHAR2 (2);
      v_count     NUMBER;
   BEGIN
      v_date := TO_CHAR (SYSDATE, 'YYYYMMDD');
      v_dptcde := LTRIM (RTRIM (icdptcde));
      v_fintyp := LTRIM (RTRIM (icfintyp));

      IF (LENGTH (v_dptcde) >= 7)
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 7);
      ELSE
         v_dptcde := fill_zero (v_dptcde, 7, 1);
      END IF;

      SELECT COUNT (*)
        INTO v_count
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_count > 0
      THEN
         UPDATE WEB_BAS_FIN_SERIENO
            SET c_serie_no = c_serie_no + 1
          WHERE c_dpt_cde = v_dptcde
            AND c_vch_typ = v_fintyp
            AND c_time = v_date;
      ELSE
              INSERT INTO WEB_BAS_FIN_SERIENO
                     (t_crt_tm, t_upd_tm, c_dpt_cde, c_vch_typ, c_time,
                      c_serie_no
                     )
              VALUES (SYSDATE, SYSDATE, v_dptcde, v_fintyp, v_date,
                      1
                     );

      END IF;

      SELECT c_serie_no
        INTO v_serieno
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_fintyp = 'MA'
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 6);
         ofincde :=
                v_date || v_dptcde ||idep_type|| v_fintyp || fill_zero (v_serieno, 6, 0);
      ELSE
         ofincde :=
                v_date || v_dptcde ||idep_type|| v_fintyp || fill_zero (v_serieno, 6, 0);
      END IF;
   END;



/*获取凭证号*/
/* PROCEDURE get_fin_voucode (
      v_vou_no        IN OUT   WEB_FIN_DCR.c_vou_no%TYPE,
      v_period_name   IN OUT   WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE,
      v_dptacc_cde             WEB_FIN_DCR.c_dptacc_no%TYPE,
      idep_type                         VARCHAR2
   )
   IS
      v_serieno       VARCHAR2 (12);
      n_serieno       NUMBER;
      v_fintyp        VARCHAR2 (2);
      v_count         NUMBER;
      v_company_cde   WEB_ORG_DPT.c_company_cde%TYPE;
   BEGIN */
      --获取需要信息,保证生成凭证号/会计期间/公司信息
      /*
      SELECT c_company_cde
         INTO v_company_cde
         FROM WEB_ORG_DPT
         WHERE c_dpt_cde=v_dptacc_cde;
      */
  /*    v_company_cde := v_dptacc_cde;
      v_fintyp := 'X';

      SELECT COUNT (*)
        INTO v_count
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptacc_cde
         AND c_vch_typ = 'X'
         AND c_time =
                   SUBSTR (v_period_name, 1, 4)
                || SUBSTR (v_period_name, 6, 2)
                || '01';

      IF v_count > 0
      THEN
         UPDATE WEB_BAS_FIN_SERIENO
            SET c_serie_no = c_serie_no + 1
          WHERE c_dpt_cde = v_dptacc_cde
            AND c_vch_typ = 'X'
            AND c_time =
                      SUBSTR (v_period_name, 1, 4)
                   || SUBSTR (v_period_name, 6, 2)
                   || '01';
      ELSE
         INSERT INTO WEB_BAS_FIN_SERIENO
                     (t_crt_tm, t_upd_tm, c_dpt_cde, c_vch_typ,
                      c_time,
                      c_serie_no
                     )
              VALUES (SYSDATE, SYSDATE, v_dptacc_cde, v_fintyp,
                         SUBSTR (v_period_name, 1, 4)
                      || SUBSTR (v_period_name, 6, 2)
                      || '01',
                      1
                     );
      END IF;

      SELECT c_serie_no
        INTO n_serieno
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptacc_cde
         AND c_vch_typ = v_fintyp
         AND c_time =
                   SUBSTR (v_period_name, 1, 4)
                || SUBSTR (v_period_name, 6, 2)
                || '01';

      --公司编码（7位）+凭证来源（2位）+年/月（4位）+每月顺序号(6
            v_serieno := TRIM (TO_CHAR (n_serieno, '000000'));
      v_vou_no :=
            SUBSTR (v_company_cde || '0000000', 1, 7)
         || '01'
         || SUBSTR (v_period_name, 3, 2)
         || SUBSTR (v_period_name, 6, 2)
         || v_serieno;
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (SQLCODE);
         RETURN;
   END;

*/
/*再保获取凭证号,流水号表用B标识 */

-- wuqy 暂时屏蔽
/*
   PROCEDURE get_fin_rivoucode (
      v_vou_no        IN OUT   WEB_FIN_DCR.c_vou_no%TYPE,
      v_period_name   IN OUT   WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE,
      v_dptacc_cde             WEB_FIN_DCR.c_dptacc_no%TYPE,
      idep_type                         VARCHAR2
   )
   IS
      v_serieno       VARCHAR2 (12);
      n_serieno       NUMBER;
      v_fintyp        VARCHAR2 (2);
      v_count         NUMBER;
      v_company_cde   WEB_ORG_DPT.c_company_cde%TYPE;
   BEGIN */
      --获取需要信息,保证生成凭证号/会计期间/公司信息
      /*
      SELECT c_company_cde
         INTO v_company_cde
         FROM WEB_ORG_DPT
         WHERE c_dpt_cde=v_dptacc_cde;
      */
/*      v_company_cde := v_dptacc_cde;
      v_fintyp := 'B';

      SELECT COUNT (*)
        INTO v_count
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptacc_cde
         AND c_vch_typ = 'B'
         AND c_time =
                   SUBSTR (v_period_name, 1, 4)
                || SUBSTR (v_period_name, 6, 2)
                || '01';

      IF v_count > 0
      THEN
         UPDATE WEB_BAS_FIN_SERIENO
            SET c_serie_no = c_serie_no + 1
          WHERE c_dpt_cde = v_dptacc_cde
            AND c_vch_typ = 'B'
            AND c_time =
                      SUBSTR (v_period_name, 1, 4)
                   || SUBSTR (v_period_name, 6, 2)
                   || '01';
      ELSE
         INSERT INTO WEB_BAS_FIN_SERIENO
                     (t_crt_tm, t_upd_tm, c_dpt_cde, c_vch_typ,
                      c_time,
                      c_serie_no
                     )
              VALUES (SYSDATE, SYSDATE, v_dptacc_cde, v_fintyp,
                         SUBSTR (v_period_name, 1, 4)
                      || SUBSTR (v_period_name, 6, 2)
                      || '01',
                      1
                     );
      END IF;

      SELECT c_serie_no
        INTO n_serieno
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptacc_cde
         AND c_vch_typ = v_fintyp
         AND c_time =
                   SUBSTR (v_period_name, 1, 4)
                || SUBSTR (v_period_name, 6, 2)
                || '01';

      --公司编码（7位）+凭证来源（2位 再保03 准备金04）+年/月（4位）+每月顺序号（6位)
      v_serieno := TRIM (TO_CHAR (n_serieno, '000000'));
      v_vou_no :=
            SUBSTR (v_company_cde || '0000000', 1, 7)
         || '03'
         || SUBSTR (v_period_name, 3, 2)
         || SUBSTR (v_period_name, 6, 2)
         || v_serieno;
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (SQLCODE);
         RETURN;
   END;
*/
/*准备金获取凭证号,流水号表用Z标识 */
/*
   PROCEDURE get_fin_prevoucode (
      v_vou_no        IN OUT   WEB_FIN_DCR.c_vou_no%TYPE,
      v_period_name   IN OUT   WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE,
      v_dptacc_cde             WEB_FIN_DCR.c_dptacc_no%TYPE,
      idep_type                         VARCHAR2
   )
   IS
      v_serieno       VARCHAR2 (12);
      n_serieno       NUMBER;
      v_fintyp        VARCHAR2 (2);
      v_count         NUMBER;
      v_company_cde   WEB_ORG_DPT.c_company_cde%TYPE;
   BEGIN
 */     --获取需要信息,保证生成凭证号/会计期间/公司信息
      /*
      SELECT c_company_cde
         INTO v_company_cde
         FROM WEB_ORG_DPT
         WHERE c_dpt_cde=v_dptacc_cde;
      */
/*      v_company_cde := v_dptacc_cde;
      v_fintyp := 'Z';

      SELECT COUNT (*)
        INTO v_count
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptacc_cde
         AND c_vch_typ = 'Z'
         AND c_time =
                   SUBSTR (v_period_name, 1, 4)
                || SUBSTR (v_period_name, 6, 2)
                || '01';

      IF v_count > 0
      THEN
         UPDATE WEB_BAS_FIN_SERIENO
            SET c_serie_no = c_serie_no + 1
          WHERE c_dpt_cde = v_dptacc_cde
            AND c_vch_typ = 'Z'
            AND c_time =
                      SUBSTR (v_period_name, 1, 4)
                   || SUBSTR (v_period_name, 6, 2)
                   || '01';
      ELSE
         INSERT INTO WEB_BAS_FIN_SERIENO
                     (t_crt_tm, t_upd_tm, c_dpt_cde, c_vch_typ,
                      c_time,
                      c_serie_no
                     )
              VALUES (SYSDATE, SYSDATE, v_dptacc_cde, v_fintyp,
                         SUBSTR (v_period_name, 1, 4)
                      || SUBSTR (v_period_name, 6, 2)
                      || '01',
                      1
                     );
      END IF;

      SELECT c_serie_no
        INTO n_serieno
        FROM WEB_BAS_FIN_SERIENO
       WHERE c_dpt_cde = v_dptacc_cde
         AND c_vch_typ = v_fintyp
         AND c_time =
                   SUBSTR (v_period_name, 1, 4)
                || SUBSTR (v_period_name, 6, 2)
                || '01';

      --公司编码（7位）+凭证来源（2位 再保03 准备金04）+年/月（4位）+每月顺序号（6位)
      v_serieno := TRIM (TO_CHAR (n_serieno, '000000'));
      v_vou_no :=
            SUBSTR (v_company_cde || '0000000', 1, 7)
         || '04'
         || SUBSTR (v_period_name, 3, 2)
         || SUBSTR (v_period_name, 6, 2)
         || v_serieno;
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (SQLCODE);
         RETURN;
   END;
*/

/*************************产生业务接口流水号 SEQUENCE finseq******************/
--------业务接口流水号：类型（MA）＋年月日YYYYMMDD（8位）+机构码（7）+事业部门类型(2)+流水号（4位）--

   PROCEDURE get_ifin_no (
      ofincde    OUT   WEB_FIN_CAV_BILL.C_CAV_PK_ID%TYPE,
      icdptcde            WEB_ORG_DPT.c_dpt_cde%TYPE,
      icfintyp            VARCHAR2,
      idep_type                         VARCHAR2
   )
   IS
      v_date      VARCHAR2 (8);
      v_dptcde    VARCHAR2 (11);
      v_serieno   VARCHAR2 (10);
      v_fintyp    VARCHAR2 (2);
      v_count     NUMBER;
   BEGIN
      v_date := TO_CHAR (SYSDATE, 'YYYYMMDD');
      v_dptcde := LTRIM (RTRIM (icdptcde));
      v_fintyp := LTRIM (RTRIM (icfintyp));

      IF (LENGTH (v_dptcde) >= 7)
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 7);
      ELSE
         v_dptcde := fill_zero (v_dptcde, 7, 1);
      END IF;

      SELECT COUNT (*)
        INTO v_count
        FROM WEB_BAS_FIN_ISERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_count > 0
      THEN
         UPDATE WEB_BAS_FIN_ISERIENO
            SET c_serie_no = c_serie_no + 1
          WHERE c_dpt_cde = v_dptcde
            AND c_vch_typ = v_fintyp
            AND c_time = v_date;
      ELSE
              INSERT INTO WEB_BAS_FIN_ISERIENO
                     (t_crt_tm, t_upd_tm, c_dpt_cde, c_vch_typ, c_time,
                      c_serie_no
                     )
              VALUES (SYSDATE, SYSDATE, v_dptcde, v_fintyp, v_date,
                      1
                     );

      END IF;

      SELECT c_serie_no
        INTO v_serieno
        FROM WEB_BAS_FIN_ISERIENO
       WHERE c_dpt_cde = v_dptcde AND c_vch_typ = v_fintyp AND c_time = v_date;

      IF v_fintyp = 'MA'
      THEN
         v_dptcde := SUBSTR (v_dptcde, 1, 6);
         ofincde :=
                v_fintyp ||v_date || v_dptcde ||idep_type||  fill_zero (v_serieno, 6, 0);
      ELSE
         ofincde :=
                v_fintyp ||v_date || v_dptcde ||idep_type||  fill_zero (v_serieno, 6, 0);
      END IF;
   END;
END dz_proc;
/
