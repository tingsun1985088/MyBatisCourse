CREATE PACKAGE "QUEST_PPCM_DATA_INSERTER" 
AS
	PROCEDURE add_sql_snap(p_instance_id 					NUMBER,
						   p_snapshot_id 					NUMBER,
						   p_sql_id 						VARCHAR2,
						   p_executions 					FLOAT,
						   p_buffer_gets 					FLOAT,
						   p_elapsed_time 					FLOAT,
						   p_disk_reads 					FLOAT,
						   p_cpu_time 						FLOAT,
						   p_user_io_wait_time 				FLOAT,
						   p_concurrency_wait_time 			FLOAT,
						   p_cluster_wait_time 				FLOAT,
						   p_application_wait_time 			FLOAT,
						   p_executions_rate 				FLOAT,
						   p_buffer_gets_rate 				FLOAT,
						   p_elapsed_time_rate 				FLOAT,
						   p_disk_reads_rate 				FLOAT,
						   p_cpu_time_rate 					FLOAT,
						   p_user_io_wait_time_rate 		FLOAT,
						   p_concurrency_wait_time_rate 	FLOAT,
						   p_cluster_wait_time_rate 		FLOAT,
						   p_application_wait_time_rate 	FLOAT,
						   p_avg_plan_hash_value 			NUMBER);

	PROCEDURE save_snap;
END;









/
