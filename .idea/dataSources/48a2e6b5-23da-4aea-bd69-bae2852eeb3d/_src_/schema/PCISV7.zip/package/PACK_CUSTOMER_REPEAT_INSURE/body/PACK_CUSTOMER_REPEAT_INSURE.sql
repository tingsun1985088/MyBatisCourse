CREATE PACKAGE BODY PACK_CUSTOMER_REPEAT_INSURE is

  procedure P_LIABILITY_INSURANCE_REPEAT(CAppType  IN VARCHAR2,
                                         CProdNo   IN VARCHAR2,
                                         CAppNo    IN VARCHAR2,
                                         CPlyNo    IN VARCHAR2,
                                         NEdrPrjNo IN NUMBER,
                                         CResult   OUT VARCHAR2) is
    vCertNoOld   VARCHAR2(50);
    vCertNoNew   VARCHAR2(50);
    vCPlyNo      VARCHAR2(50);
    vNSeqNo      NUMBER;
    vCusNme      VARCHAR2(50);
    vCusOldNme   VARCHAR2(100);
    vEdrPlyNo    VARCHAR2(50);
    vTInsrnBgnTm DATE;
    vTInsrnEndTm DATE;
    vCount       VARCHAR2(30);
    vCertTyp     VARCHAR2(50);
    vCAppNo      VARCHAR2(50);

    --新增投保，本次投保单清单
    Cursor liability_insurance_new is

      select n_seq_no,
             decode(CProdNo,
                    '041002',
                    c_Tgt_Obj_Txt_Fld_4,
                    '045001',
                    c_Tgt_Obj_Txt_Fld_7,
                    c_Tgt_Obj_Txt_Fld_2) as CCertNo
        from web_app_tgt_obj a
       where (c_cancel_mark = '0' or c_cancel_mark is null)
         and c_app_no = CAppNo
         and c_app_no not in
             ('0100107000404000220180000049',
              '0100107000704000220160000665',
              '0100107000704000220160000666');

    --批改，本次批改申请单新增清单
    Cursor liability_insurance_update is

      select n_seq_no,
             decode(CProdNo,
                    '041002',
                    c_Tgt_Obj_Txt_Fld_4,
                    '045001',
                    c_Tgt_Obj_Txt_Fld_7,
                    c_Tgt_Obj_Txt_Fld_2) as CCertNo
        from web_app_tgt_obj newapp
       where newapp.c_cancel_mark = '0'
         and newapp.c_app_no = CAppNo
         and newapp.c_tgt_obj_txt_fld_30 in ('A','U');

    --校验重复记录
    --投保，本次投保单与原来保单、投保单重复记录
    cursor repeatListApp is

      select c_ply_no as CPlyNo,
             decode(CProdNo,
                    '041002',
                    c_Tgt_Obj_Txt_Fld_4,
                    '045001',
                    c_Tgt_Obj_Txt_Fld_7,
                    c_Tgt_Obj_Txt_Fld_2) as CCertNo,
             c_edr_no as CEdrNo,
             c_Tgt_Obj_Txt_Fld_1 as CCusNme,
             c_app_no
        from web_ply_tgt_obj
       where c_app_no in (select c_app_no
                            from web_ply_base
                           where c_prod_no = CProdNo
                             and t_insrnc_end_tm >= vTInsrnBgnTm
                             and t_insrnc_bgn_tm <= vTInsrnEndTm
                             and c_latest_mrk = '1'
                             and C_PLY_STS = 'I')
         and c_Tgt_Obj_Txt_Fld_2 = vCertNoNew
         and (c_cancel_mark = '0' or c_cancel_mark is null)

      union all

      select '' as CPlyNo,
             decode(CProdNo,
                    '041002',
                    c_Tgt_Obj_Txt_Fld_4,
                    '045001',
                    c_Tgt_Obj_Txt_Fld_7,
                    c_Tgt_Obj_Txt_Fld_2) as CCertNo,
             '' as CEdrNo,
             c_Tgt_Obj_Txt_Fld_1 as CCusNme,
             c_app_no
        from web_app_tgt_obj
       where c_app_no in
             (select ab.c_app_no
                from web_app_base ab
               where ab.c_prod_no = CProdNo
                 and ab.c_app_status <> '1'
                 and ab.t_insrnc_end_tm >= vTInsrnBgnTm
                 and ab.t_insrnc_bgn_tm <= vTInsrnEndTm
                 and not exists
               (select 1 from web_ply_base where c_app_no = ab.c_app_no))
         and c_Tgt_Obj_Txt_Fld_2 = vCertNoNew
         and (c_cancel_mark = '0' or c_cancel_mark is null)
         and c_app_no <> CAppNo;

    --批改，本次批改申请单与原来保单、投保单重复记录
    cursor repeatListEdr is

      select c_ply_no as CPlyNo,
             decode(CProdNo,
                    '041002',
                    c_Tgt_Obj_Txt_Fld_4,
                    '045001',
                    c_Tgt_Obj_Txt_Fld_7,
                    c_Tgt_Obj_Txt_Fld_2) as CCertNo,
             c_edr_no as CEdrNo,
             c_Tgt_Obj_Txt_Fld_1 as CCusNme,
             c_app_no
        from web_ply_tgt_obj
       where c_app_no in (select c_app_no
                            from web_ply_base
                           where c_prod_no = CProdNo
                             and t_insrnc_end_tm >= vTInsrnBgnTm
                             and t_insrnc_bgn_tm <= vTInsrnEndTm
                             and c_latest_mrk = '1'
                             and C_PLY_STS = 'I')
         and c_Tgt_Obj_Txt_Fld_2 = vCertNoNew
         and (c_cancel_mark = '0' or c_cancel_mark is null)
         and c_ply_no <> CPlyNo

      union all

      select '' as CPlyNo,
             decode(CProdNo,
                    '041002',
                    c_Tgt_Obj_Txt_Fld_4,
                    '045001',
                    c_Tgt_Obj_Txt_Fld_7,
                    c_Tgt_Obj_Txt_Fld_2) as CCertNo,
             '' as CEdrNo,
             c_Tgt_Obj_Txt_Fld_1 as CCusNme,
             c_app_no
        from web_app_tgt_obj
       where c_app_no in
             (select ab.c_app_no
                from web_app_base ab
               where ab.c_prod_no = CProdNo
                 and ab.c_app_status <> '1'
                 and ab.t_insrnc_end_tm >= vTInsrnBgnTm
                 and ab.t_insrnc_bgn_tm <= vTInsrnEndTm
                 and not exists
               (select 1 from web_ply_base where c_app_no = ab.c_app_no))
         and c_Tgt_Obj_Txt_Fld_2 = vCertNoNew
         and (c_cancel_mark = '0' or c_cancel_mark is null)
         and c_app_no <> CAppNo;

    --当前投保单重复记录
    cursor nowRepeatList is

      select count(*) as CNum,
             c_app_no,
             decode(CProdNo,
                    '041002',
                    c_Tgt_Obj_Txt_Fld_4,
                    '045001',
                    c_Tgt_Obj_Txt_Fld_7,
                    c_Tgt_Obj_Txt_Fld_2) as CCertNo
        from web_app_tgt_obj
       where c_app_no = CAppNo
         and (c_cancel_mark = '0' or c_cancel_mark is null)
       group by decode(CProdNo,
                       '041002',
                       c_Tgt_Obj_Txt_Fld_4,
                       '045001',
                       c_Tgt_Obj_Txt_Fld_7,
                       c_Tgt_Obj_Txt_Fld_2),
                c_app_no;

  begin
    delete from web_issues_list e
     where e.c_app_no = CAppNo
       and e.c_typ in ('0', '1'); --'0'本次申请单重复,'1'与其它单重复
    --投保
    if CAppType = 'A' then
      select appBase.t_Insrnc_Bgn_Tm
        into vTInsrnBgnTm
        from web_app_base appBase
       where c_app_no = CAppNo;
      select appBase.t_Insrnc_End_Tm
        into vTInsrnEndTm
        from web_app_base appBase
       where c_app_no = CAppNo;

      for now in nowRepeatList LOOP

        if now.cnum > 1 then
          delete from web_issues_list e
           where e.c_app_no = CAppNo
             and e.c_typ = '0'
             and e.c_certf_cde = now.CCertNo
             and e.c_ply_no is null;
          insert into web_issues_list
            (C_PK_ID,
             N_SEQ_NO,
             C_NME,
             C_CERTF_CDE,
             C_CERTF_CLS,
             C_APP_NO,
             C_PROD_NO,
             C_TYP,
             T_CRT_TM,
             C_CRT_CDE,
             T_UPD_TM,
             C_UPD_CDE)
            select sys_guid(),
                   web.n_seq_no,
                   web.c_tgt_obj_txt_fld_1,
                   decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2),
                   decode(CProdNo,
                          '040002',
                          c_Tgt_Obj_Txt_Fld_8,
                          '040023',
                          c_Tgt_Obj_Txt_Fld_8,
                          '043018',
                          c_Tgt_Obj_Txt_Fld_8,
                          '042006',
                          '',
                          '120001'),
                   web.c_app_no,
                   CProdNo,
                   '0',
                   sysdate,
                   'virtual',
                   sysdate,
                   'virtual'
              from web_app_tgt_obj web
             where c_app_no = CAppNo
               and (web.c_cancel_mark = '0' or web.c_cancel_mark is null)
               and decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2) = now.CCertNo
               and rownum = 1;
        end if;
      end LOOP;

      --循环获取新增清单证件号码
      open liability_insurance_new;
      loop
        fetch liability_insurance_new
          into vNSeqNo, vCertNoNew;
        exit when liability_insurance_new%notfound;

        open repeatListApp;
        loop
          fetch repeatListApp
            into vCPlyNo, vCertNoOld, vEdrPlyNo, vCusOldNme, vCAppNo;
          exit when repeatListApp%notfound;

          select app.c_tgt_obj_txt_fld_1
            into vCusNme
            from web_app_tgt_obj app
           where app.c_app_no = CAppNo
             and (app.c_cancel_mark = '0' or app.c_cancel_mark is null)
             and app.n_seq_no = vNSeqNo;

          select decode(CProdNo,
                        '040002',
                        app.c_Tgt_Obj_Txt_Fld_8,
                        '040023',
                        app.c_Tgt_Obj_Txt_Fld_8,
                        '043018',
                        app.c_Tgt_Obj_Txt_Fld_8,
                        '042006',
                        '',
                        '120001')
            into vCertTyp
            from web_app_tgt_obj app
           where app.c_app_no = CAppNo
             and (app.c_cancel_mark = '0' or app.c_cancel_mark is null)
             and app.n_seq_no = vNSeqNo;

          insert into web_issues_list
            (C_PK_ID,
             N_SEQ_NO,
             C_NME,
             C_CERTF_CDE,
             C_CERTF_CLS,
             C_PLY_NO,
             C_APP_NO,
             C_EDR_NO,
             C_PROD_NO,
             C_NME_ORIG,
             C_TYP,
             T_CRT_TM,
             C_CRT_CDE,
             T_UPD_TM,
             C_UPD_CDE,
             C_REPEAT_APP_NO)
          values
            (sys_guid(),
             vNSeqNo,
             vCusNme,
             vCertNoOld,
             vCertTyp,
             vCPlyNo,
             CAppNo,
             vEdrPlyNo,
             CProdNo,
             vCusOldNme,
             '1',
             sysdate,
             'virtual',
             sysdate,
             'virtual',
             vCAppNo);

        end loop;
        close repeatListApp;
      end loop;

      close liability_insurance_new;
      --批改
    else
      select appBase.t_Edr_Bgn_Tm
        into vTInsrnBgnTm
        from web_app_base appBase
       where c_app_no = CAppNo;
      select appBase.t_Edr_End_Tm
        into vTInsrnEndTm
        from web_app_base appBase
       where c_app_no = CAppNo;

      for now in nowRepeatList LOOP

        if now.cnum > 1 then
          delete from web_issues_list e
           where e.c_app_no = CAppNo
             and e.c_typ = '0'
             and e.c_certf_cde = now.CCertNo
             and e.c_ply_no is null;

          insert into web_issues_list
            (C_PK_ID,
             N_SEQ_NO,
             C_NME,
             C_CERTF_CDE,
             C_CERTF_CLS,
             C_APP_NO,
             C_PROD_NO,
             C_TYP,
             T_CRT_TM,
             C_CRT_CDE,
             T_UPD_TM,
             C_UPD_CDE)
            select sys_guid(),
                   web.n_seq_no,
                   web.c_tgt_obj_txt_fld_1,
                   decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2),
                   decode(CProdNo,
                          '040002',
                          c_Tgt_Obj_Txt_Fld_8,
                          '040023',
                          c_Tgt_Obj_Txt_Fld_8,
                          '043018',
                          c_Tgt_Obj_Txt_Fld_8,
                          '042006',
                          '',
                          '120001'),
                   web.c_app_no,
                   CProdNo,
                   '0',
                   sysdate,
                   'virtual',
                   sysdate,
                   'virtual'
              from web_app_tgt_obj web
             where c_app_no = CAppNo
               and (web.c_cancel_mark = '0' or web.c_cancel_mark is null)
               and decode(CProdNo,
                          '041002',
                          c_Tgt_Obj_Txt_Fld_4,
                          '045001',
                          c_Tgt_Obj_Txt_Fld_7,
                          c_Tgt_Obj_Txt_Fld_2) = now.CCertNo
               and rownum = 1;

        end if;

      end LOOP;

      vEdrPlyNo := CPlyNo;
      open liability_insurance_update;
      loop
        fetch liability_insurance_update
          into vNSeqNo, vCertNoNew;
        exit when liability_insurance_update%notfound;

        open repeatListEdr;
        loop
          fetch repeatListEdr
            into vCPlyNo, vCertNoOld, vEdrPlyNo, vCusOldNme, vCAppNo;
          exit when repeatListEdr%notfound;

          select app.c_tgt_obj_txt_fld_1
            into vCusNme
            from web_app_tgt_obj app
           where app.c_app_no = CAppNo
             and (app.c_cancel_mark = '0' or app.c_cancel_mark is null)
             and app.n_seq_no = vNSeqNo;

          select decode(CProdNo,
                        '040002',
                        c_Tgt_Obj_Txt_Fld_8,
                        '040023',
                        c_Tgt_Obj_Txt_Fld_8,
                        '043018',
                        c_Tgt_Obj_Txt_Fld_8,
                        '042006',
                        '',
                        '120001')
            into vCertTyp
            from web_app_tgt_obj app
           where app.c_app_no = CAppNo
             and (app.c_cancel_mark = '0' or app.c_cancel_mark is null)
             and app.n_seq_no = vNSeqNo;

          insert into web_issues_list
            (C_PK_ID,
             N_SEQ_NO,
             C_NME,
             C_CERTF_CDE,
             C_CERTF_CLS,
             C_PLY_NO,
             C_APP_NO,
             C_EDR_NO,
             C_PROD_NO,
             C_NME_ORIG,
             C_TYP,
             T_CRT_TM,
             C_CRT_CDE,
             T_UPD_TM,
             C_UPD_CDE,
             C_REPEAT_APP_NO)
          values
            (sys_guid(),
             vNSeqNo,
             vCusNme,
             vCertNoOld,
             vCertTyp,
             vCPlyNo,
             CAppNo,
             vEdrPlyNo,
             CProdNo,
             vCusOldNme,
             '1',
             sysdate,
             'virtual',
             sysdate,
             'virtual',
             vCAppNo);

        end loop;
        close repeatListEdr;
      end loop;
      close liability_insurance_update;

    end if;

    select count(*)
      into vCount
      from web_issues_list e
     where e.c_app_no = CAppNo
       and e.c_typ in ('0', '1');
    if vCount = 0 then
      CResult := '0';
    else
      CResult := '1';
    end if;
    commit;

  end P_LIABILITY_INSURANCE_REPEAT;
  procedure P_HEALTH_INSURANCE_LIMIT(CAppType    IN VARCHAR2,
                                     CPlyNo      IN VARCHAR2,
                                     NAmt        IN NUMBER,
                                     NAmtChgRate IN NUMBER,
                                     CCertType   VARCHAR2,
                                     CCertNo     VARCHAR2,
                                     CResult     OUT VARCHAR2) is
    vcurrency  VARCHAR2(10);
    vAmtLimit  NUMBER;
    vOldAmtSum NUMBER;
    vtemp      NUMBER;
    /* vEdrAmtVar NUMBER;
    vCertfCde VARCHAR2(10);
    vOldCertCde VARCHAR2(10);*/

  begin
    vAmtLimit := 100000000000000.00;
    vcurrency := '人民币';
    --获取被保险人投保意健险的保额总和
    if CAppType = 'A' then
      select nvl(sum(base.n_amt *
                     decode(nvl(n_amt_rmb_exch, 1), 0, 1, n_amt_rmb_exch)),
                 0)
        into vOldAmtSum
        from web_app_insured insured, web_ply_base base
       where base.c_app_no = insured.c_app_no
         and base.t_insrnc_end_tm > sysdate
         and base.c_latest_mrk = '1'
         and base.C_PLY_STS = 'I'
         and substr(base.c_prod_no, 1, 2) = '06'
         and insured.c_certf_cls = CCertType
         and insured.c_certf_cde = CCertNo;
      vtemp := vOldAmtSum + NAmt * NAmtChgRate;
      if vtemp > vAmtLimit then
        CResult := '被保人在我司投保意健险的保额总计超过了限额' || vAmtLimit || vcurrency ||
                   ',当前有效保额为' || vOldAmtSum || vcurrency || chr(10);
      end if;
    else
      --批改申请单
      select nvl(sum(base.n_amt *
                     decode(nvl(n_amt_rmb_exch, 1), 0, 1, n_amt_rmb_exch)),
                 0)
        into vOldAmtSum
        from web_app_insured insured, web_ply_base base
       where base.c_app_no = insured.c_app_no
         and base.t_insrnc_end_tm > sysdate
         and base.c_latest_mrk = '1'
         and base.C_PLY_STS = 'I'
         and substr(base.c_prod_no, 1, 2) = '06'
         and insured.c_certf_cls = CCertType
         and insured.c_certf_cde = CCertNo
         and base.c_ply_no <> CPlyNo
         and base.c_ply_no not in ('1100101000106101320170000003');
      vtemp := vOldAmtSum + NAmt * NAmtChgRate;
      if vtemp > vAmtLimit then
        CResult := '被保人在我司投保意健险的保额总计超过了限额' || vAmtLimit || vcurrency ||
                   ',当前有效保额为' || vOldAmtSum || vcurrency || chr(10);
      end if;
    end if;

  end P_HEALTH_INSURANCE_LIMIT;

end PACK_CUSTOMER_REPEAT_INSURE;
/
