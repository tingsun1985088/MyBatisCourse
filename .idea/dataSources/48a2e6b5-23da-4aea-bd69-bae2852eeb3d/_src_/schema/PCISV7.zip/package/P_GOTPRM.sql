CREATE package p_gotprm is

  procedure P_Fin_Gotprm(v_today IN VARCHAR2,
               sDptCde IN VARCHAR2,
               v_cal_type IN CHAR, --手工 'm'-manual,自动 'a'-automatica'自动提取并传财务，'b'只提取准备金,'c'只传财务,'d' 冲回上期；
               v_return  OUT NUMBER
               );

end p_gotprm;
/
