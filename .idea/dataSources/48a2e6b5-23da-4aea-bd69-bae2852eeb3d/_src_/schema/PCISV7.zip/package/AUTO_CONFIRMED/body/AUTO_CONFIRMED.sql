CREATE PACKAGE BODY "AUTO_CONFIRMED" IS
  --?????????????????(???????)?????

  --1.???????????? Definite insurance premium income
  PROCEDURE premincome IS
    --?????????????????????????????
    --????
    v_dptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_dpt_cde    WEB_ORG_DPT.c_dpt_cde%TYPE;

    v_prod_no  WEB_FIN_PRM_DUE.c_prod_no%TYPE;
    v_get_prm  WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_got_prm  WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_dr_amt   WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_cr_amt   WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_na_prm   WEB_FIN_PRM_DUE.N_BS_AMT%TYPE; --????
    v_edr_type WEB_FIN_PRM_DUE.c_edr_typ%TYPE; --????
    v_edr_no   WEB_FIN_PRM_DUE.c_edr_no%TYPE;
    v_ply_no   WEB_FIN_PRM_DUE.c_ply_no%TYPE;
    v_pre_sum  WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_rcpt_no  WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
    v_DUE_TM   WEB_FIN_PRM_DUE.T_DUE_TM%TYPE;
    v_cnt      INT;
    v_tmpcnt   INT;

    v_sbjt_memo WEB_FIN_MADCR.c_sbjt_memo%TYPE;
    v_vou_memo  WEB_FIN_MADCR.c_vou_memo%TYPE;
    vTmpVouNo   WEB_FIN_MADCR.c_seq_no%TYPE;
    vTmpVouNo1  WEB_FIN_MADCR.c_seq_no%TYPE;

    v_drsbjt_no   WEB_FIN_DCR.c_sbjt_no%TYPE;
    v_crsbjt_no   WEB_FIN_DCR.c_sbjt_no%TYPE;
    vCavFlag      WEB_FIN_DCR.C_CAV_FLAG%TYPE;
    v_feetyp_cde  WEB_FIN_PAY_DUE.c_feetyp_cde%TYPE;
    v_tran_flag   WEB_FIN_PAY_DUE.c_tran_flag%TYPE;
    vToday        VARCHAR(10);
    vBillToday    VARCHAR(10);
    v_ply_app_no  WEB_FIN_PRM_DUE.C_APP_NO%TYPE;
    v_cha_mrk     WEB_FIN_PRM_DUE.c_cha_mrk%TYPE;
    v_con_dpt_cde WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;

    v_err_content    WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_servicetype_no WEB_BAS_FIN_SERVICETYPE.c_no%TYPE;

    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;
    v_other_amt      WEB_FIN_PRM_DUE.n_other_amt%TYPE;
    /*
    v_seebgn_tm   t_fin_seemoney_printply.t_bgn_tm%type;
    v_flag      t_fin_seemoney_printply.c_flag%type;
    v_conn_bank   t_fin_seemoney_printply.c_conn_bank%type;
    v_up_dpt_cde  WEB_ORG_DPT.c_dpt_cde%type;
    v_cust_type t_fin_seemoney_printply.c_cust_type%type;

    v_bank_cde      t_fin_seemoney_printply.c_bank_cde%type;
    v_abby_flag   t_fin_seemoney_printply.c_abby_flag%type;
    v_computer_code t_fin_seemoney_printply.C_COMPUTER_CODE%type;
    v_Interval  t_fin_seemoney_printply.n_Interval%type;
    v_times  t_fin_seemoney_printply.n_times%type;
    v_control_days      t_fin_seemoney_printply.n_control_days%type;
    */
    oErrorMsg varchar2(1000);

    --??????
    CURSOR cur_ifPrmInfo IS
      SELECT c_dpt_cde,
             c_prod_no,
             N_DUE_AMT,
             c_edr_no,
             c_edr_typ,
             c_ply_no,
             n_paid_amt,
             c_rcpt_no,
             T_DUE_TM,
             c_tran_flag,
             c_cha_mrk,
             n_paid_amt,
             c_con_dpt_cde,
             n_other_amt
        FROM WEB_FIN_PRM_DUE
       WHERE T_DUE_TM < TRUNC(SYSDATE) --??????
         AND T_DUE_TM >= sysdate - 30
            --AND c_prod_no NOT IN  ('0001','0002','0003')  --???
         AND c_prod_no not like '00%'
         and not exists (select 1
                from WEB_BAS_FIN_PROD
               where c_kind_no = '00'
                 and c_prod_no = WEB_FIN_PRM_DUE.c_prod_no)
         AND c_accnt_flag IN ('00', '10') --????
      --AND not exists (SELECT c_ply_no FROM t_ply_tgt
      --WHERE c_tgt_fld34='1' AND c_ply_no=WEB_FIN_PRM_DUE.c_ply_no) --0507?0509???????????????????????
      ;
    /*
      --????????????????????????
          CURSOR cur_seemoney IS
      select c_dpt_cde,substr(c_dpt_cde,1,length(c_dpt_cde)-2) from WEB_ORG_DPT
      WHERE c_dptacc_cde<>'?'
        AND c_dptacc_cde IS NOT NULL
        AND c_dpt_cde=c_dptacc_cde
        AND c_dpt_cde <>'00000019'
        AND not exists (select c_dptacc_cde
        from t_fin_seemoney_printply
        where c_dptacc_cde=WEB_ORG_DPT.c_dpt_cde);
    */

  BEGIN
    /*
    --????????????????????????
       OPEN cur_seemoney;
          LOOP
              FETCH cur_seemoney
              INTO  v_dpt_cde,v_up_dpt_cde;
              EXIT WHEN cur_seemoney%NOTFOUND;

      select t_bgn_tm ,c_flag,c_conn_bank,c_prod_no,c_cust_type,c_bank_cde,c_abby_flag,c_computer_code,n_Interval,n_times,n_control_days
      INTO  v_seebgn_tm,v_flag,v_conn_bank,v_prod_no,v_cust_type,v_bank_cde,v_abby_flag,v_computer_code,v_Interval,v_times,v_control_days
      from t_fin_seemoney_printply
      where  c_dptacc_cde=v_up_dpt_cde;



      INSERT INTO t_fin_seemoney_printply(c_dptacc_cde,t_bgn_tm,c_flag,c_conn_bank,c_prod_no,
      c_cust_type,c_abby_flag,C_COMPUTER_CODE,n_Interval,n_times,
      n_control_days)
      VALUES(v_dpt_cde,v_seebgn_tm,v_flag,v_conn_bank,v_prod_no,
      v_cust_type,v_abby_flag,v_computer_code,v_Interval,v_times,
      v_control_days);


          END LOOP;
          CLOSE cur_seemoney;
    commit;
    */
    --0507?0509???????????????????????
    /*
      UPDATE WEB_FIN_PRM_DUE
      SET c_bala_mrk='3',c_accnt_flag='01'
      WHERE exists (SELECT c_ply_no FROM t_ply_tgt
        WHERE c_tgt_fld34='1' AND c_ply_no=WEB_FIN_PRM_DUE.c_ply_no)
      AND c_prod_no in ('0507','0509')
      and n_paid_amt =0
      AND t_crt_tm >=sysdate -5;

      --0633???????????????????????
      UPDATE WEB_FIN_PRM_DUE a
      SET c_bala_mrk='3',c_accnt_flag='01'
      WHERE  c_prod_no in ('0633')
      and n_paid_amt =0
      and exists  (select c_dpt_cde  from WEB_ORG_DPT  where c_dpt_cde =a.c_dpt_cde
           and  (c_ctct_cde  = '014011'  or  c_dpt_cde in ('11000008','08001000','20000007') ) )
      AND t_crt_tm >=sysdate -5;
      commit;
    */

    --DESC  t_ply_tgt?????????????????
    --?????????????????
    UPDATE WEB_FIN_SAVEAMT_DUE
       SET c_bala_mrk = '1'
     WHERE exists (SELECT c_ply_no
              from WEB_EDR_BASE
             WHERE c_edr_typ = '2'
               and c_ply_no = WEB_FIN_SAVEAMT_DUE.c_ply_no)
       AND t_crt_tm >= sysdate - 2;
    commit;

    UPDATE WEB_FIN_SAVEAMT_DUE a
       SET N_BS_AMT = (select -N_BS_AMT
                         from WEB_FIN_SAVEAMT_DUE
                        where c_ply_no = a.c_ply_no
                          and N_BS_AMT < 0
                          and rownum = 1)
     WHERE 1 = 1
       and c_edr_no is not null
       and c_edr_no <> ' '
       and exists (SELECT c_ply_no
              from WEB_EDR_BASE
             WHERE c_edr_typ = '2'
               and c_ply_no = a.c_ply_no)
       and n_paid_amt = 0
       AND t_crt_tm >= sysdate - 2;
    commit;

    --??410990??????-????????????????AAAA
    UPDATE web_fin_dcr_intf
       set c_prod_no = 'AAAA'
     WHERE c_sbjt_no = '410990'
       AND t_crt_tm >= TRUNC(sysdate - 2);
    commit;

    --??
    OPEN cur_ifPrmInfo;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifPrmInfo
        INTO v_dpt_cde, v_prod_no, v_get_prm, v_edr_no, v_edr_type, v_ply_no, v_pre_sum, v_rcpt_no, v_DUE_TM, v_tran_flag, v_cha_mrk, v_got_prm, v_con_dpt_cde, v_other_amt;
      EXIT WHEN cur_ifPrmInfo%NOTFOUND;

      --????????????????????????????????WEB_ORG_DPT??
      SELECT c_dptacc_cde, c_department_cde, c_company_cde
        INTO v_dptacc_cde, v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = RTRIM(LTRIM(v_dpt_cde));

      SELECT c_kind_no
        INTO v_kind_no
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = v_prod_no;
      v_cnt := 0;

      --?????
      Dz_Proc.get_fin_no(vTmpVouNo, v_dpt_cde, '7', dz_proc.g_pttype);
      /*
          ??
          ????(??????)
          ??????????????
          ??????????????

          ??
          ???????????
          ???????????(XX???) ??
          ???????--????

          122203  ??????-??????
            4102  ?????
      */

      v_dr_amt  := v_get_prm;
      v_cr_amt  := v_get_prm;
      v_rcpt_no := trim(v_rcpt_no);

      /*
          IF v_tran_flag='1' THEN
            v_drsbjt_no:='112201';
            v_crsbjt_no:='410101';
            v_vou_memo:='??????';
            v_servicetype_no:='1000';
          ELSE
            v_drsbjt_no:='122203';
            v_crsbjt_no:='410205';
            v_vou_memo:='??????';
            v_servicetype_no:='1123';
          END IF;
      */
      v_drsbjt_no      := '112201';
      v_crsbjt_no      := '410101';
      v_vou_memo       := '??????';
      v_servicetype_no := '1000';
      v_DUE_TM         := TRUNC(v_DUE_TM);

      INSERT INTO WEB_FIN_MADCR
        (C_SEQ_NO,
         C_ITEM_NO,
         C_CAV_FLAG,
         C_SBJT_NO,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         C_DPTACC_NO,
         C_DPT_CDE,
         C_RCPT_NO,
         C_SLS_CDE,
         C_PROD_NO,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SALEGRP_CDE,
         c_pay_prsn_cde,
         C_RI_COM,
         C_CONT_CODE,
         C_VOU_NO,
         C_SEND_FLAG,
         C_bsns_typ,
         C_pay_prsn_name,
         c_sbjt_memo,
         c_cha_mrk,
         c_vou_memo,
         c_ply_no,
         c_servicetype_no,
         c_kind_no,
         c_department_cde,
         c_company_cde,
         c_period_name)
        SELECT vTmpVouNo,
               '1',
               '?',
               v_drsbjt_no,
               v_dr_amt,
               C_BS_CUR,
               v_due_tm,
               v_dptacc_cde,
               c_dpt_cde,
               c_rcpt_no,
               C_SLS_CDE,
               C_PROD_NO,
               C_CHA_CLS,
               C_CHA_CDE,
               C_SLSGRP_CDE,
               C_PAYER_CDE,
               NULL,
               NULL,
               NULL,
               '0',
               C_bsns_typ,
               C_PAYER_NME,
               v_sbjt_memo,
               c_cha_mrk,
               v_vou_memo,
               c_ply_no,
               v_servicetype_no,
               v_kind_no,
               v_department_cde,
               v_company_cde,
               TO_CHAR(v_due_tm, 'YYYY-MM')
          FROM WEB_FIN_PRM_DUE
         WHERE c_rcpt_no = v_rcpt_no;

      INSERT INTO WEB_FIN_MADCR
        (C_SEQ_NO,
         C_ITEM_NO,
         C_CAV_FLAG,
         C_SBJT_NO,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         C_DPTACC_NO,
         C_DPT_CDE,
         C_RCPT_NO,
         C_SLS_CDE,
         C_PROD_NO,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SALEGRP_CDE,
         c_pay_prsn_cde,
         C_RI_COM,
         C_CONT_CODE,
         C_VOU_NO,
         C_SEND_FLAG,
         C_bsns_typ,
         C_pay_prsn_name,
         c_cha_mrk,
         c_vou_memo,
         c_ply_no,
         c_servicetype_no,
         c_kind_no,
         c_department_cde,
         c_company_cde,
         c_period_name)
        SELECT vTmpVouNo,
               '2',
               '?',
               v_crsbjt_no,
               v_cr_amt,
               C_BS_CUR,
               v_due_tm,
               v_dptacc_cde,
               c_dpt_cde,
               c_rcpt_no,
               C_SLS_CDE,
               C_PROD_NO,
               C_CHA_CLS,
               C_CHA_CDE,
               C_SLSGRP_CDE,
               C_PAYER_CDE,
               NULL,
               NULL,
               NULL,
               '0',
               c_bsns_typ,
               C_PAYER_NME,
               c_cha_mrk,
               v_vou_memo,
               c_ply_no,
               v_servicetype_no,
               v_kind_no,
               v_department_cde,
               v_company_cde,
               TO_CHAR(v_DUE_TM, 'YYYY-MM')
          FROM WEB_FIN_PRM_DUE
         WHERE c_rcpt_no = v_rcpt_no;

      --????
      IF v_other_amt <> 0 AND
         v_DUE_TM >= TO_DATE('2007-07-01', 'YYYY-MM-DD') THEN
        --?????
        Dz_Proc.get_fin_no(vTmpVouNo, v_dpt_cde, '7', dz_proc.g_pttype);
        /*
            ??
            ????(?????????)
            ?????????????????????119113
            ?????????????????????? 214614
        */

        v_dr_amt  := v_other_amt;
        v_cr_amt  := v_other_amt;
        v_rcpt_no := trim(v_rcpt_no);

        v_drsbjt_no      := '119113';
        v_crsbjt_no      := '214614';
        v_vou_memo       := '?????????';
        v_servicetype_no := '5000';
        v_DUE_TM         := TRUNC(v_DUE_TM);

        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           C_ITEM_NO,
           C_CAV_FLAG,
           C_SBJT_NO,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           C_DPTACC_NO,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde,
           c_period_name)
          SELECT vTmpVouNo,
                 '1',
                 '?',
                 v_drsbjt_no,
                 v_dr_amt,
                 c_bs_cur,
                 v_DUE_TM,
                 v_dptacc_cde,
                 c_dpt_cde,
                 c_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 C_PAYER_CDE,
                 NULL,
                 NULL,
                 NULL,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 v_sbjt_memo,
                 c_cha_mrk,
                 v_vou_memo,
                 c_ply_no,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde,
                 TO_CHAR(v_DUE_TM, 'YYYY-MM')
            FROM WEB_FIN_PRM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           C_ITEM_NO,
           C_CAV_FLAG,
           C_SBJT_NO,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           C_DPTACC_NO,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde,
           c_period_name)
          SELECT vTmpVouNo,
                 '2',
                 '?',
                 v_crsbjt_no,
                 v_cr_amt,
                 c_bs_cur,
                 v_DUE_TM,
                 v_dptacc_cde,
                 c_dpt_cde,
                 c_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 C_PAYER_CDE,
                 NULL,
                 NULL,
                 NULL,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 v_sbjt_memo,
                 c_cha_mrk,
                 v_vou_memo,
                 c_ply_no,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde,
                 TO_CHAR(v_DUE_TM, 'YYYY-MM')
            FROM WEB_FIN_PRM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

      END IF;

      UPDATE WEB_FIN_PRM_DUE
         SET c_accnt_flag = DECODE(c_accnt_flag,
                                   '10',
                                   '11',
                                   '00',
                                   '01',
                                   '00')
       WHERE c_rcpt_no = v_rcpt_no;

      COMMIT;

    END LOOP;
    CLOSE cur_ifPrmInfo;

    --????????????

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_rcpt_no || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[premincome],??????[' || v_rcpt_no ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  --2.?????????? Advance receipt insurance premium carry-over actual receipt insurance premium
  PROCEDURE actualprem IS
    v_dptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_dpt_cde    WEB_ORG_DPT.c_dpt_cde%TYPE;

    v_prod_no  WEB_FIN_PRM_DUE.c_prod_no%TYPE;
    v_pre_sum  WEB_FIN_PRM_DUE.N_BS_AMT%TYPE;
    v_edr_type WEB_FIN_PRM_DUE.c_edr_typ%TYPE;
    v_edr_no   WEB_FIN_PRM_DUE.c_edr_no%TYPE;
    v_ply_no   WEB_FIN_PRM_DUE.c_ply_no%TYPE;
    v_rcpt_no  WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
    v_DUE_TM   WEB_FIN_PRM_DUE.T_DUE_TM%TYPE;

    v_cav_flag  WEB_FIN_DCR.c_cav_flag%TYPE;
    v_cnt       INT;
    v_tmpcnt    INT;
    v_sbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_memo WEB_FIN_MADCR.c_sbjt_memo%TYPE;
    v_vou_memo  WEB_FIN_MADCR.c_vou_memo%TYPE;
    vTmpVouNo   WEB_FIN_MADCR.c_seq_no%TYPE;
    vTmpVouNo1  WEB_FIN_MADCR.c_seq_no%TYPE;

    vSbjtNo       WEB_FIN_DCR.c_sbjt_no%TYPE;
    vCavFlag      WEB_FIN_DCR.C_CAV_FLAG%TYPE;
    v_feetyp_cde  WEB_FIN_PAY_DUE.c_feetyp_cde%TYPE;
    v_tran_flag   WEB_FIN_PAY_DUE.c_tran_flag%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_seq_no      WEB_FIN_DCR.c_seq_no%TYPE;
    v_item_no     WEB_FIN_DCR.c_item_no%TYPE;

    vToday           VARCHAR(10);
    vBillToday       VARCHAR(10);
    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;

    --??????
    CURSOR cur_ifPrmInfo IS
      SELECT c_dpt_cde,
             c_prod_no,
             c_ply_no,
             n_amt,
             c_rcpt_no,
             t_crt_tm,
             c_cav_flag,
             c_seq_no,
             c_item_no,
             c_dptacc_no
        FROM WEB_FIN_DCR
       WHERE c_sbjt_no = '212101'

         AND c_prereal_flag <> '1'
         AND EXISTS (SELECT c_rcpt_no
                FROM WEB_FIN_PRM_DUE
               WHERE T_DUE_TM <= TRUNC(SYSDATE)
                 AND c_rcpt_no = WEB_FIN_DCR.c_rcpt_no);

  BEGIN

    --?????????
    --??
    OPEN cur_ifPrmInfo;
    LOOP
      FETCH cur_ifPrmInfo
        INTO v_dpt_cde, v_prod_no, v_ply_no, v_pre_sum, v_rcpt_no, v_DUE_TM, v_cav_flag, v_seq_no, v_item_no, v_dptacc_cde;
      EXIT WHEN cur_ifPrmInfo%NOTFOUND;

      SELECT c_department_cde, c_company_cde
        INTO v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = v_dpt_cde;

      IF v_cav_flag = '?' THEN
        v_pre_sum := v_pre_sum;
      ELSE
        v_pre_sum := -v_pre_sum;
      END IF;

      v_vou_memo       := '??????????';
      v_servicetype_no := '1001';

      --?????
      Dz_Proc.get_fin_no(vTmpVouNo, v_dpt_cde, '7', dz_proc.g_pttype);
      SELECT c_kind_no
        INTO v_kind_no
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = v_prod_no;

      SELECT T_DUE_TM
        INTO v_DUE_TM
        FROM WEB_FIN_PRM_DUE
       WHERE c_rcpt_no = v_rcpt_no;

      IF TO_CHAR(v_DUE_TM, 'YYYY-MM-DD') <>
         TO_CHAR(SYSDATE - 1, 'YYYY-MM-DD') THEN
        v_DUE_TM := SYSDATE;
      END IF;

      IF TO_CHAR(v_DUE_TM, 'YYYY-MM-DD') <
         TO_CHAR(SYSDATE - 1, 'YYYY-MM-DD') THEN
        v_DUE_TM := SYSDATE;
      END IF;

      --v_DUE_TM:=trunc(SYSDATE);

      INSERT INTO WEB_FIN_MADCR
        (C_SEQ_NO,
         c_item_no,
         C_CAV_FLAG,
         c_sbjt_no,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         c_dptacc_no,
         C_DPT_CDE,
         C_RCPT_NO,
         C_SLS_CDE,
         C_PROD_NO,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SALEGRP_CDE,
         c_pay_prsn_cde,
         C_RI_COM,
         C_CONT_CODE,
         C_VOU_NO,
         C_SEND_FLAG,
         C_bsns_typ,
         C_pay_prsn_name,
         c_sbjt_memo,
         c_ply_no,
         c_cha_mrk,
         c_vou_memo,
         c_con_dpt_cde,
         c_servicetype_no,
         c_kind_no,
         c_department_cde,
         c_company_cde,
         c_period_name)
        SELECT vTmpVouNo,
               '1',
               '?',
               '212101',
               v_pre_sum,
               c_bs_cur,
               v_DUE_TM,
               v_dptacc_cde,
               c_dpt_cde,
               c_rcpt_no,
               C_SLS_CDE,
               C_PROD_NO,
               C_CHA_CLS,
               C_CHA_CDE,
               C_SLSGRP_CDE,
               C_PAYER_CDE,
               NULL,
               NULL,
               NULL,
               '0',
               C_bsns_typ,
               C_PAYER_NME,
               v_sbjt_memo,
               c_ply_no,
               c_cha_mrk,
               v_vou_memo,
               c_con_dpt_cde,
               v_servicetype_no,
               v_kind_no,
               v_department_cde,
               v_company_cde,
               TO_CHAR(v_DUE_TM, 'YYYY-MM')
          FROM WEB_FIN_PRM_DUE
         WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no))
           and not exists
         (select 1
                  from WEB_BAS_FIN_PROD
                 where c_kind_no = '00'
                   and c_prod_no = WEB_FIN_PRM_DUE.c_prod_no);
      --AND c_prod_no NOT IN  ('0001','0002','0003');

      INSERT INTO WEB_FIN_MADCR
        (C_SEQ_NO,
         c_item_no,
         C_CAV_FLAG,
         c_sbjt_no,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         c_dptacc_no,
         C_DPT_CDE,
         C_RCPT_NO,
         C_SLS_CDE,
         C_PROD_NO,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SALEGRP_CDE,
         c_pay_prsn_cde,
         C_RI_COM,
         C_CONT_CODE,
         C_VOU_NO,
         C_SEND_FLAG,
         C_bsns_typ,
         C_pay_prsn_name,
         c_ply_no,
         c_cha_mrk,
         c_vou_memo,
         c_con_dpt_cde,
         c_servicetype_no,
         c_kind_no,
         c_department_cde,
         c_company_cde,
         c_period_name,
         c_sbjt_memo)
        SELECT vTmpVouNo,
               '2',
               '?',
               '112201',
               v_pre_sum,
               C_BS_CUR,
               v_DUE_TM,
               v_dptacc_cde,
               c_dpt_cde,
               c_rcpt_no,
               C_SLS_CDE,
               C_PROD_NO,
               C_CHA_CLS,
               C_CHA_CDE,
               C_SLSGRP_CDE,
               C_PAYER_CDE,
               NULL,
               NULL,
               NULL,
               '0',
               C_bsns_typ,
               C_PAYER_NME,
               c_ply_no,
               c_cha_mrk,
               v_vou_memo,
               c_con_dpt_cde,
               v_servicetype_no,
               v_kind_no,
               v_department_cde,
               v_company_cde,
               TO_CHAR(v_DUE_TM, 'YYYY-MM'),
               '0'
          FROM WEB_FIN_PRM_DUE
         WHERE c_rcpt_no = RTRIM(LTRIM(v_rcpt_no))
              --AND c_prod_no NOT IN  ('0001','0002','0003');
           and not exists
         (select 1
                  from WEB_BAS_FIN_PROD
                 where c_kind_no = '00'
                   and c_prod_no = WEB_FIN_PRM_DUE.c_prod_no);

      /*????*/
      UPDATE WEB_FIN_DCR
         SET c_prereal_flag = '1'
       WHERE c_seq_no = v_seq_no
         AND c_item_no = v_item_no;
      COMMIT;

    END LOOP;
    CLOSE cur_ifPrmInfo;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        ROLLBACK;
        dbms_output.put_line('exception' || '*' || v_rcpt_no || SQLERRM);
        v_err_content := 'proc:[actualprem],??????[' || v_rcpt_no ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  --3.?????
  PROCEDURE handlingcharge IS
    /*
    ??????? 443101
      ??????? 211101
    */

    --????
    v_dptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_dpt_cde    WEB_ORG_DPT.c_dpt_cde%TYPE;

    v_prod_no WEB_FIN_PAY_DUE.c_prod_no%TYPE;
    v_get_prm WEB_FIN_PAY_DUE.N_BS_AMT%TYPE;
    v_dr_amt  WEB_FIN_PAY_DUE.N_BS_AMT%TYPE;
    v_cr_amt  WEB_FIN_PAY_DUE.N_BS_AMT%TYPE;
    v_na_prm  WEB_FIN_PAY_DUE.N_BS_AMT%TYPE; --????
    v_edr_no  WEB_FIN_PAY_DUE.c_edr_no%TYPE;
    v_clm_no  WEB_FIN_PAY_DUE.c_clm_no%TYPE;
    v_DUE_TM  WEB_FIN_PAY_DUE.T_DUE_TM%TYPE; --????
    v_ply_no  WEB_FIN_PAY_DUE.c_ply_no%TYPE;

    v_vou_memo       WEB_FIN_MADCR.c_vou_memo%TYPE;
    v_tran_flag      WEB_FIN_PAY_DUE.c_tran_flag%TYPE;
    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;

    v_cmmcnt     INT;
    v_cnt        INT;
    v_tmpcnt     INT;
    vTmpVouNo    WEB_FIN_DCR.c_seq_no%TYPE;
    v_sbjt_memo  WEB_FIN_DCR.c_sbjt_memo%TYPE;
    v_feetyp_cde WEB_FIN_PAY_DUE.c_feetyp_cde%TYPE;

    v_drsbjt_no  WEB_FIN_DCR.c_sbjt_no%TYPE; --shaosheng
    v_drcav_flag WEB_FIN_DCR.C_CAV_FLAG%TYPE; --shaosheng
    v_crcav_flag WEB_FIN_DCR.c_cav_flag%TYPE;

    v_ri_com        VARCHAR2(4); /*???*/
    v_cont_code     VARCHAR2(2); /*????*/
    V_BILLCODE      VARCHAR2(25); /*???*/
    v_INTERNAL_MARK CHAR(1); /*??/??*/
    v_arp_flag      CHAR(1);
    v_con_dpt_cde   WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;

    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_crsbjt_no   WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_rcpt_no     WEB_FIN_PRM_DUE.c_rcpt_no%TYPE;
    v_kind_no     WEB_BAS_FIN_PROD.c_prod_no%TYPE;

    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;
    --??????
    CURSOR cur_ifnotcmmInfo IS
      SELECT c_rcpt_no,
             c_dpt_cde,
             c_prod_no,
             N_BS_AMT,
             c_edr_no,
             T_DUE_TM,
             c_ply_no,
             c_feetyp_cde,
             c_tran_flag,
             NVL(LENGTH(c_clm_no), 0),
             c_arp_flag,
             c_con_dpt_cde,
             c_clm_no
        FROM WEB_FIN_PAY_DUE
       WHERE c_accnt_flag IN ('00', '10')

         AND c_feetyp_cde = 'S' --AND N_BS_AMT>0
         AND T_DUE_TM >= sysdate - 30
      --AND c_prod_no NOT IN  ('0001','0002','0003')
      ; --???

    --????????????????????????????????????????
    --?????????
  BEGIN

    /*
    ??????????????????????????????
    */
    --??????
    OPEN cur_ifnotcmmInfo;
    LOOP
      FETCH cur_ifnotcmmInfo
        INTO v_rcpt_no, v_dpt_cde, v_prod_no, v_get_prm, v_edr_no, v_DUE_TM, v_ply_no, v_feetyp_cde, v_tran_flag, v_cmmcnt, v_arp_flag, v_con_dpt_cde, v_clm_no;

      EXIT WHEN cur_ifnotcmmInfo%NOTFOUND;

      --????????
      SELECT c_dptacc_cde, c_department_cde, c_company_cde
        INTO v_dptacc_cde, v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      --???????
      --IF v_tran_flag='2' THEN
      --  ;
      --END IF;

      --?????
      Dz_Proc.get_fin_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

      v_dr_amt     := v_get_prm;
      v_cr_amt     := v_get_prm;
      v_drcav_flag := '?';
      v_crcav_flag := '?';

      SELECT c_kind_no
        INTO v_kind_no
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = v_prod_no;

      IF v_clm_no IS NULL OR v_clm_no = ' ' THEN
        --?????,????
        --???????443101
        -- ??????? 211101
        --IF v_get_prm >0 THEN
        v_drsbjt_no      := '443101'; --?????
        v_crsbjt_no      := '211101'; --?????
        v_servicetype_no := '1007';
        v_vou_memo       := '???????';
        --END IF;

        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           c_item_no,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           c_dptacc_no,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde)
          SELECT vTmpVouNo,
                 '1',
                 v_drcav_flag,
                 v_drsbjt_no,
                 v_dr_amt,
                 c_bs_cur,
                 trunc(t_due_tm),
                 v_dptacc_cde,
                 c_dpt_cde,
                 c_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 C_PAYER_CDE,
                 NULL,
                 NULL,
                 NULL,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 v_sbjt_memo,
                 c_cha_mrk,
                 v_vou_memo,
                 c_ply_no,
                 v_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde
            FROM WEB_FIN_PAY_DUE
           WHERE c_rcpt_no = trim(v_rcpt_no);

        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           c_item_no,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           c_dptacc_no,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde)
          SELECT vTmpVouNo,
                 '2',
                 v_crcav_flag,
                 v_crsbjt_no,
                 v_cr_amt,
                 C_CUR_NO,
                 TRUNC(T_CRT_TM),
                 c_dptacc_no,
                 C_DPT_CDE,
                 C_RCPT_NO,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SALEGRP_CDE,
                 c_pay_prsn_cde,
                 C_RI_COM,
                 C_CONT_CODE,
                 C_VOU_NO,
                 '0',
                 C_bsns_typ,
                 C_pay_prsn_name,
                 c_sbjt_memo,
                 c_cha_mrk,
                 c_vou_memo,
                 c_ply_no,
                 c_con_dpt_cde,
                 c_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde
            FROM WEB_FIN_MADCR
           WHERE c_seq_no = trim(vTmpVouNo)
             AND c_item_no = '1';

        UPDATE WEB_FIN_PAY_DUE
           SET c_accnt_flag = DECODE(c_accnt_flag,
                                     '10',
                                     '11',
                                     '00',
                                     '01',
                                     '00')
         WHERE c_rcpt_NO = v_rcpt_no;
      END IF;

      commit;
    END LOOP;
    CLOSE cur_ifnotcmmInfo;
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --    ----RAISE;
        --    dbms_output.put_line('exception'||'*'||v_rcpt_no||SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[handlingcharge],??????[' || v_rcpt_no ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;

  END;

  --4.??????
  PROCEDURE clmcharge IS
    /*????????? */

    --????
    v_rcpt_no WEB_FIN_CLM_DUE.c_rcpt_no%TYPE;

    --????
    v_dptacc_cde  WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_dpt_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_prod_no     WEB_FIN_CLM_DUE.c_prod_no%TYPE;
    v_get_prm     WEB_FIN_CLM_DUE.N_BS_AMT%TYPE;
    v_dr_amt      WEB_FIN_CLM_DUE.N_BS_AMT%TYPE;
    v_cr_amt      WEB_FIN_CLM_DUE.N_BS_AMT%TYPE;
    v_drcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag  WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_na_prm      WEB_FIN_CLM_DUE.N_BS_AMT%TYPE; --????
    v_ply_no      WEB_FIN_CLM_DUE.c_ply_no%TYPE;
    v_pay_amt     WEB_FIN_CLM_DUE.N_BS_AMT%TYPE; --????
    v_cnt         INT;
    v_tmpcnt      INT;
    vTmpVouNo     WEB_FIN_MADCR.c_seq_no%TYPE;
    v_sbjt_memo   WEB_FIN_MADCR.c_sbjt_memo%TYPE;
    vSbjtNo       WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_feetyp_cde  WEB_FIN_CLM_DUE.c_feetyp_cde%TYPE;
    v_tran_flag   WEB_FIN_CLM_DUE.c_tran_flag%TYPE;
    v_con_dpt_cde WEB_FIN_CLM_DUE.c_con_dpt_cde%TYPE;

    v_vou_memo WEB_FIN_DCR.c_vou_memo%TYPE;

    v_ri_com         VARCHAR2(4); /*???*/
    v_cont_code      VARCHAR2(2); /*????*/
    v_billcode       VARCHAR2(25); /*???*/
    v_internal_mark  CHAR(1); /*??/??*/
    v_arp_flag       CHAR(1);
    v_err_content    WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_eac_dcm_mrk    WEB_FIN_CLM_DUE.c_eac_dcm_mrk%TYPE;
    v_clm_no         WEB_FIN_CLM_DUE.c_clm_no%TYPE;
    v_total_preamt   WEB_FIN_CLM_DUE.N_BS_AMT%TYPE;
    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
    v_kind_no        WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_DCR.c_company_cde%TYPE;
    v_pretyp_cde     WEB_FIN_CLM_DUE.c_pretyp_cde%TYPE;

    CURSOR cur_ifclmInfo IS
      SELECT c_rcpt_no
        FROM WEB_FIN_CLM_DUE
       WHERE c_accnt_flag IN ('00', '10')
            --AND t_crt_tm  >= TO_DATE('2007-05-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
         AND t_crt_tm >= sysdate - 30
         AND c_eac_dcm_mrk = '2'; /*1?????2???3 ??? 4??*/
  BEGIN

    OPEN cur_ifclmInfo;
    LOOP
      FETCH cur_ifclmInfo
        INTO v_rcpt_no;
      EXIT WHEN cur_ifclmInfo%NOTFOUND;

      --???????
      --??????
      SELECT c_dpt_cde,
             c_prod_no,
             N_BS_AMT,
             c_ply_no,
             c_feetyp_cde,
             c_arp_flag,
             c_tran_flag,
             c_con_dpt_cde,
             c_eac_dcm_mrk,
             c_clm_no
        INTO v_dpt_cde,
             v_prod_no,
             v_get_prm,
             v_ply_no,
             v_feetyp_cde,
             v_arp_flag,
             v_tran_flag,
             v_con_dpt_cde,
             v_eac_dcm_mrk,
             v_clm_no
        FROM WEB_FIN_CLM_DUE
       WHERE c_rcpt_no = v_rcpt_no;

      SELECT SUM(N_BS_AMT)
        INTO v_total_preamt
        FROM WEB_FIN_CLM_DUE
       WHERE c_clm_no = v_clm_no
         AND c_eac_dcm_mrk IN ('1', '5')
         AND (c_feetyp_cde IS NULL OR c_feetyp_cde = ' ')
         AND (c_rollback_mark IS NULL OR c_rollback_mark <> 'X');

      SELECT c_dptacc_cde, c_department_cde, c_company_cde
        INTO v_dptacc_cde, v_department_cde, v_company_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      SELECT c_kind_no
        INTO v_kind_no
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = v_prod_no;

      --?????? 440101
      --?????? 215001

      v_cr_amt := v_get_prm;
      v_dr_amt := v_get_prm;

      IF v_feetyp_cde IS NULL OR v_feetyp_cde = ' ' THEN
        v_vou_memo       := '??????';
        v_servicetype_no := '1009';
        Dz_Proc.get_fin_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

        --/*?:????,?:????*/
        vSbjtNo := '440101';
        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           c_item_no,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           c_dptacc_no,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde)
          SELECT vTmpVouNo,
                 '1',
                 '?',
                 vSbjtNo,
                 v_dr_amt,
                 c_bs_cur,
                 TRUNC(t_crt_tm),
                 v_dptacc_cde,
                 c_dpt_cde,
                 v_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 c_insrnt_cde,
                 NULL,
                 NULL,
                 NULL,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 v_sbjt_memo,
                 c_cha_mrk,
                 v_vou_memo,
                 c_ply_no,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

        vSbjtNo := '215001';
        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           c_item_no,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           c_dptacc_no,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde)
          SELECT C_SEQ_NO,
                 '2',
                 '?',
                 vSbjtNo,
                 v_cr_amt,
                 C_CUR_NO,
                 TRUNC(T_CRT_TM),
                 c_dptacc_no,
                 C_DPT_CDE,
                 C_RCPT_NO,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SALEGRP_CDE,
                 c_pay_prsn_cde,
                 C_RI_COM,
                 C_CONT_CODE,
                 C_VOU_NO,
                 '0',
                 C_bsns_typ,
                 C_pay_prsn_name,
                 c_sbjt_memo,
                 c_cha_mrk,
                 c_vou_memo,
                 c_ply_no,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde
            FROM WEB_FIN_MADCR
           WHERE c_seq_no = vTmpVouNo
             AND c_item_no = '1';

        IF v_total_preamt <> 0 OR v_total_preamt IS NOT NULL THEN
          --/*?:????,?:????*/
          Dz_Proc.get_fin_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);
          vSbjtNo          := '440101';
          v_vou_memo       := '??????????';
          v_servicetype_no := '1010';

          INSERT INTO WEB_FIN_MADCR
            (C_SEQ_NO,
             c_item_no,
             C_CAV_FLAG,
             c_sbjt_no,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             c_dptacc_no,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,
             c_pay_prsn_cde,
             C_RI_COM,
             C_CONT_CODE,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             C_pay_prsn_name,
             c_sbjt_memo,
             c_cha_mrk,
             c_vou_memo,
             c_ply_no,
             c_con_dpt_cde,
             c_servicetype_no,
             c_kind_no,
             c_department_cde,
             c_company_cde)
            SELECT vTmpVouNo,
                   '1',
                   '?',
                   vSbjtNo,
                   v_total_preamt,
                   c_bs_cur,
                   TRUNC(t_crt_tm),
                   v_dptacc_cde,
                   c_dpt_cde,
                   v_rcpt_no,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   C_SLSGRP_CDE,
                   c_insrnt_cde,
                   NULL,
                   NULL,
                   NULL,
                   '0',
                   C_bsns_typ,
                   C_PAYER_NME,
                   v_sbjt_memo,
                   c_cha_mrk,
                   v_vou_memo,
                   c_ply_no,
                   c_con_dpt_cde,
                   v_servicetype_no,
                   v_kind_no,
                   v_department_cde,
                   v_company_cde
              FROM WEB_FIN_CLM_DUE
             WHERE c_rcpt_no = v_rcpt_no;

          vSbjtNo := '113101';

          SELECT NVL(c_pretyp_cde, '0')
            INTO v_pretyp_cde
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

          IF v_pretyp_cde = '0' THEN
            v_vou_memo       := '??????????';
            v_servicetype_no := '1010';
            vSbjtNo          := '113101';
          ELSIF v_pretyp_cde = '1' THEN
            v_vou_memo       := '??????????';
            v_servicetype_no := '1010';
            vSbjtNo          := '113101';
          ELSIF v_pretyp_cde = '2' THEN
            v_vou_memo       := '??????????????';
            v_servicetype_no := '1150';
            vSbjtNo          := '113102';
          ELSIF v_pretyp_cde = '3' THEN
            v_vou_memo       := '??????????????';
            v_servicetype_no := '1151';
            vSbjtNo          := '113103';
          ELSIF v_pretyp_cde = '4' THEN
            v_vou_memo       := '???????????????';
            v_servicetype_no := '1149';
            vSbjtNo          := '113104';
          END IF;

          /*
          113101????/????
          113102????/????
          113103????/????
          113104????/????

            */

          INSERT INTO WEB_FIN_MADCR
            (C_SEQ_NO,
             c_item_no,
             C_CAV_FLAG,
             c_sbjt_no,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             c_dptacc_no,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,
             c_pay_prsn_cde,
             C_RI_COM,
             C_CONT_CODE,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             C_pay_prsn_name,
             c_sbjt_memo,
             c_cha_mrk,
             c_vou_memo,
             c_ply_no,
             c_con_dpt_cde,
             c_servicetype_no,
             c_kind_no,
             c_department_cde,
             c_company_cde)
            SELECT vTmpVouNo,
                   '2',
                   '?',
                   vSbjtNo,
                   v_total_preamt,
                   C_CUR_NO,
                   TRUNC(T_CRT_TM),
                   c_dptacc_no,
                   C_DPT_CDE,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   C_SALEGRP_CDE,
                   c_pay_prsn_cde,
                   C_RI_COM,
                   C_CONT_CODE,
                   C_VOU_NO,
                   '0',
                   C_bsns_typ,
                   C_pay_prsn_name,
                   c_sbjt_memo,
                   c_cha_mrk,
                   c_vou_memo,
                   c_ply_no,
                   c_con_dpt_cde,
                   v_servicetype_no,
                   v_kind_no,
                   v_department_cde,
                   v_company_cde
              FROM WEB_FIN_MADCR
             WHERE c_seq_no = vTmpVouNo
               AND c_item_no = '1';

          UPDATE WEB_FIN_CLM_DUE
             SET c_rollback_mark = 'X'
           WHERE c_clm_no = v_clm_no
             AND c_eac_dcm_mrk IN ('1', '5')
             AND c_feetyp_cde IS NULL
             AND (c_rollback_mark IS NULL OR c_rollback_mark <> 'X');
        END IF;
      ELSE
        --????
        /*
          --?????????? 440103

          --????,????
          v_drsbjt_no:='440102';--????\??????440101
          v_crsbjt_no := '215002';--215001  ?????\?????
        */

        v_vou_memo       := '?????';
        v_servicetype_no := '1011';
        Dz_Proc.get_fin_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

        --/*?:????,?:????*/
        vSbjtNo := '440102';
        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           c_item_no,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           c_dptacc_no,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde)
          SELECT vTmpVouNo,
                 '1',
                 '?',
                 vSbjtNo,
                 v_dr_amt,
                 c_bs_cur,
                 TRUNC(t_crt_tm),
                 v_dptacc_cde,
                 c_dpt_cde,
                 v_rcpt_no,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SLSGRP_CDE,
                 c_insrnt_cde,
                 NULL,
                 NULL,
                 NULL,
                 '0',
                 C_bsns_typ,
                 C_PAYER_NME,
                 v_sbjt_memo,
                 c_cha_mrk,
                 v_vou_memo,
                 c_ply_no,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde
            FROM WEB_FIN_CLM_DUE
           WHERE c_rcpt_no = v_rcpt_no;

        vSbjtNo := '215002';
        INSERT INTO WEB_FIN_MADCR
          (C_SEQ_NO,
           c_item_no,
           C_CAV_FLAG,
           c_sbjt_no,
           N_AMT,
           C_CUR_NO,
           T_CRT_TM,
           c_dptacc_no,
           C_DPT_CDE,
           C_RCPT_NO,
           C_SLS_CDE,
           C_PROD_NO,
           C_CHA_CLS,
           C_CHA_CDE,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           C_RI_COM,
           C_CONT_CODE,
           C_VOU_NO,
           C_SEND_FLAG,
           C_bsns_typ,
           C_pay_prsn_name,
           c_sbjt_memo,
           c_cha_mrk,
           c_vou_memo,
           c_ply_no,
           c_con_dpt_cde,
           c_servicetype_no,
           c_kind_no,
           c_department_cde,
           c_company_cde)
          SELECT C_SEQ_NO,
                 '2',
                 '?',
                 vSbjtNo,
                 v_cr_amt,
                 C_CUR_NO,
                 TRUNC(T_CRT_TM),
                 c_dptacc_no,
                 C_DPT_CDE,
                 C_RCPT_NO,
                 C_SLS_CDE,
                 C_PROD_NO,
                 C_CHA_CLS,
                 C_CHA_CDE,
                 C_SALEGRP_CDE,
                 c_pay_prsn_cde,
                 C_RI_COM,
                 C_CONT_CODE,
                 C_VOU_NO,
                 '0',
                 C_bsns_typ,
                 C_pay_prsn_name,
                 c_sbjt_memo,
                 c_cha_mrk,
                 c_vou_memo,
                 c_ply_no,
                 c_con_dpt_cde,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde,
                 v_company_cde
            FROM WEB_FIN_MADCR
           WHERE c_seq_no = vTmpVouNo
             AND c_item_no = '1';

      END IF;
      UPDATE WEB_FIN_CLM_DUE
         SET c_accnt_flag = DECODE(c_accnt_flag,
                                   '10',
                                   '11',
                                   '00',
                                   '01',
                                   '00')
       WHERE c_rcpt_no = v_rcpt_no;

      commit;

    END LOOP;
    CLOSE cur_ifclmInfo;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        ROLLBACK;

        v_err_content := 'proc:[clmcharge],??????[' || v_rcpt_no ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;

  END;

  --??
  --??
  PROCEDURE gather IS
    /*???????????,??????????????????*/
    /*?????*/
    v_drsbjt_no  WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_no    WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_tmpsbjt_no VARCHAR(20);

    v_dpt_cde    WEB_FIN_MADCR.c_dpt_cde%TYPE;
    v_dptacc_cde WEB_FIN_MADCR.c_dptacc_no%TYPE;
    v_prod_no    WEB_FIN_MADCR.c_prod_no%TYPE;
    v_cur_no     web_fin_madcr_intf.c_cur_no%TYPE;
    v_drcav_flag WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_dramt      WEB_FIN_MADCR.n_amt%TYPE;
    v_cramt      WEB_FIN_MADCR.n_amt%TYPE;
    v_amt        WEB_FIN_MADCR.n_amt%TYPE;
    v_vou_memo   VARCHAR(200);
    vTmpVouNo    VARCHAR(30);
    v_crt_tm     WEB_FIN_MADCR.t_crt_tm%TYPE;

    v_salegrp_cde WEB_FIN_MADCR.c_salegrp_cde%TYPE;
    v_bsns_typ    WEB_FIN_MADCR.c_bsns_typ%TYPE;
    v_cha_mrk     WEB_FIN_MADCR.c_cha_mrk%TYPE;
    v_con_dpt_cde WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
    --????????????  ORACLE?????????
    v_company_cde    WEB_ORG_DPT.c_company_cde%TYPE;
    v_department_cde WEB_ORG_DPT.c_department_cde%TYPE;
    v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;

    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_makevou     VARCHAR2(1);
    v_check_flag  WEB_FIN_DCR.c_check_flag%TYPE;
    v_voucher_no  WEB_FIN_MADCR.c_voucher_no%TYPE;

    v_sbjt_memo   web_fin_dcr_intf.c_sbjt_memo%TYPE;
    v_period_name web_fin_dcr_intf.c_period_name%TYPE;

    v_succsflag INT;
    v_ri_com    web_fin_dcr_intf.c_ri_com%TYPE;
    v_total_amt WEB_FIN_madcr.n_total_amt%TYPE;
    v_ncompany  INT;
    v_nri       INT;

    v_voucompany_cde    WEB_FIN_madcr.c_company_cde%TYPE;
    v_voudepartment_cde WEB_FIN_madcr.c_department_cde%TYPE;
    v_voudpt_cde        WEB_FIN_madcr.c_dpt_cde%TYPE;
    v_voudptacc_cde     WEB_FIN_madcr.c_dpt_cde%TYPE;
    l_bool              boolean;

    CURSOR cur_ifgDetailma IS
      SELECT c_dpt_cde,
             c_kind_no,
             c_cur_no,
             SUM(n_amt) / 2,
             TRUNC(t_crt_tm),
             c_servicetype_no
        FROM WEB_FIN_MADCR
       WHERE c_vou_no IS NULL
         AND t_crt_tm < TRUNC(SYSDATE)
         and t_crt_tm > sysdate - 30
         AND c_ri_com IS NULL
         AND c_servicetype_no NOT IN
             ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
              '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004',
              '1127', '1148', '1133', '1135', '1152', '1129', '1131', '1101',
              '1429', '1431')
       GROUP BY c_dpt_cde,
                c_kind_no,
                c_cur_no,
                TRUNC(t_crt_tm),
                c_servicetype_no;

    CURSOR cur_ifriDetailma IS
      SELECT c_dpt_cde,
             c_kind_no,
             c_cur_no,
             SUM(n_amt) / 2,
             TRUNC(t_crt_tm),
             c_servicetype_no,
             c_ri_com
        FROM WEB_FIN_MADCR
       WHERE c_vou_no IS NULL
         AND t_crt_tm < TRUNC(SYSDATE)
         and t_crt_tm > sysdate - 30
         AND c_ri_com IS NOT NULL
         AND c_servicetype_no NOT IN
             ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
              '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004',
              '1127', '1148', '1133', '1135', '1152', '1129', '1131', '1101',
              '1429', '1431')
       GROUP BY c_dpt_cde,
                c_kind_no,
                c_cur_no,
                TRUNC(t_crt_tm),
                c_servicetype_no,
                c_ri_com;

    CURSOR cur_updgather IS
      SELECT c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no
        FROM web_fin_madcr_intf
       WHERE c_vou_no IS NULL
         and t_crt_tm > sysdate - 30
         and not (c_servicetype_no = '1007' AND c_prod_no like '014%')
            --AND c_prod_no<>'014'
            --AND c_prod_no not like '00%'
         AND c_servicetype_no NOT IN
             ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
              '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004',
              '1127', '1148', '1133', '1135', '1152', '1129', '1131', '1101',
              '1429', '1431')
       GROUP BY c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no;

    CURSOR cur_saveupdgather IS
      SELECT c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no
        FROM web_fin_madcr_intf
       WHERE c_vou_no IS NULL
         and t_crt_tm > sysdate - 30
         and (c_servicetype_no = '1007' AND c_prod_no like '014%')
         AND c_servicetype_no NOT IN
             ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
              '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004',
              '1127', '1148', '1133', '1135', '1152', '1129', '1131', '1101',
              '1429', '1431')
       GROUP BY c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no;

  BEGIN

    OPEN cur_ifgDetailma;
    LOOP
      FETCH cur_ifgDetailma
        INTO v_dpt_cde, v_prod_no, v_cur_no, v_amt, v_crt_tm, v_servicetype_no;
      EXIT WHEN cur_ifgDetailma%NOTFOUND;

      --?????
      --Dz_Proc.geWEB_FIN_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
      --??????????
      --???????/????/????
      --select  TO_CHAR(123,'0000') from dual;
      --?????7??+?????2??+?/??4??+??????4?)
      --????
      --??????,???????/????/????
      SELECT COUNT(*)
        INTO v_ncompany
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      /*
      ?????? 1000
        ??????  112201
        ??????  410101

      ?????? 1123
        ????????-?????? 122203
        ???????\??  410205

      ?????????? 1001
        ????????????  212101
        ??????  112201

      ?????? 1009
        ??????????? 440101
        ??????  215001

      ????? 1011
        ??????????  440102
        ??????????? 215001

      ?????????? 1010
        ??????  440101
        ??????  113101

      ??????? 1007
        ??????? 443101
        ??????? 211101

      5.1???????
      5.1?????
      ?1??????????????????
      ?????????????-?????? 122401   1127 ???????????
        ???????????-IBNR 122402   1148 ????????????????
      ???????????-?????? 421101
        ?????????- IBNR 421102


      ?2??????????????????
      ???????????-?????? 450101   1133 ?????????
        ?????????-IBNR 450102     1135 ????????????
        ?????????-???? 450103   1152 ?????????
      ?????????-???????????????  216101
        ???????-IBNR  216102
        ???????-????  216103


      122401,???????????/???????????
      122402,???????????/IBNR
      122403,???????????/????

      450101,?????????/???
      450102,?????????/IBNR
      450103,?????????/????

      421101,?????????/??????
      421102,?????????/??????
      421103,?????????/????

      216101,???????/???
      216102,???????/IBNR
      216103,???????/???????

        v_drsbjt_no:='119113';
        v_crsbjt_no:='214614';
        v_vou_memo:='?????????';
        v_servicetype_no:='5000';
      */

      v_drcav_flag := '?';
      v_crcav_flag := '?';
      v_dramt      := v_amt;
      v_cramt      := v_amt;
      v_makevou    := 'Y';

      IF v_servicetype_no = '1000' THEN
        --IF v_vou_memo='??????' THEN
        v_vou_memo  := '??????';
        v_drsbjt_no := '112201';
        v_sbjt_no   := '410101';
      ELSIF v_servicetype_no = '5000' THEN
        --IF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '119113';
        v_sbjt_no   := '214614';

      ELSIF v_servicetype_no = '1123' THEN
        --ELSIF v_vou_memo='??????' THEN
        v_drsbjt_no := '122203';
        v_sbjt_no   := '410205';
        v_vou_memo  := '??????';
      ELSIF v_servicetype_no = '1001' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '212101';
        v_sbjt_no   := '112201';
      ELSIF v_servicetype_no = '1009' THEN
        --ELSIF v_vou_memo='??????' THEN
        v_vou_memo  := '??????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '215001';
      ELSIF v_servicetype_no = '1011' THEN
        --ELSIF v_vou_memo='?????' THEN
        v_vou_memo  := '?????';
        v_drsbjt_no := '440102';
        v_sbjt_no   := '215002';
      ELSIF v_servicetype_no = '1010' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113101';
      ELSIF v_servicetype_no = '1150' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113102';
      ELSIF v_servicetype_no = '1151' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113103';
      ELSIF v_servicetype_no = '1149' THEN
        v_vou_memo  := '???????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113104';
      ELSIF v_servicetype_no = '1007' THEN
        --ELSIF v_vou_memo='???????' THEN
        v_vou_memo  := '???????';
        v_drsbjt_no := '443101';
        v_sbjt_no   := '211101';
      ELSIF v_servicetype_no = '1101' THEN
        --ELSIF v_vou_memo='????' THEN
        v_vou_memo  := '????';
        v_drsbjt_no := '446106';
        v_sbjt_no   := '214401';

      ELSIF v_servicetype_no = '1127' THEN
        --ELSIF v_vou_memo='???????????' THEN
        v_vou_memo  := '???????????';
        v_drsbjt_no := '122401';
        v_sbjt_no   := '421101';
      ELSIF v_servicetype_no = '1148' THEN
        --ELSIF v_vou_memo='????????????????' THEN
        v_vou_memo  := '????????????????';
        v_drsbjt_no := '122402';
        v_sbjt_no   := '421102';
      ELSIF v_servicetype_no = '1133' THEN
        --ELSIF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '450101';
        v_sbjt_no   := '216101';
      ELSIF v_servicetype_no = '1135' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '450102';
        v_sbjt_no   := '216102';
      ELSIF v_servicetype_no = '1152' THEN
        --ELSIF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '450103';
        v_sbjt_no   := '216103';

      ELSIF v_servicetype_no = '1129' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '122301';
        v_sbjt_no   := '450201';
      ELSIF v_servicetype_no = '1131' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '450201';
        v_sbjt_no   := '216201';

      ELSIF v_servicetype_no = '1429' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '122302';
        v_sbjt_no   := '450202';
      ELSIF v_servicetype_no = '1431' THEN
        --ELSIF v_vou_memo='??????????????' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '450202';
        v_sbjt_no   := '216202';

      ELSE
        v_makevou := 'N';
      END IF;

      IF v_ncompany = 0 THEN
        v_err_content := 'proc:[gather1],??????[' || v_dpt_cde ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);

      END IF;

      IF v_makevou = 'Y' AND v_ncompany > 0 THEN
        SELECT c_company_cde, c_dptacc_cde, c_department_cde
          INTO v_company_cde, v_dptacc_cde, v_department_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = trim(v_dpt_cde);

        SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;

        v_salegrp_cde := '000';
        v_bsns_typ    := '0';
        v_cha_mrk     := '0';
        v_check_flag  := '2';
        v_crt_tm      := TRUNC(v_crt_tm);
        BEGIN
          Dz_Proc.get_FIN_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

          INSERT INTO web_fin_madcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             n_amt,
             c_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_dpt_cde,
             c_prod_no,
             c_vou_memo,
             c_send_flag,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_con_dpt_cde,
             c_check_flag,
             c_servicetype_no)
          VALUES
            (vTmpVouNo,
             '1',
             v_drcav_flag,
             v_drsbjt_no,
             v_dramt,
             v_cur_no,
             TRUNC(v_crt_tm),
             v_dptacc_cde,
             v_dpt_cde,
             v_prod_no,
             v_vou_memo,
             '0',
             v_salegrp_cde,
             v_bsns_typ,
             v_cha_mrk,
             v_con_dpt_cde,
             v_check_flag,
             v_servicetype_no);

          INSERT INTO web_fin_madcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             n_amt,
             c_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_dpt_cde,
             c_prod_no,
             c_vou_memo,
             c_send_flag,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_con_dpt_cde,
             c_check_flag,
             c_servicetype_no)
          VALUES
            (vTmpVouNo,
             '2',
             v_crcav_flag,
             v_sbjt_no,
             v_cramt,
             v_cur_no,
             TRUNC(v_crt_tm),
             v_dptacc_cde,
             v_dpt_cde,
             v_prod_no,
             v_vou_memo,
             '0',
             v_salegrp_cde,
             v_bsns_typ,
             v_cha_mrk,
             v_con_dpt_cde,
             v_check_flag,
             v_servicetype_no);

          /*??????*/

          UPDATE WEB_FIN_MADCR
             SET c_vou_no = vTmpVouNo
           WHERE c_dpt_cde = v_dpt_cde
             AND c_kind_no = v_prod_no
             AND c_cur_no = v_cur_no
             AND t_crt_tm >=
                 TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                         'YYYY-MM-DD HH24:MI:SS')
             AND t_crt_tm <=
                 TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS')
             AND c_servicetype_no = v_servicetype_no
             AND c_vou_no IS NULL
             AND c_ri_com IS NULL
             AND c_rcpt_no IS NOT NULL;

          --????????????
          SELECT SUM(n_amt) / 2
            INTO v_total_amt
            FROM web_fin_madcr_intf
           WHERE c_seq_no = vTmpVouNo;

          UPDATE WEB_FIN_MADCR
             SET c_company_cde = v_company_cde,
                 c_period_name = v_period_name,
                 n_total_amt   = v_total_amt
           WHERE c_vou_no = vTmpVouNo;

          UPDATE web_fin_madcr_intf
             SET c_company_cde    = v_company_cde,
                 c_department_cde = v_department_cde,
                 c_period_name    = v_period_name,
                 t_end_tm         = SYSDATE,
                 n_total_amt      = v_total_amt,
                 c_cur_no         = DECODE(c_cur_no,
                                           '01',
                                           'CNY',
                                           '02',
                                           'HKD',
                                           '03',
                                           'USD',
                                           '12',
                                           'EUR',
                                           '13',
                                           'EUR',
                                           '05',
                                           'JPY',
                                           c_cur_no),
                 c_dpt_cde        = DECODE(c_dpt_cde,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_dpt_cde),
                 c_prod_no        = DECODE(c_prod_no,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_prod_no),
                 c_bsns_typ       = DECODE(c_bsns_typ,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_bsns_typ)
           WHERE c_seq_no = vTmpVouNo;

        END;
      END IF;
      commit;

    END LOOP;
    CLOSE cur_ifgDetailma;

    OPEN cur_ifriDetailma;
    LOOP
      FETCH cur_ifriDetailma
        INTO v_dpt_cde, v_prod_no, v_cur_no, v_amt, v_crt_tm, v_servicetype_no, v_ri_com;
      EXIT WHEN cur_ifriDetailma%NOTFOUND;

      --?????
      --Dz_Proc.geWEB_FIN_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
      --??????????
      --???????/????/????
      --select  TO_CHAR(123,'0000') from dual;
      --?????7??+?????2??+?/??4??+??????4?)
      --????
      --??????,???????/????/????

      SELECT COUNT(*)
        INTO v_ncompany
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      SELECT COUNT(*)
        INTO v_nri
        FROM web_bas_fin_ri
       WHERE c_ri_com = v_ri_com;

      IF v_nri > 0 AND v_ncompany > 0 THEN
        SELECT c_company_cde, c_dptacc_cde, c_department_cde
          INTO v_company_cde, v_dptacc_cde, v_department_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = trim(v_dpt_cde);

        SELECT c_finri_com
          INTO v_sbjt_memo
          FROM web_bas_fin_ri
         WHERE c_ri_com = v_ri_com;

        SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;

        v_drcav_flag := '?';
        v_crcav_flag := '?';
        v_dramt      := v_amt;
        v_cramt      := v_amt;
        v_makevou    := 'Y';

        IF v_servicetype_no = '1116' THEN
          --ELSIF v_vou_memo='??????' THEN
          v_vou_memo  := '??????';
          v_drsbjt_no := '442101';
          v_sbjt_no   := '211301';
        ELSIF v_servicetype_no = '1117' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122201';
          v_sbjt_no   := '420301';

        ELSIF v_servicetype_no = '1118' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122202';
          v_sbjt_no   := '420101';

          --ELSIF v_servicetype_no='1119' THEN
          --ELSIF v_vou_memo='????????' THEN

        ELSIF v_servicetype_no = '1121' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122204';
          v_sbjt_no   := '213101';

        ELSIF v_servicetype_no = '1122' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '446104';
          v_sbjt_no   := '211304';

        ELSIF v_servicetype_no = '3000' THEN
          --ELSIF v_vou_memo='????????' THEN
          v_vou_memo  := '????????';
          v_drsbjt_no := '211301';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '3001' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '211304';
          v_sbjt_no   := '119603';

        ELSIF v_servicetype_no = '4000' THEN
          --ELSIF v_vou_memo='????????' THEN
          v_vou_memo  := '????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '211301';
        ELSIF v_servicetype_no = '4001' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '211304';

        ELSIF v_servicetype_no = '3002' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122201';
        ELSIF v_servicetype_no = '3003' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122202';
        ELSIF v_servicetype_no = '3004' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122204';

        ELSIF v_servicetype_no = '4002' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122201';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '4003' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122202';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '4004' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122204';
          v_sbjt_no   := '119603';

          /*

            ?????????????????
              ??????????????????211301
              ???????\???????? 119603?

            ?????????????????
              ???????\????????? 119603
              ?????????????????211301

            ------------------------------------------------------
            ??????????????????????????
            ???????\???????????? 119603
            ?????????????122201  ?122202

            ??????????????????????????
            ?????????????122201
                 ???????\?????????119603



            INSERT INTO WEB_FIN_servicetype(c_no,c_name)
            VALUES('3000','?????????????????');

            INSERT INTO WEB_FIN_servicetype(c_no,c_name)
            VALUES('3001','?????????????????');

            INSERT INTO WEB_FIN_servicetype(c_no,c_name)
            VALUES('3002','??????????????????????????');

            INSERT INTO WEB_FIN_servicetype(c_no,c_name)
            VALUES('3003','??????????????????????????');

            3000,?????????????????
            3001,?????????????????
            3002,??????????????????????????
            3003,??????????????????????????
          */

        ELSIF v_servicetype_no = '1127' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122401';
          v_sbjt_no   := '421101';
        ELSIF v_servicetype_no = '1148' THEN
          --ELSIF v_vou_memo='????????????????' THEN
          v_vou_memo  := '????????????????';
          v_drsbjt_no := '122402';
          v_sbjt_no   := '421102';
        ELSIF v_servicetype_no = '1133' THEN
          --ELSIF v_vou_memo='?????????' THEN
          v_vou_memo  := '?????????';
          v_drsbjt_no := '450101';
          v_sbjt_no   := '216101';
        ELSIF v_servicetype_no = '1135' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '450102';
          v_sbjt_no   := '216102';
        ELSIF v_servicetype_no = '1152' THEN
          --ELSIF v_vou_memo='?????????' THEN
          v_vou_memo  := '?????????';
          v_drsbjt_no := '450103';
          v_sbjt_no   := '421103';

        ELSIF v_servicetype_no = '1129' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '122301';
          v_sbjt_no   := '450201';
        ELSIF v_servicetype_no = '1131' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '450201';
          v_sbjt_no   := '216201';
        ELSIF v_servicetype_no = '1429' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '122302';
          v_sbjt_no   := '450202';
        ELSIF v_servicetype_no = '1431' THEN
          --ELSIF v_vou_memo='??????????????' THEN
          v_vou_memo  := '??????????????';
          v_drsbjt_no := '450202';
          v_sbjt_no   := '216202';
          ---------------------------------------------------------
        ELSE
          v_makevou := 'N';
        END IF;

        IF v_makevou = 'Y' THEN
          v_salegrp_cde := '000';
          v_bsns_typ    := '0';
          v_cha_mrk     := '0';
          v_check_flag  := '2';
          v_crt_tm      := TRUNC(v_crt_tm);

          BEGIN

            Dz_Proc.get_FIN_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

            INSERT INTO web_fin_madcr_intf
              (c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_prod_no,
               c_vou_memo,
               c_send_flag,
               c_salegrp_cde,
               c_bsns_typ,
               c_cha_mrk,
               c_con_dpt_cde,
               c_check_flag,
               c_servicetype_no,
               c_sbjt_memo,
               c_ri_com)
            VALUES
              (vTmpVouNo,
               '1',
               v_drcav_flag,
               v_drsbjt_no,
               v_dramt,
               v_cur_no,
               TRUNC(v_crt_tm),
               v_dptacc_cde,
               v_dpt_cde,
               v_prod_no,
               v_vou_memo,
               '0',
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_con_dpt_cde,
               v_check_flag,
               v_servicetype_no,
               v_sbjt_memo,
               v_ri_com);

            INSERT INTO web_fin_madcr_intf
              (c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_prod_no,
               c_vou_memo,
               c_send_flag,
               c_salegrp_cde,
               c_bsns_typ,
               c_cha_mrk,
               c_con_dpt_cde,
               c_check_flag,
               c_servicetype_no,
               c_sbjt_memo,
               c_ri_com)
            VALUES
              (vTmpVouNo,
               '2',
               v_crcav_flag,
               v_sbjt_no,
               v_cramt,
               v_cur_no,
               TRUNC(v_crt_tm),
               v_dptacc_cde,
               v_dpt_cde,
               v_prod_no,
               v_vou_memo,
               '0',
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_con_dpt_cde,
               v_check_flag,
               v_servicetype_no,
               v_sbjt_memo,
               v_ri_com);

            /*??????*/

            UPDATE WEB_FIN_MADCR
               SET c_vou_no = vTmpVouNo
             WHERE 1 = 1
               AND c_dpt_cde = v_dpt_cde
               AND c_kind_no = v_prod_no
               AND c_cur_no = v_cur_no
               AND t_crt_tm >=
                   TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                           'YYYY-MM-DD HH24:MI:SS')
               AND t_crt_tm <=
                   TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS')
               AND c_servicetype_no = v_servicetype_no
               AND c_ri_com = v_ri_com
               AND c_vou_no IS NULL
               AND c_rcpt_no IS NOT NULL;

            SELECT SUM(n_amt) / 2
              INTO v_total_amt
              FROM web_fin_madcr_intf
             WHERE c_seq_no = vTmpVouNo;

            UPDATE WEB_FIN_MADCR
               SET c_company_cde    = v_company_cde,
                   c_period_name    = v_period_name,
                   c_department_cde = v_department_cde,
                   n_total_amt      = v_total_amt
             WHERE c_vou_no = vTmpVouNo;

            UPDATE web_fin_madcr_intf
               SET c_company_cde    = v_company_cde,
                   c_period_name    = v_period_name,
                   t_end_tm         = SYSDATE,
                   c_department_cde = v_department_cde,
                   n_total_amt      = v_total_amt,
                   c_cur_no         = DECODE(c_cur_no,
                                             '01',
                                             'CNY',
                                             '02',
                                             'HKD',
                                             '03',
                                             'USD',
                                             '12',
                                             'EUR',
                                             '13',
                                             'EUR',
                                             '05',
                                             'JPY',
                                             c_cur_no),
                   c_dpt_cde        = DECODE(c_dpt_cde,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_dpt_cde),
                   c_prod_no        = DECODE(c_prod_no,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_prod_no),
                   c_bsns_typ       = DECODE(c_bsns_typ,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_bsns_typ)
             WHERE c_seq_no = vTmpVouNo;
            commit;

          END;
        END IF;
      ELSE
        v_err_content := 'proc:[gather2],??????[' || v_dpt_cde ||
                         v_ri_com || v_vou_memo || v_sbjt_no ||
                         TO_CHAR(v_cramt) || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || v_dpt_cde ||
                         v_prod_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
      END IF; --v_ncompany||ri=0
      COMMIT;
    END LOOP;
    CLOSE cur_ifriDetailma;

    --????( ???????)
    OPEN cur_updgather;
    LOOP
      FETCH cur_updgather
        INTO v_company_cde, v_servicetype_no, v_crt_tm, v_cur_no;
      EXIT WHEN cur_updgather%NOTFOUND;

      SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;
      v_voucompany_cde := v_company_cde;

      IF v_servicetype_no IN ('4000', '4001', '4002', '4003', '4004') THEN
        v_voucompany_cde := '1000100';
      END IF;

      IF v_servicetype_no IN
         ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
          '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004') THEN
        --'??????''??????????' ?????????? ???????? ???????????
        Dz_Proc.get_fin_rivoucode(v_voucher_no,
                                  v_period_name,
                                  v_voucompany_cde,
                                  dz_proc.g_pttype);
      ELSIF v_servicetype_no IN ('1127', '1148', '1133', '1135', '1152',
             '1129', '1131', '1101', '1429', '1431') THEN
        --??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ????/??????????????/????????????
        Dz_Proc.get_FIN_prevoucode(v_voucher_no,
                                   v_period_name,
                                   v_voucompany_cde,
                                   dz_proc.g_pttype);
      ELSIF v_servicetype_no IS NULL THEN
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      ELSE
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      END IF;

      /*
        3000,????????
        3001,???????????
        4000,????????
        4001,???????????

        3002,??????????
        3003,??????????
        3004,???????????

        4002,??????????
        4003,??????????
        4004,???????????
      */
      v_voucompany_cde    := '1000100';
      v_voudepartment_cde := '2006';
      v_voudpt_cde        := '00000019';
      v_voudptacc_cde     := '00000019';

      IF v_servicetype_no IN ('3000', '3001') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4000', '4001') THEN

        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('3002', '3003', '3004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4002', '4003', '4004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;

      ELSE
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           and not (c_servicetype_no = '1007' AND c_prod_no like '014%')
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           and not (c_servicetype_no = '1007' AND c_prod_no like '00%')
           AND c_voucher_no IS NULL;
      END IF;

      --?????????????

      UPDATE web_fin_madcr_intf
         SET c_item_no = '0'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '1';

      IF v_servicetype_no <> '1001' THEN
        -- ?????
        UPDATE WEB_FIN_madcr
           SET c_item_no = '0'
         WHERE c_voucher_no = v_voucher_no
           AND c_item_no = '1';
      END IF;

      UPDATE web_fin_madcr_intf
         SET c_item_no = '1'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '0'
         AND ROWNUM < 2;

      IF v_servicetype_no <> '1001' THEN
        -- ?????
        UPDATE WEB_FIN_madcr
           SET c_item_no = '1'
         WHERE c_voucher_no = v_voucher_no
           AND c_item_no = '0'
           AND ROWNUM < 2;
      END IF;

      --?????????????????
      SELECT SUM(n_total_amt) / 2
        INTO v_total_amt
        FROM web_fin_madcr_intf
       WHERE c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET n_total_amt = v_total_amt
       WHERE c_vou_no = v_voucher_no;

      UPDATE WEB_FIN_madcr
         SET n_total_amt = v_total_amt
       WHERE c_voucher_no = v_voucher_no;

      --??????
      UPDATE web_fin_madcr_intf
         SET c_department_cde = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR
             c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR
             c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR
             c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET c_prod_no = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '119603%' OR
             c_sbjt_no LIKE '119113%' OR c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      Auto_Confirmed.ValidityCheckMaVou(v_voucher_no, v_succsflag);
      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[gather],??????????[' ||
                         TO_CHAR(v_succsflag) || v_company_cde ||
                         v_servicetype_no || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_updgather;

    --????( ???? ???????)
    OPEN cur_saveupdgather;
    LOOP
      FETCH cur_saveupdgather
        INTO v_company_cde, v_servicetype_no, v_crt_tm, v_cur_no;
      EXIT WHEN cur_saveupdgather%NOTFOUND;

      SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;
      v_voucompany_cde := v_company_cde;

      IF v_servicetype_no IN ('4000', '4001', '4002', '4003', '4004') THEN
        v_voucompany_cde := '1000100';
      END IF;

      IF v_servicetype_no = '1007' THEN
        v_voucompany_cde := '1000400';
      END IF;

      IF v_servicetype_no IN
         ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
          '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004') THEN
        --'??????''??????????' ?????????? ???????? ???????????
        Dz_Proc.get_fin_rivoucode(v_voucher_no,
                                  v_period_name,
                                  v_voucompany_cde,
                                  dz_proc.g_pttype);
      ELSIF v_servicetype_no IN ('1127', '1148', '1133', '1135', '1152',
             '1129', '1131', '1101', '1429', '1431') THEN
        --??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ????/??????????????/????????????
        Dz_Proc.get_FIN_prevoucode(v_voucher_no,
                                   v_period_name,
                                   v_voucompany_cde,
                                   dz_proc.g_pttype);
      ELSIF v_servicetype_no IS NULL THEN
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      ELSE
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      END IF;

      /*
        3000,????????
        3001,???????????
        4000,????????
        4001,???????????

        3002,??????????
        3003,??????????
        3004,???????????

        4002,??????????
        4003,??????????
        4004,???????????
      */
      v_voucompany_cde    := '1000100';
      v_voudepartment_cde := '2006';
      v_voudpt_cde        := '00000019';
      v_voudptacc_cde     := '00000019';

      IF v_servicetype_no IN ('3000', '3001') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4000', '4001') THEN

        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('3002', '3003', '3004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4002', '4003', '4004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;

      ELSE
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           and (c_servicetype_no = '1007' AND c_prod_no like '014%')
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_madcr
           SET c_voucher_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           and (c_servicetype_no = '1007' AND c_prod_no like '00%')
           AND c_voucher_no IS NULL;
      END IF;

      --?????????????

      UPDATE web_fin_madcr_intf
         SET c_item_no = '0'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '1';

      IF v_servicetype_no <> '1001' THEN
        -- ?????
        UPDATE WEB_FIN_madcr
           SET c_item_no = '0'
         WHERE c_voucher_no = v_voucher_no
           AND c_item_no = '1';
      END IF;

      UPDATE web_fin_madcr_intf
         SET c_item_no = '1'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '0'
         AND ROWNUM < 2;

      IF v_servicetype_no <> '1001' THEN
        -- ?????
        UPDATE WEB_FIN_madcr
           SET c_item_no = '1'
         WHERE c_voucher_no = v_voucher_no
           AND c_item_no = '0'
           AND ROWNUM < 2;
      END IF;

      --?????????????????
      SELECT SUM(n_total_amt) / 2
        INTO v_total_amt
        FROM web_fin_madcr_intf
       WHERE c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET n_total_amt      = v_total_amt,
             c_company_cde    = '1000400',
             c_department_cde = '2026'
       WHERE c_vou_no = v_voucher_no;

      UPDATE WEB_FIN_madcr
         SET n_total_amt = v_total_amt
       WHERE c_voucher_no = v_voucher_no;

      --??????
      UPDATE web_fin_madcr_intf
         SET c_department_cde = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR
             c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR
             c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR
             c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET c_prod_no = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '119603%' OR
             c_sbjt_no LIKE '119113%' OR c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      Auto_Confirmed.ValidityCheckMaVou(v_voucher_no, v_succsflag);
      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[gather],??????????[' ||
                         TO_CHAR(v_succsflag) || v_company_cde ||
                         v_servicetype_no || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_saveupdgather;

    --????????
    INSERT INTO WEB_FIN_MADCR_STATUS
      (C_SEQ_NO, T_CRT_TM)
    VALUES
      (F_Fin_Getcode('g'), SYSDATE);

    /*

      select NVL(c_err_content,'-')
      INTO v_err_content
      from WEB_BAS_FIN_ERRORLOG
      where trunc(t_crt_tm) =trunc(sysdate) AND ROWNUM =1;


        if  v_err_content<>'-' then
            l_bool:=CUX_SEND_MAIL(v_err_content,to_char(sysdate,'YYYY')||'-'||to_char(sysdate,'MM')||'-'||to_char(sysdate,'DD')||' ????????','zhuminghua@ab-insurance.com');
      END IF;
    */

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || vTmpVouNo || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[exception gather],??????[' ||
                         vTmpVouNo || v_vou_memo || v_sbjt_no ||
                         TO_CHAR(v_cramt) || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || v_dpt_cde ||
                         v_prod_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;

  END;

  --5.1 ?? ????
  --5.1 ?? ???? ?????gather,????c_servicetype_no???????????????????
  PROCEDURE rigather IS
    /*???????????,??????????????????*/
    /*?????*/
    v_drsbjt_no  WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_no    WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_tmpsbjt_no VARCHAR(20);

    v_dpt_cde    WEB_FIN_MADCR.c_dpt_cde%TYPE;
    v_dptacc_cde WEB_FIN_MADCR.c_dptacc_no%TYPE;
    v_prod_no    WEB_FIN_MADCR.c_prod_no%TYPE;
    v_cur_no     web_fin_madcr_intf.c_cur_no%TYPE;
    v_drcav_flag WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_dramt      WEB_FIN_MADCR.n_amt%TYPE;
    v_cramt      WEB_FIN_MADCR.n_amt%TYPE;
    v_amt        WEB_FIN_MADCR.n_amt%TYPE;
    v_vou_memo   VARCHAR(200);
    vTmpVouNo    VARCHAR(30);
    v_crt_tm     WEB_FIN_MADCR.t_crt_tm%TYPE;

    v_salegrp_cde WEB_FIN_MADCR.c_salegrp_cde%TYPE;
    v_bsns_typ    WEB_FIN_MADCR.c_bsns_typ%TYPE;
    v_cha_mrk     WEB_FIN_MADCR.c_cha_mrk%TYPE;
    v_con_dpt_cde WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
    --????????????  ORACLE?????????
    v_company_cde    WEB_ORG_DPT.c_company_cde%TYPE;
    v_department_cde WEB_ORG_DPT.c_department_cde%TYPE;
    v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;

    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_makevou     VARCHAR2(1);
    v_check_flag  WEB_FIN_DCR.c_check_flag%TYPE;
    v_voucher_no  WEB_FIN_MADCR.c_voucher_no%TYPE;

    v_sbjt_memo   web_fin_dcr_intf.c_sbjt_memo%TYPE;
    v_period_name web_fin_dcr_intf.c_period_name%TYPE;

    v_succsflag INT;
    v_ri_com    web_fin_dcr_intf.c_ri_com%TYPE;
    v_total_amt WEB_FIN_MADCR.n_total_amt%TYPE;
    v_ncompany  INT;
    v_nri       INT;

    v_voucompany_cde    WEB_FIN_MADCR.c_company_cde%TYPE;
    v_voudepartment_cde WEB_FIN_MADCR.c_department_cde%TYPE;
    v_voudpt_cde        WEB_FIN_MADCR.c_dpt_cde%TYPE;
    v_voudptacc_cde     WEB_FIN_MADCR.c_dpt_cde%TYPE;

    CURSOR cur_ifgDetailma IS
      SELECT c_dpt_cde,
             c_kind_no,
             c_cur_no,
             SUM(n_amt) / 2,
             TRUNC(t_crt_tm),
             c_servicetype_no
        FROM WEB_FIN_MADCR
       WHERE c_vou_no IS NULL
         AND t_crt_tm < TRUNC(SYSDATE)
         and t_crt_tm > sysdate - 30
         AND c_ri_com IS NULL
         AND c_servicetype_no IN
             ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
              '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004')
       GROUP BY c_dpt_cde,
                c_kind_no,
                c_cur_no,
                TRUNC(t_crt_tm),
                c_servicetype_no;

    CURSOR cur_ifriDetailma IS
      SELECT c_dpt_cde,
             c_kind_no,
             c_cur_no,
             SUM(n_amt) / 2,
             TRUNC(t_crt_tm),
             c_servicetype_no,
             c_ri_com
        FROM WEB_FIN_MADCR
       WHERE c_vou_no IS NULL
         AND t_crt_tm < TRUNC(SYSDATE)
         and t_crt_tm > sysdate - 30
         AND c_ri_com IS NOT NULL
         AND c_servicetype_no IN
             ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
              '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004')
       GROUP BY c_dpt_cde,
                c_kind_no,
                c_cur_no,
                TRUNC(t_crt_tm),
                c_servicetype_no,
                c_ri_com;

    CURSOR cur_updrigather IS
      SELECT c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no
        FROM web_fin_madcr_intf
       WHERE c_vou_no IS NULL
         and t_crt_tm > sysdate - 30
         AND c_servicetype_no IN
             ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
              '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004')
       GROUP BY c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no;

  BEGIN

    OPEN cur_ifgDetailma;
    LOOP
      FETCH cur_ifgDetailma
        INTO v_dpt_cde, v_prod_no, v_cur_no, v_amt, v_crt_tm, v_servicetype_no;
      EXIT WHEN cur_ifgDetailma%NOTFOUND;

      --?????
      --Dz_Proc.get_FIN_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
      --??????????
      --???????/????/????
      --select  TO_CHAR(123,'0000') from dual;
      --?????7??+?????2??+?/??4??+??????4?)
      --????
      --??????,???????/????/????
      SELECT COUNT(*)
        INTO v_ncompany
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      /*
      ?????? 1000
        ??????  112201
        ??????  410101

      ?????? 1123
        ????????-?????? 122203
        ???????\??  410205

      ?????????? 1001
        ????????????  212101
        ??????  112201

      ?????? 1009
        ??????????? 440101
        ??????  215001

      ????? 1011
        ??????????  440102
        ??????????? 215001

      ?????????? 1010
        ??????  440101
        ??????  113101

      ??????? 1007
        ??????? 443101
        ??????? 211101

      5.1???????
      5.1?????
      ?1??????????????????
      ?????????????-?????? 122401   1127 ???????????
        ???????????-IBNR 122402   1148 ????????????????
      ???????????-?????? 421101
        ?????????- IBNR 421102


      ?2??????????????????
      ???????????-?????? 450101   1133 ?????????
        ?????????-IBNR 450102     1135 ????????????
        ?????????-???? 450103   1152 ?????????
      ?????????-???????????????  216101
        ???????-IBNR  216102
        ???????-????  216103


      122401,???????????/???????????
      122402,???????????/IBNR
      122403,???????????/????

      450101,?????????/???
      450102,?????????/IBNR
      450103,?????????/????

      421101,?????????/??????
      421102,?????????/??????
      421103,?????????/????

      216101,???????/???
      216102,???????/IBNR
      216103,???????/???????

        v_drsbjt_no:='119113';
        v_crsbjt_no:='214614';
        v_vou_memo:='?????????';
        v_servicetype_no:='5000';
      */

      v_drcav_flag := '?';
      v_crcav_flag := '?';
      v_dramt      := v_amt;
      v_cramt      := v_amt;
      v_makevou    := 'Y';

      IF v_servicetype_no = '1000' THEN
        --IF v_vou_memo='??????' THEN
        v_vou_memo  := '??????';
        v_drsbjt_no := '112201';
        v_sbjt_no   := '410101';
      ELSIF v_servicetype_no = '5000' THEN
        --IF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '119113';
        v_sbjt_no   := '214614';

      ELSIF v_servicetype_no = '1123' THEN
        --ELSIF v_vou_memo='??????' THEN
        v_drsbjt_no := '122203';
        v_sbjt_no   := '410205';
        v_vou_memo  := '??????';
      ELSIF v_servicetype_no = '1001' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '212101';
        v_sbjt_no   := '112201';
      ELSIF v_servicetype_no = '1009' THEN
        --ELSIF v_vou_memo='??????' THEN
        v_vou_memo  := '??????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '215001';
      ELSIF v_servicetype_no = '1011' THEN
        --ELSIF v_vou_memo='?????' THEN
        v_vou_memo  := '?????';
        v_drsbjt_no := '440102';
        v_sbjt_no   := '215002';
      ELSIF v_servicetype_no = '1010' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113101';
      ELSIF v_servicetype_no = '1150' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113102';
      ELSIF v_servicetype_no = '1151' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113103';
      ELSIF v_servicetype_no = '1149' THEN
        v_vou_memo  := '???????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113104';
      ELSIF v_servicetype_no = '1007' THEN
        --ELSIF v_vou_memo='???????' THEN
        v_vou_memo  := '???????';
        v_drsbjt_no := '443101';
        v_sbjt_no   := '211101';
      ELSIF v_servicetype_no = '1101' THEN
        --ELSIF v_vou_memo='????' THEN
        v_vou_memo  := '????';
        v_drsbjt_no := '446106';
        v_sbjt_no   := '214401';

      ELSIF v_servicetype_no = '1127' THEN
        --ELSIF v_vou_memo='???????????' THEN
        v_vou_memo  := '???????????';
        v_drsbjt_no := '122401';
        v_sbjt_no   := '421101';
      ELSIF v_servicetype_no = '1148' THEN
        --ELSIF v_vou_memo='????????????????' THEN
        v_vou_memo  := '????????????????';
        v_drsbjt_no := '122402';
        v_sbjt_no   := '421102';
      ELSIF v_servicetype_no = '1133' THEN
        --ELSIF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '450101';
        v_sbjt_no   := '216101';
      ELSIF v_servicetype_no = '1135' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '450102';
        v_sbjt_no   := '216102';
      ELSIF v_servicetype_no = '1152' THEN
        --ELSIF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '450103';
        v_sbjt_no   := '216103';

      ELSIF v_servicetype_no = '1129' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '122301';
        v_sbjt_no   := '450201';
      ELSIF v_servicetype_no = '1131' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '450201';
        v_sbjt_no   := '216201';

      ELSE
        v_makevou := 'N';
      END IF;

      IF v_ncompany = 0 THEN
        v_err_content := 'proc:[rigather1],??????[' || v_dpt_cde ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);

      END IF;

      IF v_makevou = 'Y' AND v_ncompany > 0 THEN
        SELECT c_company_cde, c_dptacc_cde, c_department_cde
          INTO v_company_cde, v_dptacc_cde, v_department_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = trim(v_dpt_cde);

        SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;

        v_salegrp_cde := '000';
        v_bsns_typ    := '0';
        v_cha_mrk     := '0';
        v_check_flag  := '2';
        v_crt_tm      := TRUNC(v_crt_tm);
        BEGIN
          Dz_Proc.get_FIN_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

          INSERT INTO web_fin_madcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             n_amt,
             c_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_dpt_cde,
             c_prod_no,
             c_vou_memo,
             c_send_flag,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_con_dpt_cde,
             c_check_flag,
             c_servicetype_no)
          VALUES
            (vTmpVouNo,
             '1',
             v_drcav_flag,
             v_drsbjt_no,
             v_dramt,
             v_cur_no,
             TRUNC(v_crt_tm),
             v_dptacc_cde,
             v_dpt_cde,
             v_prod_no,
             v_vou_memo,
             '0',
             v_salegrp_cde,
             v_bsns_typ,
             v_cha_mrk,
             v_con_dpt_cde,
             v_check_flag,
             v_servicetype_no);

          INSERT INTO web_fin_madcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             n_amt,
             c_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_dpt_cde,
             c_prod_no,
             c_vou_memo,
             c_send_flag,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_con_dpt_cde,
             c_check_flag,
             c_servicetype_no)
          VALUES
            (vTmpVouNo,
             '2',
             v_crcav_flag,
             v_sbjt_no,
             v_cramt,
             v_cur_no,
             TRUNC(v_crt_tm),
             v_dptacc_cde,
             v_dpt_cde,
             v_prod_no,
             v_vou_memo,
             '0',
             v_salegrp_cde,
             v_bsns_typ,
             v_cha_mrk,
             v_con_dpt_cde,
             v_check_flag,
             v_servicetype_no);

          /*??????*/

          UPDATE WEB_FIN_MADCR
             SET c_vou_no = vTmpVouNo
           WHERE c_dpt_cde = v_dpt_cde
             AND c_kind_no = v_prod_no
             AND c_cur_no = v_cur_no
             AND t_crt_tm >=
                 TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                         'YYYY-MM-DD HH24:MI:SS')
             AND t_crt_tm <=
                 TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS')
             AND c_servicetype_no = v_servicetype_no
             AND c_vou_no IS NULL
             AND c_ri_com IS NULL
             AND c_rcpt_no IS NOT NULL;

          --????????????
          SELECT SUM(n_amt) / 2
            INTO v_total_amt
            FROM web_fin_madcr_intf
           WHERE c_seq_no = vTmpVouNo;

          UPDATE WEB_FIN_MADCR
             SET c_company_cde = v_company_cde,
                 c_period_name = v_period_name,
                 n_total_amt   = v_total_amt
           WHERE c_vou_no = vTmpVouNo;

          UPDATE web_fin_madcr_intf
             SET c_company_cde    = v_company_cde,
                 c_department_cde = v_department_cde,
                 c_period_name    = v_period_name,
                 t_end_tm         = SYSDATE,
                 n_total_amt      = v_total_amt,
                 c_cur_no         = DECODE(c_cur_no,
                                           '01',
                                           'CNY',
                                           '02',
                                           'HKD',
                                           '03',
                                           'USD',
                                           '12',
                                           'EUR',
                                           '13',
                                           'EUR',
                                           '05',
                                           'JPY',
                                           c_cur_no),
                 c_dpt_cde        = DECODE(c_dpt_cde,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_dpt_cde),
                 c_prod_no        = DECODE(c_prod_no,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_prod_no),
                 c_bsns_typ       = DECODE(c_bsns_typ,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_bsns_typ)
           WHERE c_seq_no = vTmpVouNo;

        END;
      END IF;
      commit;

    END LOOP;
    CLOSE cur_ifgDetailma;

    OPEN cur_ifriDetailma;
    LOOP
      FETCH cur_ifriDetailma
        INTO v_dpt_cde, v_prod_no, v_cur_no, v_amt, v_crt_tm, v_servicetype_no, v_ri_com;
      EXIT WHEN cur_ifriDetailma%NOTFOUND;

      --?????
      --Dz_Proc.get_FIN_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
      --??????????
      --???????/????/????
      --select  TO_CHAR(123,'0000') from dual;
      --?????7??+?????2??+?/??4??+??????4?)
      --????
      --??????,???????/????/????

      SELECT COUNT(*)
        INTO v_ncompany
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      SELECT COUNT(*)
        INTO v_nri
        FROM WEB_BAS_FIN_RI
       WHERE c_ri_com = v_ri_com;

      IF v_nri > 0 AND v_ncompany > 0 THEN
        SELECT c_company_cde, c_dptacc_cde, c_department_cde
          INTO v_company_cde, v_dptacc_cde, v_department_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = trim(v_dpt_cde);

        SELECT c_finri_com
          INTO v_sbjt_memo
          FROM WEB_BAS_FIN_RI
         WHERE c_ri_com = v_ri_com;

        SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;

        v_drcav_flag := '?';
        v_crcav_flag := '?';
        v_dramt      := v_amt;
        v_cramt      := v_amt;
        v_makevou    := 'Y';

        IF v_servicetype_no = '1116' THEN
          --ELSIF v_vou_memo='??????' THEN
          v_vou_memo  := '??????';
          v_drsbjt_no := '442101';
          v_sbjt_no   := '211301';
        ELSIF v_servicetype_no = '1117' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122201';
          v_sbjt_no   := '420301';

        ELSIF v_servicetype_no = '1118' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122202';
          v_sbjt_no   := '420101';

          --ELSIF v_servicetype_no='1119' THEN
          --ELSIF v_vou_memo='????????' THEN

        ELSIF v_servicetype_no = '1121' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122204';
          v_sbjt_no   := '213101';

        ELSIF v_servicetype_no = '1122' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '446104';
          v_sbjt_no   := '211304';

        ELSIF v_servicetype_no = '3000' THEN
          --ELSIF v_vou_memo='????????' THEN
          v_vou_memo  := '????????';
          v_drsbjt_no := '211301';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '3001' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '211304';
          v_sbjt_no   := '119603';

        ELSIF v_servicetype_no = '4000' THEN
          --ELSIF v_vou_memo='????????' THEN
          v_vou_memo  := '????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '211301';
        ELSIF v_servicetype_no = '4001' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '211304';

        ELSIF v_servicetype_no = '3002' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122201';
        ELSIF v_servicetype_no = '3003' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122202';
        ELSIF v_servicetype_no = '3004' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122204';

        ELSIF v_servicetype_no = '4002' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122201';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '4003' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122202';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '4004' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122204';
          v_sbjt_no   := '119603';

          /*

            ?????????????????
              ??????????????????211301
              ???????\???????? 119603?

            ?????????????????
              ???????\????????? 119603
              ?????????????????211301

            ------------------------------------------------------
            ??????????????????????????
            ???????\???????????? 119603
            ?????????????122201  ?122202

            ??????????????????????????
            ?????????????122201
                 ???????\?????????119603



            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3000','?????????????????');

            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3001','?????????????????');

            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3002','??????????????????????????');

            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3003','??????????????????????????');

            3000,?????????????????
            3001,?????????????????
            3002,??????????????????????????
            3003,??????????????????????????
          */

        ELSIF v_servicetype_no = '1127' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122401';
          v_sbjt_no   := '421101';
        ELSIF v_servicetype_no = '1148' THEN
          --ELSIF v_vou_memo='????????????????' THEN
          v_vou_memo  := '????????????????';
          v_drsbjt_no := '122402';
          v_sbjt_no   := '421102';
        ELSIF v_servicetype_no = '1133' THEN
          --ELSIF v_vou_memo='?????????' THEN
          v_vou_memo  := '?????????';
          v_drsbjt_no := '450101';
          v_sbjt_no   := '216101';
        ELSIF v_servicetype_no = '1135' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '450102';
          v_sbjt_no   := '216102';
        ELSIF v_servicetype_no = '1152' THEN
          --ELSIF v_vou_memo='?????????' THEN
          v_vou_memo  := '?????????';
          v_drsbjt_no := '450103';
          v_sbjt_no   := '421103';

        ELSIF v_servicetype_no = '1129' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '122301';
          v_sbjt_no   := '450201';
        ELSIF v_servicetype_no = '1131' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '450201';
          v_sbjt_no   := '216201';

        ELSIF v_servicetype_no = '1429' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '122302';
          v_sbjt_no   := '450202';
        ELSIF v_servicetype_no = '1431' THEN
          --ELSIF v_vou_memo='??????????????' THEN
          v_vou_memo  := '??????????????';
          v_drsbjt_no := '450202';
          v_sbjt_no   := '216202';

          ---------------------------------------------------------
        ELSE
          v_makevou := 'N';
        END IF;

        IF v_makevou = 'Y' THEN
          v_salegrp_cde := '000';
          v_bsns_typ    := '0';
          v_cha_mrk     := '0';
          v_check_flag  := '2';
          v_crt_tm      := TRUNC(v_crt_tm);

          BEGIN

            Dz_Proc.get_FIN_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

            INSERT INTO web_fin_madcr_intf
              (c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_prod_no,
               c_vou_memo,
               c_send_flag,
               c_salegrp_cde,
               c_bsns_typ,
               c_cha_mrk,
               c_con_dpt_cde,
               c_check_flag,
               c_servicetype_no,
               c_sbjt_memo,
               c_ri_com)
            VALUES
              (vTmpVouNo,
               '1',
               v_drcav_flag,
               v_drsbjt_no,
               v_dramt,
               v_cur_no,
               TRUNC(v_crt_tm),
               v_dptacc_cde,
               v_dpt_cde,
               v_prod_no,
               v_vou_memo,
               '0',
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_con_dpt_cde,
               v_check_flag,
               v_servicetype_no,
               v_sbjt_memo,
               v_ri_com);

            INSERT INTO web_fin_madcr_intf
              (c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_prod_no,
               c_vou_memo,
               c_send_flag,
               c_salegrp_cde,
               c_bsns_typ,
               c_cha_mrk,
               c_con_dpt_cde,
               c_check_flag,
               c_servicetype_no,
               c_sbjt_memo,
               c_ri_com)
            VALUES
              (vTmpVouNo,
               '2',
               v_crcav_flag,
               v_sbjt_no,
               v_cramt,
               v_cur_no,
               TRUNC(v_crt_tm),
               v_dptacc_cde,
               v_dpt_cde,
               v_prod_no,
               v_vou_memo,
               '0',
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_con_dpt_cde,
               v_check_flag,
               v_servicetype_no,
               v_sbjt_memo,
               v_ri_com);

            /*??????*/

            UPDATE WEB_FIN_MADCR
               SET c_vou_no = vTmpVouNo
             WHERE 1 = 1
               AND c_dpt_cde = v_dpt_cde
               AND c_kind_no = v_prod_no
               AND c_cur_no = v_cur_no
               AND t_crt_tm >=
                   TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                           'YYYY-MM-DD HH24:MI:SS')
               AND t_crt_tm <=
                   TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS')
               AND c_servicetype_no = v_servicetype_no
               AND c_ri_com = v_ri_com
               AND c_vou_no IS NULL
               AND c_rcpt_no IS NOT NULL;

            SELECT SUM(n_amt) / 2
              INTO v_total_amt
              FROM web_fin_madcr_intf
             WHERE c_seq_no = vTmpVouNo;

            UPDATE WEB_FIN_MADCR
               SET c_company_cde    = v_company_cde,
                   c_period_name    = v_period_name,
                   c_department_cde = v_department_cde,
                   n_total_amt      = v_total_amt
             WHERE c_vou_no = vTmpVouNo;

            UPDATE web_fin_madcr_intf
               SET c_company_cde    = v_company_cde,
                   c_period_name    = v_period_name,
                   t_end_tm         = SYSDATE,
                   c_department_cde = v_department_cde,
                   n_total_amt      = v_total_amt,
                   c_cur_no         = DECODE(c_cur_no,
                                             '01',
                                             'CNY',
                                             '02',
                                             'HKD',
                                             '03',
                                             'USD',
                                             '12',
                                             'EUR',
                                             '13',
                                             'EUR',
                                             '05',
                                             'JPY',
                                             c_cur_no),
                   c_dpt_cde        = DECODE(c_dpt_cde,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_dpt_cde),
                   c_prod_no        = DECODE(c_prod_no,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_prod_no),
                   c_bsns_typ       = DECODE(c_bsns_typ,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_bsns_typ)
             WHERE c_seq_no = vTmpVouNo;
            commit;

          END;
        END IF;
      ELSE
        v_err_content := 'proc:[rigather2],??????[' || v_dpt_cde ||
                         v_ri_com || v_vou_memo || v_sbjt_no ||
                         TO_CHAR(v_cramt) || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || v_dpt_cde ||
                         v_prod_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
      END IF; --v_ncompany||ri=0
      COMMIT;
    END LOOP;
    CLOSE cur_ifriDetailma;

    --????( ???????)
    OPEN cur_updrigather;
    LOOP
      FETCH cur_updrigather
        INTO v_company_cde, v_servicetype_no, v_crt_tm, v_cur_no;
      EXIT WHEN cur_updrigather%NOTFOUND;

      SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;
      v_voucompany_cde := v_company_cde;

      IF v_servicetype_no IN ('4000', '4001', '4002', '4003', '4004') THEN
        v_voucompany_cde := '1000100';
      END IF;

      IF v_servicetype_no IN
         ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
          '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004') THEN
        --'??????''??????????' ?????????? ???????? ???????????
        Dz_Proc.get_fin_rivoucode(v_voucher_no,
                                  v_period_name,
                                  v_voucompany_cde,
                                  dz_proc.g_pttype);
      ELSIF v_servicetype_no IN ('1127', '1148', '1133', '1135', '1152',
             '1129', '1131', '1101', '1429', '1431') THEN
        --??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ????/??????????????/????????????
        Dz_Proc.get_FIN_prevoucode(v_voucher_no,
                                   v_period_name,
                                   v_voucompany_cde,
                                   dz_proc.g_pttype);
      ELSIF v_servicetype_no IS NULL THEN
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      ELSE
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      END IF;

      /*
        3000,????????
        3001,???????????
        4000,????????
        4001,???????????

        3002,??????????
        3003,??????????
        3004,???????????

        4002,??????????
        4003,??????????
        4004,???????????
      */
      v_voucompany_cde    := '1000100';
      v_voudepartment_cde := '2006';
      v_voudpt_cde        := '00000019';
      v_voudptacc_cde     := '00000019';

      IF v_servicetype_no IN ('3000', '3001') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4000', '4001') THEN

        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('3002', '3003', '3004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4002', '4003', '4004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;

      ELSE
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      END IF;

      --?????????????
      UPDATE web_fin_madcr_intf
         SET c_item_no = '0'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '1';

      UPDATE WEB_FIN_MADCR
         SET c_item_no = '0'
       WHERE c_voucher_no = v_voucher_no
         AND c_item_no = '1';

      UPDATE web_fin_madcr_intf
         SET c_item_no = '1'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '0'
         AND ROWNUM < 2;

      UPDATE WEB_FIN_MADCR
         SET c_item_no = '1'
       WHERE c_voucher_no = v_voucher_no
         AND c_item_no = '0'
         AND ROWNUM < 2;

      --?????????????????
      SELECT SUM(n_total_amt) / 2
        INTO v_total_amt
        FROM web_fin_madcr_intf
       WHERE c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET n_total_amt = v_total_amt
       WHERE c_vou_no = v_voucher_no;

      UPDATE WEB_FIN_MADCR
         SET n_total_amt = v_total_amt
       WHERE c_voucher_no = v_voucher_no;

      --??????
      UPDATE web_fin_madcr_intf
         SET c_department_cde = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR
             c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR
             c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR
             c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET c_prod_no = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '119603%' OR
             c_sbjt_no LIKE '119113%' OR c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      Auto_Confirmed.ValidityCheckMaVou(v_voucher_no, v_succsflag);
      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[rigather],??????????[' ||
                         TO_CHAR(v_succsflag) || v_company_cde ||
                         v_servicetype_no || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_updrigather;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || vTmpVouNo || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[exception rigather],??????[' ||
                         vTmpVouNo || v_vou_memo || v_sbjt_no ||
                         TO_CHAR(v_cramt) || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || v_dpt_cde ||
                         v_prod_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;

  END;

  --5.2 ?? ????????
  PROCEDURE pregather IS
    /*???????????,??????????????????*/
    /*?????*/
    v_drsbjt_no  WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_sbjt_no    WEB_FIN_MADCR.c_sbjt_no%TYPE;
    v_tmpsbjt_no VARCHAR(20);

    v_dpt_cde    WEB_FIN_MADCR.c_dpt_cde%TYPE;
    v_dptacc_cde WEB_FIN_MADCR.c_dptacc_no%TYPE;
    v_prod_no    WEB_FIN_MADCR.c_prod_no%TYPE;
    v_cur_no     web_fin_madcr_intf.c_cur_no%TYPE;
    v_drcav_flag WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_crcav_flag WEB_FIN_MADCR.c_cav_flag%TYPE;
    v_dramt      WEB_FIN_MADCR.n_amt%TYPE;
    v_cramt      WEB_FIN_MADCR.n_amt%TYPE;
    v_amt        WEB_FIN_MADCR.n_amt%TYPE;
    v_vou_memo   VARCHAR(200);
    vTmpVouNo    VARCHAR(30);
    v_crt_tm     WEB_FIN_MADCR.t_crt_tm%TYPE;

    v_salegrp_cde WEB_FIN_MADCR.c_salegrp_cde%TYPE;
    v_bsns_typ    WEB_FIN_MADCR.c_bsns_typ%TYPE;
    v_cha_mrk     WEB_FIN_MADCR.c_cha_mrk%TYPE;
    v_con_dpt_cde WEB_FIN_PRM_DUE.c_con_dpt_cde%TYPE;
    --????????????  ORACLE?????????
    v_company_cde    WEB_ORG_DPT.c_company_cde%TYPE;
    v_department_cde WEB_ORG_DPT.c_department_cde%TYPE;
    v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;

    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_makevou     VARCHAR2(1);
    v_check_flag  WEB_FIN_DCR.c_check_flag%TYPE;
    v_voucher_no  WEB_FIN_MADCR.c_voucher_no%TYPE;

    v_sbjt_memo   web_fin_dcr_intf.c_sbjt_memo%TYPE;
    v_period_name web_fin_dcr_intf.c_period_name%TYPE;

    v_succsflag INT;
    v_ri_com    web_fin_dcr_intf.c_ri_com%TYPE;
    v_total_amt WEB_FIN_MADCR.n_total_amt%TYPE;
    v_ncompany  INT;
    v_nri       INT;

    v_voucompany_cde    WEB_FIN_MADCR.c_company_cde%TYPE;
    v_voudepartment_cde WEB_FIN_MADCR.c_department_cde%TYPE;
    v_voudpt_cde        WEB_FIN_MADCR.c_dpt_cde%TYPE;
    v_voudptacc_cde     WEB_FIN_MADCR.c_dpt_cde%TYPE;

    CURSOR cur_ifgDetailma IS
      SELECT decode(c_check_flag, '4', '4', '2'),
             c_dpt_cde,
             c_kind_no,
             c_cur_no,
             SUM(n_amt) / 2,
             TRUNC(t_crt_tm),
             c_servicetype_no
        FROM WEB_FIN_MADCR
       WHERE c_vou_no IS NULL
         AND t_crt_tm < TRUNC(SYSDATE)
         and t_crt_tm > sysdate - 30
         AND c_ri_com IS NULL
         AND c_servicetype_no IN ('1127', '1148', '1133', '1135', '1152',
              '1129', '1131', '1429', '1431', '1101')
       GROUP BY decode(c_check_flag, '4', '4', '2'),
                c_dpt_cde,
                c_kind_no,
                c_cur_no,
                TRUNC(t_crt_tm),
                c_servicetype_no;

    CURSOR cur_ifriDetailma IS
      SELECT decode(c_check_flag, '4', '4', '2'),
             c_dpt_cde,
             c_kind_no,
             c_cur_no,
             SUM(n_amt) / 2,
             TRUNC(t_crt_tm),
             c_servicetype_no,
             c_ri_com
        FROM WEB_FIN_MADCR
       WHERE c_vou_no IS NULL
         AND t_crt_tm < TRUNC(SYSDATE)
         and t_crt_tm > sysdate - 30
         AND c_ri_com IS NOT NULL
         AND c_servicetype_no IN ('1127', '1148', '1133', '1135', '1152',
              '1129', '1131', '1429', '1431', '1101')
       GROUP BY decode(c_check_flag, '4', '4', '2'),
                c_dpt_cde,
                c_kind_no,
                c_cur_no,
                TRUNC(t_crt_tm),
                c_servicetype_no,
                c_ri_com;

    CURSOR cur_updpregather IS
      SELECT c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no
        FROM web_fin_madcr_intf
       WHERE c_vou_no IS NULL
         and t_crt_tm > sysdate - 30
         AND c_servicetype_no IN ('1127', '1148', '1133', '1135', '1152',
              '1129', '1131', '1429', '1431', '1101')
       GROUP BY c_company_cde, c_servicetype_no, TRUNC(t_crt_tm), c_cur_no;

  BEGIN

    OPEN cur_ifgDetailma;
    LOOP
      FETCH cur_ifgDetailma
        INTO v_check_flag, v_dpt_cde, v_prod_no, v_cur_no, v_amt, v_crt_tm, v_servicetype_no;
      EXIT WHEN cur_ifgDetailma%NOTFOUND;

      --?????
      --Dz_Proc.get_FIN_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
      --??????????
      --???????/????/????
      --select  TO_CHAR(123,'0000') from dual;
      --?????7??+?????2??+?/??4??+??????4?)
      --????
      --??????,???????/????/????
      SELECT COUNT(*)
        INTO v_ncompany
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      /*
      ?????? 1000
        ??????  112201
        ??????  410101

      ?????? 1123
        ????????-?????? 122203
        ???????\??  410205

      ?????????? 1001
        ????????????  212101
        ??????  112201

      ?????? 1009
        ??????????? 440101
        ??????  215001

      ????? 1011
        ??????????  440102
        ??????????? 215001

      ?????????? 1010
        ??????  440101
        ??????  113101

      ??????? 1007
        ??????? 443101
        ??????? 211101

      5.1???????
      5.1?????
      ?1??????????????????
      ?????????????-?????? 122401   1127 ???????????
        ???????????-IBNR 122402   1148 ????????????????
      ???????????-?????? 421101
        ?????????- IBNR 421102


      ?2??????????????????
      ???????????-?????? 450101   1133 ?????????
        ?????????-IBNR 450102     1135 ????????????
        ?????????-???? 450103   1152 ?????????
      ?????????-???????????????  216101
        ???????-IBNR  216102
        ???????-????  216103


      122401,???????????/???????????
      122402,???????????/IBNR
      122403,???????????/????

      450101,?????????/???
      450102,?????????/IBNR
      450103,?????????/????

      421101,?????????/??????
      421102,?????????/??????
      421103,?????????/????

      216101,???????/???
      216102,???????/IBNR
      216103,???????/???????

        v_drsbjt_no:='119113';
        v_crsbjt_no:='214614';
        v_vou_memo:='?????????';
        v_servicetype_no:='5000';
      */

      v_drcav_flag := '?';
      v_crcav_flag := '?';
      v_dramt      := v_amt;
      v_cramt      := v_amt;
      v_makevou    := 'Y';

      IF v_servicetype_no = '1000' THEN
        --IF v_vou_memo='??????' THEN
        v_vou_memo  := '??????';
        v_drsbjt_no := '112201';
        v_sbjt_no   := '410101';
      ELSIF v_servicetype_no = '5000' THEN
        --IF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '119113';
        v_sbjt_no   := '214614';

      ELSIF v_servicetype_no = '1123' THEN
        --ELSIF v_vou_memo='??????' THEN
        v_drsbjt_no := '122203';
        v_sbjt_no   := '410205';
        v_vou_memo  := '??????';
      ELSIF v_servicetype_no = '1001' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '212101';
        v_sbjt_no   := '112201';
      ELSIF v_servicetype_no = '1009' THEN
        --ELSIF v_vou_memo='??????' THEN
        v_vou_memo  := '??????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '215001';
      ELSIF v_servicetype_no = '1011' THEN
        --ELSIF v_vou_memo='?????' THEN
        v_vou_memo  := '?????';
        v_drsbjt_no := '440102';
        v_sbjt_no   := '215002';
      ELSIF v_servicetype_no = '1010' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113101';
      ELSIF v_servicetype_no = '1150' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113102';
      ELSIF v_servicetype_no = '1151' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113103';
      ELSIF v_servicetype_no = '1149' THEN
        v_vou_memo  := '???????????????';
        v_drsbjt_no := '440101';
        v_sbjt_no   := '113104';
      ELSIF v_servicetype_no = '1007' THEN
        --ELSIF v_vou_memo='???????' THEN
        v_vou_memo  := '???????';
        v_drsbjt_no := '443101';
        v_sbjt_no   := '211101';
      ELSIF v_servicetype_no = '1101' THEN
        --ELSIF v_vou_memo='????' THEN
        v_vou_memo  := '????';
        v_drsbjt_no := '446106';
        v_sbjt_no   := '214401';

      ELSIF v_servicetype_no = '1127' THEN
        --ELSIF v_vou_memo='???????????' THEN
        v_vou_memo  := '???????????';
        v_drsbjt_no := '122401';
        v_sbjt_no   := '421101';
      ELSIF v_servicetype_no = '1148' THEN
        --ELSIF v_vou_memo='????????????????' THEN
        v_vou_memo  := '????????????????';
        v_drsbjt_no := '122402';
        v_sbjt_no   := '421102';
      ELSIF v_servicetype_no = '1133' THEN
        --ELSIF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '450101';
        v_sbjt_no   := '216101';
      ELSIF v_servicetype_no = '1135' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '450102';
        v_sbjt_no   := '216102';
      ELSIF v_servicetype_no = '1152' THEN
        --ELSIF v_vou_memo='?????????' THEN
        v_vou_memo  := '?????????';
        v_drsbjt_no := '450103';
        v_sbjt_no   := '216103';

      ELSIF v_servicetype_no = '1129' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '122301';
        v_sbjt_no   := '450201';
      ELSIF v_servicetype_no = '1131' THEN
        --ELSIF v_vou_memo='??????????' THEN
        v_vou_memo  := '??????????';
        v_drsbjt_no := '450201';
        v_sbjt_no   := '216201';
      ELSIF v_servicetype_no = '1429' THEN
        --ELSIF v_vou_memo='????????????' THEN
        v_vou_memo  := '????????????';
        v_drsbjt_no := '122302';
        v_sbjt_no   := '450202';
      ELSIF v_servicetype_no = '1431' THEN
        --ELSIF v_vou_memo='??????????????' THEN
        v_vou_memo  := '??????????????';
        v_drsbjt_no := '450202';
        v_sbjt_no   := '216202';
      ELSE
        v_makevou := 'N';
      END IF;

      IF v_ncompany = 0 THEN
        v_err_content := 'proc:[pregather1],??????[' || v_dpt_cde ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);

      END IF;

      IF v_makevou = 'Y' AND v_ncompany > 0 THEN
        SELECT c_company_cde, c_dptacc_cde, c_department_cde
          INTO v_company_cde, v_dptacc_cde, v_department_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = trim(v_dpt_cde);

        SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;

        v_salegrp_cde := '000';
        v_bsns_typ    := '0';
        v_cha_mrk     := '0';
        --v_check_flag:='2';
        v_crt_tm := TRUNC(v_crt_tm);
        BEGIN
          Dz_Proc.get_FIN_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

          INSERT INTO web_fin_madcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             n_amt,
             c_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_dpt_cde,
             c_prod_no,
             c_vou_memo,
             c_send_flag,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_con_dpt_cde,
             c_check_flag,
             c_servicetype_no)
          VALUES
            (vTmpVouNo,
             '1',
             v_drcav_flag,
             v_drsbjt_no,
             v_dramt,
             v_cur_no,
             TRUNC(v_crt_tm),
             v_dptacc_cde,
             v_dpt_cde,
             v_prod_no,
             v_vou_memo,
             '0',
             v_salegrp_cde,
             v_bsns_typ,
             v_cha_mrk,
             v_con_dpt_cde,
             v_check_flag,
             v_servicetype_no);

          INSERT INTO web_fin_madcr_intf
            (c_seq_no,
             c_item_no,
             c_cav_flag,
             c_sbjt_no,
             n_amt,
             c_cur_no,
             t_crt_tm,
             c_dptacc_no,
             c_dpt_cde,
             c_prod_no,
             c_vou_memo,
             c_send_flag,
             c_salegrp_cde,
             c_bsns_typ,
             c_cha_mrk,
             c_con_dpt_cde,
             c_check_flag,
             c_servicetype_no)
          VALUES
            (vTmpVouNo,
             '2',
             v_crcav_flag,
             v_sbjt_no,
             v_cramt,
             v_cur_no,
             TRUNC(v_crt_tm),
             v_dptacc_cde,
             v_dpt_cde,
             v_prod_no,
             v_vou_memo,
             '0',
             v_salegrp_cde,
             v_bsns_typ,
             v_cha_mrk,
             v_con_dpt_cde,
             v_check_flag,
             v_servicetype_no);

          /*??????*/

          UPDATE WEB_FIN_MADCR
             SET c_vou_no = vTmpVouNo
           WHERE c_dpt_cde = v_dpt_cde
             AND c_kind_no = v_prod_no
             AND c_cur_no = v_cur_no
             AND t_crt_tm >=
                 TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                         'YYYY-MM-DD HH24:MI:SS')
             AND t_crt_tm <=
                 TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS')
             AND c_servicetype_no = v_servicetype_no
             AND c_vou_no IS NULL
             AND c_ri_com IS NULL
             AND c_rcpt_no IS NOT NULL;

          --????????????
          SELECT SUM(n_amt) / 2
            INTO v_total_amt
            FROM web_fin_madcr_intf
           WHERE c_seq_no = vTmpVouNo;

          UPDATE WEB_FIN_MADCR
             SET c_company_cde = v_company_cde,
                 c_period_name = v_period_name,
                 n_total_amt   = v_total_amt
           WHERE c_vou_no = vTmpVouNo;

          UPDATE web_fin_madcr_intf
             SET c_company_cde    = v_company_cde,
                 c_department_cde = v_department_cde,
                 c_period_name    = v_period_name,
                 t_end_tm         = SYSDATE,
                 n_total_amt      = v_total_amt,
                 c_cur_no         = DECODE(c_cur_no,
                                           '01',
                                           'CNY',
                                           '02',
                                           'HKD',
                                           '03',
                                           'USD',
                                           '12',
                                           'EUR',
                                           '13',
                                           'EUR',
                                           '05',
                                           'JPY',
                                           c_cur_no),
                 c_dpt_cde        = DECODE(c_dpt_cde,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_dpt_cde),
                 c_prod_no        = DECODE(c_prod_no,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_prod_no),
                 c_bsns_typ       = DECODE(c_bsns_typ,
                                           NULL,
                                           '0',
                                           ' ',
                                           '0',
                                           c_bsns_typ)
           WHERE c_seq_no = vTmpVouNo;

        END;
      END IF;
      commit;

    END LOOP;
    CLOSE cur_ifgDetailma;

    OPEN cur_ifriDetailma;
    LOOP
      FETCH cur_ifriDetailma
        INTO v_check_flag, v_dpt_cde, v_prod_no, v_cur_no, v_amt, v_crt_tm, v_servicetype_no, v_ri_com;
      EXIT WHEN cur_ifriDetailma%NOTFOUND;

      --?????
      --Dz_Proc.get_FIN_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);
      --??????????
      --???????/????/????
      --select  TO_CHAR(123,'0000') from dual;
      --?????7??+?????2??+?/??4??+??????4?)
      --????
      --??????,???????/????/????

      SELECT COUNT(*)
        INTO v_ncompany
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = trim(v_dpt_cde);

      SELECT COUNT(*)
        INTO v_nri
        FROM WEB_BAS_FIN_RI
       WHERE c_ri_com = v_ri_com;

      IF v_nri > 0 AND v_ncompany > 0 THEN
        SELECT c_company_cde, c_dptacc_cde, c_department_cde
          INTO v_company_cde, v_dptacc_cde, v_department_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = trim(v_dpt_cde);

        SELECT c_finri_com
          INTO v_sbjt_memo
          FROM WEB_BAS_FIN_RI
         WHERE c_ri_com = v_ri_com;

        SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;

        v_drcav_flag := '?';
        v_crcav_flag := '?';
        v_dramt      := v_amt;
        v_cramt      := v_amt;
        v_makevou    := 'Y';

        IF v_servicetype_no = '1116' THEN
          --ELSIF v_vou_memo='??????' THEN
          v_vou_memo  := '??????';
          v_drsbjt_no := '442101';
          v_sbjt_no   := '211301';
        ELSIF v_servicetype_no = '1117' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122201';
          v_sbjt_no   := '420301';

        ELSIF v_servicetype_no = '1118' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122202';
          v_sbjt_no   := '420101';

          --ELSIF v_servicetype_no='1119' THEN
          --ELSIF v_vou_memo='????????' THEN

        ELSIF v_servicetype_no = '1121' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122204';
          v_sbjt_no   := '213101';

        ELSIF v_servicetype_no = '1122' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '446104';
          v_sbjt_no   := '211304';

        ELSIF v_servicetype_no = '3000' THEN
          --ELSIF v_vou_memo='????????' THEN
          v_vou_memo  := '????????';
          v_drsbjt_no := '211301';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '3001' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '211304';
          v_sbjt_no   := '119603';

        ELSIF v_servicetype_no = '4000' THEN
          --ELSIF v_vou_memo='????????' THEN
          v_vou_memo  := '????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '211301';
        ELSIF v_servicetype_no = '4001' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '211304';

        ELSIF v_servicetype_no = '3002' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122201';
        ELSIF v_servicetype_no = '3003' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122202';
        ELSIF v_servicetype_no = '3004' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '119603';
          v_sbjt_no   := '122204';

        ELSIF v_servicetype_no = '4002' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122201';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '4003' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '122202';
          v_sbjt_no   := '119603';
        ELSIF v_servicetype_no = '4004' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122204';
          v_sbjt_no   := '119603';

          /*

            ?????????????????
              ??????????????????211301
              ???????\???????? 119603?

            ?????????????????
              ???????\????????? 119603
              ?????????????????211301

            ------------------------------------------------------
            ??????????????????????????
            ???????\???????????? 119603
            ?????????????122201  ?122202

            ??????????????????????????
            ?????????????122201
                 ???????\?????????119603



            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3000','?????????????????');

            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3001','?????????????????');

            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3002','??????????????????????????');

            INSERT INTO WEB_BAS_FIN_SERVICETYPE(c_no,c_name)
            VALUES('3003','??????????????????????????');

            3000,?????????????????
            3001,?????????????????
            3002,??????????????????????????
            3003,??????????????????????????
          */

        ELSIF v_servicetype_no = '1127' THEN
          --ELSIF v_vou_memo='???????????' THEN
          v_vou_memo  := '???????????';
          v_drsbjt_no := '122401';
          v_sbjt_no   := '421101';
        ELSIF v_servicetype_no = '1148' THEN
          --ELSIF v_vou_memo='????????????????' THEN
          v_vou_memo  := '????????????????';
          v_drsbjt_no := '122402';
          v_sbjt_no   := '421102';
        ELSIF v_servicetype_no = '1133' THEN
          --ELSIF v_vou_memo='?????????' THEN
          v_vou_memo  := '?????????';
          v_drsbjt_no := '450101';
          v_sbjt_no   := '216101';
        ELSIF v_servicetype_no = '1135' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '450102';
          v_sbjt_no   := '216102';
        ELSIF v_servicetype_no = '1152' THEN
          --ELSIF v_vou_memo='?????????' THEN
          v_vou_memo  := '?????????';
          v_drsbjt_no := '450103';
          v_sbjt_no   := '421103';

        ELSIF v_servicetype_no = '1129' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '122301';
          v_sbjt_no   := '450201';
        ELSIF v_servicetype_no = '1131' THEN
          --ELSIF v_vou_memo='??????????' THEN
          v_vou_memo  := '??????????';
          v_drsbjt_no := '450201';
          v_sbjt_no   := '216201';
        ELSIF v_servicetype_no = '1429' THEN
          --ELSIF v_vou_memo='????????????' THEN
          v_vou_memo  := '????????????';
          v_drsbjt_no := '122302';
          v_sbjt_no   := '450202';
        ELSIF v_servicetype_no = '1431' THEN
          --ELSIF v_vou_memo='??????????????' THEN
          v_vou_memo  := '??????????????';
          v_drsbjt_no := '450202';
          v_sbjt_no   := '216202';
          ---------------------------------------------------------
        ELSE
          v_makevou := 'N';
        END IF;

        IF v_makevou = 'Y' THEN
          v_salegrp_cde := '000';
          v_bsns_typ    := '0';
          v_cha_mrk     := '0';
          --v_check_flag:='2';
          v_crt_tm := TRUNC(v_crt_tm);

          BEGIN

            Dz_Proc.get_FIN_no(vTmpVouNo, v_dpt_cde, '5', dz_proc.g_pttype);

            INSERT INTO web_fin_madcr_intf
              (c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_prod_no,
               c_vou_memo,
               c_send_flag,
               c_salegrp_cde,
               c_bsns_typ,
               c_cha_mrk,
               c_con_dpt_cde,
               c_check_flag,
               c_servicetype_no,
               c_sbjt_memo,
               c_ri_com)
            VALUES
              (vTmpVouNo,
               '1',
               v_drcav_flag,
               v_drsbjt_no,
               v_dramt,
               v_cur_no,
               TRUNC(v_crt_tm),
               v_dptacc_cde,
               v_dpt_cde,
               v_prod_no,
               v_vou_memo,
               '0',
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_con_dpt_cde,
               v_check_flag,
               v_servicetype_no,
               v_sbjt_memo,
               v_ri_com);

            INSERT INTO web_fin_madcr_intf
              (c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_prod_no,
               c_vou_memo,
               c_send_flag,
               c_salegrp_cde,
               c_bsns_typ,
               c_cha_mrk,
               c_con_dpt_cde,
               c_check_flag,
               c_servicetype_no,
               c_sbjt_memo,
               c_ri_com)
            VALUES
              (vTmpVouNo,
               '2',
               v_crcav_flag,
               v_sbjt_no,
               v_cramt,
               v_cur_no,
               TRUNC(v_crt_tm),
               v_dptacc_cde,
               v_dpt_cde,
               v_prod_no,
               v_vou_memo,
               '0',
               v_salegrp_cde,
               v_bsns_typ,
               v_cha_mrk,
               v_con_dpt_cde,
               v_check_flag,
               v_servicetype_no,
               v_sbjt_memo,
               v_ri_com);

            /*??????*/

            UPDATE WEB_FIN_MADCR
               SET c_vou_no = vTmpVouNo
             WHERE 1 = 1
               AND c_dpt_cde = v_dpt_cde
               AND c_kind_no = v_prod_no
               AND c_cur_no = v_cur_no
               AND t_crt_tm >=
                   TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                           'YYYY-MM-DD HH24:MI:SS')
               AND t_crt_tm <=
                   TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS')
               AND c_servicetype_no = v_servicetype_no
               AND c_ri_com = v_ri_com
               AND c_vou_no IS NULL
               AND c_rcpt_no IS NOT NULL;

            SELECT SUM(n_amt) / 2
              INTO v_total_amt
              FROM web_fin_madcr_intf
             WHERE c_seq_no = vTmpVouNo;

            UPDATE WEB_FIN_MADCR
               SET c_company_cde    = v_company_cde,
                   c_period_name    = v_period_name,
                   c_department_cde = v_department_cde,
                   n_total_amt      = v_total_amt
             WHERE c_vou_no = vTmpVouNo;

            UPDATE web_fin_madcr_intf
               SET c_company_cde    = v_company_cde,
                   c_period_name    = v_period_name,
                   t_end_tm         = SYSDATE,
                   c_department_cde = v_department_cde,
                   n_total_amt      = v_total_amt,
                   c_cur_no         = DECODE(c_cur_no,
                                             '01',
                                             'CNY',
                                             '02',
                                             'HKD',
                                             '03',
                                             'USD',
                                             '12',
                                             'EUR',
                                             '13',
                                             'EUR',
                                             '05',
                                             'JPY',
                                             c_cur_no),
                   c_dpt_cde        = DECODE(c_dpt_cde,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_dpt_cde),
                   c_prod_no        = DECODE(c_prod_no,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_prod_no),
                   c_bsns_typ       = DECODE(c_bsns_typ,
                                             NULL,
                                             '0',
                                             ' ',
                                             '0',
                                             c_bsns_typ)
             WHERE c_seq_no = vTmpVouNo;
            commit;

          END;
        END IF;
      ELSE
        v_err_content := 'proc:[pregather2],??????[' || v_dpt_cde ||
                         v_ri_com || v_vou_memo || v_sbjt_no ||
                         TO_CHAR(v_cramt) || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || v_dpt_cde ||
                         v_prod_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
      END IF; --v_ncompany||ri=0
      COMMIT;
    END LOOP;
    CLOSE cur_ifriDetailma;

    --????( ???????)
    OPEN cur_updpregather;
    LOOP
      FETCH cur_updpregather
        INTO v_company_cde, v_servicetype_no, v_crt_tm, v_cur_no;
      EXIT WHEN cur_updpregather%NOTFOUND;

      SELECT TO_CHAR(v_crt_tm, 'YYYY-MM') INTO v_period_name FROM dual;
      v_voucompany_cde := v_company_cde;

      IF v_servicetype_no IN ('4000', '4001', '4002', '4003', '4004') THEN
        v_voucompany_cde := '1000100';
      END IF;

      IF v_servicetype_no IN
         ('1116', '1117', '1118', '1119', '1121', '1122', '3000', '3001',
          '3002', '3003', '3004', '4000', '4001', '4002', '4003', '4004') THEN
        --'??????''??????????' ?????????? ???????? ???????????
        Dz_Proc.get_fin_rivoucode(v_voucher_no,
                                  v_period_name,
                                  v_voucompany_cde,
                                  dz_proc.g_pttype);
      ELSIF v_servicetype_no IN ('1127', '1148', '1133', '1135', '1152',
             '1129', '1131', '1429', '1431', '1101') THEN
        --??????????? ???????????????? ????????? ???????????? ???????????? ?????????? ??????????????????,????????????
        Dz_Proc.get_FIN_prevoucode(v_voucher_no,
                                   v_period_name,
                                   v_voucompany_cde,
                                   dz_proc.g_pttype);
      ELSIF v_servicetype_no IS NULL THEN
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      ELSE
        Dz_Proc.get_FIN_voucode(v_voucher_no,
                                v_period_name,
                                v_voucompany_cde,
                                dz_proc.g_pttype);
      END IF;

      /*
        3000,????????
        3001,???????????
        4000,????????
        4001,???????????

        3002,??????????
        3003,??????????
        3004,???????????

        4002,??????????
        4003,??????????
        4004,???????????
      */
      v_voucompany_cde    := '1000100';
      v_voudepartment_cde := '2006';
      v_voudpt_cde        := '00000019';
      v_voudptacc_cde     := '00000019';

      IF v_servicetype_no IN ('3000', '3001') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4000', '4001') THEN

        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('3002', '3003', '3004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no    = v_voucher_no,
               t_end_tm    = SYSDATE,
               c_sbjt_memo = DECODE(c_cav_flag,
                                    '?',
                                    '02' || v_voucompany_cde,
                                    c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no = v_voucher_no,
               t_end_tm     = SYSDATE,
               c_sbjt_memo  = DECODE(c_cav_flag,
                                     '?',
                                     '02' || v_voucompany_cde,
                                     c_sbjt_memo)
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      ELSIF v_servicetype_no IN ('4002', '4003', '4004') THEN
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no      = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no  = v_voucher_no,
               t_end_tm      = SYSDATE,
               c_sbjt_memo   = DECODE(c_cav_flag,
                                      '?',
                                      '02' || v_company_cde,
                                      c_sbjt_memo),
               c_company_cde = v_voucompany_cde,
               c_dptacc_no   = v_voudptacc_cde
        --c_dpt_cde=v_voudepartment_cde,c_company_cde=v_voucompany_cde,c_dptacc_no=v_voudptacc_cde
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;

      ELSE
        UPDATE /*+  index(web_fin_madcr_intf,web_fin_madcr_intf_CRT)*/ web_fin_madcr_intf
           SET c_vou_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = v_cur_no
           AND c_vou_no IS NULL;

        UPDATE WEB_FIN_MADCR
           SET c_voucher_no = v_voucher_no, t_end_tm = SYSDATE
         WHERE c_company_cde = v_company_cde
           AND c_servicetype_no = v_servicetype_no
           AND t_crt_tm >=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS')
           AND t_crt_tm <=
               TO_DATE(TO_CHAR(v_crt_tm, 'yyyy-mm-dd') || ' 23:59:59',
                       'YYYY-MM-DD HH24:MI:SS')
           AND c_cur_no = DECODE(v_cur_no,
                                 'CNY',
                                 '01',
                                 'HKD',
                                 '02',
                                 'USD',
                                 '03',
                                 'EUR',
                                 '13',
                                 'JPY',
                                 '05',
                                 v_cur_no)
           AND c_voucher_no IS NULL;
      END IF;

      --?????????????
      UPDATE web_fin_madcr_intf
         SET c_item_no = '0'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '1';

      UPDATE WEB_FIN_MADCR
         SET c_item_no = '0'
       WHERE c_voucher_no = v_voucher_no
         AND c_item_no = '1';

      UPDATE web_fin_madcr_intf
         SET c_item_no = '1'
       WHERE c_vou_no = v_voucher_no
         AND c_item_no = '0'
         AND ROWNUM < 2;

      UPDATE WEB_FIN_MADCR
         SET c_item_no = '1'
       WHERE c_voucher_no = v_voucher_no
         AND c_item_no = '0'
         AND ROWNUM < 2;

      --?????????????????
      SELECT SUM(n_total_amt) / 2
        INTO v_total_amt
        FROM web_fin_madcr_intf
       WHERE c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET n_total_amt = v_total_amt
       WHERE c_vou_no = v_voucher_no;

      UPDATE WEB_FIN_MADCR
         SET n_total_amt = v_total_amt
       WHERE c_voucher_no = v_voucher_no;

      --??????
      UPDATE web_fin_madcr_intf
         SET c_department_cde = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '1196%' OR
             c_sbjt_no LIKE '2131%' OR c_sbjt_no LIKE '2113%' OR
             c_sbjt_no LIKE '1224%' OR c_sbjt_no LIKE '1223%' OR
             c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET c_prod_no = '0', c_bsns_typ = '0'
       WHERE (c_sbjt_no LIKE '214401%' OR c_sbjt_no LIKE '119603%' OR
             c_sbjt_no LIKE '119113%' OR c_sbjt_no = '214614')
         AND c_vou_no = v_voucher_no;

      Auto_Confirmed.ValidityCheckMaVou(v_voucher_no, v_succsflag);
      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[pregather],??????????[' ||
                         TO_CHAR(v_succsflag) || v_company_cde ||
                         v_servicetype_no || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      ELSE
        COMMIT;
      END IF;

    END LOOP;
    CLOSE cur_updpregather;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || vTmpVouNo || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[exception pregather],??????[' ||
                         vTmpVouNo || v_vou_memo || v_sbjt_no ||
                         TO_CHAR(v_cramt) || v_cur_no ||
                         TO_CHAR(v_crt_tm, 'YYYY-MM-DD') || v_dpt_cde ||
                         v_prod_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;

  END;

  --7.????
  PROCEDURE monthlycloing(v_dptacc_cde IN WEB_ORG_DPT.c_dpt_cde%TYPE,
                          v_crt_cde    IN WEB_FIN_MONTHLYCLOSING.c_upd_cde%TYPE,
                          v_succsflag  IN OUT NUMBER) IS

    v_tmp_cnt         INT;
    v_period_name     WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE;
    v_end_time        WEB_BAS_FIN_ACCT_PERIOD.t_BGN_TM%TYPE;
    v_otherdptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;

    CURSOR cur_dptacc IS
      SELECT DISTINCT c_dptacc_cde
        FROM WEB_ORG_DPT
       WHERE c_dptacc_cde <> '?'
         AND c_dptacc_cde IS NOT NULL;

  BEGIN
    /*
    1.??
    1.1.????????????????????????????????????????
    1.2.???????????????????
    1.3 ??????????????????????

    2.??????????????????????????

    3.?????????????????????
    4.???????????????????????????WEB_BAS_FIN_ERRORLOG????

    v_succsflag:
      0 ??
      -1  ?????????????????
      -2  ??????????????????????
      -3  ????????????????
      -4  ????????,???????????
      -5  ?????????????????????????

      -9  ????
    */

    v_succsflag := 0;

    --1.??????????????????????
    SELECT COUNT(*)
      INTO v_tmp_cnt
      FROM WEB_FIN_MONTHLYCLOSING
     WHERE c_dptacc_cde = v_dptacc_cde
       AND c_closing_flag = '1'; --??

    IF v_tmp_cnt = 0 THEN
      --????????? 00000019
      v_succsflag := -4;
      RETURN;
    ELSE
      SELECT c_period_name
        INTO v_period_name
        FROM WEB_FIN_MONTHLYCLOSING
       WHERE c_dptacc_cde = v_dptacc_cde
         AND c_closing_flag = '1'; --??
    END IF;

    SELECT TRUNC(t_end_tm)
      INTO v_end_time
      FROM WEB_BAS_FIN_ACCT_PERIOD
     WHERE c_period_name = v_period_name;

    v_end_time := TRUNC(v_end_time);
    IF v_end_time > TRUNC(SYSDATE) THEN
      v_succsflag := -1;
      RETURN;
    END IF;

    --2.?????????????????????????????????????????
    IF v_dptacc_cde = '00000019' THEN
      --?????
      SELECT COUNT(*)
        INTO v_tmp_cnt
        FROM WEB_FIN_CAV_BILL
       WHERE c_check_flag IN ('0', '1')
         AND T_CAV_TM <=
             TO_DATE(TO_CHAR(v_end_time, 'yyyy-mm-dd') || ' 23:59:59',
                     'YYYY-MM-DD HH24:MI:SS');
    ELSE
      SELECT COUNT(*)
        INTO v_tmp_cnt
        FROM WEB_FIN_CAV_BILL
       WHERE c_check_flag IN ('0', '1')
         AND c_dpt_cde = v_dptacc_cde
         AND T_CAV_TM <=
             TO_DATE(TO_CHAR(v_end_time, 'yyyy-mm-dd') || ' 23:59:59',
                     'YYYY-MM-DD HH24:MI:SS');
    END IF;

    IF v_tmp_cnt > 0 THEN
      v_succsflag := -2;
      RETURN;
    END IF;

    IF v_end_time >= TRUNC(SYSDATE) THEN
      v_succsflag := -1;
      RETURN;
    END IF;

    /*
      IF v_dptacc_cde='00000019' THEN --?????
        select COUNT(*)
        INTO  v_tmp_cnt
          from v_fin_cavmoney
          where  c_rp_type <200
          and C_BAL_TYP='002001'
          and c_check_flag ='2'
          and    c_moneycheck_flag<>'2'
          AND T_RP_TM <=to_date(TO_CHAR(v_end_time,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');

      ELSE
        select COUNT(*)
        INTO  v_tmp_cnt
          from v_fin_cavmoney
          where  c_rp_type <200
          and C_BAL_TYP='002001'
          and c_check_flag ='2'
          and    c_moneycheck_flag<>'2'
          AND c_dpt_cde =v_dptacc_cde
          AND T_RP_TM <=to_date(TO_CHAR(v_end_time,'yyyy-mm-dd')||' 23:59:59','YYYY-MM-DD HH24:MI:SS');

      END IF;

      IF v_tmp_cnt>0 THEN
        v_succsflag  := -5;
        RETURN;
      END IF;
    */

    ---3 ????????????????????

    SELECT COUNT(*)
      INTO v_tmp_cnt
      FROM WEB_FIN_MADCR_STATUS
     WHERE t_crt_tm >=
           TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd') || ' 00:00:00',
                   'YYYY-MM-DD HH24:MI:SS')
       AND t_crt_tm <=
           TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd') || ' 23:59:59',
                   'YYYY-MM-DD HH24:MI:SS');

    IF v_tmp_cnt = 0 THEN
      --???????
      v_succsflag := -3;
      RETURN;
    END IF;

    --4.????
    /*
    IF v_dptacc_cde='00000019' THEN
      UPDATE WEB_ORG_DPT
        SET c_switch_flag='0'  --??
        WHERE c_switch_flag<>'0';

         OPEN cur_dptacc;
          LOOP
        FETCH cur_dptacc  INTO v_otherdptacc_cde;
        EXIT WHEN cur_dptacc%NOTFOUND;
        BEGIN
          UPDATE WEB_ORG_DPT
            SET c_switch_flag='0' --??
            WHERE c_dptacc_cde=v_otherdptacc_cde AND c_switch_flag<>'0';

          UPDATE WEB_FIN_MONTHLYCLOSING
            SET c_closing_flag='2'  --??
            WHERE  c_dptacc_cde=v_otherdptacc_cde AND c_closing_flag<>'2' ;

          --????
          v_period_name:=TO_CHAR(ADD_MONTHS(v_end_time,1),'YYYY-MM');
          INSERT INTO WEB_FIN_MONTHLYCLOSING(c_period_name,c_dptacc_cde)
            VALUES(v_period_name,v_otherdptacc_cde);
        END;
          END LOOP;

          CLOSE cur_dptacc;

    ELSE
      UPDATE WEB_ORG_DPT
        SET c_switch_flag='0' --??
        WHERE c_dptacc_cde=v_dptacc_cde AND c_switch_flag<>'0';

      UPDATE WEB_FIN_MONTHLYCLOSING
        SET c_closing_flag='2'  --??
        WHERE  c_dptacc_cde=v_dptacc_cde AND c_closing_flag<>'2' ;

      --????
      INSERT INTO WEB_FIN_MONTHLYCLOSING(c_period_name,c_dptacc_cde)
        VALUES(TO_CHAR(ADD_MONTHS(v_end_time,1),'YYYY-MM'),v_dptacc_cde);
    END IF;
    */

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        RAISE;
        v_succsflag := -9;

        --dbms_output.put_line('exception'||TO_CHAR(i)||'*'||SRcptNo||SQLERRM);
        IF SQLCODE < 0 THEN
          v_succsflag := SQLCODE;
        ELSE
          v_succsflag := -SQLCODE;
        END IF;
      END;
  END;

  --7.????? Validity check
  PROCEDURE ValidityCheck IS

    v_tmp_cnt         INT;
    v_period_name     WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE;
    v_end_time        WEB_BAS_FIN_ACCT_PERIOD.T_BGN_TM%TYPE;
    v_otherdptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_err_content     WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_tmpflag_cnt     INT;

    CURSOR cur_dptacc IS
      SELECT DISTINCT c_dptacc_cde
        FROM WEB_ORG_DPT
       WHERE c_dptacc_cde <> '?'
         AND c_dptacc_cde IS NOT NULL;

    /*

    ??????
    -1??????????????????
    -2???????????????????
    -3??????????
    -4??????????

    -9?????
     0. ??
    */

  BEGIN
    SELECT COUNT(*)
      INTO v_tmp_cnt
      FROM WEB_BAS_FIN_ACCT_PERIOD
     WHERE T_bgn_tm <= TRUNC(sysdate, 'MM') + 15
       AND T_end_tm >= TRUNC(sysdate, 'MM');

    --1(?????????????????)
    IF v_tmp_cnt = 0 THEN
      v_period_name := TO_CHAR(TRUNC(SYSDATE, 'MM'), 'YYYY-MM');
      INSERT INTO WEB_BAS_FIN_ACCT_PERIOD
        (C_PERIOD_NAME, T_BGN_TM, T_END_TM)
      VALUES
        (v_period_name,
         TRUNC(SYSDATE, 'MM'),
         TRUNC(ADD_MONTHS(SYSDATE, 1), 'MM') - 1);
    END IF;

    --2???????????????????
    OPEN cur_dptacc;
    LOOP
      FETCH cur_dptacc
        INTO v_otherdptacc_cde;
      EXIT WHEN cur_dptacc%NOTFOUND;
      BEGIN
        SELECT COUNT(*)
          INTO v_tmp_cnt
          FROM WEB_FIN_MONTHLYCLOSING
         WHERE c_dptacc_cde = v_otherdptacc_cde
           AND c_closing_flag = '1'; --??

        IF v_tmp_cnt = 0 THEN
          IF v_period_name IS NULL THEN
            v_period_name := TO_CHAR(TRUNC(SYSDATE, 'MM'), 'YYYY-MM');
            INSERT INTO WEB_FIN_MONTHLYCLOSING
              (c_period_name, c_dptacc_cde)
            VALUES
              (v_period_name, v_otherdptacc_cde);
          ELSE
            INSERT INTO WEB_FIN_MONTHLYCLOSING
              (c_period_name, c_dptacc_cde)
            VALUES
              (v_period_name, v_otherdptacc_cde);
          END IF;
        END IF;

      END;
      COMMIT;
    END LOOP;
    CLOSE cur_dptacc;

    --3?????????????

    --4?????????????

    --5.???????????????????????????
    SELECT COUNT(*)
      INTO v_tmp_cnt
      FROM WEB_FIN_MONTHLYCLOSING
     WHERE c_period_name <> TO_CHAR(SYSDATE, 'YYYY-MM')
       AND c_closing_flag = '1';

    IF v_tmp_cnt <> 0 THEN
      OPEN cur_dptacc;
      LOOP
        FETCH cur_dptacc
          INTO v_otherdptacc_cde;
        EXIT WHEN cur_dptacc%NOTFOUND;
        BEGIN

          SELECT COUNT(*)
            INTO v_tmpflag_cnt
            FROM WEB_FIN_MONTHLYCLOSING
           WHERE c_period_name <> TO_CHAR(SYSDATE, 'YYYY-MM')
             AND c_dptacc_cde = v_otherdptacc_cde
             AND c_closing_flag = '1';

          IF v_tmpflag_cnt <> 0 THEN
            /*
            --??
            SELECT COUNT(*)
              INTO  v_tmp_cnt
              FROM WEB_FIN_CAV_BILL
              WHERE c_check_flag IN ('0','1') AND c_dpt_cde =v_otherdptacc_cde;
            */

            --IF v_tmp_cnt>0 THEN
            UPDATE WEB_ORG_DPT
               SET c_switch_flag = '1' --??
             WHERE c_dptacc_cde = v_otherdptacc_cde;
            --END IF;

            --??
            SELECT COUNT(*)
              INTO v_tmp_cnt
              FROM WEB_FIN_MADCR_STATUS
             WHERE t_crt_tm >=
                   TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd') || ' 00:00:00',
                           'YYYY-MM-DD HH24:MI:SS')
               AND t_crt_tm <=
                   TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');

            IF v_tmp_cnt = 0 THEN
              UPDATE WEB_ORG_DPT
                 SET c_switch_flag = '1' --??
               WHERE c_dptacc_cde = v_otherdptacc_cde;
            END IF;
          END IF;

        END;
        COMMIT;
      END LOOP;
      CLOSE cur_dptacc;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_otherdptacc_cde ||
                             SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[ValidityCheck],??????[' ||
                         v_otherdptacc_cde || '],?????[' || SQLCODE ||
                         SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  --8.???? Calculate interest
  --????
  PROCEDURE Calculateinterest IS
    v_insrnc_bgn_tm DATE; --????
    v_insrnc_end_tm DATE; --????
    v_prod_no       WEB_FIN_SAVEAMT_DUE.c_prod_no%TYPE; --????
    v_ply_no        WEB_FIN_SAVEAMT_DUE.c_ply_no%TYPE;
    v_dpt_cde       WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;
    plytime         NUMBER(16, 2);
    edrtime         NUMBER(16, 2);
    newedrtime      NUMBER(16, 2);
    ngetamt         NUMBER(16, 2);
    npayamt         NUMBER(16, 2);
    npaidamt        NUMBER(16, 2);

    v_cur_cde     WEB_FIN_SAVEAMT_DUE.c_BS_CUR%TYPE;
    v_rcpt_no     WEB_FIN_SAVEAMT_DUE.c_rcpt_no%TYPE;
    v_salegrp_cde WEB_FIN_SAVEAMT_DUE.C_SLSGRP_CDE%TYPE;
    chacls        WEB_FIN_SAVEAMT_DUE.c_cha_cls%TYPE;
    chacde        WEB_FIN_SAVEAMT_DUE.c_cha_cde%TYPE;
    v_sls_cde     WEB_FIN_SAVEAMT_DUE.c_sls_cde%TYPE;
    payprsncde    WEB_FIN_SAVEAMT_DUE.C_PAYER_CDE%TYPE;
    --v_dpt_cde          WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;
    --v_monseqno      WEB_FIN_MONTHACCRUAL.c_mon_ret_no%TYPE;
    v_seq_no        WEB_FIN_DCR.c_seq_no%TYPE;
    v_feetyp_cde    WEB_FIN_SAVEAMT_DUE.c_feetyp_cde%TYPE;
    v_newedrno      WEB_EDR_BASE.c_edr_no%TYPE;
    n_realflag      NUMBER(1);
    a               NUMBER(1);
    v_err_content   WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_crt_cde       WEB_FIN_SAVEAMT_DUE.c_crt_cde%TYPE;
    dznoflag        INT;
    v_interest_flag VARCHAR2(2);
    v_cal_tm        WEB_FIN_PAY_DUE.T_DUE_TM%TYPE;

    v_vou_memo       WEB_FIN_MADCR.c_vou_memo%TYPE;
    v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
    v_company_cde    WEB_FIN_MADCR.c_company_cde%TYPE;
    v_period_name    WEB_FIN_MADCR.c_period_name%TYPE;
    v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;
    v_end_time       WEB_BAS_FIN_ACCT_PERIOD.T_end_tm%TYPE;
    v_dptacc_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_maseq_no       WEB_FIN_MADCR.c_seq_no%TYPE;

    v_kind_no  WEB_BAS_FIN_PROD.c_prod_no%TYPE;
    v_tmp_cnt  int;
    v_add_type web_prd_prod.c_add_type%type;

    CURSOR cur_calint IS
      SELECT c_ply_no,
             c_prod_no,
             NVL(n_paid_amt, 0),
             TRUNC(t_insrnc_bgn_tm),
             TRUNC(t_insrnc_end_tm),
             NVL(C_BS_CUR, ' '),
             NVL(c_rcpt_no, ' '),
             NVL(C_SLSGRP_CDE, ' '),
             NVL(c_cha_cls, ' '),
             NVL(c_cha_cde, ' '),
             NVL(c_sls_cde, ' '),
             NVL(C_PAYER_CDE, ' '),
             NVL(c_dpt_cde, ' '),
             c_crt_cde,
             c_dptacc_cde
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE c_lx_flag = '0'
         AND c_feetyp_cde = 'G'
         AND n_paid_amt < 0
         and not exists
       (SELECT c_ply_no
                from WEB_EDR_BASE
               WHERE c_ply_no = WEB_FIN_SAVEAMT_DUE.c_ply_no
                 and c_edr_rsn in ('A1', 'A3', '77'));

    --????G?????0???????? ?????????????????????????????

  BEGIN

    return;
    --?????
    IF TRUNC(SYSDATE - 1, 'MM') <> TRUNC(ADD_MONTHS(SYSDATE, -1)) THEN
      RETURN;
    ELSE

      UPDATE WEB_FIN_SAVEAMT_DUE
         SET c_lx_flag = '0'
       WHERE c_feetyp_cde = 'G'
         AND n_paid_amt < 0
         and not exists
       (SELECT c_ply_no
                from WEB_EDR_BASE
               WHERE c_ply_no = WEB_FIN_SAVEAMT_DUE.c_ply_no
                 and c_edr_rsn in ('A1', 'A3', '77'));

      commit;
    END IF;

    --????????
    v_cal_tm      := TRUNC(SYSDATE) - 1;
    v_period_name := TO_CHAR(v_cal_tm, 'yyyy-mm');

    OPEN cur_calint;
    LOOP
      FETCH cur_calint
        INTO v_ply_no, v_prod_no, npaidamt, v_insrnc_bgn_tm, v_insrnc_end_tm, v_cur_cde, v_rcpt_no, v_salegrp_cde, chacls, chacde, v_sls_cde, payprsncde, v_dpt_cde, v_crt_cde, v_dptacc_cde;

      EXIT WHEN cur_calint%NOTFOUND;
      --??????????

      --v_period_name:=TO_CHAR(SYSDATE,'YYYY-MM');
      SELECT TRUNC(t_end_tm)
        INTO v_end_time
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = v_period_name;

      v_cal_tm      := TRUNC(v_end_time);
      v_period_name := TO_CHAR(v_cal_tm, 'YYYY-MM');

      IF TRUNC(SYSDATE) - v_end_time <> 1 THEN
        RETURN;
      END IF;

      SELECT SUM(NVL(n_edr_prj_no, 0))
        INTO edrtime
        FROM WEB_PLY_BASE
       WHERE c_ply_no = TRIM(v_ply_no);

      --?????????????
      /*zmh
            IF edrtime = 0 AND ABS (npaidamt) > 0
            THEN

               SELECT NVL (n_yl1, 0)                                     --nyl1,??
                 INTO plytime
                 FROM web_PLY_cvrg
                WHERE c_ply_no = TRIM (v_ply_no);

        SELECT nvl(c_add_type,'3')
        INTO v_add_type
        FROM web_prd_prod
        WHERE c_prod_no=v_prod_no;

        --??????
               SELECT Invst_Finc.get_profit_sum (v_add_type,
                                                 v_insrnc_bgn_tm,
                                                 v_insrnc_end_tm,
                                                 SYSDATE-1,
                                                 plytime
                                                )
                 INTO ngetamt
                 FROM DUAL;
                v_interest_flag:='Y';

            ELSIF ABS (npaidamt) > 0      THEN

              v_newedrno :=
                  Get_Newply_No (v_ply_no,
                                 TO_CHAR (SYSDATE-1, 'yyyy-mm-dd hh24:mi:ss')
                                );


          IF  v_newedrno= '------' THEN
            v_interest_flag:='N';
          ELSE
            SELECT count(*)
            INTO v_tmp_cnt
            FROM T_EDR_cvrg
            WHERE c_edr_no = TRIM (v_newedrno);

            IF v_tmp_cnt>0 THEN
              SELECT NVL (n_yl1, 0)
              INTO newedrtime
              FROM T_EDR_cvrg
              WHERE c_edr_no = TRIM (v_newedrno);

              SELECT nvl(c_add_type,'3')
              INTO v_add_type
              FROM WEB_BAS_FIN_PROD
              WHERE c_prod_no=v_prod_no;

              --??????
              SELECT Invst_Finc.get_profit_sum (v_add_type,
               v_insrnc_bgn_tm,
               v_insrnc_end_tm,
               SYSDATE-1,
               newedrtime
              )
              INTO ngetamt
              FROM DUAL;
              v_interest_flag:='Y';
            ELSE
              v_interest_flag:='N';
            END IF;
          END IF ;

            END IF;
      */
      IF v_interest_flag = 'Y' THEN
        SELECT SQ_FIN_INTERESTDUE.NEXTVAL INTO v_seq_no FROM dual;

        --????
        /*   INSERT INTO web_FIN_INTERESTDUE
                   (

                   )
                 SELECT
              FROM WEB_FIN_SAVEAMT_DUE
            WHERE c_rcpt_no=v_rcpt_no;
        */
        --????
        /*
             1101(2960)
             Dr????? 446106
             Cr:?????? 214401
        */
        v_vou_memo       := '????';
        v_servicetype_no := '1101';
        SELECT c_company_cde, c_department_cde
          INTO v_company_cde, v_department_cde
          FROM WEB_ORG_DPT
         WHERE c_dpt_cde = trim(v_dpt_cde);

        --?????
        Dz_Proc.get_FIN_no(v_maseq_no, v_dpt_cde, '7', dz_proc.g_pttype);

        SELECT c_kind_no
          INTO v_kind_no
          FROM WEB_BAS_FIN_PROD
         WHERE c_prod_no = v_prod_no;

        INSERT INTO WEB_FIN_MADCR
          (c_seq_no,
           c_item_no,
           t_end_tm,
           c_cav_flag,
           c_sbjt_no,

           n_amt,
           c_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_dpt_cde,

           c_rcpt_no,
           c_sls_cde,
           c_prod_no,
           c_bsns_typ,
           c_cha_cls,

           c_cha_cde,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           c_pay_prsn_name,
           c_ri_com,
           c_cont_code,
           c_ply_no,
           c_cha_mrk,

           c_vou_memo,
           c_company_cde,
           c_check_flag,
           n_total_amt,
           c_servicetype_no,
           c_kind_no,
           c_department_cde)
          SELECT v_maseq_no,
                 '1' /*n_item_no*/,
                 SYSDATE - 1 /*t_end_tm*/,
                 '?' /*c_cav_flag*/,
                 '446106',

                 ngetamt /*n_amt*/,
                 c_bs_cur /*c_cur_no*/,
                 v_cal_tm /*t_crt_tm*/,
                 c_dptacc_cde,
                 c_dpt_cde,

                 c_rcpt_no,
                 c_sls_cde,
                 c_prod_no,
                 c_bsns_typ,
                 c_cha_cls,
                 c_cha_cde,
                 C_SLSGRP_CDE,
                 NULL /*c_pay_prsn_cde*/,
                 NULL /*c_pay_prsn_name*/,
                 NULL /*c_ri_com*/,
                 NULL /*c_cont_code*/,
                 c_ply_no,
                 c_cha_mrk,

                 v_vou_memo /*c_vou_memo*/,
                 v_company_cde,
                 '0' /*c_check_flag*/,
                 ngetamt /*n_total_amt*/,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde
            FROM web_FIN_INTERESTDUE
           WHERE c_rcpt_no = v_seq_no;

        INSERT INTO WEB_FIN_MADCR
          (c_seq_no,
           c_item_no,
           t_end_tm,
           c_cav_flag,
           c_sbjt_no,

           n_amt,
           c_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_dpt_cde,

           c_rcpt_no,
           c_sls_cde,
           c_prod_no,
           c_bsns_typ,
           c_cha_cls,

           c_cha_cde,
           C_SALEGRP_CDE,
           c_pay_prsn_cde,
           c_pay_prsn_name,
           c_ri_com,
           c_cont_code,
           c_ply_no,
           c_cha_mrk,

           c_vou_memo,
           c_company_cde,
           c_check_flag,
           n_total_amt,
           c_servicetype_no,
           c_kind_no,
           c_department_cde)
          SELECT v_maseq_no,
                 '2' /*n_item_no*/,
                 SYSDATE - 1 /*t_end_tm*/,
                 '?' /*c_cav_flag*/,
                 '214401',

                 ngetamt /*n_amt*/,
                 c_bs_cur /*c_cur_no*/,
                 v_cal_tm /*t_crt_tm*/,
                 c_dptacc_cde,
                 c_dpt_cde,

                 c_rcpt_no,
                 c_sls_cde,
                 c_prod_no,
                 c_bsns_typ,
                 c_cha_cls,
                 c_cha_cde,
                 C_SLSGRP_CDE,
                 NULL /*c_pay_prsn_cde*/,
                 NULL /*c_pay_prsn_name*/,
                 NULL /*c_ri_com*/,
                 NULL /*c_cont_code*/,
                 c_ply_no,
                 c_cha_mrk,

                 v_vou_memo /*c_vou_memo*/,
                 v_company_cde,
                 '0' /*c_check_flag*/,
                 ngetamt /*n_total_amt*/,
                 v_servicetype_no,
                 v_kind_no,
                 v_department_cde
            FROM web_FIN_INTERESTDUE
           WHERE c_rcpt_no = v_seq_no;

        UPDATE WEB_FIN_SAVEAMT_DUE
           SET c_lx_flag = '1'
         WHERE c_rcpt_no = v_rcpt_no;

      END IF;

      COMMIT;
    END LOOP;

    CLOSE cur_calint;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_rcpt_no || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[CalculateInterest],??????[' ||
                         v_rcpt_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  --????
  PROCEDURE Formafee(v_formafee_no IN WEB_FIN_CAV_MNY.c_formafee_no%TYPE,
                     v_succsflag   IN OUT NUMBER) IS

    v_tmp_cnt     INT;
    v_period_name web_fin_monthlyclosing.c_period_name%TYPE;
    v_end_time    WEB_BAS_FIN_ACCT_PERIOD.t_bgn_tm%TYPE;

    v_voucher_no     web_fin_dcr.c_voucher_no%TYPE;
    v_seq_no         web_fin_dcr.c_seq_no%TYPE;
    v_company_cde    web_fin_dcr.c_company_cde%TYPE;
    v_department_cde web_fin_dcr.c_department_cde%TYPE;
    v_vou_memo       web_fin_dcr.c_vou_memo%TYPE;
    v_crsbjt_no      web_fin_dcr.c_sbjt_no%TYPE;
    v_savecash_bank  WEB_FIN_CAV_MNY.c_savecash_bank%TYPE;
    v_err_content    WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_dpt_cde        web_fin_cav_bill.c_dpt_cde%TYPE;
    v_servicetype_no web_fin_dcr.c_servicetype_no%TYPE;
    v_rp_type        web_fin_cav_bill.c_rp_type%TYPE;
    v_dcrvoucher_no  web_fin_dcr.c_voucher_no%TYPE;
    v_sumcr_amt      web_fin_dcr.n_amt%TYPE;
    v_sumdr_amt      web_fin_dcr.n_amt%TYPE;
    v_bank_cde       WEB_FIN_CAV_MNY.c_bank_cde%TYPE;

    v_cav_no      web_fin_dcr.c_cav_no%TYPE;
    v_item_no     web_fin_dcr.c_item_no%TYPE;
    v_flag        web_fin_dcr.c_check_flag%TYPE; /*1 ?? 2 ??*/
    v_savecash_no WEB_FIN_CAV_MNY.c_savecash_no%TYPE;

    i               INT;
    v_today_tm      web_fin_madcr.t_crt_tm%TYPE;
    v_bal_type      WEB_FIN_CAV_MNY.c_bal_typ%TYPE;
    v_drsbjt_no     web_fin_dcr.c_sbjt_no%type;
    v_kind_no       web_bas_fin_prod.c_prod_no%TYPE;
    v_cashsumcr_amt web_fin_dcr.n_amt%TYPE;
    v_credsumcr_amt web_fin_dcr.n_amt%TYPE;
    CURSOR cur_ifCavMoney IS
      SELECT c_cav_pk_id, n_item_no, c_savecash_no, c_bal_typ
        FROM WEB_FIN_CAV_MNY
       WHERE c_formafee_no = trim(v_formafee_no)
         and (c_bank_cde is null or c_bank_cde = ' ')
         and c_bal_typ in ('002001', '002006');
  BEGIN
    v_succsflag := 0;

    i := 0;

    SELECT SUM(n_amt)
      INTO v_sumcr_amt
      FROM WEB_FIN_CAV_MNY
     WHERE c_formafee_no = trim(v_formafee_no)
       and (c_bank_cde is null or c_bank_cde = ' ')
       and c_bal_typ in ('002001', '002006');

    SELECT SUM(n_amt)
      INTO v_cashsumcr_amt
      FROM WEB_FIN_CAV_MNY
     WHERE c_formafee_no = trim(v_formafee_no)
       and (c_bank_cde is null or c_bank_cde = ' ')
       and c_bal_typ in ('002001');

    SELECT SUM(n_amt)
      INTO v_credsumcr_amt
      FROM WEB_FIN_CAV_MNY
     WHERE c_formafee_no = trim(v_formafee_no)
       and (c_bank_cde is null or c_bank_cde = ' ')
       and c_bal_typ in ('002006');

    OPEN cur_ifCavMoney;
    LOOP
      FETCH cur_ifCavMoney
        INTO v_cav_no, v_item_no, v_savecash_no, v_bal_type;
      EXIT WHEN cur_ifCavMoney%NOTFOUND;

      i := i + 1;

      SELECT c_dpt_cde, c_rp_type
        INTO v_dpt_cde, v_rp_type
        FROM web_fin_cav_bill
       WHERE c_cav_pk_id = trim(v_cav_no);

      SELECT c_savecash_bank
        INTO v_savecash_bank
        FROM WEB_FIN_CAV_MNY
       WHERE c_cav_pk_id = trim(v_cav_no)
         AND n_item_no = trim(v_item_no);

      --1.??????????????????????

      SELECT COUNT(*)
        INTO v_tmp_cnt
        FROM WEB_FIN_MONTHLYCLOSING
       WHERE c_dptacc_cde = trim(v_dpt_cde)
         AND c_closing_flag = '1'; --??

      IF v_tmp_cnt = 0 THEN
        --????????? 00000019
        v_succsflag := -6;
        RETURN;
      ELSE
        SELECT c_period_name
          INTO v_period_name
          FROM WEB_FIN_MONTHLYCLOSING
         WHERE c_dptacc_cde = trim(v_dpt_cde)
           AND c_closing_flag = '1'; --??
      END IF;

      --v_period_name:=TO_CHAR(SYSDATE,'YYYY-MM');
      SELECT TRUNC(t_end_tm)
        INTO v_end_time
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = v_period_name;

      --???????????
      IF TO_CHAR(SYSDATE, 'YYYY-MM') <> v_period_name THEN
        v_today_tm := v_end_time;
      ELSE
        v_today_tm := SYSDATE;
      END IF;

      SELECT c_company_cde
        INTO v_company_cde
        FROM web_org_dpt
       WHERE c_dpt_cde = trim(v_dpt_cde);

      IF i = 1 THEN
        Dz_Proc.get_fin_voucode(v_voucher_no,
                                v_period_name,
                                v_company_cde,
                                dz_proc.g_pttype); --????????
        Dz_Proc.get_fin_no(v_seq_no, v_dpt_cde, '5', dz_proc.g_pttype);
        v_vou_memo       := '??';
        v_servicetype_no := '1115';
      END IF;

      IF v_savecash_no IS NULL THEN
        v_flag := '2';
      ELSE
        v_flag := '1';
      END IF;

      IF v_flag = 1 THEN

        SELECT c_sbjt_no
          INTO v_crsbjt_no
          FROM WEB_BAS_FIN_BANK
         WHERE c_dpt_cde = trim(v_dpt_cde)
           AND c_bank_cde = trim(v_savecash_bank);

        IF v_bal_type = '002001' THEN
          v_drsbjt_no := '100101';
        ELSE
          v_drsbjt_no := '101506';
        END IF;

        INSERT INTO web_fin_dcr
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_voucher_no,
           c_cav_no)
          SELECT v_seq_no,
                 i,
                 '?',
                 v_crsbjt_no,
                 v_savecash_bank,
                 n_amt,
                 NULL,
                 c_cur_cde,
                 NULL,
                 NULL,
                 v_today_tm,
                 v_dpt_cde,
                 c_flow_cde,
                 v_rp_type,
                 NULL,
                 c_bal_typ,
                 c_savecash_no,
                 c_check_no,
                 t_rp_tm,
                 NULL,
                 '0',
                 NULL,
                 v_dpt_cde,
                 v_vou_memo,
                 NULL,
                 NULL,
                 v_company_cde,
                 ' ',
                 '0',
                 ' ', /*c_salegrp_cde,c_bsns_typ,c_cha_mrk*/
                 v_voucher_no,
                 v_period_name,
                 v_sumcr_amt,
                 v_servicetype_no,
                 v_voucher_no,
                 v_cav_no
            FROM WEB_FIN_CAV_MNY
           WHERE c_cav_pk_id = trim(v_cav_no)
             AND n_item_no = trim(v_item_no);

        i := i + 1;
        INSERT INTO web_fin_dcr
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_voucher_no,
           c_cav_no)
          SELECT v_seq_no,
                 i,
                 '?', /*'100101'*/
                 v_drsbjt_no,
                 '0',
                 n_amt,
                 NULL,
                 c_cur_cde,
                 NULL,
                 NULL,
                 v_today_tm,
                 v_dpt_cde,
                 c_flow_cde,
                 v_rp_type,
                 NULL,
                 c_bal_typ,
                 c_bank_cde,
                 c_check_no,
                 t_rp_tm,
                 NULL,
                 '0',
                 NULL,
                 v_dpt_cde,
                 v_vou_memo,
                 NULL,
                 NULL,
                 v_company_cde,
                 ' ',
                 '0',
                 ' ', /*c_salegrp_cde,c_bsns_typ,c_cha_mrk*/
                 v_voucher_no,
                 v_period_name,
                 v_sumcr_amt,
                 v_servicetype_no,
                 v_voucher_no,
                 v_cav_no
            FROM WEB_FIN_CAV_MNY
           WHERE c_cav_pk_id = trim(v_cav_no)
             AND n_item_no = trim(v_item_no);

      ELSIF v_flag = '2' AND i = 1 THEN
        --??

        --??????
        SELECT MAX(c_voucher_no)
          INTO v_dcrvoucher_no
          FROM web_fin_dcr
         WHERE c_cav_no = v_cav_no
           AND c_vou_memo = '??';

        INSERT INTO web_fin_dcr
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_voucher_no,
           c_cav_no)
          SELECT v_seq_no,
                 c_item_no,
                 c_cav_flag,
                 c_sbjt_no,
                 c_sbjt_memo,
                 -n_amt,
                 n_exch_amt,
                 c_cur_no,
                 n_rate,
                 c_chr_cur_no,
                 v_today_tm,
                 c_dptacc_no,
                 c_flow_no,
                 c_rp_type,
                 c_ri_com,
                 c_bal_type,
                 c_bank_cde,
                 c_check_no,
                 t_rp_tm,
                 c_prod_no,
                 '0',
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 c_salegrp_cde, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 v_voucher_no,
                 TO_CHAR(v_today_tm, 'YYYY-MM'),
                 -n_total_amt,
                 c_servicetype_no,
                 v_voucher_no,
                 c_cav_no
            FROM web_fin_dcr
           WHERE c_voucher_no = v_dcrvoucher_no;

        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_cav_no)
          SELECT v_seq_no,
                 c_item_no,
                 c_cav_flag,
                 c_sbjt_no,
                 c_sbjt_memo,
                 -n_amt,
                 n_exch_amt,
                 c_cur_no,
                 n_rate,
                 c_chr_cur_no,
                 v_today_tm,
                 c_dptacc_no,
                 c_flow_no,
                 c_rp_type,
                 c_ri_com,
                 c_bal_type,
                 c_bank_cde,
                 c_check_no,
                 t_rp_tm,
                 c_prod_no,
                 '0',
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 c_salegrp_cde, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 v_voucher_no,
                 TO_CHAR(v_today_tm, 'YYYY-MM'),
                 -n_total_amt,
                 c_servicetype_no,
                 c_cav_no
            FROM web_fin_dcr_intf
           WHERE c_vou_no = v_dcrvoucher_no;

        UPDATE web_fin_dcr_intf
           SET c_sbjt_memo      = DECODE(c_sbjt_memo,
                                         NULL,
                                         '0',
                                         ' ',
                                         '0',
                                         c_sbjt_memo),
               c_dpt_cde        = DECODE(c_dpt_cde,
                                         NULL,
                                         '0',
                                         ' ',
                                         '0',
                                         c_dpt_cde),
               c_prod_no        = DECODE(c_prod_no,
                                         NULL,
                                         '0',
                                         ' ',
                                         '0',
                                         c_prod_no),
               c_bsns_typ       = DECODE(c_bsns_typ,
                                         NULL,
                                         '0',
                                         ' ',
                                         '0',
                                         c_bsns_typ),
               c_department_cde = DECODE(c_department_cde,
                                         NULL,
                                         '0',
                                         ' ',
                                         '0',
                                         c_department_cde)
         WHERE c_seq_no = trim(v_seq_no);

        /*
        UPDATE web_fin_dcr_intf
        set c_sbjt_memo=v_savecash_bank
        WHERE c_seq_no=trim(v_seq_no) AND c_sbjt_no like '1002%' ;
        */

        UPDATE web_fin_dcr_intf
           SET c_sbjt_memo = '0'
         WHERE c_seq_no = trim(v_seq_no)
           AND c_sbjt_no LIKE '1001%';

        --   Auto_Confirmed.ValidityCheckCavVou(v_seq_no,v_succsflag); --wpc
        v_succsflag := v_succsflag;
        IF v_succsflag < 0 THEN
          RETURN;
        END IF;

        UPDATE WEB_FIN_CAV_MNY
           SET c_savecash_bank = NULL
         WHERE c_cav_pk_id = trim(v_cav_no)
           AND n_item_no = trim(v_item_no);

      END IF;

    END LOOP;
    CLOSE cur_ifCavMoney;

    IF v_flag = 1 THEN
      --??

      SELECT c_bank_cde
        INTO v_bank_cde
        FROM web_fin_dcr
       WHERE c_seq_no = trim(v_seq_no)
         AND c_bank_cde IS NOT NULL
         AND ROWNUM = 1;

      INSERT INTO web_fin_dcr_intf
        (c_seq_no,
         c_item_no,
         c_cav_flag,
         c_sbjt_no,
         c_sbjt_memo,
         n_amt,
         n_exch_amt,
         c_cur_no,
         n_rate,
         c_chr_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_flow_no,
         c_rp_type,
         c_ri_com,
         c_bal_type,
         c_bank_cde,
         c_check_no,
         t_rp_tm,
         c_prod_no,
         c_send_flag,
         c_cont_code,
         c_dpt_cde,
         c_vou_memo,
         c_con_dpt_cde,
         c_cost_cde,
         c_company_cde,
         c_salegrp_cde,
         c_bsns_typ,
         c_cha_mrk,
         c_vou_no,
         c_period_name,
         n_total_amt,
         c_servicetype_no,
         c_cav_no)
        SELECT c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               c_sbjt_memo,
               v_sumcr_amt,
               n_exch_amt,
               DECODE(c_cur_no,
                      '01',
                      'CNY',
                      '02',
                      'HKD',
                      '03',
                      'USD',
                      '12',
                      'EUR',
                      '13',
                      'EUR',
                      '05',
                      'JPY',
                      c_cur_no),
               n_rate,
               c_chr_cur_no,
               v_today_tm,
               c_dptacc_no,
               c_flow_no,
               c_rp_type,
               c_ri_com,
               c_bal_type,
               NULL,
               c_check_no,
               t_rp_tm,
               c_prod_no,
               c_send_flag,
               c_cont_code,
               c_dpt_cde,
               c_vou_memo,
               c_con_dpt_cde,
               c_cost_cde,
               c_company_cde,
               c_salegrp_cde, /*c_bsns_typ*/
               '0',
               c_cha_mrk,
               c_voucher_no,
               c_period_name,
               v_sumcr_amt,
               c_servicetype_no,
               v_formafee_no
          FROM web_fin_dcr
         WHERE c_seq_no = trim(v_seq_no)
           AND c_cav_flag = '?'
           AND ROWNUM = 1;

      IF v_cashsumcr_amt <> 0 THEN
        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_cav_no)
          SELECT c_seq_no,
                 c_item_no,
                 c_cav_flag,
                 c_sbjt_no,
                 c_sbjt_memo,
                 v_cashsumcr_amt,
                 n_exch_amt,
                 DECODE(c_cur_no,
                        '01',
                        'CNY',
                        '02',
                        'HKD',
                        '03',
                        'USD',
                        '12',
                        'EUR',
                        '13',
                        'EUR',
                        '05',
                        'JPY',
                        c_cur_no),
                 n_rate,
                 c_chr_cur_no,
                 v_today_tm,
                 c_dptacc_no,
                 c_flow_no,
                 c_rp_type,
                 c_ri_com,
                 c_bal_type,
                 v_bank_cde,
                 c_check_no,
                 t_rp_tm,
                 c_prod_no,
                 c_send_flag,
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 c_salegrp_cde, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 c_voucher_no,
                 c_period_name,
                 v_sumcr_amt,
                 c_servicetype_no,
                 v_formafee_no
            FROM web_fin_dcr
           WHERE c_seq_no = trim(v_seq_no)
             AND c_cav_flag = '?'
             AND ROWNUM = 1
             AND c_sbjt_no = '100101';
      END IF;

      IF v_credsumcr_amt <> 0 THEN
        INSERT INTO web_fin_dcr_intf
          (c_seq_no,
           c_item_no,
           c_cav_flag,
           c_sbjt_no,
           c_sbjt_memo,
           n_amt,
           n_exch_amt,
           c_cur_no,
           n_rate,
           c_chr_cur_no,
           t_crt_tm,
           c_dptacc_no,
           c_flow_no,
           c_rp_type,
           c_ri_com,
           c_bal_type,
           c_bank_cde,
           c_check_no,
           t_rp_tm,
           c_prod_no,
           c_send_flag,
           c_cont_code,
           c_dpt_cde,
           c_vou_memo,
           c_con_dpt_cde,
           c_cost_cde,
           c_company_cde,
           c_salegrp_cde,
           c_bsns_typ,
           c_cha_mrk,
           c_vou_no,
           c_period_name,
           n_total_amt,
           c_servicetype_no,
           c_cav_no)
          SELECT c_seq_no,
                 c_item_no,
                 c_cav_flag,
                 c_sbjt_no,
                 c_sbjt_memo,
                 v_credsumcr_amt,
                 n_exch_amt,
                 DECODE(c_cur_no,
                        '01',
                        'CNY',
                        '02',
                        'HKD',
                        '03',
                        'USD',
                        '12',
                        'EUR',
                        '13',
                        'EUR',
                        '05',
                        'JPY',
                        c_cur_no),
                 n_rate,
                 c_chr_cur_no,
                 v_today_tm,
                 c_dptacc_no,
                 c_flow_no,
                 c_rp_type,
                 c_ri_com,
                 c_bal_type,
                 v_bank_cde,
                 c_check_no,
                 t_rp_tm,
                 c_prod_no,
                 c_send_flag,
                 c_cont_code,
                 c_dpt_cde,
                 c_vou_memo,
                 c_con_dpt_cde,
                 c_cost_cde,
                 c_company_cde,
                 c_salegrp_cde, /*c_bsns_typ*/
                 '0',
                 c_cha_mrk,
                 c_voucher_no,
                 c_period_name,
                 v_sumcr_amt,
                 c_servicetype_no,
                 v_formafee_no
            FROM web_fin_dcr
           WHERE c_seq_no = trim(v_seq_no)
             AND c_cav_flag = '?'
             AND ROWNUM = 1
             and c_sbjt_no = '101506';
      END IF;

      UPDATE web_fin_dcr_intf
         SET c_sbjt_memo = v_savecash_bank
       WHERE c_seq_no = trim(v_seq_no)
         AND c_sbjt_no LIKE '1002%';

      UPDATE web_fin_dcr_intf
         SET c_sbjt_memo = '0'
       WHERE c_seq_no = trim(v_seq_no)
         AND c_sbjt_no LIKE '1001%';

      UPDATE web_fin_dcr_intf
         SET c_sbjt_memo      = DECODE(c_sbjt_memo,
                                       NULL,
                                       '0',
                                       ' ',
                                       '0',
                                       c_sbjt_memo),
             c_dpt_cde        = DECODE(c_dpt_cde,
                                       NULL,
                                       '0',
                                       ' ',
                                       '0',
                                       c_dpt_cde),
             c_prod_no        = DECODE(c_prod_no,
                                       NULL,
                                       '0',
                                       ' ',
                                       '0',
                                       c_prod_no),
             c_bsns_typ       = DECODE(c_bsns_typ,
                                       NULL,
                                       '0',
                                       ' ',
                                       '0',
                                       c_bsns_typ),
             c_department_cde = DECODE(c_department_cde,
                                       NULL,
                                       '0',
                                       ' ',
                                       '0',
                                       c_department_cde)
       WHERE c_seq_no = trim(v_seq_no);

      --   Auto_Confirmed.ValidityCheckCavVou(v_seq_no,v_succsflag); --wpc
      v_succsflag := v_succsflag;

      IF v_succsflag < 0 THEN
        RETURN;
      END IF;
    END IF;
    /*
    1.??

    v_succsflag:
      0 ??
      -1
      -2
      -3
      -4  ????????,???????????

      -9  ????
    */

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;

        dbms_output.put_line('exception' || '*' || v_cav_no || SQLERRM);

        v_err_content := 'proc:[formafee],??????[' || v_cav_no ||
                         '],?????[' || SQLCODE || SQLERRM;

      END;
  END;

  --11 ??????
  --??????
  PROCEDURE ValidityCheckMaVou(v_seq_no    IN WEB_FIN_MADCR.c_seq_no%TYPE,
                               v_succsflag IN OUT NUMBER) IS
    /*
      1.??????
      2.??????
      3.????????
      4.??????????
      5.??????

      6.?????
      7.?????
      8.??????
      -9 ????????
    */

    v_company_cde    web_fin_madcr_intf.c_company_cde%TYPE;
    v_department_cde web_fin_madcr_intf.c_department_cde%TYPE;
    v_sbjt_no        web_fin_madcr_intf.c_sbjt_no%TYPE;
    v_prod_no        web_fin_madcr_intf.c_prod_no%TYPE;
    v_period_name    web_fin_madcr_intf.c_period_name%TYPE;
    v_sbjt_memo      web_fin_madcr_intf.c_sbjt_memo%TYPE;
    v_cur_no         web_fin_madcr_intf.c_cur_no%TYPE;
    v_dpt_cde        web_fin_madcr_intf.c_dpt_cde%TYPE;
    v_wei_1          VARCHAR2(1);
    v_wei_2          VARCHAR2(1);
    v_wei_3          VARCHAR2(1);
    v_wei_4          VARCHAR2(1);
    v_wei_5          VARCHAR2(1);

    v_wei_6 VARCHAR2(1);
    v_wei_7 VARCHAR2(1);
    v_wei_8 VARCHAR2(1);
    v_wei_9 VARCHAR2(1);

    v_dr_amt      web_fin_madcr_intf.n_amt%TYPE;
    v_cr_amt      web_fin_madcr_intf.n_amt%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;

    v_verifyvou_memo web_fin_madcr_intf.c_verifyvou_memo%TYPE;
    v_tmp_cnt        INT;
    v_crt_tm         web_fin_madcr_intf.t_crt_tm%TYPE;
    CURSOR cur_ifcavvou IS
      SELECT c_company_cde,
             c_department_cde,
             c_sbjt_no,
             c_prod_no,
             c_period_name,
             c_cur_no,
             c_dpt_cde,
             c_sbjt_memo,
             t_crt_tm
        FROM web_fin_madcr_intf
       WHERE c_seq_no = v_seq_no;

  BEGIN
    v_succsflag := 0;

    OPEN cur_ifcavvou;
    LOOP
      <<GOTO_LAB>>
      FETCH cur_ifcavvou
        INTO v_company_cde, v_department_cde, v_sbjt_no, v_prod_no, v_period_name, v_cur_no, v_dpt_cde, v_sbjt_memo, v_crt_tm;
      EXIT WHEN cur_ifcavvou%NOTFOUND;
      BEGIN

        --1.????????
        IF v_company_cde IS NULL OR v_company_cde = ' ' OR
           v_company_cde = '?' THEN
          v_wei_1     := '1';
          v_succsflag := -1;
          RETURN;
        ELSE
          SELECT COUNT(*)
            INTO v_tmp_cnt
            FROM web_oracle_company
           WHERE c_dpt_cde = trim(v_company_cde);

          IF v_tmp_cnt = 0 THEN
            v_wei_1     := '1';
            v_succsflag := -1;
            RETURN;
          ELSE
            v_wei_1 := '0';
          END IF;
        END IF;

        --2.????? ??
        IF v_department_cde IS NULL OR v_department_cde = ' ' THEN
          v_wei_2 := '1'; --?????? ?:???????
          RETURN;
        ELSIF v_department_cde = '0' THEN
          v_wei_2 := '0';
        ELSE
          SELECT COUNT(c_dpt_cde)
            INTO v_tmp_cnt
            FROM WEB_ORG_DPT
           WHERE c_dpt_cde = v_dpt_cde
             AND c_department_cde <> '?'
             AND c_department_cde IS NOT NULL
             AND c_company_cde <> '?'
             AND c_company_cde IS NOT NULL
                --AND c_ctct_cde not in ('014001','014008')
             AND LENGTH(c_dpt_cde) = 8;

          IF v_tmp_cnt = 0 THEN
            v_wei_2     := '1';
            v_succsflag := -2;
            RETURN;
          END IF;

          SELECT COUNT(*)
            INTO v_tmp_cnt
            FROM web_oracle_department
           WHERE c_dpt_cde = trim(v_department_cde);

          IF v_tmp_cnt = 0 THEN
            v_wei_2     := '1';
            v_succsflag := -2;
            RETURN;
          ELSE
            v_wei_2 := '0';
          END IF;
        END IF;

        --3.????? ????
        IF v_sbjt_no IS NULL OR v_sbjt_no = ' ' THEN
          v_wei_3     := '1';
          v_succsflag := -3;
          RETURN;
        ELSE
          SELECT COUNT(*)
            INTO v_tmp_cnt
            FROM web_oracle_subject
           WHERE c_sbjt_no = trim(v_sbjt_no);

          IF v_tmp_cnt = 0 THEN
            v_wei_3     := '1';
            v_succsflag := -3;
            RETURN;
          ELSE
            v_wei_3 := '0';
          END IF;
        END IF;

        --4.????? ??????
        IF v_sbjt_memo IS NULL OR v_sbjt_memo = ' ' THEN
          v_wei_4 := -4;
          RETURN;
        ELSIF v_sbjt_memo = '0' THEN
          v_wei_4 := '0';
        ELSE
          v_wei_4 := '0';
        END IF;

        --5.????? ??
        IF v_prod_no IS NULL OR v_prod_no = ' ' THEN
          v_wei_5 := '0'; --???? ????????
        ELSIF v_prod_no = '0' THEN
          v_wei_5 := '0';
        ELSE
          SELECT COUNT(*)
            INTO v_tmp_cnt
            FROM web_oracle_prod
           WHERE c_prod_no = trim(v_prod_no);

          IF v_tmp_cnt = 0 THEN
            v_wei_5     := '1';
            v_succsflag := -5;
            RETURN;
          ELSE
            v_wei_5 := '0';
          END IF;
        END IF;

        --6.??????
        IF v_period_name IS NULL OR v_period_name = ' ' THEN
          v_wei_6 := '1';
        ELSE

          SELECT COUNT(*)
            INTO v_tmp_cnt
            FROM WEB_BAS_FIN_ACCT_PERIOD
           WHERE c_period_name = trim(v_period_name);

          IF v_tmp_cnt = 0 THEN
            v_wei_6     := '1';
            v_succsflag := -6;
            RETURN;
          ELSE
            IF TO_CHAR(v_crt_tm, 'YYYY-MM') <> v_period_name THEN
              v_wei_6     := '1';
              v_succsflag := -6;
              RETURN;
            ELSE
              v_wei_6 := '0';

            END IF;
          END IF;

        END IF;

        --7.??????
        IF v_cur_no IS NULL OR v_cur_no = ' ' THEN
          v_wei_7 := '1';
        ELSE
          IF v_cur_no NOT IN ('CNY', 'HKD', 'USD', 'EUR', 'JPY') THEN
            v_wei_7     := '1';
            v_succsflag := -7;
            RETURN;
          ELSE
            v_wei_7 := '0';
          END IF;
        END IF;

        --8.??????
        SELECT SUM(DECODE(c_cav_flag, '?', n_amt, 0)),
               SUM(DECODE(c_cav_flag, '?', n_amt, 0))
          INTO v_dr_amt, v_cr_amt
          FROM web_fin_madcr_intf
         WHERE c_seq_no = v_seq_no;

        IF v_dr_amt = v_cr_amt THEN
          v_wei_8 := '0';
        ELSE
          v_wei_8     := '1';
          v_succsflag := -8;
          RETURN;
        END IF;

      END;

    END LOOP;
    CLOSE cur_ifcavvou;
    --v_verifyvou_memo:=v_wei_1||v_wei_2||v_wei_3||v_wei_4||v_wei_5||v_wei_6||v_wei_7||v_wei_8;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        v_succsflag := -9;
        dbms_output.put_line('exception' || '*' || v_seq_no || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[ValidityCheckMaVou],??????[' ||
                         v_seq_no || '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '1115', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;
  END;

  --12.???? Guarantee confirmation again
  PROCEDURE RiConfirm IS
    --????????????????????????
    v_busi_source WEB_FIN_RICED_DUE.c_busi_source%TYPE; --0 ?? 1 ??

    --????
    v_dptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    --v_dpt_cde    t_department.c_dpt_cde%type;

    v_prod_no       WEB_FIN_RICED_DUE.c_prod_no%TYPE;
    v_get_prm       WEB_FIN_RICED_DUE.N_BS_AMT%TYPE;
    v_dr_amt        WEB_FIN_RICED_DUE.N_BS_AMT%TYPE;
    v_cr_amt        WEB_FIN_RICED_DUE.N_BS_AMT%TYPE;
    v_mix_amt       WEB_FIN_RICED_DUE.N_BS_AMT%TYPE;
    v_fee_type_code WEB_FIN_RICED_DUE.C_FEETYP_CDE%TYPE;
    v_ply_no        WEB_FIN_RICED_DUE.c_ply_no%TYPE;
    v_cont_code     WEB_FIN_RICED_DUE.C_CONT_CDE%TYPE;

    v_sharedue_no  WEB_FIN_RICED_DUE.C_RCPT_NO%TYPE;
    v_cha_cls      WEB_FIN_RICED_DUE.C_CHA_CLS%TYPE;
    v_CHA_CDE      WEB_FIN_RICED_DUE.C_CHA_CDE%TYPE;
    v_bsns_typ     WEB_FIN_RICED_DUE.C_bsns_typ%TYPE;


    v_cha_mrk WEB_FIN_RICED_DUE.c_cha_mrk%TYPE;

    v_cnt       INT;
    v_tran_flag WEB_FIN_PRM_DUE.c_tran_flag%TYPE;

    vTmpVouNo   WEB_FIN_DCR.c_seq_no%TYPE;
    vzfTmpVouNo WEB_FIN_DCR.c_seq_no%TYPE;
    vfzTmpVouNo WEB_FIN_DCR.c_seq_no%TYPE;
    v_sbjt_memo WEB_FIN_DCR.c_sbjt_memo%TYPE;
    v_vou_memo  WEB_FIN_DCR.c_vou_memo%TYPE;

    v_cav_flag WEB_FIN_DCR.c_cav_flag%TYPE;
    v_sbjt_no  WEB_FIN_DCR.c_sbjt_no%TYPE;

    v_crcav_flag WEB_FIN_DCR.c_cav_flag%TYPE;
    v_crsbjt_no  WEB_FIN_DCR.c_sbjt_no%TYPE;

    v_ri_com         WEB_FIN_RICED_DUE.c_ri_com%TYPE;
    v_err_content    WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_voucher        VARCHAR2(3);
    v_servicetype_no WEB_FIN_DCR.c_servicetype_no%TYPE;
    v_bal_tm         WEB_FIN_PRM_DUE.T_DUE_TM%TYPE;
    v_dpt_cde        WEB_FIN_PRM_DUE.c_dpt_cde%TYPE;
    vbillcode        WEB_FIN_RICED_DUE.C_BILL_NO%TYPE;
    v_fee_current    WEB_FIN_RICED_DUE.C_BS_CUR%TYPE;
    v_second_sbjt    VARCHAR2(2);

    v_department_cde WEB_ORG_DPT.c_department_cde%TYPE;
    v_company_cde    WEB_ORG_DPT.c_company_cde%TYPE;

    v_kind_no WEB_BAS_FIN_PROD.c_prod_no%TYPE;

    --????????
    --?????????????? D9?
    /*
    ??? C1,5573407003.8907
    ????? D1,20658407.3694
    ???? D2,179069205.6268
    ???? D9,832832775.5681
    ??????D3,4492913.1675
    */

    CURSOR cur_ifRiInfo IS
      SELECT c_prod_no,
             N_BS_AMT,
             c_ply_no,
             c_busi_source,
             C_FEETYP_CDE,
             C_CONT_CDE,
             C_RCPT_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_bsns_typ,
             c_cha_mrk,
             c_ri_com,
             c_dpt_cde,
             C_BILL_NO,
             C_BS_CUR
        FROM WEB_FIN_RICED_DUE
       WHERE 1 = 1
         AND T_DUE_TM < SYSDATE
         AND T_DUE_TM >= sysdate - 10
         AND c_ri_com <> '9'
         AND C_FEETYP_CDE <> 'D9'
         AND c_accnt_flag IN ('00', '10');

  BEGIN
    OPEN cur_ifRiInfo;
    LOOP
      <<GOTO_LAB>>

      FETCH cur_ifRiInfo
        INTO v_prod_no, v_get_prm, v_ply_no, v_busi_source, v_fee_type_code, v_cont_code, v_sharedue_no, v_cha_cls, v_CHA_CDE,  v_bsns_typ,  v_cha_mrk, v_ri_com, v_dpt_cde, vbillcode, v_fee_current;
      EXIT WHEN cur_ifRiInfo%NOTFOUND;

      SELECT c_kind_no
        INTO v_kind_no
        FROM WEB_BAS_FIN_PROD
       WHERE c_prod_no = v_prod_no;

      --??0???????
      IF v_get_prm = 0 THEN
        GOTO GOTO_LAB;
      END IF;

      --?????
      Dz_Proc.get_fin_no(vTmpVouNo, '00', '5',dz_proc.g_pttype);

      v_voucher := 'VOU';
      SELECT c_dptacc_cde, c_company_cde, c_department_cde
        INTO v_dptacc_cde, v_company_cde, v_department_cde
        FROM WEB_ORG_DPT
       WHERE c_dpt_cde = RTRIM(LTRIM(v_dpt_cde));
      /*
      SELECT DECODE(v_cont_code,
        --??(??)
        '01','01',
        '08','01',

        --??
        '13','01',
        '15','01',
        '16','01',
        '17','01',
        '18','01',

        --??
        '06','02',
        '11','02',
        '12','02',
        '14','02',
        --???

        --??
        'FA','04',
        '01'
        )
      INTO v_second_sbjt
      FROM DUAL;
      */

      --?:????????
      IF v_busi_source = '0' THEN
        --0 ??
          IF v_fee_type_code = 'C1' OR v_fee_type_code = 'C6' OR
             v_fee_type_code = 'CE' OR v_fee_type_code = 'E1' OR
             v_fee_type_code = 'E3' OR v_fee_type_code = 'E4' OR
             v_fee_type_code = 'E7' OR v_fee_type_code = 'D6' THEN
            --????
            /*
            ???????????????
            ????????????? 211301
              */
            v_sbjt_no  := '442101';
            v_cav_flag := '?';

            v_crsbjt_no  := '211301';
            v_crcav_flag := '?';

            v_servicetype_no := '1116';
            v_vou_memo       := '??????';
          ELSIF v_fee_type_code = 'D1' OR v_fee_type_code = 'D4' OR
                v_fee_type_code = 'D5' OR v_fee_type_code = 'D8' OR
                v_fee_type_code = 'D7' OR v_fee_type_code = 'DE' THEN
            --??????
            /*
              ?????????????
              ?????????????????
            */
            v_sbjt_no  := '122201';
            v_cav_flag := '?';

            v_crsbjt_no  := '420301'; --??????
            v_crcav_flag := '?';

            v_servicetype_no := '1117';
            v_vou_memo       := '??????????';
          ELSIF v_fee_type_code = 'D2' OR v_fee_type_code = 'D9' OR
                v_fee_type_code = 'C4' OR v_fee_type_code = 'DQ' OR
                v_fee_type_code = 'DC' OR v_fee_type_code = 'T2' OR
                v_fee_type_code = 'C4' OR v_fee_type_code = 'C5' OR
                v_fee_type_code = 'E2' THEN
            --??????
            /*
            ?????????????
            ?????????????????
            */
            v_sbjt_no  := '122202';
            v_cav_flag := '?';

            v_crsbjt_no      := '420101';
            v_crcav_flag     := '?';
            v_servicetype_no := '1118';
            v_vou_memo       := '??????????';
          ELSIF v_fee_type_code = 'C3' THEN
            --????
            /*
              ??????
              ?????????????
            */
            v_sbjt_no  := '446104';
            v_cav_flag := '?';

            v_crsbjt_no      := '211304';
            v_crcav_flag     := '?';
            v_servicetype_no := '1122';
            v_vou_memo       := '???????????';
          ELSIF v_fee_type_code = 'D3' OR v_fee_type_code = 'D0' OR
                v_fee_type_code = 'C2' THEN
            --?????????C5,D5,D9,D0,C6,D6
            /*
            ????????????? 211304
              ??????????????????213104

            */
            v_sbjt_no  := '122204'; --'122204';???
            v_cav_flag := '?';

            v_crsbjt_no  := '213104';
            v_crcav_flag := '?';

            v_servicetype_no := '1121';
            v_vou_memo       := '???????????';
          ELSE
            v_sbjt_no  := '442101';
            v_cav_flag := '?';

            v_crsbjt_no      := '211301';
            v_crcav_flag     := '?';
            v_servicetype_no := '1116';
            v_vou_memo       := '??????';
          END IF;
      ELSE
        --1  ??
        v_servicetype_no := '1123';
        v_vou_memo       := '??????';
        --????

        IF v_fee_type_code = 'C1' OR v_fee_type_code = 'C6' OR
           v_fee_type_code = 'CE' OR v_fee_type_code = 'E1' OR
           v_fee_type_code = 'E3' OR v_fee_type_code = 'E4' OR
           v_fee_type_code = 'E7' OR v_fee_type_code = 'D6' THEN
          --????
          /*
          ???????????????
               ??????????????????
            */
          v_sbjt_no  := '811301';
          v_cav_flag := '?';

          v_crsbjt_no  := '410201';
          v_crcav_flag := '?';

          v_servicetype_no := '1123';
          v_vou_memo       := '?????????';
        ELSIF v_fee_type_code = 'D1' OR v_fee_type_code = 'D4' OR
              v_fee_type_code = 'D5' OR v_fee_type_code = 'D8' OR
              v_fee_type_code = 'D7' OR v_fee_type_code = 'DE' THEN
          --??????
          /*
          ???????????????????
               ???????????????

          */
          v_sbjt_no  := '442401';
          v_cav_flag := '?';

          v_crsbjt_no      := '811301';
          v_crcav_flag     := '?';
          v_servicetype_no := '1124';
          v_vou_memo       := '??????????';

        ELSIF v_fee_type_code = 'D2' OR v_fee_type_code = 'D9' OR
              v_fee_type_code = 'C4' OR v_fee_type_code = 'DQ' OR
              v_fee_type_code = 'DC' OR v_fee_type_code = 'T2' OR
              v_fee_type_code = 'C4' OR v_fee_type_code = 'C5' OR
              v_fee_type_code = 'E2' THEN
          --??????
          /*
          ???????????????????
            ???????????????
          */
          v_sbjt_no  := '442201';
          v_cav_flag := '?';

          v_crsbjt_no      := '811301'; --??????
          v_crcav_flag     := '?';
          v_servicetype_no := '1125';
          v_vou_memo       := '??????????';
        ELSE
          /*
          ???????????????
               ??????????????????
            */
          v_sbjt_no  := '811301';
          v_cav_flag := '?';

          v_crsbjt_no  := '410201';
          v_crcav_flag := '?';

          v_servicetype_no := '1123';
          v_vou_memo       := '?????????';
        END IF;

      END IF;

      INSERT INTO WEB_fin_madcr
        (C_SEQ_NO,
         C_ITEM_NO,
         C_CAV_FLAG,
         C_SBJT_NO,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         C_DPTACC_NO,
         C_DPT_CDE,
         C_RCPT_NO,
         C_SLS_CDE,
         C_PROD_NO,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SALEGRP_CDE,
         C_RI_COM,
         C_CONT_CODE,
         C_VOU_NO,
         C_SEND_FLAG,
         C_bsns_typ,
         c_sbjt_memo,
         c_ply_no,
         c_vou_memo,
         c_cha_mrk,
         c_servicetype_no,
         c_company_cde,
         c_department_cde,
         c_kind_no,
         c_period_name)
        SELECT vTmpVouNo,
               '1',
               v_cav_flag,
               v_sbjt_no,
               v_get_prm,
               SUBSTR(C_BS_CUR, 1, 2),
               TRUNC(T_DUE_TM),
               v_dptacc_cde,
               c_dpt_cde,
               C_RCPT_NO,
               C_SLS_CDE,
               C_PROD_NO,
               C_CHA_CLS,
               C_CHA_CDE,
               '0',
               c_ri_com,
               C_CONT_CDE,
               NULL,
               '0',
               NVL(C_bsns_typ, '0'),
               v_sbjt_memo,
               c_ply_no,
               v_vou_memo,
               v_cha_mrk,
               v_servicetype_no,
               v_company_cde,
               v_department_cde,
               v_kind_no,
               TO_CHAR(v_bal_tm, 'YYYY-MM')
          FROM WEB_FIN_RICED_DUE
         WHERE C_RCPT_NO = v_sharedue_no;

      INSERT INTO WEB_fin_madcr
        (C_SEQ_NO,
         C_ITEM_NO,
         C_CAV_FLAG,
         C_SBJT_NO,
         N_AMT,
         C_CUR_NO,
         T_CRT_TM,
         C_DPTACC_NO,
         C_DPT_CDE,
         C_RCPT_NO,
         C_SLS_CDE,
         C_PROD_NO,
         C_CHA_CLS,
         C_CHA_CDE,
         C_SALEGRP_CDE,
         C_RI_COM,
         c_cont_code,
         C_VOU_NO,
         C_SEND_FLAG,
         C_bsns_typ,
         c_sbjt_memo,
         c_ply_no,
         c_vou_memo,
         c_cha_mrk,
         c_servicetype_no,
         c_company_cde,
         c_department_cde,
         c_kind_no,
         c_period_name)
        SELECT vTmpVouNo,
               '2',
               v_crcav_flag,
               v_crsbjt_no,
               v_get_prm,
               SUBSTR(C_BS_CUR, 1, 2),
               TRUNC(T_DUE_TM),
               v_dptacc_cde,
               c_dpt_cde,
               C_RCPT_NO,
               C_SLS_CDE,
               C_PROD_NO,
               C_CHA_CLS,
               C_CHA_CDE,
               '0',

               c_ri_com,
               C_CONT_CDE,
               NULL,
               '0',
               NVL(c_bsns_typ, '0'),
               v_sbjt_memo,
               c_ply_no,
               v_vou_memo,
               v_cha_mrk,
               v_servicetype_no,
               v_company_cde,
               v_department_cde,
               v_kind_no,
               TO_CHAR(v_bal_tm, 'YYYY-MM')
          FROM WEB_FIN_RICED_DUE
         WHERE C_RCPT_NO = v_sharedue_no;

      /*
        ?????????????????
          ??????????????????211301
          ???????\???????? 119603?

        ?????????????????
          ???????\????????? 119603
          ?????????????????211301

        ------------------------------------------------------
        ??????????????????????????
        ???????\???????????? 119603
        ?????????????122201

        ??????????????????????????
        ?????????????122201
             ???????\?????????119603



        INSERT INTO t_fin_servicetype(c_no,c_name)
        VALUES('3000','?????????????????');

        INSERT INTO t_fin_servicetype(c_no,c_name)
        VALUES('3001','?????????????????');

        INSERT INTO t_fin_servicetype(c_no,c_name)
        VALUES('3002','??????????????????????????');

        INSERT INTO t_fin_servicetype(c_no,c_name)
        VALUES('3003','??????????????????????????');

        3000,?????????????????
        3001,?????????????????
        3002,??????????????????????????
        3003,??????????????????????????
      */

      --v_servicetype_no:='9999' ;---????????

      IF v_servicetype_no = '1116' THEN
        --????????????
        BEGIN
          /*
                ELSIF v_servicetype_no='3000' THEN
                --ELSIF v_vou_memo='????????' THEN
                  v_vou_memo:='????????';
                  v_drsbjt_no:='211301';
                  v_sbjt_no:='119603';

                ELSIF v_servicetype_no='4000' THEN
                --ELSIF v_vou_memo='????????' THEN
                  v_vou_memo:='????????';
                  v_drsbjt_no:='119603';
                  v_sbjt_no:='211301';
          */
          v_sbjt_no  := '211301';
          v_cav_flag := '?';

          v_crsbjt_no      := '119603';
          v_crcav_flag     := '?';
          v_servicetype_no := '3000';
          v_vou_memo       := '????????';
          Dz_Proc.get_fin_no(vfzTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,
             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

/*
        ?????????????????
          ???????\????????? 119603
          ?????????????????211301
*/

          v_sbjt_no  := '119603';
          v_cav_flag := '?';


          v_crsbjt_no      := '211301';
          v_crcav_flag     := '?';
          v_servicetype_no := '4000';
          v_vou_memo       := '????????';
          Dz_Proc.get_fin_no(vzfTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

        END;
      ELSIF v_servicetype_no = '1122' THEN
        --????????????
        BEGIN
          /*



              ?????????????
              ???????\????????????

              8.2    ?????
              ???????\?????????
              ?????????????







          */
          v_sbjt_no  := '211304';
          v_cav_flag := '?';

          v_crsbjt_no      := '119603';
          v_crcav_flag     := '?';
          v_servicetype_no := '3001';
          v_vou_memo       := '???????????';
          Dz_Proc.get_fin_no(vfzTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          v_sbjt_no  := '119603';
          v_cav_flag := '?';

          v_crsbjt_no      := '211304';
          v_crcav_flag     := '?';
          v_servicetype_no := '4001';
          v_vou_memo       := '???????????';
          Dz_Proc.get_fin_no(vzfTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

        END;

      ELSIF v_servicetype_no = '1117' THEN
        --??????????
        BEGIN
          /*
                ELSIF v_servicetype_no='3002' THEN
                --ELSIF v_vou_memo='??????????' THEN
                  v_vou_memo:='??????????';
                  v_drsbjt_no:='119603';
                  v_sbjt_no:='122201';

                ELSIF v_servicetype_no='4002' THEN
                --ELSIF v_vou_memo='??????????' THEN
                  v_vou_memo:='??????????';
                  v_drsbjt_no:='122201';
                  v_sbjt_no:='119603';
          */
          v_sbjt_no  := '119603';
          v_cav_flag := '?';

          v_crsbjt_no      := '122201';
          v_crcav_flag     := '?';
          v_servicetype_no := '3002';
          v_vou_memo       := '??????????';
          Dz_Proc.get_fin_no(vfzTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          v_sbjt_no  := '122201';
          v_cav_flag := '?';

          v_crsbjt_no      := '119603';
          v_crcav_flag     := '?';
          v_servicetype_no := '4002';
          v_vou_memo       := '??????????';
          Dz_Proc.get_fin_no(vzfTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;
        END;

      ELSIF v_servicetype_no = '1118' THEN
        --??????????
        BEGIN
          /*
                ELSIF v_servicetype_no='3003' THEN
                --ELSIF v_vou_memo='??????????' THEN
                  v_vou_memo:='??????????';
                  v_drsbjt_no:='119603';
                  v_sbjt_no:='122202';
                ELSIF v_servicetype_no='4003' THEN
                --ELSIF v_vou_memo='??????????' THEN
                  v_vou_memo:='??????????';
                  v_drsbjt_no:='122202';
                  v_sbjt_no:='119603';
          */
          v_sbjt_no  := '119603';
          v_cav_flag := '?';

          v_crsbjt_no      := '122202';
          v_crcav_flag     := '?';
          v_servicetype_no := '3003';
          v_vou_memo       := '??????????';
          Dz_Proc.get_fin_no(vfzTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          v_sbjt_no  := '122202';
          v_cav_flag := '?';

          v_crsbjt_no      := '119603';
          v_crcav_flag     := '?';
          v_servicetype_no := '4003';
          v_vou_memo       := '??????????';
          Dz_Proc.get_fin_no(vzfTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;
        END;

      ELSIF v_servicetype_no = '1121' THEN
        --???????????
        BEGIN
          /*

            ???????\????????????
            ?????????????

            8.2    ?????
            ?????????????
                 ???????\?????????




          */
          v_sbjt_no  := '119603';
          v_cav_flag := '?';

          v_crsbjt_no      := '122204';
          v_crcav_flag     := '?';
          v_servicetype_no := '3004';
          v_vou_memo       := '???????????';
          Dz_Proc.get_fin_no(vfzTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vfzTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          v_sbjt_no  := '122204';
          v_cav_flag := '?';

          v_crsbjt_no      := '119603';
          v_crcav_flag     := '?';
          v_servicetype_no := '4004';
          v_vou_memo       := '???????????';
          Dz_Proc.get_fin_no(vzfTmpVouNo, '00', '5',dz_proc.g_pttype);

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '1',
                   v_cav_flag,
                   v_sbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(C_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;

          INSERT INTO WEB_fin_madcr
            (C_SEQ_NO,
             C_ITEM_NO,
             C_CAV_FLAG,
             C_SBJT_NO,
             N_AMT,
             C_CUR_NO,
             T_CRT_TM,
             C_DPTACC_NO,
             C_DPT_CDE,
             C_RCPT_NO,
             C_SLS_CDE,
             C_PROD_NO,
             C_CHA_CLS,
             C_CHA_CDE,
             C_SALEGRP_CDE,

             C_RI_COM,
             c_cont_code,
             C_VOU_NO,
             C_SEND_FLAG,
             C_bsns_typ,
             c_sbjt_memo,
             c_ply_no,
             c_vou_memo,
             c_cha_mrk,
             c_servicetype_no,
             c_company_cde,
             c_department_cde,
             c_kind_no,
             c_period_name)
            SELECT vzfTmpVouNo,
                   '2',
                   v_crcav_flag,
                   v_crsbjt_no,
                   v_get_prm,
                   SUBSTR(C_BS_CUR, 1, 2),
                   TRUNC(T_DUE_TM),
                   v_dptacc_cde,
                   c_dpt_cde,
                   C_RCPT_NO,
                   C_SLS_CDE,
                   C_PROD_NO,
                   C_CHA_CLS,
                   C_CHA_CDE,
                   '0',

                   c_ri_com,
                   C_CONT_CDE,
                   NULL,
                   '0',
                   NVL(c_bsns_typ, '0'),
                   v_sbjt_memo,
                   c_ply_no,
                   v_vou_memo,
                   v_cha_mrk,
                   v_servicetype_no,
                   v_company_cde,
                   v_department_cde,
                   v_kind_no,
                   TO_CHAR(v_bal_tm, 'YYYY-MM')
              FROM WEB_FIN_RICED_DUE
             WHERE C_RCPT_NO = v_sharedue_no;
        END;
      END IF;

      UPDATE WEB_FIN_RICED_DUE
         SET c_accnt_flag = DECODE(c_accnt_flag,
                                   '10',
                                   '11',
                                   '00',
                                   '01',
                                   '00')
       WHERE C_RCPT_NO = v_sharedue_no
         AND c_accnt_flag IN ('00', '10');

      --????????????  ORACLE?????????,??????????????????????????
      UPDATE WEB_fin_madcr
         SET c_company_cde = (SELECT c_company_cde
                                FROM web_org_dpt
                               WHERE c_dpt_cde = v_dpt_cde)
       WHERE c_seq_no = vTmpVouNo;

      COMMIT;

    END LOOP;
    CLOSE cur_ifRiInfo;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --    ----RAISE;
        dbms_output.put_line('exception' || '*' || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[RiConfirm],??????[' || v_dpt_cde ||
                         vbillcode || v_fee_current || v_bal_tm ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           v_servicetype_no, --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;
  END;


  --????????
  PROCEDURE gatherribill IS
    v_dpt_cde web_fin_riced_due.c_dpt_cde%TYPE;
    v_prod_no web_fin_riced_due.c_prod_no%TYPE;
    v_cur_cde web_fin_riced_due.C_BS_CUR%TYPE;

    v_ri_com      web_fin_riced_due.c_ri_com%TYPE;
    v_bill_ym     web_fin_riced_due.c_bill_ym%TYPE;
    v_cont_code   web_fin_riced_due.c_type%TYPE;
    v_get_fee     web_fin_riced_due.N_BS_AMT%TYPE;
    v_bal_tm      web_fin_riced_due.T_DUE_TM%TYPE;
    vTmpVouNo     WEB_FIN_RIBILL_DUE.c_rcpt_no%TYPE;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;
    v_doc_flag    web_fin_riced_due.c_doc_flag%TYPE;

    CURSOR cur_ifribill IS
      SELECT c_prod_no,
             C_BS_CUR, --c_cur_cde       ,
             c_ri_com,
             TRUNC(T_DUE_TM),
             C_CONT_CDE,
             c_doc_flag,
             SUM(N_BS_AMT) --n_get_fee
        FROM web_fin_riced_due
       WHERE C_vou_no IS NULL
         AND T_DUE_TM < SYSDATE
         AND T_DUE_TM >= sysdate - 10
         AND c_ri_com <> '9'
         AND C_FEETYP_CDE <> 'D9'
       GROUP BY c_prod_no,
                C_BS_CUR, --c_cur_cde       ,
                c_ri_com,
                TRUNC(T_DUE_TM),
                C_CONT_CDE,
                c_doc_flag;

  BEGIN

    OPEN cur_ifribill;
    LOOP
      FETCH cur_ifribill
        INTO v_prod_no, v_cur_cde, v_ri_com, v_bal_tm, v_cont_code, v_doc_flag, v_get_fee;

      EXIT WHEN cur_ifribill%NOTFOUND;

      v_dpt_cde := '00000019';
      --?????
      Dz_Proc.get_fin_no(vTmpVouNo,v_dpt_cde,'7',dz_proc.g_pttype);

      --SELECT SQ_FIN_SHARE_DUE.NEXTVAL INTO vTmpVouNo FROM DUAL;

      IF v_doc_flag IN ('1', '6') THEN
        --?????
        v_get_fee := -v_get_fee;
      END IF;

      v_bal_tm := TRUNC(v_bal_tm);
      INSERT INTO WEB_FIN_RIBILL_DUE
        (c_dpt_cde,
         c_prod_no,
         C_BS_CUR,
         c_ri_com,
         c_bill_ym,
         C_CONT_CDE,
         c_doc_flag,
         N_BS_AMT,
         T_DUE_TM,
         c_rcpt_no)
      VALUES
        (v_dpt_cde,
         v_prod_no,
         v_cur_cde,
         v_ri_com,
         TO_CHAR(v_bal_tm, 'YYYYMM'),
         v_cont_code,
         v_doc_flag,
         v_get_fee,
         v_bal_tm,
         vTmpVouNo);

      UPDATE /*+ index (t_fin_share_due,I_FIN_SHARE_BALDPT) */ WEB_FIN_RICED_DUE
         SET c_vou_no = vTmpVouNo
       WHERE c_ri_com <> '9'
         AND C_FEETYP_CDE <> 'D9'
            --AND c_dpt_cde=v_dpt_cde
         AND c_prod_no = v_prod_no
         AND C_BS_CUR = v_cur_cde
         AND c_ri_com = v_ri_com
         AND T_DUE_TM >=
             TO_DATE(TO_CHAR(v_bal_tm, 'yyyy-mm-dd') || ' 00:00:00',
                     'YYYY-MM-DD HH24:MI:SS')
         AND T_DUE_TM <=
             TO_DATE(TO_CHAR(v_bal_tm, 'yyyy-mm-dd') || ' 23:59:59',
                     'YYYY-MM-DD HH24:MI:SS')
         AND C_CONT_CDE = v_cont_code
         AND c_doc_flag = v_doc_flag
         AND c_vou_no IS NULL;

      COMMIT;
    END LOOP;
    CLOSE cur_ifribill;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || vTmpVouNo || SQLERRM);
        ROLLBACK;

        v_err_content := 'proc:[gatherribill],??????[' || v_dpt_cde ||
                         v_prod_no || TO_CHAR(v_bal_tm) || v_ri_com ||
                         v_cur_cde || v_cont_code || '],?????[' ||
                         SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;
      END;

  END;


  --22.????
  PROCEDURE forceclosemonth IS
    v_tmp_cnt INT;

  BEGIN

    IF TRUNC(SYSDATE - 1, 'MM') = TRUNC(ADD_MONTHS(SYSDATE, -1)) THEN
      --????????
      UPDATE WEB_FIN_SAVEAMT_DUE
         SET c_lx_flag = '0'
       WHERE c_feetyp_cde = 'G'
         AND n_paid_amt < 0
         and not exists
       (SELECT c_ply_no
                from WEB_EDR_BASE
               WHERE c_ply_no = WEB_FIN_SAVEAMT_DUE.c_ply_no
                 and c_edr_rsn in ('A1', 'A3', '77'));

      --????????
      SELECT COUNT(*)
        INTO v_tmp_cnt
        FROM WEB_FIN_MONTHLYCLOSING
       WHERE c_period_name = TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'yyyy-mm')
         AND c_closing_flag = '1';

      IF v_tmp_cnt > 0 THEN
        UPDATE WEB_FIN_MONTHLYCLOSING
           SET c_period_name  = TO_CHAR(SYSDATE, 'YYYY-MM'),
               c_closing_flag = '1'
         WHERE c_period_name = TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'yyyy-mm')
           AND c_closing_flag = '1';

      END IF;

      --??????
      SELECT COUNT(*)
        INTO v_tmp_cnt
        FROM WEB_BAS_FIN_ACCT_PERIOD
       WHERE c_period_name = TO_CHAR(SYSDATE, 'YYYY-MM');

      IF v_tmp_cnt = 0 THEN
        insert into WEB_BAS_FIN_ACCT_PERIOD
          (c_period_name,
           t_bgn_tm,
           t_end_tm,
           c_crt_cde,
           t_crt_tm,
           c_upd_cde,
           t_upd_tm)
        values
          (TO_CHAR(SYSDATE, 'YYYY-MM'),
           trunc(sysdate),
           trunc(ADD_MONTHS(SYSDATE, 1) - 1),
           'admin',
           sysdate,
           'admin',
           sysdate);
      END IF;

    END IF;

  END;

  --???????????
  PROCEDURE cancelmonths IS
    --????????????

    v_seq_no      web_fin_madcr_intf.c_seq_no%TYPE;
    v_vou_no      web_fin_madcr_intf.c_vou_no%TYPE;
    v_company_cde web_fin_madcr_intf.c_company_cde%TYPE;
    v_period_name web_fin_madcr_intf.c_period_name%TYPE;
    v_voucher_no  WEB_FIN_MADCR.c_voucher_no%TYPE;
    v_succsflag   INT;
    v_err_content WEB_BAS_FIN_ERRORLOG.c_err_content%TYPE;

    CURSOR cur_ifchrg IS
      SELECT DISTINCT c_vou_no, c_company_cde
        FROM web_fin_madcr_intf
       WHERE c_con_dpt_cde IS NULL
         AND t_crt_tm = trunc(sysdate, 'MM') - 1 --to_date('2007-04-30','YYYY-MM-DD')
         AND c_check_flag = '2'
         AND c_servicetype_no = '1101';
  BEGIN
    return;
    /*
    ?????????
    --?????
    IF TRUNC(SYSDATE-1,'MM')<>TRUNC(ADD_MONTHS(SYSDATE,-1)) THEN
      RETURN;
    END IF;
    */

    IF trunc(sysdate, 'MM') + 14 <> TRUNC(SYSDATE) THEN
      return;
    END IF;

    /*3???????*/
    OPEN cur_ifchrg;
    LOOP
      FETCH cur_ifchrg
        INTO v_vou_no, v_company_cde;
      EXIT WHEN cur_ifchrg%NOTFOUND;

      SELECT TO_CHAR(ADD_MONTHS(t_crt_tm, 1), 'YYYY-MM')
        INTO v_period_name
        FROM web_fin_madcr_intf
       WHERE c_vou_no = v_vou_no
         AND ROWNUM = 1;

      Dz_Proc.get_FIN_prevoucode(v_voucher_no,
                                 v_period_name,
                                 v_company_cde,
                                 dz_proc.g_pttype);

      INSERT INTO WEB_FIN_MADCR
        (c_seq_no,
         c_item_no,
         c_cav_flag,
         c_sbjt_no,
         n_amt,
         c_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_dpt_cde,
         c_rcpt_no,
         c_sls_cde,
         c_prod_no,
         c_cha_cls,
         c_cha_cde,
         C_SALEGRP_CDE,

         c_ri_com,
         c_cont_code,
         c_vou_no,
         c_send_flag,
         t_end_tm,
         c_bsns_typ,
         c_pay_prsn_name,
         c_sbjt_memo,
         c_ply_no,
         c_cha_mrk,
         --zmh         c_finbank_cde      ,
         c_vou_memo,
         c_company_cde,
         c_cost_cde,
         c_current_dpt_cde,
         c_con_dpt_cde,
         c_check_flag,
         c_period_name,
         c_voucher_no,
         n_total_amt,
         c_servicetype_no,
         c_department_cde,
         c_kind_no)
        SELECT 'C' || c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_rcpt_no,
               c_sls_cde,
               c_prod_no,
               c_cha_cls,
               c_cha_cde,
               C_SALEGRP_CDE,

               c_ri_com,
               c_cont_code,
               'C' || c_vou_no,
               c_send_flag,
               t_end_tm,
               c_bsns_typ,
               c_pay_prsn_name,
               c_sbjt_memo,
               c_ply_no,
               c_cha_mrk,
               --zmh                   c_finbank_cde      ,
               c_vou_memo,
               c_company_cde,
               c_cost_cde,
               c_current_dpt_cde,
               c_con_dpt_cde,
               '3',
               c_period_name,
               v_voucher_no,
               n_total_amt,
               c_servicetype_no,
               c_department_cde,
               c_kind_no
          FROM WEB_FIN_MADCR
         WHERE c_voucher_no = v_vou_no;

      INSERT INTO web_fin_madcr_intf
        (c_seq_no,
         c_item_no,
         c_cav_flag,
         c_sbjt_no,
         c_sbjt_memo,
         n_amt,

         c_cur_no,
         t_crt_tm,
         c_dptacc_no,
         c_dpt_cde,
         c_ri_com,
         c_prod_no,
         ts,
         c_send_flag,
         c_vou_no,
         c_cont_code,
         c_cha_mrk,
         c_bsns_typ,
         C_SALEGRP_CDE,
         c_vou_memo,
         c_company_cde,
         c_cost_cde,
         --zmh         c_current_dpt_cde      ,
         t_vou_date,
         c_con_dpt_cde,
         c_check_flag,
         c_send_memo,
         c_period_name,
         --zmh         C_CAV_no               ,
         set_of_books_id,
         actual_flag,
         user_je_category_name,
         user_je_source_name,
         chart_of_accounts_id,
         n_total_amt,
         c_servicetype_no,
         c_department_cde,
         c_rcpt_no)
        SELECT 'C' || c_seq_no,
               c_item_no,
               c_cav_flag,
               c_sbjt_no,
               c_sbjt_memo,
               n_amt,
               c_cur_no,
               t_crt_tm,
               c_dptacc_no,
               c_dpt_cde,
               c_ri_com,
               c_prod_no,
               ts,
               c_send_flag,
               v_voucher_no,
               c_cont_code,
               c_cha_mrk,
               c_bsns_typ,
               C_SALEGRP_CDE,
               c_vou_memo,
               c_company_cde,
               c_cost_cde,
               --zmh         c_current_dpt_cde      ,
               t_vou_date,
               c_con_dpt_cde,
               '3',
               c_send_memo,
               c_period_name,
               --zmh         C_CAV_no               ,
               set_of_books_id,
               actual_flag,
               user_je_category_name,
               user_je_source_name,
               chart_of_accounts_id,
               n_total_amt,
               c_servicetype_no,
               c_department_cde,
               c_rcpt_no
          FROM web_fin_madcr_intf
         WHERE c_vou_no = v_vou_no;

      UPDATE WEB_FIN_MADCR
         SET n_amt         = -n_amt,
             n_total_amt   = -n_total_amt,
             c_voucher_no  = v_voucher_no,
             c_send_flag   = '0',
             t_end_tm      = SYSDATE,
             c_con_dpt_cde = '3',
             t_crt_tm      = TRUNC(ADD_MONTHS(t_crt_tm, 1)),
             c_period_name = TO_CHAR(ADD_MONTHS(t_crt_tm, 1), 'YYYY-MM')
       WHERE c_voucher_no = v_voucher_no;

      UPDATE web_fin_madcr_intf
         SET n_amt         = -n_amt,
             n_total_amt   = -n_total_amt,
             c_vou_no      = v_voucher_no,
             c_send_flag   = '0',
             t_end_tm      = SYSDATE,
             c_con_dpt_cde = '3',
             t_crt_tm      = TRUNC(ADD_MONTHS(t_crt_tm, 1)),
             c_period_name = TO_CHAR(ADD_MONTHS(t_crt_tm, 1), 'YYYY-MM')
       WHERE c_vou_no = v_voucher_no;

      UPDATE WEB_FIN_MADCR
         SET c_con_dpt_cde = '3'
       WHERE c_voucher_no = v_vou_no;

      UPDATE web_fin_madcr_intf
         SET c_con_dpt_cde = '3'
       WHERE c_vou_no = v_vou_no;

      --???????????????
      ValidityCheckmaVou(v_voucher_no, v_succsflag);

      IF v_succsflag < 0 THEN
        ROLLBACK;
        v_err_content := 'proc:[cancelmonths],??????[' ||
                         TO_CHAR(v_succsflag) || v_vou_no || v_voucher_no ||
                         '],?????[' || SQLCODE || SQLERRM;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END IF;
      commit;

    END LOOP;
    CLOSE cur_ifchrg;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;

        v_err_content := 'proc:[EXCEPTION cancelmonths],??????[' ||
                         TO_CHAR(v_succsflag) || v_vou_no || v_voucher_no ||
                         '],?????[' || SQLCODE || SQLERRM;
        ROLLBACK;

        INSERT INTO WEB_BAS_FIN_ERRORLOG
          (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
        VALUES
          (F_Fin_Getcode('e'),
           '001', --??????
           '0000', --??????
           v_err_content,
           SYSDATE);
        COMMIT;

      END;

  END;

  --7.????
  PROCEDURE taxclose(v_end_tm     IN VARCHAR2,
                     v_dptacc_cde IN WEB_ORG_DPT.c_dpt_cde%TYPE,
                     v_crt_cde    IN WEB_FIN_MONTHLYCLOSING.c_upd_cde%TYPE,
                     v_succsflag  IN OUT NUMBER) IS

    v_tmp_cnt         INT;
    v_period_name     WEB_FIN_MONTHLYCLOSING.c_period_name%TYPE;
    v_end_time        WEB_BAS_FIN_ACCT_PERIOD.t_BGN_TM%TYPE;
    v_otherdptacc_cde WEB_ORG_DPT.c_dptacc_cde%TYPE;
    v_tend_tm         DATE; --????
    v_up_tm           DATE; --??????

    v_rcpt_no WEB_FIN_PRM_DUE.c_rcpt_no%type;
    v_ply_no  WEB_FIN_PRM_DUE.c_ply_no%type;
    v_edr_no  WEB_FIN_PRM_DUE.c_edr_no%type;

    --??????
    CURSOR cur_ccsInfo IS
      select b.c_rcpt_no--, b.c_ply_no, b.c_edr_no
        from WEB_FIN_CAV_BILL a, WEB_FIN_CAV_DOC b
       WHERE a.C_CAV_PK_ID = b.C_CAV_PK_ID
         and a.c_rp_type in ('101', '111', '112', '201')
         AND a.T_check_TM <= v_tend_tm
         AND a.c_dpt_cde = v_dptacc_cde
         and a.c_check_flag = '2'
            --AND b.c_prod_no in ('0316','0320')
         and exists (select c_rcpt_no
                from WEB_FIN_PRM_DUE
               where c_rcpt_no = b.c_rcpt_no
                 and n_other_amt <> 0
                 and c_prod_no in ('0316', '0320'))
         AND a.T_check_TM >= v_up_tm
     and 1=2;

  BEGIN
    /*
          //1.??
          //1.1.??????????????
          //1.2.????????????????????????????????????


        v_succsflag:
          0 ??
          -1  ????????????
          -2  ????????????????

          -9  ????
    */
    v_succsflag := 0;
    v_tend_tm   := TO_DATE(v_end_tm || ' 23:59:59', 'YYYY-MM-DD hh24:mi:ss');

    return ; --?????????  lzc add 2009-09-13

    IF v_tend_tm >= TRUNC(SYSDATE) THEN
      v_succsflag := -1;
      RETURN;
    END IF;

    SELECT COUNT(*)
      INTO v_tmp_cnt
      FROM WEB_FIN_CLOSETAX
     WHERE c_dpt_cde = v_dptacc_cde;

    IF v_tmp_cnt = 0 THEN
      v_up_tm := TO_DATE('2007-06-01 23:59:59', 'yyyy-mm-dd hh24:mi:ss');
    ELSE
      SELECT MAX(t_end_tm)
        INTO v_up_tm
        FROM WEB_FIN_CLOSETAX
       WHERE c_dpt_cde = v_dptacc_cde;
    END IF;

    IF v_tend_tm <= v_up_tm THEN
      v_succsflag := -2;
      RETURN;
    END IF;

    --??????
    INSERT INTO WEB_FIN_CLOSETAX
      (c_rcpt_no, c_dpt_cde, T_bgn_tm, T_end_tm, T_crt_tm, C_emp_cde)
    VALUES
      (v_dptacc_cde || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'),
       v_dptacc_cde,
       v_up_tm,
       v_tend_tm,
       SYSDATE,
       v_crt_cde);

    --??

    OPEN cur_ccsInfo;
    LOOP
      FETCH cur_ccsInfo
        INTO v_rcpt_no;
      EXIT WHEN cur_ccsInfo%NOTFOUND;


          UPDATE  WEB_FIN_PRM_DUE
            SET c_to_fin_flag='2', t_bln_tm=TRUNC(v_tend_tm)
            WHERE c_rcpt_no=v_rcpt_no
            and n_other_amt<>0
            and (c_to_fin_flag is null or c_to_fin_flag<>'2' );

    END LOOP;
    CLOSE cur_ccsInfo;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        RAISE;
        v_succsflag := -9;

        --dbms_output.put_line('exception'||TO_CHAR(i)||'*'||SRcptNo||SQLERRM);
        IF SQLCODE < 0 THEN
          v_succsflag := SQLCODE;
        ELSE
          v_succsflag := -SQLCODE;
        END IF;
      END;
  END;

  --15 ??????????
  PROCEDURE modiglfee(v_mt_type     IN VARCHAR2,
                      v_company_cde IN VARCHAR2,
                      v_cur_dpt_cde IN VARCHAR2,
                      v_period_name IN VARCHAR2,
                      v_mix_amt     IN VARCHAR2,
                      v_dptacc_cde  IN VARCHAR2,
                      v_succsflag   IN OUT NUMBER)
  /*
    -1 ??????????oracle????????????????????
    -9 ??????,????!
    */
   IS

    v_tmp_cnt int;
    -- -1 ??????????oracle????????????????????
    -- -2 ??????????oracle???????????
    v_company_cde1 WEB_FIN_DCR.c_company_cde%type;

  BEGIN
    v_succsflag := 0;

    SELECT c_company_cde
      INTO v_company_cde1
      FROM WEB_ORG_DPT
     WHERE c_dptacc_cde = v_dptacc_cde
       and rownum = 1;

    IF v_dptacc_cde <> '00000019' THEN

      IF v_company_cde1 <> v_company_cde THEN
        v_succsflag := -2;
        return;
      END IF;
    END IF;

    SELECT COUNT(1)
      INTO v_tmp_cnt
      FROM web_fin_glinfo
     WHERE c_company_cde = v_company_cde
       AND c_cur_dpt_cde = v_cur_dpt_cde
       AND c_period_name = v_period_name;

    IF v_tmp_cnt = 0 THEN
      v_succsflag := -1;
      RETURN;
    END IF;
    IF v_mt_type = '1' THEN
      UPDATE web_fin_glinfo
         SET n_yy_ce = NVL(to_number(v_mix_amt), 0) - n_yy
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    ELSIF v_mt_type = '2' THEN
      UPDATE web_fin_glinfo
         SET n_sx_ce = NVL(to_number(v_mix_amt), 0) - n_sx
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    ELSIF v_mt_type = '3' THEN
      UPDATE web_fin_glinfo
         SET n_jjpf_ce = NVL(to_number(v_mix_amt), 0) - n_jjpf
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    ELSIF v_mt_type = '4' THEN
      UPDATE web_fin_glinfo
         SET n_byj_ce = NVL(to_number(v_mix_amt), 0) - n_byj
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    ELSIF v_mt_type = '5' THEN
      UPDATE web_fin_glinfo
         SET n_lcx_ce = NVL(to_number(v_mix_amt), 0) - n_lcx
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    ELSIF v_mt_type = '6' THEN
      UPDATE web_fin_glinfo
         SET n_knd_ce = NVL(to_number(v_mix_amt), 0) - n_knd
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    ELSIF v_mt_type = '7' THEN
      UPDATE web_fin_glinfo
         SET n_sj_ce = NVL(to_number(v_mix_amt), 0) - n_sj
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    ELSIF v_mt_type = '8' THEN
      UPDATE web_fin_glinfo
         SET n_ss_ce = NVL(to_number(v_mix_amt), 0) - n_ss
       WHERE c_company_cde = v_company_cde
         AND c_cur_dpt_cde = v_cur_dpt_cde
         AND c_period_name = v_period_name;
    END IF;

    /*
      1 ????
      2 ???
      3 ??????
      4 ???
      5 ?????
      6 ?????
      7 ??
      8 ????
    */

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        ROLLBACK;
        v_succsflag := -9;
        RETURN;

      END;
  END;

END Auto_Confirmed;
/
