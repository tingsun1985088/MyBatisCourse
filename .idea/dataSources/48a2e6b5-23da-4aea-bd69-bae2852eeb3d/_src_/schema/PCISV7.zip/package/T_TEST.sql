CREATE PACKAGE "T_TEST" 
IS
--4.?????????????????????? Collect in advance P_Fin_Precav
--PROCEDURE inadvance(vCavNo IN VARCHAR2,v_succsflag IN OUT NUMBER);

  Procedure Checkvou(vCavNo      IN VARCHAR2,
                     v_vou_out_no      IN OUT VARCHAR2,
                     v_succsflag IN OUT NUMBER) ;

END T_TEST;










/
