CREATE package body c_autowritebackwjfin is
  /***************************************************
  ************* 车理赔回写呼叫中心支付数据***********
  ***************add by zhangxin  20160613**********/
  days        number; --回写呼叫支付间隔（天）
  v_start_tm  date; --存过开始时间
  v_finish_tm date; --存过结果时间

  /**
  * 车理赔回写呼叫中心支付数据(开始逻辑)
  **/
  procedure auto_writebackwjfininfo is
    v_info           varchar2(3999); --提示信息
    v_c_rpt_no       web_vhlclm_main.c_rpt_no%type; --报案号
    v_historysuccess number; --历史数据成功条数（报案级统计）
    v_historyfailure number; --历史数据失败条数（报案级统计）
    v_success        number; --本次任务成功条数（报案级统计）
    v_failure        number; --本次任务失败条数（报案级统计）
    v_successcount   number; --计算历史,本次任务的成功过渡统计
    v_failurecount   number; --计算历史,本次任务的失败过渡统计
    /********抽取逻辑数据的报案号******/
    cursor cur_fininfo is
      select m.c_rpt_no
        from web_vhlclm_main m
       where exists
       (select 1
                from (select fin.claimNo
                        from web_fin_write_back fin
                       where fin.t_crt_tm>=v_start_tm
                         and fin.t_crt_tm< v_finish_tm
                         and datasource = 'AUTOCLAIM') fn
               where m.c_case_no = fn.claimNo)
         and not exists
       (select 0
                from (select mm.c_rpt_no
                        from web_vhlclm_main mm
                       where mm.c_case_state in ('0', '2')
                         and mm.c_rpt_no = m.c_rpt_no
                      union all
                      select nn.c_rpt_no
                        from web_vhlclm_main nn
                       where nn.c_case_state is null
                         and nn.c_rpt_no = m.c_rpt_no))
       --and m.c_rpt_no = '4100101000103300120160000035' --单测
       group by m.c_rpt_no;
  begin
    /********以业务规定来配置天数******/
    days := 3;
  
    /********初始化历史数据成功、失败条数，防止数据为空的现象******/
    v_historysuccess := 0;
    v_historyfailure := 0;
    v_success        := 0;
    v_failure        := 0;
    v_successcount   := 0;
    v_failurecount   := 0;
    /********取当前时间前3天当天的时间从零点（包含）到第二天的零点（不包含）******/
    select trunc(sysdate - (days + 1)) into v_start_tm from dual; --当前日期前4天，当天的凌晨
    select trunc(sysdate - days) into v_finish_tm from dual; --当前日期前3天，当天的凌晨
  
    /********定时任何之前先处理历史遗留的数据******/
    for crptnos in (select distinct c_rpt_no from hh_pending_hftask_log) loop
      main_writebackwjfininfo(crptnos.c_rpt_no,
                              v_historysuccess,
                              v_historyfailure);
      v_successcount := v_historysuccess + v_successcount;
      v_failurecount := v_failurecount + v_failurecount;
    end loop;
  
    /********结算历史成功失败条数******/
    v_historysuccess := v_successcount;
    v_historyfailure := v_failurecount;
    v_successcount   := 0;
    v_failurecount   := 0;
  
    /********开始处理本次任务数据******/
    open cur_fininfo;
    <<gotomrk>>
    loop
      fetch cur_fininfo
        into v_c_rpt_no;
      exit when cur_fininfo%notfound;
      /********车理赔回写呼叫中心支付数据(主逻辑)******/
      main_writebackwjfininfo(v_c_rpt_no, v_success, v_failure);
      v_successcount := v_success + v_successcount;
      v_failurecount := v_failure + v_failurecount;
    end loop;
    close cur_fininfo;
  
    /********结算本次任务成功失败条数******/
    v_success := v_successcount;
    v_failure := v_failurecount;
  
    /********保存日志信息******/
    into_fin_logInfo(sysdate,
                     '1',
                     '定时任务完成：历史数据~~成功' || v_historysuccess || '条,失败' ||
                     v_historyfailure || '条，本次任务~~成功' || v_success ||
                     '条，失败' || v_failure || '条');
  exception
    when others then
      rollback;
      v_finish_tm := sysdate; --记录结束时间
      v_info      := '';
      v_info      := v_info || sqlcode || ':' || substr(sqlerrm, 1, 3000);
      into_fin_logInfo(sysdate,
                       '0',
                       '定时任务出现异常，异常信息：' || v_info);
  end auto_writebackwjfininfo;

  /******************************************
  *  车理赔回写呼叫中心支付数据(主逻辑)
  *  v_c_rpt_no  入参  报案号
  *  v_success   出参  成功条数
  *  v_failure   出参  失败条数
  *  注：设计成功、失败条数，目的为赔案级
  *      报案级通用
  *******************************************/
  procedure main_writebackwjfininfo(v_c_rpt_no in varchar2,
                                    v_success  out number,
                                    v_failure  out number) is
    v_fin_write_back_info fin_write_back_info; --收付回写信息
    v_flag                varchar2(1); --判断标识，0-相等 1-不相等
    v_exist               varchar2(1); --是否存在标识 1-存在 0-不存在
    v_type                varchar2(1); --赔案对应的险种（0-交强 1-商业）
    v_counttype           number;      --报案号下赔案的个数
    v_number              number;      --循环次数
    v_custseqnums         number;      --支付唯一流水号个数
  begin
    /********查询收付回写信息******/
    queryfinwriteback(v_c_rpt_no, v_fin_write_back_info);
  
    /********判断应付与实付是否相等******/
    verdictamount(v_c_rpt_no, v_fin_write_back_info, v_flag);
    
    --初始化循环次数
    v_number :=0;
    
    if v_flag = '0' then
      /********通过报案号查询出所有的赔案号（赔案级）******/
      for v_claimNo in (select c_case_no
                          from web_vhlclm_main
                         where c_rpt_no = v_c_rpt_no) loop                 
        v_number:= v_number+1;
        /********判断赔案是交强还是商业******/
        verdictcasenotype(v_c_rpt_no,v_claimNo.c_Case_No,v_type,v_counttype);
        
        /*****判断是否赔付多笔，若有多笔，则循环取值*****/
        querycustseqcount(v_claimNo.c_Case_No, v_custseqnums);
        
        if v_custseqnums =1 then 
          /********查询支付唯一编号******/
          querycustseq(v_claimNo.c_Case_No, v_fin_write_back_info.v_custseq);
          main_sub_writebackwjfininfo(v_c_rpt_no,
                                      v_claimNo.c_Case_No,
                                      v_fin_write_back_info,
                                      v_number,
                                      v_counttype,
                                      v_success,
                                      v_failure);
        else
          for v_v_custseqs in (select distinct custseq
                                from web_fin_write_back
                               where claimno = v_claimNo.c_Case_No) loop
            v_fin_write_back_info.v_custseq:= v_v_custseqs.custseq;
            main_sub_writebackwjfininfo(v_c_rpt_no,
                                        v_claimNo.c_Case_No,
                                        v_fin_write_back_info,
                                        v_number,
                                        v_counttype,
                                        v_success,
                                        v_failure);
          end loop;
        end if;
        
      end loop;
    else
      /********判断数据是否已经存在赔案信息中******/
      verdictdateexist(v_c_rpt_no, v_exist);
      if v_exist <> '1' then
        /********保存应付与实付不相等的赔案信息******/
        into_hh_pending_hftask_log(v_c_rpt_no, '1', '应付与实付不相等');
      end if;
      v_failure := v_failure + 1;
    end if;
  
    /********换算统计因子为：报案级******/
    if v_success > 1 then
      v_success := 1;
    end if;
  
    if v_failure > 1 then
      v_failure := 1;
    end if;
  
  end main_writebackwjfininfo;
  
  /***************************************************
  *  车理赔回写呼叫中心支付数据(主逻辑-多次赔付分支)
  *  v_c_rpt_no  入参  报案号
  *  v_c_case_no 入参  赔案号
  *  v_custseq   入参  支付唯一编号
  *  v_number    入参  报案下赔案的循环次数
  *  v_counttype 入参  报案号下赔案的个数
  *  v_success   出参  成功条数
  *  v_failure   出参  失败条数
  *  注：设计成功、失败条数，目的为赔案级
  *      报案级通用
  ***************************************************/
  procedure main_sub_writebackwjfininfo(v_c_rpt_no            in  varchar2,
                                        v_c_case_no           in  varchar2,
                                        v_fin_write_back_info in  fin_write_back_info,
                                        v_number              in  number,
                                        v_counttype           in  number,
                                        v_success             out number,
                                        v_failure             out number) is
  v_vhlclm_income_info  vhlclm_income_info; --收款人信息
  v_flag                varchar2(1); --判断标识，0-相等 1-不相等
  v_exist               varchar2(1); --是否存在标识 1-存在 0-不存在
  v_saveflag            varchar2(1); --回写表是否成功标识，0-成功  1-失败
  v_info                varchar2(3999); --提示信息
  v_type                varchar2(1); --赔案对应的险种（0-交强 1-商业）
  v_jq_custseq          web_fin_write_back.custseq%type;
  v_sy_custseq          web_fin_write_back.custseq%type;
  m_fin_write_back_info fin_write_back_info;
  begin
    /********初始化成功、失败条数******/
    v_success := 0;
    v_failure := 0;
    
    if v_fin_write_back_info.v_custseq is null then
      --单交强或单商业
      if v_counttype = 1 then 
        /********判断数据是否已经存在赔案信息中******/
        verdictdateexist(v_c_rpt_no, v_exist);
        if v_exist <> '1' then
           /***设置详细提示信息***/
           if v_type = '0' then
             v_info :='交强险支付唯一编号不存在，';
           elsif v_type = '1' then 
             v_info :='商业险支付唯一编号不存在，';
           end if;
           /********保存应付与实付不相等的赔案信息******/
           into_hh_pending_hftask_log(v_c_rpt_no, '1', v_info || '请联系管理员或收付人员！');
           v_failure := v_failure + 1;
        end if;
        goto next;
      else--交强+商业
         if v_type='0' then 
           v_jq_custseq :=v_fin_write_back_info.v_custseq;--交强支付唯一编号
         elsif v_type = '1' then  
           v_sy_custseq :=v_fin_write_back_info.v_custseq;--商业支付唯一编号
         end if;
         /***如果未循环完毕，则直接进入下一次循环***/
         if v_counttype <> v_number then
           goto next;
         else/***循环完毕***/
             /***只要交强+商业，其中有一个支付号为空，则失败,且设置详细提示信息***/
             v_info :='';
             if v_jq_custseq is null then
               v_info :=v_info || '交强险支付唯一编号不存在，';
             elsif v_sy_custseq is null then
               v_info :=v_info || '商业险支付唯一编号不存在，';
             end if;
                 
             /********判断数据是否已经存在赔案信息中******/
             verdictdateexist(v_c_rpt_no, v_exist);
             if v_exist <> '1' then
                 /********保存应付与实付不相等的赔案信息******/
                 rollback;--防止第一次数据插入成功
                 into_hh_pending_hftask_log(v_c_rpt_no, '1', v_info || '请联系管理员或收付人员！');
                 v_success := 0;
                 v_failure := v_failure + 1;
             end if;
             goto next;
         end if;
      end if;
    else
      if v_type='0' then 
         v_jq_custseq :=v_fin_write_back_info.v_custseq;
      else
         v_sy_custseq :=v_fin_write_back_info.v_custseq;
      end if;
    end if;
        
    /********根据支付唯一编号查询收款人信息*********/
    queryInComemassage(v_fin_write_back_info.v_custseq,
                       v_vhlclm_income_info);
    
    if v_vhlclm_income_info.v_crptno is null then
      goto next;
    end if;                   
                       
    /********查询实付信息*********/                 
    queryfinwritebackinfo(v_fin_write_back_info.v_custseq,
                          v_c_case_no,
                          m_fin_write_back_info);  
    /********判断回写呼叫中心收付中间表是否已存在此数据******/
    begin
      select distinct 1
        into v_flag
        from hh_hftask
       where pay_no = v_fin_write_back_info.v_custseq;
    exception
      when no_data_found then
        v_flag := '0';
    end;
      
    if v_flag = '0' then
      /********回写前判断 交强+商业 是否都已经赔案完成******/
      if v_counttype <> v_number then 
        /********回写呼叫中心收付中间表******/
        into_hh_hftask(m_fin_write_back_info,
                       v_vhlclm_income_info,
                       '1',
                       v_saveflag,
                       v_info);
      else
        /********回写呼叫中心收付中间表******/
        into_hh_hftask(m_fin_write_back_info,
                       v_vhlclm_income_info,
                       '0',
                       v_saveflag,
                       v_info);
      end if;
        
      if v_saveflag = '0' then
        /********删除hh_pending_hftask_log表信息******/
        delete hh_pending_hftask_log where c_rpt_no = v_c_rpt_no;
        commit;
        v_success := v_success + 1;
      elsif v_saveflag = '2' then 
        v_success := v_success + 1;
        goto next;
      else
        /********判断数据是否已经存在赔案信息中******/
        verdictdateexist(v_c_rpt_no, v_exist);
        if v_exist <> '1' then
          into_hh_pending_hftask_log(v_c_rpt_no,
                                     '2',
                                     '回写保存失败信息:' || v_info);
          v_failure := v_failure + 1;
        end if;
      end if;
    end if;
    <<next>>
    null;
  end main_sub_writebackwjfininfo;
  
  
  /******************************************
  **  查询收付回写信息
  **  v_c_rpt_no 入参  报案号
  **  v_fin_write_back_info  出参  实付信息
  *******************************************/
  procedure queryfinwriteback(v_c_rpt_no            in varchar2,
                              v_fin_write_back_info out fin_write_back_info) is
  begin
    begin
      select sum(fin.baserealamount) as baserealamount
        into v_fin_write_back_info.v_baserealamount
        from web_fin_write_back fin,Web_Vhlclm_Income i
       where 
       fin.custseq = i.c_fin_custseq
       and i.c_ic_typ in ('171','172','173','174')
       and claimNo in (select c_case_no
                           from web_vhlclm_main
                          where c_rpt_no = v_c_rpt_no)
         and datasource = 'AUTOCLAIM'
         and fin.opflag not in ('1', '3');
    exception
      when no_data_found then
        v_fin_write_back_info.v_baserealamount := 0;
    end;
  end queryfinwriteback;
  
  /*************************************************
  * *************** 查询实付信息********************
  *  v_custseq              入参  客户序号
  *  v_c_case_no            入参  赔案号
  *  v_fin_write_back_info  出参  实付信息
  *************************************************/
  procedure queryfinwritebackinfo(v_custseq             in  varchar2,
                                  v_c_case_no           in  varchar2,
                                  v_fin_write_back_info out fin_write_back_info) is
  begin
    v_fin_write_back_info.v_custseq := v_custseq;
    select sum(wfw.baserealamount),
           max(wfw.t_crt_tm),
           '2'
      into v_fin_write_back_info.v_baserealamount,
           v_fin_write_back_info.v_tfintime,
           v_fin_write_back_info.v_opflag
      from web_fin_write_back wfw
     where wfw.claimNo = v_c_case_no
       and wfw.custseq = v_custseq
       and wfw.datasource = 'AUTOCLAIM'
       and wfw.opflag not in ('1', '3');
  end queryfinwritebackinfo;
  
  /**************************************
  *  判断是否赔付多笔，若有多笔，则循环取值
  *  v_claimno     入参  赔案号
  *  v_custseqnums 出参  支付流水号个数
  ***************************************/
  procedure querycustseqcount(v_claimno in varchar2, v_custseqnums out number) is
  begin
    select count(custseq) 
      into v_custseqnums
      from web_fin_write_back
     where claimno = v_claimno;
  end querycustseqcount;
  
  /**************************************
  *  查询支付唯一编号
  *  v_claimno 入参  赔案号
  *  v_custseq 出参  支付流水号
  ***************************************/
  procedure querycustseq(v_claimno in varchar2, v_custseq out varchar2) is
  begin
    begin
      select distinct custseq
        into v_custseq
        from web_fin_write_back
       where claimno = v_claimno;
    exception
      when no_data_found then
        v_custseq := '';
    end;
  end querycustseq;
  
  /*****************************************
  *  判断案件号是交强还是商业
  *  v_c_rpt_no   入参    报案号
  *  v_c_case_no  入参    赔案号
  *  v_type       出参    赔案号所属险种  0-交强  1-商业  2-交商联合  3-不存在
  *  v_counttyp   出参    报案号下赔案的个数
  ******************************************/
  procedure verdictcasenotype(v_c_rpt_no          in varchar2,
                              v_c_case_no         in varchar2,
                              v_type              out varchar2,
                              v_counttyp          out number) is
  begin
    begin
    select c_ply_typ
      into v_type
      from web_vhlclm_main
     where c_case_No = v_c_case_no;
    exception
      when no_data_found then
        v_type := '3';
    end;
    
    select count(c_ply_typ)
     into v_counttyp
     from web_vhlclm_main
    where c_rpt_no =v_c_rpt_no;
  end verdictcasenotype;

  /*****************************************
  *  判断应付与实付是否相等
  *  v_c_rpt_no    入参   报案号
  *  v_fin_write_back_info 入参  实付信息
  *  v_flag        出参   是否相等标识
  ******************************************/
  procedure verdictamount(v_c_rpt_no            in varchar2,
                          v_fin_write_back_info in fin_write_back_info,
                          v_flag                out varchar2) is
    v_amount mm_chargedetail_ti.amount%type; --应付金额
  begin
    select sum(amount)
      into v_amount
      from mm_chargedetail_ti ct
     where ct.seqcharge in
           (select lt.id
              from mm_policylist_ti lt,web_vhlclm_income i
             where 
             lt.custseq  = i.c_fin_custseq
             and i.c_ic_typ in ('171','172','173','174')
             and lt.seqpolicy in
                   (select ti.id
                      from mm_policy_ti ti
                     where ti.CLAIMNO in
                           (select c_case_no
                              from web_vhlclm_main
                             where c_rpt_no = v_c_rpt_no
                               and c_case_state in('1','3'))));
    if v_amount = v_fin_write_back_info.v_baserealamount then
      v_flag := 0;
    else
      v_flag := 1;
    end if;
  end verdictamount;

  /*************************************
  *  判断数据是否已经存在赔案信息中
  *  v_c_rpt_no  入参   报案号
  *  v_exist     出参   是否存在标识
  **************************************/
  procedure verdictdateexist(v_c_rpt_no in varchar2, v_exist out varchar2) is
  begin
    begin
      select distinct 1
        into v_exist
        from hh_pending_hftask_log
       where c_rpt_no = v_c_rpt_no;
    exception
      when no_data_found then
        v_exist := '0';
    end;
  end verdictdateexist;

  /*****************************************
  *  根据支付唯一编号查询收款人信息
  *  v_custseq   入参   支付流水号
  *  v_vhlclm_income_info  出参  收款人信息
  ******************************************/
  procedure queryInComemassage(v_custseq            in varchar2,
                               v_vhlclm_income_info out vhlclm_income_info) is
  begin
    begin
      select b.c_inc_nme,
             b.c_tel,
             b.c_ic_typ,
             b.c_amt_typ,
             b.c_inc_bank_nme,
             b.c_bank_num,
             b.c_rpt_no
        into v_vhlclm_income_info.v_cincnme, --收款人姓名
             v_vhlclm_income_info.v_ctel, --联系电话
             v_vhlclm_income_info.v_cictyp, --收款人类型（被保险人、受益人、三者、其他）
             v_vhlclm_income_info.v_camttyp, --款项类型（正常赔款、预付、垫付）
             v_vhlclm_income_info.v_cincbanknme, --开户行名称
             v_vhlclm_income_info.v_cbanknum, --银行账号
             v_vhlclm_income_info.v_crptno --报案号
        from web_vhlclm_income b
       where b.c_fin_custseq = v_custseq
         and b.c_ic_typ in
             ('171', '172', '173', '174', '176', '177', '178');
    exception
      when no_data_found then
      v_vhlclm_income_info.v_crptno:='';
    end;
  end queryInComemassage;

  /*****************************************
  *  回写呼叫中心收付中间表
  *  v_fin_write_back_info 入参  实付信息
  *  v_vhlclm_income_info  入参  收款人信息
  *  v_flag  出参  是否成功标识
  *  v_info  出参  失败详细原因
  ******************************************/
  procedure into_hh_hftask(v_fin_write_back_info in fin_write_back_info,
                           v_vhlclm_income_info  in vhlclm_income_info,
                           v_commitflag          in varchar2,
                           v_flag                out varchar2,
                           v_info                out varchar2) is
  begin
    v_info := '';
    begin
      insert into hh_hftask
        (rec_guid,
         flag,
         createdby,
         createddate,
         tasktype,
         payee,
         contactmobile,
         recipienttype,
         moneytype,
         bankcard,
         bankcard_number,
         paydate,
         crptno,
         paystatus,
         payamount,
         pay_no)
      values
        (sys_guid() || 'AAAA', --主键id
         0,
         'CENTER', --创建人
         sysdate, --创建时间
         '2',
         v_vhlclm_income_info.v_cincnme, --收款人姓名
         v_vhlclm_income_info.v_ctel, --联系电话
         v_vhlclm_income_info.v_cictyp, --收款人类型
         v_vhlclm_income_info.v_camttyp, --款项类型
         v_vhlclm_income_info.v_cincbanknme, --开户行名称
         v_vhlclm_income_info.v_cbanknum, --银行账号
         v_fin_write_back_info.v_tfintime, --支付时间
         v_vhlclm_income_info.v_crptno, --报案号
         v_fin_write_back_info.v_opflag, --支付状态
         v_fin_write_back_info.v_baserealamount, --支付金额
         v_fin_write_back_info.v_custseq); --支付号
      if v_commitflag='0' then 
        commit;
        v_flag := '0'; --成功
      else 
        v_flag := '2'; --未执行
      end if;
    exception
      when others then
        v_info := v_info || sqlcode || ':' || substr(sqlerrm, 1, 3000);
        v_flag := '1'; --失败
    end;
  end into_hh_hftask;

  /****************************************
  *  保存回写呼叫中心支付数据处理异常信息
  *  v_c_rpt_no  入参   报案号
  *  v_c_flag    入参   失败原因分类
  *  v_c_error_msg 入参  失败详细原因
  *****************************************/
  procedure into_hh_pending_hftask_log(v_c_rpt_no    in varchar2,
                                       v_c_flag      in varchar2,
                                       v_c_error_msg in varchar2) is
  begin
    insert into hh_pending_hftask_log
      (c_id,
       c_rpt_no,
       c_flag,
       c_failure_msg,
       c_crt_cde,
       t_crt_tm,
       c_upd_cde,
       t_upd_tm)
    values
      (sys_guid(),
       v_c_rpt_no,
       v_c_flag,
       v_c_error_msg,
       'system',
       sysdate,
       'system',
       sysdate);
    commit;
  end into_hh_pending_hftask_log;

  /***************************************
  *  保存日志信息
  *  v_c_back_tm 入参  定时任务完成时间
  *  v_c_states 入参  定时任务成功失败标识 
  *  v_c_error_msg 入参   失败详细原因
  ****************************************/
  procedure into_fin_logInfo(v_c_back_tm   in varchar2,
                             v_c_states    in varchar2,
                             v_c_error_msg in varchar2) is
  begin
    insert into web_vhlclm_write_back_wj_fin
      (c_id,
       c_back_tm,
       c_states,
       c_error_msg,
       c_crt_cde,
       t_crt_tm,
       c_upd_cde,
       t_upd_tm,
       c_trans_mrk,
       t_trans_tm)
    values
      (sys_guid(),
       v_c_back_tm,
       v_c_states,
       v_c_error_msg,
       'SYSTEM',
       sysdate,
       'SYSTEM',
       sysdate,
       '',
       '');
    commit;
  end into_fin_logInfo;

end c_autowritebackwjfin;
/
