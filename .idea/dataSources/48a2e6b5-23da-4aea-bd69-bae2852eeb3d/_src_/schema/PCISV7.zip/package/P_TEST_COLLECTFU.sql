CREATE PACKAGE "P_TEST_COLLECTFU" is
--1.???? Generate a voucher p_fin_cavvou
PROCEDURE Generateavoucher(vCavNo IN VARCHAR2,v_succsflag IN OUT NUMBER);

end P_test_COLLECTFU;










/
