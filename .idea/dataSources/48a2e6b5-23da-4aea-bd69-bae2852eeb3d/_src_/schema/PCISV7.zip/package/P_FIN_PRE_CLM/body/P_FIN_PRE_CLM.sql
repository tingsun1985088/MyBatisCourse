CREATE package body p_fin_pre_clm is
  t_today_tm                date;
  v_kind_no                 varchar2(10);
  v_dpt_cde                 varchar2(20);
  v_dpt_three               varchar2(20);
  v_prod_no                 varchar2(10);
  v_clm_no                  varchar2(50);
  v_ply_no                  varchar2(50);
  v_insrnc_bgn_tm           date;
  v_insrnc_end_tm           date;
  v_cvrg_no                 varchar2(10);
  v_inwd_mrk                varchar2(10);
  v_stk_mrk                 varchar2(10);
  v_pend                     number(20,2);
  v_clmfee                  number(20,2);
  v_rpt_tm                  date;
  v_accdnt_tm               date;
  v_rgst_tm                 date;
  v_err_content             varchar2(500);
  v_grp_mrk                 varchar2(10);
  v_end_tm                  date;
  ---------------------------------------------------------------------------------
  procedure p_fin_novhl_pend(v_today in varchar2,v_return out varchar2)
    is 
    cursor cur_clm is
    select --非车未决明细(非分人)
         a.c_clm_no,
         a.c_ply_no,
         a.t_insrnc_bgn_tm m,
         a.t_insrnc_end_tm,
         a.c_dpt_cde,
         a.c_kind_no,
         a.c_prod_no,
         pend.c_cvrg_no,
         (select nvl(applic.c_stk_mrk,0) from web_ply_applicant applic 
         where applic.c_ply_no=a.c_ply_no and applic.n_edr_prj_no=a.n_edr_prj_no ) as c_stk_mrk,
         nvl(a.c_inwd_mrk,'0') as c_inwd_mrk,
         nvl(pend.n_this_pend, 0) as n_nopay,
         nvl(pend.n_clmfee, 0) as n_noclmfee,
         accdnt.t_accdnt_tm,
         rpt.t_rpt_tm,
         RGST.T_RGST_TM
    from web_clm_pend   pend,
         web_clm_main   a,
         web_clm_rpt    rpt,
         web_clm_accdnt accdnt,
         WEB_CLM_RGST   RGST
   where a.c_clm_no = pend.c_clm_no
     and a.c_inwd_mrk <> '1'
     and a.c_clm_no = rpt.c_clm_no
     and a.c_clm_no = accdnt.c_clm_no
     and a.c_clm_no = RGST.c_Clm_No(+)
     and pend.n_pend_tms =
         (select max(n_pend_tms)from web_clm_pend
           where c_clm_no = pend.c_clm_no and t_pend_tm <= t_today_tm)
     and pend.c_pend_source <> '6'
    and
     --撤销案件处理
      not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and trunc(c.t_cnl_tm)<=t_today_tm) or
            ( c.c_cnl_typ='1' and trunc(c.t_chk_tm) <=t_today_tm
             and ((c.t_renew_tm is not null and trunc(c.t_renew_tm) >t_today_tm) or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)from web_clm_cancel
                                 where trunc(t_chk_tm) <=t_today_tm
                                   and c_chk_conc = '0'and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1'))
            and  c.c_chk_conc = '0' )  and c_clm_no = a.c_clm_no)

union all
--非车未决明细(分人)
select   a.c_clm_no,
         a.c_ply_no,
         a.t_insrnc_bgn_tm,
         a.t_insrnc_end_tm,
         a.c_dpt_cde,
         a.c_kind_no,
         a.c_prod_no,
         pend.c_cvrg_no,
         (select nvl(applic.c_stk_mrk,0) from web_ply_applicant applic 
         where applic.c_ply_no=a.c_ply_no and applic.n_edr_prj_no=a.n_edr_prj_no ) as c_stk_mrk,--  股东标志,
         nvl(a.c_inwd_mrk,'0'),-- 分入标志,
         nvl(pend.n_this_pend, 0) ,--原币种未决赔款,
         nvl(pend.n_clmfee, 0) ,--原币种未决直接理赔费用,
         accdnt.t_accdnt_tm,-- 出险时间,
         rpt.t_rpt_tm, --报案时间,
         RGST.T_RGST_TM --立案时间
    from web_clm_pend   pend,
         web_clm_main   a,
         web_clm_rpt    rpt,
         web_clm_accdnt accdnt,
         WEB_CLM_RGST   RGST
   where a.c_clm_no = pend.c_clm_no
     and a.c_inwd_mrk = '1'
     and a.c_clm_no = rpt.c_clm_no
     and a.c_clm_no = accdnt.c_clm_no
     and a.c_clm_no = RGST.c_Clm_No(+)
     and pend.n_pend_tms =
         (select max(n_pend_tms)
            from web_clm_pend
           where c_clm_no = pend.c_clm_no
             and t_pend_tm <= t_today_tm)
    and pend.c_pend_source <> '6'
    and
     --撤销案件处理
    not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and trunc(c.t_cnl_tm)<=t_today_tm) or
            ( c.c_cnl_typ='1' and trunc(c.t_chk_tm) <=t_today_tm
             and ((c.t_renew_tm is not null and trunc(c.t_renew_tm) >t_today_tm) or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)
                                  from web_clm_cancel
                                 where t_chk_tm <=t_today_tm
                                   and c_chk_conc = '0'
                                   and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1'))
            and  c.c_chk_conc = '0' )  and c_clm_no = a.c_clm_no);
       
    begin
       delete from web_fin_clm_pre where c_mrk = '1' and c_kind_no <> '03';
       commit;
       t_today_tm:=to_date(v_today||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
       v_return:=1;
           open cur_clm;
            loop 
               fetch cur_clm 
                into v_clm_no,v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_kind_no,v_prod_no,
                     v_cvrg_no,v_stk_mrk,v_inwd_mrk,v_pend,v_clmfee,v_accdnt_tm,v_rpt_tm,v_rgst_tm ;
               exit when cur_clm%notfound;
               
           v_grp_mrk:='0';
           if v_kind_no = '06' then
              select nvl(a.c_grp_mrk,0) into v_grp_mrk from web_ply_base a where a.c_ply_no = v_ply_no and rownum = 1;
              --险类判断
              v_kind_no:=rpfunction.getKindNo(v_kind_no,v_prod_no,v_cvrg_no);
           end if;
           
           if substr(v_dpt_cde,1,4) <> '0199' then
              v_dpt_three:=substr(v_dpt_cde,1,4);
              v_dpt_cde:=substr(v_dpt_cde,1,2);
           else
              v_dpt_cde:='0199';
              v_dpt_three:='0199';
           end if;
           
           insert into web_fin_clm_pre
           (c_clm_no,c_rpt_no,c_ply_no,t_insrnc_bgn_tm,t_insrnc_end_tm,c_dpt_cde,c_dpt_three,
            c_kind_no,c_prod_no,c_cvrg_no,c_grp_mrk,c_stk_mrk,c_inwd_mrk,n_pend,c_pend_cur,
            n_pend_clmfee,n_pend_clmfee_cur,t_accdnt_tm,t_rpt_tm,t_rgst_tm,t_endcase_tm,c_mrk,T_CAL_TM) 
           values(
            v_clm_no,'---',v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_dpt_three,
            v_kind_no,v_prod_no,v_cvrg_no,v_grp_mrk,v_stk_mrk,v_inwd_mrk,v_pend,'01',--币种暂时默认为01
            v_clmfee,'01',v_accdnt_tm,v_rpt_tm,v_rgst_tm,null,'1',TRUNC(t_today_tm)
           ); 
           end loop;       
           close cur_clm;
      commit;
      exception
      When Others Then
      ROLLBACK;

      v_err_content:='proc:[p_fin_novhl_pend],出错流水号:['||v_today||'  '||v_clm_no||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end p_fin_novhl_pend;
  ---------------------------------------------------------------------------------
  procedure p_fin_vhl_pend(v_today in varchar2,v_return out varchar2)
    is 
    cursor cur_clm is
    select --未决赔款 车险       
       a.c_clm_no ,
       a.c_ply_no ,
       a.t_insrnc_bgn_tm,
       a.t_insrnc_end_tm,
       a.c_dpt_cde,
       '03',
       a.c_prod_no,
       ready.c_rdr_cde,
       (select nvl(applic.c_stk_mrk,0) from web_ply_applicant applic 
       where applic.c_ply_no=a.c_ply_no and rownum = 1 ) as c_stk_mrk,--股东标志,
       nvl(a.c_inwd_mrk,'0'),--分入标志,
        greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0)),--   原币种未决赔款,
       0,
       a.t_acdnt_tm,--出险时间,
       a.t_rpt_tm,--报案时间,
       a.T_RGST_TM--立案时间,
  from (select m.c_clm_no,
               m.c_ply_no,
               m.n_edr_prj_no,
               rpt.t_rpt_tm,
               endcase.t_end_tm,
               m.c_prod_no,
               m.c_kind_no,
               m.c_dpt_cde,
               m.t_insrnc_bgn_tm,
               rpt.t_acdnt_tm,
               RGST.T_RGST_TM,
               m.t_insrnc_end_tm,
               m.c_inwd_mrk
          from web_clm_main m
          left join WEB_CLM_RGST RGST
            on m.c_clm_no = rgst.c_clm_no
          left join web_clm_endcase_zm endcase
            on m.c_clm_no = endcase.c_clm_no
           and endcase.c_endcase_status = '03' --确认结案
           and endcase.c_end_type = '02', --正常结案
         web_clm_rpt_zm rpt

         where trunc(rpt.t_rpt_tm) <= t_today_tm
           and m.c_inwd_mrk = '0'
           and m.c_clm_no = rpt.c_clm_no) a,
       web_clm_ready_amt ready

 where (a.t_end_tm > t_today_tm or
       a.t_end_tm is null)
   and a.c_clm_no = ready.c_clm_main_id
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <=t_today_tm)
   and a.c_clm_no not in
       (select cncl.c_clm_main_id
          from web_clm_cncl cncl
         where cncl.t_check_tm <= t_today_tm
           and cncl.c_check_opn = '1')--确认标志
   and nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0) <> 0;
       
    begin
       delete from web_fin_clm_pre where c_mrk = '1' and c_kind_no = '03';
       commit;
       t_today_tm:=to_date(v_today||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
       v_return:=1;
           open cur_clm;
            loop 
               fetch cur_clm 
                into v_clm_no,v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_kind_no,v_prod_no,
                     v_cvrg_no,v_stk_mrk,v_inwd_mrk,v_pend,v_clmfee,v_accdnt_tm,v_rpt_tm,v_rgst_tm ;
               exit when cur_clm%notfound;
               
           v_grp_mrk:='0';--车险默认为0
           
           if substr(v_dpt_cde,1,4) <> '0199' then
              v_dpt_three:=substr(v_dpt_cde,1,4);
              v_dpt_cde:=substr(v_dpt_cde,1,2);
           else
              v_dpt_cde:='0199';
              v_dpt_three:='0199';
           end if;
           --车险与非车不一样
           if v_stk_mrk = '192002' then--股东
              v_stk_mrk:='1';
           else
              v_stk_mrk:='0';
           end if;
           
           insert into web_fin_clm_pre
           (c_clm_no,c_rpt_no,c_ply_no,t_insrnc_bgn_tm,t_insrnc_end_tm,c_dpt_cde,c_dpt_three,
            c_kind_no,c_prod_no,c_cvrg_no,c_grp_mrk,c_stk_mrk,c_inwd_mrk,n_pend,c_pend_cur,
            n_pend_clmfee,n_pend_clmfee_cur,t_accdnt_tm,t_rpt_tm,t_rgst_tm,t_endcase_tm,c_mrk,T_CAL_TM) 
           values(
            v_clm_no,'---',v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_dpt_three,
            v_kind_no,v_prod_no,v_cvrg_no,v_grp_mrk,v_stk_mrk,v_inwd_mrk,v_pend,'01',--币种暂时默认为01
            v_clmfee,'01',v_accdnt_tm,v_rpt_tm,v_rgst_tm,null,'1',TRUNC(t_today_tm)
           ); 
           end loop;       
           close cur_clm;
      commit;
      exception
      When Others Then
        ROLLBACK;

      v_err_content:='proc:[p_fin_vhl_pend],出错流水号:['||v_today||'  '||v_clm_no||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end p_fin_vhl_pend;
    ------------------------------------------------------------------------
    procedure p_fin_vhl_clm_jq(v_today in varchar2,v_return out varchar2)
    is 
    cursor cur_clm is
    select m.c_clm_no c_clm_no,--赔案号,
           m.c_ply_no c_ply_no,--保单号,
           m.t_insrnc_bgn_tm,--保单保险起期,
           m.t_insrnc_end_tm,--保单保险止期,
           m.c_dpt_cde,
           '03'   c_kind_no,--险类,
           '0320' as c_prod_no,
           duty.c_duty_cde,
           (select nvl(applic.c_stk_mrk,0) from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no and rownum = 1 ) as c_stk_mrk,--股东标志,
           nvl(m.c_inwd_mrk,'0') as c_inwd_mrk,--分入标志,
           nvl(duty.N_IC_AMT, 0) + nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0)+
           (case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                   decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0) else 0 end)
           n_pay_amt,--原币种已决赔款,
           CASE WHEN ic.N_YFJQ_AMT = 0 THEN
                 ic.T_FEE_AMT_CAL/(SELECT COUNT(1)FROM WEB_CLM_IC_RDR_DUTY_LST WHERE C_IC_RDR_LST_ID = ic.C_IC_ID)
                ELSE ic.T_FEE_AMT_CAL *
                               --无责代赔在2011-11-24前后的处理方式不同
                     case when trunc(ic.t_crt_tm)<=to_date('2011-11-24','yyyy-mm-dd') then
                                     decode(ic.N_YFJQ_AMT,0,0,(duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0))/ ic.N_YFJQ_AMT)
                                     else decode(ic.N_YFJQ_AMT,0,0,duty.n_ic_amt/ ic.N_YFJQ_AMT)
                     end
             END    n_clmfee_amt,--原币种已决直接理赔费用,
           rpt.t_acdnt_tm ,--出险时间,
           rpt.t_rpt_tm,--报案时间,
           RGST.T_RGST_TM ,--立案时间,
           endcase.t_end_tm--结案时间
      from web_clm_ic              ic,
           web_clm_main            m,
           web_clm_endcase_zm      endcase,
           web_clm_ic_rdr_duty_lst duty,
           web_clm_rpt_zm          rpt,
           web_clm_rgst            rgst--立案表
     where ic.c_clm_no = m.c_clm_no
       and ic.c_ic_id = duty.c_ic_rdr_lst_id
       and m.c_prod_no = '0320'
       and m.c_clm_no = endcase.c_clm_no
       and m.c_clm_no = rpt.c_clm_no
       and m.c_inwd_mrk = '0'
       and endcase.c_endcase_status = '03'
       and endcase.c_end_type in ('02', '03')
       and ic.c_ic_status = '03'
       and ic.c_ic_type in ('0', '5')
       and ic.n_ic_num = endcase.n_endcase_no
       and rpt.t_rpt_tm <= t_today_tm
       and endcase.t_end_tm <= t_today_tm
       and m.c_clm_no = rgst.c_clm_no;
       
    begin
       delete from web_fin_clm_pre where c_mrk = '2' and c_kind_no = '03' and c_prod_no = '0320';
       commit;
       t_today_tm:=to_date(v_today||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
       v_return:=1;
       open cur_clm;
          loop 
            fetch cur_clm 
              into v_clm_no,v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_kind_no,v_prod_no, 
                   v_cvrg_no,v_stk_mrk,v_inwd_mrk,v_pend,v_clmfee,v_accdnt_tm,v_rpt_tm,v_rgst_tm,v_end_tm ;
              exit when cur_clm%notfound;
               
           v_grp_mrk:='0';--车险默认为0
           
           if substr(v_dpt_cde,1,4) <> '0199' then
              v_dpt_three:=substr(v_dpt_cde,1,4);
              v_dpt_cde:=substr(v_dpt_cde,1,2);
           else
              v_dpt_cde:='0199';
              v_dpt_three:='0199';
           end if;
           --车险与非车不一样
           if v_stk_mrk = '192002' then--股东
              v_stk_mrk:='1';
           else
              v_stk_mrk:='0';
           end if;
           if v_clmfee + v_pend <> 0 then
             insert into web_fin_clm_pre
             (c_clm_no,c_rpt_no,c_ply_no,t_insrnc_bgn_tm,t_insrnc_end_tm,c_dpt_cde,c_dpt_three,
              c_kind_no,c_prod_no,c_cvrg_no,c_grp_mrk,c_stk_mrk,c_inwd_mrk,n_pend,c_pend_cur,
              n_pend_clmfee,n_pend_clmfee_cur,t_accdnt_tm,t_rpt_tm,t_rgst_tm,t_endcase_tm,c_mrk,T_CAL_TM) 
             values(
              v_clm_no,'---',v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_dpt_three,
              v_kind_no,v_prod_no,v_cvrg_no,v_grp_mrk,v_stk_mrk,v_inwd_mrk,v_pend,'01',--币种暂时默认为01
              v_clmfee,'01',v_accdnt_tm,v_rpt_tm,v_rgst_tm,v_end_tm,'2',TRUNC(t_today_tm)
             );
           end if;  
           end loop;       
           close cur_clm;
      commit;
      exception
      When Others Then
        ROLLBACK;

      v_err_content:='proc:[p_fin_vhl_clm_jq],出错流水号:['||v_today||'  '||v_clm_no||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end p_fin_vhl_clm_jq;
    ------------------------------------------------------------------------
    procedure p_fin_vhl_clm_sy(v_today in varchar2,v_return out varchar2)
    is 
    cursor cur_clm is
      select m.c_clm_no c_clm_no,--赔案号,
             m.c_ply_no c_ply_no,--保单号,
             m.t_insrnc_bgn_tm,--保单保险起期,
             m.t_insrnc_end_tm,--保单保险止期,
             m.c_dpt_cde,
             '03' ,--险类,
             m.c_prod_no,
             rdr.c_rdr_cde,--险别,
             (select nvl(applic.c_stk_mrk,0) from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no and rownum = 1 ) as c_stk_mrk,--股东标志,
             nvl(m.c_inwd_mrk,'0') as c_inwd_mrk,--分入标志,
             nvl(rdr.N_IC_AMT, 0) + nvl(rdr.n_prepay_amt, 0) n_pay_amt,--原币种已决赔款,
             CASE when (select count(1) from web_clm_other_fee_lst lst where lst.c_clm_link_id=ic.c_ic_id)=0 then 0 else (
                               case    WHEN ic.N_YFSY_AMT = 0 THEN
                                    ic.B_FEE_AMT_CAL /
                                    (SELECT COUNT(1)
                                       FROM WEB_CLM_IC_RDR_LST
                                      WHERE C_IC_ID = ic.C_IC_ID)
                                   ELSE
                                    ic.B_FEE_AMT_CAL *
                                    decode(ic.N_YFSY_AMT,
                                           0,
                                           0,
                                           rdr.n_ic_amt / ic.N_YFSY_AMT)
                                 END)end  /*payfee2,--*/n_clmfee_amt,--原币种已决直接理赔费用,
             rpt.t_acdnt_tm,--出险时间,
             rpt.t_rpt_tm,  --报案时间,
             RGST.T_RGST_TM, --立案时间,
             endcase.t_end_tm   --结案时间
        from web_clm_ic         ic,
             web_clm_main       m,
             web_clm_endcase_zm endcase,
             web_clm_ic_rdr_lst rdr,
             web_clm_rpt_zm     rpt,
             web_clm_rgst       rgst
       where ic.c_clm_no = m.c_clm_no
         and ic.c_ic_id = rdr.c_ic_id
         and m.c_clm_no = rpt.c_clm_no
         and m.c_clm_no = endcase.c_clm_no
         and m.c_inwd_mrk = '0'
         and endcase.c_endcase_status = '03'
         and endcase.c_end_type in ('02', '03')
         and ic.c_ic_status = '03'
         and ic.n_ic_num = endcase.n_endcase_no
         and rpt.t_rpt_tm <= t_today_tm
         and endcase.t_end_tm <= t_today_tm
         and m.c_clm_no = rgst.c_clm_no;
       
    begin
       delete from web_fin_clm_pre where c_mrk = '2' and c_kind_no = '03' and c_prod_no <> '0320';
       commit;
       t_today_tm:=to_date(v_today||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
       v_return:=1;
       open cur_clm;
          loop 
            fetch cur_clm 
              into v_clm_no,v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_kind_no,v_prod_no, 
                   v_cvrg_no,v_stk_mrk,v_inwd_mrk,v_pend,v_clmfee,v_accdnt_tm,v_rpt_tm,v_rgst_tm,v_end_tm ;
              exit when cur_clm%notfound;
               
           v_grp_mrk:='0';--车险默认为0
           
           if substr(v_dpt_cde,1,4) <> '0199' then
              v_dpt_three:=substr(v_dpt_cde,1,4);
              v_dpt_cde:=substr(v_dpt_cde,1,2);
           else
              v_dpt_cde:='0199';
              v_dpt_three:='0199';
           end if;
           --车险与非车不一样
           if v_stk_mrk = '192002' then--股东
              v_stk_mrk:='1';
           else
              v_stk_mrk:='0';
           end if;
           if v_clmfee + v_pend <> 0 then
             insert into web_fin_clm_pre
             (c_clm_no,c_rpt_no,c_ply_no,t_insrnc_bgn_tm,t_insrnc_end_tm,c_dpt_cde,c_dpt_three,
              c_kind_no,c_prod_no,c_cvrg_no,c_grp_mrk,c_stk_mrk,c_inwd_mrk,n_pend,c_pend_cur,
              n_pend_clmfee,n_pend_clmfee_cur,t_accdnt_tm,t_rpt_tm,t_rgst_tm,t_endcase_tm,c_mrk,T_CAL_TM) 
             values(
              v_clm_no,'---',v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_dpt_three,
              v_kind_no,v_prod_no,v_cvrg_no,v_grp_mrk,v_stk_mrk,v_inwd_mrk,v_pend,'01',--币种暂时默认为01
              v_clmfee,'01',v_accdnt_tm,v_rpt_tm,v_rgst_tm,v_end_tm,'2',TRUNC(t_today_tm)
             );
           end if;  
           end loop;       
           close cur_clm;
      commit;
      exception
      When Others Then
        ROLLBACK;

      v_err_content:='proc:[p_fin_vhl_clm_sy],出错流水号:['||v_today||'  '||v_clm_no||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end p_fin_vhl_clm_sy;
    ------------------------------------------------------------------------
    procedure p_fin_novhl_clm(v_today in varchar2,v_return out varchar2)
    is 
    cursor cur_clm is
      select --已决赔款 非车险
       a.c_clm_no  as c_clm_no,
       a.c_ply_no  as c_ply_no,
       a.t_insrnc_bgn_tm,
       a.t_insrnc_end_tm,
       a.c_dpt_cde,
       a.c_kind_no,
       a.c_prod_no,
       pend.c_cvrg_no,
        (select nvl(applic.c_stk_mrk,0) from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no and applic.n_edr_prj_no=a.n_edr_prj_no )   as c_stk_mrk,
       nvl(a.c_inwd_mrk,'0') as c_inwd_mrk,
       nvl(pend.n_this_dtmd, 0)  as n_pay,     --原币种已决赔款,
       nvl(pend.n_clmfee, 0)  as n_clmfee,    --原币种已决直接理赔费用,
       acc.t_accdnt_tm,--出险时间,
       rpt.t_rpt_tm,   --报案时间,
       RGST.T_RGST_TM,  --立案时间,
       endcase.t_endcase_tm

    from web_clm_pend pend,
         web_clm_rpt  rpt,
         web_clm_main a,
         web_clm_accdnt acc,
         web_clm_rgst rgst,
         web_clm_adjust adj,
         web_clm_endcase endcase
   where pend.c_clm_no = rpt.c_clm_no
     and a.c_inwd_mrk <> '1'
     and pend.c_pend_source = '6'
     AND rpt.t_rpt_tm <= t_today_tm
     and rpt.c_clm_no = a.c_clm_no
     and a.c_clm_no=acc.c_clm_no
     and a.c_clm_no = rgst.c_clm_no
     and adj.c_clm_no = a.c_clm_no
     and adj.n_clm_tms = a.n_clm_tms
     and adj.c_adjust_pk_id = endcase.c_adjust_pk_id
     and endcase.t_endcase_tm<=t_today_tm
     and endcase.c_clm_no = a.c_clm_no
    union all
    --已决赔款 非车险(分人)
    select a.c_clm_no  as c_clm_no,
           a.c_ply_no  as c_ply_no,
           a.t_insrnc_bgn_tm,
           a.t_insrnc_end_tm,
           a.c_dpt_cde,
           a.c_kind_no,
           a.c_prod_no,
           pend.c_cvrg_no,
           (select nvl(applic.c_stk_mrk,0) from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no
                  and applic.n_edr_prj_no=a.n_edr_prj_no )   as c_stk_mrk, --股东标志,
           nvl(a.c_inwd_mrk,'0') as c_inwd_mrk,
           nvl(pend.n_this_dtmd, 0)  as n_pay,     -- 原币种已决赔款,
           nvl(pend.n_clmfee, 0) as n_clmfee,    --原币种已决直接理赔费用,
           acc.t_accdnt_tm,--出险时间,
           rpt.t_rpt_tm, --报案时间,
           RGST.T_RGST_TM,--立案时间,
           endcase.t_endcase_tm

      from web_clm_pend pend,
           web_clm_rpt  rpt,
           web_clm_main a,
           web_clm_accdnt acc,
           web_clm_rgst rgst,
           web_clm_endcase endcase
     where pend.c_clm_no = rpt.c_clm_no
       and a.c_inwd_mrk = '1'
       and pend.c_pend_source = '6'
       AND rpt.t_rpt_tm <= t_today_tm
       and rpt.c_clm_no = a.c_clm_no
       and a.c_clm_no=acc.c_clm_no
       and a.c_clm_no = rgst.c_clm_no
       and endcase.t_endcase_tm<=t_today_tm;
       
    begin
       delete from web_fin_clm_pre where c_mrk = '2' and c_kind_no <> '03';
       commit;
       t_today_tm:=to_date(v_today||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
       v_return:=1;
       open cur_clm;
          loop 
            fetch cur_clm 
              into v_clm_no,v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_kind_no,v_prod_no, 
                   v_cvrg_no,v_stk_mrk,v_inwd_mrk,v_pend,v_clmfee,v_accdnt_tm,v_rpt_tm,v_rgst_tm,v_end_tm ;
              exit when cur_clm%notfound;
               
           v_grp_mrk:='0';
           if v_kind_no = '06' then
              select nvl(a.c_grp_mrk,0) into v_grp_mrk from web_ply_base a where a.c_ply_no = v_ply_no and rownum = 1;
              --险类判断
              v_kind_no:=rpfunction.getKindNo(v_kind_no,v_prod_no,v_cvrg_no);
           end if;
           
           if substr(v_dpt_cde,1,4) <> '0199' then
              v_dpt_three:=substr(v_dpt_cde,1,4);
              v_dpt_cde:=substr(v_dpt_cde,1,2);
           else
              v_dpt_cde:='0199';
              v_dpt_three:='0199';
           end if;
           
           if v_clmfee + v_pend <> 0 then
             insert into web_fin_clm_pre
             (c_clm_no,c_rpt_no,c_ply_no,t_insrnc_bgn_tm,t_insrnc_end_tm,c_dpt_cde,c_dpt_three,
              c_kind_no,c_prod_no,c_cvrg_no,c_grp_mrk,c_stk_mrk,c_inwd_mrk,n_pend,c_pend_cur,
              n_pend_clmfee,n_pend_clmfee_cur,t_accdnt_tm,t_rpt_tm,t_rgst_tm,t_endcase_tm,c_mrk,T_CAL_TM) 
             values(
              v_clm_no,'---',v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,v_dpt_cde,v_dpt_three,
              v_kind_no,v_prod_no,v_cvrg_no,v_grp_mrk,v_stk_mrk,v_inwd_mrk,v_pend,'01',--币种暂时默认为01
              v_clmfee,'01',v_accdnt_tm,v_rpt_tm,v_rgst_tm,v_end_tm,'2',TRUNC(t_today_tm)
             );
           end if;  
         end loop;       
        close cur_clm;
      commit;
      exception
      When Others Then
        ROLLBACK;

      v_err_content:='proc:[p_fin_novhl_clm],出错流水号:['||v_today||'  '||v_clm_no||'],错误描述：['||SQLCODE||SQLERRM;
      insert into web_bas_fin_errorlog
      (c_err_no,c_errtype_no,c_tran_type, c_err_content,t_crt_tm)
      VALUES('007','001','0000', v_err_content,SYSDATE);
      COMMIT;
      v_return := -1;
    end p_fin_novhl_clm;
end p_fin_pre_clm;
/
