CREATE package body mm_mirror_pkg is
  cst_reserve_type           constant pls_integer := '1'; /*储金切片类型*/
  cst_usable_type            constant pls_integer := '2'; /*预收切片类型*/
  cst_payable_type           constant pls_integer := '3'; /*贷付切片类型*/
  cst_policy_type            constant pls_integer := '4'; /*应收切片类型*/
  cst_reinsurance_type       constant pls_integer := '5'; /*再保切片类型*/
  cst_policydiffercence_type constant pls_integer := '9'; /*在途应收切片类型*/
  cst_prepaidfeepayable_type constant pls_integer := '10'; /*待摊手续费应付切片类型*/
  cst_docno_type             constant pls_integer := '11'; /*非保费用单据台账*/

  c_fixed_value constant number := 9990000000000; --c_fixed_value
  --v_startdate mm_mirror_td.mirrordate%type;
  c_month mm_mirror_td.opstatus%type;
  -----------------------------------------------------------------------------
  -- 应收台帐切片
  -- 参数说明:
  -- in_subcompany: 分公司代码
  -- in_enddate: 切片的时间
  -- in_check_type:校验切片类型.1:储金,2:预收,3:贷付,4:应收,5:再保
  -- out_startdate:上一个帐期末日期
  procedure check_restrict(in_subcompany in mm_mirror_td.subcompany%type,
                           in_enddate    in mm_mirror_td.mirrordate%type,
                           in_check_type in pls_integer,
                           out_startdate out nocopy mm_mirror_td.mirrordate%type,
                           out_c_month   out nocopy mm_mirror_td.opstatus%type) is
    accstatus mm_accperiod_td.isclosed%type := 'x';
    cnt_tmp   pls_integer := 0;
  begin
    IF false THEN
      out_startdate := DATE '1900-1-1';
      out_c_month   := 1;
    ELSE

      begin
        /*获取上个帐期的关帐日日期*/
        select isclosed, accenddate
          into accstatus, out_startdate
          from mm_accperiod_td
         where subcompany = in_subcompany
           and accountyearmonth =
               (select to_char(Add_months(to_date(accountyearmonth, 'YYYYMM'),
                                          -1),
                               'YYYYMM') accdate
                  from mm_accperiod_td
                 where in_enddate between accstartdate and accenddate
                   and subcompany = in_subcompany);
      exception
        when no_data_found then
          null;
      end;
      if out_startdate is not null then
        case accstatus
          when '0' then
            raise_application_error(-20001,
                                    '前个月还未关帐,不能切这个日期的台帐!');
          when '1' then
            begin
              /*主要检查是否切片表有上个帐期末的切片*/
              select mirrordate
                into out_startdate
                from mm_mirror_td
               where mirrortype = in_check_type
                 and mirrordate = out_startdate
                 and subcompany = in_subcompany;
            exception
              when no_data_found then
                /*没有则再判断上个帐期未之前有没有切片,
                有则说明上个帐期末未切片过,不允许切
                没有则说明此公司是第一次做切片,允许做切片*/
                select count(1)
                  into cnt_tmp
                  from mm_mirror_td
                 where mirrortype = in_check_type
                   and mirrordate < out_startdate
                   and subcompany = in_subcompany
                   and rownum = 1;
                if cnt_tmp > 0 then
                  raise_application_error(-20001,
                                          '上个帐期末' ||
                                          to_char(out_startdate, 'yy-mm-dd') ||
                                          '还未切片,不能切本月台帐!');
                else
                  out_startdate := null;
                end if;
            end;
          when '2' then
            raise_application_error(-20001, '正在月结,不能切片!');
          when '3' then
            raise_application_error(-20001, '请勿超前切片!');
          else
            raise_application_error(-20001,
                                    '帐期表有未预知的错误,请联系管理员!');
        end case;
      end if;
      /*判断是月切还是日切,日切为'0',月切为'1'*/
      begin
        select '1'
          into out_c_month
          from mm_accperiod_td
         where subcompany = in_subcompany
           and accenddate = in_enddate;
      exception
        when no_data_found then
          out_c_month := '0';
      end;
    END IF;
  end check_restrict;
  -----------------------------------------------------------------------------
  --应收台帐切片时有缴费计划的明细记录
  procedure handle_plan_accountage(mirrordate_in in mm_mirror_td.mirrordate%type,
                                   mirrorid_in   in mm_mirror_td.mirrorid%type) is
    i_remains_tmp     mm_plan_td.amount%type; --应收余额计算中间变量
    c_accountage      mm_bad_debts_list.accountage%type; --账龄
    i_accountdate     mm_bad_debts_list.accountdate%type; --账龄天数
    i_extract_percent mm_accountageset_tc.extract_percent%type; --坏账计提百分比
    i_extract_amount  mm_bad_debts_list.this_amount %type; --坏账计提金额
    i_listno                   mm_policymirror_td.listno%type;--listno中间变量
    tmp_date          date;
    tmp_date1         date;
  begin

  i_listno :=0;--chu shi hua

    for rec in (select count(1) over(partition by m.listno) cnt, --计算是否有有缴费计划
                       m.*,
                       row_number() over(partition by m.listno order by m.listno, p.datedate, p.thisseq) as thisseq, --p.thisseq, --第几期
                       p.amount plan_amount, --本期缴费计划金额
                       p.datedate --计划缴费日期
                  from mm_policymirror_td m
                  left join mm_plan_td p
                --on p.seqcharge = m.seqcharge
                    on p.custseq = m.custseq --20140329 缴费计划关联到 保单明细记录
               --     and p.opstatus in('1','2')
                 where m.businessattr = '1'
                   and m.mirrorid = mirrorid_in
                --order by m.listno, p.thisseq
                 order by m.listno, p.datedate desc, p.thisseq desc) loop
      /*
      error_info := '/mirrordate=' || to_char(mirrordate_in, 'YYYY-MM-DD') ||
      '/mirrorid=' || i_mirrorid || '/subcompany=' ||
      subcompany_in || '/listno=' || rec.listno;
      */
      if rec.listno != i_listno then
        --huan le yige xin de listno
        i_listno :=rec.listno;
        i_remains_tmp := rec.remains; --mm_policymirror_td的ying shou yu e
      end if;
      if rec.cnt = 1 then
        --无缴费计划
        i_extract_amount := rec.remains; --坏账mm_bad_debts_list.this_amount(应收缴费金额)=mm_policymirror_td.remains(余额)
      elsif i_remains_tmp >= rec.plan_amount then
        --
        i_extract_amount := rec.plan_amount;
        i_remains_tmp := i_remains_tmp - rec.plan_amount;
      elsif i_remains_tmp < rec.plan_amount and i_remains_tmp>0 then
        i_extract_amount :=i_remains_tmp;
        i_remains_tmp :=0.00;
      else
        goto   continue;
       -- i_extract_amount :=  0.00;
      end if;
      /*2008-11-3/gq/对于批增帐龄算签单日期,其他按原来逻辑不变.*/
      /*2009-4-14/gq/批增帐龄取起保日期和签单日期的大者*/
      /*tmp_date := case
        when rec.endorseno != '无' and rec.amount > 0 then
         greatest(rec.startdate, rec.signdate) --取保单日期和签单日期的最大值作为生效日期
        else
         rec.startdate
      end;*/
      --2014-3-29 大众特殊处理，账龄都取 起保日和签单日的较大者
      tmp_date := greatest(rec.startdate, rec.signdate);
      --只有一个缴费计划情况取起保日期、签单日期、缴费计划日期靠后的日期
      if rec.datedate is not null then
        tmp_date1:=  greatest(rec.datedate,tmp_date);
        else
           tmp_date1:=  tmp_date;
          end if;
      --缴费计划账龄
      i_accountdate := greatest(0,
                                mirrordate_in - --记账日期i_accountdate
                                (case
                                  when rec.cnt = 1 then
                                 tmp_date1--tmp_date
                                  else
                                   rec.datedate --计划缴付日期datedate
                                end) + 1);

      begin
        --取坏账计提的账龄和比例
        select accountage, extract_percent
          into c_accountage, i_extract_percent
          from mm_accountageset_tc
         where agekind = '1'
           and i_accountdate between long1 and long2;
      exception
        when no_data_found then
          raise_application_error(mm_errorlog_pkg.e_no_data_found,
                                  '获取帐龄失败,帐龄天数=' || i_accountdate ||
                                  '天,请检查帐龄表mm_accountageset_tc!');
      end;
      insert into mm_bad_debts_list
        (extract_date,
         mirrorid,
         seqpolicy,
         subcompany,
         policyno,
         endorseno,
         currencycode,
         unitcode,
         departmentcode,
         customercode,
         customername,
         transactorcode,
         underwritercode,
         classescode,
         risktype,
         classeskind,
         agentcode,
         opstatus,
         accountage,
         accountdate,
         signdate,
         startdate,
         enddate,
         opdate,
         amount,
         realamount,
         remains,
         plan_date,
         plan_seq,
         plan_amount,
         is_bad,
         is_start,
         this_amount,
         bad_percent,
         bad_amount,
         businesschannel)
      values
        (mirrordate_in, --extract_date
         mirrorid_in, --mirrorid
         rec.seqpolicy, --seqpolicy
         rec.subcompany, --subcompany
         rec.policyno, --policyno
         rec.endorseno, --endorseno
         rec.currencycode, --currencycode
         rec.unitcode, --unitcode
         rec.departmentcode, --departmentcode
         rec.customercode, --customercode
         rec.customername, --customername
         rec.transactorcode, -- transactorcode
         rec.underwritercode, --underwritercode
         rec.classescode, --classescode
         rec.risktype, --risktype
         rec.classeskind, --classeskind
         rec.agentcode, --agentcode
         rec.opstatus, --opstatus
         c_accountage, --accountage
         i_accountdate, --accountdate
         rec.signdate, --signdate
         rec.startdate, --startdate
         rec.enddate, --enddate
         rec.opdate, --opdate
         rec.amount, --amount
         rec.realamount, --realamount
         rec.remains, --remains-------------------------------
         decode(rec.cnt, 1, null, rec.datedate), --plan_date
         decode(rec.cnt, 1, '0', rec.thisseq), --plan_seq
         decode(rec.cnt, 1, null, rec.plan_amount), --plan_amount
         'N', --is_bad
         decode(i_accountdate, 0, 'N', 'Y'), --is_start--是否已到缴费期
         i_extract_amount, --this_amount--应收缴费金额
         i_extract_percent, --bad_percent
         i_extract_amount * i_extract_percent,
         rec.businesschannel); --bad_amount
      <<continue>>
      null;
    end loop;
  end handle_plan_accountage;
  -----------------------------------------------------------------------------  
  --add by yaozhiqiang huahai 2015-7-7 有缴费计划的，未到结算日的不计算账龄                                                                            
  procedure handle_plan_accountday(mirrordate_in in mm_mirror_td.mirrordate%type,
                                   mirrorid_in   in mm_mirror_td.mirrorid%type) is
    i_remains_tmp     mm_plan_td.amount%type; 
    i_listno          mm_policymirror_td.listno%type;--listno中间变量 
    i_thisseq         mm_plan_td.thisseq%type;
    i_realamount      mm_policymirror_td.realamount%type; 
    i_datedate        mm_plan_td.datedate%type; 
    i_count           number;     
  begin
    
  i_listno :=0;

    for rec in (select * from mm_policymirror_td m where m.mirrorid = mirrorid_in and m.businessattr='1' and m.hasplan = '1') loop
      
       i_thisseq :=1;
       i_realamount :=0;
        select count(*)
          into i_count
          from mm_plan_td a
         where a.custseq = rec.custseq;

        for i in 1..i_count loop
          if i_thisseq<=i_count then
           select m.amount
             into i_remains_tmp
             from mm_plan_td m
            where m.custseq = rec.custseq
              and m.thisseq = i_thisseq;
                
            i_realamount := i_realamount + i_remains_tmp ; 
            
            if i_realamount > rec.realamount then
              exit;
            end if; 
          end if;
          i_thisseq :=i_thisseq +1;
        end loop;
        select a.datedate 
          into i_datedate
          from mm_plan_td a
         where a.thisseq = i_thisseq
           and a.custseq = rec.custseq;
        if i_datedate <= mirrordate_in then
           update mm_policymirror_td m
              set m.accountday = greatest(0,
                                          floor(mirrordate_in - i_datedate + 1))
            where m.listno = rec.listno
              and m.policyno = rec.policyno; 
        else
            update mm_policymirror_td m
               set m.accountday = 0
             where m.listno = rec.listno
               and m.policyno = rec.policyno;
        end if;
    end loop;
  end handle_plan_accountday;
  -----------------------------------------------------------------------------
  --应收台帐切片
  procedure mm_setpolicymirror(in_subcompany in mm_mirror_td.subcompany%type,
                               in_enddate    in mm_mirror_td.mirrordate%type,
                               in_opcode     in mm_mirror_td.opcode%type,
                               flag          out nocopy pls_integer,
                               errmsg        out nocopy varchar2) is
    v_startdate    mm_mirror_td.mirrordate%type;
    i_mirrorid     mm_mirror_td.mirrorid%type;
    c_audit_status mm_bad_debts_head.audit_status%type;
  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_policy_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete mm_mirror_td
     where mirrordate = in_enddate
       and mirrortype = cst_policy_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete mm_policymirror_td where mirrorid = i_mirrorid;
    /*删除坏账表相关记录,台帐重切之后，原来坏账的记录就没有意义了。*/
    delete from mm_bad_debts_list where mirrorid = i_mirrorid;
    delete from mm_bad_debts_head
     where mirrorid = i_mirrorid
    returning audit_status into c_audit_status;
    if c_audit_status = '1' then
      raise_application_error(mm_errorlog_pkg.e_update_error,
                              '相关联的坏账记录已审核过,暂时不允许对此日期做切片操作!');
    end if;
    /*if sql%found then
      delete from mm_bad_debts where mirrorid = i_mirrorid;
    end if;*/
    /*开始计算切片数据*/
    if mm_sysset_pkg.taxifeffect = '0' then
      insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select newno,
               decode(businesstwo, '992', amount, 0.00) amount,
               decode(businesstwo, '941', amount, 0.00) realamount
          from mm_policy_events_td pe
         where pe.businesstwo in ('992', '941')
           and businessone in
               ('101', '102', '103', '104', '108', '121', '122','Y01')
              /*'123', '124', '125'*/ /*2009-1-15 增加,'121','123','124','125'*/
           and pe.auditstatus = '4'
           and pe.opdate between nvl(v_startdate + 1, pe.opdate) and
               in_enddate
           and subcompany = in_subcompany;
      /*2009-1-15新增共保代收款挂账记录,销账也是941,121*/
      insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select oldno, amount, 0.00
          from mm_policy_events_td
         where businessone = '993'
           and businesstwo = '121'
           and amount > 0
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany;
    elsif mm_sysset_pkg.taxifeffect = '1' then
      /*如果车船税是肯定起保，则核销应收直接使用实收金额*/
      insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select newno,
               decode(businesstwo, '992', amount, 0.00) amount,
               decode(businesstwo, '941', amount, 0.00) realamount
          from mm_policy_events_td pe
         where pe.businesstwo in ('992', '941')
           and pe.businessone in
               ('101',
                '102',
                '103',
                '104',
                '121',
                '122','Y01' /*, '123', '124', '125'*/)
           and pe.auditstatus = '4'
           and pe.opdate between nvl(v_startdate + 1, pe.opdate) and
               in_enddate
           and pe.subcompany = in_subcompany;
      /*2009-1-15新增共保代收款挂账记录,销账也是,销账也是941,121*/
      insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select oldno, amount, 0.00
          from mm_policy_events_td
         where businessone = '993'
           and businesstwo = '121'
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany;

      insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select newno, 0.00 amount, amount as realamount
          from mm_paymentin_events_td pe
         where businessone = '121'
           and businesstwo = '131'
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany;
      /* and pe.opdate between nvl(date'2012-03-30' + 1, pe.opdate) and
          date'2012-04-12'
      and pe.subcompany = '0251010000000' and policyno='25107000060007120000003' ; */

      /*单独插入车船税挂账记录*/
      insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select newno, amount, 0.00
          from mm_policy_events_td pe
         where pe.businesstwo = '992'
           and pe.businessone = '108'
           and pe.auditstatus = '4'
           and pe.opdate between nvl(v_startdate + 1, pe.opdate) and
               in_enddate
           and pe.subcompany = in_subcompany;
      /*车船税销账记录*/
    /*  insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select newno, 0.00, amount
          from mm_paymentin_events_td pay
         where pay.businessone = '108'
           and pay.auditstatus = '4'
           and pay.opdate between nvl(v_startdate + 1, pay.opdate) and
               in_enddate
           and pay.tosubcompany = in_subcompany;*/

        --保单挂在途
        /*insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select newno, 0.00, amount
          from mm_paymentin_events_td pay
         where pay.businessone in('101','102','103','104','105','106','108')
           and pay.businesstwo = '9ZT'
           and pay.auditstatus = '4'
           and pay.opdate between nvl(v_startdate + 1, pay.opdate) and in_enddate
           and pay.tosubcompany = in_subcompany;*/
    end if;
    if v_startdate is not null then
      insert into mm_temp_policy_td
        (seqpolicy, amount, realamount)
        select seqpolicy, amount, realamount
          from mm_policymirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_policy_type);
    end if;
    /*插入汇总记录到临时表*/
    insert into mm_temp_sumpolicy_td
      (seqpolicy, amount, realamount)
      select seqpolicy, sum(amount), sum(realamount)
        from mm_temp_policy_td
       group by seqpolicy
      having sum(amount) != sum(realamount);
    /*插入切片主表*/
    insert into mm_mirror_td
      (mirrorid, mirrordate, subcompany, mirrortype, opstatus, opcode)
    values
      (seq_mirror.nextval,
       in_enddate,
       in_subcompany,
       cst_policy_type,
       c_month,
       in_opcode)
    returning mirrorid into i_mirrorid;
    /*关联保单表取保单的主要信息,插入切片清单表*/
    insert into mm_policymirror_td
      (listno,
       mirrorid,
       seqpolicy,
       subcompany,
       policyno,
       endorseno,
       currencycode,
       remains,
       businessattr,
       ifstart,
       unitcode,
       departmentcode,
       startdate,
       enddate,
       opdate,
       customercode,
       customername,
       transactorcode,
       underwritercode,
       classescode,
       risktype,
       classeskind,
       agentcode,
       signdate,
       seqcharge,
       opstatus,
       amount,
       realamount,
       accountage,
       accountday,
       classescodename,
       unitname,
       departmentname,
       accountage1,
       accountday1,
       accountage2,
       accountday2,
       custseq,
       -- 2014-6-3 by xlh 应收台账增加销售渠道字段
       businesschannel,
       businesschannelname,
       transactorname,
       optcode,
       optname,
       masterno,
       mastername
       )
      select seq_reservemirror.nextval,
             i_mirrorid, --seq_mirror.currval,
             p.seqpolicy,
             p.subcompany,
             p.policyno,
             p.endorseno,
             p.currencycode,
             ts.amount - ts.realamount, --remains --总应收余额
             p.businessattr,
             (case
               when in_enddate >= p.startdate then
                '1'
               else
                '0'
             end), --p.ifstart,
             p.unitcode,
             p.departmentcode,
             p.startdate,
             p.enddate,
             p.opdate,
             p.customercode,
             (select max(distinct trim(i.customername))
                from mm_invply_td iv, mm_invoice_td i
               where i.seqinvoice = iv.seqinvoice
                 and iv.seqpolicy = p.seqpolicy), --p.customername,
             p.transactorcode,
             p.underwritercode,
             p.classescode,
             p.risktype,
             p.classeskind,
             p.agentcode,
             p.signdate,
             p.seqcharge,
             decode(decode(ts.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(ts.realamount),
                                  -1,
                                  (ts.realamount + p.amount),
                                  ts.realamount),
                           ts.realamount),
                    0.00,
                    '0',
                    '1') opstatus,
             decode(ts.amount,
                    0.00,
                    decode(sign(ts.realamount), -1, p.amount, ts.amount),
                    ts.amount) amount,
             decode(ts.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(ts.realamount),
                           -1,
                           (ts.realamount + p.amount),
                           ts.realamount),
                    ts.realamount) realamount,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                    --and greatest(0, floor(in_enddate - p.startdate + 1)) between
                 and greatest(0,
                              floor(in_enddate -
                                    greatest(p.startdate, p.signdate) + 1)) between
                     long1 and long2) accountage, --added by guqin/080324
             --greatest(0, floor(in_enddate - p.startdate + 1)) accountday,
             greatest(0,
                      floor(in_enddate - greatest(p.startdate, p.signdate) + 1)) accountday,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.signdate + 1)) between
                     long1 and long2) as accountage1,
             greatest(0, floor(in_enddate - p.signdate + 1)) accountday1, --签单账龄天数
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.startdate + 1)) between
                     long1 and long2) as accountage2,
             greatest(0, floor(in_enddate - p.startdate + 1)) accountday2,
             p.custseq,
             p.businesschannel,
              (select businname
              from mm_dictcontent_td where busintypeid='BUSINESSCHANNEL'
              and businid = p.businesschannel),
              p.transactorname,
              p.optcode,
              p.optname,
              p.masterno,
              p.mastername
        from mm_temp_sumpolicy_td ts, mm_policy_td p
       where ts.seqpolicy = p.seqpolicy;

    /*if sql%notfound then
      raise_application_error(-20001, '切片失败：没有找到有效的切片数据！');
    end if;*/-----20150104 yzh 华海

    ---处理手动增加预收负数,强制插入此表 yzh20111221
    insert into mm_policymirror_td
      (listno,
       mirrorid,
       seqpolicy,
       subcompany,
       policyno,
       endorseno,
       currencycode,
       remains,
       businessattr,
       ifstart,
       unitcode,
       departmentcode,
       startdate,
       enddate,
       opdate,
       customercode,
       customername,
       transactorcode,
       underwritercode,
       classescode,
       risktype,
       classeskind,
       agentcode,
       signdate,
       seqcharge,
       opstatus,
       amount,
       realamount,
       accountage,
       accountday,
       classescodename,
       unitname,
       departmentname,
       accounted_dr,
       exchangerate,
       accountage1,
       accountday1,
       accountage2,
       accountday2,
       custseq)
      select seq_reservemirror.nextval,
             i_mirrorid, --seq_mirror.currval,
             seqpolicy,
             subcompany,
             policyno,
             endorseno,
             currencycode,
             remains,
             businessattr,
             ifstart,
             unitcode,
             departmentcode,
             startdate,
             enddate,
             opdate,
             customercode,
             customername,
             transactorcode,
             underwritercode,
             classescode,
             risktype,
             classeskind,
             agentcode,
             signdate,
             seqcharge,
             opstatus,
             amount,
             realamount,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.startdate + 1)) between
                     long1 and long2) accountage,
             greatest(0, floor(in_enddate - p.startdate + 1)) accountday,
             classescodename,
             unitname,
             departmentname,
             accounted_dr,
             exchangerate,
             p.accountage1,
             p.accountday1,
             p.accountage2,
             p.accountday2,
             p.custseq
        from mm_policymirror_td p
       where mirrorid = (select mirrorid
                           from mm_mirror_td
                          where mirrordate = v_startdate
                            and subcompany = in_subcompany
                            and mirrortype = cst_policy_type)
         and seqpolicy = '99'; ---99 的是手动增加的负数的
    ----以上部分sql----yzh20111221-----------------

    /*处理应收计划帐龄*/
    handle_plan_accountage(in_enddate, i_mirrorid); --2014-3-27 注释掉，大众这边不用这个。 
    

    --汇率
    update mm_policymirror_td p
       set p.exchangerate = decode(p.currencycode,
                                   'CNY',
                                   1,
                                  /* nvl((select round((tt.accounted_dr /
                                                    tt.entered_dr),
                                                    6)
                                         from mm_voucherdetail_td tt
                                        where tt.businessno = p.seqpolicy
                                          and tt.currencycode =
                                              p.currencycode
                                          and tt.segment1 = p.unitcode
                                          and tt.businesstype like '%992'
                                          and tt.accounted_dr <> 0
                                          and rownum <= 1),
                                       (select exchangerate
                                          from mm_conversionrate_tc
                                         where currencycode1 = p.currencycode
                                           and currencycode2 = 'CNY' -- 取外币到人民币的汇率
                                         --  and p.opdate between startdate and ---取计算账龄用的切片所在月的汇率
                                         and in_enddate between startdate and
                                               enddate
                                           and rownum = 1) )*/
                                      (select exchangerate
                                          from mm_conversionrate_tc
                                         where currencycode1 = p.currencycode
                                           and currencycode2 = 'CNY' -- 取外币到人民币的汇率
                                          --  and p.opdate between startdate and ---取计算账龄用的切片所在月的汇率
                                          -- and in_enddate between startdate and
                                         --2014-6-3 汇率表是月初汇率，5月31日的应收台帐要用6月初的汇率
                                         and in_enddate between startdate and
                                               enddate
                                           and rownum = 1)
                                           )
     where p.mirrorid = i_mirrorid;

    update mm_policymirror_td p
       set p.customername = p.customername || '等'
     where exists (select 1
              from mm_invply_td iv, mm_invoice_td i
             where i.seqinvoice = iv.seqinvoice
               and iv.seqpolicy = p.seqpolicy
               and trim(i.customername) <> p.customername)
       and p.customername is not null
       and p.mirrorid = i_mirrorid;
    --大众要求发票抬头

    update mm_policymirror_td p
       set p.accounted_dr   = round(p.remains * p.exchangerate, 2), --本位币金额
           p.remains_dued   = nvl((select sum(b.this_amount)
                                    from mm_bad_debts_list b
                                   where b.seqpolicy = p.seqpolicy
                                     and b.mirrorid = p.mirrorid
                                     and b.is_start = 'Y'),
                                  0), --已到结算日余额
           p.remains_undued = nvl((select sum(b.this_amount)
                                    from mm_bad_debts_list b
                                   where b.seqpolicy = p.seqpolicy
                                     and b.mirrorid = p.mirrorid
                                     and b.is_start = 'N'),
                                  0), --未到结算日余额
           p.hasplan        = nvl((select 1
                                    from mm_plan_td pl
                                   where pl.custseq = p.custseq
                                     and rownum = 1),
                                  0) --是否有缴费计划
     where p.mirrorid = i_mirrorid; 
     
    --add by yaozhiqiang 有缴费计划的，未到结算日不计算账龄
    handle_plan_accountday(in_enddate, i_mirrorid);
  
    flag := 0;
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
      flag := -1;
  end;
  -----------------------------------------------------------------------------
  --待付款的坏账
  procedure handle_plan_accountage_pa(mirrordate_in in mm_mirror_td.mirrordate%type,
                                      mirrorid_in   in mm_mirror_td.mirrorid%type) is
    i_remains_tmp     mm_plan_td.amount%type;
    c_accountage      mm_bad_debts_list.accountage%type;
    i_accountdate     mm_bad_debts_list.accountdate%type;
    i_extract_percent mm_accountageset_tc.extract_percent%type;
    i_extract_amount  mm_bad_debts_list.this_amount %type;
    tmp_date          date;
  begin

    for rec in (select count(1) over(partition by m.listno) cnt,
                       m.*,
                       p.thisseq,
                       p.amount plan_amount,
                       p.datedate
                  from mm_payablemirror_td m
                  left join mm_plan_td p
                    on p.seqcharge = m.paymoneyno
                 where m.datatype in ('', '', '', '')
                   and m.mirrorid = mirrorid_in
                 order by m.listno, p.thisseq) loop
      /*
      error_info := '/mirrordate=' || to_char(mirrordate_in, 'YYYY-MM-DD') ||
      '/mirrorid=' || i_mirrorid || '/subcompany=' ||
      subcompany_in || '/listno=' || rec.listno;
      */
      if rec.thisseq = 1 then
        --对应的是 mm_pay_plan_ti.serialno 缴付序号
        i_remains_tmp := rec.usedamount; --mm_policymirror_td的已处理金额
      end if;
      if rec.cnt = 1 then
        i_extract_amount := rec.remains; --坏账mm_bad_debts_list.this_amount(应收缴费金额)=mm_policymirror_td.remains(余额)
      elsif i_remains_tmp >= rec.plan_amount then
        --已处理金额>mm_plan_td.amount计划缴付金额
        i_remains_tmp := i_remains_tmp - rec.plan_amount;
        goto continue;
      else
        i_extract_amount := rec.plan_amount - i_remains_tmp; --应收缴费金额=金额-已处理金额
        i_remains_tmp    := 0.00;
      end if;
      /*2008-11-3/gq/对于批增帐龄算签单日期,其他按原来逻辑不变.*/
      /*2009-4-14/gq/批增帐龄取起保日期和签单日期的大者*/
      tmp_date      := rec.opdate; --取保单日期和签单日期的最大值作为生效日期
      i_accountdate := greatest(0,
                                mirrordate_in - --记账日期i_accountdate
                                (case
                                  when rec.cnt = 1 then
                                   tmp_date
                                  else
                                   rec.datedate
                                end) + 1); --计划缴付日期datedate
      begin
        --取坏账计提的账龄和比例
        select accountage, extract_percent
          into c_accountage, i_extract_percent
          from mm_accountageset_tc
         where agekind = '1'
           and i_accountdate between long1 and long2;
      exception
        when no_data_found then
          raise_application_error(mm_errorlog_pkg.e_no_data_found,
                                  '获取帐龄失败,帐龄天数=' || i_accountdate ||
                                  '天,请检查帐龄表mm_accountageset_tc!');
      end;
      insert into mm_bad_debts_list
        (extract_date,
         mirrorid,
         seqpolicy,
         subcompany,
         policyno,
         endorseno,
         currencycode,
         unitcode,
         departmentcode,
         customercode,
         customername,
         transactorcode,
         underwritercode,
         classescode,
         risktype,
         classeskind,
         agentcode,
         opstatus,
         accountage,
         accountdate,
         signdate,
         startdate,
         enddate,
         opdate,
         amount,
         realamount,
         remains,
         plan_date,
         plan_seq,
         plan_amount,
         is_bad,
         is_start,
         this_amount,
         bad_percent,
         bad_amount)
      values
        (mirrordate_in, --extract_date
         mirrorid_in, --mirrorid
         rec.paymoneyno, --seqpolicy
         rec.subcompany, --subcompany
         rec.policyno, --policyno
         rec.endorseno, --endorseno
         rec.currencycode, --currencycode
         rec.unitcode, --unitcode
         rec.departmentcode, --departmentcode
         rec.customercode, --customercode
         rec.customername, --customername
         rec.transactorcode, -- transactorcode
         null, --underwritercode
         rec.classescode, --classescode
         null, --risktype
         null, --classeskind
         rec.agentcode, --agentcode
         rec.opstatus, --opstatus
         c_accountage, --accountage
         i_accountdate, --accountdate
         null, --signdate
         rec.startdate, --startdate
         rec.enddate, --enddate
         rec.opdate, --opdate
         rec.amount, --amount
         rec.usedamount, --realamount
         rec.remains, --remains
         decode(rec.cnt, 1, null, rec.datedate), --plan_date
         decode(rec.cnt, 1, '0', rec.thisseq), --plan_seq
         decode(rec.cnt, 1, null, rec.plan_amount), --plan_amount
         'N', --is_bad
         decode(i_accountdate, 0, 'N', 'Y'), --is_start
         i_extract_amount, --this_amount
         i_extract_percent, --bad_percent
         i_extract_amount * i_extract_percent); --bad_amount
      <<continue>>
      null;
    end loop;
  end handle_plan_accountage_pa;
  ----------------------------------------------------------------------------
  --待付台帐切片
  procedure mm_setpayablemirror(in_subcompany in mm_mirror_td.subcompany%type,
                                in_enddate    in mm_mirror_td.mirrordate%type,
                                in_opcode     in mm_mirror_td.opcode%type,
                                flag          out nocopy pls_integer,
                                errmsg        out nocopy varchar2) is
    v_startdate mm_mirror_td.mirrordate%type;
    i_mirrorid  mm_mirror_td.mirrorid%type;
    p1          mm_payablemirror_td%rowtype;

  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_payable_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete mm_mirror_td m
     where mirrordate = in_enddate
       and mirrortype = cst_payable_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete mm_payablemirror_td where mirrorid = i_mirrorid;
    select seq_mirror.nextval into i_mirrorid from dual;
    /*插入切片主表*/
    insert into mm_mirror_td
      (mirrorid, mirrordate, subcompany, mirrortype, opstatus, opcode)
    values
      (i_mirrorid,
       in_enddate,
       in_subcompany,
       cst_payable_type,
       c_month,
       in_opcode);
    /*插入待付款切片表明细记录*/
    insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage)
      with payable_tmp as /*来自于储金，赔款的待付款的核销*/
       (select oldno as paymoneyno, 0.00 as amount, amount as usedamount
          from mm_paymentin_events_td
         where businesstwo in ('107','112', 
                              '131','302','304','306','307','311','313','321','325','328','330','332','334','336','338','340','342','344','346','348','350','351','352','353','354','356','358','35F','35H','360','362','364','366','384','385','390','391','3J0','3J1','3J2','3J3','3J4','3J5','3J6','3J7',
                              '122','522','524','532','534','535','537','355','357','359','361','363' --add by yaozhiqiang huahai 共保待付款
                              )  
           and oldno not in('11258786650','11258764833') --922107最初走的科目是222109,
           and listno not in('11295230514','11328294405','11329154071','11346628938','11346628939','11346628940')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany 
       /* union all --modify by yaozhiqiang 2016-1-31 车船税内转销408112 5月份之前凭证模板错误，不提到客户待领款台账里，5月份调整正确了
        select oldno as paymoneyno, 0.00 as amount, amount as usedamount
          from mm_paymentin_events_td
         where businesstwo  = '112' and businessone = '408'
           and listno not in('11295230514','11328294405','11329154071','11346628938','11346628939','11346628940')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany */
       UNION ALL
        SELECT (select (select td.newno   --paymoneyno获取挂账的newno以便 挂账数据和核销数据抵消 by liujing 2017-12-19
                   from mm_policy_events_td td
                  where td.oldno = t.seqpayment and rownum <= 1)
           from mm_claim_td t
          where t.custseq = r.custseq) as paymoneyno,0.00 AS amount,m.amount  AS usedamount
         FROM MM_PAYMENTIN_EVENTS_TD   M,
              MM_PAYABLEMONEY_TD       A,
              MM_CENTRALIZATIONLIST_TD R
        WHERE M.BUSINESSTWO  in( '336','338')--by liujing 2017-8-31
          AND M.AUDITSTATUS = '4'
          AND M.OPDATE BETWEEN NVL(V_STARTDATE + 1, m.OPDATE) AND IN_ENDDATE
          AND M.TOSUBCOMPANY = IN_SUBCOMPANY
          AND M.OLDNO = R.ID
          AND R.SEQCENTRALIZATION = A.FATHERNO
           UNION ALL
           SELECT (select (select td.newno
                   from mm_policy_events_td td
                  where td.oldno = t.seqpayment and rownum <= 1)
           from mm_claim_td t
          where t.custseq = r.custseq) as paymoneyno,0.00 AS amount,-m.amount  AS usedamount
         FROM MM_PAYMENTIN_EVENTS_TD   M,
              MM_PAYABLEMONEY_TD       A,
              MM_CENTRALIZATIONLIST_TD R 
        WHERE M.Businessone  in( '336')--by liujing 2017-8-31 336912   
           AND M.OPDATE BETWEEN NVL(V_STARTDATE + 1, m.OPDATE) AND IN_ENDDATE
          AND M.TOSUBCOMPANY = IN_SUBCOMPANY
          AND M.AUDITSTATUS = '4'
          AND M.Newno = R.ID
          AND R.SEQCENTRALIZATION = A.FATHERNO
           UNION ALL
                 SELECT (select (select td.newno
                   from mm_policy_events_td td
                  where td.oldno = t.seqpayment and rownum <= 1 and rownum <= 1)
           from mm_claim_td t
          where t.custseq = r.custseq) as paymoneyno,0.00 AS amount,-m.amount  AS usedamount--红字公估费 by liujing 2017-8-30
         FROM MM_PAYMENTIN_EVENTS_TD   M,
              MM_PAYABLEMONEY_TD       A,
              MM_CENTRALIZATIONLIST_TD R
        WHERE M.Businessone = '338'
          AND M.AUDITSTATUS = '4'
            AND M.OPDATE BETWEEN NVL(V_STARTDATE + 1, m.OPDATE) AND IN_ENDDATE
          AND M.TOSUBCOMPANY = IN_SUBCOMPANY
          AND M.Newno = R.ID
          AND R.SEQCENTRALIZATION = A.FATHERNO
        union all
        select oldno as paymoneyno, 0.00 as amount, amount as usedamount
          from mm_paymentin_events_td
         where businesstwo='402'
           and businessone in('921','922','923','408')   --添加408402 by liujing 2016-6-28
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany 
           --and oldno not in ('1013633875', '1013633878')
        /*核销记录应选择tosubcompany,否则跨司内往会出错。
        对于待付款抵保费的操作，取tosubcompany也可能有问题，不过这种操作暂时不会出现*/
        union all
        /*红字待付的核销，考虑到可能出现正负冲抵的情况，红字和蓝字需要单独取，
        在正负冲抵时可以取到两条*/
        select newno, 0.00, decode(businesstwo,'421',amount,-amount) /*红字收款时为正数，但核销的是负数应付款*/
          from mm_paymentin_events_td
         where businessone in--2014-4-2 改为大众的类型--2017-7-24添加355 by liujing 添加359401 by liiujing 2018-1-30
             ('132','107','112','122','302','304','306','307','311','313','321','325','328','330','332','334','336','338','340','342','344','346','348','350','351','352','353','354','355','356','358','359','35F','35H','360','362','364','366','384','385','390','391','3J0','3J1','3J2','3J3','3J4','3J5','3J6','3J7','534','532','524','522')-- 改为大众的类型添加类型522  by zlx 2017-12-27
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
           union all
            select newno, 0.00, decode(businesstwo,'421',amount,-amount) 
          from mm_paymentin_events_td
         where businessone in --排除131411 by liujing 20171206
             ('131')
           and   businesstwo /*not */ in('411') --重新添加131411 11月份凭证有误 2018-1-30 by liiujing
           and auditstatus = '4'
           and listno not in('11708895329','11708898641','11708898637','11708898631','11708898663','11708898657','11783178910',
'11783178916','11783178894','11783178890','11783178876','11783178884')--排除131411 共保凭证错误的交易流水 --by liujing 2018-1-30
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
        union all
        /*取挂账记录，402的挂账在交易流水表*/
        select newno, amount, 0.00
          from mm_paymentin_events_td
         where businessone = '402' /*and businesstwo not in('408')*/
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
        union all
        /*退保退储的挂账，107942是销账*/
        select decode(businessone, '107', newno, oldno),
               decode(businessone, '107', 0.00,-amount),
               decode(businessone, '107', amount, 0.00)
          from mm_policy_events_td
         where businessone in ('105', '106', '110', '111', '203', '107','Y03')
           and businesstwo in ('992', '993', '942')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all
        /*车船税申报也属于应付款*/
      /*  select oldno, amount, 0.00
          from mm_policy_events_td
         where businessone = '108'
           and businesstwo = '995'
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all*/
        /*车船税申报也属于应付款*/ ----起保的时候已经挂账，申报的时候 借：车船税计提  贷：车船税申报  忽略
        /*select c_fixed_value + p.seqpolicy,
               decode(pe.opstatus, '5', p.amount, 0.00),
               decode(pe.opstatus, '0', p.amount, '4', p.amount, 0.00) --decode(sign(pe.amount),-1,p.amount,0.00), decode(sign(pe.amount),-1,0.00,p.amount)
          from mm_policy_events_td   pe,
               mm_policy_td          p,
               mm_payablemoney_td    pm,
               mm_handover_events_td h
         where pe.oldno = pm.payableno
           and pm.summaryno = h.handoverno
           and p.seqpolicy = h.seqpolicy
           and pe.businessone = '108'
           and pe.businesstwo = '995'
           and pe.auditstatus = '4'
           and pe.opdate between nvl(v_startdate + 1, pe.opdate) and
               in_enddate
           and pe.subcompany = in_subcompany
        union all*/
        /*车船税申报也属于应付款*/
    /*    select c_fixed_value + newno, amount, 0.00
          from mm_policy_events_td
         where businessone in ('110', '111')
           and businesstwo = '992'
           and auditstatus = '4'
              --and not exists (select 1 from mm_handover_events_td h where h.seqpolicy=newno and h.opstatus='0')
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all*/
        /*车船税申报也属于应付款*/
    /*    select c_fixed_value + p.seqpolicy,
               decode(businesstwo,
                      '133',
                      0.00,
                      round(p.amount * pe.amount / pm.amount, 2)),
               decode(businesstwo,
                      '133',
                      round(p.amount * pe.amount / pm.amount, 2),
                      0.00) --,pe.*,p.*,pm.*,b.*
          from mm_paymentin_events_td pe,
               mm_policy_td           p,
               mm_payablemoney_td     pm,
               mm_batchinfo_ti        b
         where pe.oldno = pm.payableno
           and pm.summaryno = b.summaryno
           and b.policyno = p.policyno
           and p.businessattr = '4'
           and p.unitcode = pm.unitcode
           and p.currencycode = pm.currencycode
           and b.certitype = '7'
           and b.datatype = '1'
           and b.status = '2'
           and pe.businesstwo in ('133', '134')
           and pe.auditstatus = '4'
           and pe.opdate between nvl(v_startdate + 1, pe.opdate) and
               in_enddate
           and pm.subcompany = in_subcompany
        union all*/
        /*车船税申报也属于应付款*/
     /*   select c_fixed_value + p.seqpolicy,
               -round(p.amount * pe.amount / pm.amount, 2),
               0.00
          from mm_paymentin_events_td pe,
               mm_policy_td           p,
               mm_payablemoney_td     pm,
               mm_batchinfo_ti        b
         where pe.newno = pm.payableno
           and pm.summaryno = b.summaryno
           and b.policyno = p.policyno
           and p.businessattr = '4'
           and p.unitcode = pm.unitcode
           and p.currencycode = pm.currencycode
           and b.certitype = '7'
           and b.datatype = '1'
           and b.status = '2'
           and pe.businessone = '134'
           and pe.auditstatus = '4'
           and pe.opdate between nvl(v_startdate + 1, pe.opdate) and
               in_enddate
           and pm.subcompany = in_subcompany
        union all*/ /*储金返还、赔案、手续费待付款挂账*/ --注释掉 501 505 515 517
        select decode(businesstwo, '131', oldno + 1,/*'386','11326749110',*/ newno),
               decode(businesstwo,
                      '121',
                      amount,
                      '131',
                      -amount, --qgx20120829 businesstwo,'121',abs(amount), '131',abs(amount)
                      -- '351',-amount, '352',-amount,--qgx 20120601损余物资收回，挂账（993351）本身就是付金额，所以此处不需要加负号
                      amount),
               0.00
          from mm_policy_events_td
         where businessone = '993'
              --2014-4-2 更改为大众这边的挂账类型
           and businesstwo in ('121',
                               '131',
                               '301', 
                               '303',
                               '306',
                               '306',
                               '307',
                               '307',
                               '310',
                               '312',
                               '320',
                               '324',
                               '327',
                               '329',
                               '331',
                               '333',
                               '335',
                               '337',
                               '339',
                               '341',
                               '343',
                               '345',
                               '347',
                               '349',
                               '351',
                               '352',
                               '353',
                               '354',
                               '355',
                               '357',
                               '359',
                               '35E',
                               '35G',
                               '361',
                               '364',
                               '366',
                               '384',
                               '385',
                               --'386',--add by liujing 20160503 追偿款 386与380在下面单独处理 yzq20170224
                               '390',
                               '391',
                               '3J0',
                               '3J1',
                               '3J2',
                               '3J3',
                               '3J4',
                               '3J5',
                               '3J6',
                               '3J7',
                               '521',--add by yaozhiqiang huahai 20151109 共保待付款
                               '523',--add by yaozhiqiang huahai 20151109 共保待付款
                               '531',--add by yaozhiqiang huahai 20151109 共保待付款
                               '533',--add by yaozhiqiang huahai 20151109 共保待付款 
                               'Y09')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all /*qgx 2012-05-17 add 车船税对冲*/
        select c_fixed_value + pay.fatherno, 0.00, -pe.amount
          from mm_paymentin_events_td pe, mm_payablemoney_td pay
         where pe.oldno = pay.payableno
           and pe.businessone in ('108', '')
           and pe.businesstwo = '112'
           and pe.auditstatus = '4'
           and pe.opdate between nvl(v_startdate + 1, pe.opdate) and
               in_enddate
           and pe.subcompany = in_subcompany
        --------------------------------------- add by whw at 2009-12-14
        union all /*保险卡手续费与结算单手续费重复挂账的记录*/
        select oldno, -amount, 0.00
          from mm_policy_events_td
         where businessone = '991'
           and businesstwo in ('551', '552')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        /* union all \*保险卡手续费与结算单手续费重复挂账的记录*\
        select oldno, amount, 0.00
          from mm_policy_events_td
         where businessone='991'
           and businesstwo in('309')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany*/
        ---------------------------------------
        union all /*储金返还、赔案、手续费待付款挂账*/
        select (select payableno
                  from mm_payablemoney_td p
                 where p.fatherno = pe.oldno
                   and p.payableno <> pe.newno) oldno,
               amount,
               0.00
          from mm_policy_events_td pe
         where businessone = '993'
           and businesstwo = '121' --共保应付款挂红字应付款
           and amount < 0
           and auditstatus = '4'
           and exists
         (select payableno
                  from mm_payablemoney_td p
                 where p.fatherno = pe.oldno
                   and p.payableno <> pe.newno)
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany /*共保同时挂其他应收，其他应付，台账中需要出现两次*/
        union all /*储金返还、赔案、手续费待付款挂账*/
        select oldno, -amount, 0.00
          from mm_policy_events_td pe
         where businessone = '993'
           and businesstwo in ('355', '357', '535', '537') --共保理赔、费用（手续费）挂红字应付款
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany /*共保同时挂其他应收，其他应付，台账中需要出现两次*/
        union all
        --挂账  代扣税费
      select p.payableno,-pay.amount,0.00
        from mm_paymentin_events_td pay, mm_taxlist_td l, mm_payablemoney_td p
       where pay.oldno = l.id
         and l.seqcentralization = p.fatherno
         and pay.businesstwo in('511','513','525')
         and pay.auditstatus = '4'
         and pay.opdate  between nvl(v_startdate + 1, pay.opdate) and in_enddate
         and pay.subcompany= in_subcompany
         and p.datatype not in('575','576')
         and pay.tradebatno = p.payableseq --add by yaozhiqiang 20151229 代理税费退票后，结算单重新付款会重新生成一条514待付款记录，l.seqcentralization = p.fatherno会将两条待付款记录都关联到，取到的数据会重复
        union all 
          -- 挂账 代扣税费
       select p.payableno,decode(businesstwo,'912',pay.amount,-pay.amount),0.00
        from mm_paymentin_events_td pay, mm_taxlist_td l, mm_payablemoney_td p
       where pay.newno = l.id
         and l.seqcentralization = p.fatherno
         and pay.businessone in('511','513','525')
         and pay.auditstatus = '4'
         and pay.opdate  between nvl(v_startdate + 1, pay.opdate) and in_enddate
         and pay.subcompany= in_subcompany
         and p.datatype not in('575','576')
         and pay.tradebatno = p.payableseq --add by yaozhiqiang 20151229 代理税费退票后，结算单重新付款会重新生成一条514待付款记录，l.seqcentralization = p.fatherno会将两条待付款记录都关联到，取到的数据会重复
         union all 
      --销账  代扣税费
      select pay.oldno,0.00,pay.amount
        from mm_paymentin_events_td pay
       where pay.businesstwo in('512','514','526')
         and pay.auditstatus = '4'
         and pay.opdate  between nvl(v_startdate + 1, pay.opdate) and in_enddate
         and pay.subcompany= in_subcompany
         union all
         --销账  代扣税费
        select pay.newno,0.00,-pay.amount
        from mm_paymentin_events_td pay
       where pay.businessone in('512','514','526')
         and pay.auditstatus = '4'
         and pay.opdate  between nvl(v_startdate + 1, pay.opdate) and in_enddate
         and pay.subcompany= in_subcompany
      union all
       -----车船税挂账 正数108
        select newno, amount, 0.00
          from mm_paymentin_events_td pay
         where pay.businessone = '108'
           and pay.businesstwo in ('9ZT','401')
           and pay.auditstatus = '4'
           and pay.opdate between nvl(v_startdate + 1, pay.opdate) and
               in_enddate
           and pay.tosubcompany = in_subcompany
       /*  union all
            -----车船税挂账 负数112
         select po.seqpolicy, pay.amount, 0.00
          from mm_paymentin_events_td pay,mm_payablemoney_td p,mm_policy_td po
         where pay.businessone in('921','922')
           and pay.businesstwo ='112'
           and pay.oldno=p.payableno
           and p.fatherno=po.seqpolicy
           and pay.auditstatus = '4'
           and pay.opdate between nvl(v_startdate + 1, pay.opdate) and
               in_enddate
           and pay.tosubcompany = in_subcompany*/
        union all
       -----车船税销账
         select h.seqpolicy, 0.00, h.usedtaxamount--abs(h.usedtaxamount)
          from mm_handover_events_td h
          where h.payableno in(
          select pay.oldno
          from mm_paymentin_events_td pay
         where pay.businessone in ('921','922')
           and pay.businesstwo ='109'
           and pay.auditstatus = '4'
           and pay.opdate between nvl(v_startdate + 1, pay.opdate) and
               in_enddate
           and pay.tosubcompany = in_subcompany)
        union all
        /*取上个月记录,如没有,v_startdate is null 就取不到记录*/
        select to_number(paymoneyno), amount, usedamount
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype not in ('502','516','113','110','111','Y10','Y07','Y13','Y14','Y15','Y16','Y17','Y19','YY3','YY4','Y06','Y08','Y27','Y23','Y24','Y03','Y02')--添加Y10不去上个月Y10的数据 byliuijing 2017-5-23 添加Y02 by2017-12-7
           /*and paymoneyno not in ('1013892394',
                                  '1013892397',
                                  '1013892400',
                                  '1013892388',
                                  '1013892382',
                                  '1013892391',
                                  '1013892403')*/ --2014-4-2 永安的特殊处理代码，这里去掉
                                  )
      select seq_payablemirror.nextval,
             i_mirrorid,
            decode(p.datatype,'392','336','393','336',nvl(p.datatype, '108')),--decode(t.paymoneyno,'11326749110','386',nvl(p.datatype, '108')),modify by yaozhiqiang 20170224 
             nvl(p.subcompany, '0'),
             nvl(p.departmentcode, '0'),
             t.paymoneyno,
             nvl(p.currencycode, '00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           nvl(p.amount, 0),
                           t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount, 0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount, 0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             p.claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             p.opdate,
             p.opdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage
        from mm_payablemoney_td p
       right join (select paymoneyno,
                          sum(amount) amount,
                          sum(usedamount) usedamount,
                          sum(amount) - sum(usedamount) remains
                     from payable_tmp
                    group by paymoneyno
                   having sum(amount) != sum(usedamount)) t
          on p.payableno = t.paymoneyno;
    if sql%notfound then
      raise_application_error(-20001, '切片失败：没有找到有效的切片数据！');
    end if;
    commit;
    
   
    --add by yaozhiqiang20170206  代位求偿预估清偿款单独处理
     insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage)
      with payable_tmp_claim AS
      （select oldno AS paymoneyno,
               amount,
               0.00 AS usedamount,
               businesstwo AS datatype
          from mm_policy_events_td
         where businessone = '993'
           and businesstwo in ('380','386','388')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all
        /*取上个月记录,如没有,v_startdate is null 就取不到记录*/
        select to_number(paymoneyno), amount, usedamount,datatype
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('380','386','388') 
        )
        select seq_payablemirror.nextval,
             i_mirrorid,
             t.datatype,
             nvl(p.subcompany, '0'),
             nvl(p.departmentcode, '0'),
             t.paymoneyno,
             nvl(p.currencycode, '00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           nvl(p.amount, 0),
                           t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount, 0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount, 0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             p.claimno,
             (SELECT DISTINCT r.unitcode FROM mm_unitmapping_tc r WHERE r.departmentcode = p.departmentcode),--unitcode
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode IN(SELECT r.unitcode FROM mm_unitmapping_tc r WHERE r.departmentcode = p.departmentcode)),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             p.auditdate,
             p.auditdate,
             p.agentcode,--agentcode
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.auditdate + 1)) between
                     long1 and long2) accountage
       from mm_claim_td p
       right join (select paymoneyno,
                          sum(amount) amount,
                          sum(usedamount) usedamount,
                          sum(amount) - sum(usedamount) remains,
                          datatype
                     from payable_tmp_claim
                    group by paymoneyno,datatype
                   having sum(amount) != sum(usedamount)) t
          on p.seqpayment = t.paymoneyno;

    ------begin华海 代扣税费部分单独处理yaozhiqiang 20151112--- 
     insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpb as
       ( select oldno as paymoneyno,
                businessone as datatype,
               amount,
               0.00 as usedamount
          from mm_policy_events_td
         where businessone in ('110', '111')
           and businesstwo in ('992', '993', '942')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
         union all
         select oldno as paymoneyno,
                businesstwo as datatype,
                0.00 as amount, 
                amount as usedamount
          from mm_paymentin_events_td
         where businesstwo = '112'  
           and oldno in('11258786650','11258764833') --922112最初走的科目是222109,
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany 
         union all
         select oldno as paymoneyno,
                businesstwo as datatype,
                0.00 as amount, 
                amount as usedamount
          from mm_paymentin_events_td
         where businesstwo = '112'  and businessone = '408'
           and listno in('11295230514','11328294405','11329154071','11346628938','11346628939','11346628940')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
         /* union all
         select oldno as paymoneyno,
                businessone as datatype,
                amount, 
                0.00 as usedamount
          from mm_paymentin_events_td
         where businessone = '112'  
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany*/
         union all
        /*取上个月记录,如没有,v_startdate is null 就取不到记录*/
        select to_number(paymoneyno),datatype, amount, usedamount
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('113','110','111') 
         )
       select seq_payablemirror.nextval,
             i_mirrorid,
             decode(t.datatype,'112','113',t.datatype),
             nvl(p.subcompany, '0'),
             nvl(p.departmentcode, '0'),
             t.paymoneyno,
             nvl(p.currencycode, '00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           nvl(p.amount, 0),
                           t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount, 0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount, 0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             p.claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             p.opdate,
             p.opdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage
       from mm_payablemoney_td p
       right join (select paymoneyno,datatype,
                          sum(amount) amount,
                          sum(usedamount) usedamount,
                          sum(amount) - sum(usedamount) remains
                     from payable_tmpb
                    group by paymoneyno,datatype
                   having sum(amount) != sum(usedamount)) t
          on p.payableno = t.paymoneyno;
    
    ------end华海 代扣税费部分单独处理---
    
    --begin 华海 121应收保费-共保代收 处理 -- 
      insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpbb as
       (select newno as paymoneyno, amount, 0.00 as usedamount
          from mm_paymentin_events_td
         where businessone ='121'
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
         union all
        /*取上个月记录,如没有,v_startdate is null 就取不到记录*/
        select to_number(paymoneyno), amount, usedamount
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  ='121' 
         )
       select seq_payablemirror.nextval,
             i_mirrorid,
             '121',
             nvl(m.subcompany, '0'),
             nvl(m.departmentcode, '0'),
             t.paymoneyno,
             nvl(m.currencycode, '00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           nvl(m.amount, 0),
                           t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, 
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(m.amount, 0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             m.customername,
             decode(decode(t.amount,
                           0.00, 
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(m.amount, 0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             m.policyno,
             m.endorseno,
             '',
             m.unitcode,
             m.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = m.classescode),
             (select unitname from mm_unit_tc where unitcode = m.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = m.departmentcode),
             m.opdate,
             m.opdate,
             m.agentcode,
             m.customercode,
             m.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - m.opdate + 1)) between
                     long1 and long2) accountage
       from mm_policy_td m
       right join (select paymoneyno,
                          sum(amount) amount,
                          sum(usedamount) usedamount,
                          sum(amount) - sum(usedamount) remains
                     from payable_tmpbb
                    group by paymoneyno
                   having sum(amount) != sum(usedamount)) t
          on m.seqpolicy = t.paymoneyno;
    
    --end  华海 121应收保费-共保代收 处理 --

    -----大众应付手续费切片-
     insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpa as
 /*手续费挂应付..add by yuanzihong 20140304*/
     (  select oldno paymoneyno,
              amount,
              0.0 usedamount
         from mm_policy_events_td
        where businessone in ('993')
          and businesstwo in ('517','505','501','515','597','585','581','595')
          and auditstatus = '4'
          and opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and subcompany = in_subcompany

             union all
       /*手续费销应付..add by yuanzihong 20140304*/
        select d.seqfeelist paymoneyno, 0.00  amount, p.amount usedamount
        from mm_policy_events_td p,mm_applyfee_td d ,mm_centralizationlist_td c
       where p.oldno=c.id and c.billno=d.billno
        and p.businessone in
             ('502', '506', '516', '518', '582', '586', '596', '598')
         and businesstwo in ('942')
         and auditstatus = '4'
         and p.opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and p.subcompany = in_subcompany
         union all
         --历史迁移的手续费预付数据是没有对应结算单明细的
      select d.seqfeelist paymoneyno, 0.00  amount, p.amount usedamount
        from mm_policy_events_td p,mm_applyfee_td d
       where p.oldno=d.seqfeelist
        and p.businessone in
             ('502', '506', '516', '518', '582', '586', '596', '598')
         and businesstwo in ('942')
         and auditstatus = '4'
         and p.datasource = 'historychannelyzf'
         and p.opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and p.subcompany = in_subcompany
         union all
           select to_number(paymoneyno), amount, usedamount
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('502','516')
          union all
          select to_number(paymoneyno), amount, usedamount
         from mm_payablemirror_td where 1=2
          )

   select seq_payablemirror.nextval,
             i_mirrorid,
            decode(sign(t.remains),'-1','516','502'),--- '555' datatype,
             nvl(p.subcompany,'0'),
             nvl(p.deptcode,'0'),
             t.paymoneyno,
             nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.agentname customername,--p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.deptcode),
             ''opdate,
             --''opdate,
             p.effectdate as startdate,
             p.agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.applydate + 1)) between
                     long1 and long2) accountage
        from mm_applyfee_td p right join
             (select paymoneyno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains
                from payable_tmpa
               group by paymoneyno
              having sum(amount) != sum(usedamount)) t
       on p.seqfeelist = t.paymoneyno;

-----销项税-  add by liujing 2016-5-12
     insert into mm_payablemirror_td

      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpap as
     ( 
     select decode(pay.businessattr,'F',pay.oldno,pay.newno) as newno,0.00 as amount,pay.amount as usedamount from mm_policy_events_td  pay
    where pay.businessone in('Y02','Y04')--添加Y10944 byliujing 2016-8-4
     and pay.businesstwo='944'
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany
    union all 
      select pay.newno,pay.amount as amount,0.00 as usedamount from mm_policy_events_td  pay
    where pay.businessone='Y01'
    and   pay.businesstwo in('992','415') -- 101 Y01
     and pay.auditstatus = '4'
      and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany
     union all
     select pay.newno,pay.amount as amount,0.00 as usedamount
      from mm_policy_events_td  pay
    where pay.businessone in('Y03')
     and pay.businesstwo in('992') --105 Y03
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany
     union all 
      select pay.oldno as newno,pay.amount  as amount,0.00 as usedamount from mm_policy_events_td  pay
    where pay.businessone='993'
     and  pay.businesstwo in('Y03') --131 Y01
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany
     union all  
      select pay.oldno as newno,pay.amount as amount,0.00 as usedamount from mm_policy_events_td  pay
    where pay.businessone='993'
     and  pay.businesstwo in('Y01') -- 121Y09
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany
      union all  
      select pay.newno,pay.amount as amount,0.00 as usedamount from mm_policy_events_td  pay
    where pay.businessone='Y03'   
     and  pay.businesstwo in('415') -- 121Y09
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany  
     union all
     select decode(pay.businessattr,'1',pay.newno,'F',pay.oldno) as newno ,0.00 as amount,pay.amount as usedamount from mm_policy_events_td  pay
    where pay.businessone in('Y02','Y04')-- businessattr 控制 取newno 和oldno by liujing 2017-12-14
     and pay.businesstwo IN('417','418')
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany
     union all
     select to_number(paymoneyno), amount, usedamount
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype in ('Y02','Y04')
     )

 select seq_payablemirror.nextval,
             i_mirrorid,
            decode(p.datatype,'101','Y02','103','Y02','105','Y04','121','Y02','131','Y04','Y02'), -- 101 Y01,105 Y03,131 Y01,121Y09
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.newno ,
             nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, 
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             ''opdate,
             p.startdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_policy_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains
                from payable_tmpap
               group by newno
              having sum(amount) != sum(usedamount)) t
              on  p.seqpolicy=t.newno;
             
   insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpc as
     ( 
   
        select pay.newno,-pay.amount as amount,0.00 as usedamount from mm_policy_events_td  pay   --挂待付款
    where pay.businessone='993'
     and  pay.businesstwo in('Y09')
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany 
     union all
     select pay.newno,0.00 as amount,pay.amount as usedamount from mm_policy_events_td  pay
    where pay.businessone ='Y10'
     and pay.businesstwo='944'
     and pay.auditstatus = '4'
     and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
     and pay.subcompany = in_subcompany 
      union all
  select to_number(paymoneyno), amount, usedamount
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype in ('Y10')
        )         
       select seq_payablemirror.nextval,
             i_mirrorid,
            decode(p.datatype,'534','Y10','532','Y10','0'), --532 Y09
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.newno,
            nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, 
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             ''opdate,
             p.opdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_payablemoney_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains
                from payable_tmpc
               group by newno
              having sum(amount) != sum(usedamount)) t
               on p.payableno=t.newno;           
   
  

        -----------------------------------------------------------          
              -- 其他应收款-共保应收款-共保税款 12210406  by liujing 2017-1-18
 insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpin as
     ( 
           select pay.newno,-pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='993'
          and pay.businesstwo in('Y01','Y03')
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany    
       union all    
          select to_number(paymoneyno), amount, usedamount,datatype as businessno
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('YY3')  --其他应收款-共保应收款-共保税款12210406 by liujing 2017-1-18
     )
    select seq_payablemirror.nextval,
             i_mirrorid,
            'YY3',
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.newno,
            nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, 
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             ''opdate,
             p.opdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_payablemoney_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains
                from payable_tmpin
               group by newno
              having sum(amount) != sum(usedamount)) t
               on p.payableno=t.newno;
           
  insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpin as
     ( 
           select pay.newno,pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('Y05') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
          UNION ALL
          select pay.newno,-pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('Y27') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
          union all    
          select to_number(paymoneyno), amount, usedamount,datatype as businessno
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('YY4')
 )
    select seq_payablemirror.nextval,
             i_mirrorid,
            'YY4',
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.newno,
            nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, 
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             ''opdate,
             p.opdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_policy_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains
                from payable_tmpin
               group by newno
              having sum(amount) != sum(usedamount)) t
               on p.seqpolicy=t.newno;
       
  
  --进项税   
  insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpin as
     ( 
           select pay.newno,pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('F01','F03') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
          union all
           select pay.newno,-pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('F02') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
     union all    -- 998 F01取上个月的历史数据  by liujing2016-9-30
          select to_number(paymoneyno), amount, usedamount,datatype as businessno
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('F01','F02','F03')
     )
     select seq_payablemirror.nextval,
             i_mirrorid,
             t.businessno, 
             nvl(p.subcompany,'0'),
             p.pk_org,
             t.newno,
             nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             ''customername,
             '' opstatus,
             ''policyno,
             ''endorseno,
             ''claimno,
             （select t.unitcode from mm_unitmapping_tc t where t.departmentcode =p.pk_org and t.currencycode='CNY'） unitcode,
             ''classescode,
             '',
             (select r.unitname from mm_unit_tc r where r.unitcode =(select t.unitcode from mm_unitmapping_tc t where t.departmentcode =p.pk_org and t.currencycode='CNY')),
             (select a.departmentname from mm_department_tc a where a.departmentcode = p.pk_org),
             ''opdate,
             p.opdate,
             ''agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_invatinvoice_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin
               group by newno,businessno
              having sum(amount) != sum(usedamount)) t
               on p.id=t.newno;
               --998 F02  by liujing 2016-12-28
    insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpin as
     ( 
           select pay.newno,-pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('F02') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
      UNION ALL
      select pay.newno,pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo IN('F03') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
     union all   
          select to_number(paymoneyno), amount, usedamount,decode(datatype,'FF2','F02','FF3','F03') as businessno   
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('FF2','FF3')
     )
     select seq_payablemirror.nextval,
             i_mirrorid,
             decode(t.businessno,'F02','FF2','F03','FF3'),
             nvl(p.subcompany,'0'),
             p.pk_org,
             t.newno,
             nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             ''customername,
             '' opstatus,
             ''policyno,
             ''endorseno,
             ''claimno,
             （select t.unitcode from mm_unitmapping_tc t where t.departmentcode =p.pk_org and t.currencycode='CNY'） unitcode,
             ''classescode,
             '',
             (select r.unitname from mm_unit_tc r where r.unitcode =(select t.unitcode from mm_unitmapping_tc t where t.departmentcode =p.pk_org and t.currencycode='CNY')),
             (select a.departmentname from mm_department_tc a where a.departmentcode = p.pk_org),
             ''opdate,
             p.opdate,
             ''agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_invatinvoice_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin
               group by newno,businessno
              having sum(amount) != sum(usedamount)) t
               on p.id=t.newno;
     
    insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpin2 as
     ( 
       select pay.newno,pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('Y21','Y25','Y18','Y20','Y22','Y26') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
              union all 
       select pay.newno,-pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('Y06','Y08','Y16','Y17','Y19','Y23','Y24')   --修改金额符号 by liujing 2016-12-27
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
    union all 
       select pay.newno,0.00 as amount,pay.amount as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'   --调整998Y13,998Y14,998Y15的金额符号
          and pay.businesstwo in('Y14','Y13','Y15') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
    union all 
    select pay.newno,-pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'  --更改998Y07的金额符号 by liujing
          and pay.businesstwo in('Y07') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
            union all 
            select to_number(paymoneyno), amount, usedamount,datatype as businessno
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype in ('Y07','Y13','Y15','Y14','Y17'，'Y21','Y23',
                              'Y25','Y18','Y20','Y22','Y24','Y26','Y06','Y08','Y16','Y19')--'Y13','Y15','Y14'获取上个月的记录 --2016-11-29 by liujing
     )          
     select seq_payablemirror.nextval,
             i_mirrorid,
             t.businessno, --532 Y09
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.newno,
             nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, 
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             p.claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             ''opdate,
             p.opdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_payablemoney_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin2
               group by newno,businessno
              having sum(amount) != sum(usedamount)) t
               on p.payableno=t.newno;          
    
    insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage) with payable_tmpin3 as
     ( 
            select pay.newno,-pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998' --更改998Y07的金额符号
          and pay.businesstwo in('Y05') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
               union all 
              select pay.newno,pay.amount as amount,0.00 as usedamount,pay.businesstwo as businessno from mm_policy_events_td  pay
        where pay.businessone='998'
          and pay.businesstwo in('Y27') 
          and pay.auditstatus = '4'
          and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
          and pay.subcompany = in_subcompany 
             union all 
            select to_number(paymoneyno), amount, usedamount,datatype as businessno
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype in ('Y05','Y27')
     )          
     select seq_payablemirror.nextval,
             i_mirrorid,
            t.businessno, 
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.newno ,
             nvl(p.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, 
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             ''opdate,
             p.startdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage from mm_policy_td p
         right join (select newno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin3
               group by newno,businessno
              having sum(amount) != sum(usedamount)) t
              on  p.seqpolicy=t.newno;
 
    insert into mm_payablemirror_td
        (listno,
         mirrorid,
         datatype,
         subcompany,
         departmentcode,
         paymoneyno,
         currencycode,
         amount,
         usedamount,
         remains,
         customername,
         opstatus,
         policyno,
         endorseno,
         claimno,
         unitcode,
         classescode,
         classescodename,
         unitname,
         departmentname,
         opdate,
         startdate,
         agentcode,
         customercode,
         transactorcode,
         accountage) with payable_tmpin4 as
       ( 
         SELECT PAY.OLDNO       AS PAYMONEYNO,
                0.00            AS AMOUNT,
                PAY.AMOUNT      AS USEDAMOUNT,
                PAY.BUSINESSTWO AS BUSINESSNO,
                pay.currencycode --add by yaozhiqiang 20170410
           FROM MM_POLICY_EVENTS_TD PAY
          WHERE PAY.BUSINESSONE = '998'
            AND PAY.BUSINESSTWO IN ('Y11')
            AND PAY.AUDITSTATUS = '4'
            AND PAY.OPDATE BETWEEN NVL(V_STARTDATE + 1, OPDATE) AND
                IN_ENDDATE
            AND PAY.SUBCOMPANY = IN_SUBCOMPANY
         UNION ALL
         SELECT PAY.OLDNO       AS PAYMONEYNO,
                PAY.AMOUNT      AS AMOUNT,
                0.00            AS USEDAMOUNT,
                PAY.BUSINESSTWO AS BUSINESSNO,
                pay.currencycode--add by yaozhiqiang 20170410
           FROM MM_POLICY_EVENTS_TD PAY
          WHERE PAY.BUSINESSONE = '998'
            AND PAY.BUSINESSTWO IN ('Y12')
            AND PAY.AUDITSTATUS = '4'
            AND PAY.OPDATE BETWEEN NVL(V_STARTDATE + 1, OPDATE) AND
                IN_ENDDATE
            AND PAY.SUBCOMPANY = IN_SUBCOMPANY
         union all    -- 998Y11 998Y12取上个月的历史数据  by liujing2016-9-30
           select to_number(paymoneyno), amount, usedamount,datatype as businessno,currencycode
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype in ('Y12','Y11')
       )
     select seq_payablemirror.nextval,
             i_mirrorid,
            t.businessno,
             nvl(p.subcompany,'0'),
             nvl(p.deptcode,'0'),
             t.paymoneyno,
             nvl(t.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.agentname customername,--p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.deptcode),
             ''opdate,
             --''opdate,
             p.effectdate as startdate,
             p.agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.applydate + 1)) between
                     long1 and long2) accountage
        from mm_applyfee_td p right join
             (select paymoneyno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno,currencycode
                from payable_tmpin4
               group by paymoneyno,businessno,currencycode
              having sum(amount) != sum(usedamount)) t
       on p.seqfeelist = t.paymoneyno;
       
   insert into mm_payablemirror_td
        (listno,
         mirrorid,
         datatype,
         subcompany,
         departmentcode,
         paymoneyno,
         currencycode,
         amount,
         usedamount,
         remains,
         customername,
         opstatus,
         policyno,
         endorseno,
         claimno,
         unitcode,
         classescode,
         classescodename,
         unitname,
         departmentname,
         opdate,
         startdate,
         agentcode,
         customercode,
         transactorcode,
         accountage) with payable_tmpin5 as
       (
         select m.seqfeelist    as paymoneyno,
                0.00            as amount,
                pay.amount      as usedamount,
                pay.businessone as businessno
           from mm_policy_events_td pay,
                mm_centralizationlist_td a,
                mm_applyfee_td m
          where pay.businessone in ('Y11')
            and pay.businesstwo = '942'
            and pay.auditstatus = '4'
            and pay.oldno = a.id
            and a.billno = m.billno
            and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
            and pay.subcompany = in_subcompany
             union all  
            select m.seqfeelist    as paymoneyno,-- 修改金额符号 by liujing 2016-12-27
                0.00            as amount,
              pay.amount      as usedamount,
                pay.businessone as businessno
           from mm_policy_events_td pay,
                mm_centralizationlist_td a,
                mm_applyfee_td m
          where pay.businessone in ('Y12')
            and pay.businesstwo = '942'
            and pay.auditstatus = '4'
            and pay.oldno = a.id
            and a.billno = m.billno
            and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
            and pay.subcompany = in_subcompany
             union all   --  Y11942 Y12942 取上个月的历史数据  by liujing2016-9-30
             select to_number(paymoneyno), amount, usedamount, decode(datatype,'YY1','Y11','YY2','Y12') as businessno
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype  in ('YY2','YY1')
       )
       select seq_payablemirror.nextval,
             i_mirrorid,
             decode(t.businessno,'Y11','YY1','Y12','YY2'),
             nvl(p.subcompany,'0'),
             nvl(p.deptcode,'0'),
             t.paymoneyno,
             --nvl(p.currencycode,'00'),
             (SELECT r.currencycode FROM mm_centralizationlist_td r WHERE r.custseq = p.custseq AND rownum = 1),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.agentname customername,--p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.deptcode),
             ''opdate,
             --''opdate,
             p.effectdate as startdate,
             p.agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.applydate + 1)) between
                     long1 and long2) accountage
        from mm_applyfee_td p right join
             (select paymoneyno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin5
               group by paymoneyno,businessno
              having sum(amount) != sum(usedamount)) t
       on p.seqfeelist = t.paymoneyno;
       --添加Y9M942 by liujing 2018-1-30
   /*insert into mm_payablemirror_td
        (listno,
         mirrorid,
         datatype,
         subcompany,
         departmentcode,
         paymoneyno,
         currencycode,
         amount,
         usedamount,
         remains,
         customername,
         opstatus,
         policyno,
         endorseno,
         claimno,
         unitcode,
         classescode,
         classescodename,
         unitname,
         departmentname,
         opdate,
         startdate,
         agentcode,
         customercode,
         transactorcode,
         accountage) with payable_tmpin8 as
       ( 
         select m.seqriinsurence    as paymoneyno,
                0.00  as amount,
                pay.amount            as usedamount,
                pay.businessone as businessno
           from mm_policy_events_td pay,
                mm_centralizationlist_td a,
                mm_reinsurance_td m
          where pay.businessone in ('Y9M')
            and pay.businesstwo = '942'
            and pay.auditstatus = '4'
            and pay.oldno = a.id
            and a.custseq = m.accno
            and pay.opdate between nvl(v_startdate + 1, pay.opdate) and in_enddate
            and pay.subcompany  = in_subcompany
         --添加上个月Y9M942类型数据 属性对应Y99 by zlx 2018-3-22
         union all
         select to_number(paymoneyno), amount, usedamount,datatype as businessno
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype = 'Y99'     
       )
       select seq_payablemirror.nextval,
             i_mirrorid,
             'Y99',
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.paymoneyno,
             --nvl(p.currencycode,'00'),
             (SELECT r.currencycode FROM mm_centralizationlist_td r WHERE r.custseq = p.accno AND rownum = 1),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, \*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*\
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername customername,--p.customername,
             decode(decode(t.amount,
                           0.00, \*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*\
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.invoiceunit, --modify by lzp 
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.invoiceunit),--modify by lzp 
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode), --账套是对外分公司的但是部门还是业务的归属部门 
             ''opdate,
             --''opdate,
             p.opdate as startdate,
             p.agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between   
                     long1 and long2) accountage
        from mm_reinsurance_td p right join
             (select paymoneyno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin8
               group by paymoneyno,businessno
              having sum(amount) != sum(usedamount)) t
       on p.seqriinsurence = t.paymoneyno;  */
--添加Y9M 942 by  zlx  2018-1-29
/*insert into mm_payablemirror_td
        (listno,
         mirrorid,
         datatype,
         subcompany,
         departmentcode,
         paymoneyno,
         currencycode,
         amount,
         usedamount,
         remains,
         customername,
         opstatus,
         policyno,
         endorseno,
         claimno,
         unitcode,
         classescode,
         classescodename,
         unitname,
         departmentname,
         opdate,
         startdate,
         agentcode,
         customercode,
         transactorcode,
         accountage) with payable_tmpin6 as
       ( 
         select m.seqriinsurence    as paymoneyno,
                pay.amount      as amount,
                0.00            as usedamount,
                pay.businessone as businessno
           from mm_policy_events_td pay,
                mm_centralizationlist_td a,
                mm_reinsurance_td m
          where pay.businessone in ('Y9M')
            and pay.businesstwo = '942'
            and pay.auditstatus = '4'
            and pay.oldno = a.id
            and a.custseq = m.accno
            and pay.opdate between nvl(v_startdate + 1, pay.opdate) and in_enddate
            and pay.subcompany  = in_subcompany
       )
       select seq_payablemirror.nextval,
             i_mirrorid,
             t.businessno,
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.paymoneyno,
             --nvl(p.currencycode,'00'),
             (SELECT r.currencycode FROM mm_centralizationlist_td r WHERE r.custseq = p.accno AND rownum = 1),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, \*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*\
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername customername,--p.customername,
             decode(decode(t.amount,
                           0.00, \*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*\
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             ''opdate,
             --''opdate,
             p.opdate as startdate,
             p.agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between   
                     long1 and long2) accountage
        from mm_reinsurance_td p right join
             (select paymoneyno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin6
               group by paymoneyno,businessno
              having sum(amount) != sum(usedamount)) t
       on p.seqriinsurence = t.paymoneyno; */ --添加Y9M942类型  by zlx  2018-1-29
      
    insert into mm_payablemirror_td
        (listno,
         mirrorid,
         datatype,
         subcompany,
         departmentcode,
         paymoneyno,
         currencycode,
         amount,
         usedamount,
         remains,
         customername,
         opstatus,
         policyno,
         endorseno,
         claimno,
         unitcode,
         classescode,
         classescodename,
         unitname,
         departmentname,
         opdate,
         startdate,
         agentcode,
         customercode,
         transactorcode,
         accountage) with payable_tmpin6 as
       ( 
         select m.seqfeelist    as paymoneyno,
                pay.amount      as amount,
                0.00            as usedamount,
                pay.businessone as businessno
           from mm_policy_events_td pay,
                mm_centralizationlist_td a,
                mm_applyfee_td m
          where pay.businessone in ('Y11')
            and pay.businesstwo = '942'
            and pay.auditstatus = '4'
            and pay.oldno = a.id
            and a.billno = m.billno
            and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
            and pay.subcompany = in_subcompany
         UNION ALL
         select m.seqfeelist    as paymoneyno,
                0.00            as amount,
                pay.amount      as usedamount,
                pay.businessone as businessno
           from mm_policy_events_td pay,
                mm_centralizationlist_td a,
                mm_applyfee_td m
          where pay.businessone in ('Y12')
            and pay.businesstwo = '942'
            and pay.auditstatus = '4'
            and pay.oldno = a.id
            and a.billno = m.billno
            and pay.opdate between nvl(v_startdate + 1, opdate) and in_enddate
            and pay.subcompany = in_subcompany
         
       )
       select seq_payablemirror.nextval,
             i_mirrorid,
             t.businessno,
             nvl(p.subcompany,'0'),
             nvl(p.deptcode,'0'),
             t.paymoneyno,
             --nvl(p.currencycode,'00'),
             (SELECT r.currencycode FROM mm_centralizationlist_td r WHERE r.custseq = p.custseq AND rownum = 1),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.agentname customername,--p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.deptcode),
             ''opdate,
             --''opdate,
             p.effectdate as startdate,
             p.agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.applydate + 1)) between
                     long1 and long2) accountage
        from mm_applyfee_td p right join
             (select paymoneyno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno
                from payable_tmpin6
               group by paymoneyno,businessno
              having sum(amount) != sum(usedamount)) t
       on p.seqfeelist = t.paymoneyno;
  --新增再保数据销项税挂账   
        insert into mm_payablemirror_td
        (listno,
         mirrorid,
         datatype,
         subcompany,
         departmentcode,
         paymoneyno,
         currencycode,
         amount,
         usedamount,
         remains,
         customername,
         opstatus,
         policyno,
         endorseno,
         claimno,
         unitcode,
         classescode,
         classescodename,
         unitname,
         departmentname,
         opdate,
         startdate,
         agentcode,
         customercode,
         transactorcode,
         accountage) with payable_tmpin7 as
       (  
         SELECT PAY.OLDNO       AS PAYMONEYNO,
                0.00            AS AMOUNT,
                PAY.AMOUNT      AS USEDAMOUNT,
                PAY.BUSINESSTWO AS BUSINESSNO,
                pay.currencycode 
           FROM MM_POLICY_EVENTS_TD PAY
          WHERE PAY.BUSINESSONE = '997'
            AND PAY.BUSINESSTWO IN ('Y9A','Y9B','Y9C','Y9D','Y9I','Y9J','Y9K','Y9L','Y9M','Y9N','Y9O','Y9P','Y9U','Y9V','Y9W','Y9X') --997Y9M取上个月的历史数据 by  zlx 2017-12-27
            AND PAY.AUDITSTATUS = '4'                        --997Y9U取上个月的历史数据 by  zlx 2018-2-23
            AND PAY.OPDATE BETWEEN NVL(V_STARTDATE + 1, OPDATE) AND
                IN_ENDDATE
            AND PAY.Subcompany = IN_SUBCOMPANY
                union all 
           --添加数据类型Y9M942 by liiujing 2018-1-30
             select m.seqriinsurence    as paymoneyno,
                0.00      as amount,
                -pay.amount  as usedamount,
                pay.businessone as businessno,
                pay.currencycode 
           from mm_policy_events_td pay,
                mm_centralizationlist_td a,
                mm_reinsurance_td m
          where pay.businessone in ('Y9A','Y9B','Y9C','Y9D','Y9I','Y9J','Y9K','Y9L','Y9M','Y9N','Y9O','Y9P','Y9U','Y9V','Y9W','Y9X')
            and pay.businesstwo = '942'
            and pay.auditstatus = '4'
            and pay.oldno = a.id
            and a.custseq = m.accno
            and pay.opdate between nvl(v_startdate + 1, pay.opdate) and in_enddate
            and pay.subcompany  = in_subcompany
         union all    -- 997Y9A,997Y9B取上个月的历史数据  by liujing2017-12-4
           select to_number(paymoneyno), amount, usedamount,datatype as businessno,currencycode
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_payable_type) and datatype in ('Y9A','Y9B','Y9C','Y9D','Y9I','Y9J','Y9K','Y9L','Y9M','Y9N','Y9O','Y9P','Y9U','Y9V','Y9W','Y9X')
       )
     select seq_payablemirror.nextval,
             i_mirrorid,
            t.businessno,
             nvl(p.subcompany,'0'),
             nvl(p.departmentcode,'0'),
             t.paymoneyno,
             nvl(t.currencycode,'00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, nvl(p.amount,0), t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount,0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
              (select reinsurername
                from mm_reinsurer_tc
               where reinsurercode = p.customercode) customername,--p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount,0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             ''claimno,
             p.invoiceunit,--modify  by lzp 
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.invoiceunit),-----modify  by lzp 
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),--进项税额是对外分公司的，但是部门依旧是业务的部门
             ''opdate,
             --''opdate,
             p.opdate as startdate,
             p.agentcode,
             ''customercode,
             ''transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage
        from mm_reinsurance_td p right join
             (select paymoneyno,
                     sum(amount) amount,
                     sum(usedamount) usedamount,
                     sum(amount) - sum(usedamount) remains,
                     businessno,currencycode
                from payable_tmpin7
               group by paymoneyno,businessno,currencycode
              having sum(amount) != sum(usedamount)) t
       on p.seqriinsurence = t.paymoneyno;
  -------
    /* for da in (   select p.* from mm_payablemirror_td p where p.mirrorid=i_mirrorid and p.datatype='108') loop

    dbms_output.put_line('po:'||da.policyno||'=='||da.paymoneyno||'=='||da.claimno||'=='||da.customercode);
    end loop;*/ --0916????????

    update mm_payablemirror_td p
       set (subcompany,
            departmentcode,
            currencycode,
            customername,
            opstatus,
            policyno,
            endorseno,
            claimno,
            unitcode,
            classescode,
            classescodename,
            unitname,
            departmentname,
            opdate)

            =
           (select subcompany,
                   departmentcode,
                   currencycode,
                   customername,
                   '0',
                   policyno,
                   endorseno,
                   '' claimno,
                   unitcode,
                   classescode,
                   (select classescodename
                      from mm_classescode_tc
                     where classescode = t.classescode),
                   (select unitname
                      from mm_unit_tc
                     where unitcode = t.unitcode),
                   (select departmentname
                      from mm_department_tc
                     where departmentcode = t.departmentcode),
                   opdate
              from mm_policy_td t
             where t.seqpolicy = p.paymoneyno)
     where p.mirrorid = i_mirrorid
       and p.datatype = '108'
       and exists
     (select 1
              from mm_policy_td c
             where c.seqpolicy = p.paymoneyno);

    handle_plan_accountage_pa(in_enddate, i_mirrorid);
    flag := 0;
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片！';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
      flag := -1;
  end;
  -----------------------------------------------------------------------------
  --预收的坏账
  procedure handle_plan_accountage_um(mirrordate_in in mm_mirror_td.mirrordate%type,
                                      mirrorid_in   in mm_mirror_td.mirrorid%type) is
    i_remains_tmp     mm_plan_td.amount%type;
    c_accountage      mm_bad_debts_list.accountage%type;
    i_accountdate     mm_bad_debts_list.accountdate%type;
    i_extract_percent mm_accountageset_tc.extract_percent%type;
    i_extract_amount  mm_bad_debts_list.this_amount %type;
    tmp_date          date;
  begin

    for rec in (select count(1) over(partition by m.listno) cnt,
                       m.*,
                       p.thisseq,
                       p.amount plan_amount,
                       p.datedate
                  from mm_usablemirror_td m
                  left join mm_plan_td p
                    on p.seqcharge = m.usableno
                 where m.businestype = '1'
                   and m.mirrorid = mirrorid_in
                 order by m.listno, p.thisseq) loop
      /*
      error_info := '/mirrordate=' || to_char(mirrordate_in, 'YYYY-MM-DD') ||
      '/mirrorid=' || i_mirrorid || '/subcompany=' ||
      subcompany_in || '/listno=' || rec.listno;
      */
      if rec.thisseq = 1 then
        --对应的是 mm_pay_plan_ti.serialno 缴付序号
        i_remains_tmp := rec.usedamount; --mm_policymirror_td的已处理金额
      end if;
      if rec.cnt = 1 then
        i_extract_amount := rec.amount; --坏账mm_bad_debts_list.this_amount(应收缴费金额)=mm_policymirror_td.remains(余额)
      elsif i_remains_tmp >= rec.plan_amount then
        --已处理金额>mm_plan_td.amount计划缴付金额
        i_remains_tmp := i_remains_tmp - rec.plan_amount;
        goto continue;
      else
        i_extract_amount := rec.plan_amount - i_remains_tmp; --应收缴费金额=金额-已处理金额
        i_remains_tmp    := 0.00;
      end if;
      /*2008-11-3/gq/对于批增帐龄算签单日期,其他按原来逻辑不变.*/
      /*2009-4-14/gq/批增帐龄取起保日期和签单日期的大者*/
      tmp_date      := rec.opdate;
      i_accountdate := greatest(0,
                                mirrordate_in - --记账日期i_accountdate
                                (case
                                  when rec.cnt = 1 then
                                   tmp_date
                                  else
                                   rec.datedate
                                end) + 1); --计划缴付日期datedate
      begin
        --取坏账计提的账龄和比例
        select accountage, extract_percent
          into c_accountage, i_extract_percent
          from mm_accountageset_tc
         where agekind = '1'
           and i_accountdate between long1 and long2;
      exception
        when no_data_found then
          raise_application_error(mm_errorlog_pkg.e_no_data_found,
                                  '获取帐龄失败,帐龄天数=' || i_accountdate ||
                                  '天,请检查帐龄表mm_accountageset_tc!');
      end;
      insert into mm_bad_debts_list
        (extract_date,
         mirrorid,
         seqpolicy,
         subcompany,
         policyno,
         endorseno,
         currencycode,
         unitcode,
         departmentcode,
         customercode,
         customername,
         transactorcode,
         underwritercode,
         classescode,
         risktype,
         classeskind,
         agentcode,
         opstatus,
         accountage,
         accountdate,
         signdate,
         startdate,
         enddate,
         opdate,
         amount,
         realamount,
         remains,
         plan_date,
         plan_seq,
         plan_amount,
         is_bad,
         is_start,
         this_amount,
         bad_percent,
         bad_amount)
      values
        (mirrordate_in, --extract_date
         mirrorid_in, --mirrorid
         rec.usableno, --seqpolicy
         rec.subcompany, --subcompany
         rec.policyno, --policyno
         null, --endorseno --批单号
         rec.currencycode, --currencycode
         rec.unitcode, --unitcode
         rec.departmentcode, --departmentcode
         rec.customercode, --customercode
         rec.customername, --customername
         rec.transactorcode, -- transactorcode
         null, --underwritercode --核保员代码
         rec.classescode, --classescode
         null, --risktype --风险类别
         null, --classeskind --业务险类
         rec.agentcode, --agentcode
         rec.opstatus, --opstatus
         c_accountage, --accountage
         i_accountdate, --accountdate
         null, --signdate
         rec.startdate, --startdate
         rec.enddate, --enddate
         rec.opdate, --opdate
         rec.amount, --amount 金额
         rec.usedamount, --realamount 以处理金额
         (rec.amount - rec.usedamount), --remains --余额
         decode(rec.cnt, 1, null, rec.datedate), --plan_date
         decode(rec.cnt, 1, '0', rec.thisseq), --plan_seq
         decode(rec.cnt, 1, null, rec.plan_amount), --plan_amount
         'N', --is_bad
         decode(i_accountdate, 0, 'N', 'Y'), --is_start
         i_extract_amount, --this_amount
         i_extract_percent, --bad_percent
         i_extract_amount * i_extract_percent); --bad_amount
      <<continue>>
      null;
    end loop;
  end handle_plan_accountage_um;
  -----------------------------------------------------------------------------
  -- 预收台帐切片
  procedure mm_setusablemirror(in_subcompany in mm_mirror_td.subcompany%type,
                               in_enddate    in mm_mirror_td.mirrordate%type,
                               in_opcode     in mm_mirror_td.opcode%type,
                               flag          out nocopy pls_integer,
                               errmsg        out nocopy varchar2) is
    v_startdate mm_mirror_td.mirrordate%type;
    i_mirrorid  mm_mirror_td.mirrorid%type;
  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_usable_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete mm_mirror_td m
     where mirrordate = in_enddate
       and mirrortype = cst_usable_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete mm_usablemirror_td where mirrorid = i_mirrorid;
    /*获取一个新的序号*/
    select seq_mirror.nextval into i_mirrorid from dual;
    /*插入切片主表*/
    insert into mm_mirror_td
      (mirrorid, mirrordate, subcompany, mirrortype, opstatus, opcode)
    values
      (i_mirrorid,
       in_enddate,
       in_subcompany,
       cst_usable_type,
       c_month,
       in_opcode);
    ----多收保费、内转销的预收及核销
    insert into mm_temp_usableevent_td
      (usableno,
       dailyauditno,
       currencycode,
       amount,
       usedamount,
       businestype,
       opdate)
      select newno,
             dailyauditno,
             currencycode,
             amount,
             0.00 usedamount,
             decode(businessone,'421','2','1'), --modify by yaozhiqiang 20150618 huahai 2为协议预收
             opdate
        from mm_paymentin_events_td
       where ((businessone in ('408', '421') /*and businesstwo not in('402'\*,'302'*\)*/) or --取消对408402的限制 by iujing 20160627
             (businessone = '401' and businesstwo not in ('112', '107')))
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND tosubcompany = in_subcompany
      union all 
      select oldno, --挂预收
             dailyauditno,
             currencycode, -- 币种,意为不取.
             0.00,
             amount,
             '1', --modify by yaozhiqiang 20150618 huahai 2为协议预收
             opdate
        from mm_paymentin_events_td
       where ((businesstwo in ('401') and businessone not in('R8Q','R8G','R8K','R9C','R8E','R8I','R9A')) or 
              (/*businessone not in(\*'304',*\'402') and*/ businesstwo in('408')))
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany
           union all
          select oldno, --挂预收
             dailyauditno,
             currencycode, -- 币种,意为不取.
             0.00,
             -amount,
             '1', --modify by yaozhiqiang 20150618 huahai 2为协议预收
             opdate
        from mm_paymentin_events_td
       where businesstwo in ('401') and businessone in('R8G','R8K','R9C','R8E','R8I','R9A','R8Q')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany
         AND DAILYAUDITNO IN('2016062110100000001059CNY0000001',--20161018凭证规则借贷方向做了调整 add by yzq2016-10-31
                '2016063010100000001059CNY0000001',
                '2016063010100000001059USD0000001',
                '2016072910100000001059CNY0000001',
                '2016072910100000001059CNY0000002',
                '2016073010100000001059CNY0000004',
                '2016073010100000001059USD0000002',
                '2016073010100000001059USD0000003',
                '2016101810SYSTEMUSD0000001',
                '2016101810SYSTEMCNY0000001',
                '2016101810SYSTEMUSD0000002',
                '2016101810SYSTEMCNY0000002')
          union all 
      select oldno, --挂预收
             dailyauditno,
             currencycode, -- 币种,意为不取.
             0.00,
             amount,
             '1', --modify by yaozhiqiang 20150618 huahai 2为协议预收
             opdate
        from mm_paymentin_events_td
       where businesstwo in ('401') and businessone in('R8G','R8K','R9C','R8E','R8I','R9A','R8Q')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany
         AND DAILYAUDITNO NOT IN('2016062110100000001059CNY0000001',--20161018凭证规则借贷方向做了调整 add by yzq2016-10-31
                '2016063010100000001059CNY0000001',
                '2016063010100000001059USD0000001',
                '2016072910100000001059CNY0000001',
                '2016072910100000001059CNY0000002',
                '2016073010100000001059CNY0000004',
                '2016073010100000001059USD0000002',
                '2016073010100000001059USD0000003',
                '2016101810SYSTEMUSD0000001',
                '2016101810SYSTEMCNY0000001',
                '2016101810SYSTEMUSD0000002',
                '2016101810SYSTEMCNY0000002')
      union all
       select oldno,
             dailyauditno,
             currencycode, -- 币种,意为不取.
             0.00,
             decode(businessone,'107',-amount,amount),
                decode(businesstwo,'421','2','1'),
              --modify by yaozhiqiang 20150618 huahai 2为协议预收
             opdate
        from mm_paymentin_events_td
       where businesstwo = '421'
           and businessone<>'401'
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany 
           union all
       select (select td.fatherno from mm_payablemoney_td td where td.payableno=mm_paymentin_events_td.newno) as newno,
             dailyauditno,
             currencycode, -- 币种,意为不取.
             amount,
             0.00,
             '3',
              --modify by liujing 201712-3
             opdate
        from mm_paymentin_events_td 
       where businesstwo = '411'
           and businessone='131'
         and auditstatus = '4'
         and listno in('11708895329','11708898641','11708898637','11708898631','11708898663','11708898657','11783178910',
'11783178916','11783178894','11783178890','11783178876','11783178884')--131411 凭证错误，--by liujing 2018-1-30
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany 
     union all     
          select oldno,
             dailyauditno,
             currencycode, -- 币种,意为不取.
             0.00,
             decode(businessone,'107',-amount,amount),
                decode(businesstwo,'421','1','2'),
              --modify by yaozhiqiang 20150618 huahai 2为协议预收
             opdate
        from mm_paymentin_events_td
       where businesstwo = '421'
       and businessone='401'
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany 
      union all --销预收
      select newno, --error原因:预收款匹配后已经全部核销，预收台帐上仍有负数余额  陈磊2010-07-29修改
             dailyauditno,
             currencycode, -- 币种,意为不取.
             0.00,
             -amount,
             decode(businessone,'421','2','1'),
             opdate
        from mm_paymentin_events_td
       where ((businesstwo in('112', '107') and businessone = '401') 
              or (businesstwo = '167' and businessone = '421'))
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany
       union all
       select oldno,
             dailyauditno,
             currencycode, -- 币种,意为不取.
             0.00,
             amount,
             '5', --modify by yaozhiqiang 20151124 huahai 5为协议预收
             opdate
        from mm_paymentin_events_td
       where businesstwo = '420'
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany;

    insert into mm_temp_usableevent_td
      (usableno,
       dailyauditno,
       currencycode,
       amount,
       usedamount,
       businestype,
       opdate)
    --销保单车船税的预收
      select oldno, /*942的记录oldno是保单表的seqpolicy,避免重号，941都是seqpolicy*/
             dailyauditno, -- 日结单,意为不取
             currencycode, -- 币种,意为不取.
             0.00,
             decode(businesstwo, '941', amount, -amount),
             decode(businessone, '108', '4', '112', '4', '3'),
             opdate -- 帐期,意为不取.
        from mm_policy_events_td
       where businesstwo in ('941', '942')
         and businessone in
             ('101', '102', '103', '104')---('101', '102', '103', '104', '108', '107', '112')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and subcompany = in_subcompany
      union all
      --由负数批单，附属车船税产生的预收
      select (select fatherno /*对于退保的付款记录，fatherno就是seqpolicy,避免重号*/
                from mm_payablemoney_td
               where payableno = p.oldno) usableno,
             dailyauditno,
             currencycode,
             -amount,
             0.00,
             decode(businesstwo, '112', '4','167','2','152','5','3'),
             opdate
        from mm_paymentin_events_td p
       where (businesstwo in (/*'112',*/'167','152')
         or (businessone in('101', '102', '103', '104') and businesstwo = '107' )) --and businessone like '9%'--只统计付款记录
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND tosubcompany = in_subcompany /*应该取业务数据分公司*/

      UNION ALL
      select newno,
             dailyauditno,
             currencycode,
             -amount,
             0.00,
             '2',
             opdate
        from mm_paymentin_events_td p
       where businesstwo ='167'
         AND businessone = '408'
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND tosubcompany = in_subcompany /*应该取业务数据分公司*/
         
      union all
       select (select fatherno /*对于退保的付款记录，fatherno就是seqpolicy,避免重号*/
                from mm_payablemoney_td
               where payableno = p.newno) usableno,
             dailyauditno,
             currencycode,
             amount,
             0.00,
             decode(businessone, '112', '4', '167','2','3'),
             opdate
        from mm_paymentin_events_td p
       where businessone in (/*'107',*/ '112','167') and businesstwo not in('421')  
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND tosubcompany = in_subcompany /*应该取业务数据分公司*/

      union all
      --由保单，车船税收款产生的预收
      select newno,
             dailyauditno,
             currencycode,
             amount,
             0.00,
             decode(businessone, '108', '4','3'),--2预收保费-协议预收
             opdate
        from mm_paymentin_events_td pe
       where businessone in ('101', '102', '103', '104'/*, '108'*/)
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND tosubcompany = in_subcompany /*应该取业务数据分公司*/ 
      union all 
       select （select a.usableno
               from mm_usablemoney_td a
              where a.fatherno = newno and rownum = 1）as usableno, 
              dailyauditno, 
              currencycode,
              amount, 
              0.00, 
              decode(businessone, '161', '2', '151', '5'), --2预收保费-协议预收 5卡折预收
              opdate 
        from mm_paymentin_events_td pe
        where businessone in ('161', '151')
          and businesstwo not in ('9ZT')
          and auditstatus = '4'
          and opdate between nvl(v_startdate + 1, opdate) and in_enddate
          AND tosubcompany = in_subcompany /*应该取业务数据分公司*/
      union all
           select  newno, 
              dailyauditno, 
              currencycode,
              amount, 
              0.00, 
              decode(businessone,'151', '5'), --5卡折预收
              opdate 
        from mm_paymentin_events_td pe
        where businessone in ('151')
          and businesstwo in ('9ZT')
          and auditstatus = '4'
          and opdate between nvl(v_startdate + 1, opdate) and in_enddate
          AND tosubcompany = in_subcompany /*应该取业务数据分公司*/
      union all
      select (select fatherno 
                from mm_payablemoney_td
               where payableno = pe.newno) usableno,
             dailyauditno,
             currencycode,
             amount,
             0.00,
             '5',--5预收保费-卡折预收
             opdate
        from mm_paymentin_events_td pe
       where businessone in ('152','153','154','155')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND tosubcompany = in_subcompany
      union all
      select oldno,
             dailyauditno,
             currencycode,
             -amount,
             0.00,
             decode(businesstwo, '108', '4','161','2','151','5','3'),--2预收保费-协议预收
             opdate
        from mm_paymentin_events_td pe
       where businesstwo in ('101', '102', '103', '104', '108','161','151')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND tosubcompany = in_subcompany /*应该取业务数据分公司*/

      union all /*上个月的数据*/
      select usableno,
             dailyauditno,
             currencycode,
             amount,
             usedamount,
             businestype,
             opdate
        from mm_usablemirror_td
       where mirrorid = (select mirrorid
                           from mm_mirror_td
                          where mirrordate = v_startdate
                            and subcompany = in_subcompany
                            and mirrortype = cst_usable_type);
    /*过滤金额为0的*/
    insert into mm_temp_usablesum_td
      (usableno,
       dailyauditno,
       currencycode,
       amount,
       usedamount,
       businestype,
       opdate)
      select usableno,
             min(dailyauditno) dailyauditno,
             max(currencycode) currencycode,
             sum(amount) amount,
             sum(usedamount) usedamount,
             businestype,
             min(opdate)
        from mm_temp_usableevent_td
       group by usableno, businestype
      having sum(amount) != sum(usedamount);
    /*插入明细记录,预收无单*/
    insert into mm_usablemirror_td
      (listno,
       mirrorid,
       usableno,
       policyno,
       dailyauditno,
       currencycode,
       subcompany,
       amount,
       usedamount,
       businestype,
       unitcode,
       agentcode,
       classescode,
       departmentcode,
       opstatus,
       customername,
       classescodename,
       unitname,
       departmentname,
       startdate,
       enddate,
       opdate,
       customercode,
       transactorcode,
       accountage)
      select seq_usablereserve.nextval,
             i_mirrorid,
             t.usableno,
             null,
             t.dailyauditno,
             u.currencycode,
             u.subcompany,
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount), -1, u.amount, t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /**↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + u.amount),
                           t.usedamount),
                    t.usedamount) usedamount,
             --'1',--businestype
             t.businestype,--businestype  modify by yaozhiqiang huahai 2015-7-8
             u.unitcode,
             u.agentcode,
             null,
             u.departmentcode,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + u.amount),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             u.customername,
             null,
             (select unitname from mm_unit_tc where unitcode = u.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = u.departmentcode),
             null,
             null,
             t.opdate,
             u.customercode,
             '0',
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - u.opdate + 1)) between
                     long1 and long2) accountage
        from mm_usablemoney_td u, mm_temp_usablesum_td t
       where u.usableno = t.usableno
         and t.businestype in('1','2','5'); --modify by yaozhiqiang 20150618 huahai 2为协议预收 5为卡折预收
    /*插入明细记录,预收有单*/
    insert into mm_usablemirror_td
      (listno,
       mirrorid,
       usableno,
       policyno,
       dailyauditno,
       currencycode,
       subcompany,
       amount,
       usedamount,
       businestype,
       unitcode,
       agentcode,
       classescode,
       departmentcode,
       opstatus,
       customername,
       classescodename,
       unitname,
       departmentname,
       startdate,
       enddate,
       opdate,
       customercode,
       transactorcode,
       accountage)
      select seq_usablereserve.nextval,
             i_mirrorid,
             t.usableno,
             p.policyno,
             t.dailyauditno,
             t.currencycode,
             p.subcompany,
             t.amount,
             t.usedamount,
             t.businestype,
             p.unitcode,
             p.agentcode,
             p.classescode,
             p.departmentcode,
             decode(t.usedamount, t.amount, '2', 0, '0', '1') opstatus,
             p.customername,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             p.startdate,
             p.enddate,
             t.opdate,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.startdate + 1)) between
                     long1 and long2) accountage
        from mm_policy_td p, mm_temp_usablesum_td t
       where p.seqpolicy = t.usableno
         and t.businestype in ('3', '4','5');
    begin
      /*检查切到数据,有则返回 0 正确,否则报错*/
      select 0
        into flag
        from mm_usablemirror_td
       where mirrorid = i_mirrorid
         and rownum = 1;
    exception
      when no_data_found then
        raise_application_error(-20001,
                                '切片失败：没有找到有效的切片数据!');
    end;
    -- handle_plan_accountage_um(in_enddate, i_mirrorid);
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片！';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
      flag := -1;
  end;
  -----------------------------------------------------------------------------
  -- 储金台帐切片
  procedure mm_setreservemirror(in_subcompany in mm_mirror_td.subcompany%type,
                                in_enddate    in mm_mirror_td.mirrordate%type,
                                in_opcode     in mm_mirror_td.opcode%type,
                                flag          out nocopy pls_integer,
                                errmsg        out nocopy varchar2) is
    v_startdate mm_mirror_td.mirrordate%type;
    i_mirrorid  mm_mirror_td.mirrorid%type;
  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_reserve_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete MM_MIRROR_TD
     where mirrordate = in_enddate
       and mirrortype = cst_reserve_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete MM_RESERVEMIRROR_TD where mirrorid = i_mirrorid;

    if v_startdate is not null then
      insert into MM_TEMP_EVENT_TD
        (POLICYNO,
         BASECURRENCYCODE,
         SUBCOMPANY,
         TOTALRESERVE,
         RESERVEBALANCE,
         INCOMERESERVE,
         BACKRESERVE,
         RETURNRESERVE,
         BUSINESTYPE,
         UNITCODE,
         AGENTCODE,
         departmentcode,
         CLASSESCODE,
         STARTDATE,
         ENDDATE,
         CUSTOMERNAME)
        select policy.policyno,
               paydetail.basecurrencycode,
               paydetail.subcompany,
               policy.baseamount          as TOTALRESERVE,
               paydetail.amount           as RESERVEBALANCE,
               paydetail.amount           as INCOMERESERVE,
               0                          as BACKRESERVE,
               0                          as RETURNRESERVE,
               paydetail.businessone      as businestype,
               policy.unitcode,
               policy.agentcode,
               policy.departmentcode,
               policy.CLASSESCODE,
               policy.startdate,
               policy.enddate,
               policy.customername
          from mm_paymentin_events_td paydetail, mm_policy_td policy
         where 1 = 1
           and policy.seqpolicy = paydetail.newno
           and paydetail.businessone in ('201', '202')
           and paydetail.auditstatus = '4'
           and (paydetail.auditdate between v_startdate and in_enddate)
           and paydetail.tosubcompany = in_subcompany;

      insert into MM_TEMP_EVENT_TD
        (POLICYNO,
         BASECURRENCYCODE,
         SUBCOMPANY,
         TOTALRESERVE,
         RESERVEBALANCE,
         INCOMERESERVE,
         BACKRESERVE,
         RETURNRESERVE,
         BUSINESTYPE,
         UNITCODE,
         AGENTCODE,
         departmentcode,
         CLASSESCODE,
         STARTDATE,
         ENDDATE,
         CUSTOMERNAME)
        select policy.policyno,
               policydetail.basecurrencycode,
               policydetail.subcompany,
               policy.baseamount,
               -policydetail.AMOUNT          as RESERVEBALANCE,
               0                             as INCOMERESERVE,
               0                             as BACKRESERVE,
               policydetail.AMOUNT           as RETURNRESERVE,
               policydetail.businesstwo      as businestype,
               policy.unitcode,
               policy.agentcode,
               policy.departmentcode,
               policy.CLASSESCODE,
               policy.startdate,
               policy.enddate,
               policy.customername
          from mm_policy_events_td policydetail, mm_policy_td policy

         where policy.seqpolicy = policydetail.newno
           and policydetail.businesstwo in ('205', '207')
           and policydetail.auditstatus = '4'
           and (policydetail.auditdate between v_startdate and in_enddate)
           and policydetail.subcompany = in_subcompany;

      --------------
      insert into MM_TEMP_EVENT_TD
        (POLICYNO,
         BASECURRENCYCODE,
         SUBCOMPANY,
         TOTALRESERVE,
         RESERVEBALANCE,
         INCOMERESERVE,
         BACKRESERVE,
         RETURNRESERVE,
         BUSINESTYPE,
         UNITCODE,
         AGENTCODE,
         departmentcode,
         CLASSESCODE,
         STARTDATE,
         ENDDATE,
         CUSTOMERNAME)
        select policy.policyno,
               policydetail.basecurrencycode,
               policydetail.subcompany,
               policy.baseamount,
               policydetail.AMOUNT           as RESERVEBALANCE,
               0                             as INCOMERESERVE,
               policydetail.AMOUNT           as BACKRESERVE,
               0                             as RETURNRESERVE,
               policydetail.businessone      as businestype,
               policy.unitcode,
               policy.agentcode,
               policy.departmentcode,
               policy.CLASSESCODE,
               policy.startdate,
               policy.enddate,
               policy.customername
          from mm_policy_events_td policydetail, mm_policy_td policy

         where policy.seqpolicy = policydetail.newno
           and policydetail.businessone = '203'
           and policydetail.auditstatus = '4'
           and (policydetail.auditdate between v_startdate and in_enddate)
           and policydetail.subcompany = in_subcompany;
    else
      insert into MM_TEMP_EVENT_TD
        (POLICYNO,
         BASECURRENCYCODE,
         SUBCOMPANY,
         TOTALRESERVE,
         RESERVEBALANCE,
         INCOMERESERVE,
         BACKRESERVE,
         RETURNRESERVE,
         BUSINESTYPE,
         UNITCODE,
         AGENTCODE,
         departmentcode,
         CLASSESCODE,
         STARTDATE,
         ENDDATE,
         CUSTOMERNAME)
        select policy.policyno,
               paydetail.basecurrencycode,
               paydetail.subcompany,
               policy.baseamount          as TOTALRESERVE,
               paydetail.amount           as RESERVEBALANCE,
               paydetail.amount           as INCOMERESERVE,
               0                          as BACKRESERVE,
               0                          as RETURNRESERVE,
               paydetail.businessone      as businestype,
               policy.unitcode,
               policy.agentcode,
               policy.departmentcode,
               policy.CLASSESCODE,
               policy.startdate,
               policy.enddate,
               policy.customername
          from mm_paymentin_events_td paydetail, mm_policy_td policy
         where 1 = 1
           and policy.seqpolicy = paydetail.newno
           and paydetail.businessone in ('201', '202')
           and paydetail.auditstatus = '4'
           and (paydetail.auditdate <= in_enddate)
           and paydetail.tosubcompany = in_subcompany;

      insert into MM_TEMP_EVENT_TD
        (POLICYNO,
         BASECURRENCYCODE,
         SUBCOMPANY,
         TOTALRESERVE,
         RESERVEBALANCE,
         INCOMERESERVE,
         BACKRESERVE,
         RETURNRESERVE,
         BUSINESTYPE,
         UNITCODE,
         AGENTCODE,
         departmentcode,
         CLASSESCODE,
         STARTDATE,
         ENDDATE,
         CUSTOMERNAME)
        select policy.policyno,
               policydetail.basecurrencycode,
               policydetail.subcompany,
               policy.baseamount,
               -policydetail.AMOUNT          as RESERVEBALANCE,
               0                             as INCOMERESERVE,
               0                             as BACKRESERVE,
               policydetail.AMOUNT           as RETURNRESERVE,
               policydetail.businesstwo      as businestype,
               policy.unitcode,
               policy.agentcode,
               policy.departmentcode,
               policy.CLASSESCODE,
               policy.startdate,
               policy.enddate,
               policy.customername
          from mm_policy_events_td policydetail, mm_policy_td policy

         where policy.seqpolicy = policydetail.newno
           and policydetail.businesstwo in ('205', '207')
           and policydetail.auditstatus = '4'
           and (policydetail.auditdate <= in_enddate)
           and policydetail.subcompany = in_subcompany;

      --------------
      insert into MM_TEMP_EVENT_TD
        (POLICYNO,
         BASECURRENCYCODE,
         SUBCOMPANY,
         TOTALRESERVE,
         RESERVEBALANCE,
         INCOMERESERVE,
         BACKRESERVE,
         RETURNRESERVE,
         BUSINESTYPE,
         UNITCODE,
         AGENTCODE,
         departmentcode,
         CLASSESCODE,
         STARTDATE,
         ENDDATE,
         CUSTOMERNAME)
        select policy.policyno,
               policydetail.basecurrencycode,
               policydetail.subcompany,
               policy.baseamount,
               policydetail.AMOUNT           as RESERVEBALANCE,
               0                             as INCOMERESERVE,
               policydetail.AMOUNT           as BACKRESERVE,
               0                             as RETURNRESERVE,
               policydetail.businessone      as businestype,
               policy.unitcode,
               policy.agentcode,
               policy.departmentcode,
               policy.CLASSESCODE,
               policy.startdate,
               policy.enddate,
               policy.customername
          from mm_policy_events_td policydetail, mm_policy_td policy

         where policy.seqpolicy = policydetail.newno
           and policydetail.businessone = '203'
           and policydetail.auditstatus = '4'
           and (policydetail.auditdate <= in_enddate)
           and policydetail.subcompany = in_subcompany;

    end if;

    -- select * from TEMP_EVENT_TD where  businestype in (205, 207)

    /*
    当业务类型为205，207时，将金额写入retunreserve返还的储金金额，再将baseamount改为负数。
    当业务类型为203，时将金额写入baceerserve退储的金额
    */

    -- select * from TEMP_EVENT_TD where businestype = 203;

    ---计算清单金额，计算出总的储金余额，退储的总金额，返还的总金额，收款的总金额

    insert into MM_temp_sum_event_td
      (policyno,
       basecurrencycode,
       subcompany,
       TOTALRESERVE,
       RESERVEBALANCE,

       incomereserve,
       backreserve,
       returnreserve,
       unitcode,
       AGENTCODE,
       departmentcode,
       customername,
       classescode,
       startdate,
       enddate)
      select policyno,
             basecurrencycode,
             subcompany,
             max(TOTALRESERVE),
             sum(RESERVEBALANCE),
             sum(incomereserve),
             sum(backreserve),
             sum(returnreserve),
             max(unitcode),
             max(AGENTCODE),
             max(departmentcode),
             max(customername),
             max(classescode),
             max(startdate),
             max(enddate)

        from mm_temp_event_td
       group by policyno, basecurrencycode, subcompany;

    --select * from temp_event_td;
    --select * from temp_sum_event_td
    ---储金台帐临时表
    if v_startdate is not null then
      insert into MM_TEMP_RESERVE_TD
        (policyno,
         basecurrencycode,
         subcompany,
         TOTALRESERVE,
         RESERVEBALANCE,
         incomereserve,
         backreserve,
         returnreserve,
         unitcode,
         agentcode,
         departmentcode,
         customername,
         classescode,
         startdate,
         enddate)
        (select mr.policyno,
                mr.basecurrencycode,
                mr.SUBCOMPANY,
                mr.                 TOTALRESERVE,
                mr.RESERVEBALANCE,
                mr.                 incomereserve,
                mr.                 backreserve,
                mr.                 returnreserve,

                mr.               unitcode,
                mr.agentcode,
                mr.departmentcode,
                mr.customername,
                mr.               classescode,
                mr.               startdate,
                mr.               enddate
           from MM_RESERVEMIRROR_TD mr
          where MIRRORID =
                (select mirrorid
                   from mm_mirror_td
                  where mirrordate = v_startdate
                    and subcompany = in_subcompany
                    and mirrortype = cst_reserve_type));

      /*
      select * from MM_RESERVEMIRROR_TD
      select * from temp_reserve_td;
      select * from temp_sum_event_td;
      select * from temp_reserve_td;*/
      ---更新储金台帐临时表的退储金额，储金余额，储金返还金额

      update mm_temp_reserve_td tr
         set (RESERVEBALANCE, BACKRESERVE, RETURNRESERVE) =
             (select tr.RESERVEBALANCE + ts.RESERVEBALANCE,
                     tr.BACKRESERVE + ts.backreserve,
                     tr.RETURNRESERVE + ts.returnreserve
                from mm_temp_sum_event_td ts
               where ts.subcompany = tr.subcompany
                 and ts.basecurrencycode = tr.basecurrencycode
                 and ts.policyno = tr.policyno);

    end if;

    -----------
    --select * from temp_reserve_td
    --对于储金表中不存在的记录进行新增

    insert into mm_temp_reserve_td
      (policyno,
       basecurrencycode,
       subcompany,
       totalreserve,
       incomereserve,
       backreserve,
       returnreserve,
       RESERVEBALANCE,
       unitcode,
       customername,
       AGENTCODE,
       departmentcode,
       classescode,
       startdate,
       enddate)
      (select ts.policyno,
              ts.basecurrencycode,
              ts.subcompany,
              ts.totalreserve,
              ts.incomereserve,
              ts.backreserve,
              ts.returnreserve,
              ts.RESERVEBALANCE,
              ts.unitcode,
              ts.customername,
              ts.agentcode,
              ts.departmentcode,
              ts.classescode,
              ts.startdate,
              ts.enddate
         from mm_temp_sum_event_td ts
        where not exists (select *
                 from mm_temp_reserve_td tr2
                where tr2.subcompany = ts.subcompany
                  and tr2.basecurrencycode = ts.basecurrencycode
                  and tr2.POLICYNO = ts.POLICYNO));

    --插入切片主表

    insert into MM_MIRROR_TD
      (MIRRORID, MIRRORDATE, SUBCOMPANY, MIRRORTYPE, opstatus, opcode)
    values
      (SEQ_MIRROR.NEXTVAL,
       in_enddate,
       in_subcompany,
       cst_reserve_type,
       c_month,
       in_opcode);

    --插入切片清单表

    insert into MM_RESERVEMIRROR_TD
      (LISTNO,
       mirrorid,
       unitcode,
       policyno,
       subcompany,
       basecurrencycode,
       classescode,
       TOTALRESERVE,
       INCOMERESERVE,
       BACKRESERVE,
       RETURNRESERVE,
       RESERVEBALANCE,
       CUSTOMERNAME,
       AGENTCODE,
       departmentcode,
       STARTDATE,
       ENDDATE,
       classescodename,
       unitname,
       departmentname)

      (select Seq_Reservemirror.Nextval,
              SEQ_MIRROR.CURRVAL,
              tr.unitcode,
              tr.policyno,
              tr.subcompany,
              tr.basecurrencycode,
              tr.classescode,
              tr.TOTALRESERVE,
              tr.INCOMERESERVE,
              tr.BACKRESERVE,
              tr.RETURNRESERVE,
              tr.RESERVEBALANCE,
              tr.CUSTOMERNAME,
              tr.AGENTCODE,
              tr.departmentcode,
              tr.STARTDATE,
              tr.ENDDATE,
              (select classescodename
                 from mm_classescode_tc
                where classescode = tr.classescode),
              (select unitname from mm_unit_tc where unitcode = tr.unitcode),
              (select departmentname
                 from mm_department_tc
                where departmentcode = tr.departmentcode)
         from mm_temp_reserve_td tr);
    if sql%notfound then
      raise_application_error(-20001, '切片失败：没有找到有效的切片数据！');
    end if;
    flag := 0;
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片！';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
      flag := -1;
  end;
  -----------------------------------------------------------------------------
  -- 再保切片的坏账插入(要在加个字段)
  procedure handle_plan_accountage_ri(mirrordate_in in mm_mirror_td.mirrordate%type,
                                      mirrorid_in   in mm_mirror_td.mirrorid%type) is
    i_remains_tmp     mm_plan_td.amount%type;
    c_accountage      mm_bad_debts_list.accountage%type;
    i_accountdate     mm_bad_debts_list.accountdate%type;
    i_extract_percent mm_accountageset_tc.extract_percent%type;
    i_extract_amount  mm_bad_debts_list.this_amount %type;
    tmp_date          date;
  begin

    for rec in (select count(1) over(partition by m.listno) cnt,
                       m.*,
                       p.thisseq,
                       p.amount plan_amount,
                       p.datedate
                  from mm_reinsurancemirror_td m
                  left join mm_plan_td p
                    on p.seqcharge = m.seqricontracttab
                 where m.datatype in ('891', '892', '893', '894') --未写完
                   and m.mirrorid = mirrorid_in
                 order by m.listno, p.thisseq) loop
      if rec.thisseq = 1 then
        --对应的是 mm_pay_plan_ti.serialno 缴付序号
        i_remains_tmp := rec.realamount; --mm_policymirror_td的已处理金额
      end if;
      if rec.cnt = 1 then
        i_extract_amount := rec.remains; --坏账mm_bad_debts_list.this_amount(应收缴费金额)=mm_policymirror_td.remains(余额)
      elsif i_remains_tmp >= rec.plan_amount then
        --已处理金额>mm_plan_td.amount计划缴付金额
        i_remains_tmp := i_remains_tmp - rec.plan_amount;
        goto continue;
      else
        i_extract_amount := rec.plan_amount - i_remains_tmp; --应收缴费金额=金额-已处理金额
        i_remains_tmp    := 0.00;
      end if;
      /*2008-11-3/gq/对于批增帐龄算签单日期,其他按原来逻辑不变.*/
      /*2009-4-14/gq/批增帐龄取起保日期和签单日期的大者*/
      tmp_date      := rec.opdate;
      i_accountdate := greatest(0,
                                mirrordate_in - --记账日期i_accountdate
                                (case
                                  when rec.cnt = 1 then
                                   tmp_date
                                  else
                                   rec.datedate
                                end) + 1); --计划缴付日期datedate
      begin
        --取坏账计提的账龄和比例
        select accountage, extract_percent
          into c_accountage, i_extract_percent
          from mm_accountageset_tc
         where agekind = '1'
           and i_accountdate between long1 and long2;
      exception
        when no_data_found then
          raise_application_error(mm_errorlog_pkg.e_no_data_found,
                                  '获取帐龄失败,帐龄天数=' || i_accountdate ||
                                  '天,请检查帐龄表mm_accountageset_tc!');
      end;
      insert into mm_bad_debts_list
        (extract_date,
         mirrorid,
         seqpolicy,
         subcompany,
         policyno,
         endorseno,
         currencycode,
         unitcode,
         departmentcode,
         customercode,
         customername,
         transactorcode,
         underwritercode,
         classescode,
         risktype,
         classeskind,
         agentcode,
         opstatus,
         accountage,
         accountdate,
         signdate,
         startdate,
         enddate,
         opdate,
         amount,
         realamount,
         remains,
         plan_date,
         plan_seq,
         plan_amount,
         is_bad,
         is_start,
         this_amount,
         bad_percent,
         bad_amount)
      values
        (mirrordate_in, --extract_date
         mirrorid_in, --mirrorid
         rec.seqricontracttab, --seqpolicy
         rec.subcompany, --subcompany
         rec.policyno, --policyno
         rec.endorseno, --endorseno
         rec.currencycode, --currencycode
         rec.unitcode, --unitcode
         rec.departmentcode, --departmentcode
         rec.reinsurercode, --customercode 再保没有customercdoe
         null, --customername --这个也没有
         null, -- transactorcode --经办人
         null, --underwritercode --核保员代码
         rec.classescode, --classescode
         null, --risktype --风险类别
         null, --classeskind --业务险类
         null, --agentcode --代理点
         rec.opstatus, --opstatus
         c_accountage, --accountage
         i_accountdate, --accountdate
         rec.opdate, --signdate --签单日期
         rec.opdate, --startdate --起保日期
         rec.opdate, --enddate --终止日期
         rec.opdate, --opdate
         rec.amount, --amount
         rec.realamount, --realamount
         rec.remains, --remains
         decode(rec.cnt, 1, null, rec.datedate), --plan_date
         decode(rec.cnt, 1, '0', rec.thisseq), --plan_seq
         decode(rec.cnt, 1, null, rec.plan_amount), --plan_amount
         'N', --is_bad
         decode(i_accountdate, 0, 'N', 'Y'), --is_start
         i_extract_amount, --this_amount
         i_extract_percent, --bad_percent
         i_extract_amount * i_extract_percent); --bad_amount
      <<continue>>
      null;
    end loop;
  end handle_plan_accountage_ri;
  ------------------------------------------------------------------------------------------
  --再保台帐切片
  procedure mm_setreinsurancemirror(in_subcompany in mm_mirror_td.subcompany%type,
                                    in_enddate    in mm_mirror_td.mirrordate%type,
                                    in_opcode     in mm_mirror_td.opcode%type,
                                    flag          out nocopy pls_integer,
                                    errmsg        out nocopy varchar2) is
    v_startdate mm_mirror_td.mirrordate%type;
    i_mirrorid  mm_mirror_td.mirrorid%type;
  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_reinsurance_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete mm_mirror_td m
     where mirrordate = in_enddate
       and mirrortype = cst_reinsurance_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete mm_reinsurancemirror_td where mirrorid = i_mirrorid;
    /*插入切片主表*/
    insert into mm_mirror_td
      (mirrorid, mirrordate, subcompany, mirrortype, opstatus, opcode)
    values
      (seq_mirror.nextval,
       in_enddate,
       in_subcompany,
       cst_reinsurance_type,
       c_month,
       in_opcode);
    /*插入明细记录*/
    insert into mm_reinsurancemirror_td
      (listno,
       mirrorid,
       seqriinsurence,
       seqricontracttab,
       datatype,
       subcompany,
       policyno,
       endorseno,
       tabperiod,
       contractcode,
       currencycode,
       unitcode,
       unitname,
       departmentcode,
       departmentname,
       reinsurercode,
       reinsurername,
       classescode,
       classescodename,
       ifoversea,
       opstatus,
       opdate,
       amount,
       realamount,
       remains,
       accountage,
       accountday)
      with reins_tmp as
       (
        -- 应收再保 总体显示正数
        /*分出保费,存出准备金,分入业务的赔款和手续费均为付款,
        业务类型代码中间分别为(0,4,8),金额取反*/
        select oldno seq_reins,
                ---edit by yeyu begin
                /* (case
                  when substr(businessone, 2, 1) in ('0', '4', '8') then
                   -amount
                  else
                   amount
                end) amount,*/
                -amount amount,
                --edit by yeyu end

                0.00 realamount
          from mm_policy_events_td
         where 1 = 1
              --edit by yeyu begin
              --regexp_like(businessone, '^8[0-8][1-9]$')
           and businessone in ('RA1','RA2','RA3','RA4','RAA','RAB','RAC','RAD','RAE','RAF',
                                            'RB6','RB8','RB9',
                                            'RD1','RD2','RD3','RD4','RDA','RDB','RDC','RDD','RDE','RDF',
                                            'RF1','RF2','RF3','RF4','RFA','RFB','RFC','RFD','RFE','RFF') 
           and businesstwo = '996'
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all
        select oldno   seq_reins,
                -amount amount, --付款数据在业务流水里面是正,上面分入保费导出是正,此处要导出为负
                0.00    realamount
          from mm_policy_events_td
         where 1 = 1
           and businessone = '997'
           and businesstwo in ('RA6', 'RA7') ---分入业务里面的退保情况,还有其他业务类型的也此添加(应收里面的负数)
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all /*(891)应收分保账款法定,(892)应收分保账款合同↓*/
        select oldno, 0.00, -amount
          from mm_paymentin_events_td
         where businessone in ('921', '922', '923', '414')
           and businesstwo in
               ('R81', 'R82', 'R83', 'R84', 'R85', 'R86', 'R87', 'R88',
               'R8A','R8B','R8C','R8D','R8E','R8F','R8G','R8H','R8I','R8J',
               'R8K','R8L','R8M','R8N','R8O','R8P','R8Q','R8R','R8S','R8T',
               'R8U','R8V','R8W','R8X')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
        union all /*(893)应收分保账款超赔,(894)应收分保账款临分↑*/
        select newno, 0.00, amount
          from mm_paymentin_events_td
         where businessone in
               ('R81', 'R82', 'R83', 'R84', 'R85', 'R86', 'R87', 'R88',
               'R8A','R8B','R8C','R8D','R8E','R8F','R8G','R8H','R8I',
               'R8J','R8K','R8L','R8M','R8N','R8O','R8P','R8Q','R8R',
               'R8S','R8T','R8U','R8V','R8W','R8X')
           and businesstwo in ('911', '912', '403', '414', '898')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
        -- 应付再保 总体显示正数
        /*分出保费,存出准备金,分入业务的赔款和手续费均为付款,
        业务类型代码中间分别为(0,4,8),其他均为收款,收款部分金额取反*/
        union all
        select oldno, amount amount, 0.00 realamount
          from mm_policy_events_td
         where businessone = '997'
           and businesstwo in ('RB1','RB2','RB3','RB4','RBA','RBB','RBC','RBD','RBE','RBF',
                                            'RC1','RC2','RC3','RC4','RCA','RCB','RCC','RCD','RCE','RCF',
                                            'RE1','RE2','RE3','RE4','RE6','REA','REB','REC','RED','REE','REF')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all
        select oldno, amount amount, 0.00 realamount
          from mm_policy_events_td
         where businessone IN ('RB6', 'RB7') --临分,分出退保费,需要显示在应付里面
           and businesstwo = '996'
              --and businesstwo in ('R01','R02','R03','R04','RB1','RB2','RB3','RB4','RB5','RC1','RC2','RC3','RC4','RE1','RE2','RE3','RE4') --yzh20120314
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and subcompany = in_subcompany
        union all /*(895)应付分保账款法定,(896)应付分保账款合同*/
        select oldno, 0.00, amount
          from mm_paymentin_events_td
         where businessone in ('921', '922', '923', '414', '894')
           and businesstwo in
               ('R91', 'R92', 'R93', 'R94', 'R95', 'R96', 'R97',
               'R9A','R9B','R9C','R9D','R9E','R9F','R9G','R9H',
               'R9I','R9J','R9K','R9L','R9M','R9N','R9O','R9P',
               'R9Q','R9R','R9S','R9T','R9U','R9V','R9W','R9X')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
        union all /*(897)应付分保账款超赔,(898)应付分保账款临分*/
        select newno, 0.00, -amount
          from mm_paymentin_events_td
         where businessone in
               ('R91', 'R92', 'R93', 'R94', 'R95', 'R96', 'R97',
               'R9A','R9B','R9C','R9D','R9E','R9F','R9G','R9H',
               'R9I','R9J','R9K','R9L','R9M','R9N','R9O','R9P',
               'R9Q','R9R','R9S','R9T','R9U','R9V','R9W','R9X')
           and businesstwo in ('911', '912', '403', '414')
           and auditstatus = '4'
           and opdate between nvl(v_startdate + 1, opdate) and in_enddate
           and tosubcompany = in_subcompany
        --上个月的记录
        union all
        select seqriinsurence, amount, realamount
          from mm_reinsurancemirror_td
         where mirrorid =
               (select mirrorid
                  from mm_mirror_td
                 where mirrordate = v_startdate
                   and subcompany = in_subcompany
                   and mirrortype = cst_reinsurance_type))
      select seq_reservemirror.nextval, --listno
             seq_mirror.currval, --mirrorid
             t.seq_reins, --seqriinsurence
             r.seqricontracttab, --seqricontracttab
             r.datatype, --datatype
             r.subcompany, --subcompany
             r.policyno, --policyno
             r.endorseno, --endorseno
             r.tabperiod, -- tabperiod
             r.contractcode, --contractcode
             r.currencycode, --currencycode
             r.unitcode, --unitcode
             (select unitname from mm_unit_tc where unitcode = r.unitcode), --unitname
             r.departmentcode, --departmentcode
             (select departmentname
                from mm_department_tc
               where subcompany = r.subcompany
                 and departmentcode = r.departmentcode), --departmentname
             r.customercode, -- r.reinsurercode, --reinsurercode yzh20120515区分经纪公司和再保人的
             (select reinsurername
                from mm_reinsurer_tc
               where reinsurercode = r.customercode), --reinsurername
             r.classescode, --classescode
             (select classescodename
                from mm_classescode_tc
               where classescode = r.classescode), --classescodename
             (select ifoversea
                from mm_reinsurer_tc
               where reinsurercode = r.reinsurercode), --ifoversea
             decode(t.realamount, 0.00, '0', '1'), --opstatus
             r.opdate, --opdate
             t.amount, --amount
             t.realamount, --realamount
             t.remains, --remains,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - r.opdate + 1)) between
                     long1 and long2) accountage,
                     greatest(0,
                      floor(in_enddate - r.opdate + 1)) accountday
        from mm_reinsurance_td r,
             (select seq_reins,
                     sum(amount) amount,
                     sum(realamount) realamount,
                     sum(amount - realamount) remains
                from reins_tmp
               group by seq_reins
              having sum(amount) != sum(realamount)) t
       where r.seqriinsurence = t.seq_reins;
    if sql%notfound then
      raise_application_error(-20001, '切片失败：没有找到有效的切片数据！');
    end if;
    handle_plan_accountage(in_enddate, i_mirrorid);
    flag := 0;
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片！';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
      flag := -1;
  end;
  -----------------------------------------------------------------------------
  -- 台帐切片汇总
  procedure mm_mirror_influx(mirrordate_in in mm_mirror_td.mirrordate%type) is
    i_count pls_integer;
  begin
    select count(1)
      into i_count
      from mm_accperiod_td
     where accenddate = mirrordate_in
       and accenddate < trunc(sysdate);
    if i_count = 0 then
      raise_application_error(mm_errorlog_pkg.e_no_data_found,
                              '汇总日期必须是帐期末的日期,并且不允许提前汇总!');
    end if;
    delete from mm_accountage_td where mirrordate = mirrordate_in;
    insert into mm_accountage_td
      (unitcode,
       periodname,
       accountcode,
       classescode,
       currencycode,
       ytd_entered_dr,
       ytd_accounted_dr,
       accountage,
       agetype,
       mirrordate)
      select p.unitcode,
             (select substr(accountyearmonth, 1, 4) || '-' ||
                     substr(accountyearmonth, -2)
                from mm_accperiod_td
               where subcompany =
                     (select subcompany
                        from mm_unit_tc
                       where unitcode = p.unitcode)
                 and m.mirrordate between accstartdate and accenddate
                 and rownum = 1) periodname, /*帐期*/
             '112201' accountcode,
             p.classescode,
             (select currencysign
                from mm_currencycode_tc
               where currencycode = p.currencycode),
             sum(p.remains) ytd_entered_dr,
             sum((select p.remains * exchangerate
                   from mm_conversionrate_tc
                  where currencycode1 = p.currencycode
                    and currencycode2 = 'CNY'
                    and m.mirrordate + 1 between startdate and enddate)) ytd_accounted_dr,
             p.accountage,
             m.mirrortype agetype,
             m.mirrordate mirrordate
        from mm_policymirror_td p, mm_mirror_td m
       where p.mirrorid = m.mirrorid
         and p.currencycode != 'CNY'
         and p.businessattr = '1'
         and m.mirrordate = mirrordate_in
       group by p.unitcode,
                p.classescode,
                p.currencycode,
                p.accountage,
                m.mirrortype,
                m.mirrordate;
    insert into mm_accountage_td
      (unitcode,
       periodname,
       accountcode,
       classescode,
       currencycode,
       ytd_entered_dr,
       ytd_accounted_dr,
       accountage,
       agetype,
       mirrordate)
      select p.unitcode,
             (select substr(accountyearmonth, 1, 4) || '-' ||
                     substr(accountyearmonth, -2)
                from mm_accperiod_td
               where subcompany =
                     (select subcompany
                        from mm_unit_tc
                       where unitcode = p.unitcode)
                 and m.mirrordate between accstartdate and accenddate
                 and rownum = 1) periodname, /*帐期*/
             '112201' accountcode,
             p.classescode,
             'CNY' currencycode,
             sum(decode(p.currencycode,
                        'CNY',
                        p.remains,
                        (select p.remains * exchangerate
                           from mm_conversionrate_tc
                          where currencycode1 = p.currencycode
                            and currencycode2 = 'CNY'
                            and m.mirrordate + 1 between startdate and
                                enddate))) ytd_entered_dr,
             sum(decode(p.currencycode,
                        'CNY',
                        p.remains,
                        (select p.remains * exchangerate
                           from mm_conversionrate_tc
                          where currencycode1 = p.currencycode
                            and currencycode2 = 'CNY'
                            and m.mirrordate + 1 between startdate and
                                enddate))) ytd_accounted_dr,
             p.accountage,
             m.mirrortype agetype,
             m.mirrordate mirrordate
        from mm_policymirror_td p, mm_mirror_td m
       where p.mirrorid = m.mirrorid
         and p.businessattr = '1'
         and m.mirrordate = mirrordate_in
       group by p.unitcode,
                p.classescode,
                p.accountage,
                m.mirrortype,
                m.mirrordate;
    select count(*)
      into i_count
      from mm_accountage_td
     where mirrordate = mirrordate_in
       and ytd_accounted_dr is null;
    if i_count != 0 then
      raise_application_error(mm_errorlog_pkg.e_null_value,
                              '汇率表没有当前日期汇率!');
    end if;
    -- 增加保险卡调账功能
    /*update mm_accountageauto_td au
      set au.currencycode = (select currencysign
                               from mm_currencycode_tc
                              where currencycode = au.currencycode)
    where au.mirrordate = mirrordate_in;*/
    for recauto_in in (select *
                         from mm_accountageauto_td aca
                        where aca.flag != 0
                          and aca.flag != 999
                          and exists
                        (select 1
                                 from mm_accountage_td acc
                                where acc.mirrordate = mirrordate_in
                                  and trim(aca.unitcode) = trim(acc.unitcode)
                                  and trim(aca.classescode) =
                                      trim(acc.classescode)
                                  and trim((select currencysign
                                             from mm_currencycode_tc
                                            where currencycode =
                                                  aca.currencycode)) =
                                      trim(acc.currencycode)
                                  and trim(aca.accountage) =
                                      trim(acc.accountage)
                                  and trim(aca.agetype) = trim(acc.agetype)
                                  and trim(aca.accountcode) =
                                      trim(acc.accountcode))) loop

      ---- 把符合条件的mm_accountageauto_td 金额插入到mm_accountage_td中
      update mm_accountage_td a
         set a.ytd_entered_dr   = a.ytd_entered_dr +
                                  decode(recauto_in.currencycode,
                                         'CNY',
                                         recauto_in.ytd_entered_dr,
                                         (select recauto_in.ytd_entered_dr *
                                                 exchangerate
                                            from mm_conversionrate_tc
                                           where currencycode1 =
                                                 recauto_in.currencycode
                                             and currencycode2 = 'CNY'
                                             and mirrordate_in + 1 between
                                                 startdate and enddate)),
             a.ytd_accounted_dr = a.ytd_accounted_dr +
                                  decode(recauto_in.currencycode,
                                         'CNY',
                                         recauto_in.ytd_entered_dr,
                                         (select recauto_in.ytd_entered_dr *
                                                 exchangerate
                                            from mm_conversionrate_tc
                                           where currencycode1 =
                                                 recauto_in.currencycode
                                             and currencycode2 = 'CNY'
                                             and mirrordate_in + 1 between
                                                 startdate and enddate)),
             a.hibernateversion = a.hibernateversion + 1
       where a.mirrordate = mirrordate_in
         and trim(a.unitcode) = trim(recauto_in.unitcode)
         and trim(a.classescode) = trim(recauto_in.classescode)
            /*and trim(a.currencycode) =
            trim((select currencysign
                   from mm_currencycode_tc
                  where currencycode = recauto_in.currencycode))*/
         and trim(a.accountage) = trim(recauto_in.accountage)
         and trim(a.agetype) = trim(recauto_in.agetype)
         and trim(a.accountcode) = trim(recauto_in.accountcode);
      update mm_accountageauto_td a
         set a.flag             = 0,
             a.lastopdate       = sysdate,
             a.hibernateversion = a.hibernateversion + 1
       where a.id = recauto_in.id;
      insert into mm_accountageautolist_td
        (id,
         chage_id,
         unitcode,
         classescode,
         currencycode,
         accountcode,
         ytd_entered_dr,
         accountage,
         agetype,
         flag)
        select seq_default.nextval id,
               a.id                chage_id,
               a.unitcode          unitcode,
               a.classescode       classescode,
               a.currencycode      currencycode,
               a.accountcode       accountcode,
               a.ytd_entered_dr    ytd_entered_dr,
               a.accountage        accountage,
               a.agetype           agetype,
               0                   flag
          from mm_accountageauto_td a
         where a.id = recauto_in.id;
      commit;
    end loop;

    -----把不符合条件的mm_accountageauto_td直接插入mm_accountage_td
    insert into mm_accountage_td
      (unitcode,
       periodname,
       accountcode,
       classescode,
       currencycode,
       ytd_entered_dr,
       ytd_accounted_dr,
       accountage,
       agetype,
       mirrordate)
      select a.unitcode,
             (select substr(accountyearmonth, 1, 4) || '-' ||
                     substr(accountyearmonth, -2)
                from mm_accperiod_td
               where subcompany =
                     (select subcompany
                        from mm_unit_tc
                       where unitcode = a.unitcode)
                 and mirrordate_in between accstartdate and accenddate
                 and rownum = 1) periodname, /*帐期*/
             a.accountcode,
             a.classescode,
             (select currencysign
                from mm_currencycode_tc
               where currencycode = a.currencycode),
             sum(a.ytd_entered_dr) ytd_entered_dr,
             sum((select a.ytd_entered_dr * exchangerate
                   from mm_conversionrate_tc
                  where currencycode1 = a.currencycode
                    and currencycode2 = 'CNY'
                    and mirrordate_in + 1 between startdate and enddate)) ytd_accounted_dr,
             a.accountage,
             a.agetype,
             mirrordate_in mirrordate
        from mm_accountageauto_td a
       where a.currencycode != 'CNY'
         and a.flag != 0
         and a.flag != 999
       group by a.unitcode,
                a.classescode,
                a.currencycode,
                a.accountage,
                a.agetype,
                a.accountcode;

    insert into mm_accountage_td
      (unitcode,
       periodname,
       accountcode,
       classescode,
       currencycode,
       ytd_entered_dr,
       ytd_accounted_dr,
       accountage,
       agetype,
       mirrordate)
      select a.unitcode,
             (select substr(accountyearmonth, 1, 4) || '-' ||
                     substr(accountyearmonth, -2)
                from mm_accperiod_td
               where subcompany =
                     (select subcompany
                        from mm_unit_tc
                       where unitcode = a.unitcode)
                 and mirrordate_in between accstartdate and accenddate
                 and rownum = 1) periodname, /*帐期*/
             a.accountcode,
             a.classescode,
             'CNY' currencycode,
             sum(decode(a.currencycode,
                        'CNY',
                        a.ytd_entered_dr,
                        (select a.ytd_entered_dr * exchangerate
                           from mm_conversionrate_tc
                          where currencycode1 = a.currencycode
                            and currencycode2 = 'CNY'
                            and mirrordate_in + 1 between startdate and
                                enddate))) ytd_entered_dr,
             sum(decode(a.currencycode,
                        'CNY',
                        a.ytd_entered_dr,
                        (select a.ytd_entered_dr * exchangerate
                           from mm_conversionrate_tc
                          where currencycode1 = a.currencycode
                            and currencycode2 = 'CNY'
                            and mirrordate_in + 1 between startdate and
                                enddate))) ytd_accounted_dr,
             a.accountage,
             a.agetype,
             mirrordate_in mirrordate
        from mm_accountageauto_td a
       where a.flag != 0
         and a.flag != 999
       group by a.unitcode,
                a.classescode,
                a.accountage,
                a.agetype,
                a.accountcode;
    update mm_accountageauto_td a
       set a.flag             = 0,
           a.lastopdate       = sysdate,
           a.hibernateversion = a.hibernateversion + 1
     where a.flag != 0
       and a.flag != 999;
    insert into mm_accountageautolist_td
      (id,
       chage_id,
       unitcode,
       classescode,
       currencycode,
       accountcode,
       ytd_entered_dr,
       accountage,
       agetype,
       flag)
      select seq_default.nextval id,
             a.id                chage_id,
             a.unitcode          unitcode,
             a.classescode       classescode,
             a.currencycode      currencycode,
             a.accountcode       accountcode,
             a.ytd_entered_dr    ytd_entered_dr,
             a.accountage        accountage,
             a.agetype           agetype,
             0                   flag
        from mm_accountageauto_td a
       where a.flag != 0
         and a.flag != 999;
    commit;
    ------------------
    /*delete from Statintfplanage
     where mirrordate = to_char(mirrordate_in, 'YYYY-fmMM-DD');
    insert into Statintfplanage
      (systemid,
       unitcode,
       periodname,
       accountcode,
       classescode,
       currencycode,
       ptd_entered_dr,
       ptd_entered_cr,
       ytd_entered_dr,
       ytd_entered_cr,
       ptd_accounted_dr,
       ptd_accounted_cr,
       ytd_accounted_dr,
       ytd_accounted_cr,
       accountage,
       agetype,
       mirrordate)
      select systemid,
             unitcode,
             periodname,
             accountcode,
             classescode,
             currencycode,
             ptd_entered_dr,
             ptd_entered_cr,
             ytd_entered_dr,
             ytd_entered_cr,
             ptd_accounted_dr,
             ptd_accounted_cr,
             ytd_accounted_dr,
             ytd_accounted_cr,
             accountage,
             agetype,
             to_char(mirrordate, 'YYYY-fmMM-DD')
        from mm_accountage_td
       where mirrordate = mirrordate_in;*/
    commit;
  exception
    when others then
      rollback;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => mirrordate_in);
      dbms_output.put_line(sqlerrm);
  end mm_mirror_influx;

  procedure handle_plan_accountage_badType(mirrordate_in in mm_mirror_td.mirrordate%type,
                                           mirrorid_in   in mm_mirror_td.mirrorid%type,
                                           badType       in char) is
  begin
    case badType
      when '0' then
        handle_plan_accountage_ri(mirrordate_in, mirrorid_in);
      when '1' then
        handle_plan_accountage(mirrordate_in, mirrorid_in);
      when '2' then
        handle_plan_accountage(mirrordate_in, mirrorid_in);
      else
        dbms_output.put_line('');
    end case;
  end;

  -----------------------------------------------------------------------------
  --在途应收台帐切片
  procedure mm_setpolicyZTmirror(in_subcompany in mm_mirror_td.subcompany%type,
                                 in_enddate    in mm_mirror_td.mirrordate%type,
                                 in_opcode     in mm_mirror_td.opcode%type,
                                 flag          out nocopy pls_integer,
                                 errmsg        out nocopy varchar2) is
    v_startdate    mm_mirror_td.mirrordate%type;
    i_mirrorid     mm_mirror_td.mirrorid%type;
    c_audit_status mm_bad_debts_head.audit_status%type;   
    in_seqpolicy   mm_policy_td.seqpolicy%type;
  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_policydiffercence_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete mm_mirror_td
     where mirrordate = in_enddate
       and mirrortype = cst_policydiffercence_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete mm_policymirror_td where mirrorid = i_mirrorid;
    /*在途挂账记录XXX 9ZT*/
    insert into MM_TEMP_POLICY_TD
      (seqpolicy, amount, realamount,paychannel)-- 添加消费渠道 by liujing    2016-11-23
      select oldno, t.amount, 0.00,t.paychannel
        from mm_paymentin_events_td t
       where t.businesstwo = '9ZT'
         and t.auditstatus = '4'
         and t.opdate between nvl(v_startdate + 1, t.opdate) and in_enddate
         and t.subcompany = in_subcompany;
    /*在途销账记录401、408 9ZT*/
    insert into MM_TEMP_POLICY_TD
      (seqpolicy, amount, realamount,paychannel)-- 添加消费渠道 by liujing    2016-11-23
      select newno, 0.00, t.amount,t.paychannel
        from mm_paymentin_events_td t
       where t.businessone = '9ZT'
         and t.businesstwo in ('401', '408')
         and t.auditstatus = '4'
         AND t.subcompany = t.tosubcompany
       and t.opdate between nvl(v_startdate + 1, t.opdate) and in_enddate
         and t.subcompany = in_subcompany;
    
     insert into MM_TEMP_POLICY_TD
      (seqpolicy, amount, realamount,paychannel)-- 添加消费渠道 by liujing    2016-11-23
      select newno, 0.00, t.amount,t.paychannel
        from mm_paymentin_events_td t
       where t.businessone = '9ZT'
         and t.businesstwo in ('401', '408')
         and t.auditstatus = '4'
         AND t.subcompany != t.tosubcompany
        and t.opdate between nvl(v_startdate + 1, t.opdate) and in_enddate
         and t.tosubcompany = in_subcompany;  
        
    /*add by yaozhqiang huahai 2015-7-8 
      由于挂在途的交易流水的oldno改为了对应mm_atmpay_ti表的id
          销在途的交易流水的newno改为了对应mm_atmpay_ti的id  
      根据atmpay的id关联取mm_policy_td 的seqpolicy 并更新到MM_TEMP_POLICY_TD
    */      
    for rec in(select * from MM_TEMP_POLICY_TD) loop 
     select a.seqpolicy
       into in_seqpolicy
       from mm_policy_td a, mm_atmpay_ti m
      where m.id = rec.seqpolicy
        and m.custseq = a.custseq;
        
      update MM_TEMP_POLICY_TD b
         set b.seqpolicy = in_seqpolicy
       where b.seqpolicy = rec.seqpolicy;
    end loop;    
    
    /*上个月的数据 add by yaozhiqiang 2015-11-16 huahai*/     
    insert into mm_temp_policy_td
       (seqpolicy, amount, realamount,paychannel)-- 添加消费渠道 by liujing    2016-11-23
       select m.seqpolicy,m.amount,m.realamount,m.paychannel
         from mm_policymirror_td m
        where m.mirrorid =
              (select a.mirrorid
                 from mm_mirror_td a
                where a.mirrordate = v_startdate
                  and a.subcompany = in_subcompany
                  and a.mirrortype = cst_policydiffercence_type);         
    
    /*插入汇总记录到临时表*/
    insert into mm_temp_sumpolicy_td
      (seqpolicy, amount, realamount,paychannel)
      select seqpolicy, sum(amount), sum(realamount),paychannel-- 添加消费渠道 by liujing    2016-11-23
        from mm_temp_policy_td
       group by seqpolicy,paychannel
      having sum(amount) != sum(realamount); 
    
    /*add by yaozhqiang huahai 2015-7-8 
      由于挂在途的交易流水的oldno改为了对应mm_atmpay_ti表的id
          销在途的交易流水的newno改为了对应mm_atmpay_ti的id  
      根据atmpay的id关联取mm_policy_td 的seqpolicy 并更新到mm_temp_sumpolicy_td
    */ 
  /*  for rec in(select * from mm_temp_sumpolicy_td) loop 
     select a.seqpolicy
       into in_seqpolicy
       from mm_policy_td a, mm_atmpay_ti m
      where m.id = rec.seqpolicy
        and m.custseq = a.custseq;
        
      update mm_temp_sumpolicy_td b
         set b.seqpolicy = in_seqpolicy
       where b.seqpolicy = rec.seqpolicy;
    end loop;    */
    
  
  
    /*插入切片主表*/
    insert into mm_mirror_td
      (mirrorid, mirrordate, subcompany, mirrortype, opstatus, opcode)
    values
      (seq_mirror.nextval,
       in_enddate,
       in_subcompany,
       cst_policydiffercence_type,
       c_month,
       in_opcode) /*
                                                       returning mirrorid into i_mirrorid*/
    ;
    /*关联保单表取保单的主要信息,插入切片清单表*/
    insert into mm_policymirror_td
      (listno,
       mirrorid,
       seqpolicy,
       subcompany,
       policyno,
       endorseno,
       currencycode,
       remains,
       businessattr,
       ifstart,
       unitcode,
       departmentcode,
       startdate,
       enddate,
       opdate,
       customercode,
       customername,
       transactorcode,
       underwritercode,
       classescode,
       risktype,
       classeskind,
       agentcode,
       signdate,
       seqcharge,
       opstatus,
       amount,
       realamount,
       accountage,
       accountday,
       classescodename,
       unitname,
       departmentname,
       custseq,
       transactorname,
       optcode,
       optname,
       masterno,
       mastername,
       paychannel)
      select seq_reservemirror.nextval,
             seq_mirror.currval,
             p.seqpolicy,
             p.subcompany,
             p.policyno,
             p.endorseno,
             p.currencycode,
             ts.amount - ts.realamount,
             p.businessattr,
             p.ifstart,
             p.unitcode,
             p.departmentcode,
             p.startdate,
             p.enddate,
             p.opdate,
             p.customercode,
             p.customername,
             p.transactorcode,
             p.underwritercode,
             p.classescode,
             p.risktype,
             p.classeskind,
             p.agentcode,
             p.signdate,
             p.seqcharge,
             decode(decode(ts.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(ts.realamount),
                                  -1,
                                  (ts.realamount + p.amount),
                                  ts.realamount),
                           ts.realamount),
                    0.00,
                    '0',
                    '1') opstatus,
             decode(ts.amount,
                    0.00,
                    decode(sign(ts.realamount), -1, p.amount, ts.amount),
                    ts.amount) amount,
             decode(ts.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(ts.realamount),
                           -1,
                           (ts.realamount + p.amount),
                           ts.realamount),
                    ts.realamount) realamount,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.startdate + 1)) between
                     long1 and long2) accountage, --added by guqin/080324
             greatest(0, floor(in_enddate - p.startdate + 1)) accountday,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             p.custseq,
             p.transactorname,
             p.optcode,
             p.optname,
             p.masterno,
             p.mastername,
             paychannel
        from mm_temp_sumpolicy_td ts, mm_policy_td p
       where ts.seqpolicy = p.seqpolicy;
    if sql%notfound then
      raise_application_error(-20001, '切片失败：没有找到有效的切片数据！');
    end if;
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
  end mm_setpolicyZTmirror;
  -----------------------------------------------------------------------------
  -----------------------------------------------------------------------------
  --待摊手续费应付切片
  procedure mm_setprepaidfeepayablemirror(in_subcompany in mm_mirror_td.subcompany%type,
                                          in_enddate    in mm_mirror_td.mirrordate%type,
                                          in_opcode     in mm_mirror_td.opcode%type,
                                          flag          out nocopy pls_integer,
                                          errmsg        out nocopy varchar2) is
    v_startdate    mm_mirror_td.mirrordate%type;
    i_mirrorid     mm_mirror_td.mirrorid%type;
    c_audit_status mm_bad_debts_head.audit_status%type;
  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_prepaidfeepayable_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete mm_mirror_td m
     where mirrordate = in_enddate
       and mirrortype = cst_prepaidfeepayable_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete mm_payablemirror_td where mirrorid = i_mirrorid;
    select seq_mirror.nextval into i_mirrorid from dual;
    /*插入切片主表*/
    insert into mm_mirror_td
      (mirrorid, mirrordate, subcompany, mirrortype, opstatus, opcode)
    values
      (i_mirrorid,
       in_enddate,
       in_subcompany,
       cst_prepaidfeepayable_type,
       c_month,
       in_opcode);

    /*待摊手续费挂账记录502、506、516、518、582、586、596、598*/
    --收款
    insert into mm_temp_centralization_td
      (centralizationid, amount, realamount)
      select newno, -p.amount, 0.00
        from mm_paymentin_events_td p
       where businessone in
             ('502', '506', '516', '518', '582', '586', '596', '598','536','538')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany;

         --付款
    insert into mm_temp_centralization_td
      (centralizationid, amount, realamount)
      select oldno, p.amount, 0.00
        from mm_paymentin_events_td p
       where businesstwo in
             ('502', '506', '516', '518', '582', '586', '596', '598','536','538')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         and tosubcompany = in_subcompany;

    /*待摊手续费销账记录502、506、516、518、582、586、596、598*/
    insert into mm_temp_centralization_td
      (centralizationid, amount, realamount)
      select oldno, 0.00, amount
        from mm_policy_events_td
       where businessone in
             ('502', '506', '516', '518', '582', '586', '596', '598','536','538')
         and businesstwo in ('942')
         and auditstatus = '4'
         and opdate between nvl(v_startdate + 1, opdate) and in_enddate
         AND subcompany = in_subcompany; 
         
    /*上个月的数据 add by yaozhiqiang 20151116 huahai*/
    insert into mm_temp_centralization_td
      (centralizationid, amount, realamount)
      select m.paymoneyno,m.amount,m.usedamount
        from mm_payablemirror_td m
       where m.mirrorid =
             (select a.mirrorid
                from mm_mirror_td a
               where a.mirrordate = v_startdate
                 and a.subcompany = in_subcompany
                 and a.mirrortype = cst_prepaidfeepayable_type);
         
    /*插入汇总记录到临时表*/
    insert into mm_temp_sumcentralization_td
      (centralizationid, amount, realamount)
      select centralizationid, sum(amount), sum(realamount)
        from mm_temp_centralization_td
       group by centralizationid
      having sum(amount) != sum(realamount);

    insert into mm_payablemirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage)
      select seq_payablemirror.nextval,
             i_mirrorid,
             nvl(p.datatype, '108'),
             nvl(p.subcompany, '0'),
             nvl(p.departmentcode, '0'),
             p.id, --paymoneyno 待摊手续费存入的是 mm_centralizationlist_td id
             nvl(p.currencycode, '00'),
             decode(sc.amount,
                    0.00,
                    decode(sign(sc.realamount),
                           -1,
                           nvl(p.amount, 0),
                           sc.amount),
                    sc.amount) amount,
             decode(sc.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(sc.realamount),
                           -1,
                           (sc.realamount + nvl(p.amount, 0)),
                           sc.realamount),
                    sc.realamount) realamount,
             sc.amount - sc.realamount, --t.remains,
             pm.customername,
             decode(decode(sc.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(sc.realamount),
                                  -1,
                                  (sc.realamount + nvl(p.amount, 0)),
                                  sc.realamount),
                           sc.realamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             p.claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             pm.opdate,
             --pm.opdate,
             p.startdate as startdate,
             pm.agentcode,
             pm.customercode,
             pm.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - pm.opdate + 1)) between
                     long1 and long2) accountage
        from mm_temp_sumcentralization_td sc,
             mm_centralizationlist_td     p,
             mm_payablemoney_td           pm
       where sc.centralizationid = p.id
         and p.seqcentralization = pm.fatherno
         and pm.datatype in('575','576');
    if sql%notfound then
      raise_application_error(-20001, '切片失败：没有找到有效的切片数据！');
    end if;
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
  end mm_setprepaidfeepayablemirror;
  -----------------------------------------------------------------------------------------------------------
  -----------------------------------------------------------------------------------------------------------
  --非保费用单据切片 add by Liyh2018-5-18
  procedure mm_setdocnomirror(in_subcompany in mm_mirror_td.subcompany%type,
                                in_enddate    in mm_mirror_td.mirrordate%type,
                                in_opcode     in mm_mirror_td.opcode%type,
                                flag          out nocopy pls_integer,
                                errmsg        out nocopy varchar2) is
    v_startdate mm_mirror_td.mirrordate%type;
    i_mirrorid  mm_mirror_td.mirrorid%type;
    p1          mm_docnomirror_td%rowtype;

  begin
    /*检查能否做切片操作*/
    check_restrict(in_subcompany,
                   in_enddate,
                   cst_docno_type,
                   v_startdate,
                   c_month);
    /*删除切片表已有记录,相当于重切*/
    delete mm_mirror_td m
     where mirrordate = in_enddate
       and mirrortype = cst_docno_type
       and subcompany = in_subcompany
    returning mirrorid into i_mirrorid;
    delete mm_docnomirror_td where mirrorid = i_mirrorid;
    select seq_mirror.nextval into i_mirrorid from dual;
    /*插入切片主表*/
    insert into mm_mirror_td
      (mirrorid, mirrordate, subcompany, mirrortype, opstatus, opcode)
    values
      (i_mirrorid,
       in_enddate,
       in_subcompany,
       cst_docno_type,
       c_month,
       in_opcode);
    /*插入待付款切片表明细记录*/
    insert into mm_docnomirror_td
      (listno,
       mirrorid,
       datatype,
       subcompany,
       departmentcode,
       paymoneyno,
       currencycode,
       amount,
       usedamount,
       remains,
       customername,
       opstatus,
       policyno,
       endorseno,
       claimno,
       unitcode,
       classescode,
       classescodename,
       unitname,
       departmentname,
       opdate,
       startdate,
       agentcode,
       customercode,
       transactorcode,
       accountage)
      with payable_tmp as 
       (select tt.payableno as paymoneyno, 0.00 as amount, xx.amount as usedamount
          from mm_paymentin_events_td xx,
               mm_payablemoney_td tt,
               mm_billdetail_td hh
         where xx.oldno = hh.id
           and hh.seqmainid = tt.fatherno
           and xx.businesstwo in ('L02','L03')--测试非保费单据  
           and xx.auditstatus = '4'
           and xx.opdate between nvl(v_startdate + 1, xx.opdate) and in_enddate
           and xx.tosubcompany = in_subcompany 
       union all
        /*取上个月记录,如没有,v_startdate is null 就取不到记录*/
        select to_number(paymoneyno), amount, usedamount
          from mm_payablemirror_td
         where mirrorid = (select mirrorid
                             from mm_mirror_td
                            where mirrordate = v_startdate
                              and subcompany = in_subcompany
                              and mirrortype = cst_docno_type)
           and datatype not in ('502',
                                '516',
                                '113',
                                '110',
                                '111',
                                'Y10',
                                'Y07',
                                'Y13',
                                'Y14',
                                'Y15',
                                'Y16',
                                'Y17',
                                'Y19',
                                'YY3',
                                'YY4',
                                'Y06',
                                'Y08',
                                'Y27',
                                'Y23',
                                'Y24',
                                'Y03',
                                'Y02') --添加Y10不去上个月Y10的数据 byliuijing 2017-5-23 添加Y02 by2017-12-7
         )
      select seq_payablemirror.nextval,
             i_mirrorid,
             p.datatype,
             nvl(p.subcompany, '0'),
             nvl(p.departmentcode, '0'),
             t.paymoneyno,
             nvl(p.currencycode, '00'),
             decode(t.amount,
                    0.00,
                    decode(sign(t.usedamount),
                           -1,
                           nvl(p.amount, 0),
                           t.amount),
                    t.amount) amount,
             decode(t.amount,
                    0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                    decode(sign(t.usedamount),
                           -1,
                           (t.usedamount + nvl(p.amount, 0)),
                           t.usedamount),
                    t.usedamount) usedamount,
             t.remains,
             p.customername,
             decode(decode(t.amount,
                           0.00, /*↑有红冲记录会产生ts.amount=0 and realamount<0的情况,*/
                           decode(sign(t.usedamount),
                                  -1,
                                  (t.usedamount + nvl(p.amount, 0)),
                                  t.usedamount),
                           t.usedamount),
                    0.00,
                    '0',
                    '1') opstatus,
             p.policyno,
             p.endorseno,
             p.claimno,
             p.unitcode,
             p.classescode,
             (select classescodename
                from mm_classescode_tc
               where classescode = p.classescode),
             (select unitname from mm_unit_tc where unitcode = p.unitcode),
             (select departmentname
                from mm_department_tc
               where departmentcode = p.departmentcode),
             p.opdate,
             p.opdate,
             p.agentcode,
             p.customercode,
             p.transactorcode,
             (select accountage
                from mm_accountageset_tc
               where agekind = '1'
                 and greatest(0, floor(in_enddate - p.opdate + 1)) between
                     long1 and long2) accountage
        from mm_payablemoney_td p
       right join (select paymoneyno,
                          sum(amount) amount,
                          sum(usedamount) usedamount,
                          sum(amount) - sum(usedamount) remains
                     from payable_tmp
                    group by paymoneyno
                   having sum(amount) != sum(usedamount)) t
          on p.payableno = t.paymoneyno;
    if sql%notfound then
      raise_application_error(-20001, '切片失败：没有找到有效的切片数据！');
    end if;
    commit;
    
    handle_plan_accountage_pa(in_enddate, i_mirrorid);
    flag := 0;
    commit;
  exception
    when others then
      rollback;
      errmsg := substr(sqlerrm, 12);
      if sqlcode = -1 then
        errmsg := '切片失败：不能生成同一分公司、同一类型、同一日期的多个切片！';
      end if;
      mm_errorlog_pkg.log_error(procname_in => $$plsql_unit,
                                keyword1_in => in_subcompany,
                                keyword2_in => to_char(v_startdate,
                                                       'YYYY-MM-DD'),
                                keyword3_in => to_char(in_enddate,
                                                       'YYYY-MM-DD'));
      flag := -1;
  end;
  
end mm_mirror_pkg;
/
