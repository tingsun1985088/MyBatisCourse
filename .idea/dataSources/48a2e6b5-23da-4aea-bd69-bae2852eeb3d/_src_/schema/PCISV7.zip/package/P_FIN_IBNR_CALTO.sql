CREATE package P_FIN_IBNR_CALTO is
 --计算各个险类的IBNR author:shexiwan
 --再保前IBNR
 Procedure P_FIN_IBNR_CALTO(v_today in  varchar2,v_return  OUT NUMBER);
 --再保分出IBNR
 Procedure P_FIN_RI_IBNR_CALTO(v_today in  varchar2,v_return  OUT NUMBER);
 --再保分后IBNR
 Procedure P_FIN_BAC_IBNR_CALTO(v_today in  varchar2,v_return  OUT NUMBER);

end P_FIN_IBNR_CALTO;
/
