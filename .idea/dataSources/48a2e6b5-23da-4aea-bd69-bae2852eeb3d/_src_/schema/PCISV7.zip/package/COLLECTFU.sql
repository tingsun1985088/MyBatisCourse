CREATE PACKAGE "COLLECTFU" 
IS
--6.处理会计员冲正时处理单据 Charge against delete
  Procedure chargeagainst(vCavNo IN VARCHAR2, v_succsflag IN OUT NUMBER);

END CollectFu;

/
