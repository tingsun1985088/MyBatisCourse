CREATE PACKAGE BODY "INVST_FINC" is

  /* ????????????????????*/
  FUNCTION get_dischg_sum(ctype   IN VARCHAR2, /* ???3-3???5-5??, caojy add 6-5??,zhanghui add 7,9-1??*/
                          bgn_tm  IN DATE, /* ????*/
                          end_tm  IN DATE, /* ????*/
                          stat_tm IN DATE, /* ????*/
                          icount  IN NUMBER /* ??*/) RETURN NUMBER IS
    vsum   NUMBER(16, 2);
    imonth NUMBER;
  BEGIN
    IF TO_DATE(TO_CHAR(stat_tm, 'yyyymmdd'), 'yyyymmdd') -
       TO_DATE(TO_CHAR(bgn_tm, 'yyyymmdd'), 'yyyymmdd') >= 15 THEN
      /* ?????????*/
      IF stat_tm > end_tm THEN
        SELECT CEIL(MONTHS_BETWEEN(TO_DATE(TO_CHAR(end_tm, 'yyyymmdd'),
                                           'yyyymmdd') + 1,
                                   TO_DATE(TO_CHAR(bgn_tm, 'yyyymmdd'),
                                           'yyyymmdd')))
          INTO imonth
          FROM DUAL;
      ELSE
        SELECT CEIL(MONTHS_BETWEEN(TO_DATE(TO_CHAR(stat_tm, 'yyyymmdd'),
                                           'yyyymmdd') + 1,
                                   TO_DATE(TO_CHAR(bgn_tm, 'yyyymmdd'),
                                           'yyyymmdd')))
          INTO imonth
          FROM DUAL;
      END IF;

      /* ????*/
      IF ctype NOT IN ('3', '5', '6','7','9') /*caojy add 6 2006-01-13*//*zhanghui add 7,9 2008-04-08*/
       THEN
        RETURN - 1;
      END IF;

      /* 3????????*/
      IF imonth > 36 AND ctype = '3' THEN
        RETURN - 2;
      END IF;

      /* 5????????*/
      IF imonth > 60 AND (ctype = '5' OR ctype = '6') /*caojy add 6 2006-01-13*/
       THEN
        RETURN - 3;
      END IF;

     /* 1????????*/
      IF imonth > 12 AND (ctype = '7' OR ctype = '9') /*zhanghui add 7,9 2008-04-08*/
       THEN
        RETURN - 3;
      END IF;
      /* ?????????*/
      SELECT n_sum * icount
        INTO vsum
        FROM WEB_RETURN_SUM
       WHERE c_type = ctype
         AND i_month = imonth;
    ELSE
      vsum := icount * 10000;
    END IF;

    RETURN(vsum);
  END;
end Invst_Finc;
/
