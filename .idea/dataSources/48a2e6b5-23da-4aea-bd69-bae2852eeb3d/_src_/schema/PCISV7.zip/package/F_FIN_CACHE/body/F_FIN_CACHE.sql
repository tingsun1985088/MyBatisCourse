CREATE package body f_fin_cache is

 function f_dpt_array return t_dpt_table
  as
  v_dpt_table t_dpt_table := t_dpt_table();
  i integer;
  cursor cur_dpt is
   select a.c_dpt_cde,a.c_dpt_cnm,a.c_company_cde,a.c_department_cde,a.c_dptacc_cde
   from web_org_dpt a;
  begin
    i:=0;
    for v_dpt in cur_dpt loop
        i:=i+1;
        v_dpt_table.extend();
        v_dpt_table(v_dpt_table.count) := t_dpt
        (i,v_dpt.c_dpt_cde,v_dpt.c_dpt_cnm,v_dpt.c_company_cde,v_dpt.c_department_cde,v_dpt.c_dptacc_cde);
    end loop;
  return v_dpt_table;
  end f_dpt_array;
  
  function f_prod_array return t_prod_table
  as
  v_prod_table t_prod_table := t_prod_table();
  i integer;
  cursor cur_prod is
  select a.c_prod_no,a.c_nme_cn,a.c_kind_no
  from web_bas_fin_prod a;
  begin
    i:=0;
    for v_prod in cur_prod loop
        i:=i+1;
        v_prod_table.extend();
        v_prod_table(v_prod_table.count) := t_prod
        (i,v_prod.c_prod_no,v_prod.c_nme_cn,v_prod.c_kind_no);
    end loop;
  return v_prod_table;
  end f_prod_array;
  
  function f_department_array return t_department_table
  as
  v_department_table t_department_table := t_department_table();
  i integer;
  cursor cur_department is
  select a.c_dpt_cde,a.c_dpt_cnm,a.c_department_cde,a.c_dptacc_cde
  from web_org_dpt a where a.c_sign_dpt_mrk = '1';
  begin
    i:=0;
    for v_department in cur_department loop
        i:=i+1;
        v_department_table.extend();
        v_department_table(v_department_table.count) := t_department
        (i,v_department.c_dpt_cde,v_department.c_dpt_cnm,v_department.c_department_cde,v_department.c_dptacc_cde);
    end loop;
  return v_department_table;
  end f_department_array;
  
  function f_company_array return t_company_table
  as
  v_company_table t_company_table := t_company_table();
  i integer;
  cursor cur_company is
  select a.c_dpt_cde,a.c_dpt_cnm,a.c_company_cde,a.c_dptacc_cde
  from web_org_dpt a where a.c_acct_dpt_mrk = '1';
  begin
    i:=0;
    for v_company in cur_company loop
        i:=i+1;
        v_company_table.extend();
        v_company_table(v_company_table.count) := t_company
        (i,v_company.c_dpt_cde,v_company.c_dpt_cnm,v_company.c_company_cde,v_company.c_dptacc_cde);
    end loop;
  return v_company_table;
  end f_company_array;
  
  function f_bsns_array return t_bsns_table
  as
  v_bsns_table t_bsns_table := t_bsns_table();
  i integer;
  cursor cur_bsns is
  select a.c_cha_cde,c_fincha_cde,c_fincha_cnm
  from WEB_BAS_FIN_CHA a ;
  begin
    i:=0;
    for v_bsns in cur_bsns loop
        i:=i+1;
        v_bsns_table.extend();
        v_bsns_table(v_bsns_table.count) := t_bsns
        (i,v_bsns.c_cha_cde,v_bsns.c_fincha_cde,v_bsns.c_fincha_cnm);
    end loop;
  return v_bsns_table;
  end f_bsns_array;
  
  function f_ibnr_array return t_ibnr_table
  as
  v_ibnr_table t_ibnr_table := t_ibnr_table();
  i integer;
  cursor cur_ibnr is
  select a.c_cde,a.c_kind_no,a.c_prod_no,a.c_year,a.c_quart,a.n_rate,a.c_mane
  from web_fin_ibnr_rate a ;
  begin
    i:=0;
    for v_ibnr in cur_ibnr loop
        i:=i+1;
        v_ibnr_table.extend();
        v_ibnr_table(v_ibnr_table.count) := t_ibnr
        (i,v_ibnr.c_cde,v_ibnr.c_kind_no,v_ibnr.c_prod_no,
         v_ibnr.c_year,v_ibnr.c_quart,v_ibnr.n_rate,v_ibnr.c_mane);
    end loop;
  return v_ibnr_table;
  end f_ibnr_array;
  
  
  
end f_fin_cache;
/
