CREATE PACKAGE "INVST_FINC" is

/******************************************************************************
   NAME:       INVST_FINC
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2005-3-8             1. Created this package.
******************************************************************************/
/* ????????????????????*/

  function get_dischg_sum (
  ctype     IN   VARCHAR2,                    /* ???3-3???5-5??*/
      bgn_tm    IN   DATE,                                      /* ????*/
      end_tm    IN   DATE,                                      /* ????*/
      stat_tm   IN   DATE,                                      /* ????*/
      icount    IN   NUMBER )

       RETURN NUMBER;

end Invst_Finc;










/
