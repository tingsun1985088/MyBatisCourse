CREATE PROCEDURE       "CREATEDEPTTABLE" (TABLENAME in varchar2)
IS
SQLCreateTable   VARCHAR2(2000);
SQLAlterTable    VARCHAR2(2000);
SQLCreateIndex   VARCHAR2(2000);
ERRORCODE        VARCHAR2(20);

BEGIN


  --IF HAVETABLE = 0 THEN
    /*生成Table*/
    SQLCreateTable :=
                   'create table ' ||  TABLENAME
                           || ' ( '
                           || '  N_AUTOID            NUMBER(28) not null,  '
                           || '  C_SUB_DEPT_CDE      VARCHAR2(20) not null, '
                           || '  C_FREQUENCY         VARCHAR2(1) not null, '
                           || '  C_MONTH             VARCHAR2(7) not null, '
                           || '  C_ITEM_NO           VARCHAR2(20) , '
                           || '  C_ADJUNCT_STR       VARCHAR2(500) , '
                           || '  C_CHECK_INFO        VARCHAR2(200), '
                           || '  C_ITEM_CDE          VARCHAR2(200) not null, '
                           || '  C_PRE_YEAR_RATE     VARCHAR2(20), '
                           || '  C_PRE_MONTH_RATE    VARCHAR2(20), '
                           || '  C_MARGIN            VARCHAR2(20), '
                           || '  C_VALUE             VARCHAR2(20) not null, '
                           || '  C_MARGIN_MONTH_RATE VARCHAR2(20), '
                           || '  C_MARGIN_YEAR_RATE  VARCHAR2(20), '
                           || '  C_REMARK            VARCHAR2(200), '
                           || '  C_SUB_DEPT_NME      VARCHAR2(200), '
                           || '  C_ITEM_NME          VARCHAR2(200) '
                           || ' )  '
                           || '  pctfree 10 '
                           || '  pctused 40 '
                           || '  initrans 1 '
                           || '  maxtrans 255 '
                           || '  storage '
                           || '  ( '
                           || '    initial 64K  '
                           || '    minextents 1 '
                           || '    maxextents unlimited '
                           || '  )';

    EXECUTE IMMEDIATE SQLCreateTable;

    SQLAlterTable :=
                  'alter table ' || TABLENAME
                         || '  add constraint ' ||TABLENAME || '_PK primary key (N_AUTOID)  '
                         || '  pctfree 10 '
                         || '  initrans 2 '
                         || '  maxtrans 255 '
                         || '  storage '
                         || '  ( '
                         || '    initial 64K '
                         || '    minextents 1 '
                         || '    maxextents unlimited '
                         || '  )';

    EXECUTE IMMEDIATE SQLAlterTable;

    SQLCreateIndex :=
                   'create unique index ' ||TABLENAME || '_GETITEM on ' || TABLENAME || ' (C_ITEM_CDE,C_SUB_DEPT_CDE,C_MONTH,C_FREQUENCY) '
                           || '  pctfree 10 '
                           || '  initrans 2 '
                           || '  maxtrans 255 '
                           || '  storage '
                           || '  ( '
                           || '    initial 64K '
                           || '    minextents 1 '
                           || '    maxextents unlimited '
                           || '  )';
    EXECUTE IMMEDIATE SQLCreateIndex;
    SQLCreateIndex :=
                   'create index ' ||TABLENAME || '_CHECK on ' || TABLENAME || ' (C_SUB_DEPT_CDE,C_MONTH,C_FREQUENCY) '
                           || '  tablespace INDEXES '
                           || '  pctfree 10 '
                           || '  initrans 2 '
                           || '  maxtrans 255 '
                           || '  storage '
                           || '  ( '
                           || '    initial 64K '
                           || '    minextents 1 '
                           || '    maxextents unlimited '
                           || '  )';
    EXECUTE IMMEDIATE SQLCreateIndex;
  --END IF;



END ;

/
