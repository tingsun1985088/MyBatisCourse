CREATE FUNCTION "F_GET_TAX_MAX_ENDTM" (VBILLNO IN VARCHAR2 )
return DATE
AS
V_ENDDATE DATE;
begin
  select mAX(ENDDATE)INTO V_ENDDATE from T_AutoShipRate n
    where n.BILLNO=VBILLNO
          and n.subjstatus='1';
  return(V_ENDDATE);
exception
when others then
return NULL;
end F_GET_TAX_MAX_ENDTM;









/
