CREATE procedure add_sales_end_intoxg_1 is
      v_task_start_date  date;
      v_task_end_date    date;
      v_sql_code        number;
      v_sql_msg         varchar2(4000) := ''; ---SQL错误信息
      count1    number;
     --   count2 number;
      temp_count  number;
      temp_count1  number;
      temp_count2  number;
      temp_count3  number;
      temp_sum  number;
      temp_sum2  number;
      temp_sum3 NUMBER;
      temp_sum4 NUMBER;
      temp_XB_null  number :=0;
      RES_XIANBIE varchar2(200):='';
      RES_AGENT varchar2(200):='';
      RES_SUM  varchar2(200):='';
      RES_GONGBAO   varchar2(200):='';
      res_ZZ  varchar2(200):='';
      temp_ifchannel   varchar2(200):='';
      code1  varchar2(200) := '';
      free1 varchar2(200) := '';
      --begintime         DATE;  --  同步开始时间
      --endtime           DATE;  --  同步结束时间
      --temp              NUMBER;
      res     varchar2(10):='no';
      policy_no VARCHAR2(50);
      cust_no VARCHAR2(50);
    CURSOR a1 IS
             SELECT
            CERTIID             , --              --**流水号   注掉使用销管ID
          --  salesmiddle.SEQ_PRPSBUSINESSFORWEB.Nextval@DBLINK_NEW_SALES AS no ,
            CERTINO             , --              业务号
            POLICYNO            , --               保单号
            CERTITYPE           , --                业务类型
            CLASSCODE           , --                险类代码
            RISKCODE            , --               险种代码
            COMCODE             , --              二级机构代码
            IFCHANNEL           , --                是否渠道业务
            COINSFLAG           , --                联共保标志
            SHAREHOLDERFLAG     , --                      是否股东业务标识
            STARTDATE           , --                起保日期
            ENDDATE             , --              终保日期
            INPUTDATE           , --                录入日期
            UNDERWRITEENDDATE   , --                        核保日期
            SIGNDATE            , --               签单日期
            DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
            BUSINESSNATURE      , --                     业务来源大类
            BUSINESSNATURESUB   , --                        业务来源中类
            BUSINESSNATUREMIN   , --                        业务来源小类
            APPLICODE           , --                投保人代码
            APPLINAME           , --                投保人名称
            APPLIADDRESS        , --                   投保人地址
            INSUREDCODE         , --                  被保险人代码
            INSUREDNAME         , --                  被保险人名称
            INSUREDADDRESS      , --                     被保险人地址
            --HANDLERCODE         , --                  经办人代码
            BRANCHCODE          , --                 归属业务部门
            TEAMCODE            , --               归属团队代码
            USERCODE            , --               归属业务员代码
            AGENTCODE           , --                归属代理人
            --AGENTUSERCODE       , --                    归属代理业务员
            AGREEMENTNO         , --                  代理人协议号
            --APPROVERCODE        , --                   复核人代码
            UNDERWRITECODE      , --                     最终核保人代码
            OPERATORCODE        , --                   操作员代码(录单人)
            MAKECOM             , --              录单人员归属机构
            --REINSFLAG           , --                商业分保标志
            BUSINESSFLAG        , --                   业务标识
            CURRENCY            , --               承保币种
            CNYEXCHRATE         , --                  承保汇率
            DISCOUNTRATE        , --                   总折扣率
            SUMAMOUNT           , --                总保险金额
            SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
            SUMPREMIUM          , --                 总保险费(折扣后总保费)
            ENDORTYPE           , --                批改类型
            ENDORDATE           , --                批改日期
            VALIDDATE           , --                生效日期(含时分秒)
            CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
            CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
            LICENSENO           , --                车牌号码(货运险存放发票号)
            CARKINDCODE         , --                  车辆使用类型(车险保单必填)
            --USEYEARS            , --               使用年限
            --COUNTRYNATURE       , --                    国别性质
            SEATCOUNT           , --                座位数
            TONCOUNT            , --               吨位数
            EXHAUSTSCALE        , --                   排量
            --MODELCODE           , --                厂牌车型
            IFRENEWAL           , --                是否续保
            OLDPOLICYNO         , --                  被续保单号
            GENERATEDATE        , --                   保批单生成日期
            CARSUBNATURECODE    , --                       车辆使用性质
            CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
            --ILOGDISRATE         , --                  ILOG手续费比例
            --PLATDISRATE         , --                  平台手续费比例
            A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
            BRATE              , --             B展业费比例
            C1RATE             , --              C1个人基础绩效费用比例
            DRATE               , --            D个人附加费用比例
            ERATE               , --            E机构销售管理费用比例
            IRATE               , --            I项目拓展费用费用比例
            JRATE               , --            J追加费用比例
            ISSETTLEMENT        , --                   是否结算标记
            COINSPLANFLAG       , --                    共保业务缴费方式
           -- BUSINESSDEPARTMENT  , --                         业务服务部门
            CREATEDATE          , --                 创建时间
            BIZNO,  -- 保险卡号
            BIZTYPE,  -- 单证类型
            '0' AS DATASTATUS,
            '0' AS ITEMSTATUS,
            TOTALPROTOCOLTNO, -- 预约协议号
            ISACCOUNT,  -- 是否挂账
            custseq,
            GENERATEFLAG,  -- moren  0
            AGRIMRK,
            ZCTYMRK ,
            --CHANNELTYPE,
            TAXPREMIUM, --含税保费或含税保费变化量
            TAXRATE --保单税率
      from PRPSBUSINESSFORWEB_temp1 a ;



  begin

  count1:=0;
 for    aa  in a1  loop
             ---------------------------------初始化变量
         count1:=count1+1;
         temp_count :=0;
         temp_count1  :=0;
         temp_count2  :=0;
         temp_count3  :=0;
         temp_sum  :=0;
         temp_sum2  :=0;
         temp_sum3 :=0;
         temp_sum4 :=0;
         temp_XB_null  :=0;
         RES_XIANBIE :='';
         RES_AGENT :='';
         RES_SUM  :='';
         RES_GONGBAO  :='';
         res_ZZ  :='';
         temp_ifchannel   :=aa.IFCHANNEL;
         code1  := '';
         free1 := '';
         policy_no :=aa.certino;
         cust_no := '';

  --------循环主表，比较主表金额是否与子表金额一致
  --------子表数据是否与主表数据一致
  --------代理数据为0是否全部传送过去

    select   count(*)  into temp_count  from PRPSBUSINESSSUBFORWEB_temp1   where         CERTINO  =  aa.CERTINO;      ---查看险别表是否存在数据

    temp_count2:=0;
    if  ( AA.COINSFLAG='1' or   AA.COINSFLAG='2' )    and   aa.DATASOURCE<>'4'  then   -----1 主共   2  从工      4 ECARGO
            select count(*) into temp_count2 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO;      --------------查看共保表数据
            res:='1';
    else
            res:='0';
      end if;

     if temp_count   > 0  then                          ------险别表存在着数据
             res_ZZ:='OK';
             IF aa.certitype='P' THEN
             select sum(PREMIUM)  into  temp_sum from PRPSBUSINESSSUBFORWEB_temp1  where     CERTINO  =  aa.CERTINO;--净保费
             select sum(TAXPREMIUM)  into  temp_sum4 from PRPSBUSINESSSUBFORWEB_temp1  where     CERTINO  =  aa.CERTINO;--总保费
             END IF;
             IF aa.certitype='E' THEN
               select SUM(CHGPREMIUM)  into  temp_sum from PRPSBUSINESSSUBFORWEB_temp1  where     CERTINO  =  aa.CERTINO;
               select SUM(PREMIUM)  into  temp_sum3 from PRPSBUSINESSSUBFORWEB_temp1  where     CERTINO  =  aa.CERTINO;
               select SUM(TAXPREMIUM)  into  temp_sum4 from PRPSBUSINESSSUBFORWEB_temp1  where     CERTINO  =  aa.CERTINO;
             END IF;
             --select ACOUNTKINDCODE, isdutyfree  into   code1,free1  from PRPSBUSINESSSUBFORWEB_temp1  where CERTINO  =  aa.CERTINO;
             select count(*)  into temp_XB_null   from PRPSBUSINESSSUBFORWEB_temp1   where CERTINO  =  aa.CERTINO   and (ACOUNTKINDCODE IS  NULL   or isdutyfree IS null )   ;------险别   是否免税
             if   temp_XB_null=0    then
                   RES_XIANBIE:='OK';

             ELSE
                   RES_XIANBIE:='NO险别代码为null或isdutyfree为空';

             end if;

              if  temp_sum= aa.SUMPREMIUM  AND aa.certitype='P' AND temp_sum4=aa.TAXPREMIUM then
                  RES_SUM:='OK';
                  ELSIF  temp_sum= aa.CHGPREMIUM  AND aa.certitype='E' AND temp_sum3= aa.SUMPREMIUM AND temp_sum4=aa.TAXPREMIUM THEN  --  add 0805jiaoyanpidanbaofei
                    RES_SUM:='OK';

              ELSE
                  RES_SUM:='NO主子表金额不一致';
              END IF;

             IF     temp_ifchannel='1'    AND aa.agentcode IS NOT NULL /*and  aa.a1rate<>0*/ AND aa.AGREEMENTNO IS NOT NULL then    -- 代理编码不为空
                       RES_AGENT:='OK';
             ELSIF    temp_ifchannel='1'      AND (aa.agentcode IS  NULL /*OR  aa.a1rate=0*/ OR aa.AGREEMENTNO IS NULL)  THEN
                      RES_AGENT:='NO代理编码为空或代理协议号为空';
             ELSE
                       RES_AGENT:='OK';
             END IF;



             ----  判断车险时是否有custseq  2016/11/30
             IF  aa.CLASSCODE = '03' AND aa.custseq IS NULL THEN
               cust_no:='NO车险CUSTSEQ值为空';
             ELSE
               cust_no:='OK';
             END IF;

             if  res='1'    and temp_count2>0     then
                      temp_sum2:=0;
                      temp_sum4:=0;
                      if   AA.COINSFLAG='1' AND aa.certitype='P' AND aa.COINSPLANFLAG='1' then   ---主共代收代付保单
                              select sum(PREAMOUNT)  into  temp_sum2 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  ;
                              select sum(TAXPREMIUM)  into  temp_sum4 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  ;
                      ELSIF AA.COINSFLAG='1' AND aa.certitype='E' AND aa.COINSPLANFLAG='1'  THEN  ---主共代收代付批单
                              select SUM(preamountchg)  into  temp_sum2 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  ;
                              select sum(TAXPREMIUM)  into  temp_sum4 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  ;
                      ELSIF AA.COINSFLAG='1' AND aa.certitype='P' AND aa.COINSPLANFLAG='2'  THEN  ---主共非代收代付保单
                              select   PREAMOUNT  into  temp_sum2 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  and  COINSURERCODE='327001'  ;
                              select   TAXPREMIUM  into  temp_sum4 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  and  COINSURERCODE='327001'  ;
                      ELSIF AA.COINSFLAG='1' AND aa.certitype='E' AND aa.COINSPLANFLAG='2'  THEN  ---主共非代收代付批单
                              select   preamountchg  into  temp_sum2 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  and  COINSURERCODE='327001'  ;
                              select   TAXPREMIUM  into  temp_sum4 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO  and  COINSURERCODE='327001'  ;
                      end if;

                      if    AA.COINSFLAG='2'  THEN   --  从共

                              begin
                                    IF aa.certitype='P' then   ---从共保单

                                    select   PREAMOUNT  into  temp_sum2 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO    and COINSFLAG='0'   and  COINSURERCODE='327001'  ;
                                    select   TAXPREMIUM  into  temp_sum4 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO    and COINSFLAG='0'   and  COINSURERCODE='327001'  ;

                                    ELSIF aa.certitype='E' THEN  ---从共批单

                                    select   preamountchg  into  temp_sum2 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO    and COINSFLAG='0'   and  COINSURERCODE='327001'  ;
                                    select   TAXPREMIUM  into  temp_sum4 from PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO    and COINSFLAG='0'   and  COINSURERCODE='327001'  ;

                                    END if;
                              exception
                                     WHEN OTHERS THEN
                                      v_sql_code := SQLCODE;
                                      v_sql_msg  :=  aa.usercode||'           '||aa.certino|| ' ' /*|| dbms_utility.format_error_backtrace*/
                                                    || ' : ' || SQLERRM;
                                      --任务结束时间
                                      SELECT SYSDATE INTO v_task_end_date FROM dual;
                                      ROLLBACK;
                                      INSERT INTO LOAD_HIS_LOG1
                                        (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
                                      VALUES
                                        ('pcisv7',
                                         'PRPSBUSINESSCOINSFORWEB_temp1',
                                         v_task_start_date,
                                         v_task_end_date,
                                         to_char((v_task_end_date - v_task_start_date) * 86400),
                                         v_sql_code,
                                         v_sql_msg);
                                          RES:='NO';
                                         COMMIT;
                              end;
                         end if;

                    if   aa.SUMPREMIUM= temp_sum2 AND aa.certitype='P' AND aa.TAXPREMIUM=temp_sum4 then
                         RES_GONGBAO:='OK';
                    ELSIF aa.chgpremium= temp_sum2 AND aa.certitype='E' AND aa.TAXPREMIUM=temp_sum4 THEN
                         RES_GONGBAO:='OK';
                    ELSE
                         RES_GONGBAO:='NO主共金额不一致';
                    END IF;

            elsif   res='1'    and temp_count2=0    then    -----------------缺失共保数据
                RES_GONGBAO:='NO缺失共保数据';
            else
                RES_GONGBAO:='OK';
            END IF;
     else
          res_ZZ:='NO险别表不存在信息';
     end if;

      IF    SUBSTR(res_ZZ,0,2)='OK'  AND
            SUBSTR(RES_XIANBIE,0,2)='OK'  AND
            SUBSTR(RES_SUM,0,2)='OK'  AND
            SUBSTR(RES_AGENT,0,2)='OK'  AND
            cust_no='OK'                AND
            SUBSTR(RES_GONGBAO,0,2)='OK'     THEN

             -----------------------插入主表
                  begin
                                  res:='插入主表';
                             INSERT INTO  salesmiddle.PRPSBUSINESSFORWEB@DBLINK_NEW_SALES(
                                    CERTIID             , --              --**流水号
                                    CERTINO             , --              业务号
                                    POLICYNO            , --               保单号
                                    CERTITYPE           , --                业务类型
                                    CLASSCODE           , --                险类代码
                                    RISKCODE            , --               险种代码
                                    COMCODE             , --              二级机构代码
                                    IFCHANNEL           , --                是否渠道业务
                                    COINSFLAG           , --                联共保标志
                                    SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    STARTDATE           , --                起保日期
                                    ENDDATE             , --              终保日期
                                    INPUTDATE           , --                录入日期
                                    UNDERWRITEENDDATE   , --                        核保日期
                                    SIGNDATE            , --               签单日期
                                    DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    BUSINESSNATURE      , --                     业务来源大类
                                    BUSINESSNATURESUB   , --                        业务来源中类
                                    BUSINESSNATUREMIN   , --                        业务来源小类
                                    APPLICODE           , --                投保人代码
                                    APPLINAME           , --                投保人名称
                                    APPLIADDRESS        , --                   投保人地址
                                    INSUREDCODE         , --                  被保险人代码
                                    INSUREDNAME         , --                  被保险人名称
                                    INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    BRANCHCODE          , --                 归属业务部门
                                    TEAMCODE            , --               归属团队代码
                                    USERCODE            , --               归属业务员代码
                                    AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    UNDERWRITECODE      , --                     最终核保人代码
                                    OPERATORCODE        , --                   操作员代码(录单人)
                                    MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    BUSINESSFLAG        , --                   业务标识
                                    CURRENCY            , --               承保币种
                                    CNYEXCHRATE         , --                  承保汇率
                                    DISCOUNTRATE        , --                   总折扣率
                                    SUMAMOUNT           , --                总保险金额
                                    SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    ENDORTYPE           , --                批改类型
                                    ENDORDATE           , --                批改日期
                                    VALIDDATE           , --                生效日期(含时分秒)
                                    CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    LICENSENO           , --                车牌号码(货运险存放发票号)
                                    CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    SEATCOUNT           , --                座位数
                                    TONCOUNT            , --               吨位数
                                    EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    IFRENEWAL           , --                是否续保
                                    OLDPOLICYNO         , --                  被续保单号
                                    GENERATEDATE        , --                   保批单生成日期
                                    CARSUBNATURECODE    , --                       车辆使用性质
                                    CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    BRATE              , --             B展业费比例
                                    C1RATE             , --              C1个人基础绩效费用比例
                                    DRATE               , --            D个人附加费用比例
                                    ERATE               , --            E机构销售管理费用比例
                                    IRATE               , --            I项目拓展费用费用比例
                                    JRATE               , --            J追加费用比例
                                    ISSETTLEMENT        , --                   是否结算标记
                                    COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    CREATEDATE          , --                 创建时间
                                    BIZNO,  -- 保险卡号
                                    BIZTYPE,  -- 单证类型
                                    DATASTATUS,
                                    ITEMSTATUS,  -- 提数状态
                                    TOTALPROTOCOLTNO, -- 预约协议号
                                    ISACCOUNT,  -- 是否挂账
                                    custseq,   -- 主表 CUSTSEQ
                                    GENERATEFLAG,
                                    farmflag,
                                    policyType  ,
                                    --CHANNELTYPE,
                                    TAXPREMIUM, --含税保费或含税保费变化量
                                    TAXRATE --保单税率
                            )
                            VALUES(
                                    salesmiddle.SEQ_PRPSBUSINESSFORWEB.Nextval@DBLINK_NEW_SALES         , --              --**流水号
                                    aa.CERTINO             , --              业务号
                                    aa.POLICYNO            , --               保单号
                                    aa.CERTITYPE           , --                业务类型
                                    aa.CLASSCODE           , --                险类代码
                                    aa.RISKCODE            , --               险种代码
                                    aa.COMCODE             , --              二级机构代码
                                    aa.IFCHANNEL           , --                是否渠道业务
                                    aa.COINSFLAG           , --                联共保标志
                                    aa.SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    aa.STARTDATE           , --                起保日期
                                    aa.ENDDATE             , --              终保日期
                                    aa.INPUTDATE           , --                录入日期
                                    aa.UNDERWRITEENDDATE   , --                        核保日期
                                    aa.SIGNDATE            , --               签单日期
                                    aa.DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    aa.BUSINESSNATURE      , --                     业务来源大类
                                    aa.BUSINESSNATURESUB   , --                        业务来源中类
                                    aa.BUSINESSNATUREMIN   , --                        业务来源小类
                                    aa.APPLICODE           , --                投保人代码
                                    aa.APPLINAME           , --                投保人名称
                                    aa.APPLIADDRESS        , --                   投保人地址
                                    aa.INSUREDCODE         , --                  被保险人代码
                                    aa.INSUREDNAME         , --                  被保险人名称
                                    aa.INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    aa.BRANCHCODE          , --                 归属业务部门
                                    aa.TEAMCODE            , --               归属团队代码
                                    aa.USERCODE            , --               归属业务员代码
                                    aa.AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    aa.AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    aa.UNDERWRITECODE      , --                     最终核保人代码
                                    aa.OPERATORCODE        , --                   操作员代码(录单人)
                                    aa.MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    aa.BUSINESSFLAG        , --                   业务标识
                                    aa.CURRENCY            , --               承保币种
                                    aa.CNYEXCHRATE         , --                  承保汇率
                                    aa.DISCOUNTRATE        , --                   总折扣率
                                    aa.SUMAMOUNT           , --                总保险金额
                                    aa.SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    aa.SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    aa.ENDORTYPE           , --                批改类型
                                    aa.ENDORDATE           , --                批改日期
                                    aa.VALIDDATE           , --                生效日期(含时分秒)
                                    aa.CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    aa.CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    aa.LICENSENO           , --                车牌号码(货运险存放发票号)
                                    aa.CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    aa.SEATCOUNT           , --                座位数
                                    aa.TONCOUNT            , --               吨位数
                                    aa.EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    aa.IFRENEWAL           , --                是否续保
                                    aa.OLDPOLICYNO         , --                  被续保单号
                                    aa.GENERATEDATE        , --                   保批单生成日期
                                    aa.CARSUBNATURECODE    , --                       车辆使用性质
                                    aa.CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    aa.A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    aa.BRATE              , --             B展业费比例
                                    aa.C1RATE             , --              C1个人基础绩效费用比例
                                    aa.DRATE               , --            D个人附加费用比例
                                    aa.ERATE               , --            E机构销售管理费用比例
                                    aa.IRATE               , --            I项目拓展费用费用比例
                                    aa.JRATE               , --            J追加费用比例
                                    aa.ISSETTLEMENT        , --                   是否结算标记
                                    aa.COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    aa.CREATEDATE          , --                 创建时间
                                    aa.BIZNO,  -- 保险卡号
                                    aa.BIZTYPE,  -- 单证类型
                                    aa.datastatus,
                                    aa.itemstatus,
                                    aa.totalprotocoltno,
                                    aa.isaccount,
                                    aa.custseq,
                                    aa.GENERATEFLAG,
                                    aa.AGRIMRK,
                                    aa.ZCTYMRK ,
                                    --aa.CHANNELTYPE,
                                    aa.TAXPREMIUM, --含税保费或含税保费变化量
                                    aa.TAXRATE --保单税率
                                    );

                                    ----------------------------险别
                                     res:='插入险别';
                                       INSERT INTO salesmiddle.PRPSBUSINESSSUBFORWEB@DBLINK_NEW_SALES(
                                                    ID                 ,-- 主键
                                                    CERTINO            ,--      业务号
                                                    CERTITYPE          ,--        业务类型
                                                     POLICYNO           ,--       保单号码
                                                     CLASSCODE          ,--        险类代码
                                                     RISKCODE           ,--       险种代码
                                                      ITEMKINDNO         ,--         序号
                                                        COMCODE            ,--      归属机构代码
                                                         TEAMCODE           ,--       归属团队代码
                                                          KINDCODE           ,--       险别代码（核心）
                                                          KINDNAME           ,--       险别名称（核心）
                                                            ACOUNTKINDCODE     ,--             险别代码（收付）
                                                            ACOUNTKINDNAME     ,--             险别名称收付）
                                                                  --ACCOUNTKINDCODE    ,--              对应财务险别
                                                             STARTDATE          ,--        起保日期
                                                                    ENDDATE            ,--      终保日期
                                                            CURRENCY           ,--       承保币种
                                                           PREMIUM            ,--      折扣后保费
                                                       CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                                       CNYEXCHRATE        ,--          CNY的兑换率
                                                        -- COINSRATE          ,--        共保份额
                                                           -- COINSRATEFEE       ,--           共保金额
                                                           -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                                          AMOUNT             ,--     累计赔偿限额
                                                           --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                                         --SEATCOUNT          ,--        投保乘客座位数
                                                          -- PERSEATFEE         ,--         每座保费
                                                          GENERATEDATE       ,--           保批单生成日期
                                                            CERTIID            ,--      --**流水号
                                                            USERCODE           ,--       归属业务员工号
                                                             CREATEDATE         ,--         创建时间
                                                              UPDATEDATE         ,--         修改时间
                                                             ISDUTYfREE         ,--         此险别是否免税
                                                             TAXPREMIUM, --含税保费或含税保费变化量
                                                             TAXRATE --险别税率

                                      )
                                      select
                                        salesmiddle.seq_prpsbusinesssubforweb.Nextval@DBLINK_NEW_SALES               ,-- 主键
                                          CERTINO            ,--      业务号
                                            CERTITYPE          ,--        业务类型
                                              POLICYNO           ,--       保单号码
                                              CLASSCODE          ,--        险类代码
                                              RISKCODE           ,--       险种代码
                                              ITEMKINDNO         ,--         序号
                                              COMCODE            ,--      归属机构代码
                                              TEAMCODE           ,--       归属团队代码
                                              KINDCODE           ,--       险别代码（核心）
                                              KINDNAME           ,--       险别名称（核心）
                                              ACOUNTKINDCODE     ,--             险别代码（收付）
                                              ACOUNTKINDNAME     ,--             险别名称收付）
                                              --ACCOUNTKINDCODE    ,--              对应财务险别
                                              STARTDATE          ,--        起保日期
                                              ENDDATE            ,--      终保日期
                                              CURRENCY           ,--       承保币种
                                              PREMIUM            ,--      折扣后保费
                                              CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                              CNYEXCHRATE        ,--          CNY的兑换率
                                             -- COINSRATE          ,--        共保份额
                                             -- COINSRATEFEE       ,--           共保金额
                                             -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                              AMOUNT             ,--     累计赔偿限额
                                              --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                              --SEATCOUNT          ,--        投保乘客座位数
                                              -- PERSEATFEE         ,--         每座保费
                                              GENERATEDATE       ,--           保批单生成日期
                                              CERTIID            ,--      --**流水号
                                              USERCODE           ,--       归属业务员工号
                                              CREATEDATE         ,--         创建时间
                                              UPDATEDATE         ,--         修改时间
                                              ISDUTYfREE         ,--         此险别是否免税
                                              TAXPREMIUM, --含税保费或含税保费变化量
                                              TAXRATE --险别税率
                                              from PRPSBUSINESSSUBFORWEB_temp1   where         CERTINO  =  aa.CERTINO;

                                    --------------------------共保
                                          res:='插入共保';
                                        INSERT INTO salesmiddle.PRPSBUSINESSCOINSFORWEB@DBLINK_NEW_SALES(
                                                        ID,                --   主键
                                                        CERTINO,           --         业务号
                                                        CERTITYPE,         --           业务类型
                                                        POLICYNO,          --         保单号码
                                                        SEQNO,             --       序号
                                                        COINSURERCODE,     --               共保人代码
                                                        COINSFLAG,         --           主/从共标志
                                                        COINSRATE,         --           共保比例
                                                        COINSAMOUNT,       --             共保保额
                                                        PREAMOUNT,         --           共保保费
                                                        COINSCOMM,         --           代理经纪费(共保手续)
                                                        PLYFEE,            --       出单及相关费用
                                                        COINSAMOUNTCHG,    --               共保保额变化
                                                        PREAMOUNTCHG,      --             共保保费变化
                                                        PLYFEECHG,         --           出单费变化
                                                        CREATEDATE,        --           创建时间
                                                        UPDATEDATE,        --           修改时间
                                                        TAXPREMIUM, --   含税保费或含税保费变化量
                                                        TAXRATE --   共保税率
                                                )
                                                       select
                                                          salesmiddle.SEQ_PRPSBUSINESSCOINSFORWEB.Nextval@DBLINK_NEW_SALES ,                --   主键
                                                        CERTINO,           --         业务号
                                                        CERTITYPE,         --           业务类型
                                                        POLICYNO,          --         保单号码
                                                        SEQNO,             --       序号
                                                        COINSURERCODE,     --               共保人代码
                                                        COINSFLAG,         --           主/从共标志
                                                        COINSRATE,         --           共保比例
                                                        COINSAMOUNT,       --             共保保额
                                                        PREAMOUNT,         --           共保保费
                                                        COINSCOMM,         --           代理经纪费(共保手续)
                                                        --PLYFEE,            --       出单及相关费用
                                                        --COINSAMOUNTCHG,    --               共保保额变化
                                                        --PREAMOUNTCHG,      --             共保保费变化
                                                        --PLYFEECHG,
                                                        plyfee,
                                                        COINSAMOUNTCHG,
                                                        PREAMOUNTCHG,
                                                        PLYFEECHG,         --           出单费变化
                                                        CREATEDATE,        --           创建时间
                                                        UPDATEDATE,        --           修改时间
                                                        TAXPREMIUM, --   含税保费或含税保费变化量
                                                        TAXRATE --   共保税率
                                                     from   PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO;


                                    commit;

  v_sql_code  :=0;
  v_sql_msg   :=policy_no||';'||'NORMAL,SUCCESSFUL COMPLETION';
  --写任务日志
select sysdate into v_task_end_date from dual ;
--存过执行完毕，向日志表添加记录
insert into LOAD_HIS_LOG1
        (SYS
        ,JOBNAME --任务名称，一般为存过名
        ,START_DATE --开始时间
        ,END_DATE --结束时间
        ,RUN_DATE --总计运行时间(秒)
        ,SQL_CODE
        ,SQL_STATE --状态
        )
        VALUES
        ('pcisv7'
        ,'add_sales_end_intoxg'
        ,v_task_start_date
        ,v_task_end_date
        ,to_char((v_task_end_date-v_task_start_date)*86400)
        ,v_sql_code
        ,v_sql_msg
        );
     commit;

EXCEPTION
WHEN OTHERS THEN

v_sql_code := SQLCODE;
v_sql_msg  := policy_no||';'||SQLERRM; --记录错误原因
/*v_sql_msg  :=  v_sql_msg||';'policy_no||';'||aa.usercode||';'|| res||';' ||aa.certino|| '; '
              || ' : ' || SQLERRM;*/
--任务结束时间

SELECT SYSDATE INTO v_task_end_date FROM dual;
ROLLBACK;
INSERT INTO LOAD_HIS_LOG1
  (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
VALUES
  ('pcisv7',
   'add_sales_end_intoxg',
   v_task_start_date,
   v_task_end_date,
   to_char((v_task_end_date - v_task_start_date) * 86400),
   v_sql_code,
   v_sql_msg);
    RES:='NO';
   COMMIT;

              END;
              ------------------------插入子表
    /*              BEGIN
                         if       res='OK'    THEN

                              INSERT INTO salesmiddle.PRPSBUSINESSSUBFORWEB@DBLINK_NEW_SALES(
                                                    ID                 ,-- 主键
                                                    CERTINO            ,--      业务号
                                                    CERTITYPE          ,--        业务类型
                                                     POLICYNO           ,--       保单号码
                                                     CLASSCODE          ,--        险类代码
                                                     RISKCODE           ,--       险种代码
                                                      ITEMKINDNO         ,--         序号
                                                        COMCODE            ,--      归属机构代码
                                                         TEAMCODE           ,--       归属团队代码
                                                          KINDCODE           ,--       险别代码（核心）
                                                          KINDNAME           ,--       险别名称（核心）
                                                            ACOUNTKINDCODE     ,--             险别代码（收付）
                                                            ACOUNTKINDNAME     ,--             险别名称收付）
                                                                  --ACCOUNTKINDCODE    ,--              对应财务险别
                                                             STARTDATE          ,--        起保日期
                                                                    ENDDATE            ,--      终保日期
                                                            CURRENCY           ,--       承保币种
                                                           PREMIUM            ,--      折扣后保费
                                                       --CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                                       CNYEXCHRATE        ,--          CNY的兑换率
                                                        -- COINSRATE          ,--        共保份额
                                                           -- COINSRATEFEE       ,--           共保金额
                                                           -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                                          AMOUNT             ,--     累计赔偿限额
                                                           --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                                         --SEATCOUNT          ,--        投保乘客座位数
                                                          -- PERSEATFEE         ,--         每座保费
                                                          GENERATEDATE       ,--           保批单生成日期
                                                            CERTIID            ,--      --**流水号
                                                            USERCODE           ,--       归属业务员工号
                                                             CREATEDATE         ,--         创建时间
                                                              UPDATEDATE         ,--         修改时间
                                                             ISDUTYfREE         --         此险别是否免税

                                      )
                                      select
                                        salesmiddle.seq_prpsbusinesssubforweb.Nextval@DBLINK_NEW_SALES               ,-- 主键
                                          CERTINO            ,--      业务号
                                            CERTITYPE          ,--        业务类型
                                              POLICYNO           ,--       保单号码
                                              CLASSCODE          ,--        险类代码
                                              RISKCODE           ,--       险种代码
                                              ITEMKINDNO         ,--         序号
                                              COMCODE            ,--      归属机构代码
                                              TEAMCODE           ,--       归属团队代码
                                              KINDCODE           ,--       险别代码（核心）
                                              KINDNAME           ,--       险别名称（核心）
                                              ACOUNTKINDCODE     ,--             险别代码（收付）
                                              ACOUNTKINDNAME     ,--             险别名称收付）
                                              --ACCOUNTKINDCODE    ,--              对应财务险别
                                              STARTDATE          ,--        起保日期
                                              ENDDATE            ,--      终保日期
                                              CURRENCY           ,--       承保币种
                                              PREMIUM            ,--      折扣后保费
                                              --CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                              CNYEXCHRATE        ,--          CNY的兑换率
                                             -- COINSRATE          ,--        共保份额
                                             -- COINSRATEFEE       ,--           共保金额
                                             -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                              AMOUNT             ,--     累计赔偿限额
                                              --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                              --SEATCOUNT          ,--        投保乘客座位数
                                              -- PERSEATFEE         ,--         每座保费
                                              GENERATEDATE       ,--           保批单生成日期
                                              CERTIID            ,--      --**流水号
                                              USERCODE           ,--       归属业务员工号
                                              CREATEDATE         ,--         创建时间
                                              UPDATEDATE         ,--         修改时间
                                              ISDUTYfREE         --         此险别是否免税
                                              from PRPSBUSINESSSUBFORWEB_temp1   where         CERTINO  =  aa.CERTINO;
                                              RES:='OK';
                          END IF;
                  EXCEPTION
                  WHEN OTHERS THEN
                    v_sql_code := SQLCODE;
                    v_sql_msg  := aa.CERTINO|| '       插入子表报错' /*|| dbms_utility.format_error_backtrace
                                  || ' : ' || SQLERRM;
                    --任务结束时间
                    SELECT SYSDATE INTO v_task_end_date FROM dual;
                    ROLLBACK;

                    INSERT INTO LOAD_HIS_LOG2
                      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
                    VALUES
                      ('pcisv7',
                       'PRPSBUSINESSSUBFORWEB_temp1',
                       v_task_start_date,
                       v_task_end_date,
                       to_char((v_task_end_date - v_task_start_date) * 86400),
                       v_sql_code,
                       v_sql_msg);
                          COMMIT;
                        RES:='NO';
                  END;
             -------------------------插入共保
                  begin
                 IF   SUBSTR(RES,0,2)='OK' THEN

                        INSERT INTO salesmiddle.PRPSBUSINESSCOINSFORWEB@DBLINK_NEW_SALES(
                                                        ID,                --   主键
                                                        CERTINO,           --         业务号
                                                        CERTITYPE,         --           业务类型
                                                        POLICYNO,          --         保单号码
                                                        SEQNO,             --       序号
                                                        COINSURERCODE,     --               共保人代码
                                                        COINSFLAG,         --           主/从共标志
                                                        COINSRATE,         --           共保比例
                                                        COINSAMOUNT,       --             共保保额
                                                        PREAMOUNT,         --           共保保费
                                                        COINSCOMM,         --           代理经纪费(共保手续)
                                                        PLYFEE,            --       出单及相关费用
                                                        COINSAMOUNTCHG,    --               共保保额变化
                                                        PREAMOUNTCHG,      --             共保保费变化
                                                        PLYFEECHG,         --           出单费变化
                                                        CREATEDATE,        --           创建时间
                                                        UPDATEDATE        --           修改时间
                                                )
                                                       select
                                                          salesmiddle.SEQ_PRPSBUSINESSCOINSFORWEB.Nextval@DBLINK_NEW_SALES ,                --   主键
                                                        CERTINO,           --         业务号
                                                        CERTITYPE,         --           业务类型
                                                        POLICYNO,          --         保单号码
                                                        SEQNO,             --       序号
                                                        COINSURERCODE,     --               共保人代码
                                                        COINSFLAG,         --           主/从共标志
                                                        COINSRATE,         --           共保比例
                                                        COINSAMOUNT,       --             共保保额
                                                        PREAMOUNT,         --           共保保费
                                                        COINSCOMM,         --           代理经纪费(共保手续)
                                                        --PLYFEE,            --       出单及相关费用
                                                        --COINSAMOUNTCHG,    --               共保保额变化
                                                        --PREAMOUNTCHG,      --             共保保费变化
                                                        --PLYFEECHG,
                                                        plyfee,
                                                        COINSAMOUNTCHG,
                                                        PREAMOUNTCHG,
                                                        PLYFEECHG,         --           出单费变化
                                                        CREATEDATE,        --           创建时间
                                                        UPDATEDATE        --           修改时间
                                                     from   PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO;

                     RES:='OK';
                 END IF;
             EXCEPTION
                  WHEN OTHERS THEN
                    v_sql_code := SQLCODE;
                    v_sql_msg  := aa.certino || ' 插入共保信息出错' /*|| dbms_utility.format_error_backtrace
                                  || ' : ' || SQLERRM;
                    --任务结束时间
                    SELECT SYSDATE INTO v_task_end_date FROM dual;
                    ROLLBACK;

                    INSERT INTO LOAD_HIS_LOG2
                      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
                    VALUES
                      ('pcisv7',
                       'PRPSBUSINESSCOINSFORWEB_temp1',
                       v_task_start_date,
                       v_task_end_date,
                       to_char((v_task_end_date - v_task_start_date) * 86400),
                       v_sql_code,
                       v_sql_msg);
                        RES:='NO';
                  commit;
            end;
            IF  SUBSTR(RES,0,2)='OK' THEN           ---------------------保持数据的一致性，当三个表的插入语句都正确执行时，提交。
                                 COMMIT;
            END IF;
           */
     END IF;

   --      SUBSTR(res_ZZ,0,2)='OK'  AND   SUBSTR(RES_XIANBIE,0,2)='OK'  AND  SUBSTR(RES_SUM,0,2)='OK'  AND SUBSTR(RES_AGENT,0,2)='OK'  AND SUBSTR(RES_GONGBAO,0,2)='OK'
      IF   SUBSTR(res_ZZ,0,2)='NO'   THEN    ------------主表存在子表不存信息
              v_sql_code  :=0;
              v_sql_msg   :=policy_no||';'||'error:主表存在子表不存信息';
                --写任务日志
              select sysdate into v_task_end_date from dual ;
              --存过执行完毕，向日志表添加记录
              insert into LOAD_HIS_LOG1
                      (SYS
                      ,JOBNAME --任务名称，一般为存过名
                      ,START_DATE --开始时间
                      ,END_DATE --结束时间
                      ,RUN_DATE --总计运行时间(秒)
                      ,SQL_CODE
                      ,SQL_STATE --状态
                      )
                      VALUES
                      ('pcisv7'
                      ,'add_sales_end_intoxg'
                      ,v_task_start_date
                      ,v_task_end_date
                      ,to_char((v_task_end_date-v_task_start_date)*86400)
                      ,v_sql_code
                      ,v_sql_msg
                      );
                   commit;
              INSERT INTO  PRPSBUSINESSFORWEB_mistake2(
                                    CERTIID             , --              --**流水号
                                    CERTINO             , --              业务号
                                    POLICYNO            , --               保单号
                                    CERTITYPE           , --                业务类型
                                    CLASSCODE           , --                险类代码
                                    RISKCODE            , --               险种代码
                                    COMCODE             , --              二级机构代码
                                    IFCHANNEL           , --                是否渠道业务
                                    COINSFLAG           , --                联共保标志
                                    SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    STARTDATE           , --                起保日期
                                    ENDDATE             , --              终保日期
                                    INPUTDATE           , --                录入日期
                                    UNDERWRITEENDDATE   , --                        核保日期
                                    SIGNDATE            , --               签单日期
                                    DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    BUSINESSNATURE      , --                     业务来源大类
                                    BUSINESSNATURESUB   , --                        业务来源中类
                                    BUSINESSNATUREMIN   , --                        业务来源小类
                                    APPLICODE           , --                投保人代码
                                    APPLINAME           , --                投保人名称
                                    APPLIADDRESS        , --                   投保人地址
                                    INSUREDCODE         , --                  被保险人代码
                                    INSUREDNAME         , --                  被保险人名称
                                    INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    BRANCHCODE          , --                 归属业务部门
                                    TEAMCODE            , --               归属团队代码
                                    USERCODE            , --               归属业务员代码
                                    AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    UNDERWRITECODE      , --                     最终核保人代码
                                    OPERATORCODE        , --                   操作员代码(录单人)
                                    MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    BUSINESSFLAG        , --                   业务标识
                                    CURRENCY            , --               承保币种
                                    CNYEXCHRATE         , --                  承保汇率
                                    DISCOUNTRATE        , --                   总折扣率
                                    SUMAMOUNT           , --                总保险金额
                                    SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    ENDORTYPE           , --                批改类型
                                    ENDORDATE           , --                批改日期
                                    VALIDDATE           , --                生效日期(含时分秒)
                                    CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    LICENSENO           , --                车牌号码(货运险存放发票号)
                                    CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    SEATCOUNT           , --                座位数
                                    TONCOUNT            , --               吨位数
                                    EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    IFRENEWAL           , --                是否续保
                                    OLDPOLICYNO         , --                  被续保单号
                                    GENERATEDATE        , --                   保批单生成日期
                                    CARSUBNATURECODE    , --                       车辆使用性质
                                    CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    BRATE              , --             B展业费比例
                                    C1RATE             , --              C1个人基础绩效费用比例
                                    DRATE               , --            D个人附加费用比例
                                    ERATE               , --            E机构销售管理费用比例
                                    IRATE               , --            I项目拓展费用费用比例
                                    JRATE               , --            J追加费用比例
                                    ISSETTLEMENT        , --                   是否结算标记
                                    COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    CREATEDATE          , --                 创建时间
                                    BIZNO,  -- 保险卡号
                                    BIZTYPE,  -- 单证类型
                                    DATASTATUS,
                                    ITEMSTATUS,  -- 提数状态
                                    TOTALPROTOCOLTNO, -- 预约协议号
                                    ISACCOUNT,  -- 是否挂账
                                    custseq,
                                    GENERATEFLAG
                            )
                            VALUES(
                                    salesmiddle.SEQ_PRPSBUSINESSFORWEB.Nextval@DBLINK_NEW_SALES         , --              --**流水号
                                    aa.CERTINO             , --              业务号
                                    aa.POLICYNO            , --               保单号
                                    aa.CERTITYPE           , --                业务类型
                                    aa.CLASSCODE           , --                险类代码
                                    aa.RISKCODE            , --               险种代码
                                    aa.COMCODE             , --              二级机构代码
                                    aa.IFCHANNEL           , --                是否渠道业务
                                    aa.COINSFLAG           , --                联共保标志
                                    aa.SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    aa.STARTDATE           , --                起保日期
                                    aa.ENDDATE             , --              终保日期
                                    aa.INPUTDATE           , --                录入日期
                                    aa.UNDERWRITEENDDATE   , --                        核保日期
                                    aa.SIGNDATE            , --               签单日期
                                    aa.DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    aa.BUSINESSNATURE      , --                     业务来源大类
                                    aa.BUSINESSNATURESUB   , --                        业务来源中类
                                    aa.BUSINESSNATUREMIN   , --                        业务来源小类
                                    aa.APPLICODE           , --                投保人代码
                                    aa.APPLINAME           , --                投保人名称
                                    aa.APPLIADDRESS        , --                   投保人地址
                                    aa.INSUREDCODE         , --                  被保险人代码
                                    aa.INSUREDNAME         , --                  被保险人名称
                                    aa.INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    aa.BRANCHCODE          , --                 归属业务部门
                                    aa.TEAMCODE            , --               归属团队代码
                                    aa.USERCODE            , --               归属业务员代码
                                    aa.AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    aa.AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    aa.UNDERWRITECODE      , --                     最终核保人代码
                                    aa.OPERATORCODE        , --                   操作员代码(录单人)
                                    aa.MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    aa.BUSINESSFLAG        , --                   业务标识
                                    aa.CURRENCY            , --               承保币种
                                    aa.CNYEXCHRATE         , --                  承保汇率
                                    aa.DISCOUNTRATE        , --                   总折扣率
                                    aa.SUMAMOUNT           , --                总保险金额
                                    aa.SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    aa.SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    aa.ENDORTYPE           , --                批改类型
                                    aa.ENDORDATE           , --                批改日期
                                    aa.VALIDDATE           , --                生效日期(含时分秒)
                                    aa.CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    aa.CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    aa.LICENSENO           , --                车牌号码(货运险存放发票号)
                                    aa.CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    aa.SEATCOUNT           , --                座位数
                                    aa.TONCOUNT            , --               吨位数
                                    aa.EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    aa.IFRENEWAL           , --                是否续保
                                    aa.OLDPOLICYNO         , --                  被续保单号
                                    aa.GENERATEDATE        , --                   保批单生成日期
                                    aa.CARSUBNATURECODE    , --                       车辆使用性质
                                    aa.CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    aa.A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    aa.BRATE              , --             B展业费比例
                                    aa.C1RATE             , --              C1个人基础绩效费用比例
                                    aa.DRATE               , --            D个人附加费用比例
                                    aa.ERATE               , --            E机构销售管理费用比例
                                    aa.IRATE               , --            I项目拓展费用费用比例
                                    aa.JRATE               , --            J追加费用比例
                                    aa.ISSETTLEMENT        , --                   是否结算标记
                                    aa.COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    aa.CREATEDATE          , --                 创建时间
                                    aa.BIZNO,  -- 保险卡号
                                    aa.BIZTYPE,  -- 单证类型
                                    aa.datastatus,
                                    aa.itemstatus,
                                    aa.totalprotocoltno,
                                    aa.isaccount,
                                    aa.custseq,
                                    aa.GENERATEFLAG
                                    );
                ---主表数据
              --  commit;
      ELSIF     SUBSTR(RES_XIANBIE,0,2)='NO'  OR  SUBSTR(RES_SUM,0,2)='NO'  OR SUBSTR(RES_AGENT,0,2)='NO' OR  substr(cust_no,0,2)='NO'   THEN   -------主子表险别或税额有为空，主子表金额不一致，代理业务代理人为空或比例为0
              v_sql_code  :=0;
              v_sql_msg   :=policy_no||';'||'error:主子表险别或税额有为空，主子表金额不一致，代理业务代理人为空或比例为0或代理协议号为空，车险CUSTSEQ为空';
                --写任务日志
              select sysdate into v_task_end_date from dual ;
              --存过执行完毕，向日志表添加记录
              insert into LOAD_HIS_LOG1
                      (SYS
                      ,JOBNAME --任务名称，一般为存过名
                      ,START_DATE --开始时间
                      ,END_DATE --结束时间
                      ,RUN_DATE --总计运行时间(秒)
                      ,SQL_CODE
                      ,SQL_STATE --状态
                      )
                      VALUES
                      ('pcisv7'
                      ,'add_sales_end_intoxg'
                      ,v_task_start_date
                      ,v_task_end_date
                      ,to_char((v_task_end_date-v_task_start_date)*86400)
                      ,v_sql_code
                      ,v_sql_msg
                      );
                   commit;

             ----主表数据
              TEMP_COUNT:=0;
             select  count(*)  INTO  TEMP_COUNT  FROM   PRPSBUSINESSFORWEB_mistake2   WHERE  CERTINO  =  aa.CERTINO;
          --  IF    TEMP_COUNT = 0  THEN
            IF  TEMP_COUNT=0  THEN
              INSERT INTO  PRPSBUSINESSFORWEB_mistake2(
                                    CERTIID             , --              --**流水号
                                    CERTINO             , --              业务号
                                    POLICYNO            , --               保单号
                                    CERTITYPE           , --                业务类型
                                    CLASSCODE           , --                险类代码
                                    RISKCODE            , --               险种代码
                                    COMCODE             , --              二级机构代码
                                    IFCHANNEL           , --                是否渠道业务
                                    COINSFLAG           , --                联共保标志
                                    SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    STARTDATE           , --                起保日期
                                    ENDDATE             , --              终保日期
                                    INPUTDATE           , --                录入日期
                                    UNDERWRITEENDDATE   , --                        核保日期
                                    SIGNDATE            , --               签单日期
                                    DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    BUSINESSNATURE      , --                     业务来源大类
                                    BUSINESSNATURESUB   , --                        业务来源中类
                                    BUSINESSNATUREMIN   , --                        业务来源小类
                                    APPLICODE           , --                投保人代码
                                    APPLINAME           , --                投保人名称
                                    APPLIADDRESS        , --                   投保人地址
                                    INSUREDCODE         , --                  被保险人代码
                                    INSUREDNAME         , --                  被保险人名称
                                    INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    BRANCHCODE          , --                 归属业务部门
                                    TEAMCODE            , --               归属团队代码
                                    USERCODE            , --               归属业务员代码
                                    AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    UNDERWRITECODE      , --                     最终核保人代码
                                    OPERATORCODE        , --                   操作员代码(录单人)
                                    MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    BUSINESSFLAG        , --                   业务标识
                                    CURRENCY            , --               承保币种
                                    CNYEXCHRATE         , --                  承保汇率
                                    DISCOUNTRATE        , --                   总折扣率
                                    SUMAMOUNT           , --                总保险金额
                                    SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    ENDORTYPE           , --                批改类型
                                    ENDORDATE           , --                批改日期
                                    VALIDDATE           , --                生效日期(含时分秒)
                                    CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    LICENSENO           , --                车牌号码(货运险存放发票号)
                                    CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    SEATCOUNT           , --                座位数
                                    TONCOUNT            , --               吨位数
                                    EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    IFRENEWAL           , --                是否续保
                                    OLDPOLICYNO         , --                  被续保单号
                                    GENERATEDATE        , --                   保批单生成日期
                                    CARSUBNATURECODE    , --                       车辆使用性质
                                    CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    BRATE              , --             B展业费比例
                                    C1RATE             , --              C1个人基础绩效费用比例
                                    DRATE               , --            D个人附加费用比例
                                    ERATE               , --            E机构销售管理费用比例
                                    IRATE               , --            I项目拓展费用费用比例
                                    JRATE               , --            J追加费用比例
                                    ISSETTLEMENT        , --                   是否结算标记
                                    COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    CREATEDATE          , --                 创建时间
                                    BIZNO,  -- 保险卡号
                                    BIZTYPE,  -- 单证类型
                                    DATASTATUS,
                                    ITEMSTATUS,  -- 提数状态
                                    TOTALPROTOCOLTNO, -- 预约协议号
                                    ISACCOUNT,  -- 是否挂账
                                    custseq,
                                    GENERATEFLAG
                            )
                            VALUES(
                                    salesmiddle.SEQ_PRPSBUSINESSFORWEB.Nextval@DBLINK_NEW_SALES         , --              --**流水号
                                    aa.CERTINO             , --              业务号
                                    aa.POLICYNO            , --               保单号
                                    aa.CERTITYPE           , --                业务类型
                                    aa.CLASSCODE           , --                险类代码
                                    aa.RISKCODE            , --               险种代码
                                    aa.COMCODE             , --              二级机构代码
                                    aa.IFCHANNEL           , --                是否渠道业务
                                    aa.COINSFLAG           , --                联共保标志
                                    aa.SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    aa.STARTDATE           , --                起保日期
                                    aa.ENDDATE             , --              终保日期
                                    aa.INPUTDATE           , --                录入日期
                                    aa.UNDERWRITEENDDATE   , --                        核保日期
                                    aa.SIGNDATE            , --               签单日期
                                    aa.DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    aa.BUSINESSNATURE      , --                     业务来源大类
                                    aa.BUSINESSNATURESUB   , --                        业务来源中类
                                    aa.BUSINESSNATUREMIN   , --                        业务来源小类
                                    aa.APPLICODE           , --                投保人代码
                                    aa.APPLINAME           , --                投保人名称
                                    aa.APPLIADDRESS        , --                   投保人地址
                                    aa.INSUREDCODE         , --                  被保险人代码
                                    aa.INSUREDNAME         , --                  被保险人名称
                                    aa.INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    aa.BRANCHCODE          , --                 归属业务部门
                                    aa.TEAMCODE            , --               归属团队代码
                                    aa.USERCODE            , --               归属业务员代码
                                    aa.AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    aa.AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    aa.UNDERWRITECODE      , --                     最终核保人代码
                                    aa.OPERATORCODE        , --                   操作员代码(录单人)
                                    aa.MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    aa.BUSINESSFLAG        , --                   业务标识
                                    aa.CURRENCY            , --               承保币种
                                    aa.CNYEXCHRATE         , --                  承保汇率
                                    aa.DISCOUNTRATE        , --                   总折扣率
                                    aa.SUMAMOUNT           , --                总保险金额
                                    aa.SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    aa.SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    aa.ENDORTYPE           , --                批改类型
                                    aa.ENDORDATE           , --                批改日期
                                    aa.VALIDDATE           , --                生效日期(含时分秒)
                                    aa.CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    aa.CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    aa.LICENSENO           , --                车牌号码(货运险存放发票号)
                                    aa.CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    aa.SEATCOUNT           , --                座位数
                                    aa.TONCOUNT            , --               吨位数
                                    aa.EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    aa.IFRENEWAL           , --                是否续保
                                    aa.OLDPOLICYNO         , --                  被续保单号
                                    aa.GENERATEDATE        , --                   保批单生成日期
                                    aa.CARSUBNATURECODE    , --                       车辆使用性质
                                    aa.CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    aa.A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    aa.BRATE              , --             B展业费比例
                                    aa.C1RATE             , --              C1个人基础绩效费用比例
                                    aa.DRATE               , --            D个人附加费用比例
                                    aa.ERATE               , --            E机构销售管理费用比例
                                    aa.IRATE               , --            I项目拓展费用费用比例
                                    aa.JRATE               , --            J追加费用比例
                                    aa.ISSETTLEMENT        , --                   是否结算标记
                                    aa.COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    aa.CREATEDATE          , --                 创建时间
                                    aa.BIZNO,  -- 保险卡号
                                    aa.BIZTYPE,  -- 单证类型
                                    aa.datastatus,
                                    aa.itemstatus,
                                    aa.totalprotocoltno,
                                    aa.isaccount,
                                    aa.custseq,
                                    aa.GENERATEFLAG
                                    );
          END IF;
             ----险别表数据
            TEMP_COUNT:=0;
            SELECT  COUNT(*)   INTO TEMP_COUNT   FROM   PRPSBUSINESSSUBFORWEB_mistake2  WHERE  CERTINO  =  aa.CERTINO;
            IF TEMP_COUNT=0  THEN
              INSERT INTO PRPSBUSINESSSUBFORWEB_mistake2(
                                                    ID                 ,-- 主键
                                                    CERTINO            ,--      业务号
                                                    CERTITYPE          ,--        业务类型
                                                     POLICYNO           ,--       保单号码
                                                     CLASSCODE          ,--        险类代码
                                                     RISKCODE           ,--       险种代码
                                                      ITEMKINDNO         ,--         序号
                                                        COMCODE            ,--      归属机构代码
                                                         TEAMCODE           ,--       归属团队代码
                                                          KINDCODE           ,--       险别代码（核心）
                                                          KINDNAME           ,--       险别名称（核心）
                                                            ACOUNTKINDCODE     ,--             险别代码（收付）
                                                            ACOUNTKINDNAME     ,--             险别名称收付）
                                                                  --ACCOUNTKINDCODE    ,--              对应财务险别
                                                             STARTDATE          ,--        起保日期
                                                                    ENDDATE            ,--      终保日期
                                                            CURRENCY           ,--       承保币种
                                                           PREMIUM            ,--      折扣后保费
                                                       --CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                                       CNYEXCHRATE        ,--          CNY的兑换率
                                                        -- COINSRATE          ,--        共保份额
                                                           -- COINSRATEFEE       ,--           共保金额
                                                           -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                                          AMOUNT             ,--     累计赔偿限额
                                                           --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                                         --SEATCOUNT          ,--        投保乘客座位数
                                                          -- PERSEATFEE         ,--         每座保费
                                                          GENERATEDATE       ,--           保批单生成日期
                                                            CERTIID            ,--      --**流水号
                                                            USERCODE           ,--       归属业务员工号
                                                             CREATEDATE         ,--         创建时间
                                                              UPDATEDATE         ,--         修改时间
                                                             ISDUTYfREE         --         此险别是否免税

                                      )
                                      select
                                        salesmiddle.seq_prpsbusinesssubforweb.Nextval@DBLINK_NEW_SALES               ,-- 主键
                                          CERTINO            ,--      业务号
                                            CERTITYPE          ,--        业务类型
                                              POLICYNO           ,--       保单号码
                                              CLASSCODE          ,--        险类代码
                                              RISKCODE           ,--       险种代码
                                              ITEMKINDNO         ,--         序号
                                              COMCODE            ,--      归属机构代码
                                              TEAMCODE           ,--       归属团队代码
                                              KINDCODE           ,--       险别代码（核心）
                                              KINDNAME           ,--       险别名称（核心）
                                              ACOUNTKINDCODE     ,--             险别代码（收付）
                                              ACOUNTKINDNAME     ,--             险别名称收付）
                                              --ACCOUNTKINDCODE    ,--              对应财务险别
                                              STARTDATE          ,--        起保日期
                                              ENDDATE            ,--      终保日期
                                              CURRENCY           ,--       承保币种
                                              PREMIUM            ,--      折扣后保费
                                              --CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                              CNYEXCHRATE        ,--          CNY的兑换率
                                             -- COINSRATE          ,--        共保份额
                                             -- COINSRATEFEE       ,--           共保金额
                                             -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                              AMOUNT             ,--     累计赔偿限额
                                              --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                              --SEATCOUNT          ,--        投保乘客座位数
                                              -- PERSEATFEE         ,--         每座保费
                                              GENERATEDATE       ,--           保批单生成日期
                                              CERTIID            ,--      --**流水号
                                              USERCODE           ,--       归属业务员工号
                                              CREATEDATE         ,--         创建时间
                                              UPDATEDATE         ,--         修改时间
                                              ISDUTYfREE         --         此险别是否免税
                                              from PRPSBUSINESSSUBFORWEB_temp1   where         CERTINO  =  aa.CERTINO;
            END IF;

       ELSIF    SUBSTR(RES_GONGBAO,0,2)='NO'  THEN     --------------共保信息出错
              v_sql_code  :=0;
              v_sql_msg   :=policy_no||';'||'error:共保信息出错';
                --写任务日志
              select sysdate into v_task_end_date from dual ;
              --存过执行完毕，向日志表添加记录
              insert into LOAD_HIS_LOG1
                      (SYS
                      ,JOBNAME --任务名称，一般为存过名
                      ,START_DATE --开始时间
                      ,END_DATE --结束时间
                      ,RUN_DATE --总计运行时间(秒)
                      ,SQL_CODE
                      ,SQL_STATE --状态
                      )
                      VALUES
                      ('pcisv7'
                      ,'add_sales_end_intoxg'
                      ,v_task_start_date
                      ,v_task_end_date
                      ,to_char((v_task_end_date-v_task_start_date)*86400)
                      ,v_sql_code
                      ,v_sql_msg
                      );
                   commit;

              --主表
              TEMP_COUNT:=0;
                select  count(*)  INTO  TEMP_COUNT  FROM   PRPSBUSINESSFORWEB_mistake2   WHERE  CERTINO  =  aa.CERTINO;
            IF    TEMP_COUNT = 0  THEN
              INSERT INTO  PRPSBUSINESSFORWEB_mistake2(
                                    CERTIID             , --              --**流水号
                                    CERTINO             , --              业务号
                                    POLICYNO            , --               保单号
                                    CERTITYPE           , --                业务类型
                                    CLASSCODE           , --                险类代码
                                    RISKCODE            , --               险种代码
                                    COMCODE             , --              二级机构代码
                                    IFCHANNEL           , --                是否渠道业务
                                    COINSFLAG           , --                联共保标志
                                    SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    STARTDATE           , --                起保日期
                                    ENDDATE             , --              终保日期
                                    INPUTDATE           , --                录入日期
                                    UNDERWRITEENDDATE   , --                        核保日期
                                    SIGNDATE            , --               签单日期
                                    DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    BUSINESSNATURE      , --                     业务来源大类
                                    BUSINESSNATURESUB   , --                        业务来源中类
                                    BUSINESSNATUREMIN   , --                        业务来源小类
                                    APPLICODE           , --                投保人代码
                                    APPLINAME           , --                投保人名称
                                    APPLIADDRESS        , --                   投保人地址
                                    INSUREDCODE         , --                  被保险人代码
                                    INSUREDNAME         , --                  被保险人名称
                                    INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    BRANCHCODE          , --                 归属业务部门
                                    TEAMCODE            , --               归属团队代码
                                    USERCODE            , --               归属业务员代码
                                    AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    UNDERWRITECODE      , --                     最终核保人代码
                                    OPERATORCODE        , --                   操作员代码(录单人)
                                    MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    BUSINESSFLAG        , --                   业务标识
                                    CURRENCY            , --               承保币种
                                    CNYEXCHRATE         , --                  承保汇率
                                    DISCOUNTRATE        , --                   总折扣率
                                    SUMAMOUNT           , --                总保险金额
                                    SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    ENDORTYPE           , --                批改类型
                                    ENDORDATE           , --                批改日期
                                    VALIDDATE           , --                生效日期(含时分秒)
                                    CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    LICENSENO           , --                车牌号码(货运险存放发票号)
                                    CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    SEATCOUNT           , --                座位数
                                    TONCOUNT            , --               吨位数
                                    EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    IFRENEWAL           , --                是否续保
                                    OLDPOLICYNO         , --                  被续保单号
                                    GENERATEDATE        , --                   保批单生成日期
                                    CARSUBNATURECODE    , --                       车辆使用性质
                                    CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    BRATE              , --             B展业费比例
                                    C1RATE             , --              C1个人基础绩效费用比例
                                    DRATE               , --            D个人附加费用比例
                                    ERATE               , --            E机构销售管理费用比例
                                    IRATE               , --            I项目拓展费用费用比例
                                    JRATE               , --            J追加费用比例
                                    ISSETTLEMENT        , --                   是否结算标记
                                    COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    CREATEDATE          , --                 创建时间
                                    BIZNO,  -- 保险卡号
                                    BIZTYPE,  -- 单证类型
                                    DATASTATUS,
                                    ITEMSTATUS,  -- 提数状态
                                    TOTALPROTOCOLTNO, -- 预约协议号
                                    ISACCOUNT,  -- 是否挂账
                                    custseq,
                                    GENERATEFLAG
                            )
                            VALUES(
                                    salesmiddle.SEQ_PRPSBUSINESSFORWEB.Nextval@DBLINK_NEW_SALES         , --              --**流水号
                                    aa.CERTINO             , --              业务号
                                    aa.POLICYNO            , --               保单号
                                    aa.CERTITYPE           , --                业务类型
                                    aa.CLASSCODE           , --                险类代码
                                    aa.RISKCODE            , --               险种代码
                                    aa.COMCODE             , --              二级机构代码
                                    aa.IFCHANNEL           , --                是否渠道业务
                                    aa.COINSFLAG           , --                联共保标志
                                    aa.SHAREHOLDERFLAG     , --                      是否股东业务标识
                                    aa.STARTDATE           , --                起保日期
                                    aa.ENDDATE             , --              终保日期
                                    aa.INPUTDATE           , --                录入日期
                                    aa.UNDERWRITEENDDATE   , --                        核保日期
                                    aa.SIGNDATE            , --               签单日期
                                    aa.DATASOURCE          , --                 --**数据来源 --**1车险系统 --**2非车险系统 --**3 E-CARGO系统
                                    aa.BUSINESSNATURE      , --                     业务来源大类
                                    aa.BUSINESSNATURESUB   , --                        业务来源中类
                                    aa.BUSINESSNATUREMIN   , --                        业务来源小类
                                    aa.APPLICODE           , --                投保人代码
                                    aa.APPLINAME           , --                投保人名称
                                    aa.APPLIADDRESS        , --                   投保人地址
                                    aa.INSUREDCODE         , --                  被保险人代码
                                    aa.INSUREDNAME         , --                  被保险人名称
                                    aa.INSUREDADDRESS      , --                     被保险人地址
                                    --HANDLERCODE         , --                  经办人代码
                                    aa.BRANCHCODE          , --                 归属业务部门
                                    aa.TEAMCODE            , --               归属团队代码
                                    aa.USERCODE            , --               归属业务员代码
                                    aa.AGENTCODE           , --                归属代理人
                                    --AGENTUSERCODE       , --                    归属代理业务员
                                    aa.AGREEMENTNO         , --                  代理人协议号
                                    --APPROVERCODE        , --                   复核人代码
                                    aa.UNDERWRITECODE      , --                     最终核保人代码
                                    aa.OPERATORCODE        , --                   操作员代码(录单人)
                                    aa.MAKECOM             , --              录单人员归属机构
                                    --REINSFLAG           , --                商业分保标志
                                    aa.BUSINESSFLAG        , --                   业务标识
                                    aa.CURRENCY            , --               承保币种
                                    aa.CNYEXCHRATE         , --                  承保汇率
                                    aa.DISCOUNTRATE        , --                   总折扣率
                                    aa.SUMAMOUNT           , --                总保险金额
                                    aa.SUMDISCOUNT         , --                  总折扣金额(折扣减掉的保额)
                                    aa.SUMPREMIUM          , --                 总保险费(折扣后总保费)
                                    aa.ENDORTYPE           , --                批改类型
                                    aa.ENDORDATE           , --                批改日期
                                    aa.VALIDDATE           , --                生效日期(含时分秒)
                                    aa.CHGAMOUNT           , --                批改保额变化值(批增或批减的值)
                                    aa.CHGPREMIUM          , --                 批改保险费变化值(批增或批减的值)
                                    aa.LICENSENO           , --                车牌号码(货运险存放发票号)
                                    aa.CARKINDCODE         , --                  车辆使用类型(车险保单必填)
                                    --USEYEARS            , --               使用年限
                                    --COUNTRYNATURE       , --                    国别性质
                                    aa.SEATCOUNT           , --                座位数
                                    aa.TONCOUNT            , --               吨位数
                                    aa.EXHAUSTSCALE        , --                   排量
                                    --MODELCODE           , --                厂牌车型
                                    aa.IFRENEWAL           , --                是否续保
                                    aa.OLDPOLICYNO         , --                  被续保单号
                                    aa.GENERATEDATE        , --                   保批单生成日期
                                    aa.CARSUBNATURECODE    , --                       车辆使用性质
                                    aa.CAFFIRMCDE          , --                 保单-投保确认码,批单-批改确认码
                                    --ILOGDISRATE         , --                  ILOG手续费比例
                                    --PLATDISRATE         , --                  平台手续费比例
                                    aa.A1RATE              , --             A1手续费/佣金比例        字段会有改变0616
                                    aa.BRATE              , --             B展业费比例
                                    aa.C1RATE             , --              C1个人基础绩效费用比例
                                    aa.DRATE               , --            D个人附加费用比例
                                    aa.ERATE               , --            E机构销售管理费用比例
                                    aa.IRATE               , --            I项目拓展费用费用比例
                                    aa.JRATE               , --            J追加费用比例
                                    aa.ISSETTLEMENT        , --                   是否结算标记
                                    aa.COINSPLANFLAG       , --                    共保业务缴费方式
                                   -- BUSINESSDEPARTMENT  , --                         业务服务部门
                                    aa.CREATEDATE          , --                 创建时间
                                    aa.BIZNO,  -- 保险卡号
                                    aa.BIZTYPE,  -- 单证类型
                                    aa.datastatus,
                                    aa.itemstatus,
                                    aa.totalprotocoltno,
                                    aa.isaccount,
                                    aa.custseq,
                                    aa.GENERATEFLAG
                                    );
            END IF;
              --险别子表
                TEMP_COUNT:=0;
            SELECT  COUNT(*)   INTO TEMP_COUNT   FROM   PRPSBUSINESSSUBFORWEB_mistake2  WHERE  CERTINO  =  aa.CERTINO;
            IF TEMP_COUNT=0  THEN

              INSERT INTO PRPSBUSINESSSUBFORWEB_mistake2(
                                                    ID                 ,-- 主键
                                                    CERTINO            ,--      业务号
                                                    CERTITYPE          ,--        业务类型
                                                     POLICYNO           ,--       保单号码
                                                     CLASSCODE          ,--        险类代码
                                                     RISKCODE           ,--       险种代码
                                                      ITEMKINDNO         ,--         序号
                                                        COMCODE            ,--      归属机构代码
                                                         TEAMCODE           ,--       归属团队代码
                                                          KINDCODE           ,--       险别代码（核心）
                                                          KINDNAME           ,--       险别名称（核心）
                                                            ACOUNTKINDCODE     ,--             险别代码（收付）
                                                            ACOUNTKINDNAME     ,--             险别名称收付）
                                                                  --ACCOUNTKINDCODE    ,--              对应财务险别
                                                             STARTDATE          ,--        起保日期
                                                                    ENDDATE            ,--      终保日期
                                                            CURRENCY           ,--       承保币种
                                                           PREMIUM            ,--      折扣后保费
                                                       --CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                                       CNYEXCHRATE        ,--          CNY的兑换率
                                                        -- COINSRATE          ,--        共保份额
                                                           -- COINSRATEFEE       ,--           共保金额
                                                           -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                                          AMOUNT             ,--     累计赔偿限额
                                                           --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                                         --SEATCOUNT          ,--        投保乘客座位数
                                                          -- PERSEATFEE         ,--         每座保费
                                                          GENERATEDATE       ,--           保批单生成日期
                                                            CERTIID            ,--      --**流水号
                                                            USERCODE           ,--       归属业务员工号
                                                             CREATEDATE         ,--         创建时间
                                                              UPDATEDATE         ,--         修改时间
                                                             ISDUTYfREE         --         此险别是否免税

                                      )
                                      select
                                        salesmiddle.seq_prpsbusinesssubforweb.Nextval@DBLINK_NEW_SALES               ,-- 主键
                                          CERTINO            ,--      业务号
                                            CERTITYPE          ,--        业务类型
                                              POLICYNO           ,--       保单号码
                                              CLASSCODE          ,--        险类代码
                                              RISKCODE           ,--       险种代码
                                              ITEMKINDNO         ,--         序号
                                              COMCODE            ,--      归属机构代码
                                              TEAMCODE           ,--       归属团队代码
                                              KINDCODE           ,--       险别代码（核心）
                                              KINDNAME           ,--       险别名称（核心）
                                              ACOUNTKINDCODE     ,--             险别代码（收付）
                                              ACOUNTKINDNAME     ,--             险别名称收付）
                                              --ACCOUNTKINDCODE    ,--              对应财务险别
                                              STARTDATE          ,--        起保日期
                                              ENDDATE            ,--      终保日期
                                              CURRENCY           ,--       承保币种
                                              PREMIUM            ,--      折扣后保费
                                              --CHGPREMIUM         ,--         批改保险费变化值(批增或批减的值)
                                              CNYEXCHRATE        ,--          CNY的兑换率
                                             -- COINSRATE          ,--        共保份额
                                             -- COINSRATEFEE       ,--           共保金额
                                             -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
                                              AMOUNT             ,--     累计赔偿限额
                                              --PERACCLIMITFEE     ,--             每次事故赔偿限额
                                              --SEATCOUNT          ,--        投保乘客座位数
                                              -- PERSEATFEE         ,--         每座保费
                                              GENERATEDATE       ,--           保批单生成日期
                                              CERTIID            ,--      --**流水号
                                              USERCODE           ,--       归属业务员工号
                                              CREATEDATE         ,--         创建时间
                                              UPDATEDATE         ,--         修改时间
                                              ISDUTYfREE         --         此险别是否免税
                                              from PRPSBUSINESSSUBFORWEB_temp1   where         CERTINO  =  aa.CERTINO;
            END IF;
            -----共保表
            TEMP_COUNT:=0;
              SELECT  COUNT(*)   INTO TEMP_COUNT   FROM   PRPSBUSINESSCOINSFORWEB_mk2  WHERE  CERTINO  =  aa.CERTINO;
            IF TEMP_COUNT=0  THEN
              INSERT INTO PRPSBUSINESSCOINSFORWEB_mk2(
                                                        ID,                --   主键
                                                        CERTINO,           --         业务号
                                                        CERTITYPE,         --           业务类型
                                                        POLICYNO,          --         保单号码
                                                        SEQNO,             --       序号
                                                        COINSURERCODE,     --               共保人代码
                                                        COINSFLAG,         --           主/从共标志
                                                        COINSRATE,         --           共保比例
                                                        COINSAMOUNT,       --             共保保额
                                                        PREAMOUNT,         --           共保保费
                                                        COINSCOMM,         --           代理经纪费(共保手续)
                                                        PLYFEE,            --       出单及相关费用
                                                        COINSAMOUNTCHG,    --               共保保额变化
                                                        PREAMOUNTCHG,      --             共保保费变化
                                                        PLYFEECHG,         --           出单费变化
                                                        CREATEDATE,        --           创建时间
                                                        UPDATEDATE        --           修改时间
                                                )
                                                       select
                                                          salesmiddle.SEQ_PRPSBUSINESSCOINSFORWEB.Nextval@DBLINK_NEW_SALES ,                --   主键
                                                        CERTINO,           --         业务号
                                                        CERTITYPE,         --           业务类型
                                                        POLICYNO,          --         保单号码
                                                        SEQNO,             --       序号
                                                        COINSURERCODE,     --               共保人代码
                                                        COINSFLAG,         --           主/从共标志
                                                        COINSRATE,         --           共保比例
                                                        COINSAMOUNT,       --             共保保额
                                                        PREAMOUNT,         --           共保保费
                                                        COINSCOMM,         --           代理经纪费(共保手续)
                                                        --PLYFEE,            --       出单及相关费用
                                                        --COINSAMOUNTCHG,    --               共保保额变化
                                                        --PREAMOUNTCHG,      --             共保保费变化
                                                        --PLYFEECHG,
                                                        plyfee,
                                                        COINSAMOUNTCHG,
                                                        PREAMOUNTCHG,
                                                        PLYFEECHG,         --           出单费变化
                                                        CREATEDATE,        --           创建时间
                                                        UPDATEDATE        --           修改时间
                                                     from   PRPSBUSINESSCOINSFORWEB_temp1  where     CERTINO  =  aa.CERTINO;
              END IF;
            --commit;
       END IF;

        commit;
  end loop;



      -- commit;
  EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  :=   ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG1
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'PRPSBUSINESSSUBFORWEB_temp',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);


end   ;
/
