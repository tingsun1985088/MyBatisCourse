CREATE PROCEDURE CONVERSION_RATE_MERGE(M_SETNO IN VARCHAR2 -- 结算单号
                                            ) IS
  V_ORGFEEAMT     NUMBER; --转换后结算单主表的结算余额
  V_ORGAMTRATE    NUMBER; --转换后汇率
  V_ORGFEECUR     VARCHAR2(4000) := ''; --转换后币种
  V_ATTRIBAAMOUNT NUMBER; --境内结算余额
  V_ATTRIBBAMOUNT NUMBER; --境外结算余额
  V_CHAE          NUMBER; --差额
  V_COUNT         NUMBER; --取境内or境外是否有值
  V_CONVERSIONAMT NUMBER; --更正保费
  V_FEETYPCDE     VARCHAR2(10) := ''; --类型
  V_CONVERSIONID  VARCHAR2(50) := ''; --内账id

  /*根据结算单号获取境内再保人的各项金额*/
  CURSOR AmountOfDomesticReinsure IS
    select BILL.C_FEETYP_CDE as C_FEETYP_CDE,
           sum(bill.n_conversion_amt) as n_conversion_amt,
           sum(bill.n_conversion_vat_tax) as n_conversion_vat_tax,
           sum(bill.n_conversion_ad_tax) as n_conversion_ad_tax
      from web_ri_conversion_rate bill
     where bill.c_sett_no = M_SETNO
       and bill.c_ri_com in (select coms.c_com_cde
                               from web_ri_com coms
                              where coms.c_attrib = 'A')
       and (bill.n_conversion_amt <> 0 or bill.n_conversion_vat_tax <> 0 or
           bill.n_conversion_ad_tax <> 0)
     GROUP BY BILL.C_FEETYP_CDE;

  /*根据结算单号获取境外再保人的各项金额*/
  CURSOR AmountOfOverseasReinsure IS
    select BILL.C_FEETYP_CDE as C_FEETYP_CDE,
           sum(bill.n_conversion_amt) as n_conversion_amt,
           sum(bill.n_conversion_vat_tax) as n_conversion_vat_tax,
           sum(bill.n_conversion_ad_tax) as n_conversion_ad_tax
      from web_ri_conversion_rate bill
     where bill.c_sett_no = M_SETNO
       and bill.c_ri_com in (select coms.c_com_cde
                               from web_ri_com coms
                              where coms.c_attrib = 'B')
       and (bill.n_conversion_amt <> 0 or bill.n_conversion_vat_tax <> 0 or
           bill.n_conversion_ad_tax <> 0)
     GROUP BY BILL.C_FEETYP_CDE;

  /*1 首先,需要从web_ri_sett_main表中获取该结算单的转换后的币种与汇率和结算余额
    2 根据结算单号从内账表中查询出所有数据,insert到web_ri_conversion_rate表中,并将取出来的C_ORG_FEE_CUR(), N_ORG_FEE_AMT(), N_FEE_AMT_RATE()
    3 计算insert到web_ri_conversion_rate表中的数据,根据转换后的汇率这个字段乘对应的保费,增值税,附加税分别更新到
                                                         N_CONVERSION_AMT(转换后保费)/N_CONVERSION_VAT_TAX(转换后增值税)/N_CONVERSION_AD_TAX(转换后附加税)三个字段中
    4 根据境内境外的算法算出来他的结算余额,然后用结算单主表的结算余额-内账表的结算余额 = 尾差  将尾差随便放到一个单子上  让内账表的结算金额与结算单主表的结算金额一致  全剧终end...
  */

BEGIN

  /*上来先查询数据中是否有该结算单号的账单都删掉*/
  delete web_ri_conversion_rate where c_sett_no = M_SETNO;

  /*根据结算单号查询出转换后的币种,结算金额以及汇率*/
  select C_ORG_FEE_CUR, N_ORG_FEE_AMT, N_FEE_AMT_RATE
    into V_ORGFEECUR, V_ORGFEEAMT, V_ORGAMTRATE
    from web_ri_sett_main a
   where a.c_sett_no = M_SETNO;

  /*将内账数据添加到折币种表*/
  insert into web_ri_conversion_rate
    (C_SHARE_BILL_PK_ID,
     C_BILL_TYP,
     C_STATUS,
     C_BILLPRD_TYPE,
     C_BILL_PRD,
     C_BILL_YEAR,
     C_BILL_MONTH,
     C_PROD_NO,
     C_DPT_CDE,
     C_RI_COM,
     C_BRKR_MRK,
     C_RI_BRKR,
     C_CONT_CDE,
     C_CONT_ID,
     C_FEE_CUR,
     C_FEETYP_CDE,
     N_FEE_AMT,
     C_UW_YEAR,
     C_UW_MONTH,
     N_LAYER,
     N_TMS,
     C_PLY_NO,
     N_EDR_CLM_TMS,
     C_DOC_NO,
     N_SPLIT_SEQ,
     C_SETT_NO,
     C_INNER_BILL_NO,
     C_YOUR_DOC_NO,
     T_YOUR_TM,
     N_SHARE_PRPT,
     C_INSRNT_NME,
     T_INSRNC_BGN_TM,
     T_INSRNC_END_TM,
     T_ACCDNT_TM,
     C_ACCDNT_CAUS_CDE,
     C_PLACE_LOSS,
     C_UPD_CDE,
     T_CRT_TM,
     T_UPD_TM,
     C_CRT_CDE,
     C_ORI_CUR,
     N_BILL_CHG_RATE,
     C_BILL_NO,
     T_BILL_TM,
     C_CONFIRM_CDE,
     C_TO_FIN_MRK,
     T_TO_FIN_TM,
     C_TO_FIN_CDE,
     C_SEPE_MRK,
     C_DOC_FLAG,
     C_OFFSET_MRK,
     C_OUTBILL_MRK,
     C_EVENT_ID,
     N_BILL_ELSE_AMT,
     C_CED_TYP,
     C_BSNS_TYP,
     N_RBK_SEQ,
     C_CVRG_NO,
     N_INWD_TOL_FEE_AMT,
     C_PRE_MRK,
     C_RIKIND_NO,
     C_PROTOCOL_MRK,
     C_OFFSET_NO,
     N_EDR_PRJ_NO,
     T_PAY_BGN_TM,
     T_PAY_END_TM,
     C_EDR_NO,
     C_CLM_NO,
     N_CLM_TMS,
     C_DOC_TYP,
     C_TRANS_MRK,
     T_TRANS_TM,
     C_PAY_YM,
     C_APP_NO,
     C_ORG_FEE_CUR,
     N_ORG_FEE_AMT,
     N_FEE_AMT_RATE,
     C_CED_MRK,
     C_SI_MRK,
     C_WATER_MARK,
     C_DOCUMENT_TYPE,
     C_DOCUMENT_CDE,
     N_VAT_TAX,
     N_VAT_TAX_RATE,
     N_ADDITIONAL_TAX,
     N_ADDITIONAL_TAX_RATE,
     C_VAT_MRK,
     C_INVOICE_DPT_ID,
     C_INVOICE_DPT_CDE,
     RULES,
     N_RMB_FEE_AMT,
     N_RMB_VAT_TAX,
     N_RMB_ADDITIONAL_TAX,
     N_FEE_AMT_ORIGIN,
     C_TAX_MRK,
     RE_MARK,
     N_CHG_FEE1,
     N_CHG_FEE2,
     C_AGRI_MRK,
     C_ZCTY_MRK,
     N_CONVERSION_CUR,
     N_CONVERSION_RATE,
     N_CONVERSION_AMT,
     N_CONVERSION_VAT_TAX,
     N_CONVERSION_AD_TAX)
    select C_SHARE_BILL_PK_ID,
           C_BILL_TYP,
           C_STATUS,
           C_BILLPRD_TYPE,
           C_BILL_PRD,
           C_BILL_YEAR,
           C_BILL_MONTH,
           C_PROD_NO,
           C_DPT_CDE,
           C_RI_COM,
           C_BRKR_MRK,
           C_RI_BRKR,
           C_CONT_CDE,
           C_CONT_ID,
           C_FEE_CUR,
           C_FEETYP_CDE,
           N_FEE_AMT,
           C_UW_YEAR,
           C_UW_MONTH,
           N_LAYER,
           N_TMS,
           C_PLY_NO,
           N_EDR_CLM_TMS,
           C_DOC_NO,
           N_SPLIT_SEQ,
           C_SETT_NO,
           C_INNER_BILL_NO,
           C_YOUR_DOC_NO,
           T_YOUR_TM,
           N_SHARE_PRPT,
           C_INSRNT_NME,
           T_INSRNC_BGN_TM,
           T_INSRNC_END_TM,
           T_ACCDNT_TM,
           C_ACCDNT_CAUS_CDE,
           C_PLACE_LOSS,
           C_UPD_CDE,
           T_CRT_TM,
           T_UPD_TM,
           C_CRT_CDE,
           C_ORI_CUR,
           N_BILL_CHG_RATE,
           C_BILL_NO,
           T_BILL_TM,
           C_CONFIRM_CDE,
           C_TO_FIN_MRK,
           T_TO_FIN_TM,
           C_TO_FIN_CDE,
           C_SEPE_MRK,
           C_DOC_FLAG,
           C_OFFSET_MRK,
           C_OUTBILL_MRK,
           C_EVENT_ID,
           N_BILL_ELSE_AMT,
           C_CED_TYP,
           C_BSNS_TYP,
           N_RBK_SEQ,
           C_CVRG_NO,
           N_INWD_TOL_FEE_AMT,
           C_PRE_MRK,
           C_RIKIND_NO,
           C_PROTOCOL_MRK,
           C_OFFSET_NO,
           N_EDR_PRJ_NO,
           T_PAY_BGN_TM,
           T_PAY_END_TM,
           C_EDR_NO,
           C_CLM_NO,
           N_CLM_TMS,
           C_DOC_TYP,
           C_TRANS_MRK,
           T_TRANS_TM,
           C_PAY_YM,
           C_APP_NO,
           C_ORG_FEE_CUR,
           N_ORG_FEE_AMT,
           N_FEE_AMT_RATE,
           C_CED_MRK,
           C_SI_MRK,
           C_WATER_MARK,
           C_DOCUMENT_TYPE,
           C_DOCUMENT_CDE,
           N_VAT_TAX,
           N_VAT_TAX_RATE,
           N_ADDITIONAL_TAX,
           N_ADDITIONAL_TAX_RATE,
           C_VAT_MRK,
           C_INVOICE_DPT_ID,
           C_INVOICE_DPT_CDE,
           RULES,
           N_RMB_FEE_AMT,
           N_RMB_VAT_TAX,
           N_RMB_ADDITIONAL_TAX,
           N_FEE_AMT_ORIGIN,
           C_TAX_MRK,
           RE_MARK,
           N_CHG_FEE1,
           N_CHG_FEE2,
           C_AGRI_MRK,
           C_ZCTY_MRK,
           V_ORGFEECUR,
           V_ORGAMTRATE,
           0,
           0,
           0
      from web_ri_share_bill bill
     where bill.c_sett_no = M_SETNO;

  commit;

  /*根据set到这个表中的数据update他折算后的钱到N_CONVERSION_AMT 转换后保费,
                                               N_CONVERSION_VAT_TAX 转换后增值税,
                                               N_CONVERSION_AD_TAX 转换后附加税*/
  update web_ri_conversion_rate b
     set b.n_conversion_amt     = round(nvl(b.n_fee_amt, 0) *
                                        b.n_conversion_rate,
                                        2),
         b.n_conversion_vat_tax = round(nvl(b.n_vat_tax, 0) *
                                        b.n_conversion_rate,
                                        2),
         b.n_conversion_ad_tax  = round(nvl(b.n_additional_tax, 0) *
                                        b.n_conversion_rate,
                                        2)
   where b.c_sett_no = M_SETNO;

  commit;

  /*根据境内境外各自算出转换后的币种的结算金额*/
  --1 我需要创建一个游标 把境内的数据求出来
  --2 在创建一个游标 把境外的数据求出来
  --3 根据公式 算出境内和境外各自对应的结算金额

  --1 境内
  V_ATTRIBAAMOUNT := 0;
  FOR AttribA IN AmountOfDomesticReinsure LOOP
    BEGIN

      IF AttribA.c_Feetyp_Cde = 'C1' THEN
        V_ATTRIBAAMOUNT := V_ATTRIBAAMOUNT + AttribA.n_Conversion_Amt;
      ELSE
        V_ATTRIBAAMOUNT := V_ATTRIBAAMOUNT - AttribA.n_Conversion_Amt;
      END IF;
    END;
  END LOOP;

  --2 境外
  V_ATTRIBBAMOUNT := 0;
  FOR AttribB IN AmountOfOverseasReinsure LOOP
    BEGIN

      IF AttribB.c_Feetyp_Cde = 'C1' THEN
        V_ATTRIBBAMOUNT := V_ATTRIBBAMOUNT + AttribB.n_Conversion_Amt -
                           AttribB.n_Conversion_Vat_Tax -
                           AttribB.n_Conversion_Ad_Tax;
      ELSE
        V_ATTRIBBAMOUNT := V_ATTRIBBAMOUNT - AttribB.n_Conversion_Amt;
      END IF;
    END;
  END LOOP;

  /*用结算单主表转换后的结算余额 - 境内的结算余额 - 境外的结算余额*/
  V_CHAE := V_ORGFEEAMT - V_ATTRIBAAMOUNT - V_ATTRIBBAMOUNT;

  /* 判断内账类型,如果是C1分保费,那么就随便取一条C1的分保费 - 差额,如果类型不是C1,那么就随便取一条数据 + 差额 */
  /* 并且还要判断境内和境外是否有数据,如果境内没有数据,就从境外入手,如果境外没有数据,那么就从境内入手 */

  --1 判断境外结算余额是否有值,如果境外有值,那么说明账单表中有境外的数据
  IF V_ATTRIBBAMOUNT <> 0 THEN
    select count(1), c_share_bill_pk_id, c_feetyp_cde, n_conversion_amt
      into V_COUNT, V_CONVERSIONID, V_FEETYPCDE, V_CONVERSIONAMT
      from (select a.c_share_bill_pk_id as c_share_bill_pk_id,
                   a.c_feetyp_cde as c_feetyp_cde,
                   nvl(a.n_conversion_amt, 0) as n_conversion_amt
              from web_ri_conversion_rate a
             where a.c_sett_no = M_SETNO
               and a.c_feetyp_cde = 'C1'
               and a.c_ri_com in (select coms.c_com_cde
                                    from web_ri_com coms
                                   where coms.c_attrib = 'B')
               and (a.n_conversion_amt <> 0 or a.n_conversion_vat_tax <> 0 or
                   a.n_conversion_ad_tax <> 0)
             group by a.c_share_bill_pk_id,
                      a.c_feetyp_cde,
                      a.n_conversion_amt
             order by a.n_conversion_amt desc) b
     where rownum = 1
     group by c_share_bill_pk_id, c_feetyp_cde, n_conversion_amt;

    /*判断账单类型是否是C1,如果是,那么就用C1的金额+差额数据,UPDATE*/
    IF V_FEETYPCDE = 'C1' THEN
      V_CONVERSIONAMT := V_CONVERSIONAMT + V_CHAE;
      --将差额数据更新到转换币种表毛保费字段
      UPDATE web_ri_conversion_rate a
         set a.n_conversion_amt = V_CONVERSIONAMT, a.t_upd_tm = sysdate
       where a.c_share_bill_pk_id = V_CONVERSIONID;

      commit;

      --反之如果类型不是C1,那么就用毛保费字段-差额,UPDATE
    ELSE
      V_CONVERSIONAMT := V_CONVERSIONAMT - V_CHAE;

      UPDATE web_ri_conversion_rate a
         set a.n_conversion_amt = V_CONVERSIONAMT, a.t_upd_tm = sysdate
       where a.c_share_bill_pk_id = V_CONVERSIONID;

      commit;

    END IF;

  ELSE
    --否则数据就是境内的了呢
    select count(1), c_share_bill_pk_id, c_feetyp_cde, n_conversion_amt
      into V_COUNT, V_CONVERSIONID, V_FEETYPCDE, V_CONVERSIONAMT
      from (select a.c_share_bill_pk_id as c_share_bill_pk_id,
                   a.c_feetyp_cde as c_feetyp_cde,
                   nvl(a.n_conversion_amt, 0) as n_conversion_amt
              from web_ri_conversion_rate a
             where a.c_sett_no = M_SETNO
               and a.c_feetyp_cde = 'C1'
               and a.c_ri_com in (select coms.c_com_cde
                                    from web_ri_com coms
                                   where coms.c_attrib = 'A')
               and (a.n_conversion_amt <> 0 or a.n_conversion_vat_tax <> 0 or
                   a.n_conversion_ad_tax <> 0)
             group by a.c_share_bill_pk_id,
                      a.c_feetyp_cde,
                      a.n_conversion_amt
             order by a.n_conversion_amt desc) b
     where rownum = 1
     group by c_share_bill_pk_id, c_feetyp_cde, n_conversion_amt;

    /*判断账单类型是否是C1,如果是,那么就用C1的金额+差额数据,UPDATE*/
    IF V_FEETYPCDE = 'C1' THEN
      V_CONVERSIONAMT := V_CONVERSIONAMT + V_CHAE;
      --将差额数据更新到转换币种表毛保费字段
      UPDATE web_ri_conversion_rate a
         set a.n_conversion_amt = V_CONVERSIONAMT, a.t_upd_tm = sysdate
       where a.c_share_bill_pk_id = V_CONVERSIONID;

      COMMIT;

    ELSE
      --反之如果类型不是C1,那么就用毛保费字段-差额,UPDATE
      V_CONVERSIONAMT := V_CONVERSIONAMT - V_CHAE;

      UPDATE web_ri_conversion_rate a
         set a.n_conversion_amt = V_CONVERSIONAMT, a.t_upd_tm = sysdate
       where a.c_share_bill_pk_id = V_CONVERSIONID;

      COMMIT;

    END IF;
  END IF;

END;
/
