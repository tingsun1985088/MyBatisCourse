CREATE function       BATCHRUNEX(instrArray  in STRING_ARRAY,
                                      subdeptcode in varchar,
                                      monthx      in varchar,
                                      frequency   in varchar,
                                      tablename   in varchar)
  return STRING_ARRAY is

  valuex     varchar2(1000);
  formulax   varchar2(10000);
  outstrList STRING_ARRAY := STRING_ARRAY(1);


  onestr       varchar2(1);
  oneitem      varchar2(8);
  itemcodes    STRING_ARRAY := STRING_ARRAY(0);
  itemoprs     STRING_ARRAY := STRING_ARRAY(0);
  itemcodecount number(10,0);
  opercount    number(10,0);
  tempvalue    number(38,20);
  checkvalue   number(38,20);

  itemcode   varchar2(50);
  itemvalue  varchar2(50);
  itemcount  number(10,0);

  type itemArray is table of t_original_data%ROWTYPE INDEX BY BINARY_INTEGER;
  v_itemArray itemArray;

  v_CurID integer;
  v_SelectStmt varchar2(500);
  v_Dummy integer;

  errorLevel varchar2(100);

begin

  /*????????*/
  v_CurID := Dbms_Sql.open_cursor;
  v_SelectStmt :='     select /*+ RULE */ t.c_item_cde,t.c_value ' ||
                 '             from ' || tablename  ||  ' t ' ||
                 '      where t.c_sub_dept_cde = :subdeptcode and t.c_month = :monthx and ' ||
                 '            t.c_frequency = :frequency';

  Dbms_Sql.parse(v_CurID,v_SelectStmt,Dbms_Sql.native);
  Dbms_Sql.bind_variable(v_CurID,':subdeptcode',subdeptcode);
  Dbms_Sql.bind_variable(v_CurID,':monthx',monthx);
  Dbms_Sql.bind_variable(v_CurID,':frequency',frequency);

  Dbms_Sql.define_column(v_CurID,1,itemcode,50);
  Dbms_Sql.define_column(v_CurID,2,itemvalue,50);

  v_Dummy := Dbms_Sql.execute(v_CurID);

  itemcount := 0;
  loop
    if dbms_sql.fetch_rows(v_CurID) = 0 then
       exit;
    end if;
    dbms_sql.column_value(v_CurID,1,itemcode);
    dbms_sql.column_value(v_CurID,2,itemvalue);
    itemcount := itemcount +1 ;
    if trim(itemvalue)='' then
       itemvalue := '0';
    end if;
    v_itemArray(itemcode).c_item_cde := itemcode;
    v_itemArray(itemcode).c_value := trim( chr(13) from trim(chr(10) from itemvalue));
    -- ltrim(ltrim( trim(itemvalue),chr(10)),chr(13));
  end loop;
  dbms_sql.close_cursor(v_CurID);

  /*????????*/
  outstrList.extend(instrArray.last - 1);
  for i in 1 .. instrArray.last loop
    /*????*/
    formulax := instrArray(i);

    begin
      /*????*/
      checkvalue := 0;
      itemcodecount := 0;
      opercount := 0;
      for j in 1..length(formulax) loop
          onestr := substr(formulax,j,1);
          if onestr>='0' and onestr<='9' then
             oneitem := oneitem || onestr;
            if  j = length(formulax) then
            begin
                itemcodecount := itemcodecount + 1;
                itemcodes.extend(1);
                itemcodes(itemcodecount) :=  oneitem;
                oneitem := '';
            end;
            end if ;
          else
            /*????*/
            itemcodecount := itemcodecount + 1;
            itemcodes.extend(1);
            itemcodes(itemcodecount) :=  oneitem;
            oneitem := '';
            /*???*/
            opercount := opercount + 1;
            itemoprs.extend(1);
            itemoprs(opercount) :=  onestr;
          end if;
      end loop;

      <<getvalue>>
      for i in 1..itemcodecount loop
          /*?????,???????????0*/
          begin
            tempvalue := to_number(v_itemArray(to_number(itemcodes(i))).c_value);
            errorLevel := '0';
          exception
            WHEN OTHERS THEN
            if (sqlcode=100) then
              tempvalue := 0;
              errorLevel := '0';
            else
               valuex := '???????????????' ||
                         ' ?????' || subdeptcode ||
                         ' ???' || itemcodes(i) ||
                         ' ??' || v_itemArray(to_number(itemcodes(i))).c_value ||
                         sqlerrm;
               errorLevel := '1';
               exit getvalue;
            end if;
          end;

          /*????????*/
          if i = 1 then
             checkvalue := tempvalue;
          else
            if itemoprs(i-1) = '+' then
                checkvalue := checkvalue + tempvalue;
            end if;
            if itemoprs(i-1)  = '-' then
                checkvalue := checkvalue - tempvalue;
            end if;
          end if;
      end loop getvalue;

      itemcodes.delete;
      itemoprs.delete;
      itemcodecount := 0;
      opercount := 0;
      if errorLevel = '0' then
         valuex := to_char(checkvalue);
      --else
         --"???????????????"
      end if;
      errorLevel := 0;

    exception
      WHEN OTHERS THEN
      valuex := '????????????????????????';
    END;

    /*???*/
    outstrList(i) := valuex;
  end loop;


  return outstrList;

end BATCHRUNEX;

/
