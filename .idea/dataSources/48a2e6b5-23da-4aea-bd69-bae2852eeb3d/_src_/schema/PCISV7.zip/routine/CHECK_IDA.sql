CREATE PROCEDURE "CHECK_IDA" (
 num in web_ply_base.empno%type,---定义一个传入参数

) as
cursor c_id is select * from web_ply_base where c_ply_no=num;
 d web_ply_base%rowtype;---创建一个能放emp表中的所有字段的%rowtype
begin
   open c_id;
   loop
      fetch c_id into d;
      name:=d.ename;
      exit when c_id%notfound;
      dbms_output.put_line(name);
   end loop;
  close c_id;
 end;







/
