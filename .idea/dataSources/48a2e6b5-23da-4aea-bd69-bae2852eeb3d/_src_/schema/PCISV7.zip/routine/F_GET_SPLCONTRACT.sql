CREATE FUNCTION "F_GET_SPLCONTRACT" (V_APLNO varchar2)
return varchar2 is

V_SPLCONTRACT             varchar2(8000);

begin

  select a.splcontent into V_SPLCONTRACT from T_SPLCONTRACT_PRE a where a.aplno=V_APLNO;

return V_SPLCONTRACT;

exception
when others then
return null;

end F_GET_SPLCONTRACT;









/
