CREATE procedure add_prpdcompany_all(startdate in date,enddate in date) is

   v_task_start_date date;
   v_task_end_date   date;
   v_sql_code        number;
   v_sql_msg         varchar2(4000) := ''; --sql错误信息
   i                 number;
   temp              number;
   
   cursor prpdcompany_s is
   select d.c_dpt_cde,d.c_dpt_cnm,d.c_dpt_enm,d.c_dpt_caddr,d.c_dpt_eaddr,d.c_zip_cde,d.c_tel,d.c_fax,d.c_snr_dpt,d.c_dpt_rel_cde,d.c_dpt_cls,d.n_dpt_levl,
       d.c_is_valid,d.c_acct_dpt_mrk,d.c_company_cde,d.c_crt_cde,d.t_crt_tm,d.c_upd_cde,d.t_upd_tm
       from WEB_ORG_DPT d 
       where c_snr_dpt is not null and d.t_upd_tm between startdate and enddate;
   
begin
  i    :=0;
  for d in prpdcompany_s loop
    begin
      select count(*) into temp from salesmiddle.prpdcompany@DBLINK_NEW_SALES where  COMCODE=d.c_dpt_cde; 
      if temp=0 then
         INSERT INTO  salesmiddle.prpdcompany@DBLINK_NEW_SALES(
          COMCODE,
          COMCNAME,
          COMENAME,
          ADDRESSCNAME,
          ADDRESSENAME,
          POSTCODE,
          PHONENUMBER,
          FAXNUMBER,
          UPPERCOMCODE,
          COMATTRIBUTE,
          COMTYPE,
          COMLEVEL,
          VALIDSTATUS,
          ACNTUNIT,
          ACCCODE,
          CREATORCODE,
          CREATEDATE,
          UPDATERCODE,
          UPDATEDATE

        )
        values
        (d.c_dpt_cde,d.c_dpt_cnm,d.c_dpt_enm,d.c_dpt_caddr,d.c_dpt_eaddr,d.c_zip_cde,d.c_tel,d.c_fax,d.c_snr_dpt,d.c_dpt_rel_cde,d.c_dpt_cls,d.n_dpt_levl,
             d.c_is_valid,d.c_acct_dpt_mrk,d.c_company_cde,d.c_crt_cde,d.t_crt_tm,d.c_upd_cde,d.t_upd_tm);
      else
        update salesmiddle.prpdcompany@DBLINK_NEW_SALES  set  
          COMCNAME=d.c_dpt_cnm,
          COMENAME=d.c_dpt_enm,
          ADDRESSCNAME=d.c_dpt_caddr,
          ADDRESSENAME=d.c_dpt_eaddr,
          POSTCODE=d.c_zip_cde,
          PHONENUMBER=d.c_tel,
          FAXNUMBER=d.c_fax,
          UPPERCOMCODE=d.c_snr_dpt,
          COMATTRIBUTE=d.c_dpt_rel_cde,
          COMTYPE=d.c_dpt_cls,
          COMLEVEL=d.n_dpt_levl,
          VALIDSTATUS=d.c_is_valid,
          ACNTUNIT=d.c_acct_dpt_mrk,
          ACCCODE=d.c_company_cde,
          CREATORCODE=d.c_crt_cde,
          CREATEDATE=d.t_crt_tm,
          UPDATERCODE=d.c_upd_cde,
          UPDATEDATE=d.t_upd_tm     
          where  COMCODE=d.c_dpt_cde;
          
      end if;
      i  :=i+1;
      SELECT SYSDATE INTO v_task_end_date FROM dual;

      INSERT INTO LOAD_HIS_LOG
        (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
      VALUES
        ('pcisv7',
         'prpdrisk_s',
         v_task_start_date,
         v_task_end_date,
         to_char((v_task_end_date - v_task_start_date) * 86400),
         v_sql_code,
         v_sql_msg);
      COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'prpdrisk_s',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    end;
  end loop;
  commit;
end;
/
