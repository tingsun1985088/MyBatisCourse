CREATE function IF_GL_TB(c_app_no varchar2) return number as
  appNo varchar2(50);
  flag  number(1);
begin
  appNo := '';
  begin
    SELECT t1.C_Ply_App_No
      into appNo
      FROM web_Ply_Relation t1, web_Ply_Relation t2
     WHERE t2.C_Ply_App_No = c_app_no
       AND t1.N_Id = t2.N_Id
       AND t1.c_frm_no = t2.c_frm_no
       AND t1.C_Prod_No <> t2.C_Prod_No
       AND t1.C_Dpt_Cde = t2.C_Dpt_Cde
       AND t1.C_Joint_Mrk = 1;
  exception
    when no_data_found then
      flag := 0;
  end;

  IF appNo is not null then
    flag := 1;
  else
    flag := 0;
  end if;
  return flag;
end;
/
