CREATE function F_GET_VHL_ENGFRM_NO(V_APP_NO IN VARCHAR2) 

/*
   DESCRIB  THIS FILE IS EDITOR BY  WANGTIEPENG 2019年1月4日12:34:26
*/
RETURN  VARCHAR2 AS
-----------------------------init param-------
VC_APP_NO VARCHAR2(50);
VC_ENG_NO VARCHAR2(100);
VC_FRM_NO VARCHAR2(100);
--------------------------   find the param to used for another policy -----


V_OTHER_APP_NO VARCHAR2(50);
VC_DPT_CDE     VARCHAR2(50);


V_SQL   VARCHAR2(4000);

BEGIN
  
DELETE FROM TAB_VHL_PRM_ t WHERE t.c_app_no=V_APP_NO;


--DBMS_OUTPUT.PUT_LINE(1111);
/*STEP1 从车险通过投保单号，查询车架号和发动机号 */
SELECT VHL.C_APP_NO, 
       VHL.C_ENG_NO,
       VHL.C_FRM_NO--,
       --VHL.C_PLY_NO
       INTO 
       VC_APP_NO, 
       VC_ENG_NO,
       VC_FRM_NO--,
     --  VC_PLY_NO
  FROM WEB_APP_VHL VHL  
WHERE VHL.C_APP_NO=V_APP_NO;
/*STEP2  通过发动机号和车架号 拿到不同条件的投保单号，限定投保单号不同的其他信息*/

/*
INSERT INTO (


)*/


SELECT    nvl((SELECT C_APP_NO
       
     FROM WEB_PLY_VHL T 
   WHERE T.C_APP_NO<>V_APP_NO 
       AND t.N_EDR_PRJ_NO=0
   AND T.C_FRM_NO=VC_FRM_NO AND T.C_ENG_NO=VC_ENG_NO),'-')   INTO 
         V_OTHER_APP_NO FROM dual;

/*step3 在投保单主表提取 新投保单的相关机构*/


   SELECT C_DPT_CDE 
     INTO VC_DPT_CDE
     FROM WEB_APP_BASE T
    WHERE T.C_APP_NO = V_OTHER_APP_NO
      AND T.T_UDR_TM > (ADD_MONTHS(SYSDATE, -2))
      AND T.N_EDR_PRJ_NO = '0'
      AND T.N_RATIO_COEF='1';
/**/



/*test */

V_SQL:=(VC_APP_NO||','||VC_ENG_NO||','||VC_FRM_NO||','||V_OTHER_APP_NO||','||VC_DPT_CDE);

 INSERT INTO TAB_VHL_PRM_(
C_APP_NO ,    
C_ENG_NO  , 
C_FRM_NO ,
C_OTHER_APP_NO ,
C_DPT_CDE ,
T_CRT_TM,
PK_ID)
VALUES (
VC_APP_NO,
VC_ENG_NO,
VC_FRM_NO,
V_OTHER_APP_NO,
VC_DPT_CDE,
SYSDATE,
sys_guid()
);

COMMIT;



RETURN V_SQL;

EXCEPTION
WHEN OTHERS THEN
RETURN '';
END ;
/
