CREATE FUNCTION F_VHLCLM_TASK_GETFAC(C_RPT_NO   IN VARCHAR2,
                                                C_TASK_ID IN VARCHAR2,
                                                C_TASK_TYPE IN VARCHAR2,
                                                V_C_SNR_NO IN VARCHAR2,
                                                N_Num IN NUMBER)
 RETURN VARCHAR2 IS
  V_TASK_START_DATE DATE;
  V_TASK_END_DATE   DATE;
  V_SQL_CODE        NUMBER;
  V_SQL_MSG         VARCHAR2(4000) := ''; ---SQL错误信息
  V_SQL             VARCHAR2(4000);
  GETTASKTYPE       VARCHAR2(20):=C_TASK_TYPE;
  RETURNFLAG        VARCHAR2(30);
  RETURNTASKTYPE        VARCHAR2(30);

  -- 查询公共规则
  -- DECLARE
  CURSOR RULES IS
    SELECT T.C_SQL, T.C_RULE, T.C_FAC_NO, T.C_BLOCK_MRK,T.N_LEVEL,t.c_to_task_type
      FROM WEB_VHLCLM_TASK_FAC T
     WHERE T.C_STATUE = '1'
       AND T.C_SNR_NO = V_C_SNR_NO
       AND T.C_TASK_TYPE = GETTASKTYPE
     ORDER BY t.n_order;

BEGIN
  RETURNFLAG := '1';


  declare
    numrow number;

  BEGIN
    numrow := N_Num + 1;
    FOR RULE IN RULES LOOP
      dbms_output.put_line('');
      dbms_output.put_line('编号' || rule.c_fac_no);
      dbms_output.put_line('执行顺序' || numrow);
      numrow := numrow + 1;
      BEGIN

        DECLARE
          XX VARCHAR2(2);

          XX1 VARCHAR2(2);

        BEGIN
          XX := '1';
          IF RULE.C_SQL IS NOT NULL THEN
            --将参数赋值进sql
            V_SQL := F_VHLCLM_CHSQL_FAC(RULE.C_SQL, C_RPT_NO,C_TASK_ID,C_TASK_TYPE);
            DBMS_OUTPUT.PUT_LINE(V_SQL);
            --执行sql
            XX := F_CHECK_RIGHT(V_SQL, RULE.C_RULE);
            dbms_output.put_line(rule.c_fac_no || '结果' || xx);
            RETURNFLAG := XX;

          END IF;
          IF XX = '1' THEN
             XX1 := F_VHLCLM_TASK_GETFAC(C_RPT_NO,C_TASK_ID,C_TASK_TYPE, RULE.C_FAC_NO,numrow);
             DBMS_OUTPUT.PUT_LINE('结果' || XX1);
            RETURNFLAG := XX1;
          END IF;
          --并且关系 只要 有不满足  停止循环
          IF (XX = '0' OR XX1 = '0') AND RULE.C_BLOCK_MRK = '2' THEN
            RETURNFLAG := '0';
            dbms_output.put_line('返回' || returnflag);
            RETURN RETURNFLAG;
          END IF;

          --或者关系 只要有 满足  停止循环
          IF (XX = '1' and XX1 = '1') AND RULE.C_BLOCK_MRK = '1' THEN
            RETURNFLAG := '1';
            dbms_output.put_line('返回' || returnflag);
            --判断是否父因子
            IF (RULE.N_LEVEL = 1) THEN
               RETURNTASKTYPE := RULE.C_TO_TASK_TYPE;
               RETURN RETURNTASKTYPE;
            ELSE
               RETURN RETURNFLAG;
            END IF;
          END IF;
          --或者 关系  全部满足  返回 不不满足
        END;
      END;
    END LOOP;
  END;
  RETURN RETURNFLAG;

EXCEPTION

  WHEN OTHERS THEN
    RETURN '0';
    V_SQL_CODE := SQLCODE;
    V_SQL_MSG  := V_SQL_MSG || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO V_TASK_END_DATE FROM DUAL;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'F_VHLCLM_TASK_GETFAC',
       V_TASK_START_DATE,
       V_TASK_END_DATE,
       TO_CHAR((V_TASK_END_DATE - V_TASK_START_DATE) * 86400),
       V_SQL_CODE,
       V_SQL_MSG);
    COMMIT;

END;
/
