CREATE procedure add_prpdcompany(dptid in  varchar2) is
      v_task_start_date  date;
      v_task_end_date    date;
      v_sql_code        number;
      v_sql_msg         varchar2(4000) := ''; ---SQL错误信息
      cnm VARCHAR2(100);
      enm VARCHAR2(100);
      caddr VARCHAR2(100);
      eaddr VARCHAR2(100);
      zipcode VARCHAR2(20);
      tel VARCHAR2(50);
      fax VARCHAR2(20);
      snrdpt VARCHAR2(30);
      relcde VARCHAR2(100);
      dptsls CHAR(1);
      dptlevl CHAR(1);
      valid VARCHAR2(1);
      dptmrk CHAR(1);
      companycde VARCHAR2(30);
      crtcde VARCHAR2(30);
      crttm DATE;
      upcde VARCHAR2(30);
      uptm DATE;
      temp number;


begin

  
  select sysdate into v_task_start_date from dual;
  select sysdate into v_task_end_date from dual;

  
 select count(*) into temp from salesmiddle.prpdcompany@DBLINK_NEW_SALES  where COMCODE=dptid;
 if   temp=0  then
   
 INSERT INTO  salesmiddle.prpdcompany@DBLINK_NEW_SALES(
    COMCODE,
    COMCNAME,
    COMENAME,
    ADDRESSCNAME,
    ADDRESSENAME,
    POSTCODE,
    PHONENUMBER,
    FAXNUMBER,
    UPPERCOMCODE,
    COMATTRIBUTE,
    COMTYPE,
    COMLEVEL,
    VALIDSTATUS,
    ACNTUNIT,
    ACCCODE,
    CREATORCODE,
    CREATEDATE,
    UPDATERCODE,
    UPDATEDATE

  )
  (select d.c_dpt_cde,d.c_dpt_cnm,d.c_dpt_enm,d.c_dpt_caddr,d.c_dpt_eaddr,d.c_zip_cde,d.c_tel,d.c_fax,d.c_snr_dpt,d.c_dpt_rel_cde,d.c_dpt_cls,d.n_dpt_levl,
       d.c_is_valid,d.c_acct_dpt_mrk,d.c_company_cde,d.c_crt_cde,d.t_crt_tm,d.c_upd_cde,d.t_upd_tm
       from WEB_ORG_DPT d 
       where d.c_dpt_cde = dptid);
 
 else
   
    select d.c_dpt_cnm,d.c_dpt_enm,d.c_dpt_caddr,d.c_dpt_eaddr,d.c_zip_cde,d.c_tel,d.c_fax,d.c_snr_dpt,d.c_dpt_rel_cde,d.c_dpt_cls,d.n_dpt_levl,
       d.c_is_valid,d.c_acct_dpt_mrk,d.c_company_cde,d.c_crt_cde,d.t_crt_tm,d.c_upd_cde,d.t_upd_tm  
       into cnm,enm,caddr,eaddr,zipcode,tel,fax,snrdpt,relcde,dptsls,dptlevl,valid,dptmrk,companycde,crtcde,crttm,upcde,uptm
       from WEB_ORG_DPT d 
       where d.c_dpt_cde = dptid;
 
    update salesmiddle.prpdcompany@DBLINK_NEW_SALES  set  
    COMCNAME=cnm,
    COMENAME=enm,
    ADDRESSCNAME=caddr,
    ADDRESSENAME=eaddr,
    POSTCODE=zipcode,
    PHONENUMBER=tel,
    FAXNUMBER=fax,
    UPPERCOMCODE=snrdpt,
    COMATTRIBUTE=relcde,
    COMTYPE=dptsls,
    COMLEVEL=dptlevl,
    VALIDSTATUS=valid,
    ACNTUNIT=dptmrk,
    ACCCODE=companycde,
    CREATORCODE=crtcde,
    CREATEDATE=crttm,
    UPDATERCODE=upcde,
    UPDATEDATE=uptm     
    where  COMCODE=dptid;
 
 end if;
  
       
  SELECT SYSDATE INTO v_task_end_date FROM dual;

  INSERT INTO LOAD_HIS_LOG
    (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
  VALUES
    ('pcisv7',
     'add_prpdcompany',
     v_task_start_date,
     v_task_end_date,
     to_char((v_task_end_date - v_task_start_date) * 86400),
     v_sql_code,
     v_sql_msg);
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'add_prpdcompany',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
       commit;
       
end;
/
