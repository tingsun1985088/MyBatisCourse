CREATE FUNCTION F_GET_DPT_CNM(v_dptCde VARCHAR2) RETURN VARCHAR2 AS
  v_dpt_cnm VARCHAR2(100);
BEGIN

  SELECT dpt.c_dpt_cnm
    INTO v_dpt_cnm
    FROM web_org_dpt dpt
   WHERE dpt.c_dpt_cde = v_dptCde;

  RETURN v_dpt_cnm;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;

END;
/
