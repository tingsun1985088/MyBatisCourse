CREATE function F_rule_WX_0001(v_app_no varchar2) return number as
  --根据投保单号判断是不是只投保三者+免赔  1是，0不是
  v_count   number;
  v_SY_flag number;
begin

  --判断商业险只投保了 三者+不计免赔
  SELECT count(*)
    into v_SY_flag
    FROM WEB_APP_BASE t
   WHERE t.C_APP_NO = v_app_no
     AND t.c_prod_no in ('033011', '033014')
     and t.c_app_typ = 'A'
        --and nvl(t.c_sys_res,'0') ='00'
     and (select count(1)
            from WEB_APP_CVRG k
           where k.c_app_no = v_app_no
             and k.c_cvrg_no in ('033002', '033018')) = 2
     and (select count(1)
            from WEB_APP_CVRG k
           where k.c_app_no = v_app_no
             and k.c_cvrg_no not in ('033002', '033018')) = 0;
  if v_SY_flag >= 1 then
    v_count := 1;
  else
    v_count := 0;
  end if;

  return v_count;
exception
  when others then
    return 0;
end;
/
