CREATE FUNCTION "F_GET_C_LATEST_MRK" (VAPLNO varchar2) return  varchar2 is
V_RESULT varchar2(10);
begin
  select a.c_latest_mrk into V_RESULT from web_ply_base a
  where a.c_app_no=VAPLNO;

  return(V_RESULT);
  exception when others then
return V_RESULT;
end F_GET_C_LATEST_MRK ;









/
