CREATE function       GETCHECKTYPELESSSQL(currentmonth in varchar2,
                                       deptcode in varchar2,
                                       subdeptcode in varchar2,
                                       tablename varchar2,
                                       monthtype varchar2)
return varchar2 is
  Result varchar2(2000);
  strSQL varchar2(2000);
begin

if monthtype = '?' then
strSQL :=
    'select '
 || '    a.c_item_cde '
 || '    from '
 || '        t_item_sendrange a, t_item b, t_item_adjunct c '
 || '    where '
 || '        (a.c_item_no=b.c_item_no '
 || '        and a.c_item_no=c.c_item_no '
 || '        and '
 || '        ('
 || '        (c.c_dict_type_cde = ''SFKB'' and c.c_dict_cde = ''1'') '
 || '        ) '
 || '        and a.c_dept_cde = '''  ||  deptcode ||  ''')'
 || '        and a.c_item_no not in ('
 || '             select '
 || '                 c_item_no from '
 ||                   tablename
 || '             where c_month = ''' || currentmonth ||  ''''
 || '                   and c_sub_dept_cde    = '''  ||  subdeptcode  || ''''
 || '                   and (c_frequency = ''1'' ) '
 || '     )';

end if ;


if monthtype = '?' then
strSQL :=
    'select '
 || '    a.c_item_cde '
 || '    from '
 || '        t_item_sendrange a, t_item b, t_item_adjunt c '
 || '    where '
 || '        (a.c_item_no=b.c_item_no '
 || '        and a.c_item_no=c.c_item_no '
 || '        and '
 || '        ('
 || '        (c.c_dict_type_cde = ''SFYB'' and c.c_dict_cde = ''2'') '
 || '        ) '
 || '        and a.c_dept_cde = '''  ||  deptcode ||  ''')'
 || '        and a.c_item_no not in ('
 || '             select '
 || '                 c_item_no from '
 ||                   tablename
 || '             where c_month = ''' || currentmonth ||  ''''
 || '                   and c_sub_dept_cde    = '''  ||  subdeptcode  || ''''
 || '                   and (c_frequency = ''2'' ) '
 || '     )';

end if ;

if monthtype = '?' then
strSQL :=
    'select '
 || '    a.c_item_cde '
 || '    from '
 || '        t_item_sendrange a, t_item b, t_item_adjunt c '
 || '    where '
 || '        (a.c_item_no=b.c_item_no '
 || '        and a.c_item_no=c.c_item_no '
 || '        and '
 || '        ('
 || '        (c.c_dict_type_cde = ''SFYB'' and c.c_dict_cde = ''2'') '
 || '               or '
 || '        (c.c_dict_type_cde = ''SFJB'' and c.c_dict_cde = ''3'') '
 || '        ) '
 || '        and a.c_dept_cde = '''  ||  deptcode ||  ''')'
 || '        and a.c_item_no not in ('
 || '             select '
 || '                 c_item_no from '
 ||                   tablename
 || '             where c_month = ''' || currentmonth ||  ''''
 || '                   and c_sub_dept_cde    = '''  ||  subdeptcode  || ''''
 || '                   and (c_frequency = ''2''  or c_frequency = ''3'' ) '
 || '     )';

end if ;

if monthtype = '?' then
strSQL :=
    'select '
 || '    a.c_item_cde '
 || '    from '
 || '        t_item_sendrange a, t_item b, t_item_adjunt c '
 || '    where '
 || '        (a.c_item_no=b.c_item_no '
 || '        and a.c_item_no=c.c_item_no '
 || '        and '
 || '        ('
 || '        (c.c_dict_type_cde = ''SFYB'' and c.c_dict_cde = ''2'') '
 || '               or '
 || '        (c.c_dict_type_cde = ''SFJB'' and c.c_dict_cde = ''3'') '
 || '               or '
 || '        (c.c_dict_type_cde = ''SFBN'' and c.c_dict_cde = ''4'') '
 || '        ) '
 || '        and a.c_dept_cde = '''  ||  deptcode ||  ''')'
 || '        and a.c_item_no not in ('
 || '             select '
 || '                 c_item_no from '
 ||                   tablename
 || '             where c_month = ''' || currentmonth ||  ''''
 || '                   and c_sub_dept_cde    = '''  ||  subdeptcode  || ''''
 || '                   and ( c_frequency = ''2'' or c_frequency = ''3'' or c_frequency = ''4'') '
 || '     )';

end if ;

if monthtype = '?' then
strSQL :=
    'select '
 || '    a.c_item_cde '
 || '    from '
 || '        t_item_sendrange a, t_item b, t_item_adjunct c '
 || '    where '
 || '        (a.c_item_no=b.c_item_no '
 || '        and a.c_item_no=c.c_item_no '
 || '        and '
 || '        ('
 || '        (c.c_dict_type_cde = ''SFYB'' and c.c_dict_cde = ''2'') '
 || '               or '
 || '        (c.c_dict_type_cde = ''SFJB'' and c.c_dict_cde = ''3'') '
 || '               or '
 || '        (c.c_dict_type_cde = ''SFBN'' and c.c_dict_cde = ''4'') '
 || '               or '
 || '        (c.c_dict_type_cde = ''SFBN'' and c.c_dict_cde = ''5'') '
 || '        ) '
 || '        and a.c_dept_cde = '''  ||  deptcode ||  ''')'
 || '        and a.c_item_no not in ('
 || '             select '
 || '                 c_item_no from '
 ||                   tablename
 || '             where c_month = ''' || currentmonth ||  ''''
 || '                   and c_sub_dept_cde    = '''  ||  subdeptcode  || ''''
 || '                   and (c_frequency = ''2'' or c_frequency = ''3'' or c_frequency = ''4''  or c_frequency = ''5'') '
 || '     )';
end if ;

  Result:=strSQL;
  return(Result);

EXCEPTION
  WHEN OTHERS THEN
      RETURN '';

end GETCHECKTYPELESSSQL;

/
