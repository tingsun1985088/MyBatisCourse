CREATE function fixSpecSplit(cAppNo in varchar2,splitNo in number,fixSpecLength number) return varchar2 as
   fixSpecNode  varchar2(3999); --总特约
   fixSpecNodeNext varchar2(3999);
   prodNo varchar2(6);
   fixLength number; --特约长度
   x number; --声明变量
    begin
      SELECT LISTAGG(content, '') WITHIN GROUP(ORDER BY n_seq_no) AS content into fixSpecNode
        from (
             select rownum||'、'||c_spec_content||'；' content,n_seq_no from (
              select t.c_spec_content , t.n_seq_no from web_App_Fix_Spec t where t.c_app_no = cAppNo
              order by  t.n_seq_no
          )
      );
     select t.c_prod_no into prodNo from web_bas_qry_info t where t.c_app_no=cAppNo;
     --获得特约长度
     fixLength := length(fixSpecNode);
     If instr(prodNo,'030')=1 then
       --交强处理
        --如果长度超过600不拼接剩余长度
        if fixLength>fixSpecLength  then  --600
           fixSpecNode := substr(fixSpecNode, 0,fixSpecLength)||'剩余特约请见特约清单';
        end if;
     Else
       --商业处理
        if fixLength>fixSpecLength then  --370
          fixSpecNode := substr(fixSpecNode, 0,fixSpecLength)||'剩余特约请见特约清单';
        end if;
     End If;
     x := 0;
     WHILE x <floor(fixSpecLength/splitNo)  LOOP
       x := x + 1;
       --截取108到字符串末尾
       if x=1 then
         fixSpecNodeNext := substr(fixSpecNode,0,splitNo)||CHR(10);
       end if;
       fixSpecNodeNext := fixSpecNodeNext || substr(fixSpecNode,(splitNo * x)+1,splitNo * (x+1)) ||CHR(10);
    END LOOP;
    return fixSpecNodeNext;
    end fixSpecSplit;
/
