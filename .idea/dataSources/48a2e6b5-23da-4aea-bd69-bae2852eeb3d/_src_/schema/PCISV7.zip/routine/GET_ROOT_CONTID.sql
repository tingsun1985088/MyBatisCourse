CREATE FUNCTION "GET_ROOT_CONTID" (CContId in varchar2)/*输入查询合约ID*/
return varchar2  --返回根合约ID
as
  root_contid          varchar2(30):=CContId;

BEGIN

SELECT m.c_cont_id into root_contid
          FROM web_ri_cont_main m
           where m.c_orig_cont_id is null
         START WITH m.c_cont_id =CContId
        CONNECT BY PRIOR m.c_orig_cont_id = m.c_cont_id;


return   root_contid;

exception
when others then
return CContId;

END;






/
