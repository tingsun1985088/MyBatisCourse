CREATE FUNCTION F_CHANGE_SQL(VSQL   VARCHAR2,
                                        VWHERE VARCHAR2,
                                        VPARAM VARCHAR2,
                                        CRPTNO VARCHAR2) RETURN VARCHAR2 IS



 v_sql      VARCHAR2 (2000);


BEGIN

  SELECT  REPLACE(VSQL, 'v_crptno', CRPTNO) INTO v_sql FROM dual ;



  IF  VPARAM IS NOT NULL THEN

    SELECT  REPLACE(v_sql, '?',  VPARAM) INTO v_sql FROM dual ;

    END IF;

 -- VSQL := REPLACE(VSQL, '?', VWHERE || VPARAM);

  RETURN v_sql;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;
/
