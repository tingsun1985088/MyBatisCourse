CREATE PROCEDURE "CALPLYTAX" (v_ply_no IN WEB_PLY_BASE.c_ply_no%TYPE,--???
                    v_begin_tm DATE,--??????
                    v_end_tm   DATE,--??????
                    v_wrtlogflag IN NUMBER,--???????0???,1??
                    v_plytime OUT NUMBER,--??
                    v_bonus OUT NUMBER,--??
                    v_sum OUT NUMBER,--???
                    v_succsflag OUT NUMBER--??0,??-1,???????1,?????????2
                    )
IS
    v_prod_no     WEB_FIN_SAVEAMT_DUE.c_prod_no%TYPE; --????
    v_dpt_cde     WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;--????
    v_insrnc_bgn_tm DATE;--????
    v_insrnc_end_tm DATE;--????
    v_cal_bgn_tm    DATE;--???????
    v_cal_end_tm    DATE;--???????
    plytime       NUMBER(16, 2);--??
    edrtime       NUMBER(16, 2); --????
    newedrtime    NUMBER(16, 2);--
   -- npayamt       NUMBER(16, 2);
    npaidamt      NUMBER(16, 2);--?????
    --v_edr_rsn     WEB_EDR_BASE.C_EDR_CTNT%TYPE;
    v_cur_cde     WEB_FIN_SAVEAMT_DUE.c_Due_Cur%TYPE;
    v_rcpt_no     WEB_FIN_SAVEAMT_DUE.c_rcpt_no%TYPE;
    v_salegrp_cde WEB_FIN_SAVEAMT_DUE.C_SLSGRP_CDE%TYPE;
    chacls        WEB_FIN_SAVEAMT_DUE.c_cha_cls%TYPE;
    chacde        WEB_FIN_SAVEAMT_DUE.c_cha_cde%TYPE;
    v_sls_cde     WEB_FIN_SAVEAMT_DUE.c_sls_cde%TYPE;
    v_newedrno   WEB_EDR_BASE.c_edr_no%TYPE;--?????
    a            NUMBER(1);
    v_sub_rate   NUMBER(16, 6);
    v_crt_cde       WEB_FIN_SAVEAMT_DUE.c_crt_cde%TYPE;
    v_cal_tm        WEB_FIN_PAY_DUE.T_DUE_TM%TYPE;
    v_dptacc_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
    v_tmp_cnt      INT;
    v_tracktmp_cnt INT;
    v_add_type     WEB_BAS_BANK_PROFIT.C_REMARK%TYPE;

    --???????G,?????<0??????
    CURSOR cur_calint IS
      SELECT c_prod_no,
             NVL(n_bs_amt, 0),
             TRUNC(t_insrnc_bgn_tm),
             TRUNC(t_insrnc_end_tm),
             NVL(c_due_cur, CHR(0)),
             NVL(c_rcpt_no, CHR(0)),
             NVL(C_SLSGRP_CDE, CHR(0)),
             NVL(c_cha_cls, CHR(0)),
             NVL(c_cha_cde, CHR(0)),
             NVL(c_sls_cde, CHR(0)),
             --NVL(c_pay_prsn_cde, CHR(0)),
             NVL(c_dpt_cde, CHR(0)),
             c_crt_cde,
             c_dptacc_cde
        FROM WEB_FIN_SAVEAMT_DUE a
       WHERE c_feetyp_cde = 'G'
         AND n_bs_amt < 0
         AND c_ply_no = v_ply_no;

    vsum      NUMBER(16, 6);
    fsum      NUMBER(16, 6);
    imonth    NUMBER;
    iday      NUMBER;
    vbgntm    DATE;
    vendtm    DATE;
    fprftrate NUMBER(16, 6);--n_prft_rate,????
    fpara     NUMBER(16, 6);
    vbonus    NUMBER(16,6);--??
    vquerytm  DATE;
    v_item_no NUMBER(10);
    /* ???????????????*/
    CURSOR prft_rate(query_tm DATE) IS
      SELECT NVL(n_prft_rate, 0),
             t_bgn_tm,
             NVL(t_end_tm,
                 TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd'))
        FROM WEB_BAS_BANK_PROFIT
       WHERE (t_bgn_tm >= v_cal_bgn_tm AND t_bgn_tm <= query_tm OR
             NVL(t_end_tm,
                  TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd')) >=
             v_cal_bgn_tm AND
             NVL(t_end_tm,
                  TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd')) <=
             query_tm OR
             t_bgn_tm <= v_cal_bgn_tm AND
             NVL(t_end_tm,
                  TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd')) >=
             query_tm)
         AND c_remark = DECODE(v_add_type,
                               '3',
                               '0001',
                               '5',
                               '0002',
                               '6',
                               '0003',
                               '7',
                               '0007',
                               '9',
                               '0009')
       ORDER BY t_bgn_tm;

    --????G?????0???????? ?????????????????????????????

  BEGIN

    fsum        := 0;
    vsum        := 0;
    imonth      := 0;
    --iday        := 0;
    fprftrate   := 0;
    fpara       := 0;
    v_sub_rate  := 0;
    v_succsflag := 0;
		v_bonus			:=0;
    vbonus      :=0;
    v_tracktmp_cnt :=0;
    OPEN cur_calint;

    --???????????1
    v_succsflag := 1;
    LOOP
      FETCH cur_calint
        INTO v_prod_no, npaidamt, v_insrnc_bgn_tm, v_insrnc_end_tm, v_cur_cde, v_rcpt_no, v_salegrp_cde, chacls, chacde, v_sls_cde,  v_dpt_cde, v_crt_cde, v_dptacc_cde;
      EXIT WHEN cur_calint%NOTFOUND;
    v_succsflag := 0;
    --????????
    IF v_begin_tm<=v_insrnc_bgn_tm  THEN
       v_cal_bgn_tm:=v_insrnc_bgn_tm;
    ELSE
      IF v_begin_tm<=v_insrnc_end_tm THEN
         v_cal_bgn_tm:=v_begin_tm;
      ELSE
          v_cal_bgn_tm:=TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd');
      END IF;
    END IF;
    --????????
    IF v_end_tm>=v_insrnc_end_tm THEN
       v_cal_end_tm:=v_insrnc_end_tm;
    ELSE
      IF v_end_tm>=v_insrnc_bgn_tm THEN
           v_cal_end_tm:=v_end_tm;
      ELSE
          v_cal_end_tm:=TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd');
      END IF;
    END IF;

      v_cal_tm := TRUNC(v_cal_end_tm);

      --??????
      SELECT SUM(NVL(n_edr_prj_no, 0))
        INTO edrtime
        FROM WEB_PLY_BASE
       WHERE c_ply_no = TRIM(v_ply_no);

      SELECT NVL(c_add_type, '3')
        INTO v_add_type
        FROM WEB_PRD_PROD
       WHERE c_prod_no = v_prod_no;

       /*????????????????,????*/
				IF v_wrtlogflag=1 THEN
            SELECT COUNT(1)
    				INTO v_tracktmp_cnt
    				FROM WEB_FIN_TAXTRACK
    				WHERE c_rcpt_no = v_rcpt_no;

    				IF v_tracktmp_cnt <> 0 THEN
    				     DELETE FROM WEB_FIN_TAXTRACK WHERE c_rcpt_no = v_rcpt_no;
    				     v_tracktmp_cnt := 0;
    			  END IF;
        END IF;

      --?????????????
      IF edrtime = 0 AND ABS(npaidamt) > 0 AND v_tracktmp_cnt = 0 THEN
        /*????*/
        SELECT NVL(c_resv_txt_20, 0) --c_resv_txt_20,??
          INTO plytime
          FROM WEB_PLY_cvrg
         WHERE c_ply_no = TRIM(v_ply_no);
        newedrtime := plytime;
				/*??????????????*/
        IF TO_DATE(TO_CHAR(v_cal_end_tm, 'yyyymmdd'), 'yyyymmdd') -
           TO_DATE(TO_CHAR(v_cal_bgn_tm, 'yyyymmdd'), 'yyyymmdd') > 0 THEN
           				/*?????*/
          SELECT CEIL(MONTHS_BETWEEN(TO_DATE(TO_CHAR(v_cal_end_tm,
                                                     'yyyymmdd'),
                                             'yyyymmdd') + 1,
                                     TO_DATE(TO_CHAR(v_cal_bgn_tm,
                                                     'yyyymmdd'),
                                             'yyyymmdd')))
            INTO imonth
            FROM DUAL;

          /* ??????*/
          IF v_add_type = '3' THEN
            fpara := 0.006;
          END IF;

          IF v_add_type = '5' THEN
            fpara := 0.009;
          END IF;

          IF v_add_type = '6' /*caojy add v_add_type = '6' 2006-01-13*/
           THEN
            fpara := 0.004;
          END IF;

          IF v_add_type = '7' OR v_add_type = '9' /*zhanghui add v_add_type = '7','9' 2008-04-08*/
           THEN
            fpara := 0.0015;
          END IF;
          /* ?????????*/
          IF TO_DATE(TO_CHAR(v_cal_tm, 'yyyymmdd'), 'yyyymmdd') >
             TO_DATE(TO_CHAR(v_insrnc_end_tm, 'yyyymmdd'), 'yyyymmdd') THEN
            vquerytm := TO_DATE(TO_CHAR(v_insrnc_end_tm, 'yyyymmdd'),
                                'yyyymmdd');
          ELSE
            vquerytm := TO_DATE(TO_CHAR(v_cal_tm, 'yyyymmdd'), 'yyyymmdd');
          END IF;

          /* ?????????????*/
          v_item_no := 1;
          OPEN prft_rate(vquerytm);
          --???????2
          v_succsflag:=2;
          LOOP
            FETCH prft_rate
              INTO fprftrate, vbgntm, vendtm;
            EXIT WHEN prft_rate%NOTFOUND;

            v_succsflag:=0;

            IF v_cal_bgn_tm > vbgntm THEN
              vbgntm := v_cal_bgn_tm;
            END IF;

            IF v_cal_end_tm < vendtm THEN
              vendtm := v_cal_end_tm;
            END IF;

            IF vquerytm < vendtm THEN
              vendtm := vquerytm;
            END IF;

            v_sub_rate := (fprftrate + fpara) *
                          (TO_DATE(TO_CHAR(vendtm, 'yyyymmdd'), 'yyyymmdd') -
                          TO_DATE(TO_CHAR(vbgntm, 'yyyymmdd'), 'yyyymmdd') + 1);
            fsum       := fsum + v_sub_rate;
				IF v_wrtlogflag=1 THEN --v_wrtlogflag=1??????,?0???

            INSERT INTO WEB_FIN_TAXTRACK
              (c_rcpt_no,
               c_item_no,
               c_ply_no,
               c_edr_no,
               N_Shares,
               N_PAY_AMT,
               n_fprft_rate,
               n_fpara,
               n_sub_interest,
               t_bgn_tm,
               t_end_tm)
            VALUES
              (v_rcpt_no,
               TO_CHAR(v_item_no),
               v_ply_no,
               NULL,
               plytime,
               plytime * 10000,
               fprftrate,
               fpara,
               v_sub_rate * plytime * 10000 / 365,
               vbgntm,
               vendtm);

            v_item_no := v_item_no + 1;
            END IF;
          END LOOP;
          CLOSE prft_rate;

          /* ????????*/

          vsum :=plytime * 10000 + plytime * 10000 * fsum / 365;
          vbonus:=plytime * 10000 * fsum / 365;--??
        ELSE
          vsum := 0;
        END IF;
        v_plytime:=plytime;-- ??
        v_bonus:=vbonus;--??
        v_sum:=vsum;--???
        --??????

      ELSIF ABS(npaidamt) > 0 AND v_tracktmp_cnt = 0 THEN
            --?????????????
          SELECT Max(retno) INTO v_newedrno /*???max??????????????????????,max???,*/
                 FROM (SELECT NVL(c_edr_no,'------') AS retno, c_ply_no, t_udr_tm,t_next_edr_udr_tm FROM web_PLY_BASE
                       WHERE c_ply_no = v_ply_no)
                              WHERE TO_DATE(TO_CHAR(SYSDATE ,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss')>t_udr_tm
                                     AND TO_DATE(TO_CHAR(SYSDATE ,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss')<=t_next_edr_udr_tm;


        IF v_newedrno = '------' THEN
        v_tmp_cnt:=0;
        ELSE
          --T_EDR_????
          SELECT COUNT(*)
            INTO v_tmp_cnt
            FROM WEB_PLY_CVRG
           WHERE c_edr_no = TRIM(v_newedrno);

          IF v_tmp_cnt > 0 THEN
            SELECT NVL(n_resv_num_1, 0)
              INTO newedrtime
              FROM WEB_PLY_CVRG --T_EDR_????
             WHERE c_edr_no = TRIM(v_newedrno);

            fsum      := 0;
            vsum      := 0;
            imonth    := 0;
            iday      := 0;
            fprftrate := 0;
            fpara     := 0;
						v_bonus		:=0;
            vbonus    :=0;
						/*??????????????*/
            IF TO_DATE(TO_CHAR(v_cal_end_tm, 'yyyymmdd'), 'yyyymmdd') -
               TO_DATE(TO_CHAR(v_insrnc_bgn_tm, 'yyyymmdd'), 'yyyymmdd') >= 0 THEN
               	/*?????*/
              SELECT CEIL(MONTHS_BETWEEN(TO_DATE(TO_CHAR(v_insrnc_end_tm,
                                                         'yyyymmdd'),
                                                 'yyyymmdd') + 1,
                                         TO_DATE(TO_CHAR(v_insrnc_bgn_tm,
                                                         'yyyymmdd'),
                                                 'yyyymmdd')))
                INTO imonth
                FROM DUAL;

              /* ??????*/
              IF v_add_type = '3' THEN
                fpara := 0.006;
              END IF;

              IF v_add_type = '5' THEN
                fpara := 0.009;
              END IF;

              IF v_add_type = '6' /*caojy add v_add_type = '6' 2006-01-13*/
               THEN
                fpara := 0.004;
              END IF;

              IF v_add_type = '7' OR v_add_type = '9' /*zhanghui add v_add_type = '7','9' 2008-04-08*/
               THEN
                fpara := 0.0015;
              END IF;
              /* ?????????*/
              IF TO_DATE(TO_CHAR(v_cal_tm, 'yyyymmdd'), 'yyyymmdd') >
                 TO_DATE(TO_CHAR(v_insrnc_end_tm, 'yyyymmdd'), 'yyyymmdd') THEN
                vquerytm := TO_DATE(TO_CHAR(v_insrnc_end_tm, 'yyyymmdd'),
                                    'yyyymmdd');
              ELSE
                vquerytm := TO_DATE(TO_CHAR(v_cal_tm, 'yyyymmdd'),
                                    'yyyymmdd');
              END IF;

              /* ?????????????*/
              v_item_no := 1;
              OPEN prft_rate(vquerytm);
              --???????2
              v_succsflag:=2;
              LOOP
                FETCH prft_rate
                  INTO fprftrate, vbgntm, vendtm;
                EXIT WHEN prft_rate%NOTFOUND;

               v_succsflag:=0;

                IF v_insrnc_bgn_tm > vbgntm THEN
                  vbgntm := v_insrnc_bgn_tm;
                END IF;

                IF v_cal_end_tm < vendtm THEN
                  vendtm := v_cal_end_tm;
                END IF;

                IF vquerytm < vendtm THEN
                  vendtm := vquerytm;
                END IF;

                v_sub_rate := (fprftrate + fpara) *
                              (TO_DATE(TO_CHAR(vendtm, 'yyyymmdd'),
                                       'yyyymmdd') -
                              TO_DATE(TO_CHAR(vbgntm, 'yyyymmdd'),
                                       'yyyymmdd') + 1);

                fsum := fsum + v_sub_rate;

                IF v_wrtlogflag=1 THEN --v_wrtlogflag=1??????,?0???
                /*????????????????,????*/
						      SELECT COUNT(1)
						        INTO v_tracktmp_cnt
						        FROM WEB_FIN_TAXTRACK
						       WHERE c_rcpt_no = v_rcpt_no;

						      IF v_tracktmp_cnt <> 0 THEN
						        DELETE FROM WEB_FIN_TAXTRACK WHERE c_rcpt_no = v_rcpt_no;

						        v_tracktmp_cnt := 0;
						      END IF;
                INSERT INTO WEB_FIN_TAXTRACK
                  (c_rcpt_no,
                   C_item_no,
                   c_ply_no,
                   c_edr_no,
                   N_Shares,
                   N_PAY_AMT,
                   n_fprft_rate,
                   n_fpara,
                   n_sub_interest,
                   t_bgn_tm,
                   t_end_tm)
                VALUES
                  (v_ply_no,
                   TO_CHAR(v_item_no),
                   v_ply_no,
                   v_newedrno,
                   newedrtime,
                   newedrtime * 10000,
                   fprftrate,
                   fpara,
                   v_sub_rate * newedrtime * 10000 / 365,
                   vbgntm,
                   vendtm);
                END IF;
                v_item_no := v_item_no + 1;
              END LOOP;
              CLOSE prft_rate;

              /* ????????*/
              vsum := newedrtime * 10000 + newedrtime * 10000 * fsum / 365;
              vbonus:=newedrtime * 10000 * fsum / 365;
            ELSE
              vsum := 0;
              v_bonus:=0;
            END IF;
            --??
            v_bonus:=vbonus;
            v_plytime:=newedrtime;
            v_sum:=vsum;
          END IF;
        END IF;

      END IF;



    END LOOP;

    CLOSE cur_calint;
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        --RAISE;
        dbms_output.put_line('exception' || '*' || v_rcpt_no || SQLERRM);

        v_succsflag := -1;

      END;

  END;










/
