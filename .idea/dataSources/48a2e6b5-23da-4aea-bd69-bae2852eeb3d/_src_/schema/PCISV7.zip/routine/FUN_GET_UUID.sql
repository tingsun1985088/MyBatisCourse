CREATE FUNCTION Fun_Get_Uuid RETURN VARCHAR2 IS
V_Uuid VARCHAR2(32);
BEGIN
SELECT Sys_Guid() INTO V_Uuid FROM Dual;
RETURN V_Uuid;
END;
select sysdate from dual;
insert into web_vhlclm_dpt_ideno(C_ID,C_DPT_CDE,C_SECONDDPT_CDE,C_IDENTITY_NO,C_NEW_FLG,C_CRT_CDE,T_CRT_TM,C_UPD_CDE,T_UPD_TM)
values(Fun_Get_Uuid,'100101','1001','91370600310386738C','1','3700001',sysdate,'3700001',sysdate);
/
