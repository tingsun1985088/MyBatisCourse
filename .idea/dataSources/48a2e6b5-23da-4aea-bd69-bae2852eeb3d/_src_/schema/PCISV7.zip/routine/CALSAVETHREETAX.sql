CREATE PROCEDURE "CALSAVETHREETAX" is
v_other_sumamt WEB_FIN_SAVEAMT_DUE.N_BS_AMT%TYPE;

 v_insrnc_bgn_tm DATE; --????
        v_insrnc_end_tm DATE; --????
        v_prod_no       WEB_FIN_SAVEAMT_DUE.c_prod_no%TYPE; --????

        v_dpt_cde     WEB_FIN_SAVEAMT_DUE.c_dpt_cde%TYPE;
        plytime       NUMBER(16, 2);
        edrtime       NUMBER(16, 2);
        newedrtime    NUMBER(16, 2);
        ngetamt       NUMBER(16, 2);
        npayamt       NUMBER(16, 2);
        npaidamt      NUMBER(16, 2);
        --v_edr_rsn     WEB_EDR_BASE.c_edr_rsn%TYPE;
  v_edr_rsn     VARCHAR2(2);
        v_cur_cde     WEB_FIN_SAVEAMT_DUE.C_DUE_CUR%TYPE;
        v_rcpt_no     WEB_FIN_SAVEAMT_DUE.c_rcpt_no%TYPE;
        v_salegrp_cde WEB_FIN_SAVEAMT_DUE.C_SLSGRP_CDE%TYPE;
        chacls        WEB_FIN_SAVEAMT_DUE.c_cha_cls%TYPE;
        chacde        WEB_FIN_SAVEAMT_DUE.c_cha_cde%TYPE;
        v_sls_cde     WEB_FIN_SAVEAMT_DUE.c_sls_cde%TYPE;
        --payprsncde    WEB_FIN_SAVEAMT_DUE.c_pay_prsn_cde%TYPE;
        payprsncde    VARCHAR2(14);
        --v_dpt_cde          T_FIN_SAVEAMTDUE.c_dpt_cde%TYPE;
        --v_monseqno   T_FIN_MONTHACCRUAL.c_mon_ret_no%TYPE;
        v_monseqno   VARCHAR2(21);
        --v_seq_no     T_FIN_VOUCHER.c_seq_no%TYPE;
        v_seq_no     VARCHAR2(21);
        --v_monseqno1  T_FIN_MONTHACCRUAL.c_mon_ret_no%TYPE;
        v_monseqno1  VARCHAR2(21);
        --v_seq_no1    T_FIN_VOUCHER.c_seq_no%TYPE;
        v_seq_no1    VARCHAR2(21);
        v_feetyp_cde WEB_FIN_SAVEAMT_DUE.c_feetyp_cde%TYPE;
        v_newedrno   WEB_EDR_BASE.c_edr_no%TYPE;
        n_realflag   NUMBER(1);
        a            NUMBER(1);
        v_Interest_reate        web_fin_presave.n_Interest_reate%type;
        v_other_amttax        WEB_FIN_SAVEAMT_DUE.N_BS_AMT%TYPE;
        v_cal_tm      DATE;
        v_ply_no          WEB_FIN_SAVEAMT_DUE.c_ply_no%type;

        v_other_amt     WEB_FIN_SAVEAMT_DUE.N_BS_AMT%TYPE;
        v_pay_amt             WEB_FIN_SAVEAMT_DUE.N_BS_AMT%TYPE;
        v_succsflag         int;


        dznoflag        INT;
        v_interest_flag VARCHAR2(2);


        v_vou_memo       WEB_FIN_MADCR.c_vou_memo%TYPE;
        v_department_cde WEB_FIN_DCR.c_department_cde%TYPE;
        v_company_cde    WEB_FIN_MADCR.c_company_cde%TYPE;
        v_period_name    WEB_FIN_MADCR.c_period_name%TYPE;
        v_servicetype_no WEB_FIN_MADCR.c_servicetype_no%TYPE;
        v_end_time       WEB_BAS_FIN_ACCT_PERIOD.T_END_TM%TYPE;
        v_dptacc_cde     WEB_ORG_DPT.c_dpt_cde%TYPE;
        v_maseq_no       WEB_FIN_MADCR.c_seq_no%TYPE;

        v_kind_no      WEB_BAS_FIN_PROD.c_prod_no%TYPE;
        v_tmp_cnt      INT;
        v_tracktmp_cnt INT;
        v_add_type     web_prd_prod.c_add_type%TYPE;


        v_bonds_rate    web_fin_presave.N_Bonds_rate%TYPE;
        v_crt_cde       WEB_FIN_SAVEAMT_DUE.c_crt_cde%TYPE;
        v_year      number(20,4);
        v_data      web_fin_presave.N_Bonds_rate%TYPE;--number(16,8);--t_fin_tmpsave.n_data%TYPE;
        v_fm        number(16,6);--t_fin_tmpsave.n_fm%TYPE;
        v_fz        number(16,6);--t_fin_tmpsave.n_fz%TYPE;
        v_jg        number(16,6);--t_fin_presave.N_Bonds_rate%TYPE;--t_fin_tmpsave.n_jg%TYPE;                          --???????

        --v_max             WEB_FIN_SAVEAMT_DUE.n_pay_amt%TYPE;             --???
        --v_Surrender_amt  WEB_FIN_SAVEAMT_DUE.n_pay_amt%TYPE;             --????
        --N_cal_amt       WEB_FIN_SAVEAMT_DUE.n_pay_amt%TYPE;              --?????

        v_max             NUMBER(22, 6);           --???
        v_Surrender_amt  NUMBER(22, 6);           --????
        N_cal_amt       NUMBER(22, 6);             --?????

        v_ical_tm                WEB_FIN_SAVEAMT_DUE.t_crt_tm%type;
        v_sub_rate    NUMBER(16, 6);
        k_count        number;

        v_crt_cde          WEB_FIN_SAVEAMT_DUE.c_crt_cde%type;
           v_err_content        WEB_BAS_FIN_ERRORLOG.c_err_content%type;
    CURSOR cur_calint IS
     SELECT c_prod_no,
             NVL(n_paid_amt, 0),
             TRUNC(t_insrnc_bgn_tm),
             TRUNC(t_insrnc_end_tm),
             NVL(C_DUE_CUR, CHR(0)),
             NVL(c_rcpt_no, CHR(0)),
            NVL(C_SLSGRP_CDE, CHR(0)),
             NVL(c_cha_cls, CHR(0)),
             NVL(c_cha_cde, CHR(0)),
             NVL(c_sls_cde, CHR(0)),
             NVL(C_PAYER_CDE, CHR(0)),
             NVL(c_dpt_cde, CHR(0)),
             C_DPTACC_CDE,
             c_ply_no
        FROM WEB_FIN_SAVEAMT_DUE
       WHERE  c_feetyp_cde = 'G' AND n_paid_amt < 0
             --and t_check_tm <= to_date('2009-05-31 23:59:59','yyyy-mm-dd hh24:mi:ss')
           and t_crt_tm  <= to_date('2009-05-31 23:59:59','yyyy-mm-dd hh24:mi:ss')
              AND not exists (SELECT 1 FROM web_FIN_TMPBIGSAVE_DUE where c_ply_no=WEB_FIN_SAVEAMT_DUE.c_ply_no)
           AND NOT EXISTS
           (SELECT c_ply_no FROM web_edr_base
                              WHERE c_ply_no =WEB_FIN_SAVEAMT_DUE.c_ply_no
                                               AND c_edr_rsn IN ('A1','A3','77')
           )
       AND WEB_FIN_SAVEAMT_DUE.c_Ply_No='1010000022005100069';




    --????G?????0???????? ?????????????????????????????

  BEGIN





   -- return;

    --?????
    --IF TRUNC(SYSDATE - 1, 'MM') <> TRUNC(ADD_MONTHS(SYSDATE, -1)) THEN
    --  RETURN;
    --ELSE
      /*
      UPDATE WEB_FIN_SAVEAMT_DUE
        SET c_lx_flag='0'
        WHERE c_feetyp_cde = 'G' AND n_paid_amt < 0
      and not exists
           (SELECT c_ply_no from t_edr_base
               WHERE c_ply_no =WEB_FIN_SAVEAMT_DUE.c_ply_no
                 and c_edr_rsn in ('A1','A3','77')
           );
      */

   --   commit;
 --   END IF;

    --????????
    v_ical_tm      := TRUNC(SYSDATE) - 1;
    v_period_name := TO_CHAR(v_ical_tm, 'yyyy-mm');


    OPEN cur_calint;
    LOOP
      FETCH cur_calint
        INTO v_prod_no, npaidamt, v_insrnc_bgn_tm, v_insrnc_end_tm, v_cur_cde, v_rcpt_no, v_salegrp_cde, chacls, chacde, v_sls_cde, payprsncde, v_dpt_cde, v_dptacc_cde,v_ply_no;

      EXIT WHEN cur_calint%NOTFOUND;


        IF trunc(v_cal_tm)>trunc(v_insrnc_end_tm) then
       		v_cal_tm:=v_insrnc_end_tm;
       else
      		v_cal_tm:=v_ical_tm;
       end if;

       Service_Interface.CalPlyTax(v_ply_no,v_insrnc_bgn_tm,v_insrnc_end_tm,0,plytime,v_other_amt,v_other_sumamt,v_succsflag);

     newedrtime := v_other_amt;
     SELECT NVL(c_add_type, '3')
        INTO v_add_type
        FROM WEB_PRD_PROD
       WHERE c_prod_no = v_prod_no;


        IF TRUNC(v_cal_tm)<=TRUNC(v_insrnc_end_tm) THEN
            --???????
        select nvl(N_Bonds_rate,0)
        into v_Bonds_rate
        from WEB_BAS_FIN_PROD
        where c_prod_no = v_prod_no;

            --?????????

         v_year:= (TRUNC(v_insrnc_end_tm) - TRUNC(v_cal_tm))/365;
         v_data:= (100 + v_Bonds_rate)/100;
         v_fm :=POWER(v_data,v_year);


	  select nvl(N_PROFIT_AMT,0)
	     	INTO v_other_amttax
	    	FROM WEB_FIN_SAVEAMT_DUE
	    	WHERE c_rcpt_no=v_rcpt_no;


        	--????????????????N_PROFIT_AMT?
	--IF v_other_amttax=0 THEN
		--maintenance.CalPlyTax(v_ply_no,v_other_amttax,v_succsflag);
	--END IF;


         v_fz:=v_other_amttax;
         v_jg :=(newedrtime * 10000 +v_fz)/v_fm;
        v_Surrender_amt := Invst_Finc.get_dischg_sum(v_add_type,v_insrnc_bgn_tm,v_insrnc_end_tm,v_cal_tm,newedrtime);
        ELSE
                v_year:=0;
                v_jg:=newedrtime * 10000+v_other_amt;
                v_Surrender_amt :=newedrtime * 10000+v_other_amt;
                V_BONDS_RATE:=0;
        END IF;
        -- v_Bonds_rate = v_data;

            /*??????*/



            /*?????*/
            v_max := v_other_amt+newedrtime * 10000;
                v_other_amt:=v_other_amt+newedrtime * 10000;
            IF  v_other_amt<v_Surrender_amt THEN
                    v_max := v_Surrender_amt;
            END IF;

            IF  v_max < v_jg  THEN
                    v_max := v_jg;
            END IF;

            N_cal_amt:= v_max -v_other_amt;
                                              --???????

            /*??????????????????*/
        DELETE FROM WEB_FIN_PRESAVE WHERE C_RCPT_NO=v_rcpt_no AND T_CAL_TM=v_CAL_TM;

            INSERT INTO WEB_FIN_PRESAVE
            (c_rcpt_no,
            T_CAL_TM,
            C_ply_no,
            n_shares_no,
            N_bs_amt,
            N_TAX_amt,
            N_discount_amt,
            N_Surrender_amt,
            N_Bonds_rate,
            N_interest_reate,
            N_max_amt,
            N_cal_amt,
            C_memo,
            c_flag,
            c_prod_no,
      n_year,N_PROFIT_AMT
      )
            VALUES
            (v_rcpt_no,
            v_cal_tm,
            v_ply_no,
            nvl(newedrtime,0),
        nvl(newedrtime,0)*10000,
            v_other_amt,
            v_jg,
            v_Surrender_amt,
            v_Bonds_rate,
             nvl(v_Interest_reate,0),
            v_max,
            n_cal_amt,                   --?????
            '',                             --??
            0,
            v_prod_no,v_year,NVL(v_other_amttax,0)
            );
            v_succsflag := 1;
            COMMIT;

    END LOOP;

    CLOSE cur_calint;

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      --RAISE;
      dbms_output.put_line('exception' || '*' || v_rcpt_no || v_ply_no ||
                           v_cur_cde || SQLERRM);
      ROLLBACK;

      v_err_content := 'proc:[CalSaveThreeTax],??????[' || v_rcpt_no || v_ply_no ||'],?????[' ||
                       SQLCODE || SQLERRM;

      INSERT INTO WEB_BAS_FIN_ERRORLOG
        (c_err_no, c_errtype_no, c_tran_type, c_err_content, t_crt_tm)
      VALUES
        (F_Fin_Getcode('e'),
         '001',  --??????
         '0000', --??????
         v_err_content,
         SYSDATE);
      COMMIT;
    END;
end CalSaveThreeTax;











/
