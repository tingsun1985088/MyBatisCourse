CREATE FUNCTION "HEXTOASC" (sIn IN varchar2)
RETURN varchar2
IS
sTmp varchar2(1000);
i integer;
x integer;
BEGIN
i:=1;
stmp:='';
loop
exit when i>lengthb(sIn);
x:=to_number(substrb(sIn,i,2),'XXXX');
if x>128 then
sTmp:=sTmp||chr(to_number(substrb(sIn,i,4),'XXXX'));
i:=i+4;
else
sTmp:=sTmp||chr(to_number(substrb(sIn,i,2),'XXXX'));
i:=i+2;
end if;

end loop;
return sTmp;
END;









/
