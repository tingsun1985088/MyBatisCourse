CREATE FUNCTION F_GET_APP_NUMOFDAY(insrncBgnTm in varchar2,InsrncEndTime in varchar2)
  return number
  as
    NUMOFDAY number;
  begin
     select to_date(InsrncEndTime,'yyyy-MM-dd hh24:mi:ss') - to_date(insrncBgnTm,'yyyy-MM-dd hh24:mi:ss') into NUMOFDAY from dual;
     return trunc(NUMOFDAY) + 1;
  end;
/
