CREATE function get_gotprm_quart( --V_insrnc_bgn_tm,V_insrnc_end_tm,V_EDR_BGN_TM,V_EDR_END_TM
                                            v_today date,--评估日
                                            v_ply_no varchar2,--保单号
                                            v_edr_no varchar2,--批单号
                                            v_insrnc_bgn_tm date,--保险起期
                                            v_insrnc_end_tm date,--保险止期
                                            V_EDR_BGN_TM    date,--批单生效日期
                                            V_EDR_END_TM    date, --批单止期
                                            v_got_prm       number--各个保批单的总满期
                                            ) return number as
v_gotprm_quart        number(16,2);
v_year                varchar2(4);
v_month               varchar2(2);


begin

exception
  when others then
    return null;
end;
/
