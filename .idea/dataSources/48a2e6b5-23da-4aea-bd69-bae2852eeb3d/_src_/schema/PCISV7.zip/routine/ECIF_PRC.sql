CREATE procedure ecif_prc is
  V_TASK_START_DATE DATE;
  V_TASK_END_DATE   DATE;
  V_SQL_CODE        NUMBER;
  V_SQL_MSG         VARCHAR2(4000) := ''; --SQL错误信息
  t_latest_date     DATE;
  id                varchar2(200); --主键
  cAppNo            varchar2(200); --投保单号
  --声明游标
  --团单保单
  CURSOR CUR_PLY_GRP IS
    select c_app_no, c_ply_no
      from web_app_grp_member g
     where g.c_ply_no is not null
       and g.t_upd_tm >= t_latest_date
          
          -- and g.t_upd_tm >= date'2016-10-20'
       and g.t_upd_tm <=
           to_date(to_char(V_TASK_START_DATE, 'yyyy-MM-dd hh24:mi:ss'),
                   'yyyy-MM-dd hh24:mi:ss')
     group by c_app_no, c_ply_no;
  --团单批单
  CURSOR CUR_EDR_GRP IS
    select c_app_no, c_ply_no, c_edr_no
      from web_edr_grp_member g
     where g.c_edr_no is not null
       and g.C_OP_MRK in ('A', 'U')
       and g.t_upd_tm >= t_latest_date
          -- and g.t_upd_tm >= date'2016-10-01'
       and g.t_upd_tm <=
           to_date(to_char(V_TASK_START_DATE, 'yyyy-MM-dd hh24:mi:ss'),
                   'yyyy-MM-dd hh24:mi:ss')
     group by c_app_no, c_ply_no, c_edr_no;
  --第三方保单
  CURSOR CUR_PLY_DSF IS
    select c_app_no, c_ply_no
      from web_ply_base w
     where w.c_sys_res <> '0'
       and substr(w.c_prod_no, 0, 2) <> '03'
       and w.c_edr_no is null
       and w.t_upd_tm >= t_latest_date
          --and w.t_upd_tm >= date'2016-11-10'
       and w.t_upd_tm <=
           to_date(to_char(V_TASK_START_DATE, 'yyyy-MM-dd hh24:mi:ss'),
                   'yyyy-MM-dd hh24:mi:ss');

BEGIN
  --任务开始时间和任务结束时间
  SELECT SYSDATE INTO V_TASK_START_DATE FROM DUAL;
  SELECT SYSDATE INTO V_TASK_END_DATE FROM DUAL;
  /*  select w.t_crt_tm
   into t_latest_date
   from web_mid_ply_grp_ecif w
  where rownum = 1
  order by w.t_crt_tm desc;*/
  select t_crt_tm
    into t_latest_date
    from (select w.t_crt_tm
            from web_mid_ply_grp_ecif w
           order by w.t_crt_tm desc)
   where rownum = 1;
  -- dbms_output.put_line (t_latest_date);

  FOR CUR_PLY_REC IN CUR_PLY_GRP LOOP
    BEGIN
      select sys_guid() into id from dual;
      cAppNo := CUR_PLY_REC.c_App_No;
      insert into web_mid_ply_grp_ecif
        (C_PK_ID,
         C_APP_NO,
         C_PLY_NO,
         C_EDR_NO,
         C_SYS_RES,
         C_SUC_FLAG,
         N_SUM_CYC,
         C_RETURN_MSG,
         C_CRT_CDE,
         T_CRT_TM,
         C_UPD_CDE,
         T_UPD_TM,
         C_APP_TYP,
         C_GRP_MRK)
      values
        (id,
         cAppNo,
         CUR_PLY_REC.c_Ply_No,
         null,
         '0',
         '0',
         0,
         null,
         'sys',
         V_TASK_START_DATE,
         'sys',
         V_TASK_START_DATE,
         'A',
         '1');
    
      --COMMIT;
    
      --成功日志
      V_SQL_CODE := '0';
      V_SQL_MSG  := '团单：' || cAppNo || '，抽取成功。';
      INSERT INTO LOAD_HIS_LOG3
        (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
      VALUES
        ('pcisv7_ecif',
         '核心送意健险团单的保/批单号到中间表',
         v_task_start_date,
         V_TASK_END_DATE,
         (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
         V_SQL_CODE,
         V_SQL_MSG);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        V_SQL_CODE := SQLCODE;
        V_SQL_MSG  := '核心团单投保单号：' || cAppNo || '，插入失败。' || SQLERRM;
        ROLLBACK;
        INSERT INTO LOAD_HIS_LOG3
          (SYS,
           JOBNAME,
           START_DATE,
           END_DATE,
           RUN_DATE,
           SQL_CODE,
           SQL_STATE)
        VALUES
          ('pcisv7_ecif',
           '核心送意健险团单的保/批单号到中间表',
           v_task_start_date,
           V_TASK_END_DATE,
           (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
           V_SQL_CODE,
           V_SQL_MSG);
        COMMIT;
    END;
  end loop;

  FOR CUR_EDR_REC IN CUR_EDR_GRP LOOP
    begin
      select sys_guid() into id from dual;
      cAppNo := CUR_EDR_REC.c_App_No;
      insert into web_mid_ply_grp_ecif
        (C_PK_ID,
         C_APP_NO,
         C_PLY_NO,
         C_EDR_NO,
         C_SYS_RES,
         C_SUC_FLAG,
         N_SUM_CYC,
         C_RETURN_MSG,
         C_CRT_CDE,
         T_CRT_TM,
         C_UPD_CDE,
         T_UPD_TM,
         C_APP_TYP,
         C_GRP_MRK)
      values
        (id,
         cAppNo,
         CUR_EDR_REC.c_Ply_No,
         CUR_EDR_REC.C_EDR_NO,
         '0',
         '0',
         0,
         null,
         'sys',
         V_TASK_START_DATE,
         'sys',
         V_TASK_START_DATE,
         'E',
         '1');
      --成功日志
      V_SQL_CODE := '0';
      V_SQL_MSG  := '团单：' || cAppNo || '，抽取成功。';
      INSERT INTO LOAD_HIS_LOG3
        (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
      VALUES
        ('pcisv7_ecif',
         '核心送意健险团单的保/批单号到中间表',
         v_task_start_date,
         V_TASK_END_DATE,
         (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
         V_SQL_CODE,
         V_SQL_MSG);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        V_SQL_CODE := SQLCODE;
        V_SQL_MSG  := '核心团单投保单号：' || cAppNo || '，插入失败。' || SQLERRM;
        ROLLBACK;
        INSERT INTO LOAD_HIS_LOG3
          (SYS,
           JOBNAME,
           START_DATE,
           END_DATE,
           RUN_DATE,
           SQL_CODE,
           SQL_STATE)
        VALUES
          ('pcisv7_ecif',
           '核心送意健险团单的保/批单号到中间表',
           v_task_start_date,
           V_TASK_END_DATE,
           (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
           V_SQL_CODE,
           V_SQL_MSG);
        COMMIT;
    END;
  end loop;

  FOR CUR_PLY_OUT IN CUR_PLY_DSF LOOP
    BEGIN
      select sys_guid() into id from dual;
      cAppNo := CUR_PLY_OUT.c_App_No;
      insert into web_mid_ply_grp_ecif
        (C_PK_ID,
         C_APP_NO,
         C_PLY_NO,
         C_EDR_NO,
         C_SYS_RES,
         C_SUC_FLAG,
         N_SUM_CYC,
         C_RETURN_MSG,
         C_CRT_CDE,
         T_CRT_TM,
         C_UPD_CDE,
         T_UPD_TM,
         C_APP_TYP,
         C_GRP_MRK)
      values
        (id,
         cAppNo,
         CUR_PLY_OUT.c_Ply_No,
         null,
         null,
         '0',
         0,
         null,
         'sdf',
         V_TASK_START_DATE,
         'sdf',
         V_TASK_START_DATE,
         'A',
         '0');
    
      --COMMIT;
    
      --成功日志
      V_SQL_CODE := '0';
      V_SQL_MSG  := '第三方投保单号：' || cAppNo || '，抽取成功。';
      INSERT INTO LOAD_HIS_LOG3
        (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
      VALUES
        ('pcisv7_ecif',
         '核心送第三方保单号到中间表',
         v_task_start_date,
         V_TASK_END_DATE,
         (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
         V_SQL_CODE,
         V_SQL_MSG);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        V_SQL_CODE := SQLCODE;
        V_SQL_MSG  := '核心送第三方投保单号：' || cAppNo || '，插入失败。' || SQLERRM;
        ROLLBACK;
        INSERT INTO LOAD_HIS_LOG3
          (SYS,
           JOBNAME,
           START_DATE,
           END_DATE,
           RUN_DATE,
           SQL_CODE,
           SQL_STATE)
        VALUES
          ('pcisv7_ecif',
           '核心送核心送第三方保单号到中间表',
           v_task_start_date,
           V_TASK_END_DATE,
           (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
           V_SQL_CODE,
           V_SQL_MSG);
        COMMIT;
    END;
  end loop;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    V_SQL_CODE := SQLCODE;
    V_SQL_MSG  := '团单：' || cAppNo || '，抽取失败。' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO V_TASK_END_DATE FROM DUAL;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG3
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7_ecif',
       '核心送意健险团单的保/批单号到中间表',
       v_task_start_date,
       V_TASK_END_DATE,
       (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
       V_SQL_CODE,
       V_SQL_MSG);
    COMMIT;
END;
/
