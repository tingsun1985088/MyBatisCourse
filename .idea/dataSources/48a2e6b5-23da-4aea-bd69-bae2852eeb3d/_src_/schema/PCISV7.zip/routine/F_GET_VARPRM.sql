CREATE FUNCTION "F_GET_VARPRM" (V_APLNO in VARCHAR2) return number
as
--根据投保单号
--返回历次批改总共变化的保费
  V_PRM_VAR  number(20,2);
begin
V_PRM_VAR :=0;
 /* select sum(nvl(a.postrealprm,0)-(nvl(a.prerealprm,0))) into V_PRM_VAR from T_EDR a
  where  a.edrstatus in ('5','9') and a.aplno=V_APLNO;*/

   select sum(nvl(a.edraddprm,0)-(nvl(a.edrsubprm,0))) into V_PRM_VAR from T_EDR a
  where  a.edrstatus in ('5')
  /*and a.signdate<=to_date('20101219 00:00:00','YYYYMMDD HH24:MI:SS')*/
  and a.aplno=V_APLNO
  and a.edrtype<>'15';

return nvl(V_PRM_VAR,0);
exception
when others then
return 0;
end F_GET_VARPRM;









/
