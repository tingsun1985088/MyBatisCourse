CREATE function       GETMONTHTYPEFORITEM(ITEMCODE VARCHAR2)
  return VARCHAR deterministic as

  CURSOR curmonthtype IS
    SELECT c_dict_type_cde, c_dict_cde
      FROM t_item_adjunct
     WHERE c_item_no = ITEMCODE and
           c_dict_type_cde in('SFYB', 'SFJB', 'SFBN', 'SFNB');

  monthtype varchar2(10);
  type_cde  varchar2(50);
  dict_cde  varchar2(50);

  SFYB varchar2(10);
  SFJB varchar2(10);
  SFBN varchar2(10);
  SFNB varchar2(10);

begin

  OPEN curmonthtype;
  monthtype := '';
  LOOP
    FETCH curmonthtype
      into type_cde, dict_cde;
    EXIT WHEN curmonthtype%NOTFOUND;
    if (type_cde = 'SFYB' and dict_cde = '1') then
      SFYB := '1';
    end if;
    if (type_cde = 'SFJB' and dict_cde = '1') then
      SFJB := '1';
    end if;
    if (type_cde = 'SFBN' and dict_cde = '1') then
      SFBN := '1';
    end if;
    if (type_cde = 'SFNB' and dict_cde = '1') then
      SFNB := '1';
    end if;
  end loop;

  if SFYB = '1' then
    return '2';
  end if;

  if SFJB = '1' then
    return '3';
  end if;

  if SFBN = '1' then
    return '4';
  end if;

  if SFNB = '1' then
    return '5';
  end if;

  return '';

EXCEPTION
  WHEN OTHERS THEN
    RETURN '';

end GETMONTHTYPEFORITEM;

/
