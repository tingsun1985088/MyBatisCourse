CREATE FUNCTION "F_GET_APLNO_FROMEDR" (V_EDRNO varchar2)
return varchar2 is

V_APLNO varchar2(50);


begin

V_APLNO :='';

select  APLNO into V_APLNO from T_EDR a where a.EDRNO=V_EDRNO;

return V_APLNO;

exception when others then
return null;

end F_GET_APLNO_FROMEDR;









/
