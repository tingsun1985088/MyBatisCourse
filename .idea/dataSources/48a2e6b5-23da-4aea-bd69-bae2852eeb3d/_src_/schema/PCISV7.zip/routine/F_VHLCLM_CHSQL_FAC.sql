CREATE FUNCTION F_VHLCLM_CHSQL_FAC(VSQL   VARCHAR2,
                                        CRPTNO VARCHAR2,
                                        TASKID VARCHAR2,
                                        TASKTYPE VARCHAR2) RETURN VARCHAR2 IS



 v_sql      VARCHAR2 (2000);


BEGIN

  SELECT  REPLACE(VSQL, 'v_crptno', CRPTNO) INTO v_sql FROM dual ;
  SELECT  REPLACE(v_sql, 'v_ctaskid', TASKID) INTO v_sql FROM dual ;
  SELECT  REPLACE(v_sql, 'v_ctasktype', TASKTYPE) INTO v_sql FROM dual ;

  RETURN v_sql;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;
/
