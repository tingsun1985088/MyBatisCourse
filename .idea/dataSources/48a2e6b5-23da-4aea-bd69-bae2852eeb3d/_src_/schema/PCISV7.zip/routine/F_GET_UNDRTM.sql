CREATE FUNCTION "F_GET_UNDRTM" (V_APLNO in varchar2 )
return  date
as
--取保单批单的核保日期 保单的在T_PLCJUDGE 批单的在T_EDRJUDGE
--如果传进来的参数第１６位为Ｐ就说明是批单在T_EDRJUDGE　中查询,否则在保单中查

  V_UNDR_TM varchar2(30);

begin
  V_UNDR_TM :='';
  if(V_APLNO like '_______________P%') then

 select  max(a.judgedate) into V_UNDR_TM from T_EDRJUDGE a where a.EDRNO=V_APLNO--传进来的单号为批单号
and a.edrjudgeopn='1'--取核保通过的
;
 else

  select  max(a.judgedate) into V_UNDR_TM from T_PLCJUDGE a where a.Aplno=V_APLNO
and a.Plcjudgeopn='1'
;
  end if;
  return V_UNDR_TM;
exception
when others then
return null;
end F_GET_UNDRTM;









/
