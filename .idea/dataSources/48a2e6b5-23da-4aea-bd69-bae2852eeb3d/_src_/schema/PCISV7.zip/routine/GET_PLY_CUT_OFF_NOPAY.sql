CREATE FUNCTION "GET_PLY_CUT_OFF_NOPAY" (ply_no IN VARCHAR2)
  RETURN VARCHAR2 AS
  rcpt VARCHAR2(50) := NULL;
BEGIN
  --无赔款优待
  SELECT MAX(b.c_cnm)
    INTO rcpt
    FROM web_ply_prm_coef a, web_bas_comm_code b, web_ply_base base
   WHERE a.c_app_no = base.c_app_no
     AND base.c_app_typ = 'A'
     AND a.c_ago_clm_rec = b.c_cde
     AND a.c_ply_no = ply_no;
  RETURN rcpt;

EXCEPTION
  WHEN OTHERS THEN
    RETURN '-';
END;








/
