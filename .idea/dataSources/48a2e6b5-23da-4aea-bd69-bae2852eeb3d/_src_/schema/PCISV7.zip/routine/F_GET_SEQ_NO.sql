CREATE FUNCTION "F_GET_SEQ_NO" (V_APLNO varchar2,V_EDRNO varchar2, V_LBTCODE varchar2)
return number is
--根据投保单号、批单号和险别取序号
--如果批单号为空就是原保单的，否则是批单的
V_SEQ_NO number(4);

begin

V_SEQ_NO :=0;
--老系统的表
if (V_EDRNO is null ) then 
select SEQNO into V_SEQ_NO from

(
select a.Lbtcode Lbtcode
,row_number() over(PARTITION BY b.APLNO ORDER BY a.lbtcode) SEQNO
from T_LBTS a ,T_PLC b
where b.aplno=V_APLNO
and b.aplno=substrb(a.subjno,1,22)
and a.startdate=b.startdate
and (a.startdate,a.enddate) in (select min(startdate),min(enddate) from t_lbts
                                 where subjno=a.subjno
                                   and lbtcode=a.lbtcode
                                 )
and a.lbtstatus = '1'
) m
where m.LBTCODE=V_LBTCODE
;
else

select SEQNO into V_SEQ_NO from
(
select b.Lbtcode Lbtcode
,row_number() over(PARTITION BY a.APLNO ORDER BY b.lbtcode) SEQNO
from   T_EDR a left join (select m.lbtcode,m.subjno,m.lbtstatus,m.startdate, m.syscurrtime from  t_lbts m left join t_edrlbts n on
                             m.subjno=n.subjno and m.lbtcode=n.lbtcode AND N.EDRNO=V_EDRNO
                            where substrb(m.subjno,1,22)=V_APLNO
                             ) b   on b.subjno like a.aplno||'%'

where b.Syscurrtime<=a.Syscurrtime
and  (b.startdate, b.syscurrtime) = (select max(c.startdate), max(c.syscurrtime) from t_lbts c
                                 where
                                    substrb(c.subjno,1,22)=V_APLNO
                                   and c.lbtcode=b.lbtcode                                   
                                   and c.Syscurrtime<=a.Syscurrtime
                                 )
and b.lbtstatus in ('1','2')
and a.EDRSTATUS  in('5','9')
and a.aplno=V_APLNO
AND A.EDRNO=V_EDRNO
) m
where m.LBTCODE=V_LBTCODE
;
end if;

return V_SEQ_NO;

exception when others then
return 1;

end F_GET_SEQ_NO;









/
