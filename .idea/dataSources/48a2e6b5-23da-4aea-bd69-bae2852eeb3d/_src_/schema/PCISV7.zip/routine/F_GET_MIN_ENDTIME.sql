CREATE FUNCTION "F_GET_MIN_ENDTIME" (VSUBJNO IN VARCHAR2,VSUBJSTATUS IN VARCHAR2)
return DATE
AS
V_ENDDATE DATE;
begin
  select min(enddate)INTO V_ENDDATE from t_drivers n
    where n.subjno=VSUBJNO
          and n.subjstatus=VSUBJSTATUS;
  return(V_ENDDATE);
exception
when others then
return NULL;
end F_GET_MIN_ENDTIME;









/
