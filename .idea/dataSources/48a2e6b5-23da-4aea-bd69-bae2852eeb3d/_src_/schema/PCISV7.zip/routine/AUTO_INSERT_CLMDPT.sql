CREATE PROCEDURE AUTO_INSERT_CLMDPT

 IS

BEGIN

  /**********************意健险报案权限维护********************/
  INSERT INTO WEB_GRT_SUBSYS_PROD_MAP

    SELECT CONCAT('20160524', T.C_PROD_NO) AS C_PK_ID,
           T.C_PROD_NO,
           'CLAIM_CASU' AS C_SUBSYS_CDE,
           'ADMIN' AS C_CRT_CDE,
           SYSDATE AS T_CRT_CDE,
           'ADMIN' AS C_UPD_CDE,
           SYSDATE AS T_UPD_TM,
           '' AS C_TRANS_MRK,
           '' AS T_TRANS_TM

      FROM WEB_PRD_PROD T
     WHERE T.C_STATUS = '1'
       AND T.C_KIND_NO IN ('06', '21')
       AND T.C_PROD_NO NOT IN
           (SELECT S.C_PROD_NO
              FROM WEB_GRT_SUBSYS_PROD_MAP S
             WHERE S.C_SUBSYS_CDE = 'CLAIM_CASU');

  /**********************意健险报案权限维护********************/
  INSERT INTO WEB_GRT_SUBSYS_PROD_MAP

    SELECT CONCAT('20160524', T.C_PROD_NO) AS C_PK_ID,
           T.C_PROD_NO,
           'CLAIM_PROP' AS C_SUBSYS_CDE,
           'ADMIN' AS C_CRT_CDE,
           SYSDATE AS T_CRT_CDE,
           'ADMIN' AS C_UPD_CDE,
           SYSDATE AS T_UPD_TM,
           '' AS C_TRANS_MRK,
           '' AS T_TRANS_TM

      FROM WEB_PRD_PROD T
     WHERE T.C_STATUS = '1'
       AND T.C_KIND_NO <> '06'
       AND T.C_KIND_NO <> '03'
       AND T.C_KIND_NO <> '21'
       AND T.C_KIND_NO <> '31'
       AND T.C_PROD_NO NOT IN
           (SELECT S.C_PROD_NO
              FROM WEB_GRT_SUBSYS_PROD_MAP S
             WHERE S.C_SUBSYS_CDE = 'CLAIM_PROP');

  /******************企业财产险所有理赔机构**************/

  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_01') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '01' AS C_KIND_NO,
           '企业财产险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '01');

  /******************船舶险11所有理赔机构**************/
  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_11') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '11' AS C_KIND_NO,
           '船舶险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '11');

  /******************家庭财产险所有理赔机构**************/
  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_08') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '08' AS C_KIND_NO,
           '家庭财产险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '08');

  /******************货物运输险所有理赔机构**************/
  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_02') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '02' AS C_KIND_NO,
           '货物运输险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '02');

  /******************意健险险所有理赔机构**************/
  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_06') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '06' AS C_KIND_NO,
           '意健险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '06');
 /******************21所有理赔机构**************/
  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_21') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '21' AS C_KIND_NO,
           '意健险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '21');

  /******************工程险所有理赔机构**************/
  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_09') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '09' AS C_KIND_NO,
           '工程险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '09');

  /******************责任险险所有理赔机构**************/
  INSERT INTO WEB_ORG_DPT_MAP
    SELECT CONCAT(T.C_DPT_CDE, '_04') as c_dpt_map_id,
           T.C_DPT_CDE as c_dpt_cde,
           T.c_dpt_cnm as c_dpt_cnm,
           '04' AS C_KIND_NO,
           '责任险' AS C_KIND_CNM,
           T.C_DPT_CDE AS C_CLM_DPT_CDE,
           T.C_DPT_CNM AS C_CLM_DPT_CNM,
           '1' as c_is_valid,
           '' as c_rmk,
           '21' as c_crt_cde,
           sysdate as t_crt_tm,
           '21' as c_upd_cde,
           sysdate as t_upd_tm,
           '' as c_trans_mrd,
           '' as t_trans_tm

      FROM WEB_ORG_DPT T
     WHERE T.C_SIGN_DPT_MRK = '1'
       AND T.C_DPT_CDE NOT IN
           (SELECT C_DPT_CDE FROM WEB_ORG_DPT_MAP A WHERE A.C_KIND_NO = '04');

  /*****************************调度人维护******************************/
  DELETE FROM web_clm_dspt_member T
   WHERE T.ID not IN
         (select id
            from web_clm_dspt_member m, WEB_GRT_USR_ROLE a
           where a.c_opgrp_cde in( 'ROLE_00000175','ROLE_00000249')
             and m.C_SID = a.c_oper_id
             and m.dpt_cde = a.c_dpt_cde
             and m.C_PROD_NO IN (SELECT p.c_prod_no
                                   from Web_Prd_Prod p
                                  where (p.c_kind_no in

                                        (SELECT x.c_prod_no
                                            from web_grt_usr_prod x
                                           where x.c_oper_id = a.c_oper_id
                                             and x.c_dpt_cde = a.c_dpt_cde
                                             and x.c_prod_cat = '1') or
                                        P.c_prod_no in
                                        (SELECT x.c_prod_no
                                            from web_grt_usr_prod x
                                           where x.c_oper_id = a.c_oper_id
                                             and x.c_dpt_cde = a.c_dpt_cde
                                             and x.c_prod_cat = '0'))

                                 ));

  insert into web_clm_dspt_member
    select distinct nvl(d.c_province, '370000') as PROVINCE_CDE,
           nvl(d.c_city, '370600') AS CITY_CDE,
           o.c_oper_cnm as C_NME,
           o.c_oper_id as C_SID,
           '010001' AS C_TEL,
           d.c_dpt_cnm AS DPT_NME,
           CONCAT(t.c_prod_no,
                  concat('_' || o.c_oper_id, '_' || d.c_dpt_cde)) AS ID,
           nvl((select area.c_area_cnm
                 from web_bas_area area
                where area.c_type = '1'
                  and area.c_area_cde = d.c_province),
               '山东省') AS PROVINCE_NME,
           nvl（ (select area.c_area_cnm
                   from web_bas_area area
                  where area.c_type = '2'
                    and area.c_area_cde = d.c_city),
           '烟台市') AS CITY_NME, d.c_dpt_cde AS DPT_CDE, SYSDATE AS T_CT_TM, SYSDATE AS T_UP_TM, '0' AS C_STAT, '02000001' AS T_UPD_CDE, '21' AS T_CRT_CDE, t.c_prod_no AS C_PROD_NO, t.c_kind_no as c_kind_no, '' AS EMAIL_
      from WEB_GRT_USR_ROLE A,
           web_org_dpt      d,
           web_org_oper     o,
           web_prd_prod     t
     where a.c_opgrp_cde in( 'ROLE_00000175','ROLE_00000249')
       and o.c_oper_id = a.c_oper_id
       and o.C_IS_VALID = '1'
       and d.c_dpt_cde = a.c_dpt_cde
       and a.c_oper_id <> '02000001'
       and t.c_status = '1'
       and t.c_kind_no <> '31'
       and t.c_kind_no <> '21'
       and t.c_kind_no <> '03'
       and t.c_kind_no <> '06'
       and T.C_PROD_NO IN (SELECT p.c_prod_no
                             from Web_Prd_Prod p
                            where (p.c_kind_no in

                                  (SELECT x.c_prod_no
                                      from web_grt_usr_prod x
                                     where x.c_oper_id = a.c_oper_id
                                       and x.c_dpt_cde = a.c_dpt_cde
                                       and x.c_prod_cat = '1') or
                                  P.c_prod_no in
                                  (SELECT x.c_prod_no
                                      from web_grt_usr_prod x
                                     where x.c_oper_id = a.c_oper_id
                                       and x.c_dpt_cde = a.c_dpt_cde
                                       and x.c_prod_cat = '0'))

                           )

       and t.c_prod_no not in
           (select m.c_prod_no
              from web_clm_dspt_member m
             where m.C_SID = a.c_oper_id
               and m.dpt_cde = a.c_dpt_cde);

  /***********************************查勘人维护********************/

  DELETE FROM web_clm_srvy_member T
   WHERE T.ID not IN
         (select id
            from web_clm_srvy_member m, WEB_GRT_USR_ROLE a
           where a.c_opgrp_cde IN ( 'ROLE_00000166', 'ROLE_00000248')
             and m.C_SID = a.c_oper_id
             and m.dpt_cde = a.c_dpt_cde
             and m.C_PROD_NO IN (SELECT p.c_prod_no
                                   from Web_Prd_Prod p
                                  where (p.c_kind_no in

                                        (SELECT x.c_prod_no
                                            from web_grt_usr_prod x
                                           where x.c_oper_id = a.c_oper_id
                                             and x.c_dpt_cde = a.c_dpt_cde
                                             and x.c_prod_cat = '1') or
                                        P.c_prod_no in
                                        (SELECT x.c_prod_no
                                            from web_grt_usr_prod x
                                           where x.c_oper_id = a.c_oper_id
                                             and x.c_dpt_cde = a.c_dpt_cde
                                             and x.c_prod_cat = '0'))

                                 ));

  insert into web_clm_srvy_member
    select distinct nvl(d.c_province, '370000') as PROVINCE_CDE,
           nvl(d.c_city, '370600') AS CITY_CDE,
           o.c_oper_cnm as C_NME,
           o.c_oper_id as C_SID,
           '010001' AS C_TEL,
           '1' AS C_JOB,
           d.c_dpt_cnm AS DPT_NME,
           CONCAT(t.c_prod_no,
                  concat('_' || o.c_oper_id, '_' || d.c_dpt_cde)) AS ID,
           nvl((select area.c_area_cnm
                 from web_bas_area area
                where area.c_type = '1'
                  and area.c_area_cde = d.c_province),
               '山东省') AS PROVINCE_NME,
           nvl（ (select area.c_area_cnm
                   from web_bas_area area
                  where area.c_type = '2'
                    and area.c_area_cde = d.c_city),
           '烟台市') AS CITY_NME, d.c_dpt_cde AS DPT_CDE, '0' AS C_STAT, SYSDATE AS T_CT_TM, SYSDATE AS T_UP_TM, '02000001' AS T_UPD_CDE, '21' AS T_CRT_CDE, t.c_prod_no AS C_PROD_NO, '' as EMAIL_, t.c_kind_no as c_kind_no
      from WEB_GRT_USR_ROLE A,
           web_org_dpt      d,
           web_org_oper     o,
           web_prd_prod     t
     where a.c_opgrp_cde  IN ( 'ROLE_00000166', 'ROLE_00000248')
       and o.c_oper_id = a.c_oper_id
       and o.C_IS_VALID = '1'
       and d.c_dpt_cde = a.c_dpt_cde
       and a.c_oper_id <> '02000001'
       and t.c_status = '1'
       and t.c_kind_no <> '31'
       and t.c_kind_no <> '21'
       and t.c_kind_no <> '03'
       and t.c_kind_no <> '06'
       and T.C_PROD_NO IN (SELECT p.c_prod_no
                             from Web_Prd_Prod p
                            where (p.c_kind_no in

                                  (SELECT x.c_prod_no
                                      from web_grt_usr_prod x
                                     where x.c_oper_id = a.c_oper_id
                                       and x.c_dpt_cde = a.c_dpt_cde
                                       and x.c_prod_cat = '1') or
                                  P.c_prod_no in
                                  (SELECT x.c_prod_no
                                      from web_grt_usr_prod x
                                     where x.c_oper_id = a.c_oper_id
                                       and x.c_dpt_cde = a.c_dpt_cde
                                       and x.c_prod_cat = '0'))

                           )

       and t.c_prod_no not in
           (select m.c_prod_no
              from web_clm_srvy_member m
             where m.C_SID = a.c_oper_id
               and m.dpt_cde = a.c_dpt_cde);

  /*****************立案一级人员维护*******************/

  INSERT INTO WEB_CLM_AUTH
    SELECT
     distinct
     CONCAT(t.c_prod_no, CONCAT(c.C_DPT_CDE, '151')), --主键 机构+类型+级别
     c.C_DPT_CDE AS C_DPT_CDE, --机构
     T.C_KIND_NO,
     T.C_PROD_NO,
     '15' AS C_LEV_TYP,
     '1' AS C_LEV_CDE,
     '立案级别十' AS C_LEV_NME,
     '1' AS C_FLG,
     '21' AS C_CRT_CDE,
     SYSDATE AS T_CRT_TM,
     '02000001' AS C_UPD_CDE,
     SYSDATE AS T_UPD_TM,
     '' AS C_TRANS_MRK,
     '' AS T_TRANS_TM

      FROM WEB_PRD_PROD T, web_org_dpt c
     WHERE T.C_KIND_NO in ('01', '02', '04', '08', '09', '11') --产品大类
       AND c.c_dpt_cde in (select b.C_DPT_CDE
                             from WEB_GRT_USR_ROLE b
                            where B.c_opgrp_cde IN ( 'ROLE_00000168' , 'ROLE_00000247')
                              and B.c_dpt_cde <> '10')
       AND T.C_STATUS = '1'
       AND T.C_PROD_NO NOT IN (SELECT A.C_PROD_NO
                                 FROM WEB_CLM_AUTH A
                                WHERE A.C_DPT_CDE = c.C_DPT_CDE --机构
                                  AND A.C_LEV_TYP = '15'
                                  AND A.C_LEV_CDE = '1');
  /****立案金额维护 *********************/

  INSERT INTO WEB_CLM_AUTH_FACTOR

    SELECT T.C_AUTH_ID,
           T.C_AUTH_ID,
           '15' AS C_LEV_TYP,
           '0' AS N_LOW_AMT,
           (SELECT A.N_LOW_AMT
              FROM WEB_CLM_AUTH_FACTOR A, WEB_CLM_AUTH B
             where B.C_AUTH_ID = T.C_AUTH_ID
               AND a.c_auth_id = (SELECT p.c_auth_id
                                    from WEB_CLM_AUTH p
                                   where p.c_prod_no = B.C_PROD_NO
                                     AND P.C_LEV_TYP = '15'
                                     AND P.C_LEV_CDE = '5'
                                     AND P.C_DPT_CDE = '10')) AS N_HIG_AMT,
           '' AS N_SIG_LOW_AMT,
           '' AS N_SIG_HIG_AMT,
           '' AS C_CASE_TYP,
           '' AS C_LOS_TYP,
           '' AS C_OTH_TYP,
           '1' AS C_FLG,
           '21' AS C_CRT_CDE,
           SYSDATE AS C_CRT_TM,
           '02000001' AS C_UPD_CDE,
           SYSDATE AS C_UPD_TM,
           '' AS C_TRANS_MRK,
           '' AS T_TRANS_TM
      FROM WEB_CLM_AUTH T
     WHERE T.C_LEV_TYP = '15'
       AND T.C_LEV_CDE = '1'
       AND T.C_FLG = '1'
       AND T.C_AUTH_ID NOT IN (SELECT C_AUTH_ID
                                 FROM WEB_CLM_AUTH_FACTOR
                                WHERE C_LEV_TYP = '15'
                                  AND C_LEV_CDE = '1'
                                  AND C_FLG = '1');

  /****************人猿维护*********************/
  INSERT INTO WEB_CLM_USER_AUTH
    SELECT distinct CONCAT(T.C_AUTH_ID, A.C_OPER_ID) AS C_USER_AUTH_ID,
           T.C_AUTH_ID,
           A.C_OPER_ID AS C_OPER_ID,
           T.C_DPT_CDE,
           T.C_LEV_TYP,
           T.C_LEV_CDE,
           '1' AS C_FLG,
           '21' AS C_CRT_CDE,
           SYSDATE AS T_CRT_TM,
           '02000001' AS C_UPD_CDE,
           SYSDATE AS C_UPD_TM,
           '' AS C_TRANS_MRK,
           '' AS T_TRANS_TM

      FROM WEB_CLM_AUTH T, WEB_GRT_USR_ROLE A
     WHERE T.C_LEV_TYP = '15'
       AND T.C_LEV_CDE = '1'
       AND T.C_FLG = '1'
       AND (T.c_prod_no like '01%' or T.c_prod_no like '02%' or
           T.c_prod_no like '04%' or T.c_prod_no like '08%' or
           T.c_prod_no like '09%' or T.c_prod_no like '11%') --, '02', '04', '08', '09', '11') --产品大类
       AND A.C_DPT_CDE = T.C_DPT_CDE
       AND A.c_opgrp_cde IN ( 'ROLE_00000168' , 'ROLE_00000247')
       and A.c_dpt_cde <> '10'

       AND T.C_PROD_NO NOT IN (SELECT C_PROD_NO
                                 FROM WEB_CLM_USER_AUTH c, WEB_CLM_AUTH X
                                WHERE c.C_LEV_TYP = '15'
                                  AND X.C_AUTH_ID = C.C_AUTH_ID
                                  AND X.C_PROD_NO = T.C_PROD_NO
                                  and x.c_dpt_cde = t.c_dpt_cde
                                  AND C.C_OPER_ID = a.c_oper_id
                                  AND c.C_LEV_CDE = '1'
                                  AND c.C_FLG = '1'

                               )

    ;

  COMMIT;

END;

/
