CREATE FUNCTION "F_GET_MAX_ENDTIME" (VSUBJNO IN VARCHAR2,VSUBJSTATUS IN VARCHAR2)
return DATE
AS
V_ENDDATE DATE;
begin
  select max(enddate)INTO V_ENDDATE from t_drivers n
    where n.subjno=VSUBJNO
          and n.subjstatus=VSUBJSTATUS;
  return(V_ENDDATE);
exception
when others then
return NULL;
end F_GET_MAX_ENDTIME;









/
