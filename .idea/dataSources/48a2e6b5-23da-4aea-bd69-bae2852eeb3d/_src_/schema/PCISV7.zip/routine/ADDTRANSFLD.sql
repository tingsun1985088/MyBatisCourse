CREATE PROCEDURE "ADDTRANSFLD" IS
	v_task_start_date		date                    ;
	v_task_end_date			date                    ;
	v_num					number                  ;
	v_table_name			VARCHAR2(1000)			;
	v_sql_code				number                  ;
	v_sql_msg				VARCHAR2(4000) := ''    ; --sql????

	--??(?ORACLE???????????,????????SQL??)
	CURSOR cur_user_tables IS
		select 'ALTER TABLE '||table_name||' ADD C_TRANS_MRK CHAR(1) ADD T_TRANS_TM DATE;'
		from user_tables
		where table_name like 'WEB%';
BEGIN
	v_num := 0;

	--???????
	v_sql_msg := 'step 0.1: ???????';
	DELETE FROM load_his_log
		WHERE upper(sys) = upper('PCISV6')
		AND upper(jobname) = upper('ADDTRANSFLD');
	COMMIT;

	--?????????????
	SELECT SYSDATE INTO v_task_start_date FROM dual;
	SELECT SYSDATE INTO v_task_end_date FROM dual;

	--?????????????SQL??
	v_sql_msg := 'step 0.2: ??????SQL';
	OPEN cur_user_tables;
		LOOP
			FETCH cur_user_tables INTO v_table_name;
			EXIT WHEN cur_user_tables%NOTFOUND;

			EXECUTE IMMEDIATE v_table_name;
		END LOOP;
	CLOSE cur_user_tables;

	COMMIT;

	EXCEPTION
		WHEN OTHERS THEN
			v_sql_code := SQLCODE;
			v_sql_msg  := v_sql_msg || ' ' /*|| dbms_utility.format_error_backtrace*/ ||
				' : ' || SQLERRM;
		--??????
		SELECT SYSDATE INTO v_task_end_date FROM dual;
		ROLLBACK;
		INSERT INTO LOAD_HIS_LOG (
			SYS
			,JOBNAME
			,START_DATE
			,END_DATE
			,RUN_DATE
			,SQL_CODE
			,SQL_STATE
		) VALUES (
			'PCISV6'
			,'ADDTRANSFLD'
			,v_task_start_date
			,v_task_end_date
			,to_char((v_task_end_date - v_task_start_date) * 86400)
			,v_sql_code
			,v_sql_msg
		);
		COMMIT;

END AddTransFld;










/
