CREATE FUNCTION test_function(p tab_varchar2) RETURN CLOB IS
       l_result CLOB;
    BEGIN
       FOR cc IN (SELECT column_value FROM TABLE(p) ORDER BY column_value) LOOP
          l_result := l_result ||' '|| cc.column_value;
       END LOOP;
       return l_result;
    END;
/
