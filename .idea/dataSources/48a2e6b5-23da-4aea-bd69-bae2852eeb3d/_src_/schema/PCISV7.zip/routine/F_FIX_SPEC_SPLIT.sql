CREATE function f_fix_Spec_Split(cAppNo in varchar2,splitNo in number,fixSpecLength number) return varchar2 as
   fixSpecNode  varchar2(3999); --总特约
    begin

       SELECT nvl(LISTAGG(con, '') WITHIN GROUP(ORDER BY n_seq_no,rownum),' ') AS  fixSpecNode into fixSpecNode
        from (
             select rownum||'、'||c_spec_content||'；' con,n_seq_no from (
              select t.c_spec_content , t.n_seq_no from web_Ply_Fix_Spec t where t.c_app_no = cAppNo
              order by  t.n_seq_no
          )
      );
      --如果特约长度超出规定长度，则裁掉多余部分
      if length(fixSpecNode) > fixSpecLength  then  --600
           fixSpecNode := substr(fixSpecNode, 0,fixSpecLength)||'……剩余特约请见特约清单';
      end if;
    fixSpecNode :=replace(replace(fixSpecNode,CHR(10)),CHR(13));
    return fixSpecNode;
    end f_fix_Spec_Split;
/
