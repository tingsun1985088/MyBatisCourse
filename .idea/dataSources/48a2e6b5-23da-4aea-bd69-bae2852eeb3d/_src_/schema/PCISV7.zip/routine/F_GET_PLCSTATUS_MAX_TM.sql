CREATE FUNCTION "F_GET_PLCSTATUS_MAX_TM" (VAPLNO in varchar2)
return  number
as
v_syscurrtime number;
begin
select max(syscurrtime) into v_syscurrtime from t_plcstatus a
 where a.aplno=VAPLNO and a.poststatus='5';

  return(v_syscurrtime);
  exception
when others then
return NULL;
end F_GET_PLCSTATUS_MAX_TM;









/
