CREATE PROCEDURE CHECK_AUTO_UDR(C_APP_NO IN VARCHAR2,
                                           FLAG     OUT VARCHAR2,
                                           PROMPT   OUT VARCHAR2) IS
  --FLAG 返回状态 : 0：返回修改 1：转人工 2：自核通过
  --附：原FLAG 自核标志 0：自核通过 1：转人工核保 2：自核退回
  --变量
  V_AUTO_NOS   VARCHAR2(4000); --规则序号列表
  V_APP_NO     VARCHAR2(30) := C_APP_NO; --申请单号
  V_FLAG       VARCHAR2(30);
  V_COUNT      NUMBER;
  V_AUTO_FLAG  VARCHAR2(30);
  SUB_AUTO_NOS VARCHAR2(4000); --减少的规则序号列表

  TYPE MYCURSOR IS REF CURSOR; --定义游标类型
  CUR   MYCURSOR; --定义游标
  V_SQL VARCHAR2(4000);

  V_RULE_SQL WEB_BAS_AUTO_CED.C_RULE_SQL%TYPE;
  V_RULE_TYP WEB_BAS_AUTO_CED.C_RULE_TYP%TYPE;
  V_AUTO_NO  WEB_BAS_AUTO_CED.C_AUTO_NO%TYPE;
  V_PROMPT   WEB_BAS_AUTO_CED.C_PROMPT%TYPE;


  V_RULE_SQL_DUE WEB_BAS_AUTO_DUE.C_RULE_SQL%TYPE;
  V_AUTO_NO_DUE  WEB_BAS_AUTO_DUE.C_AUTO_NOS%TYPE;
  V_STATUS_DUE   WEB_BAS_AUTO_DUE.C_STATUS%TYPE;

  --从自核规则主档表匹配该申请单需要执行的自核规则序号(变更主档表条件字段时须修改下面脚本)
  CURSOR AUTO_DUE_INFO IS
  --通用库
    SELECT DUE.C_AUTO_NOS,
           REPLACE(DUE.C_RULE_SQL, '#APPNO#', V_APP_NO),
           DUE.C_STATUS
      FROM WEB_BAS_AUTO_DUE DUE
     WHERE DUE.C_PROD_NO IS NULL
       AND DUE.C_USAGE_CDE IS NULL
       AND DUE.C_BSNS_TYP IS NULL
       AND DUE.C_FLEET_MRK IS NULL
       AND DUE.C_APP_TYP IS NULL
       AND DUE.C_DPT_CDE IS NULL
       AND DUE.C_RESV_TXT1 IS NULL
       AND DUE.C_RESV_TXT2 IS NULL
       AND DUE.C_RESV_TXT3 IS NULL
       AND DUE.C_RESV_TXT4 IS NULL
       AND DUE.C_RESV_TXT5 IS NULL
       AND DUE.C_RESV_TXT6 IS NULL
       AND DUE.C_RESV_TXT7 IS NULL
       AND DUE.C_RESV_TXT8 IS NULL
       AND DUE.C_RESV_TXT9 IS NULL
       AND DUE.C_RESV_TXT10 IS NULL
    --产品库
    UNION ALL
    SELECT DUE.C_AUTO_NOS,
           REPLACE(DUE.C_RULE_SQL, '#APPNO#', C_APP_NO),
           DUE.C_STATUS
      FROM WEB_BAS_AUTO_DUE DUE, WEB_APP_BASE BASE
     WHERE BASE.C_APP_NO = V_APP_NO
       AND DUE.C_PROD_NO = BASE.C_PROD_NO
       AND DUE.C_USAGE_CDE IS NULL
       AND DUE.C_BSNS_TYP IS NULL
       AND DUE.C_FLEET_MRK IS NULL
       AND DUE.C_APP_TYP IS NULL
       AND DUE.C_DPT_CDE IS NULL
       AND DUE.C_RESV_TXT1 IS NULL
       AND DUE.C_RESV_TXT2 IS NULL
       AND DUE.C_RESV_TXT3 IS NULL
       AND DUE.C_RESV_TXT4 IS NULL
       AND DUE.C_RESV_TXT5 IS NULL
       AND DUE.C_RESV_TXT6 IS NULL
       AND DUE.C_RESV_TXT7 IS NULL
       AND DUE.C_RESV_TXT8 IS NULL
       AND DUE.C_RESV_TXT9 IS NULL
       AND DUE.C_RESV_TXT10 IS NULL
    --机构库
    UNION ALL
    SELECT DUE.C_AUTO_NOS,
           REPLACE(DUE.C_RULE_SQL, '#APPNO#', C_APP_NO),
           DUE.C_STATUS
      FROM WEB_BAS_AUTO_DUE DUE, WEB_APP_BASE BASE
     WHERE BASE.C_APP_NO = V_APP_NO
       AND DUE.C_PROD_NO IS NULL
       AND DUE.C_USAGE_CDE IS NULL
       AND DUE.C_BSNS_TYP IS NULL
       AND DUE.C_FLEET_MRK IS NULL
       AND DUE.C_APP_TYP IS NULL
       AND DUE.C_DPT_CDE IS NOT NULL
          --AND BASE.C_DPT_CDE LIKE DUE.C_DPT_CDE || '%'
       AND (DUE.C_DPT_CDE IN
           (select *
               from table(splitstr((SELECT A.C_DPT_REL_CDE
                                     FROM WEB_ORG_DPT A
                                    WHERE A.C_DPT_CDE = BASE.C_DPT_CDE
                                      AND A.C_IS_VALID = '1'),
                                   ';'))) or
           DUE.C_DPT_CDE = BASE.C_DPT_CDE)
       AND DUE.C_RESV_TXT1 IS NULL
       AND DUE.C_RESV_TXT2 IS NULL
       AND DUE.C_RESV_TXT3 IS NULL
       AND DUE.C_RESV_TXT4 IS NULL
       AND DUE.C_RESV_TXT5 IS NULL
       AND DUE.C_RESV_TXT6 IS NULL
       AND DUE.C_RESV_TXT7 IS NULL
       AND DUE.C_RESV_TXT8 IS NULL
       AND DUE.C_RESV_TXT9 IS NULL
       AND DUE.C_RESV_TXT10 IS NULL
    --申请单类型库
    UNION ALL
    SELECT DUE.C_AUTO_NOS,
           REPLACE(DUE.C_RULE_SQL, '#APPNO#', C_APP_NO),
           DUE.C_STATUS
      FROM WEB_BAS_AUTO_DUE DUE, WEB_APP_BASE BASE
     WHERE BASE.C_APP_NO = V_APP_NO
       AND DUE.C_PROD_NO IS NULL
       AND DUE.C_USAGE_CDE IS NULL
       AND DUE.C_BSNS_TYP IS NULL
       AND DUE.C_FLEET_MRK IS NULL
       AND DUE.C_APP_TYP = BASE.C_APP_TYP
       AND DUE.C_DPT_CDE IS NULL
       AND DUE.C_RESV_TXT1 IS NULL
       AND DUE.C_RESV_TXT2 IS NULL
       AND DUE.C_RESV_TXT3 IS NULL
       AND DUE.C_RESV_TXT4 IS NULL
       AND DUE.C_RESV_TXT5 IS NULL
       AND DUE.C_RESV_TXT6 IS NULL
       AND DUE.C_RESV_TXT7 IS NULL
       AND DUE.C_RESV_TXT8 IS NULL
       AND DUE.C_RESV_TXT9 IS NULL
       AND DUE.C_RESV_TXT10 IS NULL
    --使用性质库
    UNION ALL
    SELECT DUE.C_AUTO_NOS,
           REPLACE(DUE.C_RULE_SQL, '#APPNO#', C_APP_NO),
           DUE.C_STATUS
      FROM WEB_BAS_AUTO_DUE DUE, WEB_APP_VHL VHL
     WHERE VHL.C_APP_NO = V_APP_NO
       AND DUE.C_PROD_NO IS NULL
       AND DUE.C_USAGE_CDE = VHL.C_USAGE_CDE
       AND DUE.C_BSNS_TYP IS NULL
       AND DUE.C_FLEET_MRK IS NULL
       AND DUE.C_APP_TYP IS NULL
       AND DUE.C_DPT_CDE IS NULL
       AND DUE.C_RESV_TXT1 IS NULL
       AND DUE.C_RESV_TXT2 IS NULL
       AND DUE.C_RESV_TXT3 IS NULL
       AND DUE.C_RESV_TXT4 IS NULL
       AND DUE.C_RESV_TXT5 IS NULL
       AND DUE.C_RESV_TXT6 IS NULL
       AND DUE.C_RESV_TXT7 IS NULL
       AND DUE.C_RESV_TXT8 IS NULL
       AND DUE.C_RESV_TXT9 IS NULL
       AND DUE.C_RESV_TXT10 IS NULL
    --业务来源库
    UNION ALL
    SELECT DUE.C_AUTO_NOS,
           REPLACE(DUE.C_RULE_SQL, '#APPNO#', C_APP_NO),
           DUE.C_STATUS
      FROM WEB_BAS_AUTO_DUE DUE, WEB_APP_BASE BASE
     WHERE BASE.C_APP_NO = V_APP_NO
       AND DUE.C_PROD_NO IS NULL
       AND DUE.C_USAGE_CDE IS NULL
       AND DUE.C_BSNS_TYP = BASE.C_BSNS_TYP
       AND DUE.C_FLEET_MRK IS NULL
       AND DUE.C_APP_TYP IS NULL
       AND DUE.C_DPT_CDE IS NULL
       AND DUE.C_RESV_TXT1 IS NULL
       AND DUE.C_RESV_TXT2 IS NULL
       AND DUE.C_RESV_TXT3 IS NULL
       AND DUE.C_RESV_TXT4 IS NULL
       AND DUE.C_RESV_TXT5 IS NULL
       AND DUE.C_RESV_TXT6 IS NULL
       AND DUE.C_RESV_TXT7 IS NULL
       AND DUE.C_RESV_TXT8 IS NULL
       AND DUE.C_RESV_TXT9 IS NULL
       AND DUE.C_RESV_TXT10 IS NULL
    --团单库
    UNION ALL
    SELECT DUE.C_AUTO_NOS,
           REPLACE(DUE.C_RULE_SQL, '#APPNO#', C_APP_NO),
           DUE.C_STATUS
      FROM WEB_BAS_AUTO_DUE DUE, WEB_APP_VHL VHL
     WHERE VHL.C_APP_NO = V_APP_NO
       AND DUE.C_PROD_NO IS NULL
       AND DUE.C_USAGE_CDE IS NULL
       AND DUE.C_BSNS_TYP IS NULL
       AND DUE.C_FLEET_MRK = VHL.C_FLEET_MRK
       AND DUE.C_APP_TYP IS NULL
       AND DUE.C_DPT_CDE IS NULL
       AND DUE.C_RESV_TXT1 IS NULL
       AND DUE.C_RESV_TXT2 IS NULL
       AND DUE.C_RESV_TXT3 IS NULL
       AND DUE.C_RESV_TXT4 IS NULL
       AND DUE.C_RESV_TXT5 IS NULL
       AND DUE.C_RESV_TXT6 IS NULL
       AND DUE.C_RESV_TXT7 IS NULL
       AND DUE.C_RESV_TXT8 IS NULL
       AND DUE.C_RESV_TXT9 IS NULL
       AND DUE.C_RESV_TXT10 IS NULL;

BEGIN
  IF C_APP_NO IS NULL THEN
    FLAG   := '0'; --0：返回修改
    PROMPT := '申请单号不能为空';
  ELSE
    BEGIN
      --查询申请单是否有个性自核设置，有数据的话直接使用该设置
      SELECT decode(C_RULE_TYP,'0','2','1'), C_UNDR_OPN   --开关表C_RULE_TYP ： 0 自核通过，1 转人工
        INTO FLAG, PROMPT --FLAG 返回状态 : 1：转人工 2：自核通过
        FROM WEB_BAS_AUTO_IND IND
       WHERE IND.C_APP_NO = V_APP_NO
         AND C_RULE_TYP IS NOT NULL;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --没有个性自核设置，走自核规则匹配
        BEGIN
      OPEN AUTO_DUE_INFO;
          LOOP
          FETCH AUTO_DUE_INFO
            INTO V_AUTO_NO_DUE, V_RULE_SQL_DUE, V_STATUS_DUE;
          EXIT WHEN AUTO_DUE_INFO%NOTFOUND;
              BEGIN
                --执行规则，V_FLAG字段没有意义，用于触发NO_DATA_FOUND异常
                EXECUTE IMMEDIATE V_RULE_SQL_DUE
                INTO V_FLAG;
                --组装增加或减少的规则序号,RemoveSameStr方法是删除重复序号
                IF V_STATUS_DUE = '0' THEN   --0：增加  1：减少
                   V_AUTO_NOS := RemoveSameStr(V_AUTO_NOS || ',' || V_AUTO_NO_DUE);
                ELSIF V_STATUS_DUE = '1' THEN
                   SUB_AUTO_NOS := RemoveSameStr(SUB_AUTO_NOS || ',' ||V_AUTO_NO_DUE);
                END IF;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
              END;
          END LOOP;

          --标志置为转人工核保，用于规则明细表查询数据为空时
          FLAG   := '1'; --FLAG 返回状态 : 0：返回修改 1：转人工 2：自核通过
          PROMPT := '没有匹配到自核规则';

          IF V_AUTO_NOS IS NOT NULL THEN
              V_COUNT := 0;
              --（修改后）C_RULE_TYP 0：返回修改 1：转人工 2：自核通过
              --查询出需要执行的自核规则，执行顺序：先执行自核退回规则，再执行自核转人工规则，再执行自核通过规则
              --并把申请号组装到规则脚本中
              --注意#C_AUTO_NO#的组装
              IF SUB_AUTO_NOS IS NULL THEN
                V_SQL := 'SELECT REPLACE(C_RULE_SQL, ''#APPNO#'', ''' ||
                     V_APP_NO || ''') C_RULE_SQL,
                     C_AUTO_NO,
                     C_PROMPT,
                     C_RULE_TYP
                  FROM WEB_BAS_AUTO_CED
                 WHERE C_AUTO_NO IN (' || V_AUTO_NOS || ')
                   AND C_STATUS = ''1''
                 ORDER BY C_RULE_TYP ASC';
              ELSE
                V_SQL := 'SELECT REPLACE(C_RULE_SQL, ''#APPNO#'', ''' ||
                     V_APP_NO || ''') C_RULE_SQL,
                     C_AUTO_NO,
                     C_PROMPT,
                     C_RULE_TYP
                  FROM WEB_BAS_AUTO_CED
                 WHERE C_AUTO_NO IN (' || V_AUTO_NOS ||
                     ') AND C_AUTO_NO NOT IN (' || SUB_AUTO_NOS || ')
                   AND C_STATUS = ''1''
                 ORDER BY C_RULE_TYP ASC'; --（修改后）C_RULE_TYP 0：返回修改 1：转人工 2：自核通过
              END IF;

              --循环每一条自核规则
              OPEN CUR FOR V_SQL;
                LOOP
                    FETCH CUR
                    INTO V_RULE_SQL, V_AUTO_NO, V_PROMPT, V_RULE_TYP;   --（修改后）C_RULE_TYP 0：返回修改 1：转人工 2：自核通过
                    exit when CUR%notfound;

                    --初次进入循环，默认自核通过
                    IF V_COUNT = 0 THEN
                    FLAG   := '2';  --FLAG 返回状态 : 0：返回修改 1：转人工 2：自核通过
                    PROMPT := '';
                    END IF;


                    V_COUNT := V_COUNT + 1;

                    BEGIN

                        --如果自核退回规则或转人工核保规则匹配通过，则中止循环
                        --第一轮执行“C_RULE_TYP 0：返回修改”规则，如果规则触发，那么FLAG=0，则循环Loop到执行第二类“1：转人工”规则时，停止存过，返回【返回修改标志、意见】
                        --第一轮规则未触发，执行第二轮“C_RULE_TYP 1：转人工”规则，如果规则触发，那么FLAG=1，则循环Loop到执行第三类“2：自核通过”规则时，停止存过，返回【转人工、意见】
                        --第一轮、第二轮规则都未触发，执行第三轮“2：自核通过”规则，如果规则触发，那么FLAG=1，直到执行完所有“2：自核通过”规则，返回【转人工、意见】
                        IF FLAG <> '2' AND V_RULE_TYP <> FLAG THEN
                          EXIT;
                        END IF;

                        --执行规则，V_FLAG字段没有意义，用于触发NO_DATA_FOUND异常
                        EXECUTE IMMEDIATE V_RULE_SQL
                          INTO V_FLAG;
                              --两套规则（第一套规则执行功能处）
                              --    如果是返回修改类和转人工类的规则，查询不到表示规则通过；查询到表示规则触发，返回修改或转人工。
                              --    如果是自核通过类规则，查询到表示规则通过；查询不到表示规则触发，转人工。

                              --自核退回规则、转人工核保规则匹配通过
                              IF V_RULE_TYP <> '2' THEN  --C_RULE_TYP 0：返回修改 1：转人工 2：自核通过
                                FLAG := V_RULE_TYP;
                                BEGIN
                                --拼装不通过原因
                                PROMPT := PROMPT || V_AUTO_NO || ' ' || V_PROMPT || '；';
                                EXCEPTION
                                --如果拼装字符串过长，中止循环(测试最长为1000个中文字符)
                                WHEN VALUE_ERROR THEN
                                  EXIT;
                                END;
                              END IF;

                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                                --两套规则（第二套规则执行功能处）
                                --    如果是返回修改类和转人工类的规则，查询不到表示规则通过；查询到表示规则触发，返回修改或转人工。
                                --    如果是自核通过类规则，查询到表示规则通过；查询不到表示规则触发，转人工。

                                --自核通过的规则匹配没成功，则记录不通过原因，状态置为“转人工核保”
                                IF V_RULE_TYP = '2' THEN   --C_RULE_TYP 0：返回修改 1：转人工 2：自核通过
                                V_AUTO_FLAG := '1';
                                BEGIN
                                  --拼装不通过原因
                                  PROMPT := PROMPT || V_AUTO_NO || ' ' || V_PROMPT || '；';
                                EXCEPTION
                                  --如果拼装字符串过长，中止循环(测试最长为1000个中文字符)
                                  WHEN VALUE_ERROR THEN
                                  EXIT;
                                END;
                                END IF;
                    END;
                END LOOP;

              --第一轮、第二轮规则都未触发，执行第三轮“2：自核通过”规则，如果规则触发，那么FLAG=1，直到执行完所有“2：自核通过”规则，返回【转人工、意见】
              IF V_AUTO_FLAG IS NOT NULL THEN
                FLAG := V_AUTO_FLAG;
              END IF;

          END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --没有匹配到规则主档表WEB_BAS_AUTO_DUE
          FLAG   := '1'; --FLAG 返回状态 : 0：返回修改 1：转人工 2：自核通过
          PROMPT := '没有匹配到自核规则';
        END;
    END;
  END IF;
END;
/
