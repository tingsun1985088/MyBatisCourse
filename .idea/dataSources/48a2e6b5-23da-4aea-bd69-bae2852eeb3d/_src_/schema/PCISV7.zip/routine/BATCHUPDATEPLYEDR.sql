CREATE procedure BatchUpdatePlyEdr is
 v_app_no         varchar2(30);
 v_usage_cde      varchar2(30);
 v_vhl_typ        varchar2(30);

  type t_rd_vhl is record(id number,
                      c_app_no varchar2(50),c_usage_cde varchar2(20),c_vhl_typ varchar2(20),
                      c_edr_type varchar2(10),c_salegrp_cde varchar2(10),c_edr_rsn varchar2(50),
                      c_bsns_typ varchar2(10));
  type t_tb_vhl is table of t_rd_vhl index by binary_integer;
  v_tb_vhl t_tb_vhl;
  
  type t_rd_novhl is record(id number,c_app_no varchar2(50),c_edr_type varchar2(10),
                            c_salegrp_cde varchar2(10),c_edr_rsn varchar2(50),
                            c_bsns_typ varchar2(10));
  type t_tb_novhl is table of t_rd_novhl index by binary_integer;
  v_tb_novhl t_tb_novhl;

 cursor vhl is
  select rownum,a.c_app_no,b.c_usage_cde,b.c_vhl_typ,a.c_edr_type,
         a.c_salegrp_cde,a.c_edr_rsn_bundle_cde as c_edr_rsn,a.c_bsns_typ
  from web_ply_base a ,web_ply_vhl b
  where a.c_prod_no like '03%'
    and a.c_app_no = b.c_app_no
    and a.t_crt_tm <= to_date('2013-07-31 23:59:59','yyyy-mm-dd hh24:mi:ss')
    ;
  cursor novhl is
  select rownum,a.c_app_no,a.c_edr_type,
         a.c_salegrp_cde,a.c_edr_rsn_bundle_cde as c_edr_rsn,a.c_bsns_typ
  from web_ply_base a
  where a.c_prod_no not like '03%'
    and a.t_crt_tm <= to_date('2013-07-31 23:59:59','yyyy-mm-dd hh24:mi:ss')
    ;
    
  cursor agro is
  select rownum,a.c_app_no,a.c_agri_mrk,b.c_ply_typ,'---','---'
  from web_ply_base a,web_app_agro b
  where a.c_prod_no like '11%'
    and a.c_app_no = b.c_app_no
    ;
 
 cursor stk is
  select rownum,a.c_app_no,a.c_agri_mrk,b.c_stk_mrk,'---','---'
  from web_ply_base a,web_ply_applicant b,web_fin_plyedr c
  where a.c_app_no = b.c_app_no
  and a.c_app_no = c.c_app_no
    ;

begin
  
  --更新非车相关信息
  open stk;
       loop
         fetch stk bulk collect into v_tb_novhl limit 500;
             for i in 1 .. v_tb_novhl.count loop
                 update web_fin_plyedr a
                    set a.c_agri_mrk = v_tb_novhl(i).c_edr_type,
                        a.c_stk_mrk = v_tb_novhl(i).c_salegrp_cde
                  where c_app_no = v_tb_novhl(i).c_app_no;
              end loop;
              commit;
          exit when stk%notfound;
       end loop;
  close stk;

end BatchUpdatePlyEdr;
/
