CREATE procedure ADD_PLY_INTOXG_P_NOT03(BEGINDATE IN DATE,
                                                   ENDDATE   IN DATE) IS
  v_task_start_date date;
  v_task_end_date   date;
  v_sql_code        number;
  v_sql_msg         varchar2(4000) := ''; ---SQL错误信息

BEGIN
  select sysdate into v_task_start_date from dual;
  BEGIN
    ----------------  非车 A
    INSERT INTO PRPSBUSINESSFORWEB_temp
      (CERTIID, --              --**流水号
       CERTINO, --              业务号
       CERTINO1,
       POLICYNO, --               保单号
       CERTITYPE, --                业务类型
       CLASSCODE, --                险类代码
       RISKCODE, --               险种代码
       COMCODE, --              二级机构代码
       IFCHANNEL, --                是否渠道业务
       COINSFLAG, --                联共保标志
       SHAREHOLDERFLAG, --                      是否股东业务标识
       STARTDATE, --                起保日期
       ENDDATE, --              终保日期
       INPUTDATE, --                录入日期
       UNDERWRITEENDDATE, --                        核保日期
       SIGNDATE, --               签单日期
       DATASOURCE, --                 --**数据来源 --**1车险系统 --**2非车险系统 --**4 E-CARGO系统
       BUSINESSNATURE, --                     业务来源大类
       BUSINESSNATURESUB, --                        业务来源中类
       BUSINESSNATUREMIN, --                        业务来源小类
       APPLICODE, --                投保人代码
       APPLINAME, --                投保人名称
       APPLIADDRESS, --                   投保人地址
       INSUREDCODE, --                  被保险人代码
       INSUREDNAME, --                  被保险人名称
       INSUREDADDRESS, --                     被保险人地址
       --HANDLERCODE         , --                  经办人代码
       BRANCHCODE, --                 归属业务部门
       TEAMCODE, --               归属团队代码
       USERCODE, --               归属业务员代码
       AGENTCODE, --                归属代理人
       --AGENTUSERCODE       , --                    归属代理业务员
       AGREEMENTNO, --                  代理人协议号
       --APPROVERCODE        , --                   复核人代码
       UNDERWRITECODE, --                     最终核保人代码
       OPERATORCODE, --                   操作员代码(录单人)
       MAKECOM, --              录单人员归属机构
       --REINSFLAG           , --                商业分保标志
       BUSINESSFLAG, --                   业务标识
       CURRENCY, --               承保币种
       CNYEXCHRATE, --                  承保汇率
       DISCOUNTRATE, --                   总折扣率
       SUMAMOUNT, --                总保险金额
       SUMDISCOUNT, --                  总折扣金额(折扣减掉的保额)
       SUMPREMIUM, --                 总保险费(折扣后总保费)
       ENDORTYPE, --                批改类型
       ENDORDATE, --                批改日期
       VALIDDATE, --                生效日期(含时分秒)
       CHGAMOUNT, --                批改保额变化值(批增或批减的值)
       CHGPREMIUM, --                 批改保险费变化值(批增或批减的值)
       LICENSENO, --                车牌号码(货运险存放发票号)
       CARKINDCODE, --                  车辆使用类型(车险保单必填)
       --USEYEARS            , --               使用年限
       --COUNTRYNATURE       , --                    国别性质
       SEATCOUNT, --                座位数
       TONCOUNT, --               吨位数
       EXHAUSTSCALE, --                   排量
       --MODELCODE           , --                厂牌车型
       IFRENEWAL, --                是否续保
       OLDPOLICYNO, --                  被续保单号
       GENERATEDATE, --                   保批单生成日期
       CARSUBNATURECODE, --                       车辆使用性质
       CAFFIRMCDE, --                 保单-投保确认码,批单-批改确认码
       --ILOGDISRATE         , --                  ILOG手续费比例
       --PLATDISRATE         , --                  平台手续费比例
       A1RATE, --             A1手续费/佣金比例        字段会有改变0616
       BRATE, --             B展业费比例
       C1RATE, --              C1个人基础绩效费用比例
       DRATE, --            D个人附加费用比例
       ERATE, --            E机构销售管理费用比例
       IRATE, --            I项目拓展费用费用比例
       JRATE, --            J追加费用比例
       ISSETTLEMENT, --                   是否结算标记
       COINSPLANFLAG, --                    共保业务缴费方式    1：华海主共录全单 **2：华海主共录比例 **3：华海从共录比例
       -- BUSINESSDEPARTMENT  , --                         业务服务部门
       CREATEDATE, --                 创建时间
       BIZNO, -- 保险卡号
       BIZTYPE, -- 单证类型
       TOTALPROTOCOLTNO, -- 预约协议号
       DATASTATUS, -- '0'
       ITEMSTATUS, -- '0'
       ISACCOUNT, -- 是否挂账
       AGRIMRK, --涉农标志
       ZCTYMRK, --政策性
       CHANNELTYPE,
       CUSTSEQ,
       TAXPREMIUM, --含税保费或含税保费变化量
       TAXRATE --保单税率
       )
      SELECT PRPSBUSINESSFORWEB_seq.Nextval,
             wpb.c_ply_no,
             wpb.c_ply_no,
             wpb.c_ply_no,
             decode(wpb.c_app_typ, 'A', 'P'),
             --(select c_kind_no from web_prd_prod wpp where wpp.c_prod_no=wpb.c_prod_no ),
             substr(wpb.c_prod_no, 1, 2),
             wpb.c_prod_no,
             --(SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE)
             --  nvl(substr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),instr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),';',1,1)+1,instr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),';',1,2)-1-instr((SELECT wod.c_dpt_rel_cde FROM web_org_dpt wod WHERE c_dpt_cde =wpb.C_DPT_CDE),';',1,1)),wpb.c_dpt_cde),
             dp2.C_SNR_DPT,
             decode(wpb.c_bsns_typ, '19001', 0, 1),
             decode(wpb.c_ci_mrk,
                    '3',
                    '1',
                    '4',
                    '2',
                    '1',
                    '3',
                    '2',
                    '4',
                    '0'), --  共保标识  hexin  外部34
             --wpb.c_ci_mrk,
             decode(wpb.c_cha_type, '1900103', 1, 0),
             (wpb.t_insrnc_bgn_tm + 1 / 24 / 60 / 60), -- 起保日期
             wpb.t_insrnc_end_tm,
             wpb.T_CRT_TM,
             wpb.t_udr_tm,
             wpb.t_issue_tm,
             decode(wpb.c_sys_res, 'ECARGO', '4', '2'), -- feiche chuan 2
             wpb.c_bsns_typ,
             wpb.c_cha_type,
             wpb.c_cha_subtype,
             wpa.c_app_cde,
             wpa.c_app_nme,
             wpa.c_clnt_addr,
             wpi.c_insured_cde,
             wpi.c_insured_nme,
             wpi.c_clnt_addr,
             --NULL,  经办人
             wpb.c_dpt_cde,
             wpb.c_salegrp_cde,
             wpb.c_sls_id,
             wpb.c_brkr_cde,
             --null,   归属代理业务员
             wpb.c_agt_agr_no,
             --null,   核心无复核人
             wpb.c_udr_cde,
             wpb.c_opr_cde,
             --   (SELECT woo.c_own_dpt_cde FROM web_org_oper woo WHERE woo.c_oper_id  = wpb.c_opr_cde), --录单员归属机构
             
             woo.c_own_dpt_cde,
             --null, 商业分保标识
             wpb.c_inwd_mrk,
             --wpb.c_prm_cur,-- 保费币种
             decode(wpb.c_prm_cur,
                    '01',
                    'CNY',
                    '02',
                    'HKD',
                    '03',
                    'USD',
                    '04',
                    'GBP',
                    '12',
                    'EUR',
                    '05',
                    'JPY'), -- 保费币种
             wpb.n_prm_rmb_exch, -- 保费人民币汇率
             wpb.n_irr_ratio, -- 折扣率
             wpb.n_amt,
             0, --总折扣费
             --wpb.n_prm, --折扣后总保险金额
             --wapv.n_prm_clean, --XQ-6253,SUMPREMIUM 由“总保险费(折扣后总保费)”调整为“总保险费(折扣后总保费,不含税)”
             case
               when 'N' = (select t.c_cde
                             from web_sys_sta_dict t
                            where t.c_par_cde like 'SalesVat%'
                              and wpb.t_crt_tm > t.t_trans_tm
                              and wpb.t_crt_tm < t.t_adb_tm) then
                wpb.n_prm
               else
                wapv.n_prm_clean
             end,
             wpb.c_edr_type,
             wpb.t_edr_app_tm,
             (wpb.t_edr_bgn_tm + 1 / 24 / 60 / 60),
             wpb.n_amt_var,
             --wpb.n_prm_var, --保费费变化量
             --wapv.n_prm_var_clean, --XQ-6253,CHGPREMIUM 由“批改保险费变化值(批增或批减的值)”调整为“批改保险费变化值(批增或批减的值,不含税)”
             case
               when 'N' = (select t.c_cde
                             from web_sys_sta_dict t
                            where t.c_par_cde like 'SalesVat%'
                              and wpb.t_crt_tm > t.t_trans_tm
                              and wpb.t_crt_tm < t.t_adb_tm) then
                wpb.n_prm_var
               else
                wapv.n_prm_var_clean
             end,
             null, --wpv.c_plate_no,
             null, --wpv.c_vhl_typ,
             null, --wpv.n_seat_num,
             null, --wpv.n_tonage,
             null, --wpv.n_displacement,
             --wpb.c_renew_mrk,
             decode(wpb.c_renew_mrk, '0', '0', '1', '1', '0'),
             wpb.c_orig_ply_no,
             --nvl((wpb.t_insrnc_bgn_tm+1/24/60/60),(wpb.t_insrnc_bgn_tm+1/24/60/60)), -- 起保日期  -- 报批单落地时间
             wpb.t_crt_tm, --   报批单生成日期
             null, --wpv.c_usage_cde,
             null, --wpv.c_affirm_cde,
             /*         nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y0' ),0),--A
             nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y3' ),0),--B
             nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y2' ),0),--C
             nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y1' ),0),--D
             nvl((SELECT wpf.n_fee_prop FROM web_ply_fee wpf WHERE wpf.c_app_no = wpb.c_app_no AND wpf.c_feetyp_cde='Y9' ),0),--E*/
             nvl(wpf.n_fee_prop, 0), --A  y0
             nvl(wpf1.n_fee_prop, 0), --B y3
             nvl(wpf2.n_fee_prop, 0), --C y2
             nvl(wpf4.n_fee_prop, 0), --D  y1
             nvl(wpf3.n_fee_prop, 0), --E  y9
             0.0,
             0.0,
             DECODE(wpb.c_ecargo_fee_typ, '1', '1', '0', '0', '1'),
             --decode(wpb.c_ci_inp_typ,'600001','1','600002','2','600003','3'),  -- 共保业务缴费方式    1：华海主共录全单 **2：华海主共录比例 **3：华海从共录比例
             (CASE
               WHEN wpb.c_ci_mrk = '3' AND wpb.c_ci_inp_typ = '1' THEN
                '1'
               WHEN wpb.c_ci_mrk = '3' AND wpb.c_ci_inp_typ = '0' THEN
                '2'
               WHEN wpb.c_ci_mrk = '4' AND wpb.c_ci_inp_typ = '1' THEN
                '3'
               WHEN wpb.c_ci_mrk = '4' AND wpb.c_ci_inp_typ = '0' THEN
                '3'
               ELSE
                NULL
             END),
             SYSDATE,
             wco.c_card_no,
             wco.c_card_type,
             
             wpb.c_oc_agr_no,
             '0', --默认0
             '0', --默认0
             --decode(wpb.c_bsns_typ,'19001',0,1)
             (CASE
               WHEN wpf.n_fee_prop = '0' and wpf2.n_fee_prop = '0' THEN
                '0'
               ELSE
                '1'
             END),
             /*(CASE WHEN wpb.t_crt_tm<to_date('2016/07/25 00:00:00','yyyy/mm/dd hh24:mi:ss') THEN '0'
             WHEN wpb.t_crt_tm>=to_date('2016/07/25 00:00:00','yyyy/mm/dd hh24:mi:ss') THEN '1'
               ELSE NULL END)*/
             wpb.c_agri_mrk,
             (CASE
               WHEN substr(wpb.c_prod_no, 0, 2) = '16' THEN
                (select C_Tgt_Txt_Fld_1
                   from web_ply_tgt tgt
                  where tgt.c_app_no = wpb.c_app_no)
               ELSE
                ''
             END),
             wpb.c_tem_channel,
             cus.custseq,
             --wpb.n_prm, --XQ-6253,含税保费或含税保费变化量
             --wapv.n_net_vat / wapv.n_net_prm --XQ-6253,保单税率
             case
               when 'N' = (select t.c_cde
                             from web_sys_sta_dict t
                            where t.c_par_cde like 'SalesVat%'
                              and wpb.t_crt_tm > t.t_trans_tm
                              and wpb.t_crt_tm < t.t_adb_tm) then
                null
               else
                wpb.n_prm
             end,
             case
               when 'N' = (select t.c_cde
                             from web_sys_sta_dict t
                            where t.c_par_cde like 'SalesVat%'
                              and wpb.t_crt_tm > t.t_trans_tm
                              and wpb.t_crt_tm < t.t_adb_tm) then
                null
               else
                wapv.n_net_vat / wapv.n_net_prm
             end
        FROM web_ply_base wpb
        LEFT JOIN web_mid_fee_to_sales sales
          ON sales.c_app_no = wpb.c_app_no -- 送销管中间表
        left join web_card_orlog wcog
          on wcog.c_app_no = wpb.c_app_no
        LEFT JOIN web_ply_applicant wpa
          ON wpa.c_app_no = wpb.c_app_no --   根据投保单号关联投保人信息表
        LEFT JOIN web_ply_insured wpi
          ON wpi.c_app_no = wpb.c_app_no --   根据投保单号关联被保人信息表
      --LEFT JOIN WEB_PLY_VHL wpv
      --ON wpv.c_app_no = wpb.c_app_no
        left join web_org_dpt dp1
          on dp1.C_DPT_CDE = wpb.C_DPT_CDE
        left join web_org_dpt dp2
          on dp2.C_DPT_CDE = dp1.C_SNR_DPT
        left join web_org_oper woo
          on woo.c_oper_id = wpb.c_opr_cde
        left join web_ply_fee wpf
          on wpf.c_app_no = wpb.c_app_no
         AND wpf.c_feetyp_cde = 'Y0'
        left join web_ply_fee wpf1
          on wpf1.c_app_no = wpb.c_app_no
         AND wpf1.c_feetyp_cde = 'Y3'
        left join web_ply_fee wpf2
          on wpf2.c_app_no = wpb.c_app_no
         AND wpf2.c_feetyp_cde = 'Y2'
        left join web_ply_fee wpf4
          on wpf4.c_app_no = wpb.c_app_no
         AND wpf4.c_feetyp_cde = 'Y1'
        left join web_ply_fee wpf3
          on wpf3.c_app_no = wpb.c_app_no
         AND wpf3.c_feetyp_cde = 'Y9'
        left join WEB_CARD_ORLOG wco
          on wco.c_app_no = wpb.c_app_no
         AND wco.c_ply_no = wpb.c_ply_no
        left join (SELECT t.id, t.policyno
                     FROM mm_policy_ti t
                    WHERE t.endorseno = '无'
                      AND t.certitype = '1') mmti
          on mmti.policyno = wpb.c_ply_no
        LEFT JOIN (SELECT ti.custseq, ti.seqpolicy, ti.policyno
                     FROM mm_policylist_ti ti
                    WHERE ti.datatype = '1') cus
          ON cus.seqpolicy = mmti.id
         AND cus.policyno = wpb.c_ply_no
        left join (SELECT v.n_prm_clean,
                          v.n_prm_var_clean,
                          v.n_net_vat,
                          v.n_net_prm,
                          v.c_vat_query_cde
                     FROM web_app_base_vat v
                    WHERE v.c_erti_type = 'premium'
                      AND v.c_app_typ = 'A') wapv
          ON wapv.c_vat_query_cde = wpb.c_vat_query_cde
       WHERE substr(wpb.c_prod_no, 0, 2) <> '03'
         AND WPB.C_APP_TYP = 'A'
         and (wcog.c_txt2 = '0' or wcog.c_txt2 is null)
         and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null)
         and (sales.c_fee_upd_flag is null or sales.c_fee_upd_flag = '')
         AND wpb.t_crt_tm BETWEEN begindate AND enddate
            
         AND sales.c_status = '0'
         and sales.c_send_num <= 3
         AND (wpb.t_crt_tm > sysdate - 1 or sales.t_upd_tm > sysdate - 1)
      
      ;
  
    --  子表
  
    ----------------------- 险种代码   非车  非06  21大类
    INSERT INTO PRPSBUSINESSSUBFORWEB_temp
      (
       --ID                 ,-- 主键
       CERTINO, --      业务号
       CERTINO1,
       CERTITYPE, --        业务类型
       POLICYNO, --       保单号码
       CLASSCODE, --        险类代码
       RISKCODE, --       险种代码
       ITEMKINDNO, --         序号
       COMCODE, --      归属机构代码
       TEAMCODE, --       归属团队代码
       KINDCODE, --       险别代码（核心）
       KINDNAME, --       险别名称（核心）
       ACOUNTKINDCODE, --             险别代码（收付）
       ACOUNTKINDNAME, --             险别名称收付）
       --ACCOUNTKINDCODE    ,--              对应财务险别
       STARTDATE, --        起保日期
       ENDDATE, --      终保日期
       CURRENCY, --       承保币种
       PREMIUM, --      折扣后保费
       CHGPREMIUM, --         批改保险费变化值(批增或批减的值)
       CNYEXCHRATE, --          CNY的兑换率
       -- COINSRATE          ,--        共保份额
       -- COINSRATEFEE       ,--           共保金额
       -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
       AMOUNT, --     累计赔偿限额
       --PERACCLIMITFEE     ,--             每次事故赔偿限额
       --SEATCOUNT          ,--        投保乘客座位数
       -- PERSEATFEE         ,--         每座保费
       GENERATEDATE, --           保批单生成日期
       CERTIID, --      --**流水号
       USERCODE, --       归属业务员工号
       CREATEDATE, --         创建时间
       UPDATEDATE, --         修改时间
       ISDUTYfREE, --         此险别是否免税
       TAXPREMIUM, --含税保费或含税保费变化量
       TAXRATE --险别税率
       )
      SELECT
      --PRPSBUSINESSSUBFORWEB_seq.Nextval,
       wpc.c_ply_no,
       wpc.c_ply_no,
       --(SELECT wpb.c_app_typ FROM web_ply_base wpb WHERE wpb.c_app_no = wpc.c_app_no),
       --wpb.c_app_typ,
       decode(wpb.c_app_typ, 'A', 'P', 'E', 'E'),
       wpc.c_ply_no,
       --(select c_kind_no from web_prd_prod wpp where wpp.c_prod_no=wpb.c_prod_no ),
       substr(wpb.c_prod_no, 1, 2),
       wpb.c_prod_no,
       --wpc.n_seq_no,
       number_seq.nextval, --  序号改为序列
       wpb.c_dpt_cde,
       wpb.c_salegrp_cde, -- tuandui
       wpc.c_cvrg_no,
       w1.c_nme_cn,
       nvl(w2.c_fin_prod, w3.c_fin_prod),
       nvl(w2.c_fin_prod_name, w3.c_fin_prod_name),
       --null,
       nvl((wpc.t_bgn_tm + 1 / 24 / 60 / 60),
           (wpb.t_insrnc_bgn_tm + 1 / 24 / 60 / 60)),
       nvl(wpc.t_end_tm, wpb.t_insrnc_end_tm),
       decode(wpb.c_prm_cur,
              '01',
              'CNY',
              '02',
              'HKD',
              '03',
              'USD',
              '04',
              'GBP',
              '12',
              'EUR',
              '05',
              'JPY'), -- 保费币种
       --wpb.c_prm_cur, --  保费币种
       --wpc.n_prm, --  折后保费
       --wacv.n_prm_clean, --XQ-6253,PREMIUM 由“折扣后保费”调整为“折扣后保费,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm
         else
          wacv.n_prm_clean
       end,
       --wpc.n_prm_var, -- 保费变化量
       --wacv.n_prm_var_clean, --XQ-6253,CHGPREMIUM 由“批改保险费变化值”调整为“批改保险费变化值,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm_var
         else
          wacv.n_prm_var_clean
       end,
       wpb.n_prm_rmb_exch, --人民币汇率
       --null,
       --null,
       --null,
       nvl(wpc.n_indem_lmt, 0), --wpb.n_indem_lmt,-- 赔偿限额合计
       --null，
       --null,
       --null,
       wpb.t_crt_tm,
       PRPSBUSINESSSUBFORWEB_seq.Nextval,
       wpb.c_sls_id,
       wpc.t_crt_tm,
       wpc.t_upd_tm,
       /*NVL((SELECT c_vat_typ FROM web_bas_cvrg_vat_rate WHERE c_cvrg_no NOT LIKE '03%'
                        AND c_imporexp_mrk=(CASE WHEN wpb.c_imporexp_mrk='1' THEN '1'  ELSE '0' END)
                        AND c_cvrg_no=wpc.c_cvrg_no
                        AND c_insrnc_typ=(CASE WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)=365 THEN '2'
                            WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)>365 THEN '3'
                              WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)<365 THEN '1' ELSE NULL END)),
       (SELECT c_vat_typ FROM web_bas_cvrg_vat_rate WHERE c_cvrg_no NOT LIKE '03%'
                         AND c_imporexp_mrk='0' AND c_cvrg_no=wpc.c_cvrg_no))*/ --         此险别是否免税
       NVL(rates.c_vat_typ, rates1.c_vat_typ), --         此险别是否免税
       --wpc.n_prm, --XQ-6253,含税保费或含税保费变化量
       --wacv.n_vat_rate --XQ-6253,险别税率
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wpc.n_prm
       end,
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wacv.n_vat_rate
       end
        FROM web_ply_cvrg wpc
        LEFT JOIN web_mid_fee_to_sales sales
          ON sales.c_app_no = wpc.c_app_no -- 送销管中间表
        left join web_ply_base wpb
          on wpc.c_app_no = wpb.c_app_no
        left join web_prd_cvrg w1
          on w1.c_cvrg_no = wpc.c_cvrg_no
        left join web_mid_busprod_con_finprod w3
          on w3.c_bus_prod = wpb.c_prod_no
         AND ((w3.c_resv_txt_1 = (CASE
               WHEN wpb.c_imporexp_mrk = '1' THEN
                '1'
               WHEN wpb.c_imporexp_mrk = '2' THEN
                '2'
               WHEN wpb.c_imporexp_mrk = '3' THEN
                '3'
               WHEN wpb.c_imporexp_mrk = '4' THEN
                '4'
               ELSE
                NULL
             END) or w3.c_resv_txt_1 is null) AND
             (w3.c_resv_txt_3 IS NULL or w3.c_resv_txt_3 = '0'))
        left join web_mid_busprod_con_finprod w2
          on w2.c_bus_cvrg_no = wpc.c_cvrg_no
         and ((w2.c_resv_txt_1 = (CASE
               WHEN wpb.c_imporexp_mrk = '1' THEN
                '1'
               WHEN wpb.c_imporexp_mrk = '2' THEN
                '2'
               WHEN wpb.c_imporexp_mrk = '3' THEN
                '3'
               WHEN wpb.c_imporexp_mrk = '4' THEN
                '4'
               ELSE
                NULL
             END) or w3.c_resv_txt_1 is null) AND w2.c_resv_txt_3 = '1')
        left join web_bas_cvrg_vat_rate rates
          on substr(rates.c_cvrg_no, 0, 2) <> '03'
         AND rates.c_cvrg_no = wpc.c_cvrg_no
         AND rates.c_imporexp_mrk = (CASE
                                       WHEN wpb.c_imporexp_mrk = '1' THEN
                                        '1'
                                       WHEN wpb.c_imporexp_mrk = '0' THEN
                                        '0'
                                       ELSE
                                        NULL
                                     END)
        left join web_bas_cvrg_vat_rate rates1
          on substr(rates1.c_cvrg_no, 0, 2) <> '03'
         AND rates1.c_imporexp_mrk = '0'
         AND rates1.c_cvrg_no = wpc.c_cvrg_no
        left join (SELECT v.n_prm_clean,
                          v.n_vat_rate,
                          v.n_prm_var_clean,
                          v.c_vat_query_cde,
                          v.c_cvrg_no,
                          v.c_resv_txt_1
                     FROM web_app_cvrg_vat v
                    WHERE v.c_erti_type = 'premium'
                      AND v.c_app_typ = 'A') wacv
          on wacv.c_vat_query_cde = wpb.c_vat_query_cde
         AND wacv.c_cvrg_no = wpc.c_cvrg_no
         AND wacv.c_resv_txt_1 = wpc.n_seq_no
       WHERE substr(wpc.c_cvrg_no, 0, 2) <> '03'
         AND substr(wpc.c_cvrg_no, 0, 2) <> '06'
         AND substr(wpc.c_cvrg_no, 0, 2) <> '21'
         AND substr(wpc.c_cvrg_no, 0, 2) <> '16'
         and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null) --销管秒接中间表
         and (sales.c_fee_upd_flag is null or sales.c_fee_upd_flag = '')
         AND WPB.C_APP_TYP = 'A'
         AND wpb.c_app_no = wpc.c_app_no
            --AND wpb.c_ply_no in(SELECT pp FROM aaa WHERE ee='无')  --  0722
         AND EXISTS
       (SELECT a.c_app_no
                FROM web_ply_base a
               WHERE a.c_app_typ = 'A'
                 AND a.c_app_no = wpc.c_app_no
                    --AND a.c_renew_mrk IN('1','0')
                 AND substr(a.c_prod_no, 0, 2) <> '03'
                 AND substr(a.c_prod_no, 0, 2) <> '06'
                 AND substr(a.c_prod_no, 0, 2) <> '21'
                 AND substr(wpc.c_cvrg_no, 0, 2) <> '16'
                 AND a.t_crt_tm BETWEEN begindate AND enddate) -- 主表保费变化量为0的不传销管
            
            -- AND wpc.t_crt_tm BETWEEN begindate AND enddate
            
         AND sales.c_status = '0'
         and sales.c_send_num <= 3
         AND (wpc.t_crt_tm > sysdate - 1 or sales.t_upd_tm > sysdate - 1)
      
      ;
  
    ----------------------- 险别代码  团单 wpb.c_grp_mrk='1'  21 06大类
  
    INSERT INTO PRPSBUSINESSSUBFORWEB_temp
      (
       --ID                 ,-- 主键
       CERTINO, --      业务号
       CERTINO1,
       CERTITYPE, --        业务类型
       POLICYNO, --       保单号码
       CLASSCODE, --        险类代码
       RISKCODE, --       险种代码
       ITEMKINDNO, --         序号
       COMCODE, --      归属机构代码
       TEAMCODE, --       归属团队代码
       KINDCODE, --       险别代码（核心）
       KINDNAME, --       险别名称（核心）
       ACOUNTKINDCODE, --             险别代码（收付）
       ACOUNTKINDNAME, --             险别名称收付）
       --ACCOUNTKINDCODE    ,--              对应财务险别
       STARTDATE, --        起保日期
       ENDDATE, --      终保日期
       CURRENCY, --       承保币种
       PREMIUM, --      折扣后保费
       CHGPREMIUM, --         批改保险费变化值(批增或批减的值)
       CNYEXCHRATE, --          CNY的兑换率
       -- COINSRATE          ,--        共保份额
       -- COINSRATEFEE       ,--           共保金额
       -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
       AMOUNT, --     累计赔偿限额
       --PERACCLIMITFEE     ,--             每次事故赔偿限额
       --SEATCOUNT          ,--        投保乘客座位数
       -- PERSEATFEE         ,--         每座保费
       GENERATEDATE, --           保批单生成日期
       CERTIID, --      --**流水号
       USERCODE, --       归属业务员工号
       CREATEDATE, --         创建时间
       UPDATEDATE, --         修改时间
       ISDUTYfREE, --         此险别是否免税
       TAXPREMIUM, --含税保费或含税保费变化量
       TAXRATE --险别税率
       )
    
      SELECT
      --PRPSBUSINESSSUBFORWEB_seq.Nextval,
       wpc.c_ply_no,
       wpc.c_ply_no,
       decode(wpb.c_app_typ, 'A', 'P', 'E', 'E'),
       --wpb.c_app_typ,
       wpc.c_ply_no,
       SUBSTR(wpb.c_prod_no, 1, 2),
       wpb.c_prod_no,
       --wpb.c_prod_no,
       --wpc.n_seq_no,
       number_seq.nextval, --  序号改为序列
       wpb.c_dpt_cde,
       --wpb.c_dpt_cde,
       wpb.c_salegrp_cde, -- tuandui
       wpc.c_cvrg_no,
       w1.c_nme_cn,
       NVL(w3.c_fin_prod, w4.c_fin_prod),
       nvl(w3.c_fin_prod_name, w4.c_fin_prod_name),
       
       --null,
       nvl((wpc.t_bgn_tm + 1 / 24 / 60 / 60),
           (wpb.t_insrnc_bgn_tm + 1 / 24 / 60 / 60)),
       nvl(wpc.t_end_tm, wpb.t_insrnc_end_tm),
       DECODE(wpb.c_prm_cur,
              '01',
              'CNY',
              '02',
              'HKD',
              '03',
              'USD',
              '04',
              'GBP',
              '12',
              'EUR',
              '05',
              'JPY'), -- 保费币种
       --wpc.n_prm, --  折后保费
       --wacv.n_prm_clean, --XQ-6253,PREMIUM 由“折扣后保费”调整为“折扣后保费,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm
         else
          wacv.n_prm_clean
       end,
       --wpc.n_prm_var, -- 保费变化量
       --wacv.n_prm_var_clean, --XQ-6253,CHGPREMIUM 由“批改保险费变化值”调整为“批改保险费变化值,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm_var
         else
          wacv.n_prm_var_clean
       end,
       wpb.n_prm_rmb_exch, --人民币汇率
       --null,
       --null,
       --null,
       nvl(wpc.n_indem_lmt, 0), -- 赔偿限额合计
       --null，
       --null,
       --null,
       wpb.t_crt_tm,
       PRPSBUSINESSSUBFORWEB_seq.Nextval,
       --  (SELECT wpb.c_sls_id FROM web_ply_base wpb WHERE wpb.c_app_no = wpc.c_app_no),
       wpb.c_sls_id,
       wpc.t_crt_tm,
       wpc.t_upd_tm,
       NVL(wbcvr.c_vat_typ, wbcvr2.c_vat_typ),
       --NVL((SELECT c_vat_typ FROM web_bas_cvrg_vat_rate WHERE c_cvrg_no NOT LIKE '03%' AND c_imporexp_mrk=wpb.c_imporexp_mrk AND c_cvrg_no=wpc.c_cvrg_no AND c_insrnc_typ=(CASE WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)=365 THEN '2' WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)>365 THEN '3' WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)<365 THEN '1' ELSE NULL END)),(SELECT c_vat_typ FROM web_bas_cvrg_vat_rate WHERE c_cvrg_no NOT LIKE '03%' AND c_imporexp_mrk=wpb.c_imporexp_mrk AND c_cvrg_no=wpc.c_cvrg_no AND c_insrnc_typ='0'))
       --         此险别是否免税
       --wpc.n_prm, --XQ-6253,含税保费或含税保费变化量
       --wacv.n_vat_rate --XQ-6253,险别税率
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wpc.n_prm
       end,
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wacv.n_vat_rate
       end
        FROM web_ply_cvrg wpc
        LEFT JOIN web_mid_fee_to_sales sales
          ON sales.c_app_no = wpc.c_app_no -- 送销管中间表
        LEFT JOIN web_ply_base wpb
          ON wpb.c_app_no = wpc.c_app_no
        LEFT JOIN web_prd_cvrg w1
          ON w1.c_cvrg_no = wpc.c_cvrg_no
        LEFT JOIN web_mid_busprod_con_finprod w3
          ON w3.c_bus_prod = wpb.c_prod_no
         AND w3.c_bus_cvrg_no = wpc.c_cvrg_no
         AND substr(w3.c_bus_kind, 0, 2) <> '03'
         AND w3.c_bus_cvrg_no IS NOT NULL
         AND (w3.c_group_mark = '1' OR w3.c_group_mark IS NULL)
         AND w3.c_resv_txt_4 = (CASE
               WHEN (wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) < 365 THEN
                '0'
               WHEN (wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) >= 365 THEN
                '1'
               ELSE
                NULL
             END)
        LEFT JOIN web_mid_busprod_con_finprod w4
          ON w4.c_bus_prod = wpb.c_prod_no
         AND w4.c_bus_cvrg_no = wpc.c_cvrg_no
         AND substr(w4.c_bus_kind, 0, 2) <> '03'
         AND (w4.c_group_mark = '1' OR w4.c_group_mark IS NULL)
         AND w4.c_bus_cvrg_no IS NOT NULL
         AND w4.c_resv_txt_4 IS NULL
        LEFT JOIN web_bas_cvrg_vat_rate wbcvr
          ON SUBSTR(wbcvr.c_cvrg_no, 0, 2) <> '03'
         AND wbcvr.c_imporexp_mrk = (CASE
                                       WHEN wpb.c_imporexp_mrk = '1' THEN
                                        '1'
                                       WHEN wpb.c_imporexp_mrk = '2' THEN
                                        '0'
                                       WHEN wpb.c_imporexp_mrk = '3' THEN
                                        '0'
                                       WHEN wpb.c_imporexp_mrk = '4' THEN
                                        '0'
                                       WHEN wpb.c_imporexp_mrk = '0' THEN
                                        '0'
                                       ELSE
                                        '0'
                                     END)
            --AND c_yworjk=(SELECT c_yworjk FROM web_prd_cvrg WHERE c_cvrg_no=wpc.c_cvrg_no)
         AND wbcvr.c_cvrg_no = wpc.c_cvrg_no
         AND wbcvr.c_insrnc_typ = (CASE
                                     WHEN TRUNC(wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) = 365 THEN
                                      '2'
                                     WHEN TRUNC(wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) > 365 THEN
                                      '3'
                                     WHEN TRUNC(wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) < 365 THEN
                                      '1'
                                     ELSE
                                      NULL
                                   END)
        LEFT JOIN web_bas_cvrg_vat_rate wbcvr2
          ON SUBSTR(wbcvr2.c_cvrg_no, 0, 2) <> '03'
         AND wbcvr2.c_imporexp_mrk = (CASE
                                        WHEN wpb.c_imporexp_mrk = '1' THEN
                                         '1'
                                        WHEN wpb.c_imporexp_mrk = '2' THEN
                                         '0'
                                        WHEN wpb.c_imporexp_mrk = '3' THEN
                                         '0'
                                        WHEN wpb.c_imporexp_mrk = '4' THEN
                                         '0'
                                        WHEN wpb.c_imporexp_mrk = '0' THEN
                                         '0'
                                        ELSE
                                         '0'
                                      END)
         AND wbcvr2.c_cvrg_no = wpc.c_cvrg_no
         AND wbcvr2.c_insrnc_typ = '0'
        left join (SELECT v.n_prm_clean,
                          v.n_vat_rate,
                          v.n_prm_var_clean,
                          v.c_vat_query_cde,
                          v.c_cvrg_no,
                          v.c_resv_txt_1
                     FROM web_app_cvrg_vat v
                    WHERE v.c_erti_type = 'premium'
                      AND v.c_app_typ = 'A') wacv
          on wacv.c_vat_query_cde = wpb.c_vat_query_cde
         AND wacv.c_cvrg_no = wpc.c_cvrg_no
         AND wacv.c_resv_txt_1 = wpc.n_seq_no
       WHERE EXISTS
       (SELECT wpb.c_app_no
                FROM web_ply_base wpb
               WHERE wpb.c_grp_mrk = '1'
                 AND wpb.c_app_no = wpc.c_app_no
                    --AND SUBSTR (wpb.c_prod_no,0,2)<> '03'
                 AND (SUBSTR(wpb.c_prod_no, 0, 2) = '06' OR
                     SUBSTR(wpb.c_prod_no, 0, 2) = '21')
                 AND wpb.c_app_typ = 'A'
                 AND wpb.t_crt_tm BETWEEN begindate AND enddate)
         AND wpc.c_app_no = wpb.c_app_no
         AND wpb.c_grp_mrk = '1'
         and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null) --销管秒接中间表
         and (sales.c_fee_upd_flag is null or sales.c_fee_upd_flag = '')
         AND wpb.c_app_typ = 'A'
         AND (SUBSTR(wpc.c_cvrg_no, 0, 2) = '06' OR
             SUBSTR(wpc.c_cvrg_no, 0, 2) = '21')
            --AND wpb.c_ply_no in(SELECT pp FROM aaa WHERE ee='无')  --  0722
            --  AND wpc.t_crt_tm BETWEEN begindate AND enddate
            
         AND sales.c_status = '0'
         and sales.c_send_num <= 3
         AND (wpc.t_crt_tm > sysdate - 1 or sales.t_upd_tm > sysdate - 1)
      
      ;
  
    ----------------------- 险别代码  非团单 wpb.c_grp_mrk<>'1'  21 06大类
  
    INSERT INTO PRPSBUSINESSSUBFORWEB_temp
      (
       --ID                 ,-- 主键
       CERTINO, --      业务号
       CERTINO1,
       CERTITYPE, --        业务类型
       POLICYNO, --       保单号码
       CLASSCODE, --        险类代码
       RISKCODE, --       险种代码
       ITEMKINDNO, --         序号
       COMCODE, --      归属机构代码
       TEAMCODE, --       归属团队代码
       KINDCODE, --       险别代码（核心）
       KINDNAME, --       险别名称（核心）
       ACOUNTKINDCODE, --             险别代码（收付）
       ACOUNTKINDNAME, --             险别名称收付）
       --ACCOUNTKINDCODE    ,--              对应财务险别
       STARTDATE, --        起保日期
       ENDDATE, --      终保日期
       CURRENCY, --       承保币种
       PREMIUM, --      折扣后保费
       CHGPREMIUM, --         批改保险费变化值(批增或批减的值)
       CNYEXCHRATE, --          CNY的兑换率
       -- COINSRATE          ,--        共保份额
       -- COINSRATEFEE       ,--           共保金额
       -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
       AMOUNT, --     累计赔偿限额
       --PERACCLIMITFEE     ,--             每次事故赔偿限额
       --SEATCOUNT          ,--        投保乘客座位数
       -- PERSEATFEE         ,--         每座保费
       GENERATEDATE, --           保批单生成日期
       CERTIID, --      --**流水号
       USERCODE, --       归属业务员工号
       CREATEDATE, --         创建时间
       UPDATEDATE, --         修改时间
       ISDUTYfREE, --         此险别是否免税
       TAXPREMIUM, --含税保费或含税保费变化量
       TAXRATE --险别税率
       )
    
      SELECT
      --PRPSBUSINESSSUBFORWEB_seq.Nextval,
       wpc.c_ply_no,
       wpc.c_ply_no,
       DECODE(wpb.c_app_typ, 'A', 'P', 'E', 'E'),
       wpc.c_ply_no,
       SUBSTR(wpb.c_prod_no, 1, 2),
       wpb.c_prod_no,
       --wpc.n_seq_no,
       number_seq.nextval, --  序号改为序列
       wpb.c_dpt_cde,
       wpb.c_salegrp_cde, -- tuandui
       wpc.c_cvrg_no,
       w1.c_nme_cn,
       NVL(w4.c_fin_prod, w5.c_fin_prod),
       NVL(w4.c_fin_prod_name, w5.c_fin_prod_name),
       
       --null,
       nvl((wpc.t_bgn_tm + 1 / 24 / 60 / 60),
           (wpb.t_insrnc_bgn_tm + 1 / 24 / 60 / 60)),
       nvl(wpc.t_end_tm, (wpb.t_insrnc_end_tm)),
       
       DECODE(wpb.c_prm_cur,
              '01',
              'CNY',
              '02',
              'HKD',
              '03',
              'USD',
              '04',
              'GBP',
              '12',
              'EUR',
              '05',
              'JPY'), -- 保费币种
       --wpb.c_prm_cur, --  保费币种
       --decode(wpc.n_prm, null, 0, wpc.n_prm), --  折后保费
       --wacv.n_prm_clean, --XQ-6253,PREMIUM 由“折扣后保费”调整为“折扣后保费,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm
         else
          wacv.n_prm_clean
       end,
       --wpc.n_prm_var, -- 保费变化量
       --wacv.n_prm_var_clean, --XQ-6253,CHGPREMIUM 由“批改保险费变化值”调整为“批改保险费变化值,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm_var
         else
          wacv.n_prm_var_clean
       end,
       wpb.n_prm_rmb_exch, --人民币汇率
       --null,
       --null,
       --null,
       nvl(wpc.n_indem_lmt, 0), -- 赔偿限额合计
       --null，
       --null,
       --null,
       wpb.t_crt_tm,
       PRPSBUSINESSSUBFORWEB_seq.Nextval,
       wpb.c_sls_id,
       wpc.t_crt_tm,
       wpc.t_upd_tm,
       --(SELECT wpb.c_imporexp_mrk FROM web_ply_base wpb WHERE wpb.c_app_no = wpc.c_app_no)
       NVL(w6.c_vat_typ, w7.c_vat_typ), --         此险别是否免税
       --wpc.n_prm, --XQ-6253,含税保费或含税保费变化量
       --wacv.n_vat_rate --XQ-6253,险别税率
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wpc.n_prm
       end,
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wacv.n_vat_rate
       end
        FROM web_ply_cvrg wpc
        LEFT JOIN web_mid_fee_to_sales sales
          ON sales.c_app_no = wpc.c_app_no -- 送销管中间表
        LEFT JOIN web_ply_base wpb
          ON wpb.c_app_no = wpb.c_app_no
        LEFT JOIN web_prd_cvrg w1
          ON w1.c_cvrg_no = wpc.c_cvrg_no
        LEFT JOIN web_mid_busprod_con_finprod w4
          ON w4.c_bus_prod = wpb.c_prod_no
         AND w4.c_bus_cvrg_no = wpc.c_cvrg_no
         AND substr(w4.c_bus_kind, 0, 2) <> '03'
         AND w4.c_bus_cvrg_no IS NOT NULL
         AND (w4.c_group_mark <> '1' OR w4.c_group_mark IS NULL)
         AND w4.c_resv_txt_4 = (CASE
               WHEN (wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) < 365 THEN
                '0'
               WHEN (wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) >= 365 THEN
                '1'
               ELSE
                NULL
             END)
      
        LEFT JOIN web_mid_busprod_con_finprod w5
          ON w5.c_bus_prod = wpb.c_prod_no
         AND w5.c_bus_cvrg_no = wpc.c_cvrg_no
         AND substr(w5.c_bus_kind, 0, 2) <> '03'
         AND (w5.c_group_mark <> '1' OR w5.c_group_mark IS NULL)
         AND w5.c_bus_cvrg_no IS NOT NULL
         AND w5.c_resv_txt_4 IS NULL
      
        LEFT JOIN web_bas_cvrg_vat_rate w6
          ON substr(w6.c_cvrg_no, 0, 2) <> '03%'
         AND w6.c_imporexp_mrk = (CASE
                                    WHEN wpb.c_imporexp_mrk = '1' THEN
                                     '1'
                                    WHEN wpb.c_imporexp_mrk = '2' THEN
                                     '0'
                                    WHEN wpb.c_imporexp_mrk = '3' THEN
                                     '0'
                                    WHEN wpb.c_imporexp_mrk = '4' THEN
                                     '0'
                                    WHEN wpb.c_imporexp_mrk = '0' THEN
                                     '0'
                                    ELSE
                                     '0'
                                  END)
            --AND c_yworjk=(SELECT c_yworjk FROM web_prd_cvrg WHERE c_cvrg_no=wpc.c_cvrg_no)
         AND w6.c_cvrg_no = wpc.c_cvrg_no
         AND w6.c_insrnc_typ = (CASE
                                  WHEN TRUNC(wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) = 365 THEN
                                   '2'
                                  WHEN TRUNC(wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) > 365 THEN
                                   '3'
                                  WHEN TRUNC(wpb.t_insrnc_end_tm - wpb.t_insrnc_bgn_tm + 1) < 365 THEN
                                   '1'
                                  ELSE
                                   NULL
                                END)
        LEFT JOIN web_bas_cvrg_vat_rate w7
          ON substr(w7.c_cvrg_no, 0, 2) <> '03%'
         AND w7.c_imporexp_mrk = (CASE
                                    WHEN wpb.c_imporexp_mrk = '1' THEN
                                     '1'
                                    WHEN wpb.c_imporexp_mrk = '2' THEN
                                     '0'
                                    WHEN wpb.c_imporexp_mrk = '3' THEN
                                     '0'
                                    WHEN wpb.c_imporexp_mrk = '4' THEN
                                     '0'
                                    WHEN wpb.c_imporexp_mrk = '0' THEN
                                     '0'
                                    ELSE
                                     '0'
                                  END)
         AND w7.c_cvrg_no = wpc.c_cvrg_no
         AND w7.c_insrnc_typ = '0' --         此险别是否免税
        left join (SELECT v.n_prm_clean,
                          v.n_vat_rate,
                          v.n_prm_var_clean,
                          v.c_vat_query_cde,
                          v.c_cvrg_no,
                          v.c_resv_txt_1
                     FROM web_app_cvrg_vat v
                    WHERE v.c_erti_type = 'premium'
                      AND v.c_app_typ = 'A') wacv
          on wacv.c_vat_query_cde = wpb.c_vat_query_cde
         AND wacv.c_cvrg_no = wpc.c_cvrg_no
         AND wacv.c_resv_txt_1 = wpc.n_seq_no
       WHERE EXISTS
       (SELECT wpb.c_app_no
                FROM web_ply_base wpb
               WHERE wpb.c_grp_mrk <> '1'
                 AND wpb.c_app_typ = 'A'
                 AND wpb.c_app_no = wpc.c_app_no
                 AND substr(wpb.c_prod_no, 0, 2) <> '03'
                 AND (substr(wpb.c_prod_no, 0, 2) = '06' OR
                     substr(wpb.c_prod_no, 0, 2) = '21')
                 AND wpb.t_crt_tm BETWEEN begindate AND enddate
              
              )
         AND wpc.c_app_no = wpb.c_app_no
         AND wpb.c_app_typ = 'A'
         AND wpb.c_grp_mrk <> '1'
         and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null) --销管秒接中间表
         and (sales.c_fee_upd_flag is null or sales.c_fee_upd_flag = '')
         AND substr(wpb.c_prod_no, 0, 2) <> '03'
         AND (substr(wpc.c_cvrg_no, 0, 2) = '06' OR
             substr(wpc.c_cvrg_no, 0, 2) = '21')
            -- AND wpb.c_ply_no in(SELECT pp FROM aaa WHERE ee='无')  --  0722
            
            --  AND wpc.t_crt_tm BETWEEN begindate AND enddate
         AND sales.c_status = '0'
         and sales.c_send_num <= 3
         AND (wpc.t_crt_tm > sysdate - 1 or sales.t_upd_tm > sysdate - 1)
      
      ;
    --  子表
  
    ----------------------- 险种代码   非车  16大类
    INSERT INTO PRPSBUSINESSSUBFORWEB_temp
      (
       --ID                 ,-- 主键
       CERTINO, --      业务号
       CERTINO1,
       CERTITYPE, --        业务类型
       POLICYNO, --       保单号码
       CLASSCODE, --        险类代码
       RISKCODE, --       险种代码
       ITEMKINDNO, --         序号
       COMCODE, --      归属机构代码
       TEAMCODE, --       归属团队代码
       KINDCODE, --       险别代码（核心）
       KINDNAME, --       险别名称（核心）
       ACOUNTKINDCODE, --             险别代码（收付）
       ACOUNTKINDNAME, --             险别名称收付）
       --ACCOUNTKINDCODE    ,--              对应财务险别
       STARTDATE, --        起保日期
       ENDDATE, --      终保日期
       CURRENCY, --       承保币种
       PREMIUM, --      折扣后保费
       CHGPREMIUM, --         批改保险费变化值(批增或批减的值)
       CNYEXCHRATE, --          CNY的兑换率
       -- COINSRATE          ,--        共保份额
       -- COINSRATEFEE       ,--           共保金额
       -- UNITAMOUNT         ,--         每人赔偿限额(车上人员责任险)
       AMOUNT, --     累计赔偿限额
       --PERACCLIMITFEE     ,--             每次事故赔偿限额
       --SEATCOUNT          ,--        投保乘客座位数
       -- PERSEATFEE         ,--         每座保费
       GENERATEDATE, --           保批单生成日期
       CERTIID, --      --**流水号
       USERCODE, --       归属业务员工号
       CREATEDATE, --         创建时间
       UPDATEDATE, --         修改时间
       ISDUTYfREE, --         此险别是否免税
       TAXPREMIUM, --含税保费或含税保费变化量
       TAXRATE --险别税率
       )
      SELECT
      --PRPSBUSINESSSUBFORWEB_seq.Nextval,
       wpc.c_ply_no,
       wpc.c_ply_no,
       --(SELECT wpb.c_app_typ FROM web_ply_base wpb WHERE wpb.c_app_no = wpc.c_app_no),
       --wpb.c_app_typ,
       decode(wpb.c_app_typ, 'A', 'P', 'E', 'E'),
       wpc.c_ply_no,
       --(select c_kind_no from web_prd_prod wpp where wpp.c_prod_no=wpb.c_prod_no ),
       substr(wpb.c_prod_no, 1, 2),
       wpb.c_prod_no,
       --wpc.n_seq_no,
       number_seq.nextval, --  序号改为序列
       wpb.c_dpt_cde,
       wpb.c_salegrp_cde, -- tuandui
       wpc.c_cvrg_no,
       w1.c_nme_cn,
       nvl(w2.c_fin_prod, w3.c_fin_prod),
       nvl(w2.c_fin_prod_name, w3.c_fin_prod_name),
       --null,
       nvl((wpc.t_bgn_tm + 1 / 24 / 60 / 60),
           (wpb.t_insrnc_bgn_tm + 1 / 24 / 60 / 60)),
       nvl(wpc.t_end_tm, wpb.t_insrnc_end_tm),
       decode(wpb.c_prm_cur,
              '01',
              'CNY',
              '02',
              'HKD',
              '03',
              'USD',
              '04',
              'GBP',
              '12',
              'EUR',
              '05',
              'JPY'), -- 保费币种
       --wpb.c_prm_cur, --  保费币种
       --wpc.n_prm, --  折后保费
       --wacv.n_prm_clean, --XQ-6253,PREMIUM 由“折扣后保费”调整为“折扣后保费,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm
         else
          wacv.n_prm_clean
       end,
       --wpc.n_prm_var, -- 保费变化量
       --wacv.n_prm_var_clean, --XQ-6253,CHGPREMIUM 由“批改保险费变化值”调整为“批改保险费变化值,不含税”
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          wpc.n_prm_var
         else
          wacv.n_prm_var_clean
       end,
       wpb.n_prm_rmb_exch, --人民币汇率
       --null,
       --null,
       --null,
       nvl(wpc.n_indem_lmt, 0), --wpb.n_indem_lmt,-- 赔偿限额合计
       --null，
       --null,
       --null,
       wpb.t_crt_tm,
       PRPSBUSINESSSUBFORWEB_seq.Nextval,
       wpb.c_sls_id,
       wpc.t_crt_tm,
       wpc.t_upd_tm,
       /*NVL((SELECT c_vat_typ FROM web_bas_cvrg_vat_rate WHERE c_cvrg_no NOT LIKE '03%'
                        AND c_imporexp_mrk=(CASE WHEN wpb.c_imporexp_mrk='1' THEN '1'  ELSE '0' END)
                        AND c_cvrg_no=wpc.c_cvrg_no
                        AND c_insrnc_typ=(CASE WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)=365 THEN '2'
                            WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)>365 THEN '3'
                              WHEN TRUNC(wpc.t_bgn_tm-wpc.t_end_tm+1)<365 THEN '1' ELSE NULL END)),
       (SELECT c_vat_typ FROM web_bas_cvrg_vat_rate WHERE c_cvrg_no NOT LIKE '03%'
                         AND c_imporexp_mrk='0' AND c_cvrg_no=wpc.c_cvrg_no))*/ --         此险别是否免税
       NVL(rates.c_vat_typ, rates1.c_vat_typ), --         此险别是否免税
       --wpc.n_prm, --XQ-6253,含税保费或含税保费变化量
       --wacv.n_vat_rate --XQ-6253,险别税率
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wpc.n_prm
       end,
       case
         when 'N' = (select t.c_cde
                       from web_sys_sta_dict t
                      where t.c_par_cde like 'SalesVat%'
                        and wpb.t_crt_tm > t.t_trans_tm
                        and wpb.t_crt_tm < t.t_adb_tm) then
          null
         else
          wacv.n_vat_rate
       end
        FROM web_ply_cvrg wpc
        LEFT JOIN web_mid_fee_to_sales sales
          ON sales.c_app_no = wpc.c_app_no -- 送销管中间表
        left join web_ply_tgt tgt
          on wpc.c_app_no = tgt.c_app_no
        left join web_ply_base wpb
          on wpc.c_app_no = wpb.c_app_no
        left join web_prd_cvrg w1
          on w1.c_cvrg_no = wpc.c_cvrg_no
        left join web_mid_busprod_con_finprod w3
          on w3.c_bus_prod = wpb.c_prod_no
         and tgt.C_Tgt_Txt_Fld_2 = w3.c_hxtgt_cde
         AND (w3.c_resv_txt_1 = (CASE
               WHEN wpb.c_imporexp_mrk = '1' THEN
                '1'
               WHEN wpb.c_imporexp_mrk = '2' THEN
                '2'
               WHEN wpb.c_imporexp_mrk = '3' THEN
                '3'
               WHEN wpb.c_imporexp_mrk = '4' THEN
                '4'
               ELSE
                NULL
             END) or w3.c_resv_txt_1 is null)
        left join web_mid_busprod_con_finprod w2
          on w2.c_bus_cvrg_no = wpc.c_cvrg_no
         and tgt.C_Tgt_Txt_Fld_2 = w2.c_hxtgt_cde
         and (w2.c_resv_txt_1 = (CASE
               WHEN wpb.c_imporexp_mrk = '1' THEN
                '1'
               WHEN wpb.c_imporexp_mrk = '2' THEN
                '2'
               WHEN wpb.c_imporexp_mrk = '3' THEN
                '3'
               WHEN wpb.c_imporexp_mrk = '4' THEN
                '4'
               ELSE
                NULL
             END) or w2.c_resv_txt_1 IS NULL)
        left join web_bas_cvrg_vat_rate rates
          on substr(rates.c_cvrg_no, 0, 2) = '16'
         AND rates.c_cvrg_no = wpc.c_cvrg_no
         AND rates.c_imporexp_mrk = (CASE
                                       WHEN wpb.c_imporexp_mrk = '1' THEN
                                        '1'
                                       WHEN wpb.c_imporexp_mrk = '0' THEN
                                        '0'
                                       ELSE
                                        NULL
                                     END)
        left join web_bas_cvrg_vat_rate rates1
          on substr(rates1.c_cvrg_no, 0, 2) = '16'
         AND rates1.c_imporexp_mrk = '0'
         AND rates1.c_cvrg_no = wpc.c_cvrg_no
        left join (SELECT v.n_prm_clean,
                          v.n_vat_rate,
                          v.n_prm_var_clean,
                          v.c_vat_query_cde,
                          v.c_cvrg_no,
                          v.c_resv_txt_1
                     FROM web_app_cvrg_vat v
                    WHERE v.c_erti_type = 'premium'
                      AND v.c_app_typ = 'A') wacv
          on wacv.c_vat_query_cde = wpb.c_vat_query_cde
         AND wacv.c_cvrg_no = wpc.c_cvrg_no
         AND wacv.c_resv_txt_1 = wpc.n_seq_no
       WHERE substr(wpc.c_cvrg_no, 0, 2) = '16'
         AND WPB.C_APP_TYP = 'A'
         AND wpb.c_app_no = wpc.c_app_no
         and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null) --销管秒接中间表
         and (sales.c_fee_upd_flag is null or sales.c_fee_upd_flag = '')
            --AND wpb.c_ply_no in(SELECT pp FROM aaa WHERE ee='无')  --  0722
         AND EXISTS
       (SELECT a.c_app_no
                FROM web_ply_base a
               WHERE a.c_app_typ = 'A'
                 AND a.c_app_no = wpc.c_app_no
                    --AND a.c_renew_mrk IN('1','0')
                 AND substr(a.c_prod_no, 0, 2) = '16'
                 AND a.t_crt_tm BETWEEN begindate AND enddate) -- 主表保费变化量为0的不传销管
            
            --     AND wpc.t_crt_tm BETWEEN begindate AND enddate
            
         AND sales.c_status = '0'
         and sales.c_send_num <= 3
         AND (wpc.t_crt_tm > sysdate - 1 or sales.t_upd_tm > sysdate - 1)
      
      ;
  
  END;
  COMMIT;

  v_sql_code := 0;
  v_sql_msg  := 'NORMAL,SUCCESSFUL COMPLETION';

  SELECT SYSDATE INTO v_task_end_date FROM dual;

  INSERT INTO LOAD_HIS_LOG
    (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
  VALUES
    ('pcisv7',
     'ADD_PLY_INTOXG_P_NOT03',
     v_task_start_date,
     v_task_end_date,
     to_char((v_task_end_date - v_task_start_date) * 86400),
     v_sql_code,
     v_sql_msg);
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' || ':' || SQLERRM; --记录错误原因
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_P_NOT03',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    commit;
end ADD_PLY_INTOXG_P_NOT03;
/
