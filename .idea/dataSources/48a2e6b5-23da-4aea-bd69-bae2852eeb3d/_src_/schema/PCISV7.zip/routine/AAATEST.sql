CREATE procedure AAAtest is
 a number;
begin

  


select count(1) into a from dual where 1=a;

dbms_output.put_line(a);


end AAAtest;
/
