CREATE function F_rule_isUnionJQSY(v_app_no varchar2)
  return number
as
--根据投保单号判断是不是"交强、商业联合单"  1是，0不是
  v_count number ;
  v_n_id number(20);
  v_n_id_count number(20);
  v_app_no_JQ varchar2(50);
  v_app_no_SY varchar2(50);
begin
  --获取关联id
  select n_id into v_n_id from web_ply_relation k where c_ply_app_no = v_app_no and rownum <=1;

  --在表web_ply_relation中有n_id
  if v_n_id is not null then
    select count(1) into v_n_id_count
       from web_ply_relation where n_id = v_n_id;
    --是交商关联单
    if v_n_id_count = 2 then
      select c_ply_app_no into v_app_no_JQ
         from web_ply_relation  where n_id = v_n_id  and c_prod_no like '030%' and rownum <=1;
      select c_ply_app_no into v_app_no_SY
         from web_ply_relation  where n_id = v_n_id  and c_prod_no like '033%' and rownum <=1;
      --交强投保单号、商业投保单号都存在
      if v_app_no_JQ is not null and v_app_no_SY is not null then
         v_count := 1;
      else
         v_count := 0;
      end if;
    else
       v_count := 0;
    end if;
  else
     v_count := 0;
  end if;

  return v_count;
exception
  when others then
    return 0;
end;
/
