CREATE FUNCTION "F_GET_PLY_APP_NO" (CPlyNo in varchar2)/*输入保单号*/
return varchar2  --返回保单申请单号
as
 v_PLY_NO           varchar2(30);
 v_APP_PLY_NO       varchar2(30);
 V_NUM               number      ;

BEGIN
	 v_PLY_NO    :=CPlyNo ;
	 v_NUM          :=0;

  select COUNT(1) into v_NUM from WEB_PLY_BASE
	where C_APP_TYP='A'
  and C_PLY_NO=v_PLY_NO;

  if(v_NUM>0) then
	select C_APP_NO into v_APP_PLY_NO from WEB_PLY_BASE
	where  C_APP_TYP='A'
      and C_PLY_NO=v_PLY_NO;
      else
	      v_APP_PLY_NO := NULL;
  end if ;

return 	v_APP_PLY_NO;

exception
when others then
return null;

END F_GET_PLY_APP_NO;









/
