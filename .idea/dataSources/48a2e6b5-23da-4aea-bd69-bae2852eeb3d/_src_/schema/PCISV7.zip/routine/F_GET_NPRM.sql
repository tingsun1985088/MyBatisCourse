CREATE FUNCTION "F_GET_NPRM" (APLNO in varchar2 ) return  varchar2
as
--原始保单保费
  V_APLNO VARCHAR2(30);
  V_RESULT VARCHAR2(30);
  V_RESULT1 number;
begin
  V_APLNO:=APLNO;
  select PREREALPRM, rownum into V_RESULT,V_RESULT1 from t_edr e where e.aplno=V_APLNO and rownum=1 order by EDRSTARTDATE  ;
  return(V_RESULT);
  exception
when others then
return null;
end F_GET_NPRM;









/
