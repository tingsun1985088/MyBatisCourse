CREATE function get_edrsn(v_app_no varchar2,v_kind_no varchar2) return varchar2 is
--获取批改原因
  v_edrsn varchar2(1000) ;
  v_num   binary_integer;
  type t_tb is table of varchar2(20) index by binary_integer;
  v_return varchar2(1000) ;
  v_str    varchar2(1000) ;
  v_i       binary_integer;
  v_tb t_tb;
begin
  begin
    select count(*) into v_num from  web_edr_rsn  where c_edr_app_no = v_app_no;

  exception when no_data_found then
    v_num:=0;
  end;
  if v_num>0 then
     for i in 1..v_num loop

       begin

         select a.cde into v_edrsn from
             (select c_edr_rsn_cde as cde,rownum as num from web_edr_rsn
                where c_edr_app_no = v_app_no
                order by c_edr_rsn_cde ) a where a.num = i;
        -- v_i:=i;
         v_tb(i):=v_edrsn;
       end;
     end loop;
     for i in 1..v_num loop
       begin
         select rsn.c_rsn_nme into v_str from  web_bas_edr_rsn rsn
                where rsn.c_kind_no = v_kind_no and rsn.c_rsn_cde = v_tb(i);
         if i = 1 then
           v_return:= v_str;
         else
           v_return:=v_return || ';' || v_str;
         end if;
       end;
     end loop;
   end if;
   return v_return;
end get_edrsn;
/
