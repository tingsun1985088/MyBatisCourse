CREATE function F_c_cha_subtype(v_cha_subtype varchar2)
  return varchar2 as
  v_cha_subtype_nme  varchar2(100);
                     ----返回业务来源，如直销业务-员工直销-员工直销
begin
    v_cha_subtype_nme:=v_cha_subtype;

    select decode(v_cha_subtype,
                  '1900101001',
                  '直销业务-员工直销-员工直销',
                  '1900102001',
                  '直销业务-公司业务-非招标公司业务',
                  '1900102002',
                  '直销业务-公司业务-招标公司业务',
                  '1900103001',
                  '直销业务-股东业务-股东业务',
                  '1900106001',
                  '直销业务-其他直销-其他直销',
                  '1900201001',
                  '代理业务-专业代理-专业代理',
                  '1900202001',
                  '代理业务-兼业代理-车商代理',
                  '1900202002',
                  '代理业务-兼业代理-银邮代理',
                  '1900202999',
                  '代理业务-兼业代理-其他兼业代理',
                  '1900203001',
                  '代理业务-个人代理-个人代理',
                  '1900301001',
                  '经纪业务-经纪业务-经纪业务',
                  v_cha_subtype)
      into v_cha_subtype_nme
      from dual;

  return v_cha_subtype_nme;
exception
  when others then
    return v_cha_subtype;
end;
/
