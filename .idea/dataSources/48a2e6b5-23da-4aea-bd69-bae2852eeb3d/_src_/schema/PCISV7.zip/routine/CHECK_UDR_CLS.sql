CREATE procedure check_udr_cls(c_app_no   in varchar2, --传入的投保单号
                                          c_cur_cls  in varchar2, --传入的当前核保级别
                                          c_prond_no in varchar2, --传入的产品号
                                          flag       out varchar2, --上报/通过 标识
                                          PROMPT     out varchar2) is
  --返回内容 (险别_当前核保级别_校验结果根据条件种类拆分的明细 eg :033005_03601_110110)
  c_Usage_Cde     web_app_vhl.c_Usage_Cde%type; --使用性质
  c_Usage_Cde_sql varchar2(200); --查询使用性质sql
   c_min_base_undr_cls  web_app_base.c_min_base_undr_dpt%type;--基准最低核保级别
   c_min_base_undr_cls_sql varchar2(200);     --获取基准最低核保级别sql
  v_isCvrg_sql    varchar2(200); --校验是否投保该险别sql
  c_isCvrg_count  number; --是否投保该险别    -- 0 未投保  大于0 投保
  rule_sql        web_udr_report_prompt.c_check_sql%type; --要执行的校验sql
  c_cvrg_no       web_udr_report_prompt.c_cvrg_no%type; --对应的险别
  check_result    number; -- 规则sql执行的结果
  cursor udr_cls_cursor is
    select REPLACE(t.c_check_sql, '?', c_app_no) as checksql, c_cvrg_no
      from web_udr_report_prompt t
     where c_udr_cls = c_cur_cls
       and c_prond_no = c_prond_no; --对应产品号和核保级别的校验sql
begin
  flag := '1'; --0  超权限上报， 1 核保通过
  if c_app_no is null then
    flag   := '0';
    PROMPT := '申请单号不能为空';
  else
    --查询该单的使用性质
    c_Usage_Cde_sql := 'select c_Usage_Cde  from web_app_vhl where c_app_no = ''' ||c_app_no || '''';
     --获取基准最低核保级别
    c_min_base_undr_cls_sql:='select c_min_base_undr_cls from web_app_base where c_app_no = ''' ||c_app_no || '''';
    execute immediate c_Usage_Cde_sql into c_Usage_Cde;
    execute immediate c_min_base_undr_cls_sql into c_min_base_undr_cls;
      --如果当前核保级别小于最低基准核保级别（越小级别越高），则说明是触发了特殊规则 begin
      if c_cur_cls > c_min_base_undr_cls then
        --执行特殊规则返回上报提示(挪到程序中判断)
        open udr_cls_cursor;
        loop
          fetch udr_cls_cursor
            into rule_sql, c_cvrg_no;
          exit when udr_cls_cursor%notfound;
          --1: 首先判断该条校验sql是否对应此条投保单的使用性质，如果不对应则跳过；
          if instr(rule_sql, c_Usage_Cde) = 0 then
            continue;
          end if;
          begin
            --2：是否投保该险别，如果不投保则跳过
            c_isCvrg_count := 0;
            v_isCvrg_sql   := 'select count(*) from web_app_cvrg where c_app_no=''' ||
                              c_app_no || '''  and c_cvrg_no=''' || c_cvrg_no || '''';
            execute immediate v_isCvrg_sql into c_isCvrg_count;
            if c_isCvrg_count > 0 then
              --3：开始校验sql
              execute immediate rule_sql into check_result;
              if instr(check_result, 0) > 0 then --如果包含0 说明校验不过
                flag   := '0';
                PROMPT := PROMPT || c_cvrg_no || '_' || c_cur_cls || '_' ||check_result || '@';
              end if;
            end if;
          exception
            when no_data_found then
              null;
          end;
        end loop;
      end if;
  end if;
end;
/
