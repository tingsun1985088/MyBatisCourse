CREATE function       f_get_con_scale
  (v_c_doc_no varchar2,
   v_n_tms    number, /*赔案时传赔付次数*/
   v_type      integer /*1:保单;2:批单;3:赔案*/
  )
return number
as
  v_plyedr_no    varchar2(100);
  v_edr_no      varchar2(100);
  v_plyedr      integer;
  v_rpttm       date;
  v_count        int;
  v_scale        number;
begin
   v_scale:=1;
  case v_type
  when 1 then
    /*select DECODE( NVL(a.C_CONINSRNC_CDE, '00'), '00', 1,DECODE(a.N_PRM,0,1,d.N_CON_PRM/a.N_PRM) \*(SELECT MAX( N_CON_PROP ) FROM t_ply_con WHERE c_ply_no=a.c_ply_no AND C_CON_DPT_CDE = '9')*\ )\*将119001改9*\
    into  v_scale
    from t_ply_base a,t_ply_con d
    where a.c_ply_no=v_c_doc_no and a.c_ply_no=d.c_ply_no AND d.C_CON_DPT_CDE = '9';
  */
  V_COUNT:=0;
  select count(1) into V_COUNT from WEB_ply_cI a where a.C_PLY_NO=v_c_doc_no and a.N_EDR_PRJ_NO=0;
  if(V_COUNT>0) then
  select N_CI_SHARE into v_scale from WEB_ply_cI a where a.C_PLY_NO=v_c_doc_no and a.N_EDR_PRJ_NO=0;
  end if;
  when 2 then
   /* SELECT DECODE(NVL(B.C_CONINSRNC_CDE, '00'), '00', 1, DECODE(B.N_PRM,0,1,C.N_CON_PRM/pp.N_CON_PRM))
     INTO v_scale
     FROM T_EDR_BASE B,T_EDR_CON C,(select c_edr_no,sum(N_CON_PRM) N_CON_PRM from t_edr_con group by c_edr_no) pp
    WHERE B.C_EDR_NO=C.C_EDR_NO AND C.C_CON_DPT_CDE = '9' and b.c_edr_no=pp.c_edr_no
    AND B.C_EDR_NO =v_c_doc_no;  */
      V_COUNT:=0;
      select count(1) into V_COUNT from WEB_ply_cI a where a.C_EDR_NO=v_c_doc_no ;
   if(V_COUNT>0) then
    select N_CI_SHARE into v_scale from WEB_ply_cI a where a.C_EDR_NO=v_c_doc_no ;
  end if;
  /*when 3 then
    select  a.c_ply_no, a.t_crt_tm
      into  v_plyedr_no, v_rpttm
      from t_clm_main a,t_ply_base b
    where a.c_clm_no=v_c_doc_no and a.n_clm_tms=v_n_tms
    and a.c_ply_no=b.c_ply_no
    and b.C_CONINSRNC_CDE='01';

    select max(c_edr_no),count(*)
     into v_edr_no,v_count
     from t_edr_base
    where c_ply_no=v_plyedr_no
    and t_edr_bgn_tm <=v_rpttm
    and t_udr_date<=v_rpttm and c_edr_no is not null;

     if v_count=0 then
      return f_get_con_scale( v_plyedr_no, 0, 1);
     else   return f_get_con_scale( v_edr_no, 0, 2);
     end if;*/
  else
    return 1;
  end case;
  return v_scale;
exception
  when others then
      return 1;
end;

/
