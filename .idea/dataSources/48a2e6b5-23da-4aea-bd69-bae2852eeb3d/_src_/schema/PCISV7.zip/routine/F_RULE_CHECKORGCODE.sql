CREATE FUNCTION F_RULE_CHECKORGCODE(P_ORGCODE IN VARCHAR2)  RETURN INT IS
  C_REGSTR    VARCHAR2(2000);                                   --校验正则表达式
BEGIN
/*
*********************************************组织机构代码校验规则*********************************************
以下两条校验规则为或者关系
1)      传送格式为8位数字+0-9/X，例如“123456789” 或“12345678X”，平台对公司传送的组织机构代码证号码进行格式校验。
2)      传送的组织机构代码必须为18位，且仅能使用阿拉伯数字或英文字母，不允许录入其他字符。
*********************************************组织机构代码校验规则*********************************************

--返回是否符合组织机构代码校验规则：0：不符合；1：符合
*/
  CASE LENGTHB(P_ORGCODE)
    WHEN 9 THEN     -- 9位，传送格式为8位数字+0-9/X
      C_REGSTR := '^[0-9A-Z]{8}[0-9X]$';
      IF REGEXP_LIKE(P_ORGCODE, C_REGSTR) THEN  --正则校验通过
        RETURN 1; --1：符合校验规则
      ELSE
        RETURN 0; --0：不符合校验规则
      END IF;
    WHEN 18 THEN  -- 18位，仅能使用阿拉伯数字或英文字母，不允许录入其他字符
      C_REGSTR := '^[0-9a-zA-Z]{18}$';
      IF REGEXP_LIKE(P_ORGCODE, C_REGSTR) THEN  --正则校验通过
        RETURN 1; --1：符合校验规则
      ELSE
        RETURN 0; --0：不符合校验规则
      END IF;
    ELSE
      RETURN 0; -- 组织机构代码位数不对
  END CASE;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;  --异常返回不通过校验
END F_RULE_CHECKORGCODE;
/
