CREATE procedure ADD_PLY_INTOXG_GB(BEGINDATE IN DATE,
                                              ENDDATE   IN DATE) IS
  v_task_start_date date;
  v_task_end_date   date;
  v_sql_code        number;
  v_sql_msg         varchar2(4000) := ''; ---SQL错误信息

  /*************************************
  * 共保信息数据抽取到核心中间表总存过   *
  **************************************/

BEGIN

  select sysdate into v_task_start_date from dual;
  --  共保

  INSERT INTO PRPSBUSINESSCOINSFORWEB_temp
    (ID, --   主键
     CERTINO, --         业务号
     CERTITYPE, --           业务类型
     POLICYNO, --         保单号码
     SEQNO, --       序号
     COINSURERCODE, --               共保人代码
     COINSFLAG, --           主/从共标志
     COINSRATE, --           共保比例
     COINSAMOUNT, --             共保保额
     PREAMOUNT, --           共保保费
     COINSCOMM, --           代理经纪费(共保手续)
     PLYFEE, --       出单及相关费用
     COINSAMOUNTCHG, --               共保保额变化
     PREAMOUNTCHG, --             共保保费变化
     PLYFEECHG, --           出单费变化
     CREATEDATE, --           创建时间
     UPDATEDATE, --           修改时间
     TAXPREMIUM, --   含税保费或含税保费变化量
     TAXRATE --   共保税率
     )
  
    SELECT PRPSBUSINESSCOINSFORWEB_seq.Nextval,
           NVL(wpci.c_edr_no, wpci.c_ply_no),
           --(SELECT wpb.c_app_typ FROM web_ply_base wpb WHERE wpb.c_app_no= wpci.c_app_no),
           decode(wpb.c_app_typ, 'A', 'P', 'E', 'E'),
           wpci.c_ply_no,
           wpci.n_seq_no,
           wpci.c_coinsurer_cde,
           wpci.c_chief_mrk, -- 主从标志
           wpci.n_ci_share,
           wpci.n_ci_amt,
           --wpci.n_ci_prm,
           /*CASE
             WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
              wapv.n_prm_clean * wpci.n_ci_share
             ELSE
              (CASE
                WHEN wpci.c_coinsurer_cde = '327001' THEN
                 wapv.n_prm_clean
                ELSE
                 wpci.n_ci_prm
              END)
           END, --XQ-6253,PREAMOUNT 由“共保保费”调整为"共保保费,不含税"*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              wpci.n_ci_prm
             else
              (CASE
                WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
                 wapv.n_prm_clean * wpci.n_ci_share
                ELSE
                 (CASE
                   WHEN wpci.c_coinsurer_cde = '327001' THEN
                    wapv.n_prm_clean
                   ELSE
                    wpci.n_ci_prm
                 END)
              END)
           end,
           wpci.n_comm,
           wpci.n_ply_fee,
           wpci.n_ci_amt_var,
           --wpci.n_ci_prm_var,
           /*CASE
             WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
              wapv.n_prm_var_clean * wpci.n_ci_share
             ELSE
              (CASE
                WHEN wpci.c_coinsurer_cde = '327001' THEN
                 wapv.n_prm_var_clean
                ELSE
                 wpci.n_ci_prm_var
              END)
           END, --XQ-6253,PREAMOUNTCHG 由“共保保费变化”调整为"共保保费变化,不含税"*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              wpci.n_ci_prm_var
             else
              (CASE
                WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
                 wapv.n_prm_var_clean * wpci.n_ci_share
                ELSE
                 (CASE
                   WHEN wpci.c_coinsurer_cde = '327001' THEN
                    wapv.n_prm_var_clean
                   ELSE
                    wpci.n_ci_prm_var
                 END)
              END)
           end,
           wpci.n_ply_fee_var,
           wpci.t_crt_tm,
           wpci.t_upd_tm,
           /*CASE
             WHEN wpb.c_app_typ = 'A' THEN
              wpci.n_ci_prm
             ELSE
              wpci.n_ci_prm_var
           END, --XQ-6253,含税保费或含税保费变化量*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              null
             else
              (CASE
                WHEN wpb.c_app_typ = 'A' THEN
                 wpci.n_ci_prm
                ELSE
                 wpci.n_ci_prm_var
              END)
           end,
           /*CASE
             WHEN (wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1') or
                  wpci.c_coinsurer_cde = '327001' THEN
              wapv.n_net_vat / wapv.n_net_prm
             ELSE
              0
           END --XQ-6253,共保税率*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              null
             else
              (CASE
                WHEN (wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1') or
                     wpci.c_coinsurer_cde = '327001' THEN
                 wapv.n_net_vat / wapv.n_net_prm
                ELSE
                 0
              END)
           end
    
      FROM web_ply_ci wpci
    --left join  web_ply_base a    on (a.c_Sys_Res   not  IN(select  distinct c_Sys_Res from web_ply_base where c_Sys_Res='ECARGO') OR a.c_sys_res IS NULL )
      left join web_ply_base wpb
        on wpb.c_app_no = wpci.c_app_no
      LEFT JOIN web_mid_fee_to_sales sales
        ON sales.c_app_no = wpb.c_app_no -- 送销管中间表
      left join web_app_base_vat wapv
        on wpb.c_vat_query_cde = wapv.c_vat_query_cde
      left join (select b.c_ply_no, b.t_crt_tm
                   from web_ply_base b
                  where b.c_app_typ = 'A') pb
        on pb.c_ply_no = wpb.c_ply_no
     where wpci.c_app_no = WPB.c_app_no
       and wpci.c_chief_mrk = '0'
       AND (wpb.c_Sys_Res NOT IN ('ECARGO') OR wpb.c_Sys_Res IS NULL)
       and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null)
       and (sales.c_fee_upd_flag is null or sales.c_fee_upd_flag = '')
       and wpb.c_ply_no not in
           ('1103711000102000920170001000',
            '1103711000102000920170001002',
            '1103711000102000920170001003',
            '1103711000102000920170001004',
            '1103711000102000920170001005',
            '1103711000102000920170001006',
            '1103711000102000920170001007',
            '1103711000102000920170001016',
            '1103711000102000920170001017',
            '1103711000102000920170001018',
            '1103711000102000920170001019',
            '1103711000102000920170001021',
            '1103711000102000920170001022')
       and wpci.t_crt_tm BETWEEN BEGINDATE AND ENDDATE;
  --wpci.t_upd_tm BETWEEN BEGINDATE AND ENDDATE;
  INSERT INTO PRPSBUSINESSCOINSFORWEB_temp
    (ID, --   主键
     CERTINO, --         业务号
     CERTITYPE, --           业务类型
     POLICYNO, --         保单号码
     SEQNO, --       序号
     COINSURERCODE, --               共保人代码
     COINSFLAG, --           主/从共标志
     COINSRATE, --           共保比例
     COINSAMOUNT, --             共保保额
     PREAMOUNT, --           共保保费
     COINSCOMM, --           代理经纪费(共保手续)
     PLYFEE, --       出单及相关费用
     COINSAMOUNTCHG, --               共保保额变化
     PREAMOUNTCHG, --             共保保费变化
     PLYFEECHG, --           出单费变化
     CREATEDATE, --           创建时间
     UPDATEDATE, --           修改时间
     TAXPREMIUM, --   含税保费或含税保费变化量
     TAXRATE --   共保税率
     )
  
    SELECT PRPSBUSINESSCOINSFORWEB_seq.Nextval,
           NVL(wpci.c_edr_no, wpci.c_ply_no),
           --(SELECT wpb.c_app_typ FROM web_ply_base wpb WHERE wpb.c_app_no= wpci.c_app_no),
           decode(wpb.c_app_typ, 'A', 'P', 'E', 'E'),
           wpci.c_ply_no,
           wpci.n_seq_no,
           wpci.c_coinsurer_cde,
           wpci.c_chief_mrk, -- 主从标志
           wpci.n_ci_share,
           wpci.n_ci_amt,
           --wpci.n_ci_prm,
           /*CASE
             WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
              wapv.n_prm_clean -
              (select sum(round(ci.n_ci_share * v.n_prm_clean, 2))
                 from web_ply_ci ci, web_app_base_vat v
                where ci.c_app_no = wpci.c_app_no
                  and v.c_vat_query_cde = wapv.c_vat_query_cde
                  and ci.c_chief_mrk = '0')
             ELSE
              (CASE
                WHEN wpci.c_coinsurer_cde = '327001' THEN
                 wapv.n_prm_clean
                ELSE
                 wpci.n_ci_prm
              END)
           END, --XQ-6253,PREAMOUNT 由“共保保费”调整为"共保保费,不含税"*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              wpci.n_ci_prm
             else
              (CASE
                WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
                 wapv.n_prm_clean -
                 (select sum(round(ci.n_ci_share * v.n_prm_clean, 2))
                    from web_ply_ci ci, web_app_base_vat v
                   where ci.c_app_no = wpci.c_app_no
                     and v.c_vat_query_cde = wapv.c_vat_query_cde
                     and ci.c_chief_mrk = '0')
                ELSE
                 (CASE
                   WHEN wpci.c_coinsurer_cde = '327001' THEN
                    wapv.n_prm_clean
                   ELSE
                    wpci.n_ci_prm
                 END)
              END)
           end,
           wpci.n_comm,
           wpci.n_ply_fee,
           wpci.n_ci_amt_var,
           --wpci.n_ci_prm_var,
           /*CASE
             WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
              wapv.n_prm_var_clean -
              (select sum(round(ci.n_ci_share * v.n_prm_var_clean, 2))
                 from web_ply_ci ci, web_app_base_vat v
                where ci.c_app_no = wpci.c_app_no
                  and v.c_vat_query_cde = wapv.c_vat_query_cde
                  and ci.c_chief_mrk = '0')
             ELSE
              (CASE
                WHEN wpci.c_coinsurer_cde = '327001' THEN
                 wapv.n_prm_var_clean
                ELSE
                 wpci.n_ci_prm_var
              END)
           END, --XQ-6253,PREAMOUNTCHG 由“共保保费变化”调整为"共保保费变化,不含税"*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              wpci.n_ci_prm_var
             else
              (CASE
                WHEN wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1' THEN
                 wapv.n_prm_var_clean -
                 (select sum(round(ci.n_ci_share * v.n_prm_var_clean, 2))
                    from web_ply_ci ci, web_app_base_vat v
                   where ci.c_app_no = wpci.c_app_no
                     and v.c_vat_query_cde = wapv.c_vat_query_cde
                     and ci.c_chief_mrk = '0')
                ELSE
                 (CASE
                   WHEN wpci.c_coinsurer_cde = '327001' THEN
                    wapv.n_prm_var_clean
                   ELSE
                    wpci.n_ci_prm_var
                 END)
              END)
           end,
           wpci.n_ply_fee_var,
           wpci.t_crt_tm,
           wpci.t_upd_tm,
           /*CASE
             WHEN wpb.c_app_typ = 'A' THEN
              wpci.n_ci_prm
             ELSE
              wpci.n_ci_prm_var
           END, --XQ-6253,含税保费或含税保费变化量*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              null
             else
              (CASE
                WHEN wpb.c_app_typ = 'A' THEN
                 wpci.n_ci_prm
                ELSE
                 wpci.n_ci_prm_var
              END)
           end,
           /*CASE
             WHEN (wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1') or
                  wpci.c_coinsurer_cde = '327001' THEN
              wapv.n_net_vat / wapv.n_net_prm
             ELSE
              0
           END --XQ-6253,共保税率*/
           case
             when 'N' = (select t.c_cde
                           from web_sys_sta_dict t
                          where t.c_par_cde like 'SalesVat%'
                            and pb.t_crt_tm > t.t_trans_tm
                            and pb.t_crt_tm < t.t_adb_tm) then
              null
             else
              (CASE
                WHEN (wpb.c_ci_mrk = '3' and wpb.c_ci_inp_typ = '1') or
                     wpci.c_coinsurer_cde = '327001' THEN
                 wapv.n_net_vat / wapv.n_net_prm
                ELSE
                 0
              END)
           end
    
      FROM web_ply_ci wpci
    --left join  web_ply_base a    on (a.c_Sys_Res   not  IN(select  distinct c_Sys_Res from web_ply_base where c_Sys_Res='ECARGO') OR a.c_sys_res IS NULL )
      left join web_ply_base wpb
        on wpb.c_app_no = wpci.c_app_no
      LEFT JOIN web_mid_fee_to_sales sales
        ON sales.c_app_no = wpb.c_app_no -- 送销管中间表
      left join web_app_base_vat wapv
        on wpb.c_vat_query_cde = wapv.c_vat_query_cde
      left join (select b.c_ply_no, b.t_crt_tm
                   from web_ply_base b
                  where b.c_app_typ = 'A') pb
        on pb.c_ply_no = wpb.c_ply_no
     where wpci.c_app_no = WPB.c_app_no
       and wpci.c_chief_mrk = '1'
       AND (wpb.c_Sys_Res NOT IN ('ECARGO') OR wpb.c_Sys_Res IS NULL)
       and (sales.c_to_sales_mrk = '0' or sales.c_to_sales_mrk is null)
       and (sales.c_fee_upd_flag is null or sales.c_fee_upd_flag = '')
       and wpb.c_ply_no not in
           ('1103711000102000920170001000',
            '1103711000102000920170001002',
            '1103711000102000920170001003',
            '1103711000102000920170001004',
            '1103711000102000920170001005',
            '1103711000102000920170001006',
            '1103711000102000920170001007',
            '1103711000102000920170001016',
            '1103711000102000920170001017',
            '1103711000102000920170001018',
            '1103711000102000920170001019',
            '1103711000102000920170001021',
            '1103711000102000920170001022')
       and wpci.t_crt_tm BETWEEN BEGINDATE AND ENDDATE;
  COMMIT;

  v_sql_code := 0;
  v_sql_msg  := 'NORMAL,SUCCESSFUL COMPLETION';
  SELECT SYSDATE INTO v_task_end_date FROM dual;

  INSERT INTO LOAD_HIS_LOG
    (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
  VALUES
    ('pcisv7',
     'ADD_PLY_INTOXG_GB',
     v_task_start_date,
     v_task_end_date,
     to_char((v_task_end_date - v_task_start_date) * 86400),
     v_sql_code,
     v_sql_msg);
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' || ':' || SQLERRM; --记录错误原因
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'ADD_PLY_INTOXG_GB',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
    commit;
end ADD_PLY_INTOXG_GB;
/
