CREATE PROCEDURE "AAAA" 
IS
 -- tmpsql VARCHAR2(100);
 -- tmpsql1 varchar2(100);
BEGIN
 -- SYS.DBMS_OUTPUT.PUT_LINE('hello world');
 -- tmpsql:='TRUNCATE TABLE WEB_GRT_MENU_TPW';
 -- tmpsql1:='TRUNCATE TABLE WEB_GRT_MENU_TPW_TMP';
 -- EXECUTE IMMEDIATE tmpsql;
 -- EXECUTE IMMEDIATE tmpsql1;
  
  ------------ edited by tpwang-----------------------------------------------------------------------
  --------------this section is  transected the WEB_GRT_MENU_TPW from  web_grt_menu------------------- 
 -- insert into WEB_GRT_MENU_TPW(c_oper_id, c_dpt_cde,C_OP_CDE,C_PARENT_CDE,C_OP_CNM,C_OP_ACT, N_OP_ORDER,C_OP_IMG, C_TARGET) 
 -- select c_oper_id,c_dpt_cde,C_OP_CDE,C_PARENT_CDE,C_OP_CNM,C_OP_ACT,N_OP_ORDER,C_OP_IMG,C_TARGET from web_grt_menu;
 -- insert into WEB_GRT_MENU_TPW_TMP (c_oper_id, c_dpt_cde,C_OP_CDE,C_PARENT_CDE,C_OP_CNM,C_OP_ACT, N_OP_ORDER,C_OP_IMG, C_TARGET)
  
  -------------this section is reserve table web_grt_menu where  the base table and itself both hava;
delete FROM WEB_GRT_MENU where(c_oper_id,c_dpt_cde,C_OP_CDE)  in 
  ((select c_oper_id,c_dpt_cde,C_OP_CDE from WEB_GRT_MENU_TPW)  --取菜单表集合
      MINUS
 select c_oper_id,c_dpt_cde,C_OP_CDE from      
(select opdiff.C_OPER_ID,opdiff.C_DPT_CDE,op.C_OP_CDE,op.C_PARENT_CDE,op.C_OP_CNM,dict.C_MAP_CDE||op.C_OP_ACT,op.N_OP_ORDER,op.C_OP_IMG,op.C_TARGET 
 FROM  WEB_GRT_USR_OP opdiff,WEB_GRT_OP op,WEB_SYS_STA_DICT dict,web_grt_usr_op_dpt usropdpt 
 WHERE opdiff.C_OP_CDE = op.C_OP_CDE AND op.C_SUB_SYS_CDE = dict.C_CDE AND dict.C_PAR_CDE ='grt_sub_sys' 
 and opdiff.C_ENABLED='1' and op.C_OP_TYPE='0' and usropdpt.C_OPER_ID = opdiff.C_OPER_ID 
 and usropdpt.C_DPT_CDE = opdiff.C_DPT_CDE
 UNION(SELECT usrRole.C_OPER_ID,usrRole.C_DPT_CDE,op.C_OP_CDE,op.C_PARENT_CDE,op.C_OP_CNM,dict.C_MAP_CDE||op.C_OP_ACT,op.N_OP_ORDER,op.C_OP_IMG,op.C_TARGET 
 FROM WEB_GRT_OP op,WEB_GRT_ROLE_OP rop,WEB_GRT_ROLE role,WEB_GRT_USR_ROLE usrRole,WEB_SYS_STA_DICT dict,web_grt_usr_op_dpt usropdpt 
 WHERE op.C_OP_CDE = rop.C_OP_CDE 
 AND role.C_OPGRP_CDE =usrRole.C_OPGRP_CDE AND op.C_SUB_SYS_CDE = dict.C_CDE AND dict.C_PAR_CDE ='grt_sub_sys' AND rop.C_OPGRP_CDE = role.C_OPGRP_CDE  
 AND op.C_OP_TYPE = '0' and usropdpt.C_OPER_ID = usrRole.C_OPER_ID and usropdpt.C_DPT_CDE = usrRole.C_DPT_CDE
 minus 
 SELECT opdiff.C_OPER_ID,opdiff.C_DPT_CDE,op.C_OP_CDE,op.C_PARENT_CDE,op.C_OP_CNM,dict.C_MAP_CDE||op.C_OP_ACT,op.N_OP_ORDER,op.C_OP_IMG,op.C_TARGET 
 FROM  WEB_GRT_USR_OP opdiff,WEB_GRT_OP op,WEB_SYS_STA_DICT dict,web_grt_usr_op_dpt usropdpt 
 WHERE opdiff.C_OP_CDE = op.C_OP_CDE AND op.C_SUB_SYS_CDE = dict.C_CDE AND dict.C_PAR_CDE ='grt_sub_sys' and opdiff.C_ENABLED='0' 
 and op.C_OP_TYPE='0'  and usropdpt.C_OPER_ID = opdiff.C_OPER_ID and usropdpt.C_DPT_CDE = opdiff.C_DPT_CDE)
 )
    );
    --commit;
-----------------insert into the different information where the base table only changed-------
insert into WEB_GRT_MENU(c_oper_id, c_dpt_cde,C_OP_CDE,C_PARENT_CDE,C_OP_CNM,C_OP_ACT,N_OP_ORDER, C_OP_IMG, C_TARGET) 
SELECT * FROM(
  (select opdiff.C_OPER_ID,opdiff.C_DPT_CDE,op.C_OP_CDE,op.C_PARENT_CDE,op.C_OP_CNM,dict.C_MAP_CDE||op.C_OP_ACT,op.N_OP_ORDER,op.C_OP_IMG,op.C_TARGET 
 FROM  WEB_GRT_USR_OP opdiff,WEB_GRT_OP op,WEB_SYS_STA_DICT dict,web_grt_usr_op_dpt usropdpt 
 WHERE opdiff.C_OP_CDE = op.C_OP_CDE AND op.C_SUB_SYS_CDE = dict.C_CDE AND dict.C_PAR_CDE ='grt_sub_sys' 
 and opdiff.C_ENABLED='1' and op.C_OP_TYPE='0' and usropdpt.C_OPER_ID = opdiff.C_OPER_ID 
 and usropdpt.C_DPT_CDE = opdiff.C_DPT_CDE
 UNION(SELECT usrRole.C_OPER_ID,usrRole.C_DPT_CDE,op.C_OP_CDE,op.C_PARENT_CDE,op.C_OP_CNM,dict.C_MAP_CDE||op.C_OP_ACT,op.N_OP_ORDER,op.C_OP_IMG,op.C_TARGET 
 FROM WEB_GRT_OP op,WEB_GRT_ROLE_OP rop,WEB_GRT_ROLE role,WEB_GRT_USR_ROLE usrRole,WEB_SYS_STA_DICT dict,web_grt_usr_op_dpt usropdpt 
 WHERE op.C_OP_CDE = rop.C_OP_CDE 
 AND role.C_OPGRP_CDE =usrRole.C_OPGRP_CDE AND op.C_SUB_SYS_CDE = dict.C_CDE AND dict.C_PAR_CDE ='grt_sub_sys' AND rop.C_OPGRP_CDE = role.C_OPGRP_CDE  
 AND op.C_OP_TYPE = '0' and usropdpt.C_OPER_ID = usrRole.C_OPER_ID and usropdpt.C_DPT_CDE = usrRole.C_DPT_CDE
 minus 
 SELECT opdiff.C_OPER_ID,opdiff.C_DPT_CDE,op.C_OP_CDE,op.C_PARENT_CDE,op.C_OP_CNM,dict.C_MAP_CDE||op.C_OP_ACT,op.N_OP_ORDER,op.C_OP_IMG,op.C_TARGET 
 FROM  WEB_GRT_USR_OP opdiff,WEB_GRT_OP op,WEB_SYS_STA_DICT dict,web_grt_usr_op_dpt usropdpt 
 WHERE opdiff.C_OP_CDE = op.C_OP_CDE AND op.C_SUB_SYS_CDE = dict.C_CDE AND dict.C_PAR_CDE ='grt_sub_sys' and opdiff.C_ENABLED='0' 
 and op.C_OP_TYPE='0'  and usropdpt.C_OPER_ID = opdiff.C_OPER_ID and usropdpt.C_DPT_CDE = opdiff.C_DPT_CDE) 
 
 MINUS
 SELECT c_oper_id, c_dpt_cde,C_OP_CDE,C_PARENT_CDE,C_OP_CNM,C_OP_ACT,N_OP_ORDER, C_OP_IMG, C_TARGET FROM WEB_GRT_MENU
 )
) ;

-- commit;
END;

/
