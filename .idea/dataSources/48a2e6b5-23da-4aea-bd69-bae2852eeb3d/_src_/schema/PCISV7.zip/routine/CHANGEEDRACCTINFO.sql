CREATE PROCEDURE "CHANGEEDRACCTINFO" 
is
   cursor edrItem_cursor is (select m.c_pk_id,m.c_edr_item from web_bas_edr_rsn_item m);
   v_pkId in m.c_pk_id%type;
   v_edrItem in m.c_edr_item%type;
begin
   open edrItem_cursor;
   loop
        fetch edrItem_cursor into (v_pkId,v_edrItem);
        if v_edrItem == 'Acctinfo'
          DBMS_OUTPUT.put_line("Delete then Add");
        exit when edrItem_cursor%notfound;
             dbms_output.put_line(v_pkId);
    end loop;
    close edrItem_cursor;
end changeEdrAcctInfo;







/
