CREATE PROCEDURE ECARGO_PRC AS
  temp_count        number;
  temp_count1       number;
  temp_count2       number;
  temp_count3       number;
  temp_count4       number;
  COCAGRNO          varchar2(200); --协议批改号
  COCAGREDRNO       varchar2(200); --协议批改号
  ISAGRORPOLICY     varchar2(200); --是否协议的批改  O协议修改，A保单，E保单批改
  prod_msg          varchar2(200); --原始数据产品信息
  prod_cvrg_msg     varchar2(200); --原始数据险别信息
  prod_edr_msg      varchar2(200); --批改数据产品信息
  prod_cvrg_edr_msg varchar2(200); --批改数据险别信息
  V_TASK_START_DATE DATE;
  V_TASK_END_DATE   DATE;
  V_SQL_CODE        NUMBER;
  V_SQL_MSG         VARCHAR2(4000) := ''; --SQL错误信息
  CRELATELEASTAPPNO varchar2(50); --关联的最新的协议批改申请单号
  CURSOR CUR_BASE_ECARGO IS
    SELECT C_OC_AGR_NO, --协议号
           N_SEQ, --序号
           C_CLNT_CDE, --客户编码
           C_CLNT_NME, --客户名称
           C_DPT_CDE, --出单机构
           C_SIGN_DPT_CDE, --签约机构
           C_BSNS_TYP, --业务来源
           C_BSNS_SUBTYP, --业务来源细分
           C_BRKR_CDE, --代理人
           C_SALEGRP_CDE, --销售团队
           C_SLS_CDE, --业务员代码
           T_BGN_TM, --协议有效起期
           T_END_TM, --协议有效止期
           N_EST_YEAR_AMT, --预计年保险金额
           N_EST_YEAR_PRM, --预计年保险费
           C_AMT_CUR, --保额币种
           C_PRM_CUR, --保费币种
           C_LOAD_MRK, --自动带出信息标志
           C_EST_DESC, --预计理由
           C_OTHER_DESC, --其他协议内容
           C_APPR_CDE, --审核人
           C_APPR_OPN, --审核意见
           T_APPR_TM, --审核时间
           C_EDR_DESC, --批改说明
           C_OC_AGR_STS, --协议状态
           C_APPR_STS, --审核状态
           C_CRT_CDE,
           T_CRT_TM,
           C_UPD_CDE,
           T_UPD_TM,
           C_OC_AGR_EDR_NO, --协议批改号
           C_EDR_NO,
           C_PLY_NO,
           N_AMT_VAR, --保额变化
           N_PRM_VAR, --保费变化
           C_EDR_RSN, --批改理由
           IS_AGRORPOLICY, --是否协议的批改  O协议修改，A保单，E保单批改
           C_APP_NO,
           C_CHA_TYPE, --渠道中级分类
           C_OPEN_FINP, --传收付0为协议，1为小保单
           C_TRACT_NO, --合同编号
           C_CUS_RISK_LVL, --客户风险等级
           C_SLS_NME,
           C_RELATE_LEASTAPPNO, --关联的最新的协议批改申请单号
           C_SALEGRP_NME --销售团队名称
      FROM web_oc_base_ecargo
     where t_crt_tm >= to_date(to_char(sysdate -interval '30' minute, 'yyyy-MM-dd hh24:mi:ss'),
                               'yyyy-MM-dd hh24:mi:ss')
       and t_crt_tm <= to_date(to_char(sysdate, 'yyyy-MM-dd hh24:mi:ss'),
                               'yyyy-MM-dd hh24:mi:ss')
     order by t_crt_tm;
BEGIN
  --任务开始时间和任务结束时间
  SELECT SYSDATE INTO V_TASK_START_DATE FROM DUAL;
  SELECT SYSDATE INTO V_TASK_END_DATE FROM DUAL;

  FOR CUR_BASE_REC IN CUR_BASE_ECARGO LOOP
  
    temp_count    := 0;
    temp_count1   := 0;
    temp_count2   := 0;
    temp_count3   := 0;
    COCAGRNO      := CUR_BASE_REC.C_OC_AGR_NO; --协议号
    COCAGREDRNO   := CUR_BASE_REC.C_OC_AGR_EDR_NO; --协议批改号
    ISAGRORPOLICY := CUR_BASE_REC.IS_AGRORPOLICY; --是否协议的批改  O协议修改，A保单，E保单批改
    select count(*)
      into temp_count
      from web_oc_base_ecargo
     where C_OC_AGR_NO = COCAGRNO
       and C_OC_AGR_EDR_NO is null
       and IS_AGRORPOLICY = ISAGRORPOLICY; --查看此记录是否是原始数据
  
    if temp_count > 0 then
      --BASE原始数据
      select count(*)
        into temp_count2
        from web_oc_prod_ecargo
       where C_OC_AGR_EDR_NO is null
         and C_OC_AGR_NO = COCAGRNO; --查看PROD表的数据
    
      if temp_count2 > 0 then
        --PROD原始数据
        select count(*)
          into temp_count3
          from web_oc_prod_cvrg_ecargo
         where C_OC_AGR_EDR_NO is null
           and C_OC_AGR_NO = COCAGRNO; --查看CVRG表的数据
        if temp_count3 > 0 then
          --CVRG原始数据
          BEGIN
            insert into WEB_OC_BASE -- 插入BASE数据
              (C_OC_AGR_NO,
               N_SEQ,
               C_CLNT_CDE,
               C_CLNT_NME,
               C_DPT_CDE,
               C_SIGN_DPT_CDE,
               C_BSNS_TYP,
               C_BSNS_SUBTYP,
               C_BRKR_CDE,
               C_SALEGRP_CDE,
               C_SLS_CDE,
               T_BGN_TM,
               T_END_TM,
               N_EST_YEAR_AMT,
               N_EST_YEAR_PRM,
               C_AMT_CUR,
               C_PRM_CUR,
               C_LOAD_MRK,
               C_EST_DESC,
               C_OTHER_DESC,
               C_APPR_CDE,
               C_APPR_OPN,
               T_APPR_TM,
               C_EDR_DESC,
               C_OC_AGR_STS,
               C_APPR_STS,
               C_CRT_CDE,
               T_CRT_TM,
               C_UPD_CDE,
               T_UPD_TM,
               C_RELATE_LEASTAPPNO,
               C_CHA_TYPE,
               C_OPEN_FINP,
               C_TRACT_NO,
               C_CUS_RISK_LVL,
               C_SLS_NME,
               C_SALEGRP_NME, --销售团队名称
               C_SYS_RES)
            values
              (CUR_BASE_REC.C_OC_AGR_NO,
               CUR_BASE_REC.N_SEQ,
               CUR_BASE_REC.C_CLNT_CDE,
               CUR_BASE_REC.C_CLNT_NME,
               CUR_BASE_REC.C_DPT_CDE,
               CUR_BASE_REC.C_SIGN_DPT_CDE,
               CUR_BASE_REC.C_BSNS_TYP,
               CUR_BASE_REC.C_BSNS_SUBTYP,
               CUR_BASE_REC.C_BRKR_CDE,
               CUR_BASE_REC.C_SALEGRP_CDE,
               CUR_BASE_REC.C_SLS_CDE,
               CUR_BASE_REC.T_BGN_TM,
               CUR_BASE_REC.T_END_TM,
               CUR_BASE_REC.N_EST_YEAR_AMT,
               CUR_BASE_REC.N_EST_YEAR_PRM,
               CUR_BASE_REC.C_AMT_CUR,
               CUR_BASE_REC.C_PRM_CUR,
               CUR_BASE_REC.C_LOAD_MRK,
               CUR_BASE_REC.C_EST_DESC,
               CUR_BASE_REC.C_OTHER_DESC,
               CUR_BASE_REC.C_APPR_CDE,
               CUR_BASE_REC.C_APPR_OPN,
               CUR_BASE_REC.T_APPR_TM,
               CUR_BASE_REC.C_EDR_DESC,
               CUR_BASE_REC.C_OC_AGR_STS,
               CUR_BASE_REC.C_APPR_STS,
               CUR_BASE_REC.C_CRT_CDE,
               CUR_BASE_REC.T_CRT_TM,
               CUR_BASE_REC.C_UPD_CDE,
               CUR_BASE_REC.T_UPD_TM,
               CUR_BASE_REC.C_RELATE_LEASTAPPNO,
               CUR_BASE_REC.C_CHA_TYPE,
               CUR_BASE_REC.C_OPEN_FINP,
               CUR_BASE_REC.C_TRACT_NO,
               CUR_BASE_REC.C_CUS_RISK_LVL,
               CUR_BASE_REC.C_SLS_NME,
               CUR_BASE_REC.C_SALEGRP_NME, --销售团队名称
               'ECARGO');
            insert into web_oc_prod -- 插入PROD数据
              (C_PK_ID,
               C_PROD_NO,
               C_SEQ_NO,
               C_OC_AGR_NO,
               C_CRGO_TYP,
               C_CRGO_NME,
               C_PACK_WAY,
               C_CTR_MRK,
               C_FROM_AREA,
               C_FROM_PORT,
               C_TO_AREA,
               C_TO_PORT,
               C_TRANS_WAY,
               N_PER_LMT,
               N_AUTO_APPR_AMT,
               N_RATE,
               N_LOWEST_PRM,
               C_NC_DESC,
               N_NC_AMT,
               C_REMARK,
               C_CRT_CDE,
               T_CRT_TM,
               C_UPD_CDE,
               T_UPD_TM,
               N_SUB_COUNT,
               N_SUB_VLAID_COUNT,
               C_YUNSHU_CUR,
               C_HEBAO_CUR,
               C_ZUIDI_CUR)
              SELECT C_PK_ID,
                     C_PROD_NO,
                     C_SEQ_NO,
                     C_OC_AGR_NO,
                     C_CRGO_TYP,
                     C_CRGO_NME,
                     C_PACK_WAY,
                     C_CTR_MRK,
                     C_FROM_AREA,
                     C_FROM_PORT,
                     C_TO_AREA,
                     C_TO_PORT,
                     C_TRANS_WAY,
                     N_PER_LMT,
                     N_AUTO_APPR_AMT,
                     N_RATE,
                     N_LOWEST_PRM,
                     C_NC_DESC,
                     N_NC_AMT,
                     C_REMARK,
                     C_CRT_CDE,
                     T_CRT_TM,
                     C_UPD_CDE,
                     T_UPD_TM,
                     N_SUB_COUNT,
                     N_SUB_VLAID_COUNT,
                     C_YUNSHU_CUR,
                     C_HEBAO_CUR,
                     C_ZUIDI_CUR
                from web_oc_prod_ecargo
               where C_OC_AGR_EDR_NO is null
                 and C_OC_AGR_NO = COCAGRNO;
            insert into web_oc_prod_cvrg --插入CVRG数据
              (C_PK_ID,
               C_OC_AGR_NO,
               C_PROD_NO,
               N_SEQ_NO,
               C_CVRG_NO,
               C_CVRG_NME,
               C_CRT_CDE,
               T_CRT_TM,
               C_UPD_CDE,
               T_UPD_TM)
              select C_PK_ID,
                     C_OC_AGR_NO,
                     C_PROD_NO,
                     N_SEQ_NO,
                     C_CVRG_NO,
                     C_CVRG_NME,
                     C_CRT_CDE,
                     T_CRT_TM,
                     C_UPD_CDE,
                     T_UPD_TM
                from web_oc_prod_cvrg_ecargo
               where C_OC_AGR_EDR_NO is null
                 and C_OC_AGR_NO = COCAGRNO
               order by N_SEQ_NO;
            insert into web_oc_acctinfo
              (C_PK_ID,
               C_OC_AGR_NO,
               C_ACCT_NME,
               C_ACCT_NO,
               C_BANK_REL_CDE,
               C_BANK_PRO,
               C_BANK_AREA,
               C_BANK_CDE,
               C_BANK_COUNTY,
               C_BANK_REL_TYP,
               C_BANK_CNAPS,
               C_BANK_ADDR,
               C_PUB_PRI,
               C_SETTLEMENT_TYP,
               C_PAY_MODE_CDE,
               C_CRT_CDE,
               T_CRT_TM,
               C_UPD_CDE,
               T_UPD_TM)
              select C_PK_ID,
                     C_OC_AGR_NO,
                     C_ACCT_NME,
                     C_ACCT_NO,
                     C_BANK_REL_CDE,
                     C_BANK_PRO,
                     C_BANK_AREA,
                     C_BANK_CDE,
                     C_BANK_COUNTY,
                     C_BANK_REL_TYP,
                     C_BANK_CNAPS,
                     C_BANK_ADDR,
                     C_PUB_PRI,
                     C_SETTLEMENT_TYP,
                     C_PAY_MODE_CDE,
                     C_CRT_CDE,
                     T_CRT_TM,
                     C_UPD_CDE,
                     T_UPD_TM
                from web_oc_acctinfo_ecargo
               where C_OC_AGR_EDR_NO is null
                 and C_OC_AGR_NO = COCAGRNO;
          
            COMMIT;
            SELECT SYSDATE INTO v_task_end_date FROM dual;
            v_sql_code := 0;
            v_sql_msg  := 'NORMAL,SUCCESSFUL COMPLETION';
          
            INSERT INTO LOAD_HIS_LOG
              (SYS,
               JOBNAME,
               START_DATE,
               END_DATE,
               RUN_DATE,
               SQL_CODE,
               SQL_STATE)
            VALUES
              ('pcisv7',
               'ECARGO_PRC',
               v_task_start_date,
               v_task_end_date,
               to_char((v_task_end_date - v_task_start_date) * 86400),
               v_sql_code,
               v_sql_msg);
            COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              V_SQL_CODE := SQLCODE;
              V_SQL_MSG  := 'ecargo协议号：' || COCAGRNO || '，（批改协议号：' ||
                            COCAGRNO || '),抽数失败。' || SQLERRM;
              ROLLBACK;
              INSERT INTO load_his_log
                (sys,
                 jobname,
                 start_date,
                 end_date,
                 run_date,
                 sql_code,
                 sql_state)
              VALUES
                ('pcisv7_ecargo',
                 'ecargo协议推送核心',
                 V_TASK_START_DATE,
                 V_TASK_END_DATE,
                 (V_TASK_END_DATE - V_TASK_START_DATE) * 24 * 60 * 60,
                 V_SQL_CODE,
                 V_SQL_MSG);
              COMMIT;
          END;
        
        else
          prod_cvrg_msg := 'false,协议号：' || COCAGRNO || '没有相关险别数据';
          --插入错误数据
          INSERT INTO LOAD_HIS_LOG
            (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_STATE)
          VALUES
            ('pcisv7_ecargo',
             'ECARGO协议推送核心',
             v_task_start_date,
             v_task_end_date,
             (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
             prod_cvrg_msg);
        end if;
      else
        prod_msg := 'false,协议号：' || COCAGRNO || '没有相关产品数据';
        --插入错误数据
        INSERT INTO LOAD_HIS_LOG
          (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_STATE)
        VALUES
          ('pcisv7_ecargo',
           'ECARGO协议推送核心',
           v_task_start_date,
           v_task_end_date,
           (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
           prod_msg);
      end if;
    
    else
      select count(*)
        into temp_count4
        from web_oc_base
       where C_OC_AGR_NO = COCAGRNO; --查看此批改记录对应的原始数据是否存在
      if temp_count4 > 0 then
        select sys_guid() into CRELATELEASTAPPNO from dual;
        --批改数据
        select count(*)
          into temp_count2
          from web_oc_prod_ecargo
         where C_OC_AGR_EDR_NO = COCAGREDRNO
           and C_OC_AGR_NO = COCAGRNO; --查看PROD表的数据
      
        if temp_count2 > 0 then
          --PROD批改数据
          select count(*)
            into temp_count3
            from web_oc_prod_cvrg_ecargo
           where C_OC_AGR_EDR_NO = COCAGREDRNO
             and C_OC_AGR_NO = COCAGRNO; --查看CVRG表的数据
          if temp_count3 > 0 then
            --CVRG批改数据
            --批改数据
            BEGIN
              insert into web_oc_base_edr
                (C_OC_AGR_NO,
                 N_SEQ,
                 C_CLNT_CDE,
                 C_CLNT_NME,
                 C_DPT_CDE,
                 C_SIGN_DPT_CDE,
                 C_BSNS_TYP,
                 C_BSNS_SUBTYP,
                 C_BRKR_CDE,
                 C_SALEGRP_CDE,
                 C_SLS_CDE,
                 T_BGN_TM,
                 T_END_TM,
                 N_EST_YEAR_AMT,
                 N_EST_YEAR_PRM,
                 C_AMT_CUR,
                 C_PRM_CUR,
                 C_LOAD_MRK,
                 C_EST_DESC,
                 C_OTHER_DESC,
                 C_APPR_CDE,
                 C_APPR_OPN,
                 T_APPR_TM,
                 C_EDR_DESC,
                 C_OC_AGR_STS,
                 C_APPR_STS,
                 C_CRT_CDE,
                 T_CRT_TM,
                 C_UPD_CDE,
                 T_UPD_TM,
                 C_OC_AGR_EDR_NO,
                 C_EDR_NO,
                 C_PLY_NO,
                 N_AMT_VAR,
                 N_PRM_VAR,
                 C_EDR_RSN,
                 IS_AGRORPOLICY,
                 C_APP_NO,
                 C_CHA_TYPE,
                 C_OPEN_FINP,
                 C_TRACT_NO,
                 C_CUS_RISK_LVL,
                 C_SLS_NME,
                 C_SALEGRP_NME,
                 C_SYS_RES) --销售团队名称
              values
                (CUR_BASE_REC.C_OC_AGR_NO,
                 CUR_BASE_REC.N_SEQ,
                 CUR_BASE_REC.C_CLNT_CDE,
                 CUR_BASE_REC.C_CLNT_NME,
                 CUR_BASE_REC.C_DPT_CDE,
                 CUR_BASE_REC.C_SIGN_DPT_CDE,
                 CUR_BASE_REC.C_BSNS_TYP,
                 CUR_BASE_REC.C_BSNS_SUBTYP,
                 CUR_BASE_REC.C_BRKR_CDE,
                 CUR_BASE_REC.C_SALEGRP_CDE,
                 CUR_BASE_REC.C_SLS_CDE,
                 CUR_BASE_REC.T_BGN_TM,
                 CUR_BASE_REC.T_END_TM,
                 CUR_BASE_REC.N_EST_YEAR_AMT,
                 CUR_BASE_REC.N_EST_YEAR_PRM,
                 CUR_BASE_REC.C_AMT_CUR,
                 CUR_BASE_REC.C_PRM_CUR,
                 CUR_BASE_REC.C_LOAD_MRK,
                 CUR_BASE_REC.C_EST_DESC,
                 CUR_BASE_REC.C_OTHER_DESC,
                 CUR_BASE_REC.C_APPR_CDE,
                 CUR_BASE_REC.C_APPR_OPN,
                 CUR_BASE_REC.T_APPR_TM,
                 CUR_BASE_REC.C_EDR_DESC,
                 CUR_BASE_REC.C_OC_AGR_STS,
                 CUR_BASE_REC.C_APPR_STS,
                 CUR_BASE_REC.C_CRT_CDE,
                 CUR_BASE_REC.T_CRT_TM,
                 CUR_BASE_REC.C_UPD_CDE,
                 CUR_BASE_REC.T_UPD_TM,
                 CUR_BASE_REC.C_OC_AGR_EDR_NO,
                 CUR_BASE_REC.C_EDR_NO,
                 CUR_BASE_REC.C_PLY_NO,
                 CUR_BASE_REC.N_AMT_VAR,
                 CUR_BASE_REC.N_PRM_VAR,
                 CUR_BASE_REC.C_EDR_RSN,
                 CUR_BASE_REC.IS_AGRORPOLICY,
                 'E-' || CRELATELEASTAPPNO,
                 CUR_BASE_REC.C_CHA_TYPE,
                 CUR_BASE_REC.C_OPEN_FINP,
                 CUR_BASE_REC.C_TRACT_NO,
                 CUR_BASE_REC.C_CUS_RISK_LVL,
                 CUR_BASE_REC.C_SLS_NME,
                 CUR_BASE_REC.C_SALEGRP_NME,
                 'ECARGO');
              update web_oc_base w
                 set w.c_relate_leastappno = 'E-' || CRELATELEASTAPPNO,
                     w.t_upd_tm            = sysdate
               where w.c_oc_agr_no = COCAGRNO;
              insert into web_oc_prod_edr -- 插入PROD数据
                (C_PK_ID,
                 C_PROD_NO,
                 C_SEQ_NO,
                 C_OC_AGR_NO,
                 C_CRGO_TYP,
                 C_CRGO_NME,
                 C_PACK_WAY,
                 C_CTR_MRK,
                 C_FROM_AREA,
                 C_FROM_PORT,
                 C_TO_AREA,
                 C_TO_PORT,
                 C_TRANS_WAY,
                 N_PER_LMT,
                 N_AUTO_APPR_AMT,
                 N_RATE,
                 N_LOWEST_PRM,
                 C_NC_DESC,
                 N_NC_AMT,
                 C_REMARK,
                 C_CRT_CDE,
                 T_CRT_TM,
                 C_UPD_CDE,
                 T_UPD_TM,
                 N_SUB_COUNT,
                 N_SUB_VLAID_COUNT,
                 C_OC_AGR_EDR_NO,
                 C_YUNSHU_CUR,
                 C_HEBAO_CUR,
                 C_ZUIDI_CUR)
                select C_PK_ID,
                       C_PROD_NO,
                       C_SEQ_NO,
                       C_OC_AGR_NO,
                       C_CRGO_TYP,
                       C_CRGO_NME,
                       C_PACK_WAY,
                       C_CTR_MRK,
                       C_FROM_AREA,
                       C_FROM_PORT,
                       C_TO_AREA,
                       C_TO_PORT,
                       C_TRANS_WAY,
                       N_PER_LMT,
                       N_AUTO_APPR_AMT,
                       N_RATE,
                       N_LOWEST_PRM,
                       C_NC_DESC,
                       N_NC_AMT,
                       C_REMARK,
                       C_CRT_CDE,
                       T_CRT_TM,
                       C_UPD_CDE,
                       T_UPD_TM,
                       N_SUB_COUNT,
                       N_SUB_VLAID_COUNT,
                       C_OC_AGR_EDR_NO,
                       C_YUNSHU_CUR,
                       C_HEBAO_CUR,
                       C_ZUIDI_CUR
                  from web_oc_prod_ecargo
                 where C_OC_AGR_EDR_NO = COCAGREDRNO
                   and C_OC_AGR_NO = COCAGRNO;
              insert into web_oc_prod_cvrg_edr --插入CVRG数据
                (C_PK_ID,
                 C_OC_AGR_NO,
                 C_PROD_NO,
                 N_SEQ_NO,
                 C_CVRG_NO,
                 C_CVRG_NME,
                 C_CRT_CDE,
                 T_CRT_TM,
                 C_UPD_CDE,
                 T_UPD_TM,
                 C_OC_AGR_EDR_NO)
                select C_PK_ID,
                       C_OC_AGR_NO,
                       C_PROD_NO,
                       N_SEQ_NO,
                       C_CVRG_NO,
                       C_CVRG_NME,
                       C_CRT_CDE,
                       T_CRT_TM,
                       C_UPD_CDE,
                       T_UPD_TM,
                       C_OC_AGR_EDR_NO
                  from web_oc_prod_cvrg_ecargo
                 where C_OC_AGR_EDR_NO = COCAGREDRNO
                   and C_OC_AGR_NO = COCAGRNO
                 order by N_SEQ_NO;
            
              insert into web_oc_acctinfo_edr
                (C_PK_ID,
                 C_OC_AGR_NO,
                 C_OC_AGR_EDR_NO,
                 C_ACCT_NME,
                 C_ACCT_NO,
                 C_BANK_REL_CDE,
                 C_BANK_PRO,
                 C_BANK_AREA,
                 C_BANK_CDE,
                 C_BANK_COUNTY,
                 C_BANK_REL_TYP,
                 C_BANK_CNAPS,
                 C_BANK_ADDR,
                 C_PUB_PRI,
                 C_SETTLEMENT_TYP,
                 C_PAY_MODE_CDE,
                 C_CRT_CDE,
                 T_CRT_TM,
                 C_UPD_CDE,
                 T_UPD_TM)
                select C_PK_ID,
                       C_OC_AGR_NO,
                       C_OC_AGR_EDR_NO,
                       C_ACCT_NME,
                       C_ACCT_NO,
                       C_BANK_REL_CDE,
                       C_BANK_PRO,
                       C_BANK_AREA,
                       C_BANK_CDE,
                       C_BANK_COUNTY,
                       C_BANK_REL_TYP,
                       C_BANK_CNAPS,
                       C_BANK_ADDR,
                       C_PUB_PRI,
                       C_SETTLEMENT_TYP,
                       C_PAY_MODE_CDE,
                       C_CRT_CDE,
                       T_CRT_TM,
                       C_UPD_CDE,
                       T_UPD_TM
                  from web_oc_acctinfo_ecargo
                 where C_OC_AGR_EDR_NO = COCAGREDRNO
                   and C_OC_AGR_NO = COCAGRNO;
            
              COMMIT;
              SELECT SYSDATE INTO v_task_end_date FROM dual;
              v_sql_code := 0;
              v_sql_msg  := 'NORMAL,SUCCESSFUL COMPLETION';
            
              INSERT INTO LOAD_HIS_LOG
                (SYS,
                 JOBNAME,
                 START_DATE,
                 END_DATE,
                 RUN_DATE,
                 SQL_CODE,
                 SQL_STATE)
              VALUES
                ('pcisv7',
                 'ECARGO_PRC',
                 v_task_start_date,
                 v_task_end_date,
                 to_char((v_task_end_date - v_task_start_date) * 86400),
                 v_sql_code,
                 v_sql_msg);
              COMMIT;
            EXCEPTION
              WHEN OTHERS THEN
                V_SQL_CODE := SQLCODE;
                V_SQL_MSG  := 'ecargo协议号：' || COCAGRNO || '，（批改协议号：' ||
                              COCAGRNO || '),抽数失败。' || SQLERRM;
                ROLLBACK;
                INSERT INTO load_his_log
                  (sys,
                   jobname,
                   start_date,
                   end_date,
                   run_date,
                   sql_code,
                   sql_state)
                VALUES
                  ('pcisv7_ecargo',
                   'ecargo协议推送核心',
                   V_TASK_START_DATE,
                   V_TASK_END_DATE,
                   (V_TASK_END_DATE - V_TASK_START_DATE) * 24 * 60 * 60,
                   V_SQL_CODE,
                   V_SQL_MSG);
                COMMIT;
            END;
          else
            prod_cvrg_edr_msg := 'false,批改协议号：' || COCAGREDRNO ||
                                 '没有相关险别数据';
            --插入错误数据
            INSERT INTO LOAD_HIS_LOG
              (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_STATE)
            VALUES
              ('pcisv7_ecargo',
               'ECARGO协议推送核心',
               v_task_start_date,
               v_task_end_date,
               (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
               prod_cvrg_edr_msg);
          end if;
        else
          prod_edr_msg := 'false,批改协议号：' || COCAGREDRNO || '没有相关产品数据';
          --插入错误数据
          INSERT INTO LOAD_HIS_LOG
            (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_STATE)
          VALUES
            ('pcisv7_ecargo',
             'ECARGO协议推送核心',
             v_task_start_date,
             v_task_end_date,
             (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
             prod_edr_msg);
        end if;
      else
        --插入错误数据
        prod_edr_msg := 'false,批改协议号：' || COCAGREDRNO || '没有对应的原始协议';
        INSERT INTO LOAD_HIS_LOG
          (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_STATE)
        VALUES
          ('pcisv7_ecargo',
           'ECARGO协议推送核心',
           v_task_start_date,
           v_task_end_date,
           (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
           prod_edr_msg);
      end if;
    
    end if;
  
  END LOOP;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    V_SQL_CODE := SQLCODE;
    V_SQL_MSG  := 'ecargo协议号：' || COCAGRNO || '，(批改协议号：' || COCAGREDRNO ||
                  '),抽取失败。' || SQLERRM;
  
    ROLLBACK to SP;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7_ecargo',
       'ECARGO协议推送核心',
       v_task_start_date,
       V_TASK_END_DATE,
       (v_task_end_date - v_task_start_date) * 24 * 60 * 60,
       V_SQL_CODE,
       V_SQL_MSG);
    COMMIT;
  
END;
/
