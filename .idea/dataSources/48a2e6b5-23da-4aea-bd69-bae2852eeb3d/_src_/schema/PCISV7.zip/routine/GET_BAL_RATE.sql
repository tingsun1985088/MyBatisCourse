CREATE FUNCTION       get_bal_rate(
    cur_no_1 IN VARCHAR2,
    cur_no_2 IN VARCHAR2,
    t_bal_tm date)
RETURN NUMBER AS
  hv_ret1 NUMBER;
    CURSOR curhv1 IS
        SELECT  N_CHG_RTE
        FROM t_chg_rate
         WHERE C_CUR_NO_1 = cur_no_1 AND C_CUR_NO_2 = '01'
         AND  t_effc_tm <= t_bal_tm
         AND t_expd_tm >= t_bal_tm;

        CURSOR curhv IS
            SELECT  hv_ret1*N_CHG_RTE FROM t_chg_rate
            WHERE C_CUR_NO_1 = '01' AND C_CUR_NO_2 = cur_no_2
                  AND  t_effc_tm <= t_bal_tm
                  AND t_expd_tm >= t_bal_tm;

   hv_ret NUMBER;

BEGIN
  OPEN curhv1;
          FETCH curhv1 INTO hv_ret1;
          IF curhv1%NOTFOUND THEN
               hv_ret1 := 1;
          END IF;
  CLOSE curhv1;

      OPEN curhv;
          FETCH curhv INTO hv_ret;
          IF curhv%NOTFOUND THEN
               RETURN 1;
          END IF;
       CLOSE curhv;

       RETURN hv_ret;
EXCEPTION
    WHEN  OTHERS THEN
            RETURN 1;

END;

/
