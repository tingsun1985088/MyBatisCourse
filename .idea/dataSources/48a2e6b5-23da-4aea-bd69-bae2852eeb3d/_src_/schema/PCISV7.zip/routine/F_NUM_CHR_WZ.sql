CREATE FUNCTION F_NUM_CHR_WZ (C_APP_NO in varchar2,C_NUM in NUMBER)
 return VARCHAR2
as
V_CAPPNO varchar2(100);
V_CNUM NUMBER ;
V_RESULT VARCHAR2(3999);
V_NUM number;
begin
V_CAPPNO :=C_APP_NO;
V_CNUM  :=C_NUM;
V_RESULT := '';
V_NUM :=0;
    select ((length(base.c_unfix_spc)-length(replace(base.c_unfix_spc,chr(10),'')))/lengthb(chr(10))+1) into V_NUM
    from
      web_ply_base base where base.C_APP_NO=V_CAPPNO;
 case
when  V_NUM>0 then

if(C_NUM>=v_num) then
    select base.c_unfix_spc into V_RESULT
    from
    web_ply_base base where base.C_APP_NO=V_CAPPNO;
else
    select
    (substr(base.c_unfix_spc,1,(select INSTR(base.c_unfix_spc,chr(10), 1,(V_CNUM-1)) from web_ply_base b where b.c_app_no = base.c_app_no))||'     更多内容，请详见特别约定清单') INTO V_RESULT
    from
    web_ply_base base where base.C_APP_NO=V_CAPPNO;
end if;
when  V_NUM<1 then
     V_RESULT := ' ';
end case;
   --获取指定chr（10;
return V_RESULT;
exception
when others then
return ' ';
end;
/
