CREATE FUNCTION "GET_SAVEAMT_SUM" (ctype   IN VARCHAR2, /* 标识：3-3年期，5-5年期, 6-5年期,  7,9-1年期*/
                          bgn_tm  IN DATE, /* 保险起期*/
                          end_tm  IN DATE, /* 保险止期*/
                          stat_tm IN DATE, /* 统计截止日期*/
                          saveamt  IN NUMBER /* 储金金额 */) RETURN NUMBER IS
    vsum      NUMBER(16, 2);
    fsum      NUMBER(16, 6);
    imonth    NUMBER;
    iday      NUMBER;
    vbgntm    DATE;
    vendtm    DATE;
    fprftrate NUMBER(8, 6);
    fpara     NUMBER(8, 6);
    vquerytm  DATE;

    /* 取出所有在保险期间内适用的利率*/
    CURSOR prft_rate(query_tm DATE) IS
      SELECT NVL(n_prft_rate, 0),
             t_bgn_tm,
             NVL(t_end_tm,
                 TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd'))
        FROM WEB_BAS_BANK_PROFIT
       WHERE (t_bgn_tm >= bgn_tm AND t_bgn_tm <= query_tm OR
             NVL(t_end_tm,
                  TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd')) >=
             bgn_tm AND NVL(t_end_tm,
                             TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'),
                                     'yyyy-mm-dd')) <= query_tm OR
             t_bgn_tm <= bgn_tm AND
             NVL(t_end_tm,
                  TO_DATE(TO_CHAR(SYSDATE, 'yyyy-mm-dd'), 'yyyy-mm-dd')) >=
             query_tm)
         AND c_remark =
             DECODE(ctype, '3', '0001', '5', '0002', '6', '0003','7','0007','9','0009')
       ORDER BY t_bgn_tm;
  BEGIN
    fsum      := 0;
    vsum      := 0;
    imonth    := 0;
    iday      := 0;
    fprftrate := 0;
    fpara     := 0;

    SELECT ROUND(MONTHS_BETWEEN(TO_DATE(TO_CHAR(end_tm, 'yyyymmdd'),
                                       'yyyymmdd') + 1,
                               TO_DATE(TO_CHAR(bgn_tm, 'yyyymmdd'),
                                       'yyyymmdd')))
      INTO imonth
      FROM DUAL;

    /* 类型错误*/
    IF ctype NOT IN ('3', '5', '6','7','9')
     THEN
      RETURN - 1;
    END IF;

    /* 3年期期限输入错误*/
    IF imonth > 36 AND ctype = '3' THEN
      RETURN - 2;
    END IF;

    /* 5年期期限输入错误*/
    IF imonth > 60 AND (ctype = '5' OR ctype = '6')
     THEN
      RETURN - 3;
    END IF;

    /* 1年期期限输入错误*/
      IF imonth > 12 AND (ctype = '7' OR ctype = '9')
       THEN
        RETURN - 3;
      END IF;
    /* 处理上浮利率*/
    IF ctype = '3' THEN
      fpara := 0.006;
    END IF;

    IF ctype = '5' THEN
      fpara := 0.009;
    END IF;

    IF ctype = '6'
     THEN
      fpara := 0.004;
    END IF;

    IF ctype = '7' OR  ctype = '9'
     THEN
      fpara := 0.0015;
    END IF;

    /* 判断是否过保险期限*/
    IF stat_tm > end_tm THEN
      vquerytm := TO_DATE(TO_CHAR(end_tm, 'yyyymmdd'), 'yyyymmdd');
    ELSE
      vquerytm := TO_DATE(TO_CHAR(stat_tm, 'yyyymmdd'), 'yyyymmdd');
    END IF;

    /* 取出按日计算出来的利率总和*/
    OPEN prft_rate(vquerytm);

    LOOP
      FETCH prft_rate
        INTO fprftrate, vbgntm, vendtm;

      EXIT WHEN prft_rate%NOTFOUND;

      IF bgn_tm > vbgntm THEN
        vbgntm := bgn_tm;
      END IF;

      IF end_tm < vendtm THEN
        vendtm := end_tm;
      END IF;

      IF vquerytm < vendtm THEN
        vendtm := vquerytm;
      END IF;

      fsum := fsum + (fprftrate + fpara) *
              (TO_DATE(TO_CHAR(vendtm, 'yyyymmdd'), 'yyyymmdd') -
              TO_DATE(TO_CHAR(vbgntm, 'yyyymmdd'), 'yyyymmdd') + 1);
    END LOOP;

    CLOSE prft_rate;

    /* 计算满期返还金额*/
    vsum :=  saveamt *  ( 1 +  fsum / 365 );
    RETURN(vsum);
  END;








/
