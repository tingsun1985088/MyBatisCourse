CREATE PROCEDURE "COMPREHENSIVEMAINTENANCE" (
    v_ply_no      WEB_fin_tmpmt.c_ply_no%type,
	v_edr_no      WEB_fin_tmpmt.c_edr_no%type,
	v_mt_type     WEB_fin_tmpmt.c_mt_type%type,
	v_sumamount1  WEB_fin_tmpmt.n_sumamount1%type,
	v_sumamount2  WEB_fin_tmpmt.n_sumamount2%type,
	v_yl1         WEB_fin_tmpmt.c_yl1%type,
	v_yl2         WEB_fin_tmpmt.c_yl2%type,
	v_succsflag  in out NUMBER)   IS

	v_pkid        WEB_FIN_TMPMT.C_TMPMT_PK_ID%TYPE;
	n_count			 number;

BEGIN

	 SELECT nvl(max(TO_NUMBER(C_TMPMT_PK_ID)),0)
	 INTO v_pkid
	 FROM WEB_fin_tmpmt;
	 v_pkid := v_pkid+1;

	 INSERT INTO WEB_fin_tmpmt
	 VALUES	(v_pkid,v_ply_no,v_edr_no,v_mt_type,v_sumamount1,v_sumamount2,v_yl1,v_yl2);
	 v_succsflag :=1;
EXCEPTION
  WHEN OTHERS THEN
  	   v_pkid := '1';
	   v_succsflag :=-1;

END Comprehensivemaintenance;











/
