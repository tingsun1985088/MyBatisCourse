CREATE function p_fin_bac_gotprm(NEDRPRJNO IN NUMBER, --批改次数
                                            CKINDNO   IN VARCHAR2, --产品大类
                                            CPLYNO    IN VARCHAR2, --保单号
                                            CPLYCUR   IN VARCHAR2, --币种
                                            CCVRGNO   IN VARCHAR2, --险别
                                            TTODAYTM  IN DATE --评估日
                                            ) return number is
  V_INWARD            WEB_PLY_BASE.C_INWD_MRK%TYPE; --分入业务标志
  V_CUR_NO            WEB_PLY_BASE.C_PRM_CUR%TYPE; --保费币种
  V_PROD_NO           WEB_PLY_BASE.C_PROD_NO%TYPE; --产品代码，也称为险种，如0901
  V_PLY_NO            WEB_PLY_BASE.C_PLY_NO%TYPE; --保单号
  V_EDR_NO            WEB_PLY_BASE.C_EDR_NO%TYPE; --批单号
  V_EDR_PRJ_NO        WEB_PLY_BASE.N_EDR_PRJ_NO%TYPE; --批改次数
  V_EDR_TYPE          WEB_PLY_BASE.C_EDR_TYPE%TYPE; --批改类型
  V_COINSRNC_FLG      WEB_PLY_BASE.C_CI_MRK%TYPE; --共保标志
  V_TRAN_FLAG         WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE; --业务单据标志   自营-分入-共保
  V_INSRNC_BGN_TM     WEB_PLY_BASE.T_INSRNC_BGN_TM%TYPE; --保险起期
  V_INSRNC_END_TM     WEB_PLY_BASE.T_INSRNC_END_TM%TYPE; --保险止期
  V_CAL_AMT           NUMBER(16, 2); /*提取金额-法定*/
  V_INSRNC_CDE        WEB_PLY_CVRG.C_CVRG_NO%TYPE; --险别代码
  V_AMT               WEB_PLY_CVRG.N_AMT%TYPE; --险别金额
  V_PRM               WEB_PLY_CVRG.N_PRM%TYPE; --险别保费  准备金提取时细化到单个险别的层面
  T_TODAY_TM          DATE;
  V_INSRNC_BGN_TM_PLY DATE; --保单起期
  V_INSRNC_END_TM_PLY DATE; --保单止期
  NUM                 INT; --错误点标记
  V_EDR_RSN           WEB_PLY_BASE.C_EDR_RSN_BUNDLE_CDE%TYPE; --批改原因，保单的批改原因为'0'
  V_GOT_PRM           NUMBER(16, 2);
  V_NOPRM_SUM         NUMBER(16, 2);

  v_ri_prm NUMBER(20, 2); --再保分出保费
  v_ri_fee number(20, 2); --再保分出手续费
  ----------------------------------------------------------------
  CURSOR CUR_PLYEDR_VHL IS
    SELECT BASE.C_PLY_NO,
           NVL(BASE.C_EDR_NO, '---'), /*保单没有批单号*/
           BASE.N_EDR_PRJ_NO,
           BASE.C_PRM_CUR,
           BASE.C_PROD_NO,
           BASE.C_INWD_MRK, --分入业务标志
           BASE.T_INSRNC_BGN_TM,
           BASE.T_INSRNC_END_TM,
           BASE.C_CI_MRK, -- 共保标志
           NVL(BASE.C_EDR_TYPE, '0'), --批改类型,0为保单
           CVRG.C_CVRG_NO, /*险别代码*/
           NVL(CVRG.N_AMT, 0), --保额
           CVRG.N_PRM, -- 保费
           TRUNC(BASE.T_INSRNC_BGN_TM),
           BASE.T_INSRNC_END_TM,
           NVL(BASE.C_EDR_RSN_BUNDLE_CDE, '0') --批改原因
    
      FROM WEB_PLY_BASE BASE, WEB_PLY_CVRG CVRG
     WHERE BASE.C_EDR_NO IS NULL
       AND BASE.N_EDR_PRJ_NO = '0'
       AND BASE.C_PLY_NO = CPLYNO
       AND SUBSTR(BASE.C_PROD_NO, 1, 2) IN ('03', '06') --车险细化到险别
       AND BASE.C_APP_NO = CVRG.C_APP_NO(+) --分险别
       AND CVRG.C_CVRG_NO = CCVRGNO
       AND TRUNC(BASE.T_INSRNC_BGN_TM) <= T_TODAY_TM --已起保
       AND BASE.T_UDR_TM IS NOT NULL --针对倒签单的情况
    UNION ALL
    ----------------------------批单数据的提取，车险细化到险别，----------------------------------------
    SELECT EDRBASE.C_PLY_NO,
           NVL(EDRBASE.C_EDR_NO, '---'),
           EDRBASE.N_EDR_PRJ_NO,
           EDRBASE.C_PRM_CUR,
           EDRBASE.C_PROD_NO,
           EDRBASE.C_INWD_MRK, --分入业务标志
           EDRBASE.T_EDR_BGN_TM,
           NVL(EDRBASE.T_EDR_END_TM, EDRBASE.T_INSRNC_END_TM),
           EDRBASE.C_CI_MRK,
           EDRBASE.C_EDR_TYPE,
           EDRCVRG.C_CVRG_NO,
           NVL(EDRCVRG.N_AMT_VAR, 0), -- 保额变化=批单保额-上一批单（保单）保额
           EDRCVRG.N_PRM_VAR, --保费变化，批单保费上一批单（保单）保费'
           EDRBASE.T_INSRNC_BGN_TM,
           EDRBASE.T_INSRNC_END_TM,
           NVL(EDRBASE.C_EDR_RSN_BUNDLE_CDE, '0') --批改原因
      FROM WEB_PLY_BASE EDRBASE, WEB_PLY_CVRG EDRCVRG
     WHERE EDRBASE.C_EDR_NO IS NOT NULL
       AND EDRBASE.N_EDR_PRJ_NO < NEDRPRJNO
       AND EDRBASE.C_PLY_NO = CPLYNO
       AND EDRBASE.C_EDR_NO = EDRCVRG.C_EDR_NO(+) --分险别
       AND EDRCVRG.C_CVRG_NO = CCVRGNO
       AND EDRCVRG.N_PRM_VAR <> 0 --保费发生变化
       AND SUBSTR(EDRBASE.C_PROD_NO, 1, 2) IN ('03', '06') --车险大类
       AND TRUNC(EDRBASE.T_EDR_BGN_TM) <= T_TODAY_TM --已生效
       AND EDRBASE.T_UDR_TM IS NOT NULL;

  CURSOR CUR_PLYEDR_NOVHL IS
  ---------------------------保单数据的提取，非车只需要到险种就可以---------------------------------------
    SELECT BASE.C_PLY_NO,
           NVL(BASE.C_EDR_NO, '---'), /*保单没有批单号*/
           BASE.N_EDR_PRJ_NO,
           BASE.C_PRM_CUR,
           BASE.C_PROD_NO,
           BASE.C_INWD_MRK, --分入业务标志
           BASE.T_INSRNC_BGN_TM,
           BASE.T_INSRNC_END_TM,
           BASE.C_CI_MRK,
           BASE.C_EDR_TYPE, --批改类型
           '---', --险别代码，非车险不细算到险别
           NVL(BASE.N_AMT, 0),
           BASE.N_PRM,
           TRUNC(BASE.T_INSRNC_BGN_TM),
           BASE.T_INSRNC_END_TM,
           NVL(BASE.C_EDR_RSN_BUNDLE_CDE, '0') --批改原因
      FROM WEB_PLY_BASE BASE
     WHERE BASE.C_EDR_NO IS NULL
       AND BASE.N_EDR_PRJ_NO = '0'
       AND BASE.C_PLY_NO = CPLYNO
       AND SUBSTR(BASE.C_PROD_NO, 1, 2) not in ('03', '06') --非车只细化到险种
       AND TRUNC(BASE.T_INSRNC_BGN_TM) <= T_TODAY_TM --已起保
       AND BASE.T_UDR_TM IS NOT NULL --针对倒签单的情况
    
    UNION ALL
    ----------------------------------------------批单数据的提取，非车只是到险种-----------------------------------
    SELECT EDRBASE.C_PLY_NO,
           NVL(EDRBASE.C_EDR_NO, '---'),
           EDRBASE.N_EDR_PRJ_NO,
           EDRBASE.C_PRM_CUR,
           EDRBASE.C_PROD_NO,
           EDRBASE.C_INWD_MRK, --分入业务标志
           EDRBASE.T_EDR_BGN_TM,
           NVL(EDRBASE.T_EDR_END_TM, EDRBASE.T_INSRNC_END_TM),
           EDRBASE.C_CI_MRK,
           EDRBASE.C_EDR_TYPE,
           '---',
           NVL(EDRBASE.N_AMT_VAR, 0),
           EDRBASE.N_PRM_VAR, --updated by ctt 2011-06-23
           EDRBASE.T_INSRNC_BGN_TM,
           EDRBASE.T_INSRNC_END_TM,
           NVL(EDRBASE.C_EDR_RSN_BUNDLE_CDE, '0') --批改原因
    
      FROM WEB_PLY_BASE EDRBASE
     WHERE EDRBASE.C_EDR_NO IS NOT NULL
       AND EDRBASE.N_EDR_PRJ_NO < NEDRPRJNO
       AND EDRBASE.C_PLY_NO = CPLYNO
       AND EDRBASE.N_PRM_VAR <> 0 --保费发生变化
       AND SUBSTR(EDRBASE.C_PROD_NO, 1, 2) not in ('03', '06') --非车险大类
       AND TRUNC(EDRBASE.T_EDR_BGN_TM) <= T_TODAY_TM --已生效
       AND EDRBASE.T_UDR_TM IS NOT NULL;
BEGIN
  T_TODAY_TM  := TTODAYTM;
  V_NOPRM_SUM := 0;
  IF CCVRGNO = '---' THEN
    OPEN CUR_PLYEDR_NOVHL;
    LOOP
      FETCH CUR_PLYEDR_NOVHL
        INTO V_PLY_NO,
             V_EDR_NO,
             V_EDR_PRJ_NO,
             V_CUR_NO,
             V_PROD_NO,
             V_INWARD,
             V_INSRNC_BGN_TM,
             V_INSRNC_END_TM,
             V_COINSRNC_FLG,
             V_EDR_TYPE,
             V_INSRNC_CDE,
             V_AMT,
             V_PRM,
             V_INSRNC_BGN_TM_PLY,
             V_INSRNC_END_TM_PLY,
             V_EDR_RSN;
      EXIT WHEN CUR_PLYEDR_NOVHL%NOTFOUND;
      --对批单止期没有时分秒的进行处理
      if to_char(v_insrnc_end_tm, 'hh24:mi:ss') = '00:00:00' and
         nvl(v_edr_no, '---') <> '---' then
        v_insrnc_end_tm     := to_date(to_char(v_insrnc_end_tm,
                                               'yyyy-mm-dd') || ' 23:59:59',
                                       'yyyy-mm-dd hh24:mi:ss');
        v_insrnc_end_tm_ply := v_insrnc_end_tm;
      end if;
      --判断业务性质
      IF V_INWARD = '0' THEN
        V_TRAN_FLAG := '1'; --自营
      ELSIF V_INWARD = '1' THEN
        V_TRAN_FLAG := '2'; --分入
      ELSE
        V_TRAN_FLAG := '1';
      END IF;
    
      IF V_COINSRNC_FLG = '3' THEN
        V_TRAN_FLAG := '3'; --共保
      END IF;
    
      --共保时直接取得共保我司净保额 zengshaotao 2010-08-24
      IF V_COINSRNC_FLG = '3' THEN
        NUM := 1;
        SELECT N_CI_OWN_AMT /*共保我司净保额*/, N_CI_OWN_PRM /*共保我司净保费*/
          INTO V_AMT, V_PRM
          FROM (SELECT C_PLY_NO, C_EDR_NO, N_CI_OWN_AMT, N_CI_OWN_PRM
                  FROM WEB_PLY_BASE
                 WHERE C_EDR_NO IS NULL
                UNION
                SELECT C_PLY_NO,
                       C_EDR_NO,
                       N_CI_AMT_VAR N_CI_OWN_AMT,
                       N_CI_PRM_VAR N_CI_OWN_PRM
                  FROM WEB_PLY_CI /*共保信息*/
                 WHERE C_EDR_NO IS NOT NULL
                   AND /*C_COINSURER_CDE \* 共保人*\
                       = '327001'*/ C_SELF_MRK = '1'/*20140530 新增共保公司代码修改*/)
         WHERE C_PLY_NO = V_PLY_NO
           AND NVL(C_EDR_NO, '---') = NVL(V_EDR_NO, '---'); ---updated by ctt 2011-01-04
        NUM := 0;
      END IF;
    
      --根据传入的币种查询对应的分出保费
      select  nvl(n_prm,0),  nvl(n_fee,0)
        into v_ri_prm, v_ri_fee
        from (select sum(n_prm) n_prm, sum(n_fee) n_fee
                from web_fin_ri_plyedr a
               where c_ply_no = V_PLY_NO
                 and c_edr_no = V_EDR_NO
                 and c_prm_cur = CPLYCUR);
    
      /*if (V_CUR_NO = CPLYCUR) --如果传入的币种与原保单币种相同，再保后保费
       then
        V_PRM := V_PRM - v_ri_prm;
      else
        \*if CPLYCUR is not null --如果币种不相同，并且传入的币种不为空
        then*\
        V_PRM := 0 - v_ri_prm;
      end if;*/
      
      --将再保前保费及手续费转换成人民币
        if V_CUR_NO <> '01'
          then 
            v_prm := v_prm * get_rate(V_CUR_NO, '01', t_today_tm);
           -- v_fee := v_fee * get_rate(V_CUR_NO, '01', t_today_tm);
        end if;
        
        --将再保分出保费及手续费转换成人民币
        if CPLYCUR <> '01'
          then 
            v_ri_prm := v_ri_prm * get_rate(CPLYCUR, '01', t_today_tm);
            v_ri_fee := v_ri_fee * get_rate(CPLYCUR, '01', t_today_tm);
        end if;
        
        --再保后保费
        v_prm := v_prm - v_ri_prm;
      
    
      IF NVL(V_EDR_NO, '---') = '---' THEN
        /*保单*/
        /*满期保费  ＝ 保单保费/保险止期-保险起期+1×(评估日－保险起期+1)
        未满期保费 ＝ 保单保费 － 满期保费*/
        V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                     (V_INSRNC_END_TM - V_INSRNC_BGN_TM);
        V_CAL_AMT := V_PRM - V_GOT_PRM;
      
      ELSE
        IF V_EDR_RSN = 'c1' THEN
          --注销保单,那保单对应的批单呢?就不用管吗?'22'
          /*
          满期保费＝－保单保费×评估日-保险起期+1/保险止期-保险起期+1
          未满期保费＝－保单保费－满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM_PLY) /
                       (V_INSRNC_END_TM_PLY - V_INSRNC_BGN_TM_PLY);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        ELSIF V_EDR_RSN = 'c2' THEN
          /*'23'*/
          /*满期保费＝保单保费×评估日-保险起期+1/保险止期-保险起期+1
          未满期保费＝保单保费－满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM_PLY) /
                       (V_INSRNC_END_TM_PLY - V_INSRNC_BGN_TM_PLY);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        
        ELSIF V_EDR_RSN = 'c3' THEN
          /*'24'*/
          /*满期保费＝－被注销批单满期保费
          未满期保费＝－被注销批单未满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                       (V_INSRNC_END_TM - V_INSRNC_BGN_TM);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        ELSIF V_EDR_RSN = 'c5' THEN
          /*'25'*/
          /*满期保费＝被注销批单满期保费
          未满期保费＝被注销保单未满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                       (V_INSRNC_END_TM - V_INSRNC_BGN_TM);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        ELSE
          /*满期保费＝批单保费/保险止期-批单生效日期+1×(评估日－批单生效日期+1)
            未满期保费＝批单保费－满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                       (V_INSRNC_END_TM_PLY - V_INSRNC_BGN_TM);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        
        END IF;
      END IF;
      V_NOPRM_SUM := V_NOPRM_SUM + V_CAL_AMT;
    END LOOP;
    CLOSE CUR_PLYEDR_NOVHL;
  ELSE
    OPEN CUR_PLYEDR_VHL;
    LOOP
      FETCH CUR_PLYEDR_VHL
        INTO V_PLY_NO,
             V_EDR_NO,
             V_EDR_PRJ_NO,
             V_CUR_NO,
             V_PROD_NO,
             V_INWARD,
             V_INSRNC_BGN_TM,
             V_INSRNC_END_TM,
             V_COINSRNC_FLG,
             V_EDR_TYPE,
             V_INSRNC_CDE,
             V_AMT,
             V_PRM,
             V_INSRNC_BGN_TM_PLY,
             V_INSRNC_END_TM_PLY,
             V_EDR_RSN;
      EXIT WHEN CUR_PLYEDR_VHL%NOTFOUND;
      --判断业务性质
      IF V_INWARD = '0' THEN
        V_TRAN_FLAG := '1'; --自营
      ELSIF V_INWARD = '1' THEN
        V_TRAN_FLAG := '2'; --分入
      ELSE
        V_TRAN_FLAG := '1';
      END IF;
    
      IF V_COINSRNC_FLG = '3' THEN
        V_TRAN_FLAG := '3'; --共保
      END IF;
    
      --共保时直接取得共保我司净保额 zengshaotao 2010-08-24
      IF V_COINSRNC_FLG = '3' THEN
        NUM := 1;
        SELECT N_CI_OWN_AMT, N_CI_OWN_PRM
          INTO V_AMT, V_PRM
          FROM (SELECT C_PLY_NO, C_EDR_NO, N_CI_OWN_AMT, N_CI_OWN_PRM
                  FROM WEB_PLY_BASE
                 WHERE C_EDR_NO IS NULL
                UNION
                SELECT C_PLY_NO,
                       C_EDR_NO,
                       N_CI_AMT_VAR N_CI_OWN_AMT,
                       N_CI_PRM_VAR N_CI_OWN_PRM
                  FROM WEB_PLY_CI
                 WHERE C_EDR_NO IS NOT NULL
                   AND /*C_COINSURER_CDE = '327001'*/C_SELF_MRK = '1'/*20140530 新增共保公司代码修改*/)
         WHERE C_PLY_NO = V_PLY_NO
           AND NVL(C_EDR_NO, '---') = NVL(V_EDR_NO, '---'); ---updated by ctt 2011-01-04
        NUM := 0;
      END IF;
    
      --根据传入的币种查询对应的分出保费
      select n_prm, n_fee
        into v_ri_prm, v_ri_fee
        from (select sum(n_prm) n_prm, sum(n_fee) n_fee
                from web_fin_ri_plyedr a
               where c_ply_no = V_PLY_NO
                 and c_edr_no = V_EDR_NO
                 and c_prm_cur = CPLYCUR
                 and c_cvrg_no = CCVRGNO);
    
      /*if (V_CUR_NO = CPLYCUR) --如果传入的币种与原保单币种相同，再保后保费
       then
        V_PRM := V_PRM - v_ri_prm;
      else
        \*if CPLYCUR is not null --如果币种不相同，并且传入的币种不为空
        then*\
        V_PRM := 0 - v_ri_prm;
      end if;*/
      
      --将再保前保费及手续费转换成人民币
        if V_CUR_NO <> '01'
          then 
            v_prm := v_prm * get_rate(V_CUR_NO, '01', t_today_tm);
           -- v_fee := v_fee * get_rate(V_CUR_NO, '01', t_today_tm);
        end if;
        
        --将再保分出保费及手续费转换成人民币
        if CPLYCUR <> '01'
          then 
            v_ri_prm := v_ri_prm * get_rate(CPLYCUR, '01', t_today_tm);
            v_ri_fee := v_ri_fee * get_rate(CPLYCUR, '01', t_today_tm);
        end if;
        
        --再保后保费
        v_prm := v_prm - v_ri_prm;
    
      /*--根据传入的币种查询对应的分出保费
        SELECT n_prm, n_fee
          INTO v_ri_prm, v_ri_fee
          FROM (select c_ply_no,
                       c_edr_no,
                       c_prm_cur,
                       sum(n_prm) as n_prm,
                       sum(n_fee) as n_fee
                  from web_fin_ri_plyedr a
                 group by a.c_ply_no, c_edr_no, c_prm_cur) ri
         where c_ply_no = V_PLY_NO
           and c_edr_no = V_EDR_NO
           and c_prm_cur = CPLYCUR;
      
        if (V_CUR_NO = CPLYCUR) --如果传入的币种与原保单币种相同，再保后保费
         then
          V_PRM := V_PRM - v_ri_prm;
        elsif CPLYCUR is not null --如果币种不相同，并且传入的币种不为空
         then
          V_PRM := 0 - v_ri_prm;
        end if;
      */
      IF NVL(V_EDR_NO, '---') = '---' THEN
        /*保单*/
        /*满期保费  ＝ 保单保费/保险止期-保险起期+1×(评估日－保险起期+1)
        未满期保费 ＝ 保单保费 － 满期保费*/
        V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                     (V_INSRNC_END_TM - V_INSRNC_BGN_TM);
        V_CAL_AMT := V_PRM - V_GOT_PRM;
      
      ELSE
        IF V_EDR_RSN = '29' THEN
          /*满期保费＝min(批单保费,0)
          未满期保费＝批单保费－满期保费
          */
          V_GOT_PRM := CASE
                         WHEN V_PRM < 0 THEN
                          V_PRM
                         ELSE
                          0
                       END; /*min(v_prm,0)*/
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        ELSIF V_EDR_RSN IN ('s1', 'c1') THEN
          /*满期保费＝－保单保费/保险止期－保险起期+1×(评估日－保险起期+1)
          未满期保费＝－保单保费－满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM_PLY) /
                       (V_INSRNC_END_TM_PLY - V_INSRNC_BGN_TM_PLY);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        ELSIF V_EDR_RSN BETWEEN 's2' AND 's8' THEN
          /*'31' and '37'*/
          /*满期保费＝批单保费/（批改前保险止期－批单生效日期+1）×(评估日－批单生效日期+1)
          未满期保费＝批单保费－满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                       (V_INSRNC_END_TM_PLY - V_INSRNC_BGN_TM);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        ELSE
          /* if V_EDR_RSN between '01' and '27' then*/
          /*满期保费＝批单保费/（保险止期-批单生效日期+1）×(评估日－批单生效日期+1)
          未满期保费＝批单保费－满期保费
          */
          V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                       (V_INSRNC_END_TM_PLY - V_INSRNC_BGN_TM);
          V_CAL_AMT := V_PRM - V_GOT_PRM;
        END IF;
      END IF;
      V_NOPRM_SUM := V_NOPRM_SUM + V_CAL_AMT;
    END LOOP;
    CLOSE CUR_PLYEDR_VHL;
  END IF;
  RETURN V_NOPRM_SUM;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('p_fin_bac_gotprm' || '*' || CPLYNO || SQLERRM);
end p_fin_bac_gotprm;
/
