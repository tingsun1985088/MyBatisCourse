CREATE FUNCTION "GET_PLY_CUT_OFF_RATE" (ply_no IN VARCHAR2)
  RETURN NUMBER AS
  rcpt NUMBER(20, 2) := 1;
BEGIN

  SELECT decode(SUM(n_bef_prm),
                0,
                1,
                SUM(n_bef_prm * nvl(N_RESV_NUM_10, 1)) / SUM(n_bef_prm))
    INTO rcpt
    FROM web_ply_cvrg a, web_ply_base b
   WHERE a.c_app_no = b.c_app_no
     AND b.c_app_typ = 'A'
     AND a.c_ply_no = ply_no;
  RETURN rcpt;

EXCEPTION
  WHEN OTHERS THEN
    RETURN 1;
END;








/
