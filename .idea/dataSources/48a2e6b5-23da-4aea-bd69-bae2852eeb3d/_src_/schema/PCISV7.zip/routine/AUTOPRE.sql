CREATE procedure AutoPre is
v_succ     varchar2(10);
v_dpt_cde  varchar2(30);
cursor cur_dpt is
    select distinct c_dpt_cde
      from web_org_dpt a
     where (length(a.c_dpt_cde) <> 2 and a.c_dptacc_cde <> 1)
        or a.c_dpt_cde = '00';
    
begin
    v_succ := '0';
    P_FIN_PLYER(to_char(sysdate-1,'yyyy-mm-dd'),v_succ);  
    --根据机构循环
    open cur_dpt;
    loop
    fetch cur_dpt
      into v_dpt_cde;
    exit when cur_dpt%notfound;
         P_Fin_Gotprmply(to_char(sysdate-1,'yyyy-mm-dd'),v_dpt_cde,'b',v_succ); --再保前满期保费
         Commit;
    end loop;
    close cur_dpt;
    
    p_fin_gotprm_month(to_char(sysdate-1,'yyyy-mm-dd'),'b',v_succ); --再保前保批单所经历的各个季度的满期保费
    Commit;
  
end AutoPre;
/
