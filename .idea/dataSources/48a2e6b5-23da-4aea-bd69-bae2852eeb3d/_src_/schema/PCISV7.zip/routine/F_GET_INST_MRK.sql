CREATE FUNCTION "F_GET_INST_MRK" (VAPLNO IN VARCHAR2) return  NUMBER
AS
    V_APLNO  varchar2(30);
    V_RESULT NUMBER;
begin
  V_APLNO:=VAPLNO;
  select count(1) INTO V_RESULT  from T_PAYPLAN WHERE APLNO=V_APLNO;
  return(V_RESULT);
  exception
when others then
return 0;
end F_GET_INST_MRK ;









/
