CREATE FUNCTION GET_RATE1(CUR_NO_1 IN VARCHAR2, --要转换的币种
                                     CUR_NO_2 IN VARCHAR2, --转换后的币种
                                     T_TIME   IN DATE --保险起期
                                     ) RETURN NUMBER AS
  CURSOR CURHV IS
    SELECT N_CHG_RTE
      FROM /*Web_Bas_Fin_Chg_Rate*/ RPT_FIN_CHG_RATE A
     WHERE C_CUR_CDE1 = CUR_NO_1
       AND C_CUR_CDE2 = CUR_NO_2
       AND TO_DATE(TO_CHAR(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),
                           'yyyy-MM-dd'),
                   'yyyy-MM-dd') /*T_TIME*/
           >= A.T_EFFC_TM
       AND TO_DATE(TO_CHAR(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),
                           'yyyy-MM-dd'),
                   'yyyy-MM-dd') /*T_TIME*/
           <= A.T_EXPD_TM;
  HV_RET NUMBER;
BEGIN
  IF CUR_NO_1 = CUR_NO_2 THEN
    HV_RET := 1;
  ELSE
    OPEN CURHV;
    FETCH CURHV
      INTO HV_RET;
    IF CURHV%NOTFOUND THEN
      RETURN 1;
    END IF;
    CLOSE CURHV;
  END IF;
  RETURN HV_RET;

EXCEPTION
  WHEN OTHERS THEN
    RETURN 1;
END;
/
