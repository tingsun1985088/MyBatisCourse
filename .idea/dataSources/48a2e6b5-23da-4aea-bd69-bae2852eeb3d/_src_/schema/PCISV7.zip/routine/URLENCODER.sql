CREATE FUNCTION        URLEncoder(data  IN VARCHAR2,charset IN VARCHAR2)
   ----this file is edit by tpwang  20151027
RETURN VARCHAR2 AS
    BEGIN
      RETURN utl_url.escape(data,true,charset ); --this return needed  utl_url Packages which is relate to DBA procedures.
    END;
/
