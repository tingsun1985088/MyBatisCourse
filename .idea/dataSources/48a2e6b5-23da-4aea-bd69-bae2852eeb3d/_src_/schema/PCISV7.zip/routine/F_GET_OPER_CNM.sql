CREATE FUNCTION F_GET_OPER_CNM(v_operId VARCHAR2)
  RETURN VARCHAR2 AS
  v_operCnm VARCHAR2(100);
BEGIN

  SELECT opr.c_oper_cnm
    INTO v_operCnm
    FROM web_org_oper opr
   WHERE opr.c_oper_id = v_operId;

  RETURN v_operCnm;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;

END;
/
