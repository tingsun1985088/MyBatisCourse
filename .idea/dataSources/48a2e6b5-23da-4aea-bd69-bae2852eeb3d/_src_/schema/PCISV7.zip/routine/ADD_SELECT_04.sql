CREATE procedure add_select_04(startdate in date,enddate in date) is
   
   v_task_start_date date;
   v_task_end_date   date;
   v_sql_code        number;
   v_sql_msg         varchar2(4000) := ''; --sql错误信息
   i                 number;
   temp              number;
   
   
   cursor prpdclass_s is 
      select wd.c_kind_no,wd.c_nme_cn,wd.c_nme_en,wd.c_status,wd.c_crt_cde,wd.t_crt_tm,wd.c_upd_cde,wd.t_upd_tm --wp.c_prod_no,
      from web_prd_kind wd 
        --inner join web_prd_prod wp 
        --on wd.c_kind_no=wp.c_kind_no
        where wd.t_upd_tm between startdate and enddate;
        
   cursor prpdrisk_s is
       select w1.c_prod_no,w1.c_nme_cn,w1.c_nme_en,w1.c_kind_no,w1.c_prod_no as c_prod_no2,w1.c_status,w1.c_bs_type,w1.c_crt_cde,w1.t_crt_tm,w1.c_upd_cde,w1.t_upd_tm --w2.c_kind_no,
       from web_prd_prod w1 
       --inner join web_prd_kind w2 on w1.c_kind_no=w2.c_kind_no
       where w1.t_upd_tm between startdate and enddate;
       
   
   cursor prpdkind_s is
       select e.c_cvrg_no,e.c_nme_cn,e.c_status,e.c_crt_cde,e.t_crt_tm,e.c_upd_cde,e.t_upd_tm from web_prd_cvrg e
       where e.t_upd_tm between startdate and enddate; 
       

   cursor prpdcurrency_s is
       select r.c_cur_cde,r.c_cur_cnm,r.c_cur_enm,r.c_is_valid,r.c_crt_cde,r.t_crt_tm,r.c_upd_cde,r.t_upd_tm from web_bas_fin_cur r
       where r.t_upd_tm between startdate and enddate;
       
begin
   i    :=0;
   for a in prpdclass_s loop
     begin
       select count(*) into temp from salesmiddle.prpdclass@DBLINK_NEW_SALES where CLASSCODE =a.c_kind_no;
       
       if temp=0 then
         
         insert into salesmiddle.prpdclass@DBLINK_NEW_SALES(
            CLASSCODE,
            CLASSNAME,
            CLASSENAME,
            VALIDSTATUS,
            CREATORCODE,
            CREATEDATE,
            UPDATERCODE,
            UPDATEDATE
         )
         values(a.c_kind_no,a.c_nme_cn,a.c_nme_en,a.c_status,a.c_crt_cde,a.t_crt_tm,a.c_upd_cde,a.t_upd_tm);
         
       else
         
         update salesmiddle.prpdclass@DBLINK_NEW_SALES set
            CLASSNAME=a.c_nme_cn,
            CLASSENAME=a.c_nme_en,
            VALIDSTATUS=a.c_status,
            CREATORCODE=a.c_crt_cde,
            CREATEDATE=a.t_crt_tm,
            UPDATERCODE=a.c_upd_cde,
            UPDATEDATE=a.t_upd_tm
            where CLASSCODE =a.c_kind_no;
       end if;
         
     i :=i+1;
  SELECT SYSDATE INTO v_task_end_date FROM dual;

  INSERT INTO LOAD_HIS_LOG
    (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
  VALUES
    ('pcisv7',
     'prpdclass_s',
     v_task_start_date,
     v_task_end_date,
     to_char((v_task_end_date - v_task_start_date) * 86400),
     v_sql_code,
     v_sql_msg);
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' 
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'prpdclass_s',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
     end;
     end loop;
     commit;
    
   for b in prpdrisk_s loop
     begin
       select count(*) into temp from salesmiddle.prpdrisk@DBLINK_NEW_SALES where CLASSCODE =b.c_prod_no;
       
       if temp=0 then
         insert into salesmiddle.prpdrisk@DBLINK_NEW_SALES (
           RISKCODE,
           RISKCNAME,
           RISKENAME,
           CLASSCODE,
           NEWRISKCODE,
           VALIDSTATUS,
           KINDBIGCODE,
           CREATORCODE,
           CREATEDATE,
           UPDATERCODE,
           UPDATEDATE
         )values(b.c_prod_no,b.c_nme_cn,b.c_nme_en,b.c_kind_no,b.c_prod_no2,b.c_status,b.c_bs_type,b.c_crt_cde,b.t_crt_tm,b.c_upd_cde,b.t_upd_tm);
         
         else
           update salesmiddle.prpdrisk@DBLINK_NEW_SALES set
               
               RISKCNAME=b.c_nme_cn,
               RISKENAME=b.c_nme_en,
               CLASSCODE=b.c_kind_no,
               NEWRISKCODE=b.c_prod_no2,
               VALIDSTATUS=b.c_status,
               KINDBIGCODE=b.c_bs_type,
               CREATORCODE=b.c_crt_cde,
               CREATEDATE=b.t_crt_tm,
               UPDATERCODE=b.c_upd_cde,
               UPDATEDATE=b.t_upd_tm
           where RISKCODE=b.c_prod_no;
         
       end if;
       i :=i+1;
  SELECT SYSDATE INTO v_task_end_date FROM dual;

  INSERT INTO LOAD_HIS_LOG
    (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
  VALUES
    ('pcisv7',
     'prpdrisk_s',
     v_task_start_date,
     v_task_end_date,
     to_char((v_task_end_date - v_task_start_date) * 86400),
     v_sql_code,
     v_sql_msg);
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' '
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'prpdrisk_s',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);
     end;
     end loop;
     commit;
     
   for c in prpdkind_s loop
     begin
       select count(*) into temp from salesmiddle.prpdkind@DBLINK_NEW_SALES where KINDCODE =c.c_cvrg_no;
       if temp=0 then
         insert into salesmiddle.prpdkind@DBLINK_NEW_SALES(
           KINDCODE,
           KINDCNAME,
           VALIDSTATUS,
           CREATORCODE,
           CREATEDATE,
           UPDATERCODE,
           UPDATEDATE
         )values(c.c_cvrg_no,c.c_nme_cn,c.c_status,c.c_crt_cde,c.t_crt_tm,c.c_upd_cde,c.t_upd_tm);
       else
         update salesmiddle.prpdkind@DBLINK_NEW_SALES set
           KINDCNAME=c.c_nme_cn,
           VALIDSTATUS=c.c_status,
           CREATORCODE=c.c_crt_cde,
           CREATEDATE=c.t_crt_tm,
           UPDATERCODE=c.c_upd_cde,
           UPDATEDATE=c.t_upd_tm
           where KINDCODE=c.c_cvrg_no;
       end if;
       i :=i+1;
  SELECT SYSDATE INTO v_task_end_date FROM dual;

  INSERT INTO LOAD_HIS_LOG
    (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
  VALUES
    ('pcisv7',
     'prpdkind_s',
     v_task_start_date,
     v_task_end_date,
     to_char((v_task_end_date - v_task_start_date) * 86400),
     v_sql_code,
     v_sql_msg);
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' ' 
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'prpdkind_s',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);      
     end;
     end loop;
     commit;

     
   for d in prpdcurrency_s loop
     begin
       select count(*) into temp from salesmiddle.prpdcurrency@DBLINK_NEW_SALES where  currencyCode=d.c_cur_cde;
       if temp=0 then
         insert into salesmiddle.prpdcurrency@DBLINK_NEW_SALES(
           currencyCode,
           currencyCName,
           currencyEName,
           validStatus,
           CREATORCODE,
           CREATEDATE,
           UPDATERCODE,
           UPDATEDATE
         )values(d.c_cur_cde,d.c_cur_cnm,d.c_cur_enm,d.c_is_valid,d.c_crt_cde,d.t_crt_tm,d.c_upd_cde,d.t_upd_tm);
       else
         update salesmiddle.prpdcurrency@DBLINK_NEW_SALES set
           currencyCName=d.c_cur_cnm,
           currencyEName=d.c_cur_enm,
           validStatus=d.c_is_valid,
           CREATORCODE=d.c_crt_cde,
           CREATEDATE=d.t_crt_tm,
           UPDATERCODE=d.c_upd_cde,
           UPDATEDATE=d.t_upd_tm
           where currencyCode=d.c_cur_cde;
       end if;
       i :=i+1;
  SELECT SYSDATE INTO v_task_end_date FROM dual;

  INSERT INTO LOAD_HIS_LOG
    (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
  VALUES
    ('pcisv7',
     'prpdcurrency_s',
     v_task_start_date,
     v_task_end_date,
     to_char((v_task_end_date - v_task_start_date) * 86400),
     v_sql_code,
     v_sql_msg);
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    v_sql_code := SQLCODE;
    v_sql_msg  := v_sql_msg || ' '
                  || ' : ' || SQLERRM;
    --任务结束时间
    SELECT SYSDATE INTO v_task_end_date FROM dual;
    ROLLBACK;
    INSERT INTO LOAD_HIS_LOG
      (SYS, JOBNAME, START_DATE, END_DATE, RUN_DATE, SQL_CODE, SQL_STATE)
    VALUES
      ('pcisv7',
       'prpdcurrency_s',
       v_task_start_date,
       v_task_end_date,
       to_char((v_task_end_date - v_task_start_date) * 86400),
       v_sql_code,
       v_sql_msg);       
     end;
     end loop;
     commit;
end;
/
