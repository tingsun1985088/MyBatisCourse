CREATE FUNCTION F_RI_GETIFACPLYCVRG_VAT(M_POLICYNO     VARCHAR2,
                                                   M_REINID       VARCHAR2,
                                                   M_SUBCOMPANY   VARCHAR2,
                                                   M_CURRENCYCODE VARCHAR2,
                                                   M_AMOUNT       NUMBER,
                                                   M_PRODNO       VARCHAR2,
                                                   M_TAX_MRK      VARCHAR2, -- 险别属性(应税，免税)
                                                   M_VAT_TAX_RATE NUMBER, -- 增值税率
                                                   M_VAT_TAX      NUMBER) -- 增值税
  /*
  
      临分分入获取险别函数
  
  */

 RETURN NUMBER AS
  V_RESULT      NUMBER; --返回结果
  SURPLUSAMOUNT NUMBER := M_AMOUNT; --剩余金额
  I             NUMBER := 0; --执行次数
  NSUMAMT       NUMBER := 0; --总金额(险别总保费)
  AMTPRPT       NUMBER := 1; --保费占比
  CVRGAMT       NUMBER := 0; --险别金额（到再保）
  SUMROW        NUMBER := 0; --总行数
  V_IMPORT      VARCHAR2(10) := ''; ----进出口标记

  SURPLUSTAX NUMBER := M_VAT_TAX; --剩余增值税

  CURSOR CS_CVRG IS
    SELECT SYS_GUID() AS ID, --  物理主键
           M_REINID AS SEQCHARGEDETAIL, --  业务系统传过来的接口明细表policylist.custseq
           M_REINID AS SEQCHARGE, --  关联字段，等于mm_policy_ti.id
           M_SUBCOMPANY AS SUBCOMPANY, --  分公司
           V.C_PLY_NO AS POLICYNO, --保单号
           '' AS ENDORSENO, --批单号
           M_CURRENCYCODE AS CURRENCYCODE, --挂账币种
           PROD.C_FIN_PROD AS CLASSESCODE, -- 险别
           SUM(V.N_PRM) AS AMOUNT, --  金额
           '0' AS OPSTATUS, --核销状态 初始化为0
           'ISoftStone_RI' AS SOURCE, --
           SYSDATE AS TIMESTAMP, --时间戳
           SYSDATE AS LASTOPDATE, --最后操作时间
           '1' AS HIBERNATEVERSION, --版本号
           '' AS LANDID, --  落地进入td表后的id
           '' AS TAXESAMOUNT, --  进项税额
           M_VAT_TAX_RATE AS TAXESRATE, --  税率
           M_TAX_MRK AS CLASSESSTYPE, --  险别属性：0应税 1 免税 2 零税
           '' AS TAXESAMOUNTOUT, --  进项税额转出
           '' AS TAXSTR, --  税额结构  进项税必传:01-货物及加工、修理修配劳务的进项,02-运输服务的进项,03-电信服务的进项,04-建筑安装服务的进项,05-金融保险服务的进项,06-有形动产租赁的进项,07-有形动产租赁服务的进项,08-不动产租赁服务的进项,09-取得无形资产的进项,10-受让土地使用权的进项,11-生活服务的进项,12-用于购建不动产并一次性抵扣的进项,13-通行费的进项,14-其他的进项
           '' AS RETURNITEM, --  转出项目:01：免税项目用,02：集体福利、个人消费,03：非正常损失,04：简易计税方法征税项目用,05：免抵退税办法不得抵扣的进项税,06：额纳税检查调减进项税额,07：红字专用发票信息表注明的进项税额,08：上期留抵税额抵减欠税,09：上期留抵税额退税,99：其他应作进项税额转出的情形
           '' AS INVOICECODE, -- 发票代码
           '' AS INVOICENO, -- 发票号码
           '' AS INVOICEDATE --  开票日期
      FROM WEB_PLY_BASE A, WEB_PLY_CVRG V
      LEFT JOIN WEB_MID_BUSPROD_CON_FINPROD PROD
        ON (V.C_CVRG_NO = PROD.C_BUS_CVRG_NO AND C_BUS_PROD = M_PRODNO)
       --AND (PROD.C_GROUP_MARK = '0' OR PROD.C_GROUP_MARK IS NULL)
     WHERE A.C_APP_NO = V.C_APP_NO
          --一年期及一年期以上
       AND (((A.T_INSRNC_END_TM - A.T_INSRNC_BGN_TM) / 365 >= 1 AND
           PROD.C_RESV_TXT_4 = '1' OR PROD.C_RESV_TXT_4 IS NULL) OR
           --一年期以内
           ((A.T_INSRNC_END_TM - A.T_INSRNC_BGN_TM) / 365 < 1 AND
           PROD.C_RESV_TXT_4 = '0' OR PROD.C_RESV_TXT_4 IS NULL))
          --个单
      /* AND ((A.C_GRP_MRK = '0' AND PROD.C_GROUP_MARK = '0' OR
           PROD.C_GROUP_MARK IS NULL) OR
           --团单
           (A.C_GRP_MRK = '1' AND PROD.C_GROUP_MARK = '1' OR
           PROD.C_GROUP_MARK IS NULL))*/
       AND V.C_PLY_NO = M_POLICYNO
       AND V.N_EDR_PRJ_NO = '0'
     GROUP BY V.C_PLY_NO, PROD.C_FIN_PROD;
BEGIN

  SELECT SUM(V.N_PRM), COUNT(DISTINCT PROD.C_FIN_PROD)
    INTO NSUMAMT, SUMROW
    FROM WEB_PLY_BASE A, WEB_PLY_CVRG V
    LEFT JOIN WEB_MID_BUSPROD_CON_FINPROD PROD
      ON (V.C_CVRG_NO = PROD.C_BUS_CVRG_NO AND C_BUS_PROD = M_PRODNO)
     --AND (PROD.C_GROUP_MARK = '0' OR PROD.C_GROUP_MARK IS NULL)
   WHERE A.C_APP_NO = V.C_APP_NO
     AND (((A.T_INSRNC_END_TM - A.T_INSRNC_BGN_TM) / 365 >= 1 AND
         PROD.C_RESV_TXT_4 = '1' OR PROD.C_RESV_TXT_4 IS NULL) OR
         ((A.T_INSRNC_END_TM - A.T_INSRNC_BGN_TM) / 365 < 1 AND
         PROD.C_RESV_TXT_4 = '0' OR PROD.C_RESV_TXT_4 IS NULL))
    /* AND ((A.C_GRP_MRK = '0' AND PROD.C_GROUP_MARK = '0' OR
         PROD.C_GROUP_MARK IS NULL) OR
         (A.C_GRP_MRK = '1' AND PROD.C_GROUP_MARK = '1' OR
         PROD.C_GROUP_MARK IS NULL))*/
     AND V.C_PLY_NO = M_POLICYNO
     AND V.N_EDR_PRJ_NO = '0';

  FOR REC IN CS_CVRG LOOP
    I := I + 1;
  
    IF (SUMROW = 0) AND SUBSTR(M_PRODNO, 0, 2) <> '02' THEN
    
      SELECT PROD.C_FIN_PROD
        INTO REC.CLASSESCODE
        FROM WEB_MID_BUSPROD_CON_FINPROD PROD
       WHERE PROD.C_BUS_PROD = M_PRODNO;
      CVRGAMT := M_AMOUNT;
    
    ELSIF (SUMROW = 0) AND SUBSTR(M_PRODNO, 0, 2) = '02' THEN
    
      SELECT DISTINCT C_IMPOREXP_MRK
        INTO V_IMPORT
        FROM WEB_PLY_BASE
       WHERE C_PLY_NO = M_POLICYNO;
      SELECT PROD.C_FIN_PROD
        INTO REC.CLASSESCODE
        FROM WEB_MID_BUSPROD_CON_FINPROD PROD
       WHERE PROD.C_BUS_PROD = M_PRODNO
         AND C_RESV_TXT_1 = V_IMPORT;
    
      CVRGAMT := M_AMOUNT;
    ELSE
      IF (SUMROW = I) THEN
      
        CVRGAMT := SURPLUSAMOUNT;
      ELSE
        AMTPRPT       := REC.AMOUNT / NSUMAMT; --获取险别占比
        CVRGAMT       := ROUND(M_AMOUNT * AMTPRPT, 2); --获取到险别的分保金额
        SURPLUSAMOUNT := SURPLUSAMOUNT - CVRGAMT;
      
      END IF;
    END IF;
    REC.AMOUNT := CVRGAMT;
  
    IF (M_TAX_MRK = '0') THEN
      -- 应税
    
      IF (SUMROW = I) THEN
      
        REC.TAXESAMOUNT := SURPLUSTAX;
      ELSE
      
        REC.TAXESAMOUNT := ROUND(M_VAT_TAX * AMTPRPT, 2); --获取到险别的增值税金额
        SURPLUSTAX      := SURPLUSTAX - REC.TAXESAMOUNT;
      END IF;
    
    ELSE
      -- 免税
    
      REC.TAXESAMOUNT := 0; -- 增值税
    END IF;
  
    --INSERT INTO MM_CHARGEDETAIL_TI_FND VALUES REC;
    --INSERT INTO WEB_RI_CHARGEDETAIL VALUES REC;
  
    INSERT INTO MM_CHARGEDETAIL_TI_FND
      (ID,
       SEQCHARGEDETAIL,
       SEQCHARGE,
       SUBCOMPANY,
       POLICYNO,
       ENDORSENO,
       CURRENCYCODE,
       CLASSESCODE,
       AMOUNT,
       OPSTATUS,
       SOURCE,
       TIMESTAMP,
       LASTOPDATE,
       HIBERNATEVERSION,
       LANDID,
       TAXESAMOUNT,
       TAXESRATE,
       CLASSESSTYPE,
       TAXESAMOUNTOUT,
       TAXSTR,
       RETURNITEM,
       INVOICECODE,
       INVOICENO,
       INVOICEDATE)
    VALUES
      (REC.ID,
       REC.SEQCHARGEDETAIL,
       REC.SEQCHARGE,
       REC.SUBCOMPANY,
       REC.POLICYNO,
       REC.ENDORSENO,
       REC.CURRENCYCODE,
       REC.CLASSESCODE,
       REC.AMOUNT,
       REC.OPSTATUS,
       REC.SOURCE,
       REC.TIMESTAMP,
       REC.LASTOPDATE,
       REC.HIBERNATEVERSION,
       REC.LANDID,
       REC.TAXESAMOUNT,
       REC.TAXESRATE,
       REC.CLASSESSTYPE,
       REC.TAXESAMOUNTOUT,
       REC.TAXSTR,
       REC.RETURNITEM,
       REC.INVOICECODE,
       REC.INVOICENO,
       REC.INVOICEDATE);
  
    INSERT INTO WEB_RI_CHARGEDETAIL
      (ID,
       SEQCHARGEDETAIL,
       SEQCHARGE,
       SUBCOMPANY,
       POLICYNO,
       ENDORSENO,
       CURRENCYCODE,
       CLASSESCODE,
       AMOUNT,
       OPSTATUS,
       SOURCE,
       TIMESTAMP,
       LASTOPDATE,
       HIBERNATEVERSION,
       LANDID,
       TAXESAMOUNT,
       TAXESRATE,
       CLASSESSTYPE,
       TAXESAMOUNTOUT,
       TAXSTR,
       RETURNITEM,
       INVOICECODE,
       INVOICENO,
       INVOICEDATE)
    VALUES
      (REC.ID,
       REC.SEQCHARGEDETAIL,
       REC.SEQCHARGE,
       REC.SUBCOMPANY,
       REC.POLICYNO,
       REC.ENDORSENO,
       REC.CURRENCYCODE,
       REC.CLASSESCODE,
       REC.AMOUNT,
       REC.OPSTATUS,
       REC.SOURCE,
       REC.TIMESTAMP,
       REC.LASTOPDATE,
       REC.HIBERNATEVERSION,
       REC.LANDID,
       REC.TAXESAMOUNT,
       REC.TAXESRATE,
       REC.CLASSESSTYPE,
       REC.TAXESAMOUNTOUT,
       REC.TAXSTR,
       REC.RETURNITEM,
       REC.INVOICECODE,
       REC.INVOICENO,
       REC.INVOICEDATE);
  
  END LOOP;

  V_RESULT := I;

  RETURN V_RESULT;

EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;
/
