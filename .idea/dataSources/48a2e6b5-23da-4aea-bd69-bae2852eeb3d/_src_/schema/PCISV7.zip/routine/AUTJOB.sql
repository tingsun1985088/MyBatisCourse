CREATE procedure AUTJOB
is
v_return    VARCHAR2(10);
v_year      VARCHAR2(10);
v_month     VARCHAR2(10);
v_begin     VARCHAR2(30);
v_end       VARCHAR2(30);
begin
   v_return:=1;
   
   
   if to_char(sysdate,'dd') = '01' then
      /*P_FIN_PLYER(v_return);
      P_FIN_RI_PLYER('C','1');*/
      ---快报指标 begin
      /*v_year:=to_char(sysdate,'yyyy');
      if to_char(sysdate,'mm') = '01' then
         v_year:=v_year-1;
      end if;
      v_begin:=v_year||'-01-01';
      --编译视图
      execute immediate 'alter materialized view v_prem_novhl_yj compile';
      execute immediate 'alter materialized view v_clm_novhl_yj compile';
      --刷新视图
      DBMS_SNAPSHOT.REFRESH('v_prem_novhl_yj');
      DBMS_SNAPSHOT.REFRESH('v_clm_novhl_yj');

      FIN_iface_optimize.p_get_report(to_date(v_begin,'yyyy-mm-dd'),trunc((ADD_MONTHS(LAST_DAY(SYSDATE), -1))),'','1',v_return);
      */---快报指标 end  
 end if;
   --P_FIN_RI_CLM_DETAIL(v_return);
end AUTJOB;

/
