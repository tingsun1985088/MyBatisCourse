CREATE FUNCTION "F_GET_UNDRCDE" (V_APLNO in varchar2 )
return  varchar2
as
--取保单批单的核保人 保单的在T_PLCJUDGE 批单的在T_EDRJUDGE
--如果传进来的参数第１６位为Ｐ就说明是批单在T_EDRJUDGE　中查询,否则在保单中查

  V_UNDR_CDE varchar2(30);

begin
  V_UNDR_CDE :='';
  if(V_APLNO like '_______________P%') then

 select  a.Optno into V_UNDR_CDE from T_EDRJUDGE a where a.EDRNO=V_APLNO
and a.edrjudgeopn='1'--取核保通过的
and a.syscurrtime=
(select max(syscurrtime) from T_EDRJUDGE b where a.EDRNO=b.EDRNO)
;
 else

  select  a.Optno into V_UNDR_CDE from T_PLCJUDGE a where a.Aplno=V_APLNO
and a.Plcjudgeopn='1'
and a.syscurrtime=
(select max(syscurrtime) from T_PLCJUDGE b where a.Aplno=b.Aplno)
;
  end if;
  return V_UNDR_CDE;
exception
when others then
return null;
end F_GET_UNDRCDE;









/
