CREATE procedure AUTOFACE is
t_bgn_tm       date;
t_end_tm       date;
v_year         varchar2(4);
v_month        varchar2(2);
v_ret_sta      number;
begin
  v_ret_sta:=1;
  v_year:=TO_CHAR(SYSDATE,'yyyy');
  v_month:=TO_CHAR(SYSDATE,'mm');
  IF v_month = '01' THEN
     v_year:=v_year-1;
     t_bgn_tm:=to_date(v_year||'-01-01','yyyy-mm-dd');
     t_end_tm:=to_date(v_year||'-12-31','yyyy-mm-dd');
  ELSE
     v_month:=TO_NUMBER(v_month)-1;
     IF v_month <= '9' THEN
        v_month:='0'||v_month;
     END IF;
     t_bgn_tm:=to_date(v_year||'-01-01','yyyy-mm-dd');
     t_end_tm:=last_day(to_date(v_year||'-'||v_month,'yyyy-mm'));
  END IF;
  FIN_iface_optimize.p_get_report(t_bgn_tm,t_end_tm,'','1',v_ret_sta);
end AUTOFACE;
/
