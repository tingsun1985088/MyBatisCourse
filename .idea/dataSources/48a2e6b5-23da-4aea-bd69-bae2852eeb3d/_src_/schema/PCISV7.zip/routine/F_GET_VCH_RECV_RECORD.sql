CREATE FUNCTION F_GET_VCH_RECV_RECORD(v_vchType VARCHAR2,
                                                 v_prnNo   VARCHAR2,
                                                 v_Dpt     VARCHAR2,
                                                 v_handle  VARCHAR2)

 RETURN NUMBER AS
  v_count NUMBER(5);
BEGIN
  SELECT nvl(sum(rcrd.n_issue_tms),0)
    INTO v_count
    FROM WEB_VCH_RECVISSUE_RECORD rcrd
   WHERE rcrd.c_vch_type = v_vchType
     AND rcrd.c_prn_no = v_prnNo
     AND rcrd.c_dpt_cde = v_Dpt
     AND rcrd.c_handle = v_handle;
  RETURN v_count;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
/
