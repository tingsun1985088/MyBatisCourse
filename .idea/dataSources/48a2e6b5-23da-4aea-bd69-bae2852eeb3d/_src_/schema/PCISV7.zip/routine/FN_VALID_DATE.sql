CREATE FUNCTION "FN_VALID_DATE" (C_DATE in varchar2,C_FORMATE in varchar2)
 return number
as
V_DATE varchar2(10) ;
V_FORMATE varchar2(10) ;
V_RESULT date ;
begin
V_DATE :=C_DATE;
V_FORMATE :=C_FORMATE;
select TO_date (V_DATE,V_FORMATE)into V_RESULT from dual;
return 1;
exception
when others then
return 0;
end;









/
