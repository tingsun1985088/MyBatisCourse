CREATE function p_fin_invert(v_ply_no1 varchar2,    --保单号
                                        v_edr_no1 varchar2,    --批单号
                                        v_kind_no1 varchar2,   --险类
                                        v_prod_no1 varchar2,   --产品
                                        v_insrnc_cde1 varchar2,--险别
                                        v_today1 date,         --季度止期
                                        v_ratedate date,       --评估日(用于取汇率)
                                        v_edr_resn varchar2,   --批改原因
                                        v_bgn_tm_ply   date,   --保险起期
                                        v_end_tm_ply   date,   --保险止期
                                        v_bgn_tm_edr   date,   --批单起期
                                        v_end_tm_edr   date,   --批单止期
                                        v_prm    number,       --改保批单的总满期
                                        v_cur_no varchar2) return  number is--币种

  V_INWARD        WEB_PLY_BASE.C_INWD_MRK%TYPE; --分入业务标志
  V_PROD_NO       WEB_PLY_BASE.C_PROD_NO%TYPE; --产品代码，也称为险种，如0901
  V_PLY_NO        WEB_PLY_BASE.C_PLY_NO%TYPE; --保单号
  V_EDR_NO        WEB_PLY_BASE.C_EDR_NO%TYPE; --批单号
  V_EDR_PRJ_NO    WEB_PLY_BASE.N_EDR_PRJ_NO%TYPE; --批改次数
  V_EDR_TYPE      WEB_PLY_BASE.C_EDR_TYPE%TYPE; --批改类型
  V_COINSRNC_FLG  WEB_PLY_BASE.C_CI_MRK%TYPE; --共保标志
  V_TRAN_FLAG     WEB_FIN_PRM_DUE.C_TRAN_FLAG%TYPE; --业务单据标志   自营-分入-共保
  V_INSRNC_BGN_TM WEB_PLY_BASE.T_INSRNC_BGN_TM%TYPE; --保险起期
  V_INSRNC_END_TM WEB_PLY_BASE.T_INSRNC_END_TM%TYPE; --保险止期
  V_CAL_AMT       NUMBER(16, 2); /*提取金额-法定*/
  V_RI_COM        WEB_PLY_INWD.C_CED_COM_CDE%TYPE; --分出公司
  V_INSRNC_CDE    WEB_PLY_CVRG.C_CVRG_NO%TYPE; --险别代码
  V_AMT           WEB_PLY_CVRG.N_AMT%TYPE; --险别金额
  T_TODAY_TM      DATE;
  V_INSRNC_BGN_TM_PLY DATE; --保单起期
  V_INSRNC_END_TM_PLY DATE; --保单止期
  NUM                 INT; --错误点标记
  V_EDR_RSN           WEB_PLY_BASE.C_EDR_RSN_BUNDLE_CDE%TYPE; --批改原因，保单的批改原因为'0'
  V_GOT_PRM           NUMBER(16, 2);
  V_PLY_NOPRM         NUMBER(16, 2); --对应保单未满期保费
  V_PLY_NOPRM1        NUMBER(16, 2); --对应批单未满起保费
  V_MIN_TM            NUMBER(16, 2);
  V_MIN_TM1           DATE;
  V_MIN_TM2           DATE;
  V_COUNT             INT;
  V_RESV_TM_1         DATE; --停驶止期
  V_SQLCODE           NUMBER;
  V_SQLERRM           VARCHAR2(4000);
  V_INSRNC_END_TM_ORG DATE; ---原保单保险止期
  V_NOPRM_SUM         NUMBER(16, 2);
  nEdrPrjNo           WEB_PLY_BASE.n_Edr_Prj_No%type;
  v_rate              number(16,6);
  V_LAYOFF_BGN_TM     DATE;--停驶起期
  --因为该函数都是处理批单
BEGIN
  T_TODAY_TM  := v_today1;
  V_NOPRM_SUM := 0;
  V_INSRNC_BGN_TM:=v_bgn_tm_edr;
  V_INSRNC_END_TM:=v_end_tm_edr;
  V_INSRNC_BGN_TM_PLY:=v_bgn_tm_ply;
  V_INSRNC_END_TM_PLY:=v_end_tm_ply;
  V_EDR_RSN:=v_edr_resn;
  V_EDR_NO:=v_edr_no1;
  V_PLY_NO:=v_ply_no1;
  v_prod_no:=v_prod_no1;
  --对批单止期没有时分秒的进行处理
  if to_char(v_insrnc_end_tm,'hh24:mi:ss')='00:00:00' and nvl(v_edr_no,'---')<>'---' then
     v_insrnc_end_tm:=to_date(to_char(v_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
  end if;
  --如果传入时有时分秒，需要处理
  if(nvl(v_edr_no,'---')<>'---')
    then
      v_insrnc_end_tm_ply:= v_insrnc_end_tm;
  end if;


  IF v_kind_no1 <> '03' or v_prod_no1 = '0320' THEN

      IF NVL(V_EDR_NO, '---') = '---' THEN
        /*保单*/
        /*满期保费  ＝ 保单保费/保险止期-保险起期+1×(评估日－保险起期+1)
        未满期保费 ＝ 保单保费 － 满期保费*/
        V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                     (V_INSRNC_END_TM - V_INSRNC_BGN_TM );
        V_CAL_AMT := V_PRM - V_GOT_PRM;

      ELSE
         if substr(v_prod_no,1,2)='03' then /*车险*/
            if V_EDR_RSN ='28' then
            /*如果是第一次停驶批改：
    满期保费＝批单保费+对应保批单未满期保费/批改后保险止期－停驶止期×min(评估日－停驶止期,0)
    －对应保批单未满期保费/批改前保险止期－停驶起期+1×[min(评估日,批改前保险止期)－停驶起期+1]

    如果是第二次或以上的停驶批改：
    满期保费＝min(批单保费,0)

    对于以上两种情况，
    未满期保费＝批单保费－满期保费

    对应保批单未满期保费：以批单生效日期为评估日，该批单对应的所有保单、批单的未满期保费之和。
        */
            select count(*) into v_count
            from web_ply_base
            where c_edr_no <v_edr_no and c_ply_no=v_ply_no and c_edr_rsn_bundle_cde=V_EDR_RSN;

                if v_count=0 then
                  --select b.n_prm*(t_today_tm-t_insrnc_bgn_tm+1)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                  /*select b.n_prm - b.n_prm*(t_today_tm-t_insrnc_bgn_tm+1)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                  into v_ply_noprm
                  from web_ply_base a,web_ply_cvrg b
                  where a.c_ply_no=v_ply_no and a.c_ply_no=b.c_ply_no
                  and b.c_cvrg_no=v_insrnc_cde
                  and a.c_edr_no is null
                  and b.c_edr_no is null;

                  --select nvl(b.n_prm_var*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                  select nvl(b.n_prm_var,0) - nvl(b.n_prm_var*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                  into v_ply_noprm1
                  from web_ply_base a,web_ply_cvrg b
                  where a.c_ply_no=v_ply_no and a.c_ply_no=b.c_ply_no
                  and b.c_cvrg_no=v_insrnc_cde and a.c_edr_no=b.c_edr_no
                  and a.c_edr_no <v_edr_no
                  and a.c_edr_no is not null
                  and b.c_edr_no is not null;*/

          /*停驶止起*/
            --select nvl(t_resv_tm_1,t_edr_end_tm) into v_resv_tm_1 from web_ply_base where c_edr_no=v_edr_no; /*停驶止起，如果没有复驶，就是空的,就取出来批单的保险止期*/
            --保批单未满期
            --v_ply_noprm:=p_fin_gotprm(nEdrPrjNo,v_kind_no,v_ply_no,v_resv_tm_1);
            --20140120停复驶修改 只要是停复驶批改，复驶日期不会为空 取停驶和提前复驶中小的复驶时间，
            --目前系统只允许一次停驶和一次复驶
            --对应停驶批单的算法改成以下，复驶批单不用再算：
            /*满期保费=(（批单保费+对应保批单未满期保费）)/(批改后保险止期-复驶起期)×max(评估日-复驶起期，0)
           －对应保批单未满期保费/(批改前保险止期-停驶起期+1)×[min(评估日，批改前保险止期)－停驶起期+1]*/
            --复驶起期
            --SELECT MIN(T.T_VEHICLE_LAYOFF_END_TM) INTO v_resv_tm_1 FROM WEB_PLY_BASE_42 T WHERE C_EDR_NO = v_edr_no;
            SELECT MIN(T.T_VEHICLE_LAYOFF_END_TM),MIN(T.T_EDR_END_TM) INTO v_resv_tm_1,v_insrnc_end_tm FROM WEB_PLY_BASE T WHERE T.C_PLY_NO = v_ply_no AND T.C_EDR_RSN_BUNDLE_CDE IN ('28','29');
            if to_char(v_insrnc_end_tm,'hh24:mi:ss')='00:00:00' then
             v_insrnc_end_tm:=to_date(to_char(v_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
            end if;
            v_resv_tm_1 := v_resv_tm_1 + 1/24/60/60;
             --停驶起期及原保险止期
            SELECT T.T_VEHICLE_LAYOFF_BGN_TM INTO V_LAYOFF_BGN_TM FROM WEB_PLY_BASE T WHERE C_EDR_NO = v_edr_no;
            SELECT T.T_INSRNC_END_TM INTO v_insrnc_end_tm_ply FROM WEB_PLY_BASE T WHERE C_PLY_NO = v_ply_no AND T.N_EDR_PRJ_NO = 0;
            --保批单未满期
            select a.n_edr_prj_no into nEdrPrjNo from web_ply_base a where a.c_edr_no = v_edr_no;
            v_ply_noprm:= p_fin_gotprm_vhl(nEdrPrjNo,v_kind_no1,v_ply_no,v_insrnc_bgn_tm,V_INSRNC_CDE1);
            /*if trunc(t_today_tm)<trunc(v_resv_tm_1) then  --min((t_today_tm-trunc(v_insrnc_end_tm)),0)
              v_min_tm:= trunc(t_today_tm)-v_resv_tm_1 ;
            else v_min_tm:=0 ;
            end if;*/
            --按最新的公式取大值 20140127
            if trunc(t_today_tm) > trunc(v_resv_tm_1) then  --min((t_today_tm-trunc(v_insrnc_end_tm)),0)
              v_min_tm:= t_today_tm - v_resv_tm_1;
            else v_min_tm:=0 ;
            end if;

            v_min_tm2:=  case when trunc(t_today_tm)<trunc(v_insrnc_end_tm_ply) then t_today_tm else v_insrnc_end_tm_ply end;--min(t_today_tm,trunc(v_insrnc_end_tm_ply))

             v_got_prm:=(v_prm+v_ply_noprm)*v_min_tm/(v_insrnc_end_tm-v_resv_tm_1)
                        -(v_ply_noprm)*(v_min_tm2-V_LAYOFF_BGN_TM)/(v_insrnc_end_tm_ply-V_LAYOFF_BGN_TM);
                 else
                    v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
                 end if;
               v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='29'then
            /*满期保费＝min(批单保费,0)
             未满期保费＝批单保费－满期保费
            */
             --20140127 目前停复驶的保费变化都为0
              v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
              v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN = 'c1' then --in('s1','c1') then --modify by shexiwan 2011-08-18 全单退保修改为和一般批改相同的算法
            /*满期保费＝－保单保费/(int(保险止期)－保险起期+1)×(评估日－保险起期+1) --就算法
              满期保费＝－保单保费/(保险止期－保险起期)×(评估日－保险起期)          --新算法
             未满期保费＝－保单保费－满期保费
          */
                 v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                 v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN between 's2' and 's8' /*and trunc(v_insrnc_bgn_tm)<=to_date('2011-08-12','yyyy-mm-dd')*/ then/*'31' and '37'*/
            --modify by shexiwan 2011-09-20 由于车险退保,全单退保 在2011-08-12之后的批改前保险止期=批单生效日期,因此在此之前的 满期算法不变,之后的则 未满期=0,满期=保费收入
            /*满期保费＝批单保费/（批改前保险止期－批单生效日期+1）×(评估日－批单生效日期+1)
          未满期保费＝批单保费－满期保费
          */    if V_EDR_RSN = 's2' then
                   select a.t_insrnc_end_tm into v_insrnc_end_tm_ply from web_ply_base a where a.c_ply_no = v_ply_no and a.n_edr_prj_no = 0;
                   v_insrnc_end_tm:=v_insrnc_end_tm_ply;
                 end if;
                 v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
                 v_cal_amt:= v_prm-v_got_prm;
            /*elsif V_EDR_RSN in('s1','s2') and trunc(v_insrnc_bgn_tm)>to_date('2011-08-12','yyyy-mm-dd') then --add by shexiwan 2011-09-20 退保,全单退保 的保险止期=批单的生效日期
                v_got_prm:=v_prm;
                v_cal_amt:=0;*/
            else   /* if V_EDR_RSN between '01' and '27' then*/
            /*满期保费＝批单保费/（保险止期-批单生效日期+1）×(评估日－批单生效日期+1)
    未满期保费＝批单保费－满期保费*/
              if V_EDR_RSN = 's1' then
                 select a.t_insrnc_end_tm into v_insrnc_end_tm_ply from web_ply_base a where a.c_ply_no = v_ply_no and a.n_edr_prj_no = 0;
                 v_insrnc_end_tm:=v_insrnc_end_tm_ply;
              end if;
              v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
               v_cal_amt:= v_prm-v_got_prm;
            end if;

       else  /*非车险*/
            if V_EDR_RSN = '12' then/*'11'批改保险期限*/
            /*如果是第一次批改：
            满期保费
            ＝批单保费+对应保批单未满期保费/(批改后保险止期-批单生效日期+1)×[min(评估日,批改后保险止期)－批单生效日期+1]
            －对应保批单未满期保费/(批改前保险止期-批单生效日期+1)×[min(评估日,批改前保险止期)－批单生效日期+1]

            如果是第二次或以上的批改：
            满期保费＝min(批单保费,0)

            对于以上两种情况，
            未满期保费＝批单保费－满期保费
            */
            select count(*) into v_count
            from web_ply_base
            where c_edr_no <v_edr_no and c_ply_no=v_ply_no and c_edr_rsn_bundle_cde=V_EDR_RSN;
           /* select count(1) into v_count1
            from web_ply_base
            where n_edr_prj_no<nEdrPrjNo and c_ply_no=v_ply_no;*/
                if v_count=0 then/*第一次批改*/
                 --保批单的未满期
                 select t_insrnc_end_tm into v_insrnc_end_tm_org from web_fin_plyedr
                  where c_ply_no=v_ply_no
                         and n_edr_prj_no=0;
                 --20140120货运险修改
                   /*
                      0201  国内水路运输保险
                      0202  进口货运险
                      0203  国内公路货物运输保险
                      0204  国内铁路货物运输保险
                      0205  国内航空货物运输保险
                      0206  国内水路、陆路运输保险
                      0207  出口货运险
                      0208  进出口货运险（其他）
                      规则：
                      货运险，对于内陆期限固定为30天，对于进出口期限规定为60天，对于大保单附明细的
                      ，按照大保单的保险起期和报下止期来算 批单止期与保单止期一致

                 IF v_insrnc_end_tm_org IS NULL AND v_kind_no1 = '02' THEN
                    v_insrnc_end_tm_org := v_end_tm_ply;
                 END IF;*/
                 select a.n_edr_prj_no into nEdrPrjNo from web_ply_base a where a.c_edr_no = v_edr_no;
                 v_ply_noprm:=p_fin_gotprm(nEdrPrjNo,v_kind_no1,v_ply_no1,v_insrnc_bgn_tm);
                 v_min_tm1 := case
                           when trunc(t_today_tm) < trunc(v_insrnc_end_tm_ply) then
                            trunc(t_today_tm)
                           else
                            trunc(v_insrnc_end_tm_ply) --此处未修改,一直如此
                         end; --min(t_today_tm,trunc(v_insrnc_end_tm))
                v_min_tm2 := case
                           when trunc(t_today_tm) < trunc(v_insrnc_end_tm_org) then
                            trunc(t_today_tm)
                           else
                            trunc(v_insrnc_end_tm_org) --此处未修改,一直如此
                         end; --min(t_today_tm,trunc(v_insrnc_end_tm_ply))

                v_got_prm := (v_prm + v_ply_noprm) *
                         (v_min_tm1 - v_insrnc_bgn_tm + 1) /
                         (trunc(v_insrnc_end_tm_ply) - v_insrnc_bgn_tm + 1) -
                         v_ply_noprm * (v_min_tm2 - v_insrnc_bgn_tm + 1) /
                         (trunc(v_insrnc_end_tm_org) - v_insrnc_bgn_tm + 1);

                 else
                    v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
                 end if;
               v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='c1' then --注销保单,那保单对应的批单呢?就不用管吗?'22'
            /*
            满期保费＝－保单保费×评估日-保险起期+1/保险止期-保险起期+1
            未满期保费＝－保单保费－满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                  v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='c2' then/*'23'*/
            /*满期保费＝保单保费×评估日-保险起期+1/保险止期-保险起期+1
            未满期保费＝保单保费－满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                  v_cal_amt:=v_prm-v_got_prm;

            elsif V_EDR_RSN ='c3' then/*'24'*/
            /*满期保费＝－被注销批单满期保费
            未满期保费＝－被注销批单未满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);
                  v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN ='c5' then/*'25'*/
            /*满期保费＝被注销批单满期保费
            未满期保费＝被注销保单未满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);
                  v_cal_amt:= v_prm-v_got_prm;
            else
            /*满期保费＝批单保费/保险止期-批单生效日期+1×(评估日－批单生效日期+1)
              未满期保费＝批单保费－满期保费
            */
               --v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm+1)/(trunc(v_insrnc_end_tm_ply)-v_insrnc_bgn_tm+1);
               --v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
               v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
               v_cal_amt:= v_prm-v_got_prm;

            end if;

         end if;
      END IF;
      V_NOPRM_SUM := V_NOPRM_SUM + V_CAL_AMT;

  ELSE


      IF NVL(V_EDR_NO, '---') = '---' THEN
        /*保单*/
        /*满期保费  ＝ 保单保费/保险止期-保险起期+1×(评估日－保险起期+1)
        未满期保费 ＝ 保单保费 － 满期保费*/
        V_GOT_PRM := V_PRM * (T_TODAY_TM - V_INSRNC_BGN_TM) /
                     (V_INSRNC_END_TM - V_INSRNC_BGN_TM );
        V_CAL_AMT := V_PRM - V_GOT_PRM;

      ELSE
        --============================
          if substr(v_prod_no,1,2)='03' then /*车险*/
            if V_EDR_RSN ='28' then
            /*如果是第一次停驶批改：
    满期保费＝批单保费+对应保批单未满期保费/批改后保险止期－停驶止期×min(评估日－停驶止期,0)
    －对应保批单未满期保费/批改前保险止期－停驶起期+1×[min(评估日,批改前保险止期)－停驶起期+1]

    如果是第二次或以上的停驶批改：
    满期保费＝min(批单保费,0)

    对于以上两种情况，
    未满期保费＝批单保费－满期保费

    对应保批单未满期保费：以批单生效日期为评估日，该批单对应的所有保单、批单的未满期保费之和。
        */
            select count(*) into v_count
            from web_ply_base
            where c_edr_no <v_edr_no and c_ply_no=v_ply_no and c_edr_rsn_bundle_cde=V_EDR_RSN;

                if v_count=0 then
                  --select b.n_prm*(t_today_tm-t_insrnc_bgn_tm+1)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                  /*select b.n_prm - b.n_prm*(t_today_tm-t_insrnc_bgn_tm+1)/(trunc(t_insrnc_end_tm)-t_insrnc_bgn_tm+1)
                  into v_ply_noprm
                  from web_ply_base a,web_ply_cvrg b
                  where a.c_ply_no=v_ply_no and a.c_ply_no=b.c_ply_no
                  and b.c_cvrg_no=v_insrnc_cde
                  and a.c_edr_no is null
                  and b.c_edr_no is null;

                  --select nvl(b.n_prm_var*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                  select nvl(b.n_prm_var,0) - nvl(b.n_prm_var*(t_today_tm-t_edr_bgn_tm+1)/(trunc(t_edr_end_tm)-t_edr_bgn_tm+1),0)
                  into v_ply_noprm1
                  from web_ply_base a,web_ply_cvrg b
                  where a.c_ply_no=v_ply_no and a.c_ply_no=b.c_ply_no
                  and b.c_cvrg_no=v_insrnc_cde and a.c_edr_no=b.c_edr_no
                  and a.c_edr_no <v_edr_no
                  and a.c_edr_no is not null
                  and b.c_edr_no is not null;*/

          /*停驶止起*/
           -- select nvl(t_resv_tm_1,t_edr_end_tm) into v_resv_tm_1 from web_ply_base where c_edr_no=v_edr_no; /*停驶止起，如果没有复驶，就是空的,就取出来批单的保险止期*/
            --保批单未满期
            --v_ply_noprm:=p_fin_gotprm(nEdrPrjNo,v_kind_no,v_ply_no,v_resv_tm_1);

            /*v_ply_noprm:=p_fin_gotprm(nEdrPrjNo,v_kind_no1,v_ply_no,v_resv_tm_1);
            if trunc(t_today_tm)<trunc(v_resv_tm_1) then  --min((t_today_tm-trunc(v_insrnc_end_tm)),0)
              v_min_tm:= trunc(t_today_tm)-v_resv_tm_1 ;
            else v_min_tm:=0 ;
            end if;

                 v_min_tm2:=  case when trunc(t_today_tm)<trunc(v_insrnc_end_tm_ply) then trunc(t_today_tm) else trunc(v_insrnc_end_tm_ply) end;--min(t_today_tm,trunc(v_insrnc_end_tm_ply))

                    v_got_prm:=(v_prm+v_ply_noprm\*+v_ply_noprm1*\)*v_min_tm/(trunc(v_insrnc_end_tm)-v_resv_tm_1+1)
                             -(v_ply_noprm\*+v_ply_noprm1*\)*(v_min_tm2-v_resv_tm_1+1)/(trunc(v_insrnc_end_tm_ply)-v_resv_tm_1+1);

                 else
                    v_got_prm:= case when v_prm<0 then v_prm else 0 end;\*min(v_prm,0)*\
                 end if;
               v_cal_amt:=v_prm-v_got_prm;*/
            SELECT MIN(T.T_VEHICLE_LAYOFF_END_TM),MIN(T.T_EDR_END_TM) INTO v_resv_tm_1,v_insrnc_end_tm FROM WEB_PLY_BASE T WHERE T.C_PLY_NO = v_ply_no AND T.C_EDR_RSN_BUNDLE_CDE IN ('28','29');
            if to_char(v_insrnc_end_tm,'hh24:mi:ss')='00:00:00' then
             v_insrnc_end_tm:=to_date(to_char(v_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss');
            end if;
            v_resv_tm_1 := v_resv_tm_1 + 1/24/60/60;
             --停驶起期及原保险止期
            SELECT T.T_VEHICLE_LAYOFF_BGN_TM INTO V_LAYOFF_BGN_TM FROM WEB_PLY_BASE T WHERE C_EDR_NO = v_edr_no;
            SELECT T.T_INSRNC_END_TM INTO v_insrnc_end_tm_ply FROM WEB_PLY_BASE T WHERE C_PLY_NO = v_ply_no AND T.N_EDR_PRJ_NO = 0;
            --保批单未满期
            select a.n_edr_prj_no into nEdrPrjNo from web_ply_base a where a.c_edr_no = v_edr_no;
            --20140418将计算保批单未满期的日期由v_resv_tm_1改为 v_insrnc_bgn_tm
            v_ply_noprm:=p_fin_gotprm_vhl(nEdrPrjNo,v_kind_no1,v_ply_no,v_insrnc_bgn_tm,V_INSRNC_CDE1);
            /*if trunc(t_today_tm)<trunc(v_resv_tm_1) then  --min((t_today_tm-trunc(v_insrnc_end_tm)),0)
              v_min_tm:= trunc(t_today_tm)-v_resv_tm_1 ;
            else v_min_tm:=0 ;
            end if;*/
            --按最新的公式取大值 20140127
            if trunc(t_today_tm) > trunc(v_resv_tm_1) then  --min((t_today_tm-trunc(v_insrnc_end_tm)),0)
              v_min_tm:= t_today_tm - v_resv_tm_1;
            else v_min_tm:=0 ;
            end if;

            v_min_tm2:=  case when trunc(t_today_tm)<trunc(v_insrnc_end_tm_ply) then t_today_tm else v_insrnc_end_tm_ply end;--min(t_today_tm,trunc(v_insrnc_end_tm_ply))

             v_got_prm:=(v_prm+v_ply_noprm)*v_min_tm/(v_insrnc_end_tm-v_resv_tm_1)
                        -(v_ply_noprm)*(v_min_tm2-V_LAYOFF_BGN_TM)/(v_insrnc_end_tm_ply-V_LAYOFF_BGN_TM);
                 else
                    v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
                 end if;
               v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='29'then
            /*满期保费＝min(批单保费,0)
             未满期保费＝批单保费－满期保费
            */
              v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
              v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN = 'c1' then --in('s1','c1') then --modify by shexiwan 2011-08-18 全单退保修改为和一般批改相同的算法
            /*满期保费＝－保单保费/(int(保险止期)－保险起期+1)×(评估日－保险起期+1) --就算法
              满期保费＝－保单保费/(保险止期－保险起期)×(评估日－保险起期)          --新算法
             未满期保费＝－保单保费－满期保费
          */
                 v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                 v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN between 's2' and 's8' /*and trunc(v_insrnc_bgn_tm)<=to_date('2011-08-12','yyyy-mm-dd')*/ then/*'31' and '37'*/
            --modify by shexiwan 2011-09-20 由于车险退保,全单退保 在2011-08-12之后的批改前保险止期=批单生效日期,因此在此之前的 满期算法不变,之后的则 未满期=0,满期=保费收入
            /*满期保费＝批单保费/（批改前保险止期－批单生效日期+1）×(评估日－批单生效日期+1)
          未满期保费＝批单保费－满期保费
          */    --if V_EDR_RSN = 's2' then
                   select a.t_insrnc_end_tm into v_insrnc_end_tm_ply from web_ply_base a where a.c_ply_no = v_ply_no and a.n_edr_prj_no = 0;
                   v_insrnc_end_tm:=v_insrnc_end_tm_ply;
                 --end if;
                 v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
                 v_cal_amt:= v_prm-v_got_prm;
            /*elsif V_EDR_RSN in('s1','s2') and trunc(v_insrnc_bgn_tm)>to_date('2011-08-12','yyyy-mm-dd') then --add by shexiwan 2011-09-20 退保,全单退保 的保险止期=批单的生效日期
                v_got_prm:=v_prm;
                v_cal_amt:=0;*/
            else   /* if V_EDR_RSN between '01' and '27' then*/
            /*满期保费＝批单保费/（保险止期-批单生效日期+1）×(评估日－批单生效日期+1)
    未满期保费＝批单保费－满期保费*/
              if V_EDR_RSN = 's1' then
                 select a.t_insrnc_end_tm into v_insrnc_end_tm_ply from web_ply_base a where a.c_ply_no = v_ply_no and a.n_edr_prj_no = 0;
                 v_insrnc_end_tm:=v_insrnc_end_tm_ply;
              end if;
              v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm);
               v_cal_amt:= v_prm-v_got_prm;
            end if;

       else  /*非车险*/
            if V_EDR_RSN = '12' then/*'11'批改保险期限*/
            /*如果是第一次批改：
            满期保费
            ＝批单保费+对应保批单未满期保费/(批改后保险止期-批单生效日期+1)×[min(评估日,批改后保险止期)－批单生效日期+1]
            －对应保批单未满期保费/(批改前保险止期-批单生效日期+1)×[min(评估日,批改前保险止期)－批单生效日期+1]

            如果是第二次或以上的批改：
            满期保费＝min(批单保费,0)

            对于以上两种情况，
            未满期保费＝批单保费－满期保费
            */
            select count(*) into v_count
            from web_ply_base
            where c_edr_no <v_edr_no and c_ply_no=v_ply_no and c_edr_rsn_bundle_cde=V_EDR_RSN;
           /* select count(1) into v_count1
            from web_ply_base
            where n_edr_prj_no<nEdrPrjNo and c_ply_no=v_ply_no;*/
                if v_count=0 then/*第一次批改*/
                 --保批单的未满期
                 select t_insrnc_end_tm into v_insrnc_end_tm_org from web_ply_base
                  where c_ply_no=v_ply_no
                         and n_edr_prj_no=0;
                 v_ply_noprm:=p_fin_gotprm(nEdrPrjNo,v_kind_no1,v_ply_no1,v_insrnc_bgn_tm);
                 v_min_tm1 := case
                           when trunc(t_today_tm) < trunc(v_insrnc_end_tm_ply) then
                            trunc(t_today_tm)
                           else
                            trunc(v_insrnc_end_tm_ply) --此处未修改,一直如此
                         end; --min(t_today_tm,trunc(v_insrnc_end_tm))
                v_min_tm2 := case
                           when trunc(t_today_tm) < trunc(v_insrnc_end_tm_org) then
                            trunc(t_today_tm)
                           else
                            trunc(v_insrnc_end_tm_org) --此处未修改,一直如此
                         end; --min(t_today_tm,trunc(v_insrnc_end_tm_ply))

                v_got_prm := (v_prm + v_ply_noprm) *
                         (v_min_tm1 - v_insrnc_bgn_tm + 1) /
                         (trunc(v_insrnc_end_tm_ply) - v_insrnc_bgn_tm + 1) -
                         v_ply_noprm * (v_min_tm2 - v_insrnc_bgn_tm + 1) /
                         (trunc(v_insrnc_end_tm_org) - v_insrnc_bgn_tm + 1);

                 else
                    v_got_prm:= case when v_prm<0 then v_prm else 0 end;/*min(v_prm,0)*/
                 end if;
               v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='c1' then --注销保单,那保单对应的批单呢?就不用管吗?'22'
            /*
            满期保费＝－保单保费×评估日-保险起期+1/保险止期-保险起期+1
            未满期保费＝－保单保费－满期保费
            */    if v_insrnc_bgn_tm_ply<v_today1 then
                     v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                  else
                     v_got_prm:=0;
                  end if;
                  v_cal_amt:=v_prm-v_got_prm;
            elsif V_EDR_RSN ='c2' then/*'23'*/
            /*满期保费＝保单保费×评估日-保险起期+1/保险止期-保险起期+1
            未满期保费＝保单保费－满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm_ply)/(v_insrnc_end_tm_ply-v_insrnc_bgn_tm_ply);
                  v_cal_amt:=v_prm-v_got_prm;

            elsif V_EDR_RSN ='c3' then/*'24'*/
            /*满期保费＝－被注销批单满期保费
            未满期保费＝－被注销批单未满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);
                  v_cal_amt:= v_prm-v_got_prm;
            elsif V_EDR_RSN ='c5' then/*'25'*/
            /*满期保费＝被注销批单满期保费
            未满期保费＝被注销保单未满期保费
            */
                  v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm)/(v_insrnc_end_tm-v_insrnc_bgn_tm);
                  v_cal_amt:= v_prm-v_got_prm;
            else
            /*满期保费＝批单保费/保险止期-批单生效日期+1×(评估日－批单生效日期+1)
              未满期保费＝批单保费－满期保费
            */
               --v_got_prm:=v_prm*(t_today_tm-v_insrnc_bgn_tm+1)/(trunc(v_insrnc_end_tm_ply)-v_insrnc_bgn_tm+1);

               v_cal_amt:= v_prm-v_got_prm;

            end if;

         end if;
      --=======================
      END IF;

      V_NOPRM_SUM := V_NOPRM_SUM + V_CAL_AMT;

  END IF;
  /*if v_kind_no1 <> '03' and V_EDR_RSN not in('s1','s2') then
    if trunc(v_insrnc_end_tm)<=trunc(t_today_tm)  then \*如果保单止期<评估日,在评估日前已经止保了*\
        v_got_prm:=v_prm;
        v_cal_amt:=0;
      end if;
  end if;*/
  if v_kind_no1 = '03' and V_EDR_RSN  in('s1','s2') and trunc(v_insrnc_end_tm)<=trunc(t_today_tm) then
     NUM:=NUM+1;
     v_got_prm:=v_prm;
     v_cal_amt:=0;
  else
     if trunc(v_insrnc_end_tm)<=trunc(t_today_tm)  then /*如果保单止期<评估日,在评估日前已经止保了*/
        v_got_prm:=v_prm;
        v_cal_amt:=0;
      end if;
  end if;
  /*if V_CUR_NO<>'01' then
     v_rate:=get_rate(V_CUR_NO,'01',trunc(v_ratedate));
  else v_rate:=1;
  end if;*/
  v_rate:=1;
  RETURN V_GOT_PRM*v_rate;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('p_fin_invert' || '*' || v_ply_no1 ||'---'||v_edr_no1 || SQLERRM);
END;
/
