CREATE FUNCTION "GET_NEWPLY_NO" (lp_PlyNo IN VARCHAR2, deadline IN VARCHAR2)
RETURN VARCHAR2
AS
 sEdrNo VARCHAR2(30);
 sPlyNo VARCHAR2(30);
 --ncont  number;
BEGIN
 --ncont := 0 ;
 sPlyNo := LTRIM(RTRIM(lp_PlyNo));
 --select count(*) into ncont from T_CLM_NOCHECK where c_ply_no=sPlyNo;
 --if ncont>0 then
 	--RETURN '------';
 --end if;

 SELECT Max(retno) INTO sEdrNo /*暂时用max取最新保单因后台程序下一次批改时间更新有问题,max已去掉,*/
  FROM (SELECT c_edr_no AS retno, c_ply_no, t_udr_tm,t_next_edr_udr_tm FROM web_PLY_BASE
    WHERE c_ply_no = sPlyNo)
  WHERE TO_DATE(deadline,'yyyy-mm-dd hh24:mi:ss')>t_udr_tm
  AND TO_DATE(deadline,'yyyy-mm-dd hh24:mi:ss')<=t_next_edr_udr_tm;
  if sEdrNo is null then
  return '------';
  else
   RETURN sEdrNo;
   end if;
EXCEPTION
 WHEN OTHERS THEN
  RETURN NULL;
END;








/
