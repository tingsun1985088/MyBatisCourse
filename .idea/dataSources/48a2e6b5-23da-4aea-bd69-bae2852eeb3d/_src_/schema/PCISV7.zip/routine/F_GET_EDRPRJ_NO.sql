CREATE FUNCTION "F_GET_EDRPRJ_NO" (V_APLNO varchar2, V_EDRNO varchar2)
return number is

V_EDRPRJ_NO number(4);

begin

V_EDRPRJ_NO :=0;

select PRJNO into V_EDRPRJ_NO from

(
select a.EDRNO EDRNO,row_number() over(PARTITION BY a.APLNO ORDER BY a.syscurrtime,a.EDRNO) PRJNO
from T_EDR a
where a.aplno=V_APLNO
) m
where m.EDRNO=V_EDRNO
;

return V_EDRPRJ_NO;

exception when others then
return 1;

end F_GET_EDRPRJ_NO;









/
