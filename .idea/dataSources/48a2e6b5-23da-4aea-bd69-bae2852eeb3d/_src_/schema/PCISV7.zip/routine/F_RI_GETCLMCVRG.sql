CREATE FUNCTION f_ri_getClmCvrg(m_claimno      varchar2,
                                           m_ribillno     varchar2,
                                           m_reinId       varchar2,
                                           m_SUBCOMPANY   varchar2,
                                           m_CURRENCYCODE varchar2,
                                           m_amount       number)
/*

      非车险赔案获取险别函数

  */

 return number AS
  v_result      number; --返回结果
  SurplusAmount number := m_amount; --剩余金额
  i             number := 0; --执行次数
  nSumAmt       number := 0; --总金额(险别总保费)
  amtPrpt       number := 1; --保费占比
  cvrgAmt       number := 0; --险别金额（到再保）
  sumRow        number := 0; --总行数

  cursor cs_cvrg is
    select sys_guid() as ID, --  物理主键
           m_reinId as SEQCHARGEDETAIL, --  业务系统传过来的接口明细表policylist.custseq
           m_reinId as SEQCHARGE, --  关联字段，等于mm_policy_ti.id
           m_SUBCOMPANY as SUBCOMPANY, --  分公司
           c.policyno as POLICYNO, --保单号
           c.endorseno as ENDORSENO, --批单号
           m_CURRENCYCODE as CURRENCYCODE, --挂账币种
           c.classescode as CLASSESCODE, -- 险别
           sum(c.amount) as AMOUNT, --  金额
           '0' as OPSTATUS, --核销状态 初始化为0
           'ISoftStone_RI' as SOURCE, --
           sysdate as TIMESTAMP, --时间戳
           sysdate as LASTOPDATE, --最后操作时间
           '1' as HIBERNATEVERSION, --版本号
           '' as LANDID, --  落地进入td表后的id
           '' as TAXESAMOUNT, --  进项税额
           '' as TAXESRATE, --  税率
           '' as CLASSESSTYPE, --  险别属性：0应税 1 免税 2 零税
           '' as TAXESAMOUNTOUT, --  进项税额转出
           '' as TAXSTR, --  税额结构  进项税必传:01-货物及加工、修理修配劳务的进项,02-运输服务的进项,03-电信服务的进项,04-建筑安装服务的进项,05-金融保险服务的进项,06-有形动产租赁的进项,07-有形动产租赁服务的进项,08-不动产租赁服务的进项,09-取得无形资产的进项,10-受让土地使用权的进项,11-生活服务的进项,12-用于购建不动产并一次性抵扣的进项,13-通行费的进项,14-其他的进项
           '' as RETURNITEM, --  转出项目:01：免税项目用,02：集体福利、个人消费,03：非正常损失,04：简易计税方法征税项目用,05：免抵退税办法不得抵扣的进项税,06：额纳税检查调减进项税额,07：红字专用发票信息表注明的进项税额,08：上期留抵税额抵减欠税,09：上期留抵税额退税,99：其他应作进项税额转出的情形
           '' as INVOICECODE, -- 发票代码
           '' as INVOICENO, -- 发票号码
           '' as INVOICEDATE --  开票日期
      from mm_policy_ti a, mm_policylist_ti b, mm_chargedetail_ti c
     WHERE 1 = 1
       AND a.id = b.seqpolicy
       AND b.id = c.seqcharge
       and a.claimno = m_claimno
       and exists
     (select 'X'
              from web_ri_share_bill bill, web_ri_clm_due due
             where bill.c_ply_no = due.c_ply_no
               and bill.c_clm_no = due.c_clm_no
               and bill.n_clm_tms = due.n_clm_tms
               and a.policyno = bill.c_ply_no
               and a.claimno = bill.c_clm_no
               and due.n_clm_tms = replace(a.payment_type, '-', '')
               and bill.c_inner_bill_no = m_ribillno)
     group by a.claimno,
              a.serialno,
              c.policyno,
              c.endorseno,
              c.currencycode,
              c.classescode;
BEGIN

  select sum(c.amount), count(distinct c.classescode)
    into nSumAmt, sumRow
    from mm_policy_ti a, mm_policylist_ti b, mm_chargedetail_ti c
   WHERE 1 = 1
     AND a.id = b.seqpolicy
     AND b.id = c.seqcharge
     and a.claimno = m_claimno
     and exists
   (select 'X'
            from web_ri_share_bill bill, web_ri_clm_due due
           where bill.c_ply_no = due.c_ply_no
             and bill.c_clm_no = due.c_clm_no
             and bill.n_clm_tms = due.n_clm_tms
             and a.policyno = bill.c_ply_no
             and a.claimno = bill.c_clm_no
             and due.n_clm_tms = replace(a.payment_type, '-', '')
             and bill.c_inner_bill_no = m_ribillno);

  if sumRow = 0 then

    v_result := 0;

  else

    for rec in cs_cvrg loop
      i := i + 1;
      -- rec.id := m_reinId || '_' || to_char(i);
      if (sumRow = i) then

        cvrgAmt := SurplusAmount;
      else
        amtPrpt       := rec.amount / nSumAmt; --获取险别占比
        cvrgAmt       := round(m_amount * amtPrpt, 2); --获取到险别的分保金额
        SurplusAmount := SurplusAmount - cvrgAmt;

      end if;

      rec.amount := cvrgAmt;
      insert into mm_chargedetail_ti_fnd values rec;
      insert into web_ri_chargedetail values rec;
    end loop;


    v_result := i;

  end if;

  return v_result;

  exception
  when others then
    return 0;
end;

/
