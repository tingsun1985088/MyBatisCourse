CREATE FUNCTION "F_GET_BEF_AMT" (CPlyNo in varchar2,NPrjNo in number /*本次批改的序列号*/,CAmtCls in varchar2/*金额类型*/)/*输入保单号和批改次数*/
return varchar2
--取本次批改前保额和保费 类别为1为保额 类别为2为保费
as
 v_PLY_NO           varchar2(30);
 V_NUM               number      ;
 V_BEF_AMT           number(20,2); /*批改前保额*/
 V_BEF_PRM           number(20,2); /*批改前保费*/

BEGIN
	 v_PLY_NO    :=CPlyNo ;
	 v_NUM          :=0;
   if (NPrjNo=1) then
   select COUNT(1) into v_NUM from T_PLY_BASE
	where C_PLY_NO=v_PLY_NO ;
     IF(V_NUM>0) THEN
     select N_AMT,N_PRM into V_BEF_AMT,V_BEF_PRM from T_PLY_BASE
	where C_PLY_NO=v_PLY_NO ;
     END IF;
   else
  select COUNT(1) into v_NUM from T_EDR_BASE
	where C_PLY_NO=v_PLY_NO and N_EDR_PRJ_NO=NPrjNo-1;
      if(v_NUM>0) then
	     select N_AMT,N_PRM into V_BEF_AMT,V_BEF_PRM from T_EDR_BASE
	   where C_PLY_NO=v_PLY_NO and N_EDR_PRJ_NO=NPrjNo-1;
      END IF;
  END IF;

  if(CAmtCls=1) then
  return V_BEF_AMT;
  elsif(CAmtCls=2) then
  return V_BEF_PRM;
  end if;

exception
when others then
return 0;

END F_GET_BEF_AMT;








/
