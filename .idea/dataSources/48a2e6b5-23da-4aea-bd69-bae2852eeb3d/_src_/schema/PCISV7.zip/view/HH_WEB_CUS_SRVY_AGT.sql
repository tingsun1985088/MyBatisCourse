CREATE VIEW HH_WEB_CUS_SRVY_AGT AS SELECT
c_srvy_cde,
c_abr_nme,
c_ara_cde,
c_cty_cnm,
c_whl_ara_mrk,
c_dpt_cde,
c_sry_doc,
c_company_nme,
c_country_cn,
c_country_en,
c_continent_cn,
c_continent_en,
c_cty_enm
 FROM web_cus_srvy_agt
/
