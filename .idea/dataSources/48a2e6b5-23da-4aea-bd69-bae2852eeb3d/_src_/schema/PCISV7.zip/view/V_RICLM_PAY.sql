CREATE VIEW V_RICLM_PAY AS select --再保分出已决赔款明细
      due.c_clm_no as c_clm_no,'' as c_rpt_no,due.c_ply_no as c_ply_no,
      to_char(plyedr.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
      to_char(plyedr.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
      --dpt.c_dpt_cnm   as c_dpt_cnm,
      case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
      decode(plyedr.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as 三级机构,
      --rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'')  as c_kind_name,
      case when pend.c_cvrg_no is not null then decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')
         else rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'')  end as  kindName,
      prod.c_nme_cn   as c_prod_name,
      '---'           as c_cvrg_name,
      decode(nvl(plyedr.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,--团单标志,
      decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东') as c_stk_mrk,--股东标志,
       --ced.n_clm_amt,
      cur.c_cur_cnm  as  c_pay_cur,--已决赔款的币种,
      sum(ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee)))  as n_pay,--原币种已决赔款,
      sum(CASE WHEN ced.c_riclm_cur='01' THEN ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))
       ELSE ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_this_dtmd/(pend.n_this_dtmd+pend.n_clmfee))*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm) END)
            as n_pay_rmb,--折合人民币已决赔款,
      cur.c_cur_cnm  as c_clmfee_cur,--已决直接理赔费用币种,
      sum(ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/(pend.n_this_dtmd+pend.n_clmfee))) as n_clmfee,--原币种已决直接理赔费用,
      sum(case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))
         else ced.n_clm_amt* decode((pend.n_this_dtmd+pend.n_clmfee),0,0,pend.n_clmfee/((pend.n_this_dtmd+pend.n_clmfee)))*
             get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end )  as n_clmfee_rmb,--折合人民币已决直接理赔费用,

      '人民币'       as c_nopay_cur,-- 未决赔款币种,
      0              as n_nopay,-- 原币种未决赔款,
      0              as n_nopay_rmb,-- 折合人民币未决赔款,
      '人民币'       as c_noclmfee_cur, -- 未决直接理赔费用币种,
      0              as n_noclmfee,--原币种未决直接理赔费用,
      0              as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
      to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,出险时间,
      ''                                               as t_rpt_tm,--报案时间,报案时间,
      to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,--立案时间,立案时间,
      to_char(due.t_cls_tm,'yyyy-mm-dd hh24:mi:ss')    as t_endcase_tm,--结案时间结案时间
      prod.c_kind_no,
      prod.c_prod_no,
      '已决' as d_state
   from web_ri_clm_due due,web_ri_clm_ced ced,
        web_prd_prod prod,web_ply_base plyedr,
        --web_prd_kind kind,
        web_org_dpt dpt,web_org_dpt dpt2,
       -- web_clm_pend pend,
       (select c_clm_no,sum(nvl(n_this_dtmd,0) * get_rate(NVL(c_pend_cur,'01'),'01',a.t_end_tm)) as n_this_dtmd ,sum(nvl(n_clmfee,0) * get_rate(NVL(c_Clmfee_Cur,'01'),'01',a.t_end_tm))as n_clmfee,c_pend_source,c_cvrg_no
          from web_clm_pend,WEB_FIN_ACCNTQUART a where T_PEND_TM <= a.T_END_TM AND a.C_MRK = '2' AND  c_pend_source='6' group by  c_clm_no,c_pend_source,c_cvrg_no) pend,
        web_ply_applicant app,
        web_bas_fin_cur cur,web_prd_cvrg cvrg,web_fin_accntquart acc
   where
        due.c_clm_no = ced.c_clm_no
    and due.n_clm_tms =ced.n_clm_tms
    and due.n_rbk_seq=ced.n_rbk_seq
    and due.n_split_seq = ced.n_split_seq
    and due.c_prod_no = prod.c_prod_no
    --and due.c_clm_no in ('4000006132013000008','4010206062013000275')
    and due.c_ply_no = plyedr.c_ply_no
    and acc.c_mrk = '2'
    and nvl(due.n_edr_prj_no,0) = plyedr.n_edr_prj_no
    AND plyedr.c_app_no = app.c_app_no(+)
    and due.c_status IN ('B','C') --= 'C'
    and prod.c_kind_no != '03'
    and pend.c_cvrg_no = cvrg.c_cvrg_no(+)
    --and due.n_rbk_seq=0
    and ced.c_cont_cde not in('BB','04','AR') --不是我司
    and due.t_ridue_tm <= acc.t_end_tm
    --and prod.c_kind_no = kind.c_kind_no
    and due.c_clm_no=pend.c_clm_no
    and pend.c_pend_source='6'
    and ced.c_riclm_cur = cur.c_cur_cde
    and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
    and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
    group by
          due.c_clm_no, due.c_ply_no, to_char(plyedr.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
          to_char(plyedr.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
          prod.c_nme_cn,plyedr.c_grp_mrk,app.c_stk_mrk,cur.c_cur_cnm,
          to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
          to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss'),
          to_char(due.t_cls_tm,'yyyy-mm-dd hh24:mi:ss'),
          prod.c_kind_no,prod.c_prod_no,pend.c_cvrg_no,cvrg.c_jy_flg,
          substr(due.c_dpt_cde,1,4),plyedr.c_inwd_mrk,dpt2.c_dpt_cnm
/
