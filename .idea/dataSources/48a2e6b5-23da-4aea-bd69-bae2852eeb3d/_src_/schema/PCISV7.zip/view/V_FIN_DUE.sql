CREATE VIEW V_FIN_DUE AS SELECT '1' AS c_due_type, c_ply_no, c_edr_no, c_app_no, NULL AS c_clm_no,
          n_tms, c_prod_no, c_bsns_typ, c_slsgrp_cde, c_sls_cde, c_feetyp_cde,
          c_clnt_mrk, c_bs_cur, n_bs_amt, c_due_cur, n_due_amt, t_due_tm,
          c_rp_cur, n_rp_amt, t_rp_tm, t_paid_tm, n_paid_amt, n_pre_amt,
          c_cha_mrk, c_cha_cls, c_cha_cde, t_pay_bgn_tm, t_pay_end_tm,
          c_dpt_cde, c_dptacc_cde, c_payer_cde, c_payer_nme, c_pay_mde_cde,
          c_bank_account, c_app_nme, c_lcn_no, t_insrnc_bgn_tm,
          t_insrnc_end_tm, c_rp_flag, c_edr_typ, c_tran_flag, c_bala_mrk,
          c_rcpt_no, c_opt_no, c_account, NULL, NULL, n_other_amt, NULL,
          t_upd_tm, c_upd_cde, t_crt_tm, n_shares_no, c_memo, c_accnt_flag,
          c_batch_no,c_prn_no,c_customer_accounts
     FROM web_fin_prm_due
   UNION ALL
   SELECT '2' AS c_due_type, c_ply_no, NULL AS c_edr_no, NULL AS c_app_no,
          c_clm_no, 1, c_prod_no, c_bsns_typ, c_slsgrp_cde, c_sls_cde,
          c_feetyp_cde, c_clnt_mrk, c_bs_cur, n_bs_amt, c_due_cur, n_due_amt,
          t_due_tm, c_rp_cur, n_rp_amt, t_rp_tm, t_paid_tm, n_paid_amt,
          n_cavpre_amt AS n_pre_amt, c_cha_mrk, c_cha_cls, c_cha_cde,
          t_pay_bgn_tm, t_pay_end_tm, c_dpt_cde, c_dptacc_cde, c_payer_cde,
          c_payer_nme, c_pay_mde_cde, c_bank_account, c_app_nme, c_lcn_no,
          NULL, NULL, c_rp_flag, NULL, c_tran_flag, c_bala_mrk, c_rcpt_no,
          c_opt_no, c_account, NULL, NULL, NULL, NULL, t_upd_tm, c_upd_cde,
          t_crt_tm, NULL, c_memo, c_accnt_flag, c_batch_no,c_prn_no,c_customer_accounts
     FROM web_fin_clm_due
   UNION ALL
   SELECT '3' AS c_due_type, c_ply_no, c_edr_no, c_app_no, c_clm_no, n_tms,
          c_prod_no, c_bsns_typ, c_slsgrp_cde, c_sls_cde, c_feetyp_cde,
          c_clnt_mrk, c_bs_cur, n_bs_amt, c_due_cur, n_due_amt, t_due_tm,
          c_rp_cur, n_rp_amt, t_rp_tm, t_paid_tm, n_paid_amt,
          0.0 AS n_pre_amt, c_cha_mrk, c_cha_cls, c_cha_cde, t_pay_bgn_tm,
          t_pay_end_tm, c_dpt_cde, c_dptacc_cde, c_payer_cde, c_payer_nme,
          c_pay_mde_cde, c_bank_account, c_app_nme, c_lcn_no, t_insrnc_bgn_tm,
          t_insrnc_end_tm, c_rp_flag, c_edr_typ, c_tran_flag, c_bala_mrk,
          c_rcpt_no, c_opt_no, c_account, NULL, NULL, NULL, NULL, t_upd_tm,
          c_upd_cde, t_crt_tm, NULL, c_memo, c_accnt_flag, c_batch_no,c_prn_no,null
     FROM web_fin_pay_due

/
