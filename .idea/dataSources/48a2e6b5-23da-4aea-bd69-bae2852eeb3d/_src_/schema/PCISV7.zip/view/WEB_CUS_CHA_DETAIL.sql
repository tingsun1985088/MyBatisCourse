CREATE VIEW WEB_CUS_CHA_DETAIL AS SELECT DISTINCT B.C_CHA_CDE,
                B.C_CHA_NME,
                B.C_DPT_CDE,
                DPT.c_Snr_Dpt,
                b.c_crt_cde,
                b.t_crt_tm,
                b.c_upd_cde,
                b.t_upd_tm,
                b.c_certf_cls,
                b.c_certf_no
  FROM WEB_CUS_CHA        B,
       WEB_ORG_DPT        DPT
 WHERE B.C_DPT_CDE = DPT.C_DPT_CDE
/
