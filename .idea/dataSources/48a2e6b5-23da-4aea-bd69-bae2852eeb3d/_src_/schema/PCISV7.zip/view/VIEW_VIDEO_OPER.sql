CREATE VIEW VIEW_VIDEO_OPER AS SELECT oper.C_Oper_Id as COperId,
                       oper.C_Oper_Cnm as COperCnm,
                       emp.C_Mobile as CMobile,
                       emp.C_Tel as CTel,
                       dpt.C_Dpt_Cde as CDptCde,
                       dpt.C_Dpt_Cnm as CDptCnm,
                       ur.C_Opgrp_Cde as COpgrpCd
          FROM web_Grt_Usr_Role ur, web_Org_Oper oper, web_Org_Dpt dpt,web_Grt_Usr_Op_Dpt op,
          (select e.C_Mobile as C_Mobile, e.C_Tel as C_Tel,e.c_emp_cde as c_emp_cde from web_Org_Emp e
          union select d.C_TEL as C_Tel,d.C_MOBILE as C_Mobile ,d.c_clnt_cde as c_emp_cde FROM Web_Cus_Client d
          union select f.C_TEL as C_Tel,f.C_MOBILE as C_Mobile ,f.c_cha_emp_cde as c_emp_cde FROM WEB_CUS_CHA_EMP f  ) emp
         WHERE
           ur.C_Oper_Id = oper.C_Oper_Id
           AND oper.C_Oper_Id = emp.C_Emp_Cde
           AND oper.C_Oper_Id =op.C_Oper_Id
           AND op.C_Dpt_Cde=dpt.C_Dpt_Cde
           AND ur.C_Dpt_Cde = dpt.C_Dpt_Cde
           AND oper.C_Is_Valid = '1'
/
