CREATE VIEW V_CLM_VHL_NOPAY_COP2 AS select --未决赔款 车险
       a.c_clm_no      as c_clm_no,
       ''              as c_rpt_no,
       a.c_ply_no      as c_ply_no,
       to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       dpt2.c_dpt_cnm  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,

       prod.c_nme_cn     as c_prod_name,
       cvrg.c_nme_cn     as c_cvrg_name,
       '个人'            as c_grp_mrk,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no
              and rownum = 1 ) as c_stk_mrk,--股东标志,
       decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,--分入标志,
       (select case when count(1)>0 then '是' else '否' end from WEB_CLM_DISPATCH_FIX_LIST D
             where d.c_accident_no = a.c_accident_no
               and D.C_DAMAGE_TYPES LIKE 'B%') as c_rs_mrk,--  '是否人伤'
       '人民币'     as  c_pay_cur,--已决赔款币种,
         0            as n_pay,--原币种已决赔款,
         0            as n_pay_rmb,--折合人民币已决赔款,
         '人民币'     as c_clmfee_cur,--已决直接理赔费用币种,
         0            as n_clmfee,--原币种已决直接理赔费用,
         0            as n_clmfee_rmb,--折合人民币已决直接理赔费用,
         '人民币'     as c_nopay_cur,--未决赔款的币种,
        greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0)) as n_nopay,--   原币种未决赔款,
        greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))  as n_nopay_rmb,--折合人民币未决赔款,
       '人民币'      as c_noclmfee_cur, --未决直接理赔费用币种,
       0 as n_noclmfee,--原币种未决直接理赔费用,
       0 as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
       to_char(a.t_acdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,
       to_char(a.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rpt_tm,--报案时间,
       to_char(a.T_RGST_TM,'yyyy-mm-dd hh24:mi:ss')  as t_rgst_tm,--立案时间,
       ''                                            as t_endcase_tm,--结案时间
       '未决' c_pay_mrk,
       a.c_kind_no,
       a.c_prod_no
  from (select m.c_clm_no,
               m.c_ply_no,
               m.n_edr_prj_no,
               rpt.t_rpt_tm,
               endcase.t_end_tm,
               m.c_prod_no,
               m.c_kind_no,
               m.c_dpt_cde,
               m.t_insrnc_bgn_tm,
               rpt.t_acdnt_tm,
               RGST.T_RGST_TM,
               m.t_insrnc_end_tm,
               m.c_inwd_mrk,
               m.c_accident_no
          from web_clm_main m
          left join WEB_CLM_RGST RGST
            on m.c_clm_no = rgst.c_clm_no
          left join web_clm_endcase_zm endcase
            on m.c_clm_no = endcase.c_clm_no
           and endcase.c_endcase_status = '03' --确认结案
           and endcase.c_end_type = '02', --正常结案
         web_clm_rpt_zm rpt

         where trunc(rpt.t_rpt_tm) <= sysdate
           and m.c_inwd_mrk = '0'
           and m.c_clm_no = rpt.c_clm_no) a,
       web_clm_ready_amt ready, ---未决赔款
       web_prd_prod prod, web_prd_cvrg cvrg,web_org_dpt dpt,web_org_dpt dpt2,
       web_fin_accntquart acc
 where (a.t_end_tm > acc.t_end_tm or
       a.t_end_tm is null)
   and acc.c_mrk = '2'
   and a.c_clm_no = ready.c_clm_main_id
   and a.c_kind_no = prod.c_kind_no
   and a.c_kind_no = cvrg.c_kind_no
   and a.c_prod_no = prod.c_prod_no
   and a.t_rpt_tm <= acc.t_end_tm
   and substr(ready.c_rdr_cde,1,6) = cvrg.c_cvrg_no
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <=acc.t_end_tm)
   and a.c_clm_no not in
       (select cncl.c_clm_main_id
          from web_clm_cncl cncl
         where cncl.t_check_tm <= acc.t_end_tm
           and cncl.c_check_opn = '1')--确认标志
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(a.c_dpt_cde,1,4)
   and nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0) <> 0
/
