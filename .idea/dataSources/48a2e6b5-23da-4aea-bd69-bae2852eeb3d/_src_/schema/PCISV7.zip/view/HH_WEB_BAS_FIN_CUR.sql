CREATE VIEW HH_WEB_BAS_FIN_CUR AS SELECT
c_cur_cde as c_cur_cde,
c_cur_cnm as c_cur_cnm ,
c_cur_enm as c_cur_enm,
c_cur_unt as c_cur_unt,
c_cur_sbl as c_cur_sbl,
t_adb_tm as t_adb_tm,
c_fin_mrk as c_fin_mrk,
c_trans_mrk as c_trans_mrk,
t_trans_tm as t_trans_tm,
c_is_valid as c_is_valid
FROM WEB_BAS_FIN_CUR
/
