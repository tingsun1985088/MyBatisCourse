CREATE VIEW V_FIN_CAVMONEY AS SELECT
C_BAL_TYP				,
C_BANK_ACCNT    ,
C_BANK_CDE      ,
C_BANK_NME      ,
C_CHECK_FLAG    ,
C_CHECK_NO      ,
C_CUR_CDE       ,
C_FEETYP_CDE    ,
C_FLOW_CDE      ,
C_FORMAFEE_NO   ,
N_ITEM_NO       ,
C_PAYER_NME     ,
C_RP_NAME       ,
C_SAVECASH_BANK ,
C_SAVECASH_NO   ,
C_SAVECASH_OPT  ,
C_SBJT_NO       ,
N_AMT           ,
N_USE_AMT       ,
T_RP_TM         ,
T_SAVECASH_TM   ,
C_CAV_PK_ID
/*              ,
C_UPD_CDE       ,

C_CRT_CDE       ,
C_CAVMNY_PK_ID  ,
C_CAVRPTYP_PK_ID,
C_RP_NME        ,
T_CRT_TM        ,
T_UPD_TM        ,
*/
FROM WEB_FIN_CAV_MNY

/
