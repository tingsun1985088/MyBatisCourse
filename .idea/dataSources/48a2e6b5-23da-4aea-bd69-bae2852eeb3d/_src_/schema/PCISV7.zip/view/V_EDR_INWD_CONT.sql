CREATE VIEW V_EDR_INWD_CONT AS select --再保前批单明细(合约分入)
       '' as c_edr_no,
       '泰山财产保险股份有限公司总公司'   as c_dpt_cnm,
       ri.c_com_cnm          as c_dpt_three,    --机构
       rpfunction.getKindName(d.c_kind_no,prod.c_prod_no,'') as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       '---'           as c_cvrg_name,
       '个人'          as c_grp_mrk,
       '---'           as c_stk_mrk,
       '分入'          as c_inwd_mrk,
       cur.c_cur_cnm        as c_prmcur_name,
       --case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end       as n_prm,
       --case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end       as n_prm_rmb,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end )   as n_prm,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end ) * get_rate(m.c_fee_cur, '01', acc.t_End_Tm)  as n_prm_rmb,
       /*m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_udr_tm,     --核保日期*/
       to_char(m.t_to_fin_tm,'yyyy-mm-dd hh24:mi:ss')                              as t_udr_tm,
       /*m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'                                as t_edr_bgn_tm,
       to_number(m.c_bill_prd_year)+1||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-14 23:59:59'                               as t_edr_end_tm,*/
       'T'||(
            case when upper(c_billprd_type) <> 'S' then m.c_uw_year ||'-'|| m.c_uw_month ||'-15 00:00:00'
              else m.c_bill_prd_year||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-15 00:00:00'
            end
       )  as t_edr_bgn_tm,
       'T'||(
            case when upper(c_billprd_type) <> 'S' then to_number(m.c_uw_year)+1 ||'-'|| m.c_uw_month ||'-14 23:59:59'
              else to_number(m.c_bill_prd_year)+1||(case when UPPER(m.c_bill_prd) = 'Q1' then '-02'
            else case when UPPER(m.c_bill_prd) = 'Q2' then '-05'
            else case when UPPER(m.c_bill_prd) = 'Q3' then '-08'
            else '-11' end end end)||'-14 23:59:59'
            end
       ) as t_edr_end_tm,
       '' as c_edr_rsn,
       '一般批改' as c_edr_type,
       to_char(acc.t_end_tm,'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       round((case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end
        /case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end
       ),4)               as n_fee_prop,
       cur.c_cur_cnm         as c_feecur_name,
       --case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end   as n_fee,
       --case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end   as n_fee_rmb,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end )  as n_fee,
       decode(m.n_month_rbk_mrk, 0, 1, m.n_month_rbk_mrk) *
        (case when p.c_pk_id is null then d.n_comm+d.n_duty+d.n_spl_comm else p.n_comm+p.n_duty+p.n_spl_comm end ) * get_rate(m.c_fee_cur, '01', acc.t_End_Tm)  as n_fee_rmb,
       /*d.c_kind_no,*/rpfunction.getKindNo(d.c_kind_no ,prod.c_prod_no,'') as c_kind_no,
       prod.c_prod_no

from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,WEB_RI_INTER_cont_BILL_prod p,
     web_prd_prod prod,web_ri_com ri,web_fin_accntquart acc, WEB_BAS_FIN_CUR CUR
where decode(m.n_month_rbk_mrk, -1, substr(m.c_bill_no, 2), m.c_bill_no) = d.c_bill_no
  and d.c_pk_id = p.c_bill_dtl_pk_id(+)
  and p.c_prod_no = prod.c_prod_no(+)
  and m.c_ri_com = ri.c_com_cde
  and m.c_to_fin_mrk = '1'
  and acc.c_mrk = '2'
  AND M.C_FEE_CUR = CUR.C_CUR_CDE
  and m.t_crt_tm <= acc.t_end_tm
  and m.t_to_fin_tm <= acc.t_end_tm
  and (upper(c_billprd_type) = 'S' or nvl(n_month_rbk_mrk,1) = -1 )
  and (case when p.c_pk_id is null then d.n_inter_prm else p.n_inter_prm end) <>0
/
