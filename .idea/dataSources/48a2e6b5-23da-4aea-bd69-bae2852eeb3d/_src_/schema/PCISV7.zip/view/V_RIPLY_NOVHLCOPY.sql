CREATE VIEW V_RIPLY_NOVHLCOPY AS select --再保分出保单明细
       ced.c_ply_no   as c_ply_no,
       case when substr(ced.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm) as 三级机构,
       rpfunction.getKindName(prod.c_kind_no,ced.c_prod_no,'')  as c_kind_name,
       prod.c_nme_cn  as c_prod_name,
       '---'          as c_cvrg_name,
       decode(nvl(base.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk,
       decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东') as c_stk_mrk,
       sum(ced.n_ced_prm)/decode(base.c_ci_mrk,'3',base.n_ci_own_prm,nvl(base.n_prm, 0)) as n_split_prop,--分出比例,
       cur.c_cur_cnm      as c_prmcur_name,--分出保费保单的币种,
       sum(ced.n_ced_prm) as n_prm,--原币种分出保费保单,
       sum(case when ced.c_riprm_cur = '01' then ced.n_ced_prm
         else ced.n_ced_prm*
           get_rate(ced.c_riprm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))) end) as n_prm_rmb,--折合人民币分出保费保单,
       to_char(base.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss')  as t_insrnc_bgn_tm,--保单保险起期,
       --to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')  as t_insrnc_end_tm,--保单保险止期,
       case when base.c_inwd_mrk = '1' and to_char(base.t_insrnc_end_tm,'hh24:mi:ss')='00:00:00' then
           to_char(base.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59' else to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')
       end as t_insrnc_end_tm,--保单保险止期,
       --decode(to_char(base.t_insrnc_end_tm,'hh24:mi:ss'),'00:00:00',to_char(base.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59',to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')) as t_insrnc_end_tm,
       to_char(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       cur.c_cur_cnm    as c_feecur_name,--摊回手续费币种,
       sum(ced.n_comm)  as n_fee,--原币种摊回手续费,
        sum(case when ced.c_riprm_cur = '01' then ced.n_comm+nvl(ced.n_duty,0)
         else (ced.n_comm+nvl(ced.n_duty,0))*
           get_rate(ced.c_riprm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))) end)  as n_fee_rmb,--折合人民币摊回手续费,

       ced.n_comm_prpt as n_comm_prpt,--手续费比率
       prod.c_kind_no,ced.c_prod_no
      from /*web_ri_plyedr_due due,*/ web_ri_plyedr_ced ced ,--web_prd_kind kind,
           web_prd_prod prod,web_org_dpt dpt,web_bas_fin_cur cur,web_ply_base base,web_ply_applicant app,web_org_dpt dpt2
      where prod.c_prod_no = ced.c_prod_no
        --and kind.c_kind_no = prod.c_kind_no
        and substr(ced.c_prod_no,1,2) <> '03'
        and ced.c_cont_cde not in('BB','04','AR')
        and dpt.c_dpt_cde = substr(ced.c_dpt_cde,1,2)--(select b.c_dptacc_cde from web_org_dpt b where b.c_dpt_cde = due.c_dpt_cde)
        and substr(ced.c_dpt_cde,1,4) = dpt2.c_dpt_cde
        and ced.n_edr_prj_no = 0
        and ced.c_ply_no= base.c_ply_no
        and base.n_edr_prj_no = 0
        and ced.c_riprm_cur = cur.c_cur_cde
        and base.c_app_no = app.c_app_no(+)
        -----------------
        and exists (select 1
          from web_ri_plyedr_due b
         where b.c_app_no = ced.c_app_no
           and b.n_split_seq = ced.n_split_seq
           and b.n_rbk_seq = ced.n_rbk_seq
           and b.c_ply_no = base.c_ply_no
           and b.n_edr_prj_no = 0
           and trunc(b.t_ridue_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and decode(ced.c_cont_cde,'FA',C_FAC_TO_FIN_MRK,'1') = '1'
           and decode(b.n_edr_prj_no,0,trunc(b.t_insrnc_bgn_tm),trunc(b.t_edr_bgn_tm))<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and trunc(b.t_udr_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and b.c_status = 'C')
        ------------------
        group by ced.c_ply_no,ced.c_edr_no,--ced.n_split_seq,ced.c_cont_cde,
                 ced.c_prod_no,--ced.c_ri_com, ced.n_comm_prpt, ced.n_duty_prpt,
                 --kind.c_nme_cn,
                 base.c_inwd_mrk,
                 case when substr(ced.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end,   --机构
                 dpt2.c_dpt_cnm,
                 prod.c_nme_cn,--ced.c_ri_brkr,
                 dpt.c_dpt_cnm,base.n_prm,
                 ced.c_prod_no,prod.c_kind_no,
                 cur.c_cur_cnm,
                 ced.c_riprm_cur,base.c_inwd_mrk,
                 decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东'),
                 decode(base.c_ci_mrk,'3',base.n_ci_own_prm,nvl(base.n_prm, 0)),
                 --decode(nvl(due.c_stock_mrk,'0'),'0','非股东','股东'),
                 ced.n_edr_prj_no,ced.n_comm_prpt,base.c_grp_mrk,
                 to_char(base.t_udr_tm,'yyyy-mm-dd hh24:mi:ss'),
                 to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
                 case when base.c_inwd_mrk = '1' and to_char(base.t_insrnc_end_tm,'hh24:mi:ss')='00:00:00' then
                     to_char(base.t_insrnc_end_tm,'yyyy-mm-dd')||' 23:59:59' else to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')
                 end
                 --to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss')
/
