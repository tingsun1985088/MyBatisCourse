CREATE VIEW T_PAYMODE AS SELECT C_CDE mode_id, --收费方式代码
              C_CNM mode_name--收费方式名称
          FROM WEB_BAS_CODELIST t
         WHERE C_PAR_CDE = 'shoufeifangshi'
         ORDER BY t.C_CDE
/
