CREATE VIEW V_CLM_VHL_NOPAY AS select --未决赔款 车险
       m.c_clm_no      as c_clm_no,
       ''              as c_rpt_no,
       m.c_ply_no      as c_ply_no,
       to_char(m.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(m.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(m.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       dpt2.c_dpt_cnm  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,

       prod.c_nme_cn     as c_prod_name,
       cvrg.c_nme_cn     as c_cvrg_name,
       '个人'            as c_grp_mrk,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no
              and rownum = 1 ) as c_stk_mrk,--股东标志,
       decode(nvl(m.c_Inward,'0'),'0','非分入','分入') as c_inwd_mrk,--分入标志,
       (select case when count(1)>0 then '是' else '否' end from WEB_CLM_DISPATCH_FIX_LIST D
             where d.c_accident_no = m.c_accident_no
               and D.C_DAMAGE_TYPES LIKE 'B%') as c_rs_mrk,--  '是否人伤'
       '人民币'     as  c_pay_cur,--已决赔款币种,
         0            as n_pay,--原币种已决赔款,
         0            as n_pay_rmb,--折合人民币已决赔款,
         '人民币'     as c_clmfee_cur,--已决直接理赔费用币种,
         0            as n_clmfee,--原币种已决直接理赔费用,
         0            as n_clmfee_rmb,--折合人民币已决直接理赔费用,
         '人民币'     as c_nopay_cur,--未决赔款的币种,
       /*greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0)) as n_nopay,*/
       /*case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                 greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end as*/
        DTL.N_SUM_ESTMT_AMT n_nopay,-- 原币种未决赔款,
       /*greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))  as n_nopay_rmb,*/
      /* case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                  greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end */
        DTL.N_SUM_ESTMT_AMT as n_nopay_rmb,--折合人民币未决赔款,
       '人民币'      as c_noclmfee_cur, --未决直接理赔费用币种,
       nvl(DTL.N_CLM_FEE,0) as n_noclmfee,--原币种未决直接理赔费用,
       nvl(DTL.N_CLM_FEE,0) as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
       to_char(M.T_ACCDNT_TM,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,
       to_char(M.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rpt_tm,--报案时间,
       to_char(M.T_CLM_RGST_TM,'yyyy-mm-dd hh24:mi:ss')  as t_rgst_tm,--立案时间,
       ''                                            as t_endcase_tm,--结案时间
       '未决' c_pay_mrk,
       m.c_kind_no,
       m.c_prod_no,
       M.C_JY_FLAG --1或空 软通 2 精友
  from
       /*web_clm_main m
       left join WEB_CLM_RGST rgst on m.c_clm_no = rgst.c_clm_no,
       web_clm_rpt_zm rpt,*/
       WEB_FIN_CLM_MAIN M,
       WEB_FIN_CLM_DETAIL DTL,
      -- web_clm_ready_amt ready, ---未决赔款
       web_prd_prod prod, web_prd_cvrg cvrg,web_org_dpt dpt,web_org_dpt dpt2,
       web_fin_accntquart acc
 where --m.c_clm_no = rpt.c_clm_no
       M.C_CLM_NO = DTL.C_CLM_NO
   --and m.c_clm_no = ready.c_clm_main_id
   and m.c_kind_no = prod.c_kind_no
   and m.c_kind_no = cvrg.c_kind_no
   and m.c_prod_no = prod.c_prod_no
   --and m.c_clm_no = '400000203262013005568'
   --and m.c_prod_no = '0320'
   and substr(DTL.C_INSRNC_CDE,1,6) = cvrg.c_cvrg_no
   /*and ready.n_rgst_num =
       (select max(n_rgst_num)
          from WEB_CLM_READY_AMT
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <=acc.t_end_tm
           and c_jy_flag is null )--软通数据*/
   AND  DTL.N_SEQ_NUM =
       (select max(N_SEQ_NUM)
          from WEB_FIN_CLM_DETAIL DT
         where DT.C_CLM_NO = DTL.C_CLM_NO
           and DT.T_ASSESS_TM <=acc.t_end_tm)
   AND NOT EXISTS (SELECT 1
      FROM WEB_CLM_CNCL CNL
     WHERE CNL.C_CLM_MAIN_ID = M.C_CLM_NO
       AND CNL.C_CHECK_OPN = '1'
       AND CNL.T_CHECK_TM <= acc.t_end_tm
       AND CNL.C_CLM_MAIN_ID NOT IN ('400000103202014000004','400000103202014000010') --对接时产生的重复赔案号，从精友取数
       )
   AND NOT EXISTS (SELECT 1
      FROM WEB_CLM_CNL_JY JY
     WHERE JY.C_CLM_NO = M.C_CLM_NO
       AND JY.T_CNL_TM <= acc.t_end_tm
       AND JY.C_CLM_NO NOT IN ('400000103202014000006','400000103202014000009')--对接时产生的重复赔号，从软通取数
       --AND JY.C_CLM_NO <> '400000103202014000006'--特殊处理
       )
   and acc.c_mrk = '2'
   and dpt.c_dpt_cde = substr(m.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(m.c_dpt_cde,1,4)
   --and nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0) + nvl(ready.n_clmfee_amt,0) <> 0
   --AND (NVL(READY.N_PREP_AMT, 0)+ NVL(READY.N_AMT,0)+ NVL(READY.N_CHECKLOS_HELP_FEE, 0) + NVL(READY.N_CLMFEE_AMT,0)) <> 0
   AND DTL.N_SUM_ESTMT_AMT + DTL.N_CLM_FEE <> 0
   AND DTL.C_CLM_MAINSTATUS NOT IN ('38','39')
   AND DTL.C_KIND_NO = '03'
   and m.c_kind_no = '03'
   /*--存在结案暂存情况
   and (
       not exists (
            select 1 from web_clm_endcase_zm endcase
            where endcase.c_clm_no = m.c_clm_no
              and endcase.c_endcase_status = '03' --确认结案
              and endcase.c_end_type = '02'       --正常结案
       )
      or
      exists (
            select 1 from web_clm_endcase_zm endcase
            where endcase.c_clm_no = m.c_clm_no
              and endcase.t_end_tm > acc.t_end_tm
              and endcase.c_endcase_status = '03' --确认结案
              and endcase.c_end_type = '02'       --正常结案
       )
   )
   AND ready.C_JY_FLAG IS NULL --软通数据
   AND m.C_CLM_NO NOT IN ('400000103202014000004','400000103202014000010')--对接时产生的重复赔案号，从精友取数
   --20140111增加精友理赔数据
   UNION ALL
   select m.c_clm_no c_clm_no,
       ''         c_rpt_no,
       m.c_ply_no c_ply_no,
       to_char(BASE.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_bgn_tm,
       to_char(BASE.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') t_insrnc_end_tm,
       case when substr(m.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm1,
       dpt2.c_dpt_cnm  as c_dpt_cnm2,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn     c_prod_name,--产品,
       cvrg.c_nme_cn     c_cvrg_name,--险别,
       '个人'        c_group_mrk,
       (select decode(c_stk_mrk,'192002','股东','非股东')
         from web_ply_applicant applic where applic.c_ply_no=m.c_ply_no
              and rownum = 1 ) as c_stk_mrk,
       decode(nvl(m.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,
       '---'        as C_RS_MRK ,\*是否人伤*\
       '人民币'     c_pay_cur,
       0 as n_pay_amt,--原币种已决赔款,
       0 as n_pay_rmbamt,
       '人民币'     c_clmfee_cur,
       0  as n_clmfee_amt,\*原币种已决直接理赔费用,*\
       0  as n_clmfee_rmbamt,\*折合人民币已决直接理赔费用,*\
       '人民币'     c_nopay_cur,\*未决赔款币种,*\
       case when nvl(r.n_prep_amt, 0) = 0 then
                         nvl(r.n_amt,0)+ nvl(r.n_checklos_help_fee, 0)
            else
                 greatest((nvl(r.n_amt,0)+ nvl(r.n_checklos_help_fee, 0)),nvl(r.n_prep_amt, 0))
            end     n_nopay_amt,\*原币种未决赔款,*\
       case when nvl(r.n_prep_amt, 0) = 0 then
                         nvl(r.n_amt,0)+ nvl(r.n_checklos_help_fee, 0)
            else
                 greatest((nvl(r.n_amt,0)+ nvl(r.n_checklos_help_fee, 0)),nvl(r.n_prep_amt, 0))
            end     n_nopay_rmbamt,\*折合人民币未决赔款,*\
       '人民币'                  c_noclmfee_cur,\*未决直接理赔费用币种,*\
       NVL(r.n_clmfee_amt,0)            n_noclmfee_amt,\*原币种未决直接理赔费用,*\
       NVL(r.n_clmfee_amt,0)           n_noclmfee_rmbamt,\*折合人民币未决直接理赔费用,*\
       to_char(m.t_acdnt_tm,'yyyy-mm-dd hh24:mi:ss') t_acdnt_tm,\*出险时间,*\
       to_char(m.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')   t_rpt_tm,\*报案时间,*\
       to_char(m.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') T_RGST_TM,\*立案时间,*\
       to_char(R.t_Update,'yyyy-mm-dd hh24:mi:ss') t_end_tm,\*结案时间,*\
       '未决'                                           c_pay_mrk,
       m.c_kind_no,
       m.c_prod_no,
       '2' c_jy_flag --1 软通 2 精友
  from WEB_CLM_MAIN_JY            m,
       WEB_PLY_BASE            BASE,
       WEB_CLM_READY_AMT       R,
       web_prd_cvrg            cvrg,
       web_org_dpt             dpt,
       web_org_dpt             dpt2,
       web_prd_prod            prod,
       web_fin_accntquart         acc
 where m.c_clm_no = r.c_clm_main_id
   and m.t_rpt_tm <= acc.t_end_tm --报案时间在评估月内的数据
   --and m.t_rpt_tm >= acc.t_bgn_tm
   and R.t_Update <= acc.t_end_tm
   --and R.t_Update >= acc.t_bgn_tm
   and substr(R.c_Rdr_Cde, 1, 6) = cvrg.c_cvrg_no(+) --险别
   and m.c_prod_no = prod.c_prod_no
   and dpt.c_dpt_cde = substr(m.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(m.c_dpt_cde,1,4)
   AND BASE.C_PLY_NO = M.C_PLY_NO
   AND BASE.N_EDR_PRJ_NO = 0 --取对应保单的起止期
   --AND m.c_prod_no <> '0320' --商车
   --AND NVL(R.N_AMT,0)+ NVL(R.N_CHECKLOS_HELP_FEE, 0) + NVL(R.N_CLMFEE_AMT,0)<> 0
   AND (NVL(R.N_PREP_AMT, 0)+ NVL(R.N_AMT,0)+ NVL(R.N_CHECKLOS_HELP_FEE, 0) + NVL(R.N_CLMFEE_AMT,0)) <> 0
   and R.c_task_type not in ('38','39') --未决状态
   and acc.c_mrk = '2'
   AND R.C_JY_FLAG = '2' --精友数据标识
   AND R.N_RGST_NUM = (SELECT MAX(T.N_RGST_NUM) FROM WEB_CLM_READY_AMT T WHERE T.C_CLM_MAIN_ID = R.C_CLM_MAIN_ID AND T.T_UPDATE <= ACC.T_END_TM AND T.C_JY_FLAG = '2') --最新的未决状态
   \*AND NOT EXISTS (SELECT 1 FROM WEB_CLM_READY_AMT READY WHERE READY.C_CLM_MAIN_ID = R.C_CLM_MAIN_ID AND READY.C_TASK_TYPE IN ('38','39') AND READY.T_UPDATE <= ACC.T_END_TM AND READY.C_JY_FLAG = '2' ) *\--没有结案
   AND NOT EXISTS (SELECT 1 FROM WEB_CLM_CNL_JY CNL WHERE CNL.C_CLM_NO = R.C_CLM_MAIN_ID AND CNL.T_CNL_TM <= ACC.T_END_TM ) --不存在撤销案
   AND M.C_CLM_NO NOT IN ('400000103202014000006','400000103202014000009')--对接时产生的重复赔号，从软通取数*/
/
