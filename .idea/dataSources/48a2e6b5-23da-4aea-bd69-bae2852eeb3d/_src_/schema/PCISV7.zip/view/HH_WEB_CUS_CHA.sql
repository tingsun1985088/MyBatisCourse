CREATE VIEW HH_WEB_CUS_CHA AS SELECT
c_cha_cde,
c_cha_nme,
c_cha_abbr,
c_cha_cls,
c_cha_type,
c_dpt_cde,
c_cha_mrk,
c_certf_no,
c_tel,
c_addr,
c_front_back_mrk,
c_auth_mrk,
c_stock_memo,
c_status,
c_handle,
c_cha_subtype,
c_trans_mrk,
c_action_typ
 FROM WEB_CUS_CHA  where c_dpt_cde like '10%'
/
