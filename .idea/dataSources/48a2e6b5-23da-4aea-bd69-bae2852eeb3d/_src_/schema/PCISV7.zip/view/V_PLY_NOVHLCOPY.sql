CREATE VIEW V_PLY_NOVHLCOPY AS select --再保前保单明细(非车,交强险)
       a.c_ply_no    as c_ply_no,    --保单号
       case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
       dpt2.c_dpt_cnm as  三级机构,
       rpfunction.getKindName(prod.c_kind_no,a.c_prod_no,'')  as c_kind_name, --险类
       prod.c_nme_cn as c_prod_name,   --产品
       '---'         as c_cvrg_name,   --险别
       decode(nvl(a.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk, --团单标志
       decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东') as c_stk_mrk, --股东标志
       decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入')  as c_inwd_mrk,--分入标志
       cur.c_cur_cnm as c_prmcur_name,                                  --币种
       decode(a.c_ci_mrk,'3',a.n_ci_own_prm,nvl(a.n_prm, 0)) as n_prm,  --原币种保费
       case when a.c_prm_cur = '01' then decode(a.c_ci_mrk,'3',a.n_ci_own_prm,nvl(a.n_prm, 0))
         else decode(a.c_ci_mrk,'3',a.n_ci_own_prm,nvl(a.n_prm, 0))*
             get_rate(a.c_prm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))) ) end as n_prm_rmb, --折人民币保费
       to_char(a.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm, --保险起期
       to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm, --保险止期
       to_char(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       f.N_FEE_PROP  as n_fee_prop,   --手续费比例
       cur.c_cur_cnm as c_feecur_name,--手续费币种
       f.N_FEE       as n_fee,        --原币手续费
       case when a.c_prm_cur = '01' then f.N_FEE
         else f.N_FEE*get_rate(a.c_prm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))) ) end as n_fee_rmb,--折人民币手续费
       prod.c_kind_no as c_kind_no,
       a.c_prod_no    as c_prod_no

  from web_ply_base a, WEB_ply_FEE f, /*web_prd_kind kind,*/web_bas_fin_cur cur,
       web_prd_prod prod,web_org_dpt dpt,web_ply_applicant app,web_org_dpt dpt2
 where  a.c_app_no = f.c_app_no
   and a.c_app_no = app.c_app_no
   and trunc(a.t_insrnc_bgn_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and nvl(a.c_edr_no, '---') = '---'
   and f.C_FEETYP_CDE = 'S'
   and a.c_prod_no = prod.c_prod_no
   and trunc(a.t_udr_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)--(select b.c_dptacc_cde from web_org_dpt b where b.c_dpt_cde = a.c_dpt_cde)
   and substr(a.c_dpt_cde,1,4) = dpt2.c_dpt_cde
   and a.c_prm_cur = cur.c_cur_cde
   --and kind.c_kind_no <> '06'
   and exists (
           select 1 from web_prd_prod prod where prod.c_prod_no = a.c_prod_no and (prod.c_prod_no='0320' or prod.c_kind_no <> '03' ))
/
