CREATE VIEW WEB_PRD_PROD_DETAIL AS select prod.c_kind_no,
       kind.c_nme_cn,
       kind.c_nme_en,
       prod.c_prod_no,
       prod.c_nme_cn as c_nme_name,
       prod.c_status,
       prod.c_crt_cde,
       prod.t_crt_tm,
       prod.c_upd_cde,
       prod.t_upd_tm
  from web_prd_kind kind, WEB_PRD_PROD prod
where kind.c_kind_no = prod.c_kind_no
/
