CREATE VIEW V_FIN_ACCNTPERIOD AS SELECT
T_BGN_TM						,
C_CRT_CDE           ,
T_END_TM            ,
C_PERIOD_NAME       ,
C_TP_FLAG           ,
C_UPD_CDE           ,
T_ADB_TM            ,
T_CRT_TM            ,
T_UPD_TM
/*
C_IS_VALID
*/
FROM WEB_BAS_FIN_ACCT_PERIOD

/
