CREATE VIEW V_EDR_INWDCOPY AS select --再保前批单明细(分入)
       inwd.c_edr_no  as c_edr_no,     --批单号
       dpt.c_dpt_cnm  as c_dpt_cnm,    --机构
       '---'          as 三级机构,    --机构
       rpfunction.getKindName(kind.c_kind_no,base.c_prod_no,'')  as c_kind_name, --险类
       prod.c_nme_cn  as c_prod_name,  --产品
       '---'          as c_cvrg_name,  --险别
       '---'          as c_grp_mrk,    --团单标志
       '---'          as c_stk_mrk,    --股东标志
       '分入'         as c_inwd_mrk,   --分入标志
       cur.c_cur_cnm  as c_cur_name,   --币种
       inwd.n_own_gr_prm_var as n_prm, --原币种批单保费
       case when inwd.c_inwd_cur_cde = '01' then nvl(inwd.n_own_gr_prm_var,0)
         else
           nvl(inwd.n_own_gr_prm_var,0)*get_rate(inwd.c_inwd_cur_cde,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
        end  as n_prm_rmb,             --折人民币原币种批单保费
       to_char(base.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       to_char(base.t_edr_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_bgn_tm, --批单生效日期
       to_char(base.t_edr_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_end_tm, --批单止期
       get_edrsn(base.c_app_no,kind.c_kind_no) as c_edr_rsn,               --批改原因
       decode(nvl(base.c_edr_type,'1'),'1','一般批改','3','退保','2','注销') as c_edr_type,--批改类型
       to_char(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       inwd.n_inwd_comm_rate as n_fee_prop,
       cur.c_cur_cnm         as c_feecur_name,
       inwd.n_inwd_comm_var  as n_fee,
       case when inwd.c_inwd_cur_cde = '01' then inwd.n_inwd_comm_var
         else inwd.n_inwd_comm_var*get_rate(inwd.c_inwd_cur_cde,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
       end  as n_fee_rmb,
       kind.c_kind_no,
       base.c_prod_no
from web_ply_inwd inwd,
     web_ply_base base,
     web_org_dpt dpt,
     web_prd_kind kind,
     web_prd_prod prod,
     web_bas_fin_cur cur
where inwd.c_app_no = base.c_app_no
  and base.c_dpt_cde = dpt.c_dpt_cde
  and base.c_edr_no is not null
  and substr(base.c_prod_no,1,2) = kind.c_kind_no
  and base.c_prod_no = prod.c_prod_no
  and inwd.C_INWD_CUR_CDE = cur.c_cur_cde
  and trunc(base.t_udr_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
  and trunc(base.t_edr_bgn_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
  and trunc(base.t_insrnc_bgn_tm)<=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
/
