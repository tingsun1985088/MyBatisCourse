CREATE VIEW V_RICLM_NOPAYCOPY AS select --再保分出未决赔款
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,--报案号
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       --dpt.c_dpt_cnm   as c_dpt_cnm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as 三级机构,
       --rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'')  as c_kind_name,
       case when pend.c_cvrg_no is not null then decode(cvrg.c_jy_flg,'0','意外伤害保险','短期健康保险')
         else rpfunction.getKindName(prod.c_kind_no,prod.c_prod_no,'')  end as  kindName,
       prod.c_nme_cn   as c_prod_name,
       '---'           as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,--团单标志,
       decode(nvl(due.c_stock_mrk, '0'), '0', '非股东', '股东') as c_stk_mrk,--股东标志,
       '人民币'        as  c_pay_cur,--已决赔款的币种,
       0               as n_pay,--原币种已决赔款,
       0               as n_pay_rmb,--折合人民币已决赔款,
       '人民币'        as c_clmfee_cur,--已决直接理赔费用币种,
       0               as n_clmfee,--原币种已决直接理赔费用,
       0               as n_clmfee_rmb,--折合人民币已决直接理赔费用,
       cur.c_cur_cnm   as c_nopay_cur,--未决赔款的币种,
       sum(ced.n_clm_amt * ((pend.n_this_pend) /
       (/*pend.n_this_pend +pend.n_clmfee*/
         select sum(a.n_this_pend+a.n_clmfee) from web_clm_pend a where a.c_clm_no = due.c_clm_no and a.n_pend_tms = pend.n_pend_tms
       ))) as n_nopay,-- 原币种未决赔款,

       sum(case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt * (pend.n_this_pend /(
             select sum(a.n_this_pend+a.n_clmfee) from web_clm_pend a where a.c_clm_no = due.c_clm_no and a.n_pend_tms = pend.n_pend_tms
           ))
         else ced.n_clm_amt * (pend.n_this_pend /(
             select sum(a.n_this_pend+a.n_clmfee) from web_clm_pend a where a.c_clm_no = due.c_clm_no and a.n_pend_tms = pend.n_pend_tms
           ))*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end)  as n_nopay_rmb,-- 折合人民币未决赔款,
       cur.c_cur_cnm   as c_noclmfee_cur, -- 未决直接理赔费用币种,
       sum(ced.n_clm_amt *
       (pend.n_clmfee / (
           select sum(a.n_this_pend+a.n_clmfee) from web_clm_pend a where a.c_clm_no = due.c_clm_no and a.n_pend_tms = pend.n_pend_tms
       ))) as n_noclmfee,--原币种未决直接理赔费用,
       sum(case when ced.c_riclm_cur = '01'
         then ced.n_clm_amt*(pend.n_clmfee/(
              select sum(a.n_this_pend+a.n_clmfee) from web_clm_pend a where a.c_clm_no = due.c_clm_no and a.n_pend_tms = pend.n_pend_tms
           ))
         else ced.n_clm_amt*(pend.n_clmfee/(
              select sum(a.n_this_pend+a.n_clmfee) from web_clm_pend a where a.c_clm_no = due.c_clm_no and a.n_pend_tms = pend.n_pend_tms
           ))*
              get_rate(ced.c_riclm_cur,'01',acc.t_end_tm)
          end)  as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,--报案时间,
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,--立案时间,
       ''                                               as t_endcase_tm,--结案时间
       prod.c_kind_no,prod.c_prod_no
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_prd_prod      prod,
       --web_ri_plyedr_due plyedr,
       --web_prd_kind      kind,
       web_org_dpt       dpt,
       web_org_dpt       dpt2,
       web_clm_rpt       rpt,
       web_clm_pend      pend,
       web_clm_main      m,
       web_ply_base      base,
       web_bas_fin_cur   cur,
       web_prd_cvrg      cvrg,
       web_fin_accntquart acc
 where due.c_clm_no = ced.c_clm_no
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and m.c_ply_no = base.c_ply_no
   and pend.c_cvrg_no = cvrg.c_cvrg_no(+)
   and nvl(m.n_edr_prj_no,0) = base.n_edr_prj_no
   and m.c_clm_no = due.c_clm_no
   and due.c_clm_no = rpt.c_clm_no
   and due.c_status = 'C' --in ('B', 'C')
   and prod.c_kind_no <> '03'
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and due.t_ridue_tm <= acc.t_end_tm
   and due.t_ridue_tm >= acc.t_bgn_tm
   --and prod.c_kind_no = kind.c_kind_no
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and pend.c_clm_no = due.c_clm_no/*
   and m.c_kind_no = '06'*/
   and acc.c_mrk='2'
   and due.n_pend_tms=
       (select max(n_pend_tms) from web_ri_pend_due
             where c_clm_no=due.c_clm_no and due.t_ridue_tm <= acc.t_end_tm and c_status = 'C')
   and pend.n_pend_tms =
       (select max(n_pend_tms)
          from web_clm_pend
         where c_clm_no = pend.c_clm_no
           and t_pend_tm <= acc.t_end_tm)
   and pend.c_pend_source <> '6'
    and not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and c.t_cnl_tm<=acc.t_end_tm) or
            ( c.c_cnl_typ='1' and c.t_chk_tm <=acc.t_end_tm
             and ((c.t_renew_tm is not null and c.t_renew_tm >acc.t_end_tm) or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)
                                  from web_clm_cancel
                                 where trunc(t_chk_tm) <=acc.t_end_tm
                                   and c_chk_conc = '0'
                                   and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1'))
            and  c.c_chk_conc = '0' )  and c_clm_no = due.c_clm_no)
   group by
         due.c_clm_no ,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
         substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
         to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
         prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
         to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
         to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
         to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') ,
         prod.c_kind_no,prod.c_prod_no, pend.c_cvrg_no,cvrg.c_jy_flg
/
