CREATE VIEW HH_WEB_PRD_PROD_CVRG_REL AS SELECT
c_prod_no,
c_cvrg_no,
c_chk,
c_typ,
n_disp_ord,
c_sum_flag
 FROM web_prd_prod_cvrg_rel
/
COMMENT ON VIEW HH_WEB_PRD_PROD_CVRG_REL IS 'snapshot table for snapshot REPORTHH1.hh_WEB_PRD_PROD_CVRG_REL'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD_CVRG_REL.C_CHK IS '  0,1'
/
COMMENT ON COLUMN HH_WEB_PRD_PROD_CVRG_REL.C_TYP IS '  0:主险;1:附加险;2:扩展责任'
/
