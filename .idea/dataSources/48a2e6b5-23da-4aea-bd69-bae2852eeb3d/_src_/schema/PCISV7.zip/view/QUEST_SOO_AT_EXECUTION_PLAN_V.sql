CREATE VIEW QUEST_SOO_AT_EXECUTION_PLAN_V AS SELECT trace_file_id, ep.sql_id, ep.parse_id, ep.ID, ep.cnt, ep.pid,
          ep.pos, ep.obj, ep.cr, ep.pr, ep.pw, ep.time_us,
          o.operation_string op
     FROM quest_soo_at_execution_plan ep JOIN quest_soo_at_operations o
          USING (trace_file_id, operation_id)

/
