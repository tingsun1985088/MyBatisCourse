CREATE VIEW V_FIN_PREMONEY AS SELECT
C_BSNS_TYP              ,
C_CAV_PK_ID             ,
C_CHA_CDE               ,
C_CHA_CLS               ,
C_CHECK_FLAG            ,
C_CUR_CDE               ,
C_DPT_CDE               ,
N_ITEM_NO               ,
C_PAYER_NME             ,
C_PRE_FLAG              ,
C_PROD_NO               ,
C_RI_COM                ,
C_RPPRE_FLAG            ,
C_SLS_CDE               ,
N_PRE_AMT               ,
N_USEPRE_AMT            ,
T_CRT_TM                ,
T_UPD_TM          ,
C_PREMNY_PK_ID    ,
'1'
/*                      ,
C_CRT_CDE               ,
C_CURT_DPT_CDE          ,
C_SBJT_NO               ,
C_UPD_CDE               ,
*/
FROM WEB_FIN_PRE_MNY

/
