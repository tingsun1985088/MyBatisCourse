CREATE VIEW V_FIN_APPLICATIONFEE AS SELECT
C_ACCOUNTS_NAME						,
C_BAL_TYPE                ,
C_BANK_ACCOUNTS           ,
C_BANK_CDE                ,
C_CITY                    ,
C_COMPANY_ACCOUNTS        ,
C_COMPANY_OPENBANK        ,
C_CUR_CDE                 ,
C_CUSTOMER_ACCOUNTS       ,
C_DPTACC_CDE              ,
C_MAIL                    ,
C_MOBILE_PHONE            ,
C_OPEN_CITY               ,
C_PROD_NO                 ,
C_PROVINCES               ,
C_RCPT_NO                 ,
C_RECEIVE_NO              ,
C_USE                     ,
N_APPLICATIONS_AMT        ,
N_HASAPPLIED_AMT          ,
N_TOTAL_AMOUNT            ,
T_ALLOCATED_TM            ,
T_APPLICATIONS_TM         ,
T_BGN_TM                  ,
T_DESIRE_DATE             ,
T_DESIRE_TIME

FROM WEB_FIN_APPLICATIONFEE

/
