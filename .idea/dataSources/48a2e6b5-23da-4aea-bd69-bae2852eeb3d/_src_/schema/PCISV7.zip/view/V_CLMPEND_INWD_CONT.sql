CREATE VIEW V_CLMPEND_INWD_CONT AS select '---'          as c_clm_no,
       '---'          as c_rpt_no,--报案号,
       '---'          as c_ply_no,
       '---'          as t_insrnc_bgn_tm,
       '---'          as t_insrnc_end_tm,
       '泰山财产保险股份有限公司总公司'   as c_dpt_cnm,
       ri.c_com_cnm                       as c_dpt_three,    --机构
       rpfunction.getKindName(d.c_kind_no,p.c_prod_no,'') as c_kind_name,
       nvl(prod.c_nme_cn,'---')     as c_prod_name,
       '---'             as c_cvrg_name,
       '---'             as c_grp_mrk,--团单标志,
       '--'              as c_stk_mrk, --股东标志,
       '分入'            as c_inwd_mrk,
       '---'             as c_rs_mrk,
       CUR.C_CUR_CNM          as c_pay_cur,
       case when p.c_pk_id is null then d.n_clm_amt else p.n_clm_amt end  as n_pay,     -- 原币种已决赔款,
       get_rate(M.C_FEE_CUR,'01', ACC.T_END_TM) * (case when p.c_pk_id is null then d.n_clm_amt else p.n_clm_amt end)  as n_pay_rmb, --折合人民币已决赔款,
       '人民币'              as c_clmfee_cur,--已决直接理赔费用币种,
       0                     as n_clmfee,    --原币种已决直接理赔费用,
       0                     as n_clmfee_rmb,--折合人民币已决直接理赔费用,
       CUR.C_CUR_CNM     as c_nopay_cur,--未决赔款币种,
       case when p.c_pk_id is null then d.n_outstanding_amt else p.n_outstanding_amt end as n_nopay,--原币种未决赔款,
       get_rate(M.C_FEE_CUR,'01', ACC.T_END_TM) * (case when p.c_pk_id is null then d.n_outstanding_amt  else p.n_outstanding_amt end) as n_nopay_rmb,--折合人民币未决赔款,
       '人民币'     as c_noclmfee_cur,--未决直接理赔费用币种,
       0            as n_noclmfee,--原币种未决直接理赔费用,
       0            as n_noclmfee_rmb,--折合人民币未决直接理赔费用,
       --to_char(acc.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,
       --'2012-10-15 00:00:00'                            as t_accdnt_tm,--出险时间,
       /*m.c_uw_month,
       m.c_bill_prd,
       m.c_bill_month,
       m.c_billprd_type,*/
       'T'||case when m.c_billprd_type = 'S'
            then (m.c_bill_year||(case when m.c_bill_prd = 'Q1' then '-01'
            else case when m.c_bill_prd = 'Q2' then '-04'
            else case when m.c_bill_prd = 'Q3' then '-07'
            else '-10' end end end)||'-15')
              else
                 (
                   case when m.c_bill_month = '01' then to_number(m.c_bill_year)-1 || '-12-15'
                             else m.c_bill_year||'-'||(to_number(m.c_bill_month)-1)|| '-15' end
                 )
                 /*(m.c_bill_year||(case when m.c_bill_month in ('01','02','03') then '-02'
            else case when c_bill_month in ('04','05','06') then '-05'
            else case when c_bill_month in ('07','08','09') then '-08'
            else '-11' end end end)||'-15')  */
               end as t_accdnt_tm, --出险时间,
       ''                                               as t_rpt_tm, --报案时间,
       ''                                               as t_rgst_tm,--立案时间,

       'T'||case when (case when p.c_pk_id is null then nvl(d.n_clm_amt,0) else nvl(p.n_clm_amt,0) end) <> 0
            then (
              case when m.c_billprd_type = 'S'
                then (m.c_bill_year||(case when m.c_bill_prd = 'Q1' then '-02'
                else case when m.c_bill_prd = 'Q2' then '-05'
                else case when m.c_bill_prd = 'Q3' then '-08'
                else '-11' end end end)||'-15')
                  else m.c_bill_year||'-'||m.c_bill_month||'-15'
                  end
              )
             else '' end as t_endcase_tm,--结案时间
       '未决' c_pay_mrk,
       d.c_kind_no,
       p.c_prod_no

  from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,WEB_RI_INTER_cont_BILL_prod p,
       web_prd_prod prod,web_ri_com ri,web_fin_accntquart acc, WEB_BAS_FIN_CUR CUR
where m.c_pk_id = d.c_main_pk_id
  and d.c_pk_id = p.c_bill_dtl_pk_id(+)
  and p.c_prod_no = prod.c_prod_no(+)
  and m.c_ri_com = ri.c_com_cde
  and m.c_to_fin_mrk = '1'
  and acc.c_mrk = '2'
  AND M.C_FEE_CUR = CUR.C_CUR_CDE
  and m.t_crt_tm<= acc.t_end_tm
/
