CREATE VIEW WEB_BASE_CARMODELINFO AS select jy.VEHICLE_CODE        ModelCode, --  精友车型代码vehiclecode
       jy.VEHICLE_NAME        ModelName, --  车型名称vehiclename
       jy.REMARK              ModelDesc, --  备注remark
       jy.BRAND_NAME          Brand, --  品牌名称brandname
       jy.FAMILY_NAME         Series, --  车系名称familyname
       jy.IMPORT_FLAG         ImportFlag, --  车型类型vehicleimport
       jy.SEAT                RatedPassengerCapacity, --  座位数seat
       jy.FULL_WEIGHT         TotalVehicleWeight, --  整备质量（千克）fullweight
       jy.TONNAGE             Tonnage, --  核定载质量tonnage（吨）
       jy.GEARBOX_TYPE DerailleurType  ,--变速器形式【二期字段】
       jy.ABS_FLAG ABSFlag  ,    --是否有ABS【二期字段】
       jy.ANTI_THEFT AlarmFlag  ,--是否有防盗装备【二期字段】
       jy.AIRBAG_NUM AirbagNum  ,--安全气囊数【二期字段】
       jy.DISPLACEMENT        Displacement, --  排量（L)displacement
       jy.MARKET_DATE         MarketYear, --  上市年月marketdate
       '' RiskFlag  ,--风险标志
       jy.PURCHASE_PRICE      ReplacementValue, --  新车购置价purchaseprice
       jy.VEHICLE_CODE        GxCode, --  精友车型代码vehiclecode
       jy.VEHICLE_ALIAS       VehicleAlias, --  车型别名
       jy.SEARCH_CODE         SearchCode, --  查询速查码
       jy.SEARCH_CODE1        AliasSearchCode, --  别名速查码
       jy.SEAT_MIN            SeatMin, --  最小座位数
       jy.SEAT_MAX            SeatMax, --  最大座位数
       jy.VEHICLE_CLASS       VehicleClass, --  车型分类
       jy.JQX_CLASSID         SyxclassCode, --  商业险分类编码
       jy.JQX_CLASSNAME       SyxclassName, --  商业险分类名称
       jy.SYX_CLASSID         JqxclassCode, --  交强险分类编码
       jy.SYX_CLASSNAME       JqxclassName, --  交强险分类名称
       jy.PURCHASE_PRICE_TAX  PurchasePriceTax, --  新车购置价（含税）
       jy.KINDRED_PRICE       KindPrice, -- 类比价
       jy.KINDRED_PRICE_TAX   KindPriceTax, --  类比价（含税）
       jy.FACTORY_NAME        FactoryName, -- 厂家名称
       jy.FAMILY_CODE         SeriesCode, --  车系编码
       jy.BRAND_CODE          BrandCode, -- 品牌编码
       jy.FACTORY_ID          FactoryCode, -- 厂家编码
       jy.FULL_WEIGHT_MAX     FullWeightMax, -- 最大整备质量
       jy.FULL_WEIGHT_MIN     FullWeightMin, -- 最小整备质量
       jy.STATUS              State, -- 状态
       jy.CREATED_DATE        UpdatedDate, -- 创建日期
       jy.UPDATED_DATE        CreatedDate, -- 修改日期
       hy.C_MODEL_CODE        platmodelcode, -- 行业车型编码
       hy.C_MODEL_ID_CODE     platmodelidcode, -- 车型识别编码
       hy.C_TRADE_NAME        plattradename, -- 厂商名称
       hy.C_TRADE_CODE        plattradecode, -- 厂商代码
       hy.C_BRAND             platbrand, -- 品牌名称
       hy.C_BRAND_CODE        platbrandcode, -- 品牌代码
       hy.C_SERIES            platseries, --  车系名称
       hy.C_SERIES_CODE       platseriescode, --  车系代码
       hy.C_CARNAME           platcarname, -- 车款名称
       hy.C_NOTICE_TYPE       platnoticetype, --  公告型号
       hy.C_CONFIG_TYPE       platconfigtype, --  配置款型编码
       hy.C_CATEGORY_NAME     platcategoryname, --  类别名称
       hy.C_CATEGORY_CODE     platcategorycode, --  类别编码
       hy.C_DEPT_NAME         platdeptname, --  系别名称
       hy.C_DEPT_CODE         platdeptcode, --  系别编码
       hy.C_UPDATE_VERSION    platupdateversion, -- 车型更新版本号
       hy.C_BIZ_VERSION       platbizversion, --  车型业务版本号
       hy.C_VALID_STATUS      platvalidstatus, -- 效力状态
       hy.T_OBTAIN_CREATETIME  platobtaincreatetime, --  入库时间
       hy.T_OBTAIN_UPDATETIME  platobtainupdatetime,  -- 更新时间
        jy.GROUP_NAME GroupName,--车组名称【二期字段】
        jy.GROUP_CODE GroupCode,--车组编码【二期字段】
        jy.HFNAME HfName,--车船税减免标识【二期字段】
        jy.HFCODE HfCode,--车船税减免标识代码【二期字段】
        '2015-09-11' HfExtTime, --车船税减免校验时间点【二期字段】
        jy.POWER_TYPE PowerType,--燃料种类【二期字段】
        jy.POWER_TYPE_CODE PowerTypeCode,--燃料种类代码【二期字段】
        jy.POWER Power,--功率（KW）【二期字段】
        jy.STOP_FLAG StopFlag,--停产标识【二期字段】
        jy.NEWCLASSNAME NewClassName,--车型新分类【二期字段】
        jy.NEWCLASSCODE NewClassCode,--车型新分类编码【二期字段】
        jy.HFSTARTTIME   HfStartTime,--车船税减免起期
        jy.HFENDTIME     HfEndTime --车船税减免止期
  from fc_vehicle jy, vhl_model_data hy, web_bas_hy_jy_map ys
 where jy.vehicle_code = ys.vehicle_code_jy
   and ys.vehicle_code_hy =hy.c_model_code(+)
/
