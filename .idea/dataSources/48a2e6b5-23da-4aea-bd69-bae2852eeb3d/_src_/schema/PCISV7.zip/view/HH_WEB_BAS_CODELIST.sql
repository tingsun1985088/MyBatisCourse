CREATE VIEW HH_WEB_BAS_CODELIST AS SELECT
c_pk_id as c_pk_id,
c_par_cde as c_par_cde ,
c_par_cnm as c_par_cnm,
C_CDE as c_cde,
C_CNM as c_cnm,
c_is_valid as c_is_valid,
c_trans_mrk as c_trans_mrk,
t_trans_tm as t_trans_tm,
c_resv_1 as c_resv_1
FROM WEB_BAS_CODELIST
/
COMMENT ON VIEW HH_WEB_BAS_CODELIST IS 'snapshot table for snapshot REPORTHH1.hh_WEB_BAS_CODELIST'
/
COMMENT ON COLUMN HH_WEB_BAS_CODELIST.C_PK_ID IS '  唯一序列号'
/
COMMENT ON COLUMN HH_WEB_BAS_CODELIST.C_PAR_CDE IS '  分类码（可以用拼音字母缩写）'
/
COMMENT ON COLUMN HH_WEB_BAS_CODELIST.C_PAR_CNM IS '  分类名称'
/
COMMENT ON COLUMN HH_WEB_BAS_CODELIST.C_CDE IS '  代码'
/
COMMENT ON COLUMN HH_WEB_BAS_CODELIST.C_CNM IS '  中文名称'
/
COMMENT ON COLUMN HH_WEB_BAS_CODELIST.C_IS_VALID IS '  有效标志'
/
