CREATE VIEW V_CLM_INWD_NOPAY AS select   'C'||a.c_clm_no      as c_clm_no,
         ''              as c_rpt_no,
         'P'||a.c_ply_no      as c_ply_no,
         'T'||to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
         'T'||to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
         dpt.c_dpt_cnm   as c_dpt_cnm,
         '---'           as c_dpt_three,
         rpfunction.getKindName(a.c_kind_no,a.c_prod_no,nvl(pend.c_cvrg_no,'---'))  as c_kind_name,
         prod.c_nme_cn   as c_prod_name,
         '---'           as c_cvrg_name,
         (select decode(nvl(plybase.c_grp_mrk,0),0,'个人','团单')
          from web_ply_base plybase where plybase.c_ply_no = a.c_ply_no and plybase.n_edr_prj_no=a.n_edr_prj_no) as c_grp_mrk,
         (select decode(nvl(applic.c_stk_mrk,0),0,'非股东','股东')
         from web_ply_applicant applic where applic.c_ply_no=a.c_ply_no
              and applic.n_edr_prj_no=a.n_edr_prj_no ) as c_stk_mrk,     /*股东标志,*/
         decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入') as c_inwd_mrk,/*分入标志,*/
         '---'        c_rs_mrk,
         '人民币'     as  c_pay_cur, /*已决赔款币种,*/
         0            as n_pay, /*原币种已决赔款,*/
         /*0            as n_pay_rmb,*/ /*折合人民币已决赔款,*/
         '人民币'     as c_clmfee_cur, /*已决直接理赔费用币种,*/
         0            as n_clmfee, /*原币种已决直接理赔费用,*/
         /*0            as n_clmfee_rmb,*/ /*折合人民币已决直接理赔费用,*/
         '人民币'     as c_nopay_cur, /*未决赔款的币种,*/
         nvl(pend.n_this_pend, 0)  as n_nopay, /*原币种未决赔款,*/
         /*nvl(pend.n_this_pend, 0)  as n_nopay_rmb,*/ /*折合人民币未决赔款,*/
         '人民币'     as c_noclmfee_cur, /*未决直接理赔费用币种,*/
         nvl(pend.n_clmfee, 0)  as n_noclmfee, /*原币种未决直接理赔费用,*/
         /*nvl(pend.n_clmfee, 0)  as n_noclmfee_rmb,*/ /*折合人民币未决直接理赔费用,*/
         'T'||to_char(accdnt.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss')  as t_accdnt_tm, /*出险时间,*/
         'T'||to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')        as t_rpt_tm,  /*报案时间,*/
         'T'||to_char(RGST.T_RGST_TM,'yyyy-mm-dd hh24:mi:ss')      as t_rgst_tm, /*立案时间,*/
         ''                                                   as t_endcase_tm, /*结案时间*/
         '未决' c_pay_mrk,
         a.c_kind_no,
         /*case when a.c_kind_no = '06'
           then rpfunction.getKindNo(a.c_kind_no,a.c_prod_no,nvl(pend.c_cvrg_no,'---'))
             else a.c_kind_no end as c_kind_no,*/
         a.c_prod_no
    from web_clm_pend   pend,
         web_clm_main   a,
         web_clm_rpt    rpt,
         web_clm_accdnt accdnt,
         WEB_CLM_RGST   RGST,
         web_prd_prod   prod,
         web_prd_cvrg   cvrg,
         web_org_dpt dpt,
         web_fin_accntquart acc
   where a.c_clm_no = pend.c_clm_no
     and a.c_inwd_mrk = '1'
     and acc.c_mrk = '2'
     and a.c_prod_no = prod.c_prod_no
     and a.c_clm_no = rpt.c_clm_no
     and a.c_clm_no = accdnt.c_clm_no
     and a.c_clm_no = RGST.c_Clm_No(+)
     and pend.c_cvrg_no = cvrg.c_cvrg_no(+)
     and pend.n_pend_tms =
         (select max(n_pend_tms)
           from web_clm_pend where c_clm_no = pend.c_clm_no
             and t_pend_tm <= acc.t_end_tm)
    and pend.c_pend_source <> '6'
    and
     --撤销案件处理
    not exists  (select 1  from web_clm_cancel c where  ((c.c_cnl_typ='0' and c.t_cnl_tm <=acc.t_end_tm ) or
            ( c.c_cnl_typ='1' and c.t_chk_tm <= acc.t_end_tm
             and ((c.t_renew_tm is not null and c.t_renew_tm >acc.t_end_tm ) or c.t_renew_tm is null)
             and c.n_cnl_tms = (select max(n_cnl_tms)
                                  from web_clm_cancel
                                 where t_chk_tm <= acc.t_end_tm
                                   and c_chk_conc = '0'
                                   and c_clm_no = c.c_clm_no
                                   and c_cnl_typ='1'))
            and  c.c_chk_conc = '0' )  and c_clm_no = a.c_clm_no)
    and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
UNION ALL
select '---'          as c_clm_no,
       '---'          as c_rpt_no,--报案号,
       '---'          as c_ply_no,
       '---'          as t_insrnc_bgn_tm,
       '---'          as t_insrnc_end_tm,
       '泰山财产保险股份有限公司总公司'   as c_dpt_cnm,
       ri.c_com_cnm                       as c_dpt_three,    --机构
       rpfunction.getKindName(d.c_kind_no,p.c_prod_no,'') as c_kind_name,
       nvl(prod.c_nme_cn,'---')     as c_prod_name,
       '---'             as c_cvrg_name,
       '---'             as c_grp_mrk,--团单标志,
       '--'              as c_stk_mrk, --股东标志,
       '分入'            as c_inwd_mrk,
       '---'             as c_rs_mrk,
       cur.c_cur_cnm     as c_pay_cur,
       case when p.c_pk_id is null then d.n_clm_amt else p.n_clm_amt end  as n_pay,     -- 原币种已决赔款,
       /*case when p.c_pk_id is null then d.n_clm_amt else p.n_clm_amt end  as n_pay_rmb,*/ --折合人民币已决赔款,
       cur.c_cur_cnm      as c_clmfee_cur,--已决直接理赔费用币种,
       0                  as n_clmfee,    --原币种已决直接理赔费用,
       /*0                     as n_clmfee_rmb,*/--折合人民币已决直接理赔费用,
       cur.c_cur_cnm      as c_nopay_cur,--未决赔款币种,
       case when p.c_pk_id is null then d.n_outstanding_amt else p.n_outstanding_amt end as n_nopay,--原币种未决赔款,
       /*case when p.c_pk_id is null then d.n_outstanding_amt else p.n_outstanding_amt end as n_nopay_rmb,*/--折合人民币未决赔款,
       cur.c_cur_cnm     as c_noclmfee_cur,--未决直接理赔费用币种,
       0                 as n_noclmfee,--原币种未决直接理赔费用,
       /*0            as n_noclmfee_rmb,*/--折合人民币未决直接理赔费用,
       --to_char(acc.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm,--出险时间,
       --'2012-10-15 00:00:00'                            as t_accdnt_tm,--出险时间,
       /*m.c_uw_month,
       m.c_bill_prd,
       m.c_bill_month,
       m.c_billprd_type,*/
       'T'||case when m.c_billprd_type = 'S'
            then (m.c_bill_year||(case when m.c_bill_prd = 'Q1' then '-01'
            else case when m.c_bill_prd = 'Q2' then '-04'
            else case when m.c_bill_prd = 'Q3' then '-07'
            else '-10' end end end)||'-15')
              else
                 (
                   case when m.c_bill_month = '01' then to_number(m.c_bill_year)-1 || '-12-15'
                             else m.c_bill_year||'-'||(to_number(m.c_bill_month)-1)|| '-15' end
                 )
                 /*(m.c_bill_year||(case when m.c_bill_month in ('01','02','03') then '-02'
            else case when c_bill_month in ('04','05','06') then '-05'
            else case when c_bill_month in ('07','08','09') then '-08'
            else '-11' end end end)||'-15')  */
               end as t_accdnt_tm, --出险时间,
       ''                                               as t_rpt_tm, --报案时间,
       ''                                               as t_rgst_tm,--立案时间,

       'T'||case when (case when p.c_pk_id is null then nvl(d.n_clm_amt,0) else nvl(p.n_clm_amt,0) end) <> 0
            then (
              case when m.c_billprd_type = 'S'
                then (m.c_bill_year||(case when m.c_bill_prd = 'Q1' then '-02'
                else case when m.c_bill_prd = 'Q2' then '-05'
                else case when m.c_bill_prd = 'Q3' then '-08'
                else '-11' end end end)||'-15')
                  else m.c_bill_year||'-'||m.c_bill_month||'-15'
                  end
              )
             else '' end as t_endcase_tm,--结案时间
       '未决' c_pay_mrk,
       d.c_kind_no,
       /*case when d.c_kind_no = '06'
           then rpfunction.getKindNo(d.c_kind_no,p.c_prod_no,'---')
             else d.c_kind_no end as c_kind_no,*/
       p.c_prod_no

  from WEB_RI_INTER_cont_BILL_MAIN m,WEB_RI_INTER_cont_BILL_DTL d,WEB_RI_INTER_cont_BILL_prod p,
       web_prd_prod prod,web_ri_com ri,web_fin_accntquart acc,web_bas_fin_cur cur
where m.c_pk_id = d.c_main_pk_id
  and d.c_pk_id = p.c_bill_dtl_pk_id(+)
  and p.c_prod_no = prod.c_prod_no(+)
  and m.c_ri_com = ri.c_com_cde
  and m.c_to_fin_mrk = '1'
  and acc.c_mrk = '2'
  and m.c_fee_cur = cur.c_cur_cde
  and m.t_crt_tm<= acc.t_end_tm

--SELECT "C_CLM_NO","C_RPT_NO","C_PLY_NO","T_INSRNC_BGN_TM","T_INSRNC_END_TM","C_DPT_CNM","C_DPT_THREE","C_KIND_NAME","C_PROD_NAME","C_CVRG_NAME","C_GRP_MRK","C_STK_MRK","C_INWD_MRK","C_RS_MRK","C_PAY_CUR","N_PAY","N_PAY_RMB","C_CLMFEE_CUR","N_CLMFEE","N_CLMFEE_RMB","C_NOPAY_CUR","N_NOPAY","N_NOPAY_RMB","C_NOCLMFEE_CUR","N_NOCLMFEE","N_NOCLMFEE_RMB","T_ACCDNT_TM","T_RPT_TM","T_RGST_TM","T_ENDCASE_TM","C_PAY_MRK","C_KIND_NO","C_PROD_NO" FROM v_clmpend_inwd_cont
/
