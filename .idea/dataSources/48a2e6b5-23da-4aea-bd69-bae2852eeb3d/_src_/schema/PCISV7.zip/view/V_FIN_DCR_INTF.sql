CREATE VIEW V_FIN_DCR_INTF AS SELECT '1' AS c_dcr_type, c_seq_no, c_item_no, c_cav_flag, c_sbjt_no,
          c_sbjt_memo, n_amt, c_cur_no, t_crt_tm, c_dptacc_no, c_dpt_cde,
          c_ri_com, c_prod_no, c_vou_no,c_voucher_no,c_bsns_typ, c_salegrp_cde,
          c_vou_memo, c_company_cde,c_check_flag, c_servicetype_no,
          c_department_cde, c_rcpt_no,t_end_tm, c_prm_sou,null as c_cav_no,
          NULL AS n_exch_amt, NULL AS n_rate,
          NULL AS c_chr_cur_no, NULL AS c_flow_no, NULL AS c_rp_type,
          NULL AS c_finbank_cde, NULL AS c_check_cde, NULL AS c_bal_type,
          NULL AS c_bank_cde, NULL AS c_check_no, NULL AS t_rp_tm
     FROM web_fin_madcr WHERE c_item_no = '1'
UNION ALL
SELECT '2' AS c_dcr_type, c_seq_no, c_item_no, c_cav_flag, c_sbjt_no,
          c_sbjt_memo, n_amt, c_cur_no, t_crt_tm, c_dptacc_no, c_dpt_cde,
          c_ri_com, c_prod_no, c_vou_no,c_voucher_no,c_bsns_typ, c_salegrp_cde,
          c_vou_memo, c_company_cde,c_check_flag, c_servicetype_no,
          c_department_cde, c_rcpt_no, t_end_tm, c_prm_sou,c_cav_no,
          n_exch_amt, n_rate, c_chr_cur_no,
          c_flow_no, c_rp_type, c_finbank_cde, c_check_cde, c_bal_type,
          c_bank_cde, c_check_no, t_rp_tm
     FROM web_fin_dcr WHERE c_item_no = '1'

/
