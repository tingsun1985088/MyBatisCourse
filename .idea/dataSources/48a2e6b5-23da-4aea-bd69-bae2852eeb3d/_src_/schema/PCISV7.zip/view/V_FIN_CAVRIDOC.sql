CREATE VIEW V_FIN_CAVRIDOC AS SELECT
C_BILL_YM          ,
C_CONT_CDE        ,
C_DPT_CDE         ,
N_ITEM_NO         ,
C_RI_COM          ,
N_EXCH_RATE       ,
T_BAL_END_TM
/*                ,
C_BILL_NO         ,
C_BILL_TYP        ,
C_CAVRIDOC_PK_ID  ,
C_CAV_PK_ID       ,
C_CONT_ID         ,
C_CRT_CDE         ,
C_FEE_CUR         ,
C_FEE_TYP         ,
C_PROD_NO         ,
C_RIBILL_PK_ID    ,
C_RP_CUR          ,
C_UPD_CDE         ,
N_BILL_INST       ,
N_FEE_AMT         ,
N_ORIG_CUR_AMT    ,
N_RP_AMT          ,
T_CRT_TM          ,
T_UPD_TM          ,
*/
FROM       WEB_FIN_CAV_RIDOC

/
