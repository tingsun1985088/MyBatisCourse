CREATE VIEW V_RICLM_NOPAY_VHL AS select /*再保分出未决赔款车险*/
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       cvrg.c_nme_cn   as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,
       decode(nvl(due.c_stock_mrk, '0'), '0', '非股东', '股东') as c_stk_mrk,
       '人民币'        as  c_pay_cur,
       0               as n_pay,
       0               as n_pay_rmb,
       '人民币'        as c_clmfee_cur,
       0               as n_clmfee,
       0               as n_clmfee_rmb,
       cur.c_cur_cnm   as c_nopay_cur,
       sum(/*(case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                 greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end)*/DTL.N_SUM_ESTMT_AMT * ced.n_clm_prpt) as n_nopay,-- 原币种未决赔款,
       /*greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))  as n_nopay_rmb,*/
       sum(/*(case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                  greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end)*/ DTL.N_SUM_ESTMT_AMT * ced.n_clm_prpt) as n_nopay_rmb,--折合人民币未决赔款,
       /*sum(ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)) as n_nopay,--未决赔款
       sum(ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)) as n_nopay_rmb,*/
       cur.c_cur_cnm   as c_noclmfee_cur,
       sum(nvl(DTL.N_CLM_FEE,0) * ced.n_clm_prpt)  as n_noclmfee,
       sum(nvl(DTL.N_CLM_FEE,0) * ced.n_clm_prpt)  as n_noclmfee_rmb,
       to_char(M.T_ACCDNT_TM,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm, /*出险时间*/
       to_char(M.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,    /*报案时间*/
       to_char(M.T_CLM_RGST_TM,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,   /*立案时间*/
       ''                                               as t_endcase_tm,/*结案时间*/
       prod.c_kind_no,prod.c_prod_no,'未决' as d_state,'1' as C_JY_FLAG --1软通 2精友
  from web_ri_pend_due   due,
       web_ri_pend_ced   ced,
       web_prd_prod      prod,
       web_org_dpt       dpt,
       web_org_dpt       dpt2,
      /* web_clm_rpt_zm_42       rpt,
       web_clm_ready_amt_42 ready,*/
       web_ply_base      base,
       web_bas_fin_cur   cur,
       web_prd_cvrg      cvrg,
       web_fin_accntquart acc,
       --web_clm_main_42       m
       WEB_FIN_CLM_MAIN M,
       WEB_FIN_CLM_DETAIL DTL
 where due.c_clm_no = ced.c_clm_no
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and m.c_clm_no = due.c_clm_no
   and m.c_ply_no = base.c_ply_no
   and nvl(m.n_edr_prj_no,0) = base.n_edr_prj_no
   and due.c_prod_no like '03%'
   --and due.c_clm_no = rpt.c_clm_no
   AND DUE.C_CLM_NO = M.C_CLM_NO
   and due.c_status IN ('B','C')
   and substr(DTL.C_INSRNC_CDE,1,6) = cvrg.c_cvrg_no
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') /*从201308开始有分出赔案*/
   and due.t_ridue_tm <= acc.t_end_tm
   and DTL.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
   and DTL.C_CLM_NO = due.c_clm_no
   /*and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt_42
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <= acc.t_end_tm
           and t_update >= to_date('2013-08-01','yyyy-mm-dd')
           and c_jy_flag is null)--软通数据*/
   and DTL.N_SEQ_NUM =
       (select max(N_SEQ_NUM)
          from WEB_FIN_CLM_DETAIL DT
         where DT.C_CLM_NO = DTL.C_CLM_NO
           and DT.T_ASSESS_TM <= acc.t_end_tm
           and DT.T_ASSESS_TM >= to_date('2013-08-01','yyyy-mm-dd')
           )--软通数据
     AND NOT EXISTS (SELECT 1
      FROM WEB_CLM_CNCL CNL
     WHERE CNL.C_CLM_MAIN_ID = M.C_CLM_NO
       AND CNL.C_CHECK_OPN = '1'
       AND CNL.T_CHECK_TM <= acc.t_end_tm
       AND CNL.C_CLM_MAIN_ID NOT IN ('400000103202014000004','400000103202014000010') --对接时产生的重复赔案号，从精友取数
       )
     AND NOT EXISTS (SELECT 1
        FROM WEB_CLM_CNL_JY JY
       WHERE JY.C_CLM_NO = M.C_CLM_NO
         AND JY.T_CNL_TM <= acc.t_end_tm
         AND JY.C_CLM_NO NOT IN ('400000103202014000006','400000103202014000009')--对接时产生的重复赔号，从软通取数
         --AND JY.C_CLM_NO <> '400000103202014000006'--特殊处理
         )
    AND DTL.C_CLM_MAINSTATUS NOT IN ('38','39')
    AND DTL.C_KIND_NO = '03'
   /*and  not exists
       (select cncl.c_clm_main_id
          from web_clm_cncl cncl
         where cncl.t_check_tm <= acc.t_end_tm
           and cncl.c_check_opn = '1'
           and cncl.c_clm_main_id = due.c_clm_no
           and cncl.t_check_tm >= to_date('2013-08-01','yyyy-mm-dd')
        )--确认标志
   and not exists (
            select 1 from web_clm_endcase_zm_42 endcase
            where endcase.c_clm_no = m.c_clm_no
              and endcase.c_endcase_status = '03' --确认结案
              and endcase.c_end_type = '02'       --正常结案
              and endcase.t_end_tm <= acc.t_end_tm)*/
   --and ready.c_jy_flag is null --软通数据
   group by
         due.c_clm_no,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
         substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
         to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
         prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
         to_char(M.T_ACCDNT_TM,'yyyy-mm-dd hh24:mi:ss'),
         to_char(M.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
         to_char(M.T_CLM_RGST_TM,'yyyy-mm-dd hh24:mi:ss') ,
         prod.c_kind_no,prod.c_prod_no,substr(DTL.C_INSRNC_CDE,1,6),cvrg.c_nme_cn
/*select \*再保分出未决赔款车险*\
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       cvrg.c_nme_cn   as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,
       decode(nvl(due.c_stock_mrk, '0'), '0', '非股东', '股东') as c_stk_mrk,
       '人民币'        as  c_pay_cur,
       0               as n_pay,
       0               as n_pay_rmb,
       '人民币'        as c_clmfee_cur,
       0               as n_clmfee,
       0               as n_clmfee_rmb,
       cur.c_cur_cnm   as c_nopay_cur,
       sum((case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                 greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end) * ced.n_clm_prpt) as n_nopay,-- 原币种未决赔款,
       \*greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))  as n_nopay_rmb,*\
       sum((case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                  greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end) * ced.n_clm_prpt) as n_nopay_rmb,--折合人民币未决赔款,
       \*sum(ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)) as n_nopay,--未决赔款
       sum(ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)) as n_nopay_rmb,*\
       cur.c_cur_cnm   as c_noclmfee_cur,
       sum(nvl(ready.n_clmfee_amt,0) * ced.n_clm_prpt)  as n_noclmfee,
       sum(nvl(ready.n_clmfee_amt,0) * ced.n_clm_prpt)  as n_noclmfee_rmb,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm, \*出险时间*\
       to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,    \*报案时间*\
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,   \*立案时间*\
       ''                                               as t_endcase_tm,\*结案时间*\
       prod.c_kind_no,prod.c_prod_no,'未决' as d_state,'1' as C_JY_FLAG --1软通 2精友
  from web_ri_pend_due_42   due,
       web_ri_pend_ced_42   ced,
       web_prd_prod_42      prod,
       web_org_dpt_42       dpt,
       web_org_dpt_42       dpt2,
       web_clm_rpt_zm_42       rpt,
       web_clm_ready_amt_42 ready,
       web_ply_base_42      base,
       web_bas_fin_cur_42   cur,
       web_prd_cvrg_42      cvrg,
       web_fin_accntquart acc,
       web_clm_main_42       m
 where due.c_clm_no = ced.c_clm_no
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and m.c_clm_no = due.c_clm_no
   and m.c_ply_no = base.c_ply_no
   and nvl(m.n_edr_prj_no,0) = base.n_edr_prj_no
   and due.c_prod_no like '03%'
   and due.c_clm_no = rpt.c_clm_no
   and due.c_status IN ('B','C')
   and substr(ready.c_rdr_cde,1,6) = cvrg.c_cvrg_no
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due_42 where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and ready.t_update >= to_date('2013-08-01','yyyy-mm-dd')
   and ready.c_clm_main_id = due.c_clm_no
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt_42
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <= acc.t_end_tm
           and t_update >= to_date('2013-08-01','yyyy-mm-dd')
           and c_jy_flag is null)--软通数据
   and  not exists
       (select cncl.c_clm_main_id
          from web_clm_cncl cncl
         where cncl.t_check_tm <= acc.t_end_tm
           and cncl.c_check_opn = '1'
           and cncl.c_clm_main_id = due.c_clm_no
           and cncl.t_check_tm >= to_date('2013-08-01','yyyy-mm-dd')
        )--确认标志
   and not exists (
            select 1 from web_clm_endcase_zm_42 endcase
            where endcase.c_clm_no = m.c_clm_no
              and endcase.c_endcase_status = '03' --确认结案
              and endcase.c_end_type = '02'       --正常结案
              and endcase.t_end_tm <= acc.t_end_tm)
   and ready.c_jy_flag is null --软通数据
   group by
         due.c_clm_no,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
         substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
         to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
         prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
         to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
         to_char(rpt.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
         to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') ,
         prod.c_kind_no,prod.c_prod_no,substr(ready.c_rdr_cde,1,6),cvrg.c_nme_cn
--20140113精友理赔修改
UNION ALL
select \*再保分出未决赔款车险*\
       due.c_clm_no    as c_clm_no,
       ''              as c_rpt_no,
       due.c_ply_no    as c_ply_no,
       to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm,
       to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm,
       case when substr(due.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm)  as c_dpt_three,
       case when prod.c_prod_no = '0320' then '交强险' else '商业车险' end as c_kind_name,
       prod.c_nme_cn   as c_prod_name,
       cvrg.c_nme_cn   as c_cvrg_name,
       decode(nvl(base.c_grp_mrk,0),0,'个人','团单')  as c_grp_mrk,
       decode(nvl(due.c_stock_mrk, '0'), '0', '非股东', '股东') as c_stk_mrk,
       '人民币'        as  c_pay_cur,
       0               as n_pay,
       0               as n_pay_rmb,
       '人民币'        as c_clmfee_cur,
       0               as n_clmfee,
       0               as n_clmfee_rmb,
       cur.c_cur_cnm   as c_nopay_cur,
       sum((case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                 greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end) * ced.n_clm_prpt) as n_nopay,-- 原币种未决赔款,
       \*greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))  as n_nopay_rmb,*\
       sum((case when nvl(ready.n_prep_amt, 0) = 0 then
                         nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)
            else
                  greatest((nvl(ready.n_amt,0)+ nvl(ready.n_checklos_help_fee, 0)),nvl(ready.n_prep_amt, 0))
            end) * ced.n_clm_prpt) as n_nopay_rmb,--折合人民币未决赔款,
       \*sum(ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)) as n_nopay,--未决赔款
       sum(ced.n_clm_amt*(greatest(ready.n_amt+nvl(ready.n_checklos_help_fee,0),nvl(ready.n_prep_amt,0))/due.n_ri_clm_amt)) as n_nopay_rmb,*\
       cur.c_cur_cnm   as c_noclmfee_cur,
       sum(nvl(ready.n_clmfee_amt,0) * ced.n_clm_prpt)  as n_noclmfee,
       sum(nvl(ready.n_clmfee_amt,0) * ced.n_clm_prpt)  as n_noclmfee_rmb,
       to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss') as t_accdnt_tm, \*出险时间*\
       to_char(mj.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss')    as t_rpt_tm,    \*报案时间*\
       to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss')   as t_rgst_tm,   \*立案时间*\
       ''                                               as t_endcase_tm,\*结案时间*\
       prod.c_kind_no,prod.c_prod_no,'未决' as d_state,'2' as C_JY_FLAG --1软通 2精友
  from web_ri_pend_due_42   due,
       web_ri_pend_ced_42   ced,
       web_prd_prod_42      prod,
       web_org_dpt_42       dpt,
       web_org_dpt_42       dpt2,
      -- web_clm_rpt_zm       rpt,
       web_clm_ready_amt_42 ready,
       web_ply_base_42      base,
       web_bas_fin_cur_42   cur,
       web_prd_cvrg_42      cvrg,
       web_fin_accntquart acc,
       web_clm_main_jy       mj
 where due.c_clm_no = ced.c_clm_no
   and cur.c_cur_cde = ced.c_riclm_cur
   and due.n_pend_tms = ced.n_pend_tms
   and due.n_rbk_seq = ced.n_rbk_seq
   and due.n_split_seq = ced.n_split_seq
   and due.c_prod_no = prod.c_prod_no
   and mj.c_clm_no = due.c_clm_no
   and mj.c_clm_no = ready.c_clm_main_id
   and mj.c_ply_no = base.c_ply_no
   and base.n_edr_prj_no = 0 --取保单起止期
   and due.c_prod_no like '03%'
   and due.c_clm_no = mj.c_clm_no
   and due.c_status IN ('B','C')
   and substr(ready.c_rdr_cde,1,6) = cvrg.c_cvrg_no
   and due.n_rbk_seq = 0
   and ced.c_cont_cde not in ('BB', '04', 'AR') --不是我司
   and acc.c_mrk='2'
   and due.n_pend_tms = ( select max(n_pend_tms) from web_ri_pend_due_42 where c_clm_no = due.c_clm_no and t_ridue_tm <= acc.t_end_tm)
   and dpt.c_dpt_cde = substr(due.c_dpt_cde,1,2)
   and dpt2.c_dpt_cde = substr(due.c_dpt_cde,1,4)
   and due.t_ridue_tm >= to_date('2013-08-01','yyyy-mm-dd') \*从201308开始有分出赔案*\
   and due.t_ridue_tm <= acc.t_end_tm
   and ready.t_update >= to_date('2013-08-01','yyyy-mm-dd')
   and ready.c_clm_main_id = due.c_clm_no
   and ready.n_rgst_num =
       (select max(n_rgst_num)
          from web_clm_ready_amt_42
         where c_clm_main_id = ready.c_clm_main_id
           and t_update <= acc.t_end_tm
           and t_update >= to_date('2013-08-01','yyyy-mm-dd')
           and c_jy_flag = '2')
   and NOT EXISTS
       (select 1
          from web_clm_cnl_jy CNL
         where CNL.T_CNL_TM <= acc.t_end_tm
           and CNL.C_CLM_NO = due.c_clm_no
        )--不存在销案
   \*and not exists (
            select 1 from web_clm_ready_amt_42 R
            where R.C_CLM_MAIN_ID = DUE.C_CLM_NO
              and R.C_TASK_TYPE IN ('38','39') --结案
              and R.T_UPDATE <= acc.t_end_tm
              AND R.C_JY_FLAG = '2')--没有结案*\
   and ready.c_jy_flag = '2' --精友数据
   group by
         due.c_clm_no,due.c_ply_no,to_char(base.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss'),
         substr(due.c_dpt_cde,1,4),base.c_inwd_mrk,dpt2.c_dpt_cnm,
         to_char(base.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss'),dpt.c_dpt_cnm,
         prod.c_nme_cn,base.c_grp_mrk,due.c_stock_mrk,cur.c_cur_cnm ,
         to_char(due.t_accdnt_tm,'yyyy-mm-dd hh24:mi:ss'),
         to_char(MJ.t_rpt_tm,'yyyy-mm-dd hh24:mi:ss'),
         to_char(due.t_rgst_tm,'yyyy-mm-dd hh24:mi:ss') ,
         prod.c_kind_no,prod.c_prod_no,substr(ready.c_rdr_cde,1,6),cvrg.c_nme_cn*/
/
