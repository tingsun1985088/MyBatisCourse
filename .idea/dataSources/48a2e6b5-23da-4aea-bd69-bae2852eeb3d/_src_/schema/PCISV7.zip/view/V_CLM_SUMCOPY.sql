CREATE VIEW V_CLM_SUMCOPY AS select --赔款按险类汇总
       pay.kind 险类,sum(pay.pay2) 已决赔款,sum(pay.pay) 未决赔款,
       sum(pay.payfee2) 直接理赔费用已决,sum(pay.payfee) 直接理赔费用未决
  from (
      --未决
      ---车险
      select decode(a.c_prod_no, '0320', '交强险', '商业车险') as kind,
               0 pay2, --已决赔款
               0 payfee2, --直接理赔费用已决
               /* (case
                 when ready.c_task_type = '1' then
                  ready.n_amt
                 else
                  ready.n_amt + nvl(pp.n_rdr_amt, 0) + nvl(prep.n_rdr_amt, 0)
               end) + nvl(ready.n_checklos_help_fee, 0)*/
               /*greatest((nvl(ready.n_amt, 0) +
                        nvl(ready.n_checklos_help_fee, 0)),
                        nvl(prep.n_rdr_amt, 0)) pay, --未决赔款*/
                greatest((nvl(ready.n_amt, 0) +
                        nvl(ready.n_checklos_help_fee, 0)),
                        nvl(ready.n_prep_amt, 0)) pay,
               /*(case
                 when clm.n_sum_amt <= 5000 then
                  150
                 when clm.n_sum_amt > 5000 and clm.n_sum_amt < 30000 then
                  500
                 when clm.n_sum_amt >= 30000 then
                  1000
               end) * decode(clm.n_sum_amt, 0, 0, ready.n_amt / clm.n_sum_amt)*/
               0 payfee --直接理赔费用未决
          from (select m.c_clm_no, rpt.t_rpt_tm, m.c_prod_no,  endcase.t_end_tm
                  from web_clm_main m
                  left join web_clm_endcase_zm endcase
                    on m.c_clm_no = endcase.c_clm_no
                   and endcase.c_endcase_status = '03' --确认结案
                   and endcase.c_end_type = '02', --正常结案
                 web_clm_rpt_zm rpt

                 where trunc(rpt.t_rpt_tm) <=
                       trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
                   and m.c_inwd_mrk = '0'
                   and m.c_clm_no = rpt.c_clm_no) a,
               web_clm_ready_amt ready ---未决赔款
          left join (select pp.c_clm_main_id,  pp_rdr.c_rdr_cde,  sum(pp_rdr.n_rdr_amt) n_rdr_amt
                      from web_clm_pp pp, web_clm_rdr_lst pp_rdr
                     where pp.c_pp_id = pp_rdr.c_clm_link_id
                       and pp.c_status = '03' --确认标志
                     group by pp.c_clm_main_id, pp_rdr.c_rdr_cde) pp --垫付金额
            on pp.c_clm_main_id = ready.c_clm_main_id
           and pp.c_rdr_cde = ready.c_rdr_cde
          /*left join (select prep.c_clm_main_id, prep_rdr.c_rdr_cde, sum(prep_rdr.n_rdr_amt) n_rdr_amt
                      from web_clm_prep prep, web_clm_rdr_lst prep_rdr,web_clm_vrfc fc,web_clm_vc_task  task
                     where prep_rdr.c_clm_link_id = prep.C_PREP_ID
                       and fc.c_clm_main_id = prep.c_clm_main_id
                       and fc.c_clm_vc_id = task.c_clm_vc_id
                       and fc.c_vc_status = '03'
                       and prep.c_status = '03' --确认标志
                     group by prep.c_clm_main_id, prep_rdr.c_rdr_cde) prep ---预付金额
            on prep.c_clm_main_id = ready.c_clm_main_id
            and prep.c_rdr_cde = ready.c_rdr_cde*/,
         (select c_clm_main_id, n_rgst_num, sum(n_amt) n_sum_amt
                  from web_clm_ready_amt
                 group by c_clm_main_id, n_rgst_num) clm
         where (trunc(a.t_end_tm) > trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))) or  a.t_end_tm is null)

           and a.c_clm_no = ready.c_clm_main_id
           and ready.c_clm_main_id = clm.c_clm_main_id
           and ready.n_rgst_num = clm.n_rgst_num
           and ready.n_rgst_num =
               (select max(n_rgst_num)
                  from web_clm_ready_amt
                 where c_clm_main_id = ready.c_clm_main_id
                   and trunc(t_update) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
           and a.c_clm_no not in
               (select cncl.c_clm_main_id
                  from web_clm_cncl cncl
                 where trunc(cncl.t_check_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
                   and cncl.c_check_opn = '1') --确认标志

        union all
        select rpfunction.getKindName(a.c_kind_no, a.c_prod_no, '') as kind,
               0 pay2,
               0 payfee2,
               nvl(pend.n_this_pend, 0) /*+ round(nvl(pend.n_help, 0), 2)*/ pay,
               nvl(pend.n_clmfee, 0) payfee
          from web_clm_pend pend, web_clm_main a, web_clm_rpt rpt
         where a.c_clm_no = pend.c_clm_no
           and a.c_clm_no = rpt.c_clm_no(+)
           and pend.n_pend_tms =
               (select max(n_pend_tms) from web_clm_pend
                 where c_clm_no = pend.c_clm_no
                   and trunc(t_pend_tm) <=  trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
           and pend.c_pend_source <> '6'
            --撤销案件处理
           and not exists
           (select 1 from web_clm_cancel c
                 where ( (c.c_cnl_typ = '0' and  trunc(c.t_cnl_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2))))
                         or (c.c_cnl_typ = '1'
                             and  trunc(c.t_chk_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
                             and  ((c.t_renew_tm is not null and trunc(c.t_renew_tm) > trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))) or c.t_renew_tm is null)
                             and  c.n_cnl_tms =
                                 (select max(n_cnl_tms)  from web_clm_cancel
                                   where trunc(t_chk_tm) <=trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
                                     and c_chk_conc = '0'  and c_clm_no = c.c_clm_no
                                     and c_cnl_typ = '1')
                             )
                         and c.c_chk_conc = '0')
                   and c_clm_no = a.c_clm_no)
        ----已决
        union all
        select '商业车险' kind,
               nvl(rdr.N_IC_AMT, 0) +
               /*nvl(ic.N_SY_HELP_FEE, 0) *
               decode(nvl(ic.N_YFSY_AMT, 0),
                      0,
                      0,
                      nvl(rdr.n_ic_amt, 0) / ic.N_YFSY_AMT) +*/
                nvl(rdr.n_prepay_amt, 0) pay2, ----已决赔款
               case
                 when (select count(1)  from web_clm_other_fee_lst lst   where lst.c_clm_link_id = ic.c_ic_id) = 0
                     then  0
                 else
                    (case when ic.N_YFSY_AMT = 0
                     then ic.B_FEE_AMT_CAL / (SELECT COUNT(1) FROM WEB_CLM_IC_RDR_LST  WHERE C_IC_ID = ic.C_IC_ID)
                     else ic.B_FEE_AMT_CAL * decode(ic.N_YFSY_AMT, 0, 0, rdr.n_ic_amt / ic.N_YFSY_AMT)
                     end )
               end /*payfee2,--*/ 已决直接理赔费用,
               0 pay, --未决赔款
               0 payfee --未决直接理赔费用
          from web_clm_ic         ic,
               web_clm_main       m,
               web_clm_endcase_zm endcase,
               web_clm_ic_rdr_lst rdr,
               web_clm_rpt_zm     rpt
         where ic.c_clm_no = m.c_clm_no
           and ic.c_ic_id = rdr.c_ic_id
           and m.c_clm_no = rpt.c_clm_no
           and m.c_clm_no = endcase.c_clm_no
           and m.c_inwd_mrk = '0'
           and endcase.c_endcase_status = '03'
           and endcase.c_end_type in ('02', '03')
           and ic.c_ic_status = '03'
           and ic.n_ic_num = endcase.n_endcase_no
           and trunc(rpt.t_rpt_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and trunc(endcase.t_end_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
        union all
        --已决赔款 交强险
        select '交强险' kind,
               nvl(duty.N_IC_AMT, 0) + /*
                      nvl(ic.n_jq_help_fee, 0) *
                      decode(nvl(ic.n_yfjq_amt, 0),
                             0,
                             0,
                             nvl(duty.n_ic_amt, 0) / ic.n_yfjq_amt) +*/
                nvl(duty.n_pppay_amt, 0) + nvl(duty.n_prepay_amt, 0) +
               --decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)
                (case
                   when trunc(ic.t_crt_tm) <= to_date('2011-11-24', 'yyyy-mm-dd')
                     then  decode(duty.c_duty_cde, '030060', ic.n_wu_amt, 0)
                   else 0
                 end ) pay2, --已决赔款,

               /*  CASE
                 WHEN ic.N_YFJQ_AMT = 0 THEN
                  ic.T_FEE_AMT_CAL /
                  (SELECT COUNT(1)
                     FROM WEB_CLM_IC_RDR_DUTY_LST
                    WHERE C_IC_RDR_LST_ID = ic.C_IC_ID)
                 ELSE
                  ic.T_FEE_AMT_CAL *
                  decode(ic.N_YFJQ_AMT,
                         0,
                         0,
                         (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)) / ic.N_YFJQ_AMT)
               END  pay2,--已决直接理赔费用,*/
               CASE
                 WHEN ic.N_YFJQ_AMT = 0 THEN ic.T_FEE_AMT_CAL / (SELECT COUNT(1) FROM WEB_CLM_IC_RDR_DUTY_LST WHERE C_IC_RDR_LST_ID = ic.C_IC_ID)
                 ELSE  ic.T_FEE_AMT_CAL *
                 /* decode(ic.N_YFJQ_AMT,
                 0,
                 0,
                 (duty.n_ic_amt+decode(duty.c_duty_cde,'030060',ic.n_wu_amt,0)) / ic.N_YFJQ_AMT)*/
                  case
                    when trunc(ic.t_crt_tm) <= to_date('2011-11-24', 'yyyy-mm-dd') then
                     decode(ic.N_YFJQ_AMT, 0, 0, (duty.n_ic_amt + decode(duty.c_duty_cde, '030060', ic.n_wu_amt, 0)) / ic.N_YFJQ_AMT)
                    else
                     decode(ic.N_YFJQ_AMT, 0, 0, duty.n_ic_amt / ic.N_YFJQ_AMT)
                  end
               END pay2, --已决直接理赔费用,
               0 pay, --未决赔款,
               0 payfee --未决直接理赔费用,
          from web_clm_ic              ic,
               web_clm_main            m,
               web_clm_endcase_zm      endcase,
               web_clm_ic_rdr_duty_lst duty,
               web_clm_rpt_zm          rpt
         where ic.c_clm_no = m.c_clm_no
           and ic.c_ic_id = duty.c_ic_rdr_lst_id
           and m.c_prod_no = '0320'
           and m.c_clm_no = endcase.c_clm_no
           and m.c_clm_no = rpt.c_clm_no
           and m.c_inwd_mrk = '0'
           and endcase.c_endcase_status = '03'
           and endcase.c_end_type in ('02', '03')
           and ic.c_ic_status = '03'
           and ic.c_ic_type in ('0', '5')
           and ic.n_ic_num = endcase.n_endcase_no
           and trunc(rpt.t_rpt_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and trunc(endcase.t_end_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
        union all
        --已决赔款 非车险
        select rpfunction.getKindName(a.c_kind_no, a.c_prod_no, '') as kind,
               nvl(pend.n_this_dtmd, 0) /* + nvl(pend.n_help, 0)*/ pay2, --已决赔款,
               nvl(pend.n_clmfee, 0) payfee2, --已决直接理赔费用,
               0 pay, --未决赔款,
               0 payfee --未决直接理赔费用,
          from web_clm_pend pend,
               web_clm_rpt  rpt,
               web_clm_main a
         where pend.c_clm_no = rpt.c_clm_no
           and pend.c_pend_source = '6'
           and trunc(rpt.t_rpt_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and trunc(pend.t_pend_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
           and a.c_clm_no = pend.c_clm_no ) pay
 group by pay.kind
/
