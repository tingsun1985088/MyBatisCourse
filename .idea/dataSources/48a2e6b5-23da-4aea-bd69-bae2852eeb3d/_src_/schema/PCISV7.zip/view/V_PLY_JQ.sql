CREATE VIEW V_PLY_JQ AS select --再保前保单明细(交强险)
       'P'||a.c_ply_no    as c_ply_no,    --保单号
       case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
       dpt2.c_dpt_cnm as  c_dpt_three,
       --rpfunction.getKindName(prod.c_kind_no,a.c_prod_no,'')  as c_kind_name, --险类
       '交强险'      as c_kind_name, --险类
       --prod.c_nme_cn as c_prod_name,   --产品
       '机动车交通事故责任强制保险'  as c_prod_name,   --产品
       '---'         as c_cvrg_name,   --险别
       decode(nvl(a.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk, --团单标志
       decode(a.c_stk_mrk,'192002','股东','非股东') as c_stk_mrk, --股东标志
       decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入')  as c_inwd_mrk,--分入标志
       cur.c_cur_cnm as c_prmcur_name,                                  --币种
       a.n_prm as n_prm,
       a.n_prm as n_prm_rmb,
       'T'||to_char(a.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(a.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm, --保险起期
       'T'||to_char(a.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm, --保险止期
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_cal_tm,
       a.N_FEE_PROP  as n_fee_prop,   --手续费比例
       cur.c_cur_cnm as c_feecur_name,--手续费币种
       a.N_FEE       as n_fee,        --原币手续费
       case when a.c_prm_cur = '01' then a.N_FEE
         else a.N_FEE*get_rate(a.c_prm_cur,'01',acc.t_end_tm ) end as n_fee_rmb,--折人民币手续费
       '03'           as c_kind_no,
       a.c_prod_no    as c_prod_no,
       a.t_insrnc_bgn_tm as bgnTm,
       a.t_insrnc_end_tm as endTm
  from --web_ply_base a, WEB_ply_FEE f,
       web_fin_plyedr a,
       web_bas_fin_cur cur,
       web_org_dpt dpt,web_org_dpt dpt2,WEB_FIN_ACCNTQUART acc
 where acc.c_mrk = '2'
   and a.t_cal_tm >= acc.t_bgn_tm
   and a.t_cal_tm <= acc.t_end_tm
   and nvl(a.c_edr_no, '---') = '---'
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
   and substr(a.c_dpt_cde,1,4) = dpt2.c_dpt_cde
   and a.c_prm_cur = cur.c_cur_cde
   and a.c_prod_no = '0320'
/
