CREATE VIEW T_FEETYPE AS select t.c_feetyp_cde type_id,t.c_feetyp_cnm type_name,t.c_typ_mrk,t.c_dc_dir
       from WEB_BAS_FIN_FEE_TYP t
/
