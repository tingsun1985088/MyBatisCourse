CREATE VIEW V_PLY_NOVHL_MD AS select --再保前保单明细(非车,交强险)
       'P'||ply.c_ply_no    as c_ply_no,    --保单号
       case when substr(ply.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
       dpt2.c_dpt_cnm as  c_dpt_three,
       rpfunction.getKindName(ply.c_kind_no,ply.c_prod_no,'')  as c_kind_name, --险类
       prod.c_nme_cn as c_prod_name,   --产品
       '---'         as c_cvrg_name,   --险别
       decode(nvl(ply.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk, --团单标志
       decode(nvl(ply.c_stk_mrk,'0'),'0','非股东','股东') as c_stk_mrk, --股东标志
       decode(nvl(ply.c_inwd_mrk,'0'),'0','非分入','分入')  as c_inwd_mrk,--分入标志
       cur.c_cur_cnm as c_prmcur_name,                                  --币种
       ply.n_Amt     as n_prm,
       'T'||to_char(ply.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       'T'||to_char(ply.t_insrnc_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_bgn_tm, --保险起期
       'T'||to_char(ply.t_insrnc_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_insrnc_end_tm, --保险止期
       'T'||to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_cal_tm,--'T'||to_char(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       rpfunction.getKindNo(ply.c_kind_no ,ply.c_prod_no,'') as c_kind_no,
       ply.c_prod_no    as c_prod_no,
       ply.t_insrnc_bgn_tm as bgnTm,
       ply.t_insrnc_end_tm as endTm

  from Web_Fin_Plyedr_Md ply, web_bas_fin_cur cur,
       web_prd_prod prod,web_org_dpt dpt,
       web_org_dpt dpt2,WEB_FIN_ACCNTQUART acc
 where  acc.c_mrk = '2'
   and ply.c_inwd_mrk <> '1'
   and ply.t_cal_tm>=acc.t_bgn_tm
   and ply.t_cal_tm<=acc.t_end_tm
   and nvl(ply.c_edr_no, '---') = '---'
   and ply.c_prod_no = prod.c_prod_no
   and dpt.c_dpt_cde = substr(ply.c_dpt_cde,1,2)
   and substr(ply.c_dpt_cde,1,4) = dpt2.c_dpt_cde
   and ply.c_Amt_Cur = cur.c_cur_cde
   and ply.c_kind_no NOT IN ('03','06','99')
   --and ply.c_prm_cur = '01'
/
