CREATE VIEW V_FIN_RPCUSTOMER AS SELECT '1' AS c_customer_type, c_rcpt_no, c_item_no, c_customer_accounts,
          c_accounts_name, c_bank_accounts, c_provinces, c_city, c_mail,
          c_mobile_phone, c_cur_cde, c_open_city, c_bal_type,
          c_company_accounts, t_desire_date, t_desire_time, c_use, n_get_prm,
          c_receive_no, c_company_openbank, c_table_flag, c_check_flag,
          c_check_cde, t_check_tm, c_send_bank_flag, c_send_bank_cde,
          t_send_bank_tm, c_recv_bank_flag, c_recv_bank_cde, t_recv_bank_tm,
          c_recv_bank_reason, c_check_name, c_export_name, t_export_tm,
          c_import_name, t_import_tm, c_import_memo, c_bala_mrk, c_check_memo,
          c_entry_name, t_entry_tm, t_update_tm, c_capital_flows,
          c_identity_no, c_reportcase_tel, c_insurant_tel, c_validate_flag,
          c_validate_mind, c_trans_mrk, t_trans_tm
     FROM web_fin_rpprmcustomer
   UNION ALL
   SELECT '3' AS c_customer_type, c_rcpt_no, c_item_no, c_customer_accounts,
          c_accounts_name, c_bank_accounts, c_provinces, c_city, c_mail,
          c_mobile_phone, c_cur_cde, c_open_city, c_bal_type,
          c_company_accounts, t_desire_date, t_desire_time, c_use, n_get_prm,
          c_receive_no, c_company_openbank, c_table_flag, c_check_flag,
          c_check_cde, t_check_tm, c_send_bank_flag, c_send_bank_cde,
          t_send_bank_tm, c_recv_bank_flag, c_recv_bank_cde, t_recv_bank_tm,
          c_recv_bank_reason, c_check_name, c_export_name, t_export_tm,
          c_import_name, t_import_tm, c_import_memo, c_bala_mrk, c_check_memo,
          c_entry_name, t_entry_tm, t_update_tm, c_capital_flows,
          c_identity_no, c_reportcase_tel, c_insurant_tel, c_validate_flag,
          c_validate_mind, c_trans_mrk, t_trans_tm
     FROM web_fin_rppaycustomer
   UNION ALL
   SELECT '4' AS c_customer_type, c_rcpt_no, c_item_no, c_customer_accounts,
          c_accounts_name, c_bank_accounts, c_provinces, c_city, c_mail,
          c_mobile_phone, c_cur_cde, c_open_city, c_bal_type,
          c_company_accounts, t_desire_date, t_desire_time, c_use, n_get_prm,
          c_receive_no, c_company_openbank, c_table_flag, c_check_flag,
          c_check_cde, t_check_tm, c_send_bank_flag, c_send_bank_cde,
          t_send_bank_tm, c_recv_bank_flag, c_recv_bank_cde, t_recv_bank_tm,
          c_recv_bank_reason, c_check_name, c_export_name, t_export_tm,
          c_import_name, t_import_tm, c_import_memo, c_bala_mrk, c_check_memo,
          c_entry_name, t_entry_tm, t_update_tm, c_capital_flows,
          c_identity_no, c_reportcase_tel, c_insurant_tel, c_validate_flag,
          c_validate_mind, c_trans_mrk, t_trans_tm
     FROM web_fin_rpcustomer
   UNION ALL
   SELECT '5' AS c_customer_type, c_rcpt_no, c_item_no, c_customer_accounts,
          c_accounts_name, c_bank_accounts, c_provinces, c_city, c_mail,
          c_mobile_phone, c_cur_cde, c_open_city, c_bal_type,
          c_company_accounts, t_desire_date, t_desire_time, c_use, n_get_prm,
          c_receive_no, c_company_openbank, c_table_flag, c_check_flag,
          c_check_cde, t_check_tm, c_send_bank_flag, c_send_bank_cde,
          t_send_bank_tm, c_recv_bank_flag, c_recv_bank_cde, t_recv_bank_tm,
          c_recv_bank_reason, c_check_name, c_export_name, t_export_tm,
          c_import_name, t_import_tm, c_import_memo, c_bala_mrk, c_check_memo,
          c_entry_name, t_entry_tm, t_update_tm, c_capital_flows,
          c_identity_no, c_reportcase_tel, c_insurant_tel, c_validate_flag,
          c_validate_mind, c_trans_mrk, t_trans_tm
     FROM web_fin_rpcreditcustomer

/
