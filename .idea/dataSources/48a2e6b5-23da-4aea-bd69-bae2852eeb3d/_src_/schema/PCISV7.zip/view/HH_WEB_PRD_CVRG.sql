CREATE VIEW HH_WEB_PRD_CVRG AS SELECT
c_cvrg_no,
c_kind_no,
c_nme_cn,
c_rdr_typ,
c_status
 FROM web_prd_cvrg
/
COMMENT ON VIEW HH_WEB_PRD_CVRG IS 'snapshot table for snapshot REPORTHH1.hh_WEB_PRD_CVRG'
/
COMMENT ON COLUMN HH_WEB_PRD_CVRG.C_RDR_TYP IS '  0-主险；1-附加险；2-扩展责任'
/
