CREATE VIEW V_RIEDR_VHLSY AS select --再保分出批单明细
       ply.c_edr_no   as c_edr_no,
       case when substr(ply.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
       decode(base.c_inwd_mrk,'1','---',dpt2.c_dpt_cnm) as 三级机构,
       rpfunction.getKindName(ply.c_kind_no,ply.c_prod_no,'')  as c_kind_name,
       prod.c_nme_cn  as c_prod_name,
       cvrg.c_nme_cn  as c_cvrg_name,
       decode(nvl(base.c_grp_mrk, '0'), '0', '个人', '团单') as c_grp_mrk,
       decode(app.c_stk_mrk,'192002','股东','非股东') as c_stk_mrk,
       --sum(ply.n_prm)/(case when base.n_prm_var=0 then 1 else base.n_prm_var end) as n_split_prop,--分出比例,
       round(sum(ply.n_prm/base.n_prm_var),2) as n_split_prop,
       cur.c_cur_cnm        as c_cur_name,--批单保费的币种,
       sum(plycvrg.n_prm_var/base.n_prm_var*ply.n_prm)       as n_prm,--原币种批单保费,
       sum(plycvrg.n_prm_var/base.n_prm_var*(case when ply.c_prm_cur = '01' then ply.n_prm
         else ply.n_prm*
           get_rate(ply.c_prm_cur,'01',acc.t_end_tm) end)) as n_prm_rmb,--折合人民币批单保费,
       to_char(base.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       to_char(base.t_edr_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_bgn_tm,--批单批改起期,
       to_char(base.t_edr_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_end_tm,--批单批改止期,
       get_edrsn(app.c_app_no,ply.c_kind_no) as c_edr_rsn,--批改原因,
       decode(nvl(base.c_edr_type,'1'),'1','一般批改','3','退保','2','注销') as c_edr_type,--批改类型,
       to_char(acc.t_end_tm,'yyyy-mm-dd hh24:mi:ss') as  t_cal_tm,   --评估日
       cur.c_cur_cnm    as c_feecur_name,--摊回手续费币种,
       sum(plycvrg.n_prm_var/base.n_prm_var*ply.n_fee)  as n_fee,--原币种摊回手续费,
       sum(plycvrg.n_prm_var/base.n_prm_var*(case when ply.c_prm_cur = '01' then ply.n_fee
         else ply.n_fee*
           get_rate(ply.c_prm_cur,'01',acc.t_end_tm ) end)) n_fee_rmb,--折合人民币摊回手续费,
       sum(ply.n_fee_prop) as n_comm_prpt,--手续费比率
       ply.c_kind_no,ply.c_prod_no,--ply.t_vehicle_layoff_end_tm
       (ply.t_vehicle_layoff_end_tm + 1/24/60/60) as resumtm ,--停驶起期+1秒为 复驶起期
        ply.t_vehicle_layoff_bgn_tm as layoffbgntm --停驶起期

      from web_fin_ri_plyedr ply,
           web_prd_prod prod,
           web_org_dpt dpt,
           web_bas_fin_cur cur,
           web_ply_base base,
           web_ply_applicant app,
           web_org_dpt dpt2,
           web_fin_accntquart acc,
           web_ply_cvrg plycvrg,
           web_prd_cvrg cvrg

      where prod.c_prod_no = ply.c_prod_no
        and base.c_app_no = plycvrg.c_app_no
        and plycvrg.c_cvrg_no = cvrg.c_cvrg_no
        and plycvrg.n_prm_var <> 0
        and ply.c_kind_no = '03'
        and ply.c_prod_no <> '0320'
        and ply.n_edr_prj_no<>0
        and base.c_edr_no = ply.c_edr_no
        and base.n_edr_prj_no = ply.n_edr_prj_no
        and ply.c_prm_cur = cur.c_cur_cde
        and dpt.c_dpt_cde = substr(ply.c_dpt_cde,1,2)
        and substr(ply.c_dpt_cde,1,4) = dpt2.c_dpt_cde
        and base.c_app_no = app.c_app_no(+)
        and ply.t_due_tm <= acc.t_end_tm
       -- and ply.t_due_tm >= acc.t_bgn_tm
        and acc.c_mrk = '2'
        ---------------------
        group by
           ply.c_edr_no,ply.c_kind_no,ply.c_prod_no,app.c_app_no,
           ply.c_dpt_cde,dpt.c_dpt_cnm,dpt2.c_dpt_cnm,prod.c_nme_cn,
           base.c_inwd_mrk,dpt.c_dpt_cnm,base.c_edr_type,cur.c_cur_cnm,
           ply.c_prm_cur,app.c_stk_mrk,ply.n_edr_prj_no,base.c_grp_mrk,
           base.t_udr_tm,base.t_edr_bgn_tm,base.t_edr_end_tm,cvrg.c_nme_cn,
           acc.t_end_tm,ply.t_vehicle_layoff_end_tm,ply.t_vehicle_layoff_bgn_tm
/
