CREATE VIEW V_EDR_NOVHLCOPY AS select --再保前批单明细(非车,交强险)
      nvl(a.c_edr_no, '---') as c_edr_no,
      case when substr(a.c_dpt_cde,1,4)= '0199' then '重点项目部' else  dpt.c_dpt_cnm end as c_dpt_cnm,   --机构
      dpt2.c_dpt_cnm as  三级机构,
      rpfunction.getKindName(prod.c_kind_no,a.c_prod_no,'')  as c_kind_name,
      prod.c_nme_cn          as c_prod_name,
      '---'                  as c_cvrg_name,
      decode(nvl(a.c_grp_mrk, '0'), '0','个人', '团单')  as c_grp_mrk,
      decode(nvl(app.c_stk_mrk,'0'),'0','非股东','股东') as c_stk_mrk,
      decode(nvl(a.c_inwd_mrk,'0'),'0','非分入','分入')  as c_inwd_mrk,
      cur.c_cur_cnm          as c_cur_name,
      case when a.c_ci_mrk = '3' then (select ci.n_ci_prm_var from web_ply_ci ci where ci.c_app_no = a.c_app_no)
          else a.n_prm_var end  as n_prm,
       case when a.c_prm_cur = '01'
         then
           case when a.c_ci_mrk = '3'
            then (select ci.n_ci_prm_var from web_ply_ci ci where ci.c_app_no = a.c_app_no)
             else a.n_prm_var end
         else (case when a.c_ci_mrk = '3'
                then (select ci.n_ci_prm_var from web_ply_ci ci where ci.c_app_no = a.c_app_no)
                else a.n_prm_var end)*
                get_rate(a.c_prm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))) end as n_prm_rmb,
       to_char(a.t_udr_tm,'yyyy-mm-dd hh24:mi:ss')     as t_udr_tm,     --核保日期
       to_char(a.t_edr_bgn_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_bgn_tm,
       to_char(a.t_edr_end_tm,'yyyy-mm-dd hh24:mi:ss') as t_edr_end_tm,
       get_edrsn(a.c_app_no,prod.c_kind_no) as c_edr_rsn,
       decode(nvl(a.c_edr_type,'1'),'1','一般批改','3','退保','2','注销') as c_edr_type,
       to_char(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)),'yyyy-mm-dd')||' 23:59:59' as  t_cal_tm,   --评估日
       f.N_FEE_PROP    as n_fee_prop,
       cur.c_cur_cnm   as c_feecur_name,
       f.N_FEE         as n_fee,
       case when a.c_prm_cur = '01' then f.N_FEE
         else f.N_FEE* get_rate(a.c_prm_cur,'01',trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))) end as n_fee_rmb,
       prod.c_kind_no,
       a.c_prod_no

  from web_ply_base a, WEB_ply_FEE f, /*web_prd_kind kind,*/ web_prd_prod prod,
       web_org_dpt dpt,web_ply_applicant app,web_bas_fin_cur cur,web_org_dpt dpt2
 where a.c_app_no = f.c_app_no
   and a.c_app_no = app.c_app_no
   and trunc(a.t_insrnc_bgn_tm) <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and trunc(a.t_edr_bgn_tm)   <= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and (a.n_prm_var<>0 or a.c_edr_rsn_bundle_cde like '%12%')
   and nvl(a.c_edr_no, '---') <> '---'
   and f.C_FEETYP_CDE = 'S'
   and a.c_prod_no = prod.c_prod_no
   --and substr(a.c_prod_no, 1, 2) = kind.c_kind_no
   and trunc(a.t_udr_tm)<= trunc(LAST_DAY(ADD_MONTHS(LAST_DAY(SYSDATE) + 1, -2)))
   and dpt.c_dpt_cde = substr(a.c_dpt_cde,1,2)
   and substr(a.c_dpt_cde,1,4) = dpt2.c_dpt_cde
   and a.c_prm_cur = cur.c_cur_cde
   and exists (
           select 1 from web_prd_prod prod where prod.c_prod_no = a.c_prod_no and (prod.c_prod_no='0320' or prod.c_kind_no <> '03' ))
/
