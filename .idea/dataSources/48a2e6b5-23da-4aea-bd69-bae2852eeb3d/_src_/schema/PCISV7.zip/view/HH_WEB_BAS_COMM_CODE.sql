CREATE VIEW HH_WEB_BAS_COMM_CODE AS SELECT
c_cde as c_cde,
c_par_cde as c_par_cde ,
c_cnm as c_cnm,
c_out_cde as c_out_cde,
c_disp_cde as c_disp_cde,
c_enm as c_enm,
c_remark as c_remark,
n_value as n_value,
n_max_value as  n_max_value,
c_rel_cde as c_rel_cde,
n_level as n_level,
c_is_valid as c_is_valid,
c_trans_mrk as c_trans_mrk,
t_trans_tm as t_trans_tm
FROM WEB_BAS_COMM_CODE
/
COMMENT ON VIEW HH_WEB_BAS_COMM_CODE IS 'snapshot table for snapshot REPORTHH1.hh_WEB_BAS_COMM_CODE'
/
COMMENT ON COLUMN HH_WEB_BAS_COMM_CODE.C_CDE IS '  系统自动生成的代码，存储在业务表中的代码，以6位的序列生成'
/
COMMENT ON COLUMN HH_WEB_BAS_COMM_CODE.C_PAR_CDE IS '  根节点为 -1'
/
COMMENT ON COLUMN HH_WEB_BAS_COMM_CODE.C_OUT_CDE IS '  存保标委代码'
/
COMMENT ON COLUMN HH_WEB_BAS_COMM_CODE.C_DISP_CDE IS '  界面显示代码,缺省与标委代码相同'
/
COMMENT ON COLUMN HH_WEB_BAS_COMM_CODE.N_MAX_VALUE IS '  对于数值区间，存区间的上限值'
/
COMMENT ON COLUMN HH_WEB_BAS_COMM_CODE.C_REL_CDE IS '  用以存储代码的关系信息，以代码加;组成'
/
