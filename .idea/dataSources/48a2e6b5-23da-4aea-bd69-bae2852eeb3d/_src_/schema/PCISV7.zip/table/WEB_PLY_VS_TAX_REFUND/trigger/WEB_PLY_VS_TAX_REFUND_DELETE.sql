CREATE TRIGGER WEB_PLY_VS_TAX_REFUND_DELETE
BEFORE DELETE
  ON WEB_PLY_VS_TAX_REFUND
FOR EACH ROW
  begin
  insert into WEB_PLY_VS_TAX_REFUND_DELETE values(:old.c_pk_id,:old.c_app_no,
  :old.c_app_typ,:old.c_ply_no,:old.c_edr_no,:old.n_agg_tax_var,:old.n_return_ratio,:old.n_return_amount,
  :old.t_ply_crt_tm,:old.c_crt_cde,:old.t_crt_tm,:old.c_upd_cde,:old.t_upd_tm);
end;
/
