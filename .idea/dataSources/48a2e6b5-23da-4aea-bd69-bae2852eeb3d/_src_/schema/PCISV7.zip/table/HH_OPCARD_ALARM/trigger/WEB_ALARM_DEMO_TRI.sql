CREATE TRIGGER WEB_ALARM_DEMO_TRI
BEFORE INSERT
  ON HH_OPCARD_ALARM
FOR EACH ROW
  begin   /*触发器开始*/    
select  WEB_ALARM_DEMO_seq.nextval into :new.C_ID from dual;   
/*触发器主题内容，即触发后执行的动作，在此是取得序列WEB_ALARM_DEMO_LOG的下一个值插入到表dectuser中的C_ID字段中*/    
end;
/
