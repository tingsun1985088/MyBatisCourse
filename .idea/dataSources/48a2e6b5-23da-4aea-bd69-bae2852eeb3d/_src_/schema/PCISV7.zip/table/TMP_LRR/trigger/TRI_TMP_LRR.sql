CREATE TRIGGER TRI_TMP_LRR
BEFORE INSERT
  ON TMP_LRR
FOR EACH ROW
  BEGIN
  IF INSERTING THEN
    if substr(:NEW.c_str1,1,4) <> '1073' then
     :NEW.c_str3 := '0';
    end if;
  END IF;
END;
/
